// Storm Ace — endless top-down sky shooter with roguelike upgrades (Canvas 2D, portrait first).
// Guns hit planes. Bombs hit SAM sites, flak, boats and surfaced subs. Every sector ends with a boss, then the next biome.
// ?auto=1 lets a bot fly (recording / testing), ?t=N fast-forwards N seconds, ?sector=N starts there, ?nodie, ?seed=N.
import { CARDS, RELICS, ENEMIES, BOSSES, BOSS_ORDER, BIOMES, BIOME_ORDER, SHIPS, HANGAR } from './data.js';
import { Ads } from './ads.js';

const params = new URLSearchParams(location.search);
const AUTO = params.has('auto'), NODIE = params.has('nodie');
const FFWD = parseFloat(params.get('t') || '0');
const START_SECTOR = Math.max(1, parseInt(params.get('sector') || '1', 10));
let seed = params.has('seed') ? +params.get('seed') : (Math.random() * 1e9) | 0;
function rand() {
  seed = (seed + 0x6D2B79F5) | 0;
  let t = seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const rr = (a, b) => a + rand() * (b - a);
const ri = (a, b) => Math.floor(rr(a, b + 1));
const pick = (a) => a[Math.floor(rand() * a.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const TAU = Math.PI * 2;

// ---------- DOM / canvas ----------
const $ = (id) => document.getElementById(id);
const app = $('app'), cv = $('view'), ctx = cv.getContext('2d');
const MOBILE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && innerWidth < 900);
const VW = 540;               // screen width in units; height follows the screen
const WW = VW * 3;            // the world loops sideways every WW units (fly left or right forever)
let camX = 0;                 // world x at the screen's left edge
const wrapX = (x) => ((x % WW) + WW) % WW;
const wrapD = (d) => d - Math.round(d / WW) * WW; // shortest signed distance around the loop
let VH = 960, S = 1, DPR = 1; // S = canvas pixels per unit
function resize() {
  const w = app.clientWidth, h = app.clientHeight;
  DPR = Math.min(devicePixelRatio || 1, 2);
  cv.width = Math.round(w * DPR); cv.height = Math.round(h * DPR);
  const oldS = S;
  S = cv.width / VW; VH = cv.height / S;
  if (Math.abs(oldS - S) / S > 0.1) chunks.clear(); // terrain is baked at screen resolution
  ctx.imageSmoothingQuality = 'high';
}

// ---------- sprites ----------
const SPR = {};
function loadImg(src, tries = 4) { // retries: the public Tailscale link drops the odd request in a burst (502)
  return new Promise((res, rej) => {
    const i = new Image(); i.onload = () => res(i);
    i.onerror = () => tries > 1 ? setTimeout(() => loadImg(src, tries - 1).then(res, rej), 400) : rej();
    i.src = src;
  });
}
async function loadSprites() {
  let man = {};
  try { man = await (await fetch('sprites/manifest.json', { cache: 'no-cache' })).json(); } catch (e) { /* no art yet */ }
  await Promise.all(Object.entries(man).map(([n, m]) => loadImg('sprites/' + m.file)
    .then((img) => { SPR[n] = { img, fw: m.w, h: m.h, frames: m.frames }; }).catch(() => {})));
}
function silhouette(sp, color) {
  const key = 'sil' + color;
  if (!sp[key]) {
    const c = document.createElement('canvas'); c.width = sp.img.width; c.height = sp.img.height;
    const g = c.getContext('2d'); g.drawImage(sp.img, 0, 0);
    g.globalCompositeOperation = 'source-in'; g.fillStyle = color; g.fillRect(0, 0, c.width, c.height);
    sp[key] = c;
  }
  return sp[key];
}
const iconCache = new Map();
function iconURL(sheet, frame = 0, size = 96) {
  const key = sheet + frame;
  if (iconCache.has(key)) return iconCache.get(key);
  const sp = SPR[sheet];
  if (!sp) return '';
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d'); const k = size / Math.max(sp.fw, sp.h);
  g.drawImage(sp.img, frame * sp.fw, 0, sp.fw, sp.h, (size - sp.fw * k) / 2, (size - sp.h * k) / 2, sp.fw * k, sp.h * k);
  const url = c.toDataURL(); iconCache.set(key, url); return url;
}
const iconOf = (ic) => `url(${iconURL(ic[0], ic[1])})`;

let shx = 0, shy = 0; // screen shake (units)
function xf(x, y, rot = 0, k = 1, sx = 1) {
  const c = Math.cos(rot) * k * S, s = Math.sin(rot) * k * S;
  ctx.setTransform(c * sx, s * sx, -s, c, (x + shx) * S, (y + shy) * S);
}
const base = () => ctx.setTransform(S, 0, 0, S, shx * S, shy * S);
// size = longest side in world units, rot 0 = nose up
function sprite(name, x, y, size, rot = 0, alpha = 1, flash = 0, sx = 1, frame = 0, tint = null) {
  const sp = SPR[name];
  if (!sp) { // art not painted yet: a readable placeholder
    base(); ctx.globalAlpha = alpha; ctx.fillStyle = tint || '#c8cde0'; ctx.strokeStyle = '#111'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y, size * 0.4, 0, TAU); ctx.fill(); ctx.stroke(); ctx.globalAlpha = 1; return;
  }
  xf(x, y, rot, size / Math.max(sp.fw, sp.h), sx);
  ctx.globalAlpha = alpha;
  ctx.drawImage(tint ? silhouette(sp, tint) : sp.img, frame * sp.fw, 0, sp.fw, sp.h, -sp.fw / 2, -sp.h / 2, sp.fw, sp.h);
  if (flash > 0) {
    ctx.globalAlpha = alpha * Math.min(1, flash);
    ctx.drawImage(silhouette(sp, '#ffffff'), frame * sp.fw, 0, sp.fw, sp.h, -sp.fw / 2, -sp.h / 2, sp.fw, sp.h);
  }
  ctx.globalAlpha = 1;
}
const SHADOW = '#020308';
function shadowOf(name, x, y, size, rot, h = 1) {
  sprite(name, x + 16 * h, y + 26 * h, size * 0.82, rot, 0.26, 0, 1, 0, SHADOW);
}

// pre-rendered bullets (no shadowBlur anywhere: it is the biggest frame cost on phones, see MOBILE_PERFORMANCE.md)
function makeCanvas(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); return c; }
function orbTex(r, col, core = '#fff') { // 4 px per unit; the canvas spans 1.8r units around the centre
  const k = 4, h = Math.ceil(1.8 * r * k), R = r * k;
  return makeCanvas(h * 2, h * 2, (g) => {
    let gr = g.createRadialGradient(h, h, R * 0.5, h, h, h); gr.addColorStop(0, col + 'aa'); gr.addColorStop(0.45, col + '40'); gr.addColorStop(1, col + '00');
    g.fillStyle = gr; g.fillRect(0, 0, h * 2, h * 2);
    g.beginPath(); g.arc(h, h, R, 0, TAU); g.fillStyle = 'rgba(20,4,10,.55)'; g.fill(); // thin dark rim keeps it readable on bright ground
    gr = g.createRadialGradient(h, h, 0, h, h, R * 0.92);
    gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.38, core); gr.addColorStop(0.62, col); gr.addColorStop(1, col);
    g.beginPath(); g.arc(h, h, R * 0.92, 0, TAU); g.fillStyle = gr; g.fill();
  });
}
const TEX = {
  shot: makeCanvas(40, 160, (g, w, h) => {
    g.save(); g.translate(w / 2, h / 2); g.scale(1, 4);
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, w / 2); gr.addColorStop(0, 'rgba(255,190,70,.75)'); gr.addColorStop(0.5, 'rgba(255,140,30,.22)'); gr.addColorStop(1, 'rgba(255,120,20,0)');
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, w / 2, 0, TAU); g.fill(); g.restore();
    const tail = (y0, y1, wd, c0, c1) => { const lg = g.createLinearGradient(0, y0, 0, y1); lg.addColorStop(0, c0); lg.addColorStop(1, c1); g.fillStyle = lg;
      g.beginPath(); g.moveTo(w / 2, y0); g.quadraticCurveTo(w / 2 + wd, y0 + wd * 2, w / 2 + wd * 0.5, y1); g.lineTo(w / 2 - wd * 0.5, y1); g.quadraticCurveTo(w / 2 - wd, y0 + wd * 2, w / 2, y0); g.fill(); };
    tail(14, h - 18, 7, 'rgba(255,230,140,1)', 'rgba(255,150,40,0)');
    tail(18, h * 0.62, 3.2, '#ffffff', 'rgba(255,240,190,0)');
  }),
  flash: makeCanvas(64, 64, (g) => { // muzzle flash star
    g.translate(32, 32);
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, 32); gr.addColorStop(0, 'rgba(255,255,230,1)'); gr.addColorStop(0.25, 'rgba(255,200,90,.8)'); gr.addColorStop(1, 'rgba(255,120,20,0)');
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, 32, 0, TAU); g.fill();
    g.fillStyle = 'rgba(255,250,220,.9)';
    for (let i = 0; i < 4; i++) { g.rotate(TAU / 4 + (i % 2) * 0.2); g.beginPath(); g.moveTo(-3, 0); g.lineTo(0, -30 + (i % 2) * 12); g.lineTo(3, 0); g.fill(); }
  }),
  trail: makeCanvas(24, 96, (g, w, h) => { // rocket exhaust: hot at the nozzle, fading out
    const lg = g.createLinearGradient(0, 0, 0, h); lg.addColorStop(0, 'rgba(255,240,200,1)'); lg.addColorStop(0.2, 'rgba(255,150,50,.8)'); lg.addColorStop(1, 'rgba(120,60,40,0)');
    g.fillStyle = lg; g.beginPath(); g.moveTo(w / 2 - 5, 0); g.lineTo(w / 2 + 5, 0); g.lineTo(w / 2 + 10, h); g.lineTo(w / 2 - 10, h); g.fill();
  }),
  orb: orbTex(7, '#ff3b4a'), shell: orbTex(10, '#ff8a2a', '#ffe9a0'), flak: orbTex(5, '#ffd034'), purple: orbTex(8, '#b05cff'),
  // additive fire light (drawn with 'lighter') and the dark vignette over the whole screen
  glow: makeCanvas(128, 128, (g) => {
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(255,170,90,.75)'); gr.addColorStop(0.35, 'rgba(255,110,40,.3)'); gr.addColorStop(1, 'rgba(255,80,20,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  }),
  vignette: makeCanvas(256, 448, (g, w, h) => {
    const gr = g.createRadialGradient(w / 2, h * 0.55, h * 0.18, w / 2, h * 0.55, h * 0.62);
    gr.addColorStop(0, 'rgba(6,4,14,0)'); gr.addColorStop(0.6, 'rgba(6,4,14,.38)'); gr.addColorStop(1, 'rgba(4,2,10,.86)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
  }),
};
function laserTex(rgb) {
  return makeCanvas(48, 240, (g, w, h) => {
    g.save(); g.translate(w / 2, h / 2); g.scale(1, 5.5);
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, w / 2); gr.addColorStop(0, `rgba(${rgb},.85)`); gr.addColorStop(0.4, `rgba(${rgb},.3)`); gr.addColorStop(1, `rgba(${rgb},0)`);
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, w / 2, 0, TAU); g.fill(); g.restore();
    const cap = (bw, a, col) => { g.fillStyle = col; g.globalAlpha = a; g.beginPath(); g.roundRect(w / 2 - bw / 2, 22, bw, h - 44, bw / 2); g.fill(); };
    cap(20, 1, `rgb(${rgb})`); cap(10, 1, '#ffffff'); g.globalAlpha = 1;
  });
}
function missileTex(body, nose, len) {
  const k = 6, w = 14 * k, h = len * k, cx = w / 2;
  return makeCanvas(w, h, (g) => {
    const bw = 2.6 * k, top = 0.5 * k, noseEnd = h * 0.34, tail = h - 1.5 * k;
    g.lineJoin = 'round'; g.strokeStyle = '#0a0606'; g.lineWidth = 0.9 * k;
    const fins = (y0, span, back) => { g.beginPath(); g.moveTo(cx - bw * 0.5, y0); g.lineTo(cx - span, y0 + back); g.lineTo(cx - span, y0 + back + 1.4 * k); g.lineTo(cx - bw * 0.5, y0 + back * 0.85);
      g.lineTo(cx + bw * 0.5, y0 + back * 0.85); g.lineTo(cx + span, y0 + back + 1.4 * k); g.lineTo(cx + span, y0 + back); g.lineTo(cx + bw * 0.5, y0); g.closePath(); };
    fins(tail - 5.2 * k, 6.2 * k, 3.6 * k); g.fillStyle = '#2a2622'; g.fill(); g.stroke();           // tail fins
    fins(noseEnd + 1.2 * k, 3.4 * k, 2.4 * k); g.fill(); g.stroke();                                  // small canards
    const hull = () => { g.beginPath(); g.moveTo(cx, top); g.bezierCurveTo(cx + bw * 0.25, top + noseEnd * 0.35, cx + bw * 0.5, noseEnd * 0.75, cx + bw * 0.5, noseEnd);
      g.lineTo(cx + bw * 0.5, tail); g.lineTo(cx - bw * 0.5, tail); g.lineTo(cx - bw * 0.5, noseEnd); g.bezierCurveTo(cx - bw * 0.5, noseEnd * 0.75, cx - bw * 0.25, top + noseEnd * 0.35, cx, top); g.closePath(); };
    hull(); g.fillStyle = body; g.fill();
    g.save(); hull(); g.clip();
    g.fillStyle = nose; g.fillRect(0, 0, w, noseEnd);                                                  // painted nose cone
    g.fillStyle = 'rgba(255,255,255,.28)'; g.fillRect(cx - bw * 0.42, 0, bw * 0.22, h);               // highlight
    g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(cx + bw * 0.18, 0, bw * 0.4, h);                      // shade
    g.fillStyle = 'rgba(0,0,0,.45)'; g.fillRect(0, noseEnd, w, 0.5 * k); g.fillRect(0, h * 0.62, w, 0.4 * k); // panel lines
    g.restore();
    hull(); g.stroke();
    g.fillStyle = '#ffb060'; g.fillRect(cx - bw * 0.35, tail - 0.2 * k, bw * 0.7, 1 * k);            // hot nozzle
  });
}
TEX.missile = missileTex('#6a6458', '#c0402a', 26);
TEX.bomb = makeCanvas(72, 150, (g, w, h) => { // aerial bomb, nose up: pointed teardrop body, yellow band, box-tail fins
  const cx = w / 2; g.lineJoin = 'round'; g.strokeStyle = '#0a0806'; g.lineWidth = 5;
  g.beginPath(); g.moveTo(cx - 9, 104); g.lineTo(cx - 30, 132); g.lineTo(cx - 30, 146); g.lineTo(cx + 30, 146); g.lineTo(cx + 30, 132); g.lineTo(cx + 9, 104); g.closePath();
  g.fillStyle = '#3a3c30'; g.fill(); g.stroke();
  g.fillStyle = '#26281f'; g.fillRect(cx - 27, 134, 54, 9);
  const body = () => { g.beginPath(); g.moveTo(cx, 4); g.bezierCurveTo(cx + 15, 16, cx + 21, 40, cx + 20, 62); g.bezierCurveTo(cx + 19, 88, cx + 11, 104, cx + 7, 116);
    g.lineTo(cx - 7, 116); g.bezierCurveTo(cx - 11, 104, cx - 19, 88, cx - 20, 62); g.bezierCurveTo(cx - 21, 40, cx - 15, 16, cx, 4); g.closePath(); };
  body(); g.fillStyle = '#4a4e3a'; g.fill();
  g.save(); body(); g.clip();
  g.fillStyle = '#d8b030'; g.fillRect(0, 24, w, 7);                         // yellow nose band
  g.fillStyle = 'rgba(255,255,255,.22)'; g.fillRect(cx - 14, 0, 7, h);       // highlight
  g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(cx + 6, 0, 16, h);             // shade
  g.restore(); body(); g.stroke();
});
TEX.torp = makeCanvas(40, 168, (g, w, h) => { // torpedo, nose up: slim hull, pointed warhead, cross fins and a prop
  const cx = w / 2; g.lineJoin = 'round'; g.strokeStyle = '#06080a'; g.lineWidth = 4;
  g.fillStyle = '#1e2a30'; g.beginPath(); g.moveTo(cx - 6, 140); g.lineTo(cx - 17, 156); g.lineTo(cx + 17, 156); g.lineTo(cx + 6, 140); g.closePath(); g.fill(); g.stroke();
  const body = () => { g.beginPath(); g.moveTo(cx, 4); g.bezierCurveTo(cx + 8, 14, cx + 10, 30, cx + 10, 44); g.lineTo(cx + 10, 146); g.lineTo(cx - 10, 146); g.lineTo(cx - 10, 44); g.bezierCurveTo(cx - 10, 30, cx - 8, 14, cx, 4); g.closePath(); };
  body(); g.fillStyle = '#3c4c56'; g.fill();
  g.save(); body(); g.clip();
  g.fillStyle = '#b0402a'; g.fillRect(0, 0, w, 34);                          // red warhead
  g.fillStyle = 'rgba(255,255,255,.22)'; g.fillRect(cx - 7, 0, 4, h); g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(cx + 3, 0, 8, h);
  g.fillStyle = 'rgba(0,0,0,.45)'; g.fillRect(0, 34, w, 3); g.fillRect(0, 96, w, 3);
  g.restore(); body(); g.stroke();
  g.fillStyle = '#c8b070'; g.fillRect(cx - 9, 158, 18, 5);                   // prop
});
TEX.laser = laserTex('70,170,255');  // the player's guns
TEX.laserR = laserTex('255,40,60');  // enemy jets
TEX.beam = makeCanvas(96, 4, (g, w, h) => { // cross-section of the Laser Lance, stretched along its length
  const lg = g.createLinearGradient(0, 0, w, 0);
  for (const [o, c] of [[0, 'rgba(40,120,255,0)'], [0.2, 'rgba(40,130,255,.35)'], [0.38, 'rgba(90,200,255,.95)'], [0.45, '#ffffff'], [0.55, '#ffffff'], [0.62, 'rgba(90,200,255,.95)'], [0.8, 'rgba(40,130,255,.35)'], [1, 'rgba(40,120,255,0)']]) lg.addColorStop(o, c);
  g.fillStyle = lg; g.fillRect(0, 0, w, h);
});
TEX.beamR = makeCanvas(96, 4, (g, w, h) => { // enemy jet laser: the same beam in red
  const lg = g.createLinearGradient(0, 0, w, 0);
  for (const [o, c] of [[0, 'rgba(255,30,40,0)'], [0.25, 'rgba(255,40,50,.4)'], [0.4, 'rgba(255,90,90,.95)'], [0.47, '#ffffff'], [0.53, '#ffffff'], [0.6, 'rgba(255,90,90,.95)'], [0.75, 'rgba(255,40,50,.4)'], [1, 'rgba(255,30,40,0)']]) lg.addColorStop(o, c);
  g.fillStyle = lg; g.fillRect(0, 0, w, h);
});
TEX.hit = makeCanvas(64, 64, (g) => { // small cool-white impact flare
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(150,215,255,.8)'); gr.addColorStop(1, 'rgba(60,140,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
});
TEX.emissile = missileTex('#3e3a36', '#ff3b4a', 30);
const ETEX = { orb: TEX.orb, shell: TEX.shell, flak: TEX.flak, ring: TEX.purple };
const ER = { orb: 7, shell: 10, flak: 5, ring: 8, rocket: 7, laser: 6 };

// ---------- terrain: value-noise islands, baked into canvas chunks with marching squares ----------
let worldSeed = 1;
function hash2(i, j) {
  let h = (Math.imul(i, 374761393) + Math.imul(j, 668265263) + Math.imul(worldSeed, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296;
}
function vnoise(x, y) {
  const i = Math.floor(x), j = Math.floor(y), fx = x - i, fy = y - j;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  const a = hash2(i, j), b = hash2(i + 1, j), c = hash2(i, j + 1), d = hash2(i + 1, j + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
const fbm = (x, y) => (vnoise(x, y) + 0.5 * vnoise(x * 2.03 + 17.1, y * 2.03 + 3.7) + 0.25 * vnoise(x * 4.1 + 5.3, y * 4.1 + 11.9)) / 1.75;
const CH = 240, CELL = 6, COLS = WW / CELL + 1, ROWS = CH / CELL + 1;
let segs = [];   // terrain segments: { start (bottom wy, it applies above), biome, force, forceStart }
let bands = [];  // cloud bands that hide biome seams (wy)
const chunks = new Map();
let genTop = 0;  // smallest wy that has been baked
function segAt(wy) { for (let i = segs.length - 1; i > 0; i--) if (wy < segs[i].start) return segs[i]; return segs[0]; }
function field(x, wy, seg = segAt(wy)) { return fieldW(wrapX(x + camX), wy, seg); }
const loopBlend = (fn, wx) => { const k = clamp((wx - (WW - 300)) / 300, 0, 1); return k ? lerp(fn(wx), fn(wx - WW), k) : fn(wx); };
function fieldW(wx, wy, seg = segAt(wy)) {
  if (envOf(seg.biome)) return envField(wx, wy, seg);
  return loopBlend((x) => fieldRaw(x, wy, seg), wx);
}
function fieldRaw(x, wy, seg) {
  const B = seg.biome, f = 0.0045 * B.freq;
  const n = (fbm(x * f, wy * f) - 0.5) * 2.2;
  let v = n + B.bias;
  if (B.coast) v += clamp((VW * 0.5 + 150 * Math.sin(wy * 0.0011) + 60 * Math.sin(wy * 0.0029 + 1) - x) / 220, -1, 1) * 0.6;
  if (seg.force) v = lerp(v, seg.force * 0.7 + n * 0.25, clamp((seg.forceStart - wy) / 300, 0, 1));
  return v;
}
const isLand = (x, y) => field(x, y + cam) > 0.1;
const isSea = (x, y) => field(x, y + cam) < -0.1;

function contour(g, grid, t, fill, stroke, lw) {
  const fp = new Path2D(), sp = new Path2D();
  const pts = [];
  for (let j = 0; j < ROWS - 1; j++) for (let i = 0; i < COLS - 1; i++) {
    const a = grid[j * COLS + i], b = grid[j * COLS + i + 1], c = grid[(j + 1) * COLS + i + 1], d = grid[(j + 1) * COLS + i];
    const m = (a > t) | ((b > t) << 1) | ((c > t) << 2) | ((d > t) << 3);
    if (!m) continue;
    const x0 = i * CELL, y0 = j * CELL, x1 = x0 + CELL, y1 = y0 + CELL;
    if (m === 15) { fp.rect(x0, y0, CELL, CELL); continue; }
    const cx = [x0, x1, x1, x0], cy = [y0, y0, y1, y1], cvv = [a, b, c, d];
    pts.length = 0;
    for (let k = 0; k < 4; k++) {
      const q = (k + 1) & 3, pin = cvv[k] > t, qin = cvv[q] > t;
      if (pin) pts.push(cx[k], cy[k], 0);
      if (pin !== qin) { const s = (t - cvv[k]) / (cvv[q] - cvv[k]); pts.push(cx[k] + (cx[q] - cx[k]) * s, cy[k] + (cy[q] - cy[k]) * s, 1); }
    }
    const n = pts.length / 3;
    fp.moveTo(pts[0], pts[1]);
    for (let k = 1; k < n; k++) fp.lineTo(pts[k * 3], pts[k * 3 + 1]);
    fp.closePath();
    if (stroke) for (let k = 0; k < n; k++) {
      const q = (k + 1) % n;
      if (pts[k * 3 + 2] && pts[q * 3 + 2]) { sp.moveTo(pts[k * 3], pts[k * 3 + 1]); sp.lineTo(pts[q * 3], pts[q * 3 + 1]); }
    }
  }
  g.fillStyle = fill; g.fill(fp);
  if (stroke) { g.strokeStyle = stroke; g.lineWidth = lw; g.lineCap = 'round'; g.stroke(sp); }
}
const DECOR_SIZE = { palm: 50, tree: 46, pine: 44, rock: 30, hut: 32 };

// Tileable ground textures made from periodic noise (built once per color): mottled dirt, grainy sand, streaky water.
// This is what keeps the terrain from looking like flat vector fills.
function th(i, j, s) { let h = (Math.imul(i, 374761393) + Math.imul(j, 668265263) + Math.imul(s, 1442695041)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
function tn(x, y, px, py, s) { // value noise that repeats every px by py cells
  const i = Math.floor(x), j = Math.floor(y), fx = x - i, fy = y - j, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  const i1 = (i + 1) % px, j1 = (j + 1) % py, a = th(i % px, j % py, s), b = th(i1, j % py, s), c = th(i % px, j1, s), d = th(i1, j1, s);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
const TEX_PX = 192, TEX_UNITS = 162; // texture size in pixels, and world units per tile (WW is a multiple: no seam)
const groundTex = new Map();
function groundImg(col, kind) {
  const key = col + kind; if (groundTex.has(key)) return groundTex.get(key);
  const n = parseInt(col.slice(1), 16), R = n >> 16, Gc = (n >> 8) & 255, Bc = n & 255;
  const c = makeCanvas(TEX_PX, TEX_PX, (g) => {
    const im = g.createImageData(TEX_PX, TEX_PX), d = im.data;
    for (let y = 0; y < TEX_PX; y++) for (let x = 0; x < TEX_PX; x++) {
      const u = x / TEX_PX, v = y / TEX_PX; let k, warm = 0;
      if (kind === 'water') { // long horizontal swell streaks + fine chop
        const s = 0.55 * tn(u * 3, v * 14, 3, 14, 1) + 0.3 * tn(u * 8, v * 36, 8, 36, 2) + 0.15 * tn(u * 24, v * 60, 24, 60, 3);
        k = 0.82 + (s - 0.5) * 0.55 + (s > 0.68 ? (s - 0.68) * 1.6 : 0);
      } else {
        const big = tn(u * 3, v * 3, 3, 3, 4), mid = tn(u * 10, v * 10, 10, 10, 5), fine = tn(u * 40, v * 40, 40, 40, 6);
        const grain = th(x, y, 7) - 0.5;
        if (kind === 'sand') k = 0.9 + (big - 0.5) * 0.22 + (mid - 0.5) * 0.18 + grain * 0.16;
        else { k = 0.84 + (big - 0.5) * 0.42 + (mid - 0.5) * 0.3 + (fine - 0.5) * 0.18 + grain * 0.1; warm = (mid - 0.5) * 18; }
      }
      const i = (y * TEX_PX + x) * 4;
      d[i] = R * k + warm; d[i + 1] = Gc * k; d[i + 2] = Bc * k - warm * 0.5; d[i + 3] = 255;
    }
    g.putImageData(im, 0, 0);
  });
  groundTex.set(key, c); return c;
}
function groundPat(g, col, kind, wy0) {
  const p = g.createPattern(groundImg(col, kind), 'repeat'), sc = TEX_UNITS / TEX_PX;
  p.setTransform(new DOMMatrix([sc, 0, 0, sc, 0, -(((wy0 % TEX_UNITS) + TEX_UNITS) % TEX_UNITS)])); // seamless across chunks
  return p;
}
// big soft patches of darkness, like torchlight falling unevenly on a dungeon floor
function shadeChunk(g, wy0, amt = 0.55) {
  const w = Math.ceil(WW / 20) + 1, h = Math.ceil(CH / 20) + 1;
  const m = makeCanvas(w, h, (x) => {
    const im = x.createImageData(w, h), d = im.data;
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const v = loopBlend((x) => fbm(x * 0.004 + 31.7, (wy0 + j * 20 + 10) * 0.004 - 8.3), i * 20 + 10), o = (j * w + i) * 4;
      d[o] = 4; d[o + 1] = 3; d[o + 2] = 12; d[o + 3] = clamp((v - 0.42) * 2.6, 0, amt) * 255;
    }
    x.putImageData(im, 0, 0);
  });
  g.imageSmoothingEnabled = true; g.drawImage(m, 0, 0, w * 20, h * 20);
}

// ---------- painted environment: Codex-painted ocean/land textures and island sprites (tools/make_env.py) ----------
// Islands are scattered at random over the ocean; each one's land mask decides where tanks drive and boats sail.
// A biome without painted art falls back to the procedural terrain above.
for (const k in BIOMES) BIOMES[k].key = k;
let envMan = {};
const ENV = {};
const SEA_UNITS = WW / 4, LAND_UNITS = WW / 4; // whole tiles per loop: no seam
const envOf = (B) => (ENV[B.key] && ENV[B.key].ready ? ENV[B.key] : null);
function loadEnv(key) {
  const m = envMan[key]; if (!m || ENV[key]) return ENV[key] && ENV[key].p;
  const E = ENV[key] = { tex: {}, islands: [], ready: false };
  const jobs = Object.entries(m.tex).map(([n, f]) => loadImg('env/' + f).then((img) => { E.tex[n] = img; }));
  for (const is of m.islands) jobs.push(Promise.all([loadImg('env/' + is.file), loadImg('env/' + is.mask)]).then(([img, mk]) => {
    const c = makeCanvas(mk.width, mk.height, (g) => g.drawImage(mk, 0, 0)), d = c.getContext('2d').getImageData(0, 0, mk.width, mk.height).data;
    const mask = new Float32Array(mk.width * mk.height); for (let i = 0; i < mask.length; i++) mask[i] = d[i * 4] / 255;
    E.islands.push({ name: is.name, img, w: is.w, h: is.h, size: is.size || 340, mask, mw: mk.width, mh: mk.height }); // size: longest side in units
  }));
  E.p = Promise.all(jobs).then(() => { E.islands.sort((a, b) => a.name < b.name ? -1 : 1); E.ready = E.islands.length > 0 && !!E.tex.sea; }).catch(() => {});
  return E.p;
}
function preloadEnv(sector) { return loadEnv(BIOME_ORDER[(sector - 1) % BIOME_ORDER.length]); }

let isles = [], placeTop = 0, isleSeed = 1, recentIsles = [];
function irand() { isleSeed = (isleSeed + 0x6d2b79f5) | 0; let t = Math.imul(isleSeed ^ (isleSeed >>> 15), 1 | isleSeed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
// place islands up to wy `need` (smaller wy = further ahead); none may reach into a chunk that is already baked
function placeIsles(need) {
  let guard = 0;
  while (placeTop > need && guard++ < 200) {
    placeTop -= 18 + irand() * 40;
    const seg = segAt(placeTop), E = envOf(seg.biome);
    if (!E || seg.force && placeTop < seg.forceStart + 240) continue;
    if (irand() < 0.35) continue; // open water
    // random island (not one of the last few), random size, flip and rotation: the same painting rarely looks the same
    const big = irand() < 0.6, pool = E.islands.filter((i) => i.size >= 300 === big && !recentIsles.includes(i.name));
    const from = pool.length ? pool : E.islands, I = from[Math.floor(irand() * from.length)];
    const k = I.size * (0.85 + irand() * 0.3) / Math.max(I.w, I.h), rot = (irand() - 0.5) * 0.3, cs = Math.abs(Math.cos(rot)), sn = Math.abs(Math.sin(rot));
    const hw = (cs * I.w + sn * I.h) * k / 2, hh = (sn * I.w + cs * I.h) * k / 2, y = Math.min(placeTop, genTop - hh - 4);
    for (let tries = 0; tries < 6; tries++) {
      const x = irand() * WW;
      if (isles.some((o) => Math.abs(wrapD(o.x - x)) < (o.hw + hw) * 0.8 && Math.abs(o.y - y) < (o.hh + hh) * 0.8)) continue;
      isles.push({ I, x, y, k, hw, hh, flip: irand() < 0.5 ? -1 : 1, rot, c: Math.cos(rot), s: Math.sin(rot) });
      recentIsles.push(I.name); if (recentIsles.length > Math.min(5, E.islands.length - 2)) recentIsles.shift();
      break;
    }
  }
}
function envField(x, wy, seg) {
  if (seg.force > 0 && wy < seg.forceStart) return 1;
  let v = -1;
  for (const s of isles) {
    const dx = wrapD(x - s.x);
    if (Math.abs(wy - s.y) > s.hh || Math.abs(dx) > s.hw) continue;
    const dy = wy - s.y, lx = dx * s.c + dy * s.s, ly = -dx * s.s + dy * s.c; // into the island's unrotated frame
    const I = s.I, u = (lx * s.flip / s.k + I.w / 2) / I.w * (I.mw - 1), w = (ly / s.k + I.h / 2) / I.h * (I.mh - 1);
    const i = Math.floor(u), j = Math.floor(w), fx = u - i, fy = w - j;
    if (i < 0 || j < 0 || i >= I.mw - 1 || j >= I.mh - 1) continue;
    const M = I.mask, o = j * I.mw + i;
    const m = (M[o] * (1 - fx) + M[o + 1] * fx) * (1 - fy) + (M[o + I.mw] * (1 - fx) + M[o + I.mw + 1] * fx) * fy;
    v = Math.max(v, m * 2.4 - 1.2);
  }
  return clamp(v, -1, 1);
}
function texPat(g, img, units, wy0) {
  const p = g.createPattern(img, 'repeat'), sc = units / img.width;
  p.setTransform(new DOMMatrix([sc, 0, 0, sc, 0, -(((wy0 % units) + units) % units)]));
  return p;
}
// tile `img` over the chunk, fading from invisible at local y `y0` to solid at `y1` (y1 < y0: it fades in going up)
function fadeTex(g, img, units, wy0, y0, y1) {
  const res = g.getTransform().a, c = makeCanvas(g.canvas.width, g.canvas.height, (h) => {
    h.scale(res, res); h.fillStyle = texPat(h, img, units, wy0); h.fillRect(0, 0, WW, CH);
    const lg = h.createLinearGradient(0, y0, 0, y1); lg.addColorStop(0, 'rgba(0,0,0,0)'); lg.addColorStop(1, '#000');
    h.globalCompositeOperation = 'destination-in'; h.fillStyle = lg; h.fillRect(0, 0, WW, CH);
  });
  g.drawImage(c, 0, 0, WW, CH);
}
const SEAM = 480; // units over which one biome's sea fades into the next
function bakeEnv(g, wy0, seg, E) {
  const i = segs.indexOf(seg), prev = i > 0 ? segs[i - 1] : null, PE = prev && envOf(prev.biome), y0 = seg.start - wy0;
  if (PE && PE !== E && y0 > 0 && y0 < SEAM + CH) {
    g.fillStyle = texPat(g, PE.tex.sea, SEA_UNITS, wy0); g.fillRect(0, 0, WW, CH);
    fadeTex(g, E.tex.sea, SEA_UNITS, wy0, y0, y0 - SEAM);
  } else { g.fillStyle = texPat(g, E.tex.sea, SEA_UNITS, wy0); g.fillRect(0, 0, WW, CH); }
  if (seg.force > 0 && E.tex.land && wy0 < seg.forceStart) {
    const f0 = seg.forceStart - wy0;
    if (f0 < 300 + CH) fadeTex(g, E.tex.land, LAND_UNITS, wy0, f0, f0 - 300);
    else { g.fillStyle = texPat(g, E.tex.land, LAND_UNITS, wy0); g.fillRect(0, 0, WW, CH); }
  }
  for (const s of isles) {
    if (s.y + s.hh < wy0 || s.y - s.hh > wy0 + CH) continue;
    for (const ox of [-WW, 0, WW]) {
      if (s.x + ox + s.hw < 0 || s.x + ox - s.hw > WW) continue;
      g.save(); g.translate(s.x + ox, s.y - wy0); g.rotate(s.rot); g.scale(s.flip * s.k, s.k); g.drawImage(s.I.img, -s.I.w / 2, -s.I.h / 2); g.restore();
    }
  }
}
function bakeChunk(k) {
  const wy0 = k * CH, seg = segAt(wy0 + CH / 2), B = seg.biome;
  const res = Math.min(S, MOBILE ? 1.7 : 2.2);
  const c = document.createElement('canvas'); c.width = Math.ceil(WW * res); c.height = Math.ceil(CH * res);
  const g = c.getContext('2d'); g.scale(res, res);
  const E = envOf(B);
  if (E) {
    placeIsles(wy0 - 700);
    bakeEnv(g, wy0, seg, E); shadeChunk(g, wy0, 0.3);
    chunks.set(k, { c, g, res, wy0 });
    return;
  }
  const grid = new Float32Array(COLS * ROWS);
  for (let j = 0; j < ROWS; j++) for (let i = 0; i < COLS; i++) grid[j * COLS + i] = fieldW(i * CELL, wy0 + j * CELL, seg);
  const pat = (col, kind) => groundPat(g, col, kind, wy0);
  g.fillStyle = pat(B.deep, 'water'); g.fillRect(0, 0, WW, CH);
  const sv = seed; seed = k * 7919 + worldSeed;
  // no cartoon outlines: soft dark shore falloff, a pale wet band, then textured layers
  contour(g, grid, -0.16, 'rgba(0,0,0,.18)', null, 0);
  contour(g, grid, -0.07, pat(B.shallow, 'water'), null, 0);
  contour(g, grid, -0.025, 'rgba(190,210,215,.13)', null, 0);
  contour(g, grid, 0, pat(B.sand, 'sand'), 'rgba(0,0,0,.16)', 7);
  contour(g, grid, 0, 'rgba(0,0,0,.16)', null, 0);   // wet sand at the waterline...
  contour(g, grid, 0.03, pat(B.sand, 'sand'), null, 0); // ...dry sand above it
  contour(g, grid, 0.1, pat(B.grass, 'ground'), 'rgba(0,0,0,.2)', 6);
  contour(g, grid, 0.3, pat(B.grass2, 'ground'), 'rgba(0,0,0,.18)', 5);
  shadeChunk(g, wy0);
  for (let n = 0; n < 140; n++) { // grit: dirt specks and pebbles on land, so it reads as worn ground, not flat paint
    const x = rr(0, WW), y = rr(0, CH);
    if (fieldW(x, wy0 + y, seg) < 0.02) continue;
    const r = rr(0.8, 2.6);
    g.fillStyle = rand() < 0.8 ? 'rgba(0,0,0,.22)' : 'rgba(255,240,210,.07)';
    g.beginPath(); g.ellipse(x, y, r * rr(1, 2.2), r, rr(0, TAU), 0, TAU); g.fill();
  }
  for (let n = 0; n < 18; n++) {
    const x = rr(12, WW - 12), y = rr(12, CH - 12), v = fieldW(x, wy0 + y, seg);
    const name = pick(B.decor);
    if (name === 'hut' && rand() < 0.65) continue;
    if (name === 'rock' ? v < 0.02 : v < 0.17) continue;
    if (name === 'hut' && v < 0.22) continue;
    const sp = SPR[name]; if (!sp) continue;
    const size = DECOR_SIZE[name] * rr(0.85, 1.2), kk = size / Math.max(sp.fw, sp.h), rot = name === 'hut' ? rr(-0.4, 0.4) : rr(0, TAU);
    for (const [ox, oy, img, a] of [[5, 7, silhouette(sp, SHADOW), 0.3], [0, 0, sp.img, 1]]) {
      g.save(); g.translate(x + ox, y + oy); g.rotate(rot); g.scale(kk, kk); g.globalAlpha = a;
      g.drawImage(img, -sp.fw / 2, -sp.h / 2); g.restore();
    }
  }
  seed = sv;
  chunks.set(k, { c, g, res, wy0 });
}
function updateTerrain() {
  const kTop = Math.floor((cam - CH * 1.2) / CH), kBot = Math.floor((cam + VH) / CH);
  for (let k = kBot; k >= kTop; k--) if (!chunks.has(k)) { bakeChunk(k); genTop = Math.min(genTop, k * CH); }
  for (const k of chunks.keys()) if (k > kBot + 1) chunks.delete(k);
  if (isles.length > 40) isles = isles.filter((s) => s.y - s.hh < cam + VH + 300);
}
// paint something permanent onto the ground (scorch marks, wrecks)
function decal(x, y, draw) {
  const wy = y + cam;
  for (const k of [Math.floor((wy - 40) / CH), Math.floor((wy + 40) / CH)]) {
    const ch = chunks.get(k); if (!ch || ch.done === wy) continue;
    ch.done = wy; const wx = wrapX(x + camX);
    for (const ox of [-WW, 0, WW]) if (wx + ox > -80 && wx + ox < WW + 80) { ch.g.save(); ch.g.translate(wx + ox, wy - ch.wy0); draw(ch.g); ch.g.restore(); }
  }
}
function scorch(x, y, r) {
  decal(x, y, (g) => {
    const gr = g.createRadialGradient(0, 0, r * 0.15, 0, 0, r); gr.addColorStop(0, 'rgba(25,15,15,.55)'); gr.addColorStop(1, 'rgba(25,15,15,0)');
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
  });
}

// ---------- audio (synth, no files) ----------
let AC = null, master = null, musicBus = null, noiseBuf = null, guitarBus = null, verb = null;
// 80s arcade fighter-jet sound, all synthesized: a compressor glues everything, a distortion bus makes synth "guitars",
// and a long reverb gives booms and the lead their arena size.
function initAudio() {
  if (AC) { if (AC.state !== 'running' && AC.state !== 'closed') AC.resume(); return; } // iOS leaves it "interrupted" too
  try { AC = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'playback' }); } catch (e) { return; }
  const comp = AC.createDynamicsCompressor(); comp.threshold.value = -16; comp.ratio.value = 5; comp.attack.value = 0.004; comp.release.value = 0.2;
  comp.connect(AC.destination);
  master = AC.createGain(); master.gain.value = meta.mute ? 0 : 0.6; master.connect(comp);
  verb = AC.createConvolver(); const len = AC.sampleRate * 1.8, ir = AC.createBuffer(2, len, AC.sampleRate);
  for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
  verb.buffer = ir; const vg = AC.createGain(); vg.gain.value = 0.22; verb.connect(vg).connect(master);
  musicBus = AC.createGain(); musicBus.gain.value = 0.32; musicBus.connect(master);
  const shaper = AC.createWaveShaper(), curve = new Float32Array(1024);
  for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; curve[i] = Math.tanh(x * 9) * 0.8; }
  shaper.curve = curve; shaper.oversample = '2x';
  const cab = AC.createBiquadFilter(); cab.type = 'lowpass'; cab.frequency.value = 3200; cab.Q.value = 0.8; // "amp cabinet"
  guitarBus = AC.createGain(); guitarBus.gain.value = 0.5; guitarBus.connect(shaper).connect(cab).connect(musicBus);
  noiseBuf = AC.createBuffer(1, AC.sampleRate, AC.sampleRate);
  const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  startMusic();
}
function tone(t, f0, f1, dur, type = 'square', vol = 0.08, dest = master, wet = 0) {
  const o = AC.createOscillator(), g = AC.createGain(); o.type = type;
  o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
  o.connect(g).connect(dest); if (wet) { const w = AC.createGain(); w.gain.value = wet; g.connect(w).connect(verb); }
  o.start(t); o.stop(t + dur + 0.02);
}
function noiz(t, dur, vol, f0 = 2000, f1 = 300, type = 'lowpass', dest = master, wet = 0, q = 1) {
  const s = AC.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
  const f = AC.createBiquadFilter(); f.type = type; f.Q.value = q; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
  const g = AC.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
  s.connect(f).connect(g).connect(dest); if (wet) { const w = AC.createGain(); w.gain.value = wet; g.connect(w).connect(verb); }
  s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
}
const vr = () => 1 + (Math.random() - 0.5) * 0.12;
const SFX = {
  shoot: (t) => { noiz(t, 0.05, 0.09, 2600 * vr(), 900, 'bandpass', master, 0, 1.4); tone(t, 150 * vr(), 60, 0.05, 'triangle', 0.09); }, // gatling "dakka"
  bomb: (t) => tone(t, 1700, 520, 0.9, 'sine', 0.018),                                                      // falling whistle
  boom: (t) => { noiz(t, 0.7, 0.34, 1500, 50, 'lowpass', master, 0.25); tone(t, 110 * vr(), 30, 0.5, 'sine', 0.38); noiz(t, 0.08, 0.15, 5000, 1500, 'highpass'); },
  pop: (t) => { noiz(t, 0.35, 0.22, 2600, 120, 'lowpass', master, 0.2); tone(t, 220 * vr(), 45, 0.25, 'sine', 0.2); },
  big: (t) => { noiz(t, 1.6, 0.45, 1100, 30, 'lowpass', master, 0.5); tone(t, 75, 22, 1.4, 'sine', 0.5); noiz(t, 0.15, 0.25, 6000, 1200, 'highpass'); },
  hit: (t) => { tone(t, 1900 * vr(), 1200, 0.04, 'square', 0.012); noiz(t, 0.03, 0.04, 7000, 4000, 'highpass'); },   // metal ping
  coin: (t) => { tone(t, 1568, 1568, 0.05, 'square', 0.022); tone(t + 0.05, 2093, 2093, 0.09, 'square', 0.022); },
  xp: (t) => tone(t, 1000 * vr(), 1700, 0.05, 'sine', 0.03),
  level: (t) => { for (const f of [392, 494, 587, 784]) tone(t, f, f, 0.5, 'sawtooth', 0.03, master, 0.4); tone(t + 0.12, 988, 988, 0.4, 'square', 0.03, master, 0.4); }, // brass stab
  hurt: (t) => { tone(t, 180, 45, 0.45, 'sawtooth', 0.14, master, 0.2); noiz(t, 0.4, 0.3, 2500, 100, 'lowpass', master, 0.2); },
  shield: (t) => tone(t, 300, 1600, 0.3, 'sine', 0.1, master, 0.3),
  warn: (t) => { for (let i = 0; i < 8; i++) tone(t + i * 0.13, i % 2 ? 1320 : 990, i % 2 ? 1320 : 990, 0.1, 'square', 0.05); }, // missile-lock alarm
  torp: (t) => noiz(t, 0.5, 0.1, 300, 1400, 'bandpass', master, 0.1, 2),
  rocket: (t) => noiz(t, 0.55, 0.12, 700, 3200, 'bandpass', master, 0.15, 1.5),                             // whoosh
  kaboom: (t) => { noiz(t, 1.1, 0.42, 1300, 35, 'lowpass', master, 0.45); tone(t, 95, 24, 0.9, 'sine', 0.55); noiz(t, 0.06, 0.3, 7000, 2000, 'highpass'); noiz(t + 0.12, 0.6, 0.08, 4000, 800, 'bandpass', master, 0.3, 0.6); }, // thump + crack + debris crackle
  zap: (t) => { noiz(t, 0.12, 0.08, 6000, 2000, 'highpass'); tone(t, 1800, 600, 0.1, 'sawtooth', 0.02); },
  pick: (t) => { tone(t, 660, 990, 0.1, 'triangle', 0.08); tone(t + 0.08, 990, 1320, 0.12, 'triangle', 0.06); },
  jet: (t) => { noiz(t, 1.6, 0.11, 2400, 300, 'bandpass', master, 0.25, 0.7); tone(t, 520, 180, 1.4, 'sawtooth', 0.012, master, 0.2); }, // fly-by roar
};
const lastSfx = {};
function sfx(name) {
  if (!AC || meta.mute || FF) return;
  const now = AC.currentTime, gap = name === 'shoot' ? 0.075 : name === 'xp' || name === 'hit' ? 0.05 : name === 'coin' ? 0.06 : name === 'jet' ? 0.8 : name === 'rocket' ? 0.09 : 0.03;
  if (now - (lastSfx[name] || 0) < gap) return;
  lastSfx[name] = now; SFX[name](now);
}
const mtof = (n) => 440 * Math.pow(2, (n - 69) / 12);
// Original 80s synth-rock loop (E minor, 140 bpm): palm-muted power chords for the verse, open chords plus a heroic
// lead for the chorus, a driving rock kit with a gated snare. Boss fights double the hats and keep the chorus on.
function powerChord(t, root, dur, muted) {
  for (const iv of [0, 7, 12]) for (const det of [-6, 6]) {
    const o = AC.createOscillator(), g = AC.createGain(); o.type = 'sawtooth'; o.frequency.value = mtof(root + iv); o.detune.value = det;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.06, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0008, t + (muted ? 0.13 : dur));
    o.connect(g).connect(guitarBus); o.start(t); o.stop(t + dur + 0.05);
  }
}
const LEAD = [ // one bar = 8 eighths; null = rest, '-' = hold
  64, '-', '-', 67, 71, '-', 69, 67, 64, '-', '-', '-', 62, 64, 67, '-', 66, '-', '-', 69, 74, '-', 72, 71, 69, '-', '-', '-', 71, '-', '-', '-',
  76, '-', '-', 74, 71, '-', 74, 76, 79, '-', 76, '-', 74, '-', 72, '-', 74, '-', '-', 78, 76, '-', 74, 72, 71, '-', '-', '-', '-', '-', null, null,
];
function startMusic() {
  const spb = 60 / 140 / 2; let step = 0, next = AC.currentTime + 0.1;
  const VERSE = [40, 40, 36, 38], CHORUS = [40, 36, 38, 35];
  setInterval(() => {
    if (!AC || meta.mute || AC.state !== 'running') { next = AC ? AC.currentTime + 0.1 : 0; return; }
    // back from the background: skip the missed beats instead of firing them all at once (a burst of noise)
    if (next < AC.currentTime - 0.05) next = AC.currentTime + 0.05;
    while (next < AC.currentTime + 0.25) {
      const t = next, s = step % 128, bar = Math.floor(s / 8), e = s % 8, boss = G.phase === 'boss' || G.phase === 'warn';
      const playing = G.state === 'play', chorus = boss || s >= 64, root = (chorus ? CHORUS : VERSE)[bar % 4];
      // guitars
      if (!chorus) powerChord(t, root, spb, e !== 0);
      else if (e === 0 || e === 3 || e === 6) powerChord(t, root, e === 0 ? spb * 3 : spb * 2.6, false);
      // bass: driving eighths
      tone(t, mtof(root - 12), mtof(root - 12), spb * 0.9, 'sawtooth', 0.09, musicBus);
      // drums
      if (e === 0 || e === 4 || (chorus && e === 7) || (boss && e % 2 === 0)) tone(t, 140, 42, 0.2, 'sine', 0.55, musicBus);
      if (e === 2 || e === 6) { noiz(t, 0.18, 0.28, 3500, 900, 'bandpass', musicBus, 0.6, 0.8); tone(t, 190, 150, 0.08, 'triangle', 0.12, musicBus); }
      noiz(t, 0.03, e % 2 ? 0.05 : 0.03, 9000, 7000, 'highpass', musicBus);
      if (boss) noiz(t + spb / 2, 0.025, 0.03, 9000, 7000, 'highpass', musicBus);
      if (s % 64 === 0 && step > 0) noiz(t, 1.4, 0.12, 8000, 3000, 'highpass', musicBus, 0.5); // crash at each section
      // lead (chorus only, while flying)
      if (chorus && playing) {
        const n = LEAD[s % 64];
        if (typeof n === 'number') {
          let len = 1; while (LEAD[(s + len) % 64] === '-' && len < 8) len++;
          for (const det of [-8, 8]) { const o = AC.createOscillator(), g = AC.createGain(), lfo = AC.createOscillator(), lg = AC.createGain();
            o.type = 'sawtooth'; o.frequency.value = mtof(n); o.detune.value = det; lfo.frequency.value = 5.5; lg.gain.value = 6;
            lfo.connect(lg).connect(o.detune); const dur = spb * len;
            g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.03, t + 0.02); g.gain.setValueAtTime(0.03, t + dur * 0.7); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
            const w = AC.createGain(); w.gain.value = 0.5; o.connect(g); g.connect(musicBus); g.connect(w).connect(verb);
            o.start(t); lfo.start(t); o.stop(t + dur + 0.05); lfo.stop(t + dur + 0.05); }
        }
      }
      next += spb; step++;
    }
  }, 60);
}

// ---------- save ----------
const META_KEY = 'cb_meta_v1';
function loadMeta() {
  let m = {}; try { m = JSON.parse(localStorage.getItem(META_KEY) || '{}'); } catch (e) { /* ignore */ }
  return Object.assign({ coins: 0, up: {}, ships: { sparrow: true }, ship: 'sparrow', best: 0, bestSector: 0, bestLv: 0, kills: 0, runs: 0, mute: false, tut: 0 }, m);
}
const meta = loadMeta();
function saveMeta() { try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch (e) { /* ignore */ } }
const hl = (id) => meta.up[id] || 0;

// ---------- game state ----------
const SCROLL = 82, SECTOR_LEN = 5200;
let cam = 0;
let FF = false; // fast-forwarding (no sound / DOM)
const G = { state: 'title', paused: null, phase: 'fly', sector: 1, t: 0 };
let P = null;   // player
let enemies = [], pshots = [], eshots = [], bombs = [], torps = [], rockets = [], pickups = [], parts = [], booms = [], falling = [],
  fires = [], zaps = [], rings = [], clouds = [], glints = [], wingmen = [], impacts = [], rails = [], shocks = [], lasers = [];
const input = { keys: new Set(), down: false, lx: 0, ly: 0 };

function L(id) { return P.lv[id] || 0; }
function stat() {
  const sh = SHIPS[P.ship], doom = P.relics.has('doom') ? 1.3 : 1;
  return {
    gunDmg: 10 * (1 + 0.25 * L('heavy')) * (1 + 0.1 * hl('guns')) * doom,
    gunRate: 6 * sh.rate * (1 + 0.18 * L('rapid')),
    bombDmg: 42 * (1 + 0.15 * L('boom')) * (1 + 0.1 * hl('ord')) * doom * sh.bomb,
    bombR: 60 * (1 + 0.25 * L('boom')),
    bombCd: 1.35 * Math.pow(0.85, L('quick')),
    rocketDmg: 15 * (1 + 0.15 * Math.max(0, L('missile') - 1)) * doom,
    torpDmg: 60 * (1 + 0.25 * Math.max(0, L('torpedo') - 1)) * doom,
    magnet: 110 * (1 + 0.45 * L('magnet')) * (1 + 0.2 * hl('mag')),
    coinMul: 2.2 * (1 + 0.25 * L('bounty')) * (1 + 0.15 * hl('bounty')) * (P.relics.has('goldprop') ? 1.5 : 1), // 2.2x base: coins come easy now (the x2-coins ad is gone)
    xpMul: (P.relics.has('goldprop') ? 1.5 : 1) * (1 + 0.1 * L('magnet')),
    doom,
  };
}
let ST = null;
const hpMul = () => Math.pow(1.55, G.sector - 1) * (1 + 0.3 * clamp(progress(), 0, 1));
const bulletMul = () => Math.min(1.7, 1 + 0.08 * (G.sector - 1));
const fireMul = () => Math.min(2.2, 1 + 0.13 * (G.sector - 1));
const progress = () => (G.secStart - cam) / SECTOR_LEN;
const kmFlown = () => (G.km0 || 0) - cam / 1000;
const xpNeed = (lv) => lv <= 4 ? [0, 14, 28, 46, 70][lv] : Math.round((16 + lv * 9 + lv * lv) * 1.3); // rarer upgrades: 14/28/46/70 XP for levels 1-4, then the old curve x1.3
const xpSector = () => 1 + 0.12 * (G.sector - 1);

// ---------- run save: closing the app keeps the run; Continue restarts the sector it was in ----------
const RUN_KEY = 'cb_run_v1';
function loadRun() { try { const r = JSON.parse(localStorage.getItem(RUN_KEY) || 'null'); return r && r.v === 1 && r.sector >= 1 ? r : null; } catch (e) { return null; } }
function clearRun() { try { localStorage.removeItem(RUN_KEY); } catch (e) { /* ignore */ } }
function saveRun() {
  if (AUTO || FF || !P || G.state !== 'play' || G.dying || P.hp <= 0) return;
  commitCoins(); // coins are banked, so a run that is never continued still pays out
  const r = { v: 1, sector: G.sector, km: G.secKm || 0, ship: P.ship, hp: P.hp, maxHp: P.maxHp, xp: P.xp, lvl: P.lvl, lv: P.lv,
    relics: [...P.relics], rerolls: P.rerolls, bells: G.pendingLv + G.cardQueue.filter((q) => q.lvl).length, kills: G.kills, coins: G.coins, revived: G.revived, seed };
  try { localStorage.setItem(RUN_KEY, JSON.stringify(r)); } catch (e) { /* ignore */ }
}

function newGame(save = null) {
  seed = save ? (save.seed + save.sector * 7919) | 0 : params.has('seed') ? +params.get('seed') : (Math.random() * 1e9) | 0;
  worldSeed = (rand() * 1e6) | 0;
  const ship = save && SHIPS[save.ship] ? save.ship : meta.ships[meta.ship] ? meta.ship : 'sparrow', sh = SHIPS[ship];
  P = { x: VW / 2, y: VH * 0.76, vx: 0, ship, hp: sh.hp + hl('hull'), maxHp: sh.hp + hl('hull'), inv: 2, shield: false, shieldT: 0,
    fireT: 0, bombT: 1, rocketT: 1, torpT: 1, zapT: 1, wingT: 0, xp: 0, lvl: 1, lv: {}, relics: new Set(), rerolls: hl('reroll') + (save ? 0 : meta.rerollTok || 0), side: 0, roll: 0, bank: 0, lastX: VW / 2, beamT: 1.5, beamOn: 0, barT: 3, barQ: 0, railT: 2.5 };
  for (const m of sh.mods) P.lv[m] = 1;
  if (!save && meta.rerollTok) { meta.rerollTok = 0; saveMeta(); } // the daily reward's free rerolls are spent on this run
  if (save) {
    Object.assign(P, { hp: save.hp, maxHp: save.maxHp, xp: save.xp, lvl: save.lvl, lv: { ...save.lv }, relics: new Set(save.relics), rerolls: save.rerolls });
    if (L('shield')) P.shield = true;
  }
  if (!save) P.lvl = 5; // a new run starts at level 5 (after 5 loadout picks), so the next level-up takes a good while
  ST = stat();
  enemies = []; pshots = []; eshots = []; bombs = []; torps = []; rockets = []; pickups = []; parts = []; booms = []; falling = [];
  fires = []; zaps = []; rings = []; clouds = []; glints = []; wingmen = []; impacts = []; rails = []; shocks = []; lasers = [];
  cam = 0; camX = 0; genTop = Infinity; chunks.clear(); bands = []; isles = []; recentIsles = []; placeTop = VH + 300; isleSeed = worldSeed;
  G.sector = save ? save.sector : START_SECTOR; G.t = 0; G.kills = 0; G.coins = 0; G.coinFrac = 0; G.committed = 0; G.revived = false; G.doubled = false; G.hits = 0;
  G.km0 = save ? save.km : 0; G.secKm = G.km0;
  if (save) { G.kills = save.kills; G.coins = G.committed = save.coins; G.revived = save.revived; }
  G.pendingLv = 0; G.dying = 0; G.slow = 1; G.boss = null; G.spawnT = 1; G.offers = 0; G.combo = 0; G.lastKillT = -9; G.events = {}; G.scroll = SCROLL; G.flash = 0; G.shake = 0;
  G.cardQueue = []; G.log = []; G.bell = null; G.bellQ = [];
  if (save && save.bells) for (let i = 0; i < Math.min(save.bells, 6); i++) G.cardQueue.push({ title: 'LEVEL UP', sub: 'Pick an upgrade', kind: 'cards', lvl: 1 }); // saved unclaimed upgrades come back as picks
  segs = [{ start: Infinity, biome: BIOMES[BIOME_ORDER[(G.sector - 1) % BIOME_ORDER.length]], force: 0, forceStart: 0 }];
  G.secStart = 0; G.phase = 'fly';
  updateTerrain();
  for (let i = 0; i < 3; i++) addCloud(rr(0, VH));
  G.state = 'play'; G.paused = null;
  hudDirty = true;
  if (!FF) { banner(`SECTOR ${G.sector}`, segs[0].biome.name, 2.2); $('weapons').classList.add('show'); setTimeout(() => $('weapons').classList.remove('show'), 7000); }
  if (!save) for (let i = 0; i < 5; i++) G.cardQueue.push({ title: 'LOADOUT ' + (i + 1) + '/5', sub: 'Pick your starting upgrades', kind: 'cards' }); // 5 free picks to build the plane before takeoff
  if (hl('start') && !save) for (let i = 0; i < hl('start'); i++) G.cardQueue.push({ title: 'HEAD START', sub: 'Pick a free upgrade', kind: 'cards' });
}

function startSector(n) {
  G.sector = n;
  const b = BIOMES[BIOME_ORDER[(n - 1) % BIOME_ORDER.length]];
  segs.push({ start: genTop, biome: b, force: 0, forceStart: 0 });
  isles = isles.filter((s) => s.y + s.hh >= genTop); placeTop = Math.min(placeTop, genTop);
  preloadEnv(n + 1);
  G.secStart = genTop; G.phase = 'fly'; G.events = {}; G.spawnT = 3; G.boss = null;
  banner(`SECTOR ${n}`, b.name, 2.4);
  G.secKm = kmFlown(); saveRun();
}

// The camera pans sideways: everything in the world slides, planes included, so you fly past them instead of them
// sticking to the screen like a HUD. Only the wingmen (they fly with you) and bosses (their fight is an arena) stay.
function shiftWorld(d) {
  camX -= d;
  for (const a of [pshots, eshots, torps, rockets, pickups, parts, booms, falling, fires, rings, clouds, glints, markers,
    impacts, rails, shocks, lasers]) for (const o of a) o.x += d;
  for (const e of enemies) if (!e.boss) { e.x += d; if (e.ax !== undefined) e.ax += d; }
  for (const b of bombs) { b.x += d; b.sx += d; b.tx += d; }
  for (const z of zaps) for (const q of z.pts) q[0] += d;
}

// ---------- spawning ----------
function spawn(type, x, y, o = {}) {
  const d = ENEMIES[type], m = hpMul() * (d.elite ? 1.15 : 1);
  const e = Object.assign({ type, def: d, layer: d.layer, x, y, vx: 0, vy: 0, hp: d.hp * m, maxHp: d.hp * m, r: d.r, size: d.size,
    rot: d.layer === 'air' ? Math.PI : rr(0, TAU), t: 0, fireT: rr(1, 2.5) / fireMul(), flash: 0, mode: 'down', alive: true }, o);
  enemies.push(e); return e;
}
function findSpots(kind, n, y = -50, minGap = 90) {
  const out = [];
  for (let tries = 0; tries < 40 && out.length < n; tries++) {
    const x = rr(40, VW - 40), wy = y + cam;
    const ok = kind === 'land' ? field(x, wy) > 0.14 && field(x - 18, wy) > 0.08 && field(x + 18, wy) > 0.08
      : field(x, wy) < -0.14 && field(x - 30, wy) < -0.08 && field(x + 30, wy) < -0.08;
    if (ok && out.every((p) => Math.abs(p - x) > minGap)) out.push(x);
  }
  return out;
}
const WAVES = {
  line: () => { const n = ri(4, 6); for (let i = 0; i < n; i++) spawn('drone', 70 + (VW - 140) * i / (n - 1), -40, { vy: 125 }); },
  v: () => { const cx = rr(140, VW - 140); [[0, 0], [-55, -45], [55, -45], [-110, -90], [110, -90]].forEach(([dx, dy]) => spawn('drone', cx + dx, -40 + dy, { vy: 145 })); },
  snake: () => { const cx = rr(140, VW - 140), ph = rr(0, TAU); for (let i = 0; i < 6; i++) spawn('drone', cx, -40 - i * 48, { vy: 135, mode: 'sine', ax: cx, amp: 110, ph }); },
  sweep: () => { const s = rand() < 0.5 ? 1 : -1; for (let i = 0; i < 5; i++) spawn('drone', s > 0 ? -40 - i * 55 : VW + 40 + i * 55, 70 + i * 6, { vx: 200 * s, vy: 40, mode: 'sweep' }); },
  jets: () => { sfx('jet'); const n = ri(2, 3); for (let i = 0; i < n; i++) spawn('jet', clamp(P.x + rr(-140, 140), 50, VW - 50), -60 - i * 170, { vy: 400, mode: 'jet' }); },
  copter: () => { const n = G.sector > 1 || progress() > 0.4 ? ri(1, 2) : 1; for (let i = 0; i < n; i++) spawn('copter', rr(80, VW - 80), -60 - i * 80, { mode: 'hover', hy: rr(110, 280), vy: 120 }); },
  mines: () => { for (let i = 0; i < 4; i++) spawn('mine', rr(50, VW - 50), -40 - i * 70, { vy: 70, mode: 'mine' }); },
  blimp: () => spawn('blimp', rr(120, VW - 120), -90, { vy: 38, mode: 'blimp' }),
  tanks: () => { const xs = findSpots('land', ri(2, 3)); xs.forEach((x) => spawn('tank', x, -40, { mode: 'tank' })); return xs.length; },
  sams: () => { const xs = findSpots('land', ri(1, 2), -40, 150); xs.forEach((x) => spawn('sam', x, -40, { mode: 'sam', rot: Math.PI })); return xs.length; },
  flak: () => { const xs = findSpots('land', ri(1, 2), -40, 140); xs.forEach((x) => spawn('flak', x, -40, { mode: 'flak' })); return xs.length; },
  boats: () => { const xs = findSpots('sea', 2, -50, 120); xs.forEach((x) => spawn('boat', x, -50, { mode: 'boat', rot: Math.PI + rr(-0.6, 0.6) })); return xs.length; },
  subs: () => { const xs = findSpots('sea', ri(1, 2), -60, 150); xs.forEach((x) => spawn('sub', x, -60, { mode: 'sub', rot: Math.PI + rr(-0.5, 0.5), dive: 1, cycle: rr(0, 2) })); return xs.length; },
};
const AIR_W = { line: 3, v: 3, snake: 3, sweep: 2, jets: 2, copter: 2, mines: 1.5, blimp: 1 };
const SURF_W = { sams: 2.5, flak: 3, boats: 3, subs: 2.5 };
function weighted(w) { let t = 0; for (const k in w) t += w[k]; let r = rand() * t; for (const k in w) { r -= w[k]; if (r <= 0) return k; } return Object.keys(w)[0]; }
function director(dt) {
  if (G.phase !== 'fly') {
    if (G.phase === 'boss' && G.boss && G.boss.alive) { // a few escorts so the guns stay busy
      G.spawnT -= dt;
      if (G.spawnT <= 0) { G.spawnT = rr(4.5, 7) / Math.min(1.8, 1 + 0.1 * (G.sector - 1)); WAVES[pick(['line', 'v', 'sweep', 'jets'])](); }
    }
    return;
  }
  const pr = progress();
  for (const [key, at, fn] of [['c1', 0.3, () => spawnCrate()], ['c2', 0.68, () => spawnCrate()],
    ['e1', 0.45, () => spawnElite()], ['e2', 0.82, () => spawnElite()], ['e3', G.sector >= 3 ? 0.2 : 9, () => spawnElite()], ['e4', G.sector >= 5 ? 0.62 : 9, () => spawnElite()]]) {
    if (pr > at && !G.events[key]) { G.events[key] = 1; fn(); }
  }
  if (pr >= 1) { beginBoss(); return; }
  G.spawnT -= dt;
  if (G.spawnT > 0) return;
  const inten = Math.min(3, 1 + 0.2 * (G.sector - 1)) * (1 + 0.4 * clamp(pr, 0, 1));
  G.spawnT = rr(1.45, 2.3) / (inten * (G.sector === 1 ? 1.5 : G.sector === 2 ? 1.15 : 1)); // early sectors are denser
  if (rand() < 0.55) {
    const w = Object.assign({}, SURF_W);
    if (G.sector === 1 && pr < 0.25) delete w.subs;
    for (let k = 0; k < 3; k++) { const key = weighted(w); if (WAVES[key]()) { tutorial(key); return; } delete w[key]; if (!Object.keys(w).length) break; }
  }
  const w = Object.assign({}, AIR_W);
  if (G.sector === 1 && pr < 0.3) { delete w.blimp; delete w.copter; delete w.mines; }
  WAVES[weighted(w)]();
}
function spawnElite() {
  const xs = findSpots('sea', 1, -90);
  if (xs.length && rand() < 0.6) spawn('destroyer', xs[0], -90, { mode: 'destroyer', rot: Math.PI });
  else spawn('bomberplane', rr(140, VW - 140), -110, { vy: 60, mode: 'bomber', hy: 170 });
}
function spawnCrate() { pickups.push({ kind: 'crate', x: rr(90, VW - 90), y: -40, vx: 0, vy: 48, t: 0 }); }

function beginBoss() {
  G.phase = 'warn'; G.log.push(['warn', G.sector, Math.round(G.t)]);
  const key = BOSS_ORDER[(G.sector - 1) % BOSS_ORDER.length], def = BOSSES[key];
  G.bossKey = key;
  const seg = segs[segs.length - 1];
  if (def.terrain) {
    seg.force = def.terrain; seg.forceStart = genTop; G.warnUntil = genTop - 320;
    if (envOf(seg.biome)) { isles = isles.filter((s) => s.y + s.hh >= genTop); placeTop = Math.min(placeTop, genTop); }
  } else G.warnUntil = cam - 260;
  G.warnT = 0;
  banner('WARNING', def.name + ' INCOMING', 2.6, true); sfx('warn');
}
// rough damage per second of the current build against a big target (every shot hits)
function estDps(layer) {
  const guns = ((1 + L('twin')) + L('spread') * 1.6) * ST.gunRate * ST.gunDmg + wingmen.length * ST.gunDmg * 0.6 / 0.32
    + (L('missile') ? (1 + L('missile')) * ST.rocketDmg / 1.5 : 0) + (P.relics.has('thunder') ? 22 * ST.doom * hpMulLite() : 0);
  if (layer === 'air') return guns;
  const bombs = (1 + L('bay')) * ST.bombDmg * (1 + L('cluster') * 2 * 0.4) / ST.bombCd
    + (L('torpedo') ? (L('torpedo') >= 3 ? 2 : 1) * ST.torpDmg / (2.6 - 0.35 * (L('torpedo') - 1)) : 0);
  return bombs + guns * 0.35;
}
function spawnBoss() {
  const def = BOSSES[G.bossKey];
  // a strong build still gets a real fight: at least ~20-36 s of its own damage output (65% hit rate)
  const hp = Math.max(def.hp * hpMul(), estDps(def.layer) * (20 + Math.min(16, G.sector * 2)) * 0.65);
  const e = { type: G.bossKey, def, boss: true, layer: def.layer, x: VW / 2, y: -def.size * 0.55, vx: 0, vy: 0, hp, maxHp: hp,
    r: def.r, size: def.size, rot: 0, t: 0, fireT: 2, flash: 0, mode: 'boss', alive: true, pat: 0, patT: 4, sub: 0 };
  if (G.bossKey === 'b_battleship') { e.rot = Math.PI; e.circles = [[0, -110, 58], [0, -35, 62], [0, 40, 62], [0, 115, 55]]; }
  if (G.bossKey === 'b_fortress') e.circles = [[0, 0, 120], [-110, 10, 60], [110, 10, 60]];
  if (G.bossKey === 'b_megatank') { e.rot = Math.PI; e.circles = [[0, -50, 105], [0, 60, 105]]; }
  if (G.bossKey === 'b_kraken') { e.rot = Math.PI; e.circles = [[0, 0, 110]]; e.dive = 0; e.cycle = 0; }
  enemies.push(e); G.boss = e; G.phase = 'boss'; G.spawnT = 6; G.log.push(['boss', G.sector, Math.round(G.t), Math.round(e.maxHp)]);
  $('bossname').textContent = def.name; $('bossbar').classList.remove('hidden');
  bossImmune(false);
}
function bossImmune(on) {
  let el = $('bossbar').querySelector('.imm');
  if (!el) { el = document.createElement('span'); el.className = 'imm'; $('bossbar').appendChild(el); }
  const def = G.boss && G.boss.def;
  el.textContent = on ? 'DIVING · only torpedoes reach it' : def ? (def.layer === 'air' ? 'use GUNS' : 'use BOMBS · guns only scratch it') : '';
}

// ---------- tutorial hints ----------
function tutorial(key) {
  if (FF || AUTO) return;
  if ((key === 'sams' || key === 'flak' || key === 'boats') && !(meta.tut & 1)) { meta.tut |= 1; saveMeta(); toast('BOMBS DROP ON THEIR OWN', 'Guns hit planes · bombs hit SAM sites, flak and boats', 3.5); }
  if (key === 'subs' && !(meta.tut & 2)) { meta.tut |= 2; saveMeta(); toast('SUBMARINES DIVE!', 'Bomb them while they are surfaced', 3.5); }
}

// ---------- player weapons ----------
function firePlayer(dt) {
  P.fireT -= dt;
  if (P.fireT <= 0) {
    P.fireT += 1 / ST.gunRate; if (P.fireT < -0.1) P.fireT = 0;
    const n = 1 + L('twin'), dmg = ST.gunDmg, pierce = L('pierce');
    for (let i = 0; i < n; i++) shot(P.x + (i - (n - 1) / 2) * 14, P.y - 30, 0, dmg, pierce);
    for (let i = 1; i <= L('spread'); i++) for (const s of [-1, 1]) shot(P.x + s * 10, P.y - 24, s * 0.16 * i, dmg * 0.8, pierce);
    P.muzzle = 0.07; sfx('shoot');
  }
  if (L('laser')) { // Laser Lance: charges, then a piercing beam burns straight up the screen
    const on = 0.9 + 0.25 * L('laser');
    if (P.beamOn > 0) {
      P.beamOn -= dt;
      const w = 9 + 2 * L('laser'), dps = ST.gunDmg * 7 * (1 + 0.3 * (L('laser') - 1));
      P.beamTop = -20;
      for (const e of enemies) {
        if (!e.alive || e.y > P.y || Math.abs(e.x - P.x) > e.r * 0.8 + w || (e.layer !== 'air' && !(e.boss && !e.dive))) continue;
        hurt(e, dps * dt * (e.layer === 'air' ? 1 : 0.35), true);
        if (rand() < dt * 20) impact(P.x + rr(-w, w) * 0.5, e.y + rr(-10, 10), 22);
      }
      if ((P.beamSfx = (P.beamSfx || 0) - dt) <= 0) { P.beamSfx = 0.11; sfx('zap'); }
      if (P.beamOn <= 0) P.beamT = 2.6 - 0.15 * L('laser');
    } else if ((P.beamT -= dt) <= 0) P.beamOn = on;
  }
  if (L('barrage')) { // Missile Barrage: a ripple of micro-missiles that fan out, then dive on anything hostile
    if (P.barQ > 0) {
      if ((P.barI = (P.barI || 0) - dt) <= 0) { P.barI = 0.035; P.barQ -= 2; microMissile(-1, ST.rocketDmg * 0.8); microMissile(1, ST.rocketDmg * 0.8); if (P.barQ % 6 === 0) sfx('rocket'); }
    } else if ((P.barT -= dt) <= 0) {
      if (enemies.some((e) => e.alive && !e.dive && e.y > 0 && e.y < P.y)) { P.barT = 5.4 - 0.5 * L('barrage'); P.barQ = 6 + 6 * L('barrage'); } else P.barT = 0.3;
    }
  }
  // bombs: auto-drop on the closest surface targets
  P.bombT -= dt;
  if (P.bombT <= 0) {
    const abyss = P.relics.has('abyss');
    const cands = enemies.filter((e) => e.layer !== 'air' && e.alive && (!e.dive || abyss) && e.y > 20 && Math.hypot(e.x - P.x, e.y - P.y) - (e.boss ? e.r : 0) < (e.def && e.def.elite ? 560 : 400)) // bombs reach about half a screen ahead (was 220: land units slipped past before they were in range)
      .sort((a, b) => Math.hypot(a.x - P.x, a.y - P.y) - Math.hypot(b.x - P.x, b.y - P.y));
    if (cands.length) {
      P.bombT = ST.bombCd;
      // FOCUS like the guns: bombs lock one target and keep hitting it until it dies. Bosses and elites first (they are
      // the big boats / bases that were slipping by), otherwise the nearest. A locked target stays locked while in range.
      const big = (e) => e.boss ? 2 : e.def && e.def.elite ? 1 : 0;
      let foc = P.bombFocus && cands.includes(P.bombFocus) ? P.bombFocus : null;
      const top = cands.reduce((m, e) => Math.max(m, big(e)), 0);
      if (!foc || big(foc) < top) foc = cands.find((e) => big(e) === top);
      P.bombFocus = foc;
      const tough = big(foc) > 0 || (foc.hp || 0) > ST.bombDmg * 1.5; // a tough target takes the whole salvo, weak ones share it
      const n = 1 + L('bay');
      for (let i = 0; i < n; i++) {
        const e = tough ? foc : (i ? cands[i % cands.length] : foc);
        let ox = 0, oy = 0;
        if (e.circles) { const [cx, cy, cr] = e.circles[(i + Math.floor(rand() * e.circles.length)) % e.circles.length]; ox = cx + rr(-cr, cr) * 0.4; oy = cy + rr(-cr, cr) * 0.4; } // spread over the hull's sections
        else if (e.boss) { ox = rr(-60, 60); oy = rr(-60, 60); }
        else if (i >= cands.length) { ox = rr(-46, 46); oy = rr(-46, 46); }
        dropBomb(e, ox, oy, i * 0.08);
      }
    } else { P.bombT = 0.15; P.bombFocus = null; }
  }
  if (L('missile')) {
    P.rocketT -= dt;
    if (P.rocketT <= 0) {
      const tgts = enemies.filter((e) => e.layer === 'air' && e.alive && e.y > -20);
      if (tgts.length) {
        P.rocketT = 1.5;
        const n = 1 + L('missile');
        for (let i = 0; i < n; i++) {
          const s = i % 2 ? 1 : -1;
          rockets.push({ x: P.x + s * 22, y: P.y, vx: s * 220, vy: 60, a: 0, t: 0, tgt: tgts[i % tgts.length], dmg: ST.rocketDmg });
        }
        sfx('rocket');
      } else P.rocketT = 0.2;
    }
  }
  if (L('torpedo')) {
    P.torpT -= dt;
    if (P.torpT <= 0) {
      const sea = enemies.some((e) => e.layer === 'sea' && e.alive && e.y < P.y);
      if (sea && isSea(P.x, P.y - 50)) {
        P.torpT = 2.6 - 0.35 * (L('torpedo') - 1);
        const n = L('torpedo') >= 3 ? 2 : 1;
        for (let i = 0; i < n; i++) torps.push({ x: P.x + (n > 1 ? (i ? 16 : -16) : 0), y: P.y - 50, t: 0, dmg: ST.torpDmg });
        sfx('torp'); ring(P.x, P.y - 50, 18, '#ffffff');
      } else P.torpT = 0.25;
    }
  }
  if (P.relics.has('thunder')) {
    P.zapT -= dt;
    if (P.zapT <= 0) {
      let from = P, hit = new Set(), pts = [[P.x, P.y]];
      for (let j = 0; j < 4; j++) {
        let best = null, bd = j ? 170 : 320;
        for (const e of enemies) if (e.layer === 'air' && e.alive && !hit.has(e) && e.y > 0) { const d = Math.hypot(e.x - from.x, e.y - from.y); if (d < bd) { bd = d; best = e; } }
        if (!best) break;
        hit.add(best); pts.push([best.x, best.y]); hurt(best, 22 * ST.doom * hpMulLite()); from = best;
      }
      P.zapT = hit.size ? 1 : 0.2;
      if (hit.size) { zaps.push({ pts, t: 0.16 }); sfx('zap'); }
    }
  }
  // wingmen
  const nw = L('wingman');
  while (wingmen.length < nw) wingmen.push({ x: P.x, y: P.y + 30, side: wingmen.length ? 1 : -1, t: 0 });
  P.wingT -= dt;
  const wf = P.wingT <= 0; if (wf) P.wingT = 0.32;
  for (const w of wingmen) {
    w.x = lerp(w.x, P.x + w.side * 58, Math.min(1, dt * 7)); w.y = lerp(w.y, P.y + 26, Math.min(1, dt * 7));
    if (wf) shot(w.x, w.y - 16, 0, ST.gunDmg * 0.6, 0, 0.7);
  }
}
const hpMulLite = () => 1 + 0.25 * (G.sector - 1); // utility damage keeps up a little with the sector
function shot(x, y, a, dmg, pierce, sc = 1) { pshots.push({ x, y, vx: Math.sin(a) * 980, vy: -Math.cos(a) * 980, a, dmg, pierce, sc, hit: null }); }
function dropBomb(e, ox, oy, delay) {
  const T = clamp(0.45 + Math.hypot(e.x - P.x, e.y - P.y) / 900, 0.55, 1.2); // quicker fall = less lead error
  // Ground units ride the scrolling terrain, so the aim point is a world y. Bosses stay put on screen, so the world
  // point must be pre-compensated for the scroll during the fall, or the bomb lands ~scroll*T (up to 100+ units) past them.
  const bossFix = e.boss ? G.scroll * T : 0;
  bombs.push({ sx: P.x, sy: P.y, x: P.x, y: P.y, tx: e.x + ox + (e.gvx || 0) * T, twy: e.y + oy + (e.gvy || 0) * T + cam - bossFix, t: -delay, T, r: ST.bombR, dmg: ST.bombDmg, cluster: L('cluster'), napalm: L('napalm') });
  if (AC && !meta.mute && !FF && AC.currentTime - (lastSfx.bomb || 0) > 0.3) { lastSfx.bomb = AC.currentTime; tone(AC.currentTime + delay, 1900, 480, T, 'sine', 0.022); } // whistle
}
function blast(x, y, r, dmg, opts = {}) {
  const abyss = P.relics.has('abyss');
  for (const e of enemies) {
    if (!e.alive || e.layer === 'air') continue;
    if (e.dive && !abyss && !opts.torp) continue;
    if (distTo(e, x, y) < r) hurt(e, dmg * (abyss && e.layer === 'sea' ? 1.5 : 1) * (e.def && e.def.elite && !e.boss ? 2.5 : 1)); // bombs are the answer to big ships: x2.5 vs elites
  }
}
function distTo(e, x, y) {
  if (!e.circles) return Math.hypot(e.x - x, e.y - y) - e.r;
  let best = 1e9; for (const [cx, cy, cr] of e.circles) best = Math.min(best, Math.hypot(e.x + cx - x, e.y + cy - y) - cr);
  return best;
}

// ---------- damage / kills ----------
function hurt(e, dmg, quiet) {
  if (!e.alive) return;
  if (e.boss && G.phase !== 'boss') return;
  e.hp -= dmg; if (e.flash < -0.12) { e.flash = 0.06; if (!quiet) for (let i = 0; i < 2; i++) part(e.x + rr(-e.r, e.r) * 0.6, e.y + e.r * 0.4, i ? '#ffffff' : '#ffd070', rr(-120, 120), rr(-170, -30), rr(0.1, 0.2), rr(2, 3.5)); } if (!quiet) sfx('hit'); // at most ~5 flashes/s, or constant fire paints it solid white
  if (e.hp <= 0) kill(e);
}
function kill(e) {
  e.alive = false;
  const d = e.def;
  G.kills++;
  if (e.boss) { bossDown(e); return; }
  G.combo = G.t - G.lastKillT < 1.8 ? G.combo + 1 : 1; G.lastKillT = G.t;
  if (G.combo % 8 === 0) { toast(`${G.combo} STREAK`, '', 0.8); sfx('pick'); }
  ring(e.x, e.y, e.r * 1.3, '#fff2c0');
  for (let i = 0; i < 5; i++) { const a = rr(0, TAU), sp = rr(90, 220); part(e.x, e.y, i % 2 ? '#ffffff' : '#ffb060', Math.cos(a) * sp, Math.sin(a) * sp, rr(0.15, 0.3), rr(2, 4)); }
  const big = d.elite || e.type === 'blimp';
  explode(e.x, e.y, big ? 70 : 38, e.layer !== 'air');
  sfx(big ? 'big' : e.layer === 'air' ? 'pop' : 'boom');
  if (e.layer === 'air') falling.push({ type: e.type, x: e.x, y: e.y, size: e.size, rot: e.rot, vx: e.vx * 0.3, vy: e.vy * 0.3 + 40, t: 0 });
  else if (e.layer === 'land') { const sp = SPR[e.type]; scorch(e.x, e.y, e.r * 1.8); if (sp) decal(e.x, e.y, (g) => { const k = e.size / Math.max(sp.fw, sp.h); g.rotate(e.rot); g.scale(k, k); g.globalAlpha = 0.85; g.drawImage(silhouette(sp, '#2b2420'), -sp.fw / 2, -sp.h / 2); }); }
  else { ring(e.x, e.y, e.r * 1.6, '#ffffff'); for (let i = 0; i < 10; i++) part(e.x, e.y, '#e8f8ff', rr(-90, 90), rr(-90, 90), 0.5, rr(3, 6), 'splash'); }
  const early = G.sector <= 2, xpv = d.xp * ST.xpMul * xpSector();
  const gems = Math.min(5, Math.ceil(d.xp / 2));
  for (let i = 0; i < gems; i++) drop('xp', e.x, e.y, xpv / gems);
  let coins = d.coin * (early ? 1.7 : 1); while (coins > 0) { if (coins >= 1 || rand() < coins) drop('coin', e.x, e.y, 1); coins -= 1; }
  if (P.hp < P.maxHp && rand() < (d.elite ? 0.6 : 0.012)) drop('heart', e.x, e.y, 1);
  if (d.elite) spawnCratAt(e.x, e.y);
  if (G.dying) return;
  G.shake = Math.max(G.shake, big ? 7 : 2);
}
function spawnCratAt(x, y) { pickups.push({ kind: 'crate', x, y, vx: 0, vy: 30, t: 0 }); }
function bossDown(e) {
  G.phase = 'clear'; G.boss = null; G.log.push(['down', G.sector, Math.round(G.t), P.lvl, G.hits]);
  $('bossbar').classList.add('hidden');
  let n = 0;
  const chain = () => {
    if (n++ < 9) { explode(e.x + rr(-e.size * 0.35, e.size * 0.35), e.y + rr(-e.size * 0.3, e.size * 0.3), rr(50, 90), e.layer !== 'air'); sfx('boom'); G.shake = 8; if (FF) chain(); else setTimeout(chain, 140); return; }
    explode(e.x, e.y, 150, e.layer !== 'air'); sfx('big'); G.flash = 0.8; G.shake = 16;
    if (e.layer !== 'air') scorch(e.x, e.y, 160);
    for (let i = 0, n = G.sector <= 2 ? 40 : 24; i < n; i++) drop('coin', e.x + rr(-80, 80), e.y + rr(-60, 60), 1);
    for (let i = 0; i < 10; i++) drop('xp', e.x + rr(-80, 80), e.y + rr(-60, 60), 4 * ST.xpMul * xpSector());
    e.gone = true;
    banner('SECTOR CLEAR!', `${kmFlown().toFixed(1)} km flown`, 2);
    const after = () => { G.cardQueue.push({ title: 'BOSS TROPHY', sub: 'Pick a relic', kind: 'relic', then: () => startSector(G.sector + 1) }); };
    if (FF) after(); else setTimeout(after, 1600);
  };
  chain();
}
function drop(kind, x, y, v) {
  const a = rr(0, TAU), s = rr(40, 150);
  pickups.push({ kind, x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 30, v, t: 0 });
}
function damagePlayer(src = '?') {
  if (P.inv > 0 || G.dying || NODIE) return;
  G.log.push(['hit', src, Math.round(G.t * 10) / 10, P.shield ? 'shield' : P.hp]);
  if (P.shield) {
    P.shield = false; P.shieldT = [16, 16, 13, 10][L('shield')]; P.inv = 0.8; sfx('shield');
    ring(P.x, P.y, 60, '#9ad8ff'); clearShots(110); hudDirty = true; return;
  }
  P.hp--; P.inv = 1.7; G.hits++; G.shake = 10; G.hitStop = 0.08; sfx('hurt'); hudDirty = true;
  ring(P.x, P.y, 46, '#ff6a4a');
  for (let i = 0; i < 12; i++) { const a = rr(0, TAU), s = rr(80, 240); part(P.x, P.y, i % 3 ? '#ffb070' : '#ffffff', Math.cos(a) * s, Math.sin(a) * s, rr(0.2, 0.45), rr(2, 4)); }
  if (!FF) { const h = $('hurt'); h.style.transition = 'none'; h.style.opacity = 1; requestAnimationFrame(() => { h.style.transition = 'opacity .6s'; h.style.opacity = 0; }); }
  clearShots(130);
  if (P.hp <= 0) {
    if (P.relics.has('phoenix') && !P.phoenixUsed) {
      P.phoenixUsed = true; P.hp = P.maxHp; P.inv = 3; clearShots(9999); banner('PHOENIX!', 'Back from the ashes', 1.8);
      explode(P.x, P.y, 90, false); return;
    }
    G.dying = 1.4; G.slow = 0.35;
    explode(P.x, P.y, 80, false); sfx('big');
  }
}
function clearShots(r) { eshots = eshots.filter((b) => { const k = Math.hypot(b.x - P.x, b.y - P.y) > r; if (!k) part(b.x, b.y, '#ffffff', 0, 0, 0.25, 5, 'spark'); return k; }); }

// ---------- enemy fire ----------
function efire(x, y, a, spd, kind = 'orb') { eshots.push({ x, y, vx: Math.cos(a) * spd * bulletMul(), vy: Math.sin(a) * spd * bulletMul(), kind, r: ER[kind], t: 0 }); }
const aim = (x, y) => Math.atan2(P.y - y, P.x - x);
function fan(x, y, a, n, spread, spd, kind) { for (let i = 0; i < n; i++) efire(x, y, a + (n > 1 ? (i / (n - 1) - 0.5) * spread : 0), spd, kind); }
function ringShot(x, y, n, spd, kind, off = 0) { for (let i = 0; i < n; i++) efire(x, y, off + i * TAU / n, spd, kind); }

// ---------- enemies ----------
function updateEnemy(e, dt) {
  e.t += dt; e.flash -= dt;
  const ground = e.layer !== 'air';
  if (ground && !e.boss) e.y += G.scroll * dt * (e.type === 'destroyer' ? 0.5 : 1); // ground units ride the scrolling terrain (a destroyer sails at half the scroll, so it stays in bomb range longer)
  e.fireT -= dt * fireMul();
  // ground units only fire while ahead of the plane: being shot from behind by something you flew past feels unfair
  const onScreen = e.y > 10 && e.y < (ground ? P.y - 70 : VH - 30) && e.x > -10 && e.x < VW + 10;
  switch (e.mode) {
    case 'down': e.x += e.vx * dt; e.y += e.vy * dt; break;
    case 'sine': e.y += e.vy * dt; e.x = e.ax + Math.sin(e.t * 2.2 + e.ph) * e.amp; e.rot = Math.PI - Math.cos(e.t * 2.2 + e.ph) * 0.5; break;
    case 'sweep': e.x += e.vx * dt; e.y += e.vy * dt; e.vy += 70 * dt; e.rot = Math.atan2(e.vx, -e.vy); break;
    case 'jet':
      e.y += e.vy * dt; e.x += e.vx * dt;
      if (!e.shot && e.y > P.y - 330 && e.y < P.y - 120) { e.shot = 1; e.lz = { a: aim(e.x, e.y + 20), t: 0 }; }
      if (e.lz && !e.lz.done && (e.lz.t += dt) >= 0.4) { // the laser: instant, straight, dodgeable after the warning line
        e.lz.done = 1; const x = e.x, y = e.y + 20, c = Math.cos(e.lz.a), s = Math.sin(e.lz.a), dx = P.x - x, dy = P.y - y;
        lasers.push({ x, y, a: e.lz.a, t: 0 }); sfx('zap');
        if (dx * c + dy * s > 0 && Math.abs(-dx * s + dy * c) < 11 && !G.dying) damagePlayer('laser');
      }
      if (!e.shot) e.vx = clamp((P.x - e.x) * 1.5, -120, 120); else e.vx *= 0.98;
      e.rot = Math.atan2(e.vx, -e.vy);
      break;
    case 'hover':
      if (e.t < 4 && e.y < e.hy) e.y += e.vy * dt; else if (e.t > 9) e.x += (e.x < VW / 2 ? -1 : 1) * 150 * dt;
      else e.x += Math.sin(e.t * 0.9) * 50 * dt;
      e.rot = lerpAngle(e.rot, aim(e.x, e.y) - Math.PI / 2 + Math.PI, dt * 3);
      if (e.fireT <= 0 && onScreen) { e.fireT = 2; e.burst = 3; }
      if (e.burst > 0 && (e.bT = (e.bT || 0) - dt) <= 0) { e.burst--; e.bT = 0.13; efire(e.x, e.y, aim(e.x, e.y), 240, 'orb'); }
      break;
    case 'mine':
      e.y += e.vy * dt; e.x += Math.sin(e.t * 1.7) * 30 * dt; e.rot += dt;
      if (Math.hypot(P.x - e.x, P.y - e.y) < 95 && !G.dying) { e.alive = false; ringShot(e.x, e.y, 10, 170, 'orb', rr(0, 1)); explode(e.x, e.y, 34, false); sfx('pop'); }
      break;
    case 'blimp':
      e.y += e.vy * dt; e.x += Math.sin(e.t * 0.5) * 20 * dt;
      if (e.fireT <= 0 && onScreen) { e.fireT = 3.2; ringShot(e.x, e.y, 10, 140, 'ring', e.t); }
      break;
    case 'bomber':
      if (e.y < e.hy && e.t < 12) e.y += e.vy * dt; else if (e.t > 15) e.y += 90 * dt;
      e.x += Math.sin(e.t * 0.6) * 60 * dt;
      if (e.fireT <= 0 && onScreen) { e.fireT = 1.7; if ((e.k = (e.k || 0) + 1) % 3) fan(e.x, e.y + 40, aim(e.x, e.y), 5, 0.9, 200, 'orb'); else ringShot(e.x, e.y, 14, 150, 'ring', e.t); }
      break;
    case 'tank': {
      const want = aim(e.x, e.y) + Math.PI / 2;
      e.rot = lerpAngle(e.rot, want, dt * 1.2);
      const nx = e.x + Math.sin(e.rot) * 22 * dt, ny = e.y - Math.cos(e.rot) * 22 * dt;
      if (field(nx + Math.sin(e.rot) * 20, ny - Math.cos(e.rot) * 20 + cam) > 0.08) { e.gvx = (nx - e.x) / dt; e.gvy = (ny - e.y) / dt; e.x = nx; e.y = ny; } else { e.gvx = e.gvy = 0; }
      if (e.fireT <= 0 && onScreen) { e.fireT = 2.7; const a = e.rot - Math.PI / 2; efire(e.x + Math.cos(a) * 30, e.y + Math.sin(a) * 30, a, 150, 'shell'); part(e.x + Math.cos(a) * 34, e.y + Math.sin(a) * 34, '#fff3c0', 0, 0, 0.12, 12, 'spark'); }
      break;
    }
    case 'flak':
      e.rot = lerpAngle(e.rot, aim(e.x, e.y) + Math.PI / 2, dt * 3);
      if (e.fireT <= 0 && onScreen) { e.fireT = 2.4; e.burst = 3; }
      if (e.burst > 0 && (e.bT = (e.bT || 0) - dt) <= 0) { e.burst--; e.bT = 0.1; efire(e.x, e.y, aim(e.x, e.y) + rr(-0.12, 0.12), 240, 'flak'); }
      break;
    case 'sam': // missile launcher: turns toward the plane, fires one slow homing missile at a time
      e.rot = lerpAngle(e.rot, aim(e.x, e.y) + Math.PI / 2, dt * 1.5);
      if (e.fireT <= 0 && onScreen) {
        e.fireT = 3.4; const a = e.rot - Math.PI / 2;
        for (const s of [-1, 1]) eshots.push({ x: e.x + Math.cos(a) * 20 + s * 8, y: e.y + Math.sin(a) * 20, vx: Math.cos(a + s * 0.5) * 80, vy: Math.sin(a + s * 0.5) * 80, kind: 'rocket', r: ER.rocket, t: 0, home: 1.1 });
        for (let i = 0; i < 5; i++) part(e.x, e.y, '#8a8a8a', rr(-30, 30), rr(-30, 30), 0.8, rr(5, 9), 'smoke');
        sfx('rocket');
      }
      break;
    case 'boat': {
      const nx = e.x + Math.sin(e.rot) * 45 * dt, ny = e.y - Math.cos(e.rot) * 45 * dt;
      if (field(nx + Math.sin(e.rot) * 34, ny - Math.cos(e.rot) * 34 + cam) < -0.06 && nx > 20 && nx < VW - 20) { e.gvx = (nx - e.x) / dt; e.gvy = (ny - e.y) / dt; e.x = nx; e.y = ny; }
      else { e.rot += dt * 2.2; e.gvx = e.gvy = 0; }
      if (rand() < dt * 4) wake(e);
      if (e.fireT <= 0 && onScreen) { e.fireT = 2.3; fan(e.x, e.y, aim(e.x, e.y), 2, 0.25, 200, 'orb'); }
      break;
    }
    case 'sub': {
      e.cycle += dt;
      const len = e.dive ? 2.8 : 3.4;
      if (e.cycle > len) { e.cycle = 0; e.dive = !e.dive; ring(e.x, e.y, e.r * 1.5, '#ffffff'); if (!e.dive) { e.fireT = 0.6; } }
      const nx = e.x + Math.sin(e.rot) * 30 * dt, ny = e.y - Math.cos(e.rot) * 30 * dt;
      if (field(nx + Math.sin(e.rot) * 46, ny - Math.cos(e.rot) * 46 + cam) < -0.06 && nx > 30 && nx < VW - 30) { e.gvx = (nx - e.x) / dt; e.gvy = (ny - e.y) / dt; e.x = nx; e.y = ny; }
      else { e.rot += dt * 1.6; e.gvx = e.gvy = 0; }
      if (!e.dive && e.fireT <= 0 && onScreen) { e.fireT = 2.2; for (const s of [-1, 1]) eshots.push({ x: e.x + s * 10, y: e.y, vx: s * 60, vy: -40, kind: 'rocket', r: ER.rocket, t: 0, home: 1.1 }); }
      if (e.dive && rand() < dt * 5) part(e.x + rr(-20, 20), e.y + rr(-30, 30), '#cfefff', 0, 0, 0.6, 3, 'splash');
      break;
    }
    case 'destroyer': {
      e.x += Math.sin(e.t * 0.4) * 18 * dt; e.gvx = Math.sin(e.t * 0.4) * 18; e.gvy = -0.5 * G.scroll; // bomb lead: it moves against the ground
      if (e.fireT <= 0 && onScreen) {
        e.fireT = 1.3; e.k = (e.k || 0) + 1;
        if (e.k % 4 === 0) ringShot(e.x, e.y, 16, 140, 'ring', e.t);
        else { const oy = e.k % 2 ? -40 : 40; fan(e.x, e.y + oy, aim(e.x, e.y + oy), 3, 0.35, 210, 'shell'); }
      }
      if (rand() < dt * 3) wake(e);
      break;
    }
    case 'boss': updateBoss(e, dt); break;
  }
  if (!e.boss && (e.y > VH + 140 || e.x < -260 || e.x > VW + 260 || e.y < -700)) e.alive = false, e.gone = true;
}
function wake(e) { part(e.x - Math.sin(e.rot) * e.size * 0.45, e.y + Math.cos(e.rot) * e.size * 0.45, '#ffffff', rr(-12, 12), 0, 0.9, rr(4, 7), 'foam'); }
function lerpAngle(a, b, k) { let d = ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI; return a + d * Math.min(1, k); }

function updateBoss(e, dt) {
  const hy = e.def.layer === 'air' ? 210 : 230, enraged = e.hp < e.maxHp * 0.4, sp = enraged ? 1.35 : 1;
  if (e.y < hy && !e.entered) { e.y += 70 * dt; if (e.y >= hy) e.entered = true; return; }
  e.entered = true;
  e.patT -= dt * sp;
  e.fireT -= dt * sp * fireMul();
  const k = G.bossKey;
  if (k === 'b_fortress') {
    e.x = VW / 2 + Math.sin(e.t * 0.45) * 110;
    if (e.pat === 0 && e.fireT <= 0) { e.fireT = 0.17; for (let i = 0; i < 3; i++) efire(e.x, e.y + 20, e.t * 1.7 + i * TAU / 3, 150, 'ring'); }
    if (e.pat === 1 && e.fireT <= 0) { e.fireT = 0.85; for (const ox of [-110, 0, 110]) fan(e.x + ox, e.y + 40, aim(e.x + ox, e.y + 40), 5, 0.7, 210, 'orb'); }
    if (e.pat === 2 && e.fireT <= 0) { e.fireT = 1.6; ringShot(e.x, e.y, 22, 150, 'orb', e.t); WAVES.jets(); }
  } else if (k === 'b_battleship') {
    e.x = VW / 2 + Math.sin(e.t * 0.3) * 70;
    if (rand() < dt * 6) part(e.x + rr(-50, 50), e.y + rr(-170, 170), '#ffffff', 0, 0, 0.9, rr(5, 9), 'foam');
    if (e.pat === 0 && e.fireT <= 0) { e.fireT = 0.42; e.sub = (e.sub + 1) % 4; const [, oy] = e.circles[e.sub]; fan(e.x, e.y + oy, aim(e.x, e.y + oy), 3, 0.3, 190, 'shell'); }
    if (e.pat === 1 && e.fireT <= 0) { e.fireT = 1.1; e.sub = (e.sub + 1) % 3; ringShot(e.x, e.y + [-110, 0, 110][e.sub], 12, 135, 'ring', e.t); }
    if (e.pat === 2 && e.fireT <= 0) { e.fireT = 2.2; WAVES[pick(['v', 'sweep'])](); fan(e.x, e.y + 120, aim(e.x, e.y + 120), 7, 1.2, 180, 'orb'); }
  } else if (k === 'b_megatank') {
    // Iron Bastion: a fixed island base; its missile pattern launches a homing salvo from the silos
    if (e.pat === 0 && e.fireT <= 0) { e.fireT = 0.7; e.sub ^= 1; const ox = e.sub ? -60 : 60; fan(e.x + ox, e.y + 90, aim(e.x + ox, e.y + 90), 5, 0.8, 175, 'shell'); }
    if (e.pat === 1 && e.fireT <= 0) { e.fireT = 0.5; flakBurst(P.x + rr(-60, 60), P.y + rr(-80, 40)); }
    if (e.pat === 2 && e.fireT <= 0) {
      e.fireT = 2; // calls in SAM sites, but never more than 3 at once
      const sams = enemies.filter((o) => o.alive && o.type === 'sam').length;
      for (const xs of findSpots('land', Math.max(0, Math.min(2, 3 - sams)), -40)) spawn('sam', xs, -40, { mode: 'sam', rot: Math.PI });
      for (const [sx, sy] of [[-70, -60], [70, -60], [-70, 60], [70, 60]]) eshots.push({ x: e.x + sx, y: e.y + sy, vx: sx * 1.2, vy: -40, kind: 'rocket', r: ER.rocket, t: 0, home: 1.4 }); sfx('rocket'); }
  } else if (k === 'b_kraken') {
    e.cycle += dt;
    const len = e.dive ? 3 : 6.5;
    if (e.cycle > len) {
      e.cycle = 0; e.dive = !e.dive; ring(e.x, e.y, 150, '#ffffff'); bossImmune(e.dive && !P.relics.has('abyss'));
      if (e.dive) e.tx = rr(140, VW - 140); else { e.fireT = 0.4; for (let i = 0; i < 16; i++) part(e.x + rr(-120, 120), e.y + rr(-120, 120), '#e8f8ff', rr(-100, 100), rr(-100, 100), 0.6, rr(4, 8), 'splash'); }
    }
    if (e.dive) e.x = lerp(e.x, e.tx, dt * 0.8);
    else {
      if (e.pat === 0 && e.fireT <= 0) { e.fireT = 0.22; for (let i = 0; i < 5; i++) efire(e.x, e.y, e.t * 0.8 + i * TAU / 5, 145, 'ring'); }
      if (e.pat === 1 && e.fireT <= 0) { e.fireT = 0.8; fan(e.x, e.y + 60, aim(e.x, e.y + 60), 7, 1, 200, 'orb'); }
      if (e.pat === 2 && e.fireT <= 0) { e.fireT = 1.2; for (const s of [-1, 1]) for (let i = 0; i < 2; i++) eshots.push({ x: e.x + s * 90, y: e.y, vx: s * 90, vy: -30 - i * 40, kind: 'rocket', r: ER.rocket, t: 0, home: 1.3 }); }
    }
  }
  if (e.patT <= 0) { e.pat = (e.pat + 1) % 3; e.patT = 4.5; e.fireT = 0.6; }
}
let markers = [];
function flakBurst(x, y) { markers.push({ x, y, t: 0, T: 1.0, r: 46 }); }

// ---------- pickups ----------
function updatePickups(dt) {
  for (const p of pickups) {
    p.t += dt;
    if (p.kind === 'crate') { p.y += p.vy * dt; p.x += Math.sin(p.t * 1.3) * 25 * dt; }
    else {
      p.vx *= Math.exp(-dt * 3); p.vy = lerp(p.vy, 55, Math.min(1, dt * 2.5));
      p.x += p.vx * dt; p.y += p.vy * dt;
      const d = Math.hypot(P.x - p.x, P.y - p.y);
      if ((d < ST.magnet * (p.kind === 'xp' ? 1.3 : 1) || p.pull || p.t > 1.4 || G.phase === 'clear') && !G.dying && p.t > (p.kind === 'xp' ? 0.15 : 0.25)) {
        p.pull = true; const s = Math.max(500, 1400 - d * 2);
        p.x += (P.x - p.x) / d * s * dt; p.y += (P.y - p.y) / d * s * dt;
      }
    }
    if (Math.hypot(P.x - p.x, P.y - p.y) < (p.kind === 'crate' ? 44 : 26) && !G.dying) collect(p);
  }
  pickups = pickups.filter((p) => !p.got && p.y < VH + 60);
}
function collect(p) {
  p.got = true;
  if (p.kind === 'xp') { // one level per gem at most, and only a little XP carries over, so level-ups never come back to back
    P.xp += p.v; sfx('xp');
    if (P.xp >= xpNeed(P.lvl)) { P.xp = Math.min(P.xp - xpNeed(P.lvl), xpNeed(P.lvl + 1) * 0.25); P.lvl++; G.pendingLv++; }
  }
  else if (p.kind === 'coin') { G.coinFrac += p.v * ST.coinMul; const n = Math.floor(G.coinFrac); G.coinFrac -= n; G.coins += n; sfx('coin'); }
  else if (p.kind === 'heart') { P.hp = Math.min(P.maxHp, P.hp + 1); hudDirty = true; sfx('pick'); toast('+1 HEART'); }
  else if (p.kind === 'crate') { // a free upgrade on the spot: no card screen, so supply drops never stop the action
    sfx('pick'); const o = pick(cardOptions()); G.offers++;
    if (o) { applyCard(o); toast('SUPPLY DROP', `${CARDS[o.id].name}${o.epic ? ' +2' : ''}`); }
  }
  hudDirty = true;
}

// ---------- effects ----------
function impact(x, y, r) {
  impacts.push({ x, y, r: r * rr(0.85, 1.2), t: 0 });
  for (let i = 0; i < 2; i++) part(x, y, i ? '#bfe8ff' : '#ffffff', rr(-90, 90), rr(-110, 10), rr(0.12, 0.22), rr(2, 3.5));
}
function part(x, y, color, vx, vy, life, size, kind = 'spark') {
  if (parts.length > (MOBILE ? 350 : 700)) parts.shift();
  parts.push({ x, y, vx, vy, life, max: life, size, color, kind });
}
function explode(x, y, r, ground) {
  const puffs = [];
  const n = Math.round(4 + r / 12);
  for (let i = 0; i < n; i++) { const a = rr(0, TAU), d = rr(0, r * 0.55); puffs.push([Math.cos(a) * d, Math.sin(a) * d, rr(0.35, 0.7) * r, rr(0, 0.12)]); }
  booms.push({ x, y, t: 0, T: 0.55 + r / 300, r, puffs, ground });
  for (let i = 0; i < Math.min(14, n + 4); i++) { const a = rr(0, TAU), s = rr(80, 260) * (r / 50); part(x, y, pick(['#ffd34d', '#ff8a2a', '#fff3c0']), Math.cos(a) * s, Math.sin(a) * s, rr(0.25, 0.5), rr(3, 6)); }
  for (let i = 0; i < Math.min(8, n); i++) { const a = rr(0, TAU), s = rr(60, 200); part(x, y, '#2b2430', Math.cos(a) * s, Math.sin(a) * s, rr(0.4, 0.8), rr(3, 5), 'debris'); }
}
function ring(x, y, r, color) { rings.push({ x, y, r, t: 0, T: 0.5, color }); }
function addCloud(y) { clouds.push({ x: rr(-60, VW + 60), y, s: rr(170, 280), sp: rr(1.25, 1.6), a: rr(0.3, 0.45), f: 1, flip: rand() < 0.5 ? -1 : 1 }); }

// ---------- per-frame update ----------
function step(dt) {
  G.t += dt;
  ST = stat();
  // scroll (faster while the boss terrain rolls in)
  let target = SCROLL;
  if (G.phase === 'warn') {
    G.warnT += dt; target = SCROLL * 3.2;
    if (cam <= G.warnUntil && G.warnT > 2.2) { target = SCROLL; if (!enemies.some((e) => e.def && e.def.elite && e.alive)) spawnBoss(); }
  }
  G.scroll = lerp(G.scroll, target, Math.min(1, dt * 2));
  cam -= G.scroll * dt;
  updateTerrain();
  director(dt);

  // player
  if (!G.dying) {
    let mx = 0, my = 0;
    if (input.keys.has('ArrowLeft') || input.keys.has('a')) mx -= 1;
    if (input.keys.has('ArrowRight') || input.keys.has('d')) mx += 1;
    if (input.keys.has('ArrowUp') || input.keys.has('w')) my -= 1;
    if (input.keys.has('ArrowDown') || input.keys.has('s')) my += 1;
    const ox = P.lastX;
    if (mx || my) { const l = Math.hypot(mx, my); P.x += mx / l * 430 * dt; P.y += my / l * 430 * dt; }
    if (AUTO) bot(dt);
    P.x = clamp(P.x, 24, VW - 24); P.y = clamp(P.y, 90, VH - 135); // the health and shield bars ride under the plane, so keep room for them
    P.vx = lerp(P.vx, (P.x - ox) / Math.max(dt, 1e-4), Math.min(1, dt * 10));
    P.bank = lerp(P.bank, clamp(P.vx / 480, -1, 1), Math.min(1, dt * 7));
    if (!G.boss) {
      const BAND = 170, sh = P.x < BAND ? BAND - P.x : P.x > VW - BAND ? VW - BAND - P.x : 0;
      if (sh) { P.x += sh; shiftWorld(sh); }
    }
    P.lastX = P.x;
    firePlayer(dt);
  }
  P.inv -= dt; P.muzzle -= dt;
  if (L('shield') && !P.shield) { P.shieldT -= dt; if (P.shieldT <= 0) { P.shield = true; hudDirty = true; } }

  for (const e of enemies) if (e.alive || e.boss && !e.gone) updateEnemy(e, dt);
  enemies = enemies.filter((e) => e.alive || (e.boss && !e.gone));

  // player shots vs air
  for (const b of pshots) {
    b.x += b.vx * dt; b.y += b.vy * dt;
    if (b.y < -40) { b.dead = true; continue; }
    for (const e of enemies) {
      if (!e.alive || (e.layer !== 'air' && !(e.boss && !e.dive)) || (b.hit && b.hit.includes(e))) continue;
      if (distTo(e, b.x, b.y) < 6) {
        hurt(e, e.layer === 'air' ? b.dmg : b.dmg * 0.35); impact(b.x, b.y - 8, 14);
        if (b.pierce > 0) { b.pierce--; (b.hit = b.hit || []).push(e); } else { b.dead = true; break; }
      }
    }
    if (!b.dead) for (const m of eshots) { // guns shoot enemy homing rockets down
      if (m.kind !== 'rocket' || m.dead || Math.hypot(m.x - b.x, m.y - b.y) > ER.rocket + 9) continue;
      m.dead = true; impact(m.x, m.y, 16); explode(m.x, m.y, 30, false); ring(m.x, m.y, 26, '#ffd9a0'); part(m.x, m.y, '#fff3c0', 0, 0, 0.2, 12, 'spark'); sfx('boom');
      if (b.pierce > 0) b.pierce--; else b.dead = true;
      break;
    }
    if (!b.dead) for (const p of pickups) if (p.kind === 'crate' && Math.hypot(p.x - b.x, p.y - b.y) < 30) { b.dead = true; collect(p); break; }
  }
  pshots = pshots.filter((b) => !b.dead);

  // rockets (home on planes)
  for (const r of rockets) {
    r.t += dt;
    if (!r.lock && (!r.tgt || !r.tgt.alive || r.tgt.dive)) r.tgt = r.any ? nearestAny(r.x, r.y) : nearestAir(r.x, r.y);
    const live = r.tgt && r.tgt.alive && !r.tgt.dive;
    const want = live ? Math.atan2(r.tgt.y - r.y, r.tgt.x - r.x) : r.lock ? Math.atan2(r.vy, r.vx) : -Math.PI / 2; // a locked missile whose target died flies straight on
    const sp = Math.min(r.sp || 620, 200 + r.t * 900), wob = r.wob !== undefined ? Math.sin(r.t * 9 + r.wob) * 0.5 : 0; // swarm: each micro-missile weaves at its own rate
    const cur = Math.atan2(r.vy, r.vx), na = lerpAngle(cur, want + wob, dt * (r.t < (r.small ? 0.3 : 0.15) ? 1.5 : r.turn || 7));
    r.vx = Math.cos(na) * sp; r.vy = Math.sin(na) * sp; r.x += r.vx * dt; r.y += r.vy * dt;
    if (rand() < (r.small ? 0.3 : 0.6)) part(r.x - r.vx * 0.03, r.y - r.vy * 0.03, '#d8d8e0', rr(-15, 15), rr(-15, 15), r.small ? 0.25 : 0.35, rr(3, 5), 'smoke');
    for (const e of enemies) if (e.alive && (e.layer === 'air' || r.any && !e.dive && r.t > 0.3) && distTo(e, r.x, r.y) < 8) { hurt(e, r.dmg); r.dead = true; explode(r.x, r.y, r.small ? 22 : 26, e.layer !== 'air'); ring(r.x, r.y, r.small ? 22 : 30, '#ffd9a0'); break; } // tiny but visible blast
    if (r.t > 3 || r.y < -80 || r.y > VH + 80 || r.x < -80 || r.x > VW + 80) r.dead = true;
  }
  rockets = rockets.filter((r) => !r.dead);

  // bombs
  for (const b of bombs) {
    b.t += dt;
    if (b.t < 0) { b.sx = P.x; b.sy = P.y; continue; }
    const k = Math.min(1, b.t / b.T), ty = b.twy - cam;
    b.x = lerp(b.sx, b.tx, k); b.y = lerp(b.sy, ty, k) - Math.sin(k * Math.PI) * 60; b.k = k;
    if (k >= 1) {
      b.dead = true;
      const land = isLand(b.tx, ty), sea = isSea(b.tx, ty);
      explode(b.tx, ty, b.r * 0.75, true);
      if (!b.mini) {
        sfx('kaboom'); G.shake = Math.max(G.shake, 7); G.flash = Math.max(G.flash, 0.1); G.hitStop = Math.max(G.hitStop || 0, 0.045);
        shocks.push({ x: b.tx, y: ty, r: b.r * 2.3, t: 0 });
        for (let i = 0; i < 10; i++) part(b.tx + rr(-10, 10), ty, i % 3 ? '#ff9a3a' : '#ffe0a0', rr(-40, 40), rr(-260, -120), rr(0.4, 0.8), rr(4, 8), 'flame'); // fire column
        for (let i = 0; i < 8; i++) part(b.tx + rr(-14, 14), ty, '#2a2426', rr(-30, 30), rr(-140, -60), rr(0.8, 1.4), rr(6, 11), 'smoke');
      } else { sfx('boom'); G.shake = Math.max(G.shake, 3); }
      if (land) scorch(b.tx, ty, b.r);
      else if (sea) { ring(b.tx, ty, b.r * 1.1, '#ffffff'); for (let i = 0; i < 8; i++) part(b.tx, ty, '#e8f8ff', rr(-120, 120), rr(-120, 120), 0.5, rr(3, 7), 'splash'); }
      blast(b.tx, ty, b.r, b.dmg);
      if (b.napalm && land) fires.push({ x: b.tx, wy: b.twy, r: b.r * 0.8, t: 0, T: 1.5 + b.napalm, dps: b.dmg * (0.35 + 0.15 * b.napalm) });
      if (b.cluster) for (let i = 0; i < 1 + b.cluster * 2; i++) {
        const a = rr(0, TAU), d = rr(b.r * 0.8, b.r * 1.7);
        bombs.push({ sx: b.tx, sy: ty, x: b.tx, y: ty, tx: b.tx + Math.cos(a) * d, twy: b.twy + Math.sin(a) * d, t: -i * 0.04, T: 0.35, r: b.r * 0.55, dmg: b.dmg * 0.4, mini: true, cluster: 0, napalm: 0, fixed: true });
      }
    }
  }
  for (const b of bombs) if (b.fixed && b.t < 0) { b.sx = b.tx; } // bomblets start where their parent burst
  bombs = bombs.filter((b) => !b.dead);

  // torpedoes: run up the water, steer at ships, hit diving subs too
  for (const t of torps) {
    t.t += dt;
    let tgt = null, bd = 400;
    for (const e of enemies) if (e.alive && e.layer === 'sea' && e.y < t.y + 20) { const d = Math.hypot(e.x - t.x, e.y - t.y); if (d < bd) { bd = d; tgt = e; } }
    if (tgt) t.x += clamp(tgt.x - t.x, -1, 1) * Math.min(Math.abs(tgt.x - t.x), 160 * dt);
    t.y -= 260 * dt;
    if (rand() < 0.7) part(t.x + rr(-3, 3), t.y + 14, '#ffffff', 0, G.scroll, 0.5, rr(2, 4), 'foam');
    if (!isSea(t.x, t.y - 10)) { t.dead = true; explode(t.x, t.y, 22, true); sfx('boom'); continue; }
    for (const e of enemies) if (e.alive && e.layer === 'sea' && distTo(e, t.x, t.y) < 6) {
      t.dead = true; explode(t.x, t.y, 34, true); ring(t.x, t.y, 50, '#ffffff'); sfx('boom'); blast(t.x, t.y, 40, t.dmg, { torp: true }); break;
    }
    if (t.y < -40) t.dead = true;
  }
  torps = torps.filter((t) => !t.dead);

  for (const f of fires) {
    f.t += dt;
    const y = f.wy - cam;
    if (rand() < dt * 18) part(f.x + rr(-f.r, f.r) * 0.8, y + rr(-f.r, f.r) * 0.6, pick(['#ff8a2a', '#ffd34d', '#ff4f2a']), rr(-10, 10), rr(-50, -20), 0.5, rr(4, 8), 'flame');
    if ((f.tick = (f.tick || 0) - dt) <= 0) { f.tick = 0.25; blast(f.x, y, f.r, f.dps * 0.25); }
  }
  fires = fires.filter((f) => f.t < f.T);

  // enemy shots vs player
  for (const b of eshots) {
    b.t += dt;
    if (b.home && b.t < b.home) { // sub rockets curve toward you, then fly straight
      const sp = Math.min(230 * bulletMul(), Math.hypot(b.vx, b.vy) + 260 * dt), a = lerpAngle(Math.atan2(b.vy, b.vx), aim(b.x, b.y), dt * 3);
      b.vx = Math.cos(a) * sp; b.vy = Math.sin(a) * sp;
      if (rand() < 0.5) part(b.x, b.y, '#c8c8d0', 0, 0, 0.3, 3, 'smoke');
    }
    b.x += b.vx * dt; b.y += b.vy * dt;
    if (b.x < -30 || b.x > VW + 30 || b.y < -60 || b.y > VH + 30) b.dead = true;
    else if (Math.hypot(b.x - P.x, b.y - P.y) < b.r + 8 && !G.dying) { b.dead = true; damagePlayer(b.kind); }
  }
  eshots = eshots.filter((b) => !b.dead);
  // flak bursts (mega tank)
  for (const m of markers) {
    m.t += dt;
    if (m.t >= m.T) { m.dead = true; explode(m.x, m.y, 40, false); sfx('pop'); if (Math.hypot(P.x - m.x, P.y - m.y) < m.r + 8) damagePlayer('flakburst'); }
  }
  markers = markers.filter((m) => !m.dead);
  // body contact with planes
  if (!G.dying) for (const e of enemies) if (e.alive && e.layer === 'air' && distTo(e, P.x, P.y) < 10) {
    damagePlayer('ram:' + e.type); if (!e.boss) hurt(e, 60 * hpMul());
  }

  updatePickups(dt);
  for (const p of parts) {
    p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.kind === 'foam' || p.kind === 'splash' || p.kind === 'debris') p.y += G.scroll * dt;
    const drag = p.kind === 'smoke' || p.kind === 'flame' ? 2 : 4; p.vx *= Math.exp(-dt * drag); p.vy *= Math.exp(-dt * drag);
  }
  parts = parts.filter((p) => p.life > 0);
  for (const b of booms) { b.t += dt; if (b.ground) b.y += G.scroll * dt; }
  booms = booms.filter((b) => b.t < b.T + 0.15);
  for (const r of rings) { r.t += dt; r.y += G.scroll * dt; }
  rings = rings.filter((r) => r.t < r.T);
  for (const f of falling) {
    f.t += dt; f.x += f.vx * dt; f.y += f.vy * dt; f.rot += dt * 5;
    if (rand() < 0.6) part(f.x, f.y, '#3a3440', rr(-20, 20), rr(-20, 20), 0.6, rr(4, 7), 'smoke');
    if (f.t > 0.7) { f.dead = true; explode(f.x + 14, f.y + 22, 24, true); }
  }
  falling = falling.filter((f) => !f.dead);
  for (const z of zaps) z.t -= dt;
  zaps = zaps.filter((z) => z.t > 0);
  for (const c of clouds) { // thin high cloud; it thins out further over the plane and over ground targets so nothing hides under it
    c.y += G.scroll * c.sp * dt;
    const r = c.s * 0.42, under = Math.hypot(P.x - c.x, P.y - c.y) < r || enemies.some((e) => e.alive && e.layer !== 'air' && Math.hypot(e.x - c.x, e.y - c.y) < r);
    c.f = lerp(c.f, under ? 0.35 : 1, Math.min(1, dt * 4));
  }
  clouds = clouds.filter((c) => c.y < VH + c.s);
  if (rand() < dt * 0.22 * (G.scroll / SCROLL)) addCloud(-200);
  if (rand() < dt * 3) { const x = rr(10, VW - 10); if (isSea(x, -10)) glints.push({ x, y: -10, t: 0 }); }
  for (const g of glints) { g.t += dt; g.y += G.scroll * dt; }
  glints = glints.filter((g) => g.y < VH + 10);

  G.shake = Math.max(0, G.shake - dt * 30);
  for (const e of enemies) if (e.alive && !e.dive && e.hp < e.maxHp * 0.5 && (e.boss || e.maxHp > 60 * hpMul()) && rand() < dt * (e.boss ? 14 : 6)) {
    const s = e.size * 0.3; part(e.x + rr(-s, s), e.y + rr(-s, s), rand() < 0.3 ? '#ff8a3a' : '#2a2628', rr(-15, 15), rr(20, 60), rr(0.5, 0.9), rr(4, 8), 'smoke');
  }
  if (!G.dying && P.hp === 1 && rand() < dt * 10) part(P.x + rr(-8, 8), P.y + 18, '#2a2628', rr(-10, 10), 90, 0.7, rr(4, 6), 'smoke');
  impacts = impacts.filter((m) => (m.t += dt) < 0.12);
  shocks = shocks.filter((s) => (s.t += dt) < 0.5);
  lasers = lasers.filter((l) => (l.t += dt) < 0.16);
  rails = rails.filter((r) => (r.t += dt) < 0.6);
  G.flash = Math.max(0, G.flash - dt * 2);

  if (G.dying) { G.dying -= dt / G.slow; if (G.dying <= 0) gameOver(); }
  if (G.pendingLv > 0 && !G.dying) { G.pendingLv--; sfx('level'); G.cardQueue.push({ title: 'LEVEL UP', sub: 'Pick an upgrade', kind: 'cards', lvl: 1 }); }
  if (G.cardQueue.length && !G.dying && !G.paused && G.state === 'play') openCards(G.cardQueue.shift());
}
// Health and shield bars under the plane itself, always in the same spot (the plane's lowest position leaves room for them).
function rrect(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
function drawHeartGlyph(cx, cy, r, color) {
  ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(cx, cy + r * 0.95);
  ctx.bezierCurveTo(cx - r * 1.5, cy - r * 0.1, cx - r * 0.85, cy - r * 1.1, cx, cy - r * 0.35);
  ctx.bezierCurveTo(cx + r * 0.85, cy - r * 1.1, cx + r * 1.5, cy - r * 0.1, cx, cy + r * 0.95); ctx.fill();
}
function drawPlaneBars() {
  base();
  const W = 40, H = 6, x = P.x - W / 2, y = P.y + 52, n = Math.max(1, P.maxHp), gap = 2, segW = (W - gap * (n - 1)) / n;
  const low = P.hp <= 1, pulse = low ? 0.5 + 0.5 * Math.sin(G.t * 9) : 0;
  const top = low ? '#ff7a62' : P.hp / n > 0.6 ? '#9af27a' : '#ffd86a', bot = low ? '#c4261c' : P.hp / n > 0.6 ? '#2f9e3f' : '#d98a1c';
  ctx.globalAlpha = 0.96;
  // plate: dark glass with a thin light rim (and a red glow when on the last heart)
  if (low) { ctx.globalAlpha = 0.25 + 0.3 * pulse; ctx.fillStyle = '#ff3a2a'; rrect(x - 5, y - 4, W + 10, H + 8, 5); ctx.fill(); ctx.globalAlpha = 0.96; }
  ctx.fillStyle = 'rgba(10,8,20,.82)'; rrect(x - 3, y - 2, W + 6, H + 4, 4); ctx.fill();
  ctx.strokeStyle = P.inv > 1 ? '#ffffff' : 'rgba(190,170,255,.4)'; ctx.lineWidth = P.inv > 1 ? 1.6 : 1; rrect(x - 3, y - 2, W + 6, H + 4, 4); ctx.stroke();
  for (let i = 0; i < n; i++) {
    const sx = x + i * (segW + gap);
    ctx.fillStyle = 'rgba(255,255,255,.09)'; rrect(sx, y, segW, H, 2); ctx.fill();
    if (i < P.hp) {
      const g = ctx.createLinearGradient(0, y, 0, y + H); g.addColorStop(0, top); g.addColorStop(1, bot);
      ctx.fillStyle = g; rrect(sx, y, segW, H, 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.32)'; rrect(sx + 1, y + 0.8, segW - 2, 1.8, 1); ctx.fill(); // gloss
    }
  }
  if (L('shield')) { // shield: full bar while up, a recharge meter while down
    const maxT = [16, 16, 13, 10][L('shield')] || 16, f = P.shield ? 1 : clamp(1 - P.shieldT / maxT, 0, 1), sy = y + H + 5, sw = W;
    ctx.globalAlpha = P.shield ? 0.96 : 0.75;
    ctx.fillStyle = 'rgba(10,8,20,.82)'; rrect(x - 3, sy - 2, sw + 6, 7, 3); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.09)'; rrect(x, sy, sw, 3, 1.5); ctx.fill();
    ctx.fillStyle = P.shield ? '#6cc4ff' : '#4d7f9c'; if (f > 0) { rrect(x, sy, Math.max(3, sw * f), 3, 1.5); ctx.fill(); }
  }
  ctx.globalAlpha = 1;
}
// The barrage locks ONE target: every micro-missile goes for it, and when it dies the missiles already in the air do not
// switch (they fly on straight); the next volley picks a new one (the nearest enemy ahead of the plane).
function barTarget(tg) {
  if (!P.barTgt || !P.barTgt.alive || P.barTgt.dive) {
    let best = null, bd = 1e9;
    for (const e of tg) { const d = Math.hypot(e.x - P.x, e.y - P.y); if (d < bd) { bd = d; best = e; } }
    P.barTgt = best;
  }
  return P.barTgt;
}
function microMissile(s, dmg, spread = 1) {
  const tg = enemies.filter((e) => e.alive && !e.dive && e.y > -20 && e.y < P.y);
  rockets.push({ x: P.x + s * rr(14, 26), y: P.y + rr(-4, 8), vx: s * rr(160, 380) * spread, vy: rr(-60, 150), a: 0, t: 0,
    tgt: barTarget(tg), lock: 1, dmg, small: 1, any: 1, turn: rr(4, 11), wob: rr(0, TAU), sp: rr(380, 600) });
}
function nearestAny(x, y) { let best = null, bd = 1e9; for (const e of enemies) if (e.alive && !e.dive && e.y > -20) { const d = Math.hypot(e.x - x, e.y - y); if (d < bd) { bd = d; best = e; } } return best; }
function nearestAir(x, y) { let best = null, bd = 1e9; for (const e of enemies) if (e.alive && e.layer === 'air') { const d = Math.hypot(e.x - x, e.y - y); if (d < bd) { bd = d; best = e; } } return best; }

// ---------- autopilot (testing / teaser recording) ----------
function bot(dt) {
  let tx = VW / 2, ty = VH * 0.74;
  const tgt = nearestAir(P.x, P.y - 300);
  if (tgt && tgt.y < P.y - 60) tx = tgt.x;
  const pk = pickups.find((p) => p.kind === 'crate' || p.kind === 'heart');
  if (pk && pk.y > 100) { tx = pk.x; ty = clamp(pk.y + 40, 200, VH - 60); }
  if (G.bell && !G.bell.taken) { const bx = G.bell.boxes[G.bell.pref % G.bell.boxes.length]; if (bx.y > 40) { tx = bx.x; ty = bx.y + 10; } } // fly into the preferred upgrade box
  let best = null, bs = -1e9;
  for (let i = 0; i < 16; i++) {
    const a = i / 16 * TAU, d = i % 2 ? 26 : 52;
    for (const [cx, cy] of [[P.x + Math.cos(a) * d, P.y + Math.sin(a) * d], [P.x, P.y]]) {
      let s = -Math.hypot(cx - tx, (cy - ty) * 0.6) * 0.02;
      for (const b of eshots) {
        for (const la of [0.12, 0.28]) { const d2 = Math.hypot(b.x + b.vx * la - cx, b.y + b.vy * la - cy); if (d2 < 60) s -= (60 - d2) * (60 - d2) * 0.02; }
      }
      for (const e of enemies) if (e.alive && e.layer === 'air') { const d2 = distTo(e, cx, cy); if (d2 < 40) s -= (40 - d2) * 3; }
      if (cx < 30 || cx > VW - 30) s -= 50;
      if (s > bs) { bs = s; best = [cx, cy]; }
    }
  }
  const dx = best[0] - P.x, dy = best[1] - P.y, l = Math.hypot(dx, dy);
  if (l > 1) { const m = Math.min(l, 480 * dt); P.x += dx / l * m; P.y += dy / l * m; }
}

// ---------- drawing ----------
function render() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = '#0f2234'; ctx.fillRect(0, 0, cv.width, cv.height);
  if (!P) return;
  shx = G.shake ? rr(-1, 1) * G.shake : 0; shy = G.shake ? rr(-1, 1) * G.shake : 0;
  // terrain
  for (const [k, ch] of chunks) {
    const y = (k * CH - cam + shy) * S;
    if (y > cv.height || y + CH * S < 0) continue;
    const x0 = wrapX(camX), w1 = Math.min(VW, WW - x0), hh = Math.ceil(CH * S) + 1;
    ctx.drawImage(ch.c, x0 * ch.res, 0, w1 * ch.res, CH * ch.res, shx * S, Math.floor(y), w1 * S, hh);
    if (w1 < VW) ctx.drawImage(ch.c, 0, 0, (VW - w1) * ch.res, CH * ch.res, (shx + w1) * S, Math.floor(y), (VW - w1) * S, hh);
  }
  base();
  ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 2; ctx.lineCap = 'round';
  for (const g of glints) { const a = Math.sin(g.t * 2.5); if (a <= 0) continue; ctx.globalAlpha = a * 0.18; ctx.beginPath(); ctx.moveTo(g.x - 6, g.y); ctx.lineTo(g.x + 6, g.y); ctx.stroke(); }
  ctx.globalAlpha = 1;
  for (const f of fires) { // napalm
    const y = f.wy - cam, a = Math.min(1, (f.T - f.t) * 2);
    const gr = ctx.createRadialGradient(f.x, y, 2, f.x, y, f.r); gr.addColorStop(0, `rgba(255,190,60,${0.55 * a})`); gr.addColorStop(1, 'rgba(255,80,20,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x, y, f.r, 0, TAU); ctx.fill();
  }
  for (const p of parts) if (p.kind === 'foam') { ctx.globalAlpha = p.life / p.max * 0.8; ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1.6 - p.life / p.max), 0, TAU); ctx.fill(); }
  ctx.globalAlpha = 1;
  // surface units
  for (const e of enemies) {
    if (e.layer === 'air' || !e.alive && !e.boss) continue;
    if (e.dive) {
      sprite(e.type, e.x, e.y, e.size * 0.96, e.rot, 0.3, 0, 1, 0, '#0b2a48');
      continue;
    }
    sprite(e.type, e.x + 4, e.y + 6, e.size, e.rot, 0.3, 0, 1, 0, SHADOW);
    sprite(e.type, e.x, e.y, e.size, e.rot, 1, e.flash > 0 ? (e.boss ? 0.4 : 0.8) : 0);
    if (e.def.elite) hpBar(e);
  }
  // bomb reticles + flak markers
  ctx.lineWidth = 2.5;
  for (const b of bombs) {
    if (b.mini || b.t < 0) continue;
    const y = b.twy - cam, k = b.k || 0, blink = 0.55 + 0.45 * Math.sin(b.t * (8 + k * k * 40));
    ctx.fillStyle = `rgba(0,0,0,${0.12 + k * 0.3})`; ctx.beginPath(); ctx.ellipse(b.tx, y, 6 + k * 14, 4 + k * 9, 0, 0, TAU); ctx.fill(); // its shadow
    ctx.strokeStyle = `rgba(255,${70 - k * 40},${70 - k * 40},${(0.35 + k * 0.6) * blink})`; ctx.lineWidth = 2 + k * 2;
    const rr0 = b.r * (1.05 - k * 0.4); ctx.beginPath(); ctx.arc(b.tx, y, rr0, 0, TAU); ctx.stroke();
    for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + k * 1.5; ctx.beginPath(); ctx.moveTo(b.tx + Math.cos(a) * rr0 * 0.6, y + Math.sin(a) * rr0 * 0.6); ctx.lineTo(b.tx + Math.cos(a) * rr0 * 1.15, y + Math.sin(a) * rr0 * 1.15); ctx.stroke(); }
    ctx.lineWidth = 2.5;
  }
  for (const m of markers) {
    const k = m.t / m.T;
    ctx.strokeStyle = `rgba(255,60,90,${0.4 + k * 0.6})`; ctx.fillStyle = `rgba(255,60,90,${k * 0.25})`;
    ctx.beginPath(); ctx.arc(m.x, m.y, m.r, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(m.x, m.y, m.r * k, 0, TAU); ctx.stroke();
  }
  for (const s of shocks) { // bomb shockwave: a bright ring racing out, thinning as it goes
    const k = s.t / 0.5, r = s.r * (0.15 + 0.85 * Math.sqrt(k));
    ctx.globalAlpha = (1 - k) * 0.9; ctx.strokeStyle = '#fff3d0'; ctx.lineWidth = 9 * (1 - k) + 1; ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, TAU); ctx.stroke();
    ctx.globalAlpha = (1 - k) * 0.35; ctx.fillStyle = '#ffb060'; ctx.beginPath(); ctx.arc(s.x, s.y, r * 0.8, 0, TAU); ctx.fill();
  }
  ctx.globalAlpha = 1;
  for (const r of rings) {
    const k = r.t / r.T; ctx.globalAlpha = 1 - k; ctx.strokeStyle = r.color; ctx.lineWidth = 4 * (1 - k) + 1;
    ctx.beginPath(); ctx.arc(r.x, r.y, r.r * (0.4 + k * 0.8), 0, TAU); ctx.stroke();
  }
  ctx.globalAlpha = 1;
  drawBooms(true);
  // torpedoes
  for (const t of torps) { xf(t.x, t.y, clamp((t.x - (t.px ?? t.x)) * 0.15, -0.5, 0.5), 1); ctx.drawImage(TEX.torp, -5, -21, 10, 42); t.px = t.x; }
  // clouds under the planes
  for (const c of clouds) sprite('cloud', c.x, c.y, c.s, 0, c.a * c.f, 0, c.flip);
  for (const wy of bands) cloudBand(wy - cam);
  // air shadows
  for (const e of enemies) if (e.layer === 'air' && (e.alive || e.boss)) shadowOf(e.type, e.x, e.y, e.size, e.rot, e.boss ? 1.8 : 1);
  if (!G.dying) shadowOf(P.ship, P.x, P.y, 74, 0);
  for (const f of falling) sprite(f.type, f.x, f.y, f.size * (1 - f.t * 0.6), f.rot, 1, 0, 1, 0, '#3a3038');
  // pickups
  for (const p of pickups) {
    const bob = Math.sin(p.t * 6) * 2;
    if (p.kind === 'crate') { sprite('items', p.x, p.y + bob, 64, Math.sin(p.t * 1.3) * 0.15, 1, 0, 1, 3); continue; }
    const fr = p.kind === 'coin' ? 0 : p.kind === 'xp' ? 1 : 2, sz = (p.kind === 'xp' ? (p.v > 3 ? 24 : 18) : 22) * (p.t < 0.18 ? 1 + (0.18 - p.t) * 3 : 1);
    sprite('items', p.x, p.y + bob, sz, p.kind === 'coin' ? 0 : Math.sin(p.t * 3) * 0.3, 1, 0, p.kind === 'coin' ? Math.cos(p.t * 5) : 1, fr);
  }
  if (G.bell) drawBell(G.bell);
  // air units
  for (const e of enemies) {
    if (e.layer !== 'air' || (!e.alive && !e.boss)) continue;
    sprite(e.type, e.x, e.y, e.size, e.rot, 1, e.flash > 0 ? (e.boss ? 0.4 : 0.8) : 0);
    if (e.def.elite) hpBar(e);
  }
  // bombs in flight
  for (const b of bombs) {
    if (b.t < 0 || b.mini) continue;
    // lobbed: it swells as it climbs toward the camera, then shrinks as it falls onto the target, tumbling a little
    const k = b.k || 0, s = (1 + 0.45 * Math.sin(k * Math.PI)) * (1 - k * 0.45), a = clamp(Math.atan2(b.tx - b.sx, -((b.twy - cam) - b.sy)), -0.45, 0.45); // nose forward, leaning a little toward the target
    xf(b.x, b.y, a, s); ctx.drawImage(TEX.bomb, -8, -16.5, 16, 33);
  }
  // player + wingmen
  if (!G.dying) {
    for (const w of wingmen) { shadowOf(P.ship, w.x, w.y, 36, 0, 0.7); sprite(P.ship, w.x, w.y, 38, 0, 0.95); }
    const blink = P.inv > 0 && Math.floor(P.inv * 14) % 2 === 0;
    // banking: the wings foreshorten and the nose yaws a touch into the turn
    if (!blink) sprite(P.ship, P.x, P.y, 76, P.bank * 0.12, 1, 0, 1 - 0.32 * Math.abs(P.bank));
    if (P.muzzle > 0) { base(); ctx.globalCompositeOperation = 'lighter'; const r = 11 + Math.random() * 5; for (const s of [-1, 1]) ctx.drawImage(TEX.flash, P.x + s * 17 - r, P.y - 28 - r, r * 2, r * 2); ctx.globalCompositeOperation = 'source-over'; }
    drawPlaneBars();
    if (P.shield) { base(); ctx.strokeStyle = 'rgba(154,216,255,.85)'; ctx.fillStyle = 'rgba(154,216,255,.13)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(P.x, P.y, 50 + Math.sin(G.t * 4) * 2, 0, TAU); ctx.fill(); ctx.stroke(); }
  }
  // player shots
  ctx.globalCompositeOperation = 'lighter';
  for (const b of pshots) {
    const w = 10 * b.sc, h = 32 * b.sc; // gold tracers
    if (b.a) xf(b.x, b.y + h * 0.4, b.a, 1); else { base(); ctx.translate(b.x, b.y + h * 0.4); }
    ctx.drawImage(TEX.shot, -w, -h, w * 2, h * 2);
  }
  base();
  for (const m of impacts) { const k = 1 - m.t / 0.12, r = m.r * (0.6 + 0.6 * (1 - k)); ctx.globalAlpha = k; ctx.drawImage(TEX.hit, m.x - r, m.y - r, r * 2, r * 2); }
  ctx.globalAlpha = 1;
  for (const r of rails) {
    const k = r.t / 0.6, w = 46 * (1 - k * 0.7), top = -20;
    ctx.globalAlpha = (1 - k) * 0.9; ctx.drawImage(TEX.beam, r.x - w, top, w * 2, r.y0 - top);
    ctx.globalAlpha = 1 - k; ctx.drawImage(TEX.beam, r.x - w * 0.25, top, w * 0.5, r.y0 - top);
    ctx.fillStyle = '#bfe8ff';
    for (let y = r.y0; y > top; y -= 9) { const ph = y * 0.09 + r.t * 30, rx = Math.sin(ph) * (10 + k * 26); ctx.globalAlpha = (1 - k) * (0.4 + 0.4 * Math.cos(ph)); ctx.fillRect(r.x + rx - 2, y - 2, 4, 4); }
    ctx.globalAlpha = 1;
  }
  if (P && !G.dying && L('railgun') && P.railT < 1) { // charge glow at the nose
    const c = 1 - P.railT, r = 8 + c * 34 + Math.sin(G.t * 40) * 3; ctx.globalAlpha = 0.3 + c * 0.7; ctx.drawImage(TEX.hit, P.x - r, P.y - 34 - r, r * 2, r * 2); ctx.globalAlpha = 1;
  }
  if (P && !G.dying && L('laser')) {
    const w = (9 + 2 * L('laser')) * 2.6;
    if (P.beamOn > 0) {
      const f = 1 + Math.sin(G.t * 60) * 0.08 + rr(-0.05, 0.05), top = -20, y0 = P.y - 34;
      ctx.drawImage(TEX.beam, P.x - w * f, top, w * 2 * f, y0 - top);
      ctx.drawImage(TEX.beam, P.x - w * 0.45, top, w * 0.9, y0 - top);
      const r = 26 * f; ctx.drawImage(TEX.hit, P.x - r, y0 - r, r * 2, r * 2);
    } else if (P.beamT < 0.5) { const r = 6 + (0.5 - P.beamT) * 40; ctx.globalAlpha = 0.4 + (0.5 - P.beamT); ctx.drawImage(TEX.hit, P.x - r, P.y - 34 - r, r * 2, r * 2); ctx.globalAlpha = 1; } // charging
  }
  for (const r of rockets) { xf(r.x, r.y, Math.atan2(r.vx, -r.vy), 1); ctx.globalAlpha = 0.9; ctx.drawImage(TEX.trail, -6, 11, 12, 34 + Math.random() * 8); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  for (const r of rockets) {
    xf(r.x, r.y, Math.atan2(r.vx, -r.vy), 1);
    const k = r.small ? 0.75 : 1; ctx.drawImage(TEX.missile, -7 * k, -13 * k, 14 * k, 26 * k);
  }
  base();
  // zaps
  ctx.strokeStyle = '#bff4ff'; ctx.lineWidth = 3; ctx.lineJoin = 'round';
  for (const z of zaps) {
    ctx.globalAlpha = z.t / 0.16; ctx.beginPath();
    for (let i = 0; i < z.pts.length - 1; i++) {
      const [x0, y0] = z.pts[i], [x1, y1] = z.pts[i + 1]; ctx.moveTo(x0, y0);
      for (let s = 1; s <= 5; s++) ctx.lineTo(lerp(x0, x1, s / 5) + (s < 5 ? rr(-10, 10) : 0), lerp(y0, y1, s / 5) + (s < 5 ? rr(-10, 10) : 0));
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  // particles
  for (const p of parts) {
    if (p.kind === 'foam') continue;
    const k = p.life / p.max;
    ctx.globalAlpha = p.kind === 'smoke' ? k * 0.55 : Math.min(1, k * 2);
    ctx.fillStyle = p.color;
    const s = p.kind === 'smoke' ? p.size * (2 - k) : p.size * (p.kind === 'flame' ? k : 1);
    if (p.kind === 'debris' || p.kind === 'spark') ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
    else { ctx.beginPath(); ctx.arc(p.x, p.y, s, 0, TAU); ctx.fill(); }
  }
  ctx.globalAlpha = 1;
  drawBooms(false);
  // light: additive fire glow, then the dark vignette (Runebound's torch-lit look)
  base(); ctx.globalCompositeOperation = 'lighter';
  const glow = (x, y, r, a) => { if (a > 0.01) { ctx.globalAlpha = Math.min(1, a); ctx.drawImage(TEX.glow, x - r, y - r, r * 2, r * 2); } };
  for (const b of booms) { const k = b.t / b.T; glow(b.x, b.y, b.r * 2.6, (1 - k) * 1.1); }
  for (const f of fires) glow(f.x, f.wy - cam, f.r * 1.8, Math.min(1, (f.T - f.t) * 2) * 0.5);
  for (const r of rockets) glow(r.x, r.y, 26, 0.5);
  if (!G.dying) { glow(P.x, P.y + 30, 60, 0.18); if (P.muzzle > 0) glow(P.x, P.y - 26, 46, 0.6); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(TEX.vignette, 0, 0, cv.width, cv.height);
  // jet lasers: a flickering aim line, then a split-second beam across the screen
  base();
  for (const e of enemies) if (e.alive && e.lz && !e.lz.done) {
    const k = e.lz.t / 0.4; ctx.strokeStyle = `rgba(255,60,70,${(0.25 + 0.5 * k) * (0.6 + 0.4 * Math.sin(G.t * 60))})`; ctx.lineWidth = 1 + k * 1.5;
    ctx.beginPath(); ctx.moveTo(e.x, e.y + 20); ctx.lineTo(e.x + Math.cos(e.lz.a) * 1400, e.y + 20 + Math.sin(e.lz.a) * 1400); ctx.stroke();
  }
  for (const l of lasers) {
    const k = l.t / 0.16, w = 16 * (1 - k * 0.6);
    xf(l.x, l.y, l.a + Math.PI / 2, 1); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 1 - k * 0.7;
    ctx.drawImage(TEX.beamR, -w, -1400, w * 2, 1400); ctx.drawImage(TEX.beamR, -w * 0.4, -1400, w * 0.8, 1400);
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  }
  // enemy shots last: they must always be readable
  for (const b of eshots) {
    if (b.kind === 'rocket') {
      xf(b.x, b.y, Math.atan2(b.vx, -b.vy), 1);
      ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(TEX.trail, -8, 13, 16, 40 + Math.random() * 10); ctx.globalCompositeOperation = 'source-over';
      ctx.drawImage(TEX.emissile, -8.5, -15, 17, 30);
      continue;
    }
    if (b.kind === 'laser') {
      xf(b.x, b.y, Math.atan2(b.vx, -b.vy), 1); ctx.globalCompositeOperation = 'lighter';
      ctx.drawImage(TEX.laserR, -9, -28, 18, 56); ctx.drawImage(TEX.laserR, -5, -24, 10, 48);
      ctx.globalCompositeOperation = 'source-over'; continue;
    }
    const tx = ETEX[b.kind], s = b.r * 1.8;
    base(); ctx.drawImage(tx, b.x - s, b.y - s, s * 2, s * 2);
  }
  // boss-approach speed lines
  if (G.scroll > SCROLL * 1.3) {
    base(); ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 2;
    const k = (G.scroll - SCROLL) / (SCROLL * 2.2);
    for (let i = 0; i < 14; i++) { const x = hash2(i, 9) * VW, y = ((hash2(i, 3) * VH + G.t * 1400) % (VH + 200)) - 100; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 80 * k); ctx.stroke(); }
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (G.flash > 0) { ctx.globalAlpha = Math.min(1, G.flash); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); ctx.globalAlpha = 1; }
}
function hpBar(e) {
  base(); const w = 60, y = e.y - e.size * 0.5 - 10;
  ctx.fillStyle = '#06101f'; ctx.fillRect(e.x - w / 2 - 2, y - 2, w + 4, 8);
  ctx.fillStyle = '#ff5f8a'; ctx.fillRect(e.x - w / 2, y, w * clamp(e.hp / e.maxHp, 0, 1), 4);
}
// explosions: soft fire puffs that cool into dark smoke (pre-rendered, no per-frame gradients)
const puffTex = (stops) => makeCanvas(96, 96, (g) => {
  const gr = g.createRadialGradient(48, 48, 0, 48, 48, 48); for (const [o, c] of stops) gr.addColorStop(o, c);
  g.fillStyle = gr; g.fillRect(0, 0, 96, 96);
});
const BOOM_TEX = [
  puffTex([[0, 'rgba(255,255,230,1)'], [0.3, 'rgba(255,220,120,.95)'], [0.65, 'rgba(255,120,30,.6)'], [1, 'rgba(200,40,10,0)']]),
  puffTex([[0, 'rgba(255,170,60,.95)'], [0.45, 'rgba(220,70,20,.65)'], [1, 'rgba(90,20,10,0)']]),
  puffTex([[0, 'rgba(40,32,36,.85)'], [0.55, 'rgba(30,24,28,.55)'], [1, 'rgba(20,16,20,0)']]),
];
function drawBooms(ground) {
  base();
  for (const b of booms) {
    if (b.ground !== ground) continue;
    for (const [dx, dy, pr, delay] of b.puffs) {
      const k = (b.t - delay) / b.T; if (k <= 0 || k >= 1) continue;
      const r = pr * 1.35 * (k < 0.25 ? 0.55 + k / 0.25 * 0.45 : 1 + (k - 0.25) * 0.4), x = b.x + dx, y = b.y + dy - k * 14;
      const tex = k < 0.22 ? 0 : k < 0.45 ? 1 : 2;
      ctx.globalAlpha = tex === 2 ? (1 - k) * 1.4 : 1;
      ctx.drawImage(BOOM_TEX[tex], x - r, y - r, r * 2, r * 2);
    }
  }
  ctx.globalAlpha = 1;
}
let cloudRGB = null;
function cloudCol() { // the band's solid middle matches the cloud sprite's average color
  if (cloudRGB) return cloudRGB;
  const sp = SPR.cloud; if (!sp) return '#2a3040';
  const g = makeCanvas(16, 16, (c) => c.drawImage(sp.img, 0, 0, sp.fw, sp.h, 0, 0, 16, 16)).getContext('2d');
  const d = g.getImageData(0, 0, 16, 16).data; let r = 0, gg = 0, b = 0, n = 0;
  for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 200) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; n++; }
  return (cloudRGB = n ? `rgb(${r / n | 0},${gg / n | 0},${b / n | 0})` : '#2a3040');
}
function cloudBand(y) {
  if (y < -320 || y > VH + 320) return;
  base(); ctx.fillStyle = cloudCol(); ctx.fillRect(0, y - 90, VW, 180);
  for (let i = 0; i < 7; i++) {
    sprite('cloud', (i + 0.5) * VW / 7 + Math.sin(i * 3.1) * 30, y - 110 + hash2(i, 1) * 30, 260, 0, 1, 0, i % 2 ? 1 : -1);
    sprite('cloud', (i + 0.2) * VW / 7 + Math.sin(i * 1.7) * 30, y + 110 - hash2(i, 2) * 30, 260, Math.PI, 1, 0, i % 2 ? -1 : 1);
  }
}

// ---------- HUD ----------
let hudDirty = true, hudT = 0;
function updateHud(dt) {
  hudT -= dt;
  if (hudDirty) {
    hudDirty = false;
    const heart = iconOf(['items', 2]), sh = iconOf(['items', 4]);
    let h = '';
    for (let i = 0; i < P.maxHp; i++) h += `<div class="heart${i < P.hp ? '' : ' off'}" style="--img:${heart}"></div>`;
    if (L('shield')) h += `<div class="heart shield${P.shield ? '' : ' off'}" style="--img:${sh}"></div>`;
    $('hearts').innerHTML = h;
  }
  if (hudT > 0) return;
  hudT = 0.1;
  $('dist').textContent = kmFlown().toFixed(1) + ' km';
  $('sector').textContent = `SECTOR ${G.sector} · ${segAt(cam + VH / 2).biome.name}`;
  $('coins').querySelector('b').textContent = G.coins;
  $('xpbar').querySelector('i').style.width = (P.xp / xpNeed(P.lvl) * 100).toFixed(1) + '%';
  $('lvl').textContent = 'LV ' + P.lvl;
  if (G.boss) $('bossfill').style.transform = `scaleX(${clamp(G.boss.hp / G.boss.maxHp, 0, 1)})`;
}
let bannerTO = 0, toastTO = 0;
function banner(text, sub = '', dur = 2, warn = false) {
  if (FF) return;
  const el = $('banner'); el.innerHTML = `${text}${sub ? `<small>${sub}</small>` : ''}`;
  el.style.color = warn ? '#ff7a8a' : ''; el.classList.add('show');
  clearTimeout(bannerTO); bannerTO = setTimeout(() => el.classList.remove('show'), dur * 1000);
}
function toast(text, sub = '', dur = 1.6) {
  if (FF) return;
  const el = $('toast'); el.innerHTML = `${text}${sub ? `<small>${sub}</small>` : ''}`; el.classList.add('show');
  clearTimeout(toastTO); toastTO = setTimeout(() => el.classList.remove('show'), dur * 1000);
}

// ---------- upgrade boxes: a level-up spawns ONE set of THREE steel boxes (the 3 options of cardOptions) that drift in, then hold
// in the upper screen until the plane flies into one. No timer, no pause. Extra level-ups queue in G.bellQ.
const BOX_VY = 40;
const FAM_COL = { gun: '#ff5a3c', bomb: '#3aa0ff', ship: '#5fe08a' };
const FAM_TXT = { gun: 'GUN', bomb: 'BOMB', ship: 'SHIP' };
let rerollBtn = null;
function boxRowY() { return clamp(VH * 0.26, 150, 330); }
function setBoxes(b, opts) { b.opts = opts; b.boxes = opts.map((o, i) => ({ o, x: VW / 2 + (i - (opts.length - 1) / 2) * 175, y: -60 - i * 28, ty: boxRowY(), flash: 1 })); }
function updateRerollBtn(on) {
  if (!rerollBtn) {
    if (!on) return;
    rerollBtn = document.createElement('button'); rerollBtn.textContent = 'REROLL';
    rerollBtn.style.cssText = 'position:fixed;z-index:20;transform:translateX(-50%);padding:8px 16px;font:800 15px "Alegreya Sans",sans-serif;color:#fff;background:#10141a;border:2px solid #ffd34d;border-radius:4px;display:none;touch-action:manipulation';
    rerollBtn.onpointerdown = (ev) => { ev.stopPropagation(); const b = G.bell; if (!b || b.taken || P.rerolls <= 0) return; P.rerolls--; setBoxes(b, cardOptions()); b.boxes.forEach((x) => { x.y = x.ty; }); sfx('pick'); };
    document.body.appendChild(rerollBtn);
  }
  const b = G.bell, show = on && b && !b.taken && P.rerolls > 0 && !G.paused;
  rerollBtn.style.display = show ? 'block' : 'none';
  if (show) { const r = cv.getBoundingClientRect(); rerollBtn.textContent = `REROLL (${P.rerolls})`; rerollBtn.style.left = (r.left + r.width / 2) + 'px'; rerollBtn.style.top = (r.top + r.height * (boxRowY() + 112) / VH) + 'px'; }
}
function takeBox(b, bx) {
  const o = bx.o, c = CARDS[o.id]; sfx('pick'); applyCard(o); hudDirty = true;
  if (!FF) toast(c.name.toUpperCase() + (o.epic ? ' +2' : ''), c.text(Math.max(0, L(o.id) - 1)), 1.6);
  ring(bx.x, bx.y, 70, '#ffd34d'); for (let i = 0; i < 8; i++) part(bx.x, bx.y, '#ffe27a', rr(-140, 140), rr(-140, 140), 0.5, rr(2.5, 4));
  b.taken = bx; b.fade = 0;
}
function updateBell(dt) {
  const b = G.bell;
  if (!b) {
    updateRerollBtn(false);
    const q = G.bellQ[0];
    if (!q) return;
    q.wait -= dt;
    const blocked = G.dying || G.paused || G.phase === 'clear' || G.phase === 'warn' || (G.boss && !G.boss.alive);
    if (q.wait > 0 || blocked) return;
    const opts = cardOptions(); G.offers++; G.bellQ.shift();
    if (!opts.length) return;
    G.bell = { opts: null, boxes: [], t: 0, taken: null, fade: 0, pref: Math.floor(rand() * opts.length) };
    setBoxes(G.bell, opts);
    return;
  }
  b.t += dt;
  if (b.taken) { b.fade += dt; if (b.fade > 0.45) { G.bell = null; if (G.bellQ[0]) G.bellQ[0].wait = Math.max(G.bellQ[0].wait, 0.6); updateRerollBtn(false); } return; }
  for (const bx of b.boxes) { bx.flash = Math.max(0, bx.flash - dt * 3); if (bx.y < bx.ty) bx.y = Math.min(bx.ty, bx.y + BOX_VY * dt); }
  updateRerollBtn(true);
  if (G.dying) return;
  if (FF && b.t > 3) { takeBox(b, b.boxes[b.pref % b.boxes.length]); return; } // fast-forward never waits
  for (const bx of b.boxes) {
    const by = bx.y + (bx.y >= bx.ty ? Math.sin(b.t * 2.2 + bx.x) * 4 : 0);
    if (bx.y > 20 && Math.hypot(P.x - bx.x, P.y - by) < 56) { takeBox(b, bx); return; }
  }
}
function drawBell(b) {
  for (const bx of b.boxes) {
    const al = b.taken ? (b.taken === bx ? Math.max(0, 1 - b.fade / 0.45) : Math.max(0, 1 - b.fade / 0.3)) : 1;
    if (al <= 0) continue;
    const near = Math.hypot(P.x - bx.x, P.y - bx.y) < 120;
    drawBox(b, bx, al * (near || b.taken ? 1 : 0.62));
  }
}
function drawBox(b, bx, al) {
  const o = bx.o, c = CARDS[o.id], col = FAM_COL[c.kind] || '#ffd34d';
  const x = bx.x, y = bx.y + (bx.y >= bx.ty ? Math.sin(b.t * 2.2 + bx.x) * 4 : 0);
  base(); ctx.globalAlpha = al;
  let g = ctx.createRadialGradient(x, y, 6, x, y, 54); g.addColorStop(0, col + 'aa'); g.addColorStop(1, col + '00');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 54, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(255,214,90,.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, 40 + Math.sin(b.t * 4) * 2, 0, TAU); ctx.stroke(); // gold ring: supply crates have none
  xf(x, y, 0, 1 + bx.flash * 0.2); ctx.globalAlpha = al;
  ctx.fillStyle = '#2b3138'; ctx.fillRect(-24, -24, 48, 48);
  ctx.fillStyle = col; ctx.globalAlpha = al * 0.28; ctx.fillRect(-19, -19, 38, 38); ctx.globalAlpha = al;
  ctx.strokeStyle = col; ctx.lineWidth = 5; ctx.strokeRect(-21.5, -21.5, 43, 43);
  ctx.strokeStyle = '#0c0f13'; ctx.lineWidth = 2; ctx.strokeRect(-24, -24, 48, 48); ctx.strokeRect(-19, -19, 38, 38);
  ctx.fillStyle = '#c9ced6'; for (const [px, py] of [[-21.5, -21.5], [21.5, -21.5], [-21.5, 21.5], [21.5, 21.5]]) { ctx.beginPath(); ctx.arc(px, py, 2, 0, TAU); ctx.fill(); }
  const sp = SPR[c.icon[0]];
  if (sp) { const k = 28 / Math.max(sp.fw, sp.h); ctx.drawImage(sp.img, c.icon[1] * sp.fw, 0, sp.fw, sp.h, -sp.fw * k / 2, -sp.h * k / 2, sp.fw * k, sp.h * k); }
  if (bx.flash > 0.05) { ctx.globalAlpha = al * bx.flash * 0.5; ctx.fillStyle = '#fff'; ctx.fillRect(-24, -24, 48, 48); ctx.globalAlpha = al; }
  const lv = L(o.id), tag = c.max > 50 ? '' : lv ? `Lv ${Math.min(c.max, lv + (o.epic ? 2 : 1))}` : 'NEW';
  ctx.textAlign = 'center';
  if (tag) {
    ctx.font = '800 12px "Alegreya Sans", sans-serif'; const w = ctx.measureText(tag).width + 10;
    ctx.fillStyle = '#10141a'; ctx.fillRect(24 - w / 2, -35, w, 16); ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.strokeRect(24 - w / 2, -35, w, 16);
    ctx.fillStyle = '#fff'; ctx.fillText(tag, 24, -23);
  }
  base(); ctx.globalAlpha = al;
  const name = c.name.toUpperCase() + (o.epic ? ' +2' : ''), desc = c.text(L(o.id));
  ctx.font = '700 15px "Alegreya Sans", sans-serif';
  const lines = []; let cur = '';
  for (const w of desc.split(' ')) { if (cur && ctx.measureText(cur + ' ' + w).width > 142) { lines.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w; }
  lines.push(cur);
  const pw = 160, ph = 26 + lines.length * 18, px = clamp(x, pw / 2 + 4, VW - pw / 2 - 4) - pw / 2, py = y + 34;
  ctx.fillStyle = 'rgba(8,10,18,.9)'; ctx.fillRect(px, py, pw, ph); ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.strokeRect(px, py, pw, ph);
  const cx = px + pw / 2;
  ctx.font = (ctx.measureText(name).width > 150 ? '800 14px' : '800 17px') + ' "Alegreya Sans", sans-serif'; ctx.fillStyle = col; ctx.fillText(name, cx, py + 19);
  ctx.font = '700 15px "Alegreya Sans", sans-serif'; ctx.fillStyle = '#fff';
  lines.forEach((l, i) => ctx.fillText(l, cx, py + 38 + i * 18));
  ctx.globalAlpha = 1;
}

// ---------- cards ----------
let cardCtx = null;
function cardOptions() {
  const pool = [], nextBossAir = BOSSES[BOSS_ORDER[(G.sector - 1) % BOSS_ORDER.length]].layer === 'air';
  for (const [id, c] of Object.entries(CARDS)) {
    if (L(id) >= c.max) continue;
    if (c.hurtOnly && P.hp >= P.maxHp) continue;
    let w = L(id) ? 1.3 : 1;
    if (id === 'repair') w = 1.6;
    if ((id === 'torpedo') && G.sector === 1 && L(id) === 0) w = 0.6;
    if (c.kind === (nextBossAir ? 'gun' : 'bomb')) w *= 1.5; // soft bias toward what the next boss can be hurt with
    pool.push({ id, w });
  }
  const out = [], kinds = new Set();
  while (out.length < 3 && pool.length) {
    // prefer a different weapon family for each slot so guns and bombs both get offered
    const fresh = pool.filter((p) => !kinds.has(CARDS[p.id].kind));
    let src = fresh.length && out.length < 2 ? fresh : pool;
    if (!out.length && (G.offers | 0) < 2) { const bp = pool.filter((p) => CARDS[p.id].kind === 'bomb'); if (bp.length) src = bp; } // first two offers always carry a bomb card
    let t = 0; for (const p of src) t += p.w; let r = rand() * t, chosen = src[0];
    for (const p of src) { r -= p.w; if (r <= 0) { chosen = p; break; } }
    pool.splice(pool.indexOf(chosen), 1); kinds.add(CARDS[chosen.id].kind);
    const c = CARDS[chosen.id];
    const epic = c.max - L(chosen.id) >= 2 && chosen.id !== 'repair' && rand() < 0.07 * (P.relics.has('clover') ? 3 : 1);
    out.push({ type: 'card', id: chosen.id, epic });
  }
  return out;
}
function relicOptions() {
  const ids = Object.keys(RELICS).filter((id) => !P.relics.has(id));
  const out = [];
  while (out.length < 3 && ids.length) out.push({ type: 'relic', id: ids.splice(Math.floor(rand() * ids.length), 1)[0] });
  while (out.length < 3) { const o = cardOptions()[out.length]; if (!o) break; o.epic = true; out.push(o); }
  return out;
}
function openCards(req) {
  const opts = req.kind === 'relic' ? relicOptions() : cardOptions();
  if (req.kind !== 'relic') G.offers++;
  if (!opts.length) { if (req.then) req.then(); return; }
  if (AUTO || FF) { applyCard(pick(opts)); if (req.then) req.then(); return; }
  G.paused = 'cards'; cardCtx = req;
  clearTimeout(cardHideT); $('cards').classList.remove('out');
  $('cardsTitle').textContent = req.title; $('cardsSub').textContent = req.sub || '';
  renderCards(opts, 450);
  $('cards').classList.remove('hidden'); sfx('pick');
}
// the build so far (owned upgrades with levels, relics); ids in `mark` are the ones the open cards would upgrade
function buildChips(mark = []) {
  const chip = (src, lv, cls) => `<span class="chip${cls}"><i class="ci" style="--img:${iconOf(src.icon)}"></i>${src.name}${lv ? ` <small>${lv}</small>` : ''}</span>`;
  const cards = Object.keys(P.lv).filter((id) => P.lv[id] && CARDS[id].max < 50).map((id) => chip(CARDS[id], P.lv[id], mark.includes(id) ? ' up' : ''));
  const relics = [...P.relics].map((id) => chip(RELICS[id], 0, ' rel'));
  return cards.concat(relics).join('');
}
// cards ignore taps and keys for a moment after they appear (a stray tap from flying can't pick one)
let cardLock = 0, cardHideT = 0, cardOpts = [];
function pickCardAt(i) { const o = cardOpts[i]; if (o && performance.now() >= cardLock && G.paused === 'cards') chooseCard(o); }
const adRerollOk = () => !!cardCtx && cardCtx.kind !== 'relic' && !cardCtx.adReroll && Ads.canReward(); // out of rerolls: one more per pick screen for a rewarded ad
let adBusy = false;
async function rerollCards() { if (G.paused !== 'cards' || performance.now() < cardLock || !cardCtx || cardCtx.kind === 'relic') return;
  if (P.rerolls <= 0) { if (!adRerollOk() || adBusy) return; adBusy = true; const ok = await Ads.rewarded('reroll'); adBusy = false; if (!ok || G.paused !== 'cards' || !cardCtx) return; cardCtx.adReroll = true; sfx('pick'); renderCards(cardOptions(), 250); return; }
  P.rerolls--; sfx('pick'); renderCards(cardOptions(), 250); }
function renderCards(opts, lockMs = 0) {
  const row = $('cardRow'); row.innerHTML = ''; cardOpts = opts;
  cardLock = performance.now() + lockMs; $('cards').classList.toggle('lock', lockMs > 0);
  if (lockMs) setTimeout(() => { if (performance.now() >= cardLock) $('cards').classList.remove('lock'); }, lockMs + 20);
  const bc = buildChips(opts.filter((o) => o.type === 'card').map((o) => o.id));
  $('cardBuild').innerHTML = bc ? '<h3>YOUR BUILD</h3><div class="chips">' + bc + '</div>' : '';
  opts.forEach((o, i) => {
    const el = document.createElement('div');
    if (o.type === 'relic') {
      const r = RELICS[o.id];
      el.className = 'card relic'; el.style.setProperty('--c', '#ffd34d');
      el.innerHTML = `<div class="ci" style="--img:${iconOf(r.icon)}"></div><div><span class="tag">RELIC · LEGENDARY</span><h3>${r.name}</h3><p>${r.text}</p></div><kbd class="kc">${i + 1}</kbd>`;
    } else {
      const c = CARDS[o.id], lv = L(o.id);
      el.className = 'card' + (o.epic ? ' epic' : ''); el.style.setProperty('--c', c.c);
      const fam = c.kind === 'gun' ? 'GUNS · AIR' : c.kind === 'bomb' ? 'BOMBS · SURFACE' : 'PLANE';
      const lvTxt = c.max > 50 ? '' : lv ? ` · LV ${lv} → ${Math.min(c.max, lv + (o.epic ? 2 : 1))}` : ' · NEW';
      el.innerHTML = `<div class="ci" style="--img:${iconOf(c.icon)}"></div><div><span class="tag">${o.epic ? 'EPIC +2 · ' : ''}${fam}${lvTxt}</span><h3>${c.name}</h3><p>${c.text(lv)}</p></div><kbd class="kc">${i + 1}</kbd>`;
    }
    el.style.animationDelay = i * 0.06 + 's'; el.tabIndex = 0;
    el.onclick = () => pickCardAt(i);
    el.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickCardAt(i); } };
    row.appendChild(el);
  });
  const rb = $('btnReroll');
  const viaAd = P.rerolls <= 0 && adRerollOk();
  rb.classList.toggle('hidden', cardCtx.kind === 'relic' || (P.rerolls <= 0 && !viaAd));
  rb.querySelector('b').textContent = viaAd ? '\u25b6 AD' : '\u00d7' + P.rerolls; rb.disabled = P.rerolls <= 0 && !viaAd;
}
function chooseCard(o) {
  applyCard(o); sfx('level');
  const cd = $('cards'); cd.classList.add('out'); clearTimeout(cardHideT); cardHideT = setTimeout(() => { cd.classList.add('hidden'); cd.classList.remove('out'); }, 170);
  G.paused = null; P.inv = Math.max(P.inv, 0.6);
  const then = cardCtx && cardCtx.then; cardCtx = null;
  if (then) then();
  last = performance.now();
}
function applyCard(o) {
  if (o.type === 'relic') {
    P.relics.add(o.id);
    if (o.id === 'clover') P.rerolls += 2;
    if (o.id === 'abyss' && G.boss && G.boss.dive) bossImmune(false);
    if (!FF) toast(RELICS[o.id].name.toUpperCase(), RELICS[o.id].text);
  } else {
    const c = CARDS[o.id], n = o.epic ? 2 : 1;
    for (let i = 0; i < n; i++) {
      if (L(o.id) >= c.max) break;
      P.lv[o.id] = L(o.id) + 1;
      if (o.id === 'armor') { P.maxHp++; P.hp++; }
      if (o.id === 'repair') P.hp = Math.min(P.maxHp, P.hp + 2);
      if (o.id === 'shield' && L('shield') === 1) P.shield = true;
    }
  }
  ST = stat(); hudDirty = true;
}

// ---------- game over / meta ----------
function gameOver() {
  if (G.state === 'over') return;
  G.state = 'over'; if (G.paused === 'cards') G.paused = null; G.log.push(['dead', G.sector, Math.round(G.t), P.lvl]);
  const km = kmFlown(); clearRun();
  commitCoins();
  meta.runs++; meta.kills += G.kills;
  const newBest = km > meta.best;
  meta.best = Math.max(meta.best, km); meta.bestSector = Math.max(meta.bestSector, G.sector); meta.bestLv = Math.max(meta.bestLv, P.lvl);
  G.newBest = newBest;
  saveMeta();
  if (!FF) showOver();
}
function showOver() {
  const km = kmFlown(), newBest = G.newBest;
  $('hud').classList.add('hidden');
  $('overTitle').textContent = 'SHOT DOWN';
  $('overStats').innerHTML = `<div class="sumgrid">
    <span>Distance</span><b>${km.toFixed(2)} km${newBest ? ' <span class="new">BEST!</span>' : ''}</b>
    <span>Best</span><b>${newBest ? 'new record' : meta.best.toFixed(2) + ' km (' + (km - meta.best).toFixed(2) + ')'}</b>
    <span>Sector</span><b>${G.sector} · ${segAt(cam + VH / 2).biome.name}</b>
    <span>Level</span><b>${P.lvl}</b>
    <span>Kills</span><b>${G.kills}</b>
    <span>Coins</span><b class="gold" id="overCoins">+${G.coins}</b></div>`;
  const bc = buildChips(); $('overBuild').innerHTML = bc ? '<h3>YOUR BUILD</h3><div class="chips">' + bc + '</div>' : '';
  const rv = $('btnRevive'); rv.classList.toggle('hidden', G.revived || !Ads.canReward());
  show('over'); $('over').scrollTop = 0; focusFirst('over');
}
function focusFirst(id) { if (matchMedia('(pointer: fine)').matches) { const b = $(id).querySelector('button.big:not(.hidden), button:not(.hidden)'); if (b) b.focus({ preventScroll: true }); } }
function commitCoins() { meta.coins += G.coins - G.committed; G.committed = G.coins; saveMeta(); }
async function revive() {
  if (G.revived) return;
  const ok = await Ads.rewarded('revive');
  if (!ok) return;
  G.revived = true; G.state = 'play'; G.dying = 0; G.slow = 1; meta.runs--; // the run goes on
  G.paused = null; G.hitStop = 0; input.down = false; input.pid = null; // a card pick that opened at the moment of death must not freeze the revived run
  P.hp = P.maxHp; P.inv = 3; eshots = []; hudDirty = true;
  for (const e of enemies) if (e.alive && !e.boss && e.y > 0) hurt(e, 1e9); // clear the screen
  show(null); $('hud').classList.remove('hidden');
  last = performance.now();
}

// ---------- ad hooks, notice, daily reward, free coins (ported from Runebound Depths) ----------
Ads.hooks.mute = (on) => { adMuted = on; if (master) master.gain.value = on || meta.mute ? 0 : 0.6; };
let noticeTO = 0;
function notice(text, sub = '') { const el = $('notice'); el.innerHTML = `<b>${text}</b>${sub ? `<small>${sub}</small>` : ''}`; el.classList.add('show'); clearTimeout(noticeTO); noticeTO = setTimeout(() => el.classList.remove('show'), 3600); }
Ads.hooks.notice = notice;
// Time: the Date header of our own file (plus Age: a CDN's copy can be hours old) is the "server clock"; the device clock is the
// fallback when the fetch fails, so winding the phone's clock forward can't skip a day. ?dday=N shifts the clock N days (tests).
let dailySkew = 0;
const DAY_MS = 86400000, DDAY = +params.get('dday') || 0;
const dailyNow = () => Date.now() + dailySkew + DDAY * DAY_MS;
fetch('index.html?t=' + Date.now(), { method: 'HEAD', cache: 'no-store' }).then((r) => {
  const d = Date.parse(r.headers.get('date'));
  if (d) { const a = d - Date.now(), b = a + (+r.headers.get('age') || 0) * 1000; dailySkew = Math.abs(b) < Math.abs(a) ? b : a; if (G.state === 'title') renderDailyBtn(); }
}).catch(() => {});
const localDay = () => { const t = dailyNow(); return Math.floor((t - new Date(t).getTimezoneOffset() * 60000) / DAY_MS); };
// 7-day track, one claim per local day. meta.dl = { n: claims so far, day: local day of the last claim }. A missed day costs nothing
// (Runebound's login track does not reset either); DL_RESET = true would send a gap of 2+ days back to day 1.
const DL_COINS = [100, 125, 150, 200, 250, 300, 500], DL_TOKENS = 2 /* free rerolls for the next run, day 7 */, DL_RESET = false;
const dlSt = () => {
  const d = meta.dl || { n: 0, day: -1 };
  return DL_RESET && d.day >= 0 && localDay() - d.day > 1 ? { n: 0, day: d.day } : d;
};
const dlClaimed = () => dlSt().day >= localDay(); // also true if the clock was wound back after a claim
const dlReady = () => !AUTO && !FFWD && (meta.runs >= 1 || params.has('daily')) && !dlClaimed(); // a new player sees it after the first flight
function dlInfo(n) { const rot = Math.floor(n / 7), i = n % 7; return { day: i + 1, coins: Math.round(DL_COINS[i] * (1 + 0.2 * Math.min(rot, 5)) / 5) * 5, tok: i === 6 ? DL_TOKENS : 0 }; }
const coinHtml = () => `<i class="ico coin" style="--img:${iconOf(['items', 0])}"></i>`;
function renderDailyBtn() {
  const b = $('btnDaily'); if (!b) return;
  const show = !AUTO && !FFWD && (meta.runs >= 1 || params.has('daily')); b.classList.toggle('hidden', !show); if (!show) return;
  const ready = !dlClaimed(), inf = dlInfo(dlSt().n);
  b.classList.toggle('ready', ready);
  b.innerHTML = `DAILY REWARD${ready ? '<i class="dot"></i>' : ''}<small>${ready ? `day ${inf.day} · +${inf.coins} coins` : 'claimed · come back tomorrow'}</small>`;
}
let dlBusy = false;
async function claimDaily(ad) {
  if (dlBusy || !dlReady()) return;
  dlBusy = true;
  try {
    if (ad && !(await Ads.rewarded('daily'))) return; // no ad, nothing lost: the popup stays
    if (!dlReady()) return;
    const L = dlSt(), inf = dlInfo(L.n), coins = inf.coins * (ad ? 2 : 1);
    meta.dl = { n: L.n + 1, day: localDay() }; meta.coins += coins; if (inf.tok) meta.rerollTok = (meta.rerollTok || 0) + inf.tok;
    saveMeta(); initAudio(); sfx('coin'); renderDailyBtn();
    dailyPop({ got: coins, x2: ad, tok: inf.tok });
  } finally { dlBusy = false; }
}
function dailyPop(res = null) {
  let el = $('dailyPop');
  if (!el) {
    el = document.createElement('div'); el.id = 'dailyPop'; el.className = 'ad-overlay'; $('app').appendChild(el);
    el.addEventListener('pointerdown', (e) => e.stopPropagation());
    el.addEventListener('click', (e) => { const b = e.target.closest('[data-dl]'); if (!b) return; const k = b.dataset.dl; if (k === 'free') claimDaily(false); else if (k === 'ad') claimDaily(true); else { el.classList.add('hidden'); if (G.state === 'title') renderDailyBtn(); } });
  }
  const L = dlSt(), claimed = dlClaimed(), cur = claimed ? L.n - 1 : L.n, idx = ((cur % 7) + 7) % 7, week = Math.floor(Math.max(0, cur) / 7) * 7;
  const tiles = Array.from({ length: 7 }, (_, i) => { const t = dlInfo(week + i), st = i < idx || (i === idx && claimed) ? 'done' : i === idx ? 'now' : '';
    return `<div class="dl-t ${st}${i === 6 ? ' last' : ''}"><small>DAY ${i + 1}</small>${coinHtml()}<b>${t.coins}</b>${t.tok ? `<em>+${t.tok} rerolls</em>` : ''}${st === 'done' ? '<u>&#10003;</u>' : ''}</div>`; }).join('');
  const nx = dlInfo(L.n), adOk = Ads.canReward(), inf = dlInfo(L.n);
  const head = res ? `<p class="dl-got">+${res.got} coins${res.x2 ? ' (x2)' : ''}${res.tok ? ` · +${res.tok} free rerolls next flight` : ''}</p>`
    : `<p>${claimed ? 'Claimed today.' : `Day ${inf.day} of 7${inf.tok ? ` · +${inf.tok} free rerolls next flight` : ''}`}</p>`;
  const tail = claimed ? `<p class="dl-nx">Tomorrow: day ${nx.day} · ${nx.coins} coins${nx.tok ? ` + ${nx.tok} rerolls` : ''}</p>` : '';
  const btns = claimed ? '' : `<button class="big" data-dl="free">CLAIM +${inf.coins}</button>${adOk ? `<button class="dl-ad" data-dl="ad">&#9654; CLAIM x2 <small>watch ad · +${inf.coins * 2}</small></button>` : ''}`;
  el.innerHTML = `<div class="ad-box dl-box"><b>DAILY REWARD</b>${head}<div class="dl-grid">${tiles}</div>${tail}<div class="menu">${btns}<button data-dl="close">${claimed ? 'OK' : 'LATER'}</button></div></div>`;
  el.classList.remove('hidden'); sfx('level');
}
// free coins in the hangar: a rewarded ad for +FC_COINS, FC_MAX a day (Runebound's free shards), plus the shared 60 s ad cooldown
const FC_COINS = 100, FC_MAX = 3;
const fcLeft = () => { const f = meta.fc; return f && f.day === localDay() ? Math.max(0, FC_MAX - f.n) : FC_MAX; };
function renderFreeCoins() {
  const row = $('freeRow'), show = Ads.canReward() && fcLeft() > 0; row.classList.toggle('hidden', !show);
  if (show) $('freeTxt').textContent = `Watch an ad for +${FC_COINS} coins · ${fcLeft()} left today`;
}
$('btnFree').onclick = async () => {
  if (dlBusy || fcLeft() <= 0 || !(await Ads.rewarded('free_coins'))) return;
  meta.fc = { day: localDay(), n: FC_MAX - fcLeft() + 1 }; meta.coins += FC_COINS; saveMeta(); sfx('coin'); openHangar();
};
$('btnDaily').onclick = () => { initAudio(); dailyPop(); };

// ---------- screens ----------
const SCREENS = ['title', 'over', 'hangar', 'pause'];
function show(id) { for (const s of SCREENS) $(s).classList.toggle('hidden', s !== id); }
function toTitle() {
  G.state = 'title'; P = null; show('title'); $('hud').classList.add('hidden'); $('cards').classList.add('hidden'); $('bossbar').classList.add('hidden');
  $('best').textContent = meta.best ? `BEST ${meta.best.toFixed(2)} km · SECTOR ${meta.bestSector}` : '';
  renderDailyBtn(); if (!G.dlAuto && dlReady()) { G.dlAuto = true; setTimeout(() => { if (G.state === 'title' && dlReady()) dailyPop(); }, 600); } // opens by itself once per visit
  const run = loadRun(), cb = $('btnContinue');
  cb.classList.toggle('hidden', !run); $('btnPlay').classList.toggle('big', !run); $('btnPlay').textContent = run ? 'NEW RUN' : 'PLAY';
  if (run) cb.innerHTML = `CONTINUE <small>sector ${run.sector} · LV ${run.lvl}</small>`;
}
let envReady = Promise.resolve();
async function play(save = null) {
  initAudio();
  const btn = $('btnPlay'), label = btn.textContent;
  btn.textContent = 'LOADING…'; await Promise.all([envReady, save && preloadEnv(save.sector), save && preloadEnv(save.sector + 1)]); btn.textContent = label;
  show(null); $('hud').classList.remove('hidden'); $('bossbar').classList.add('hidden');
  newGame(save);
  if (!save) saveRun();
  if (FFWD > 0) {
    FF = true;
    for (let i = 0; i < FFWD * 60 && G.state === 'play'; i++) step(1 / 60);
    FF = false; hudDirty = true;
    if (G.state === 'over') showOver();
  }
  last = performance.now();
}
function openHangar() {
  show('hangar');
  $('hCoins').textContent = meta.coins;
  renderFreeCoins();
  const sl = $('shipList'); sl.innerHTML = '';
  for (const [id, s] of Object.entries(SHIPS)) {
    const own = meta.ships[id], cur = meta.ship === id;
    const el = document.createElement('div'); el.className = 'ship' + (cur ? ' cur' : '');
    el.innerHTML = `<img src="${SPR[id] ? SPR[id].img.src : ''}" alt=""><b>${s.name}</b><p>${s.text}</p>`;
    const b = document.createElement('button');
    if (cur) { b.textContent = 'FLYING'; b.disabled = true; }
    else if (own) { b.textContent = 'SELECT'; b.onclick = () => { meta.ship = id; saveMeta(); openHangar(); }; }
    else { b.className = 'buy'; b.innerHTML = `<i class="ico" style="--img:${iconOf(['items', 0])}"></i>${s.cost}`; b.disabled = meta.coins < s.cost; b.onclick = () => { if (meta.coins < s.cost) return; meta.coins -= s.cost; meta.ships[id] = true; meta.ship = id; saveMeta(); sfx('coin'); openHangar(); }; }
    el.appendChild(b); sl.appendChild(el);
  }
  const ul = $('upgList'); ul.innerHTML = '';
  for (const u of HANGAR) {
    const lv = hl(u.id), maxed = lv >= u.max, cost = u.cost(lv);
    const el = document.createElement('div'); el.className = 'upg';
    el.innerHTML = `<div class="ci" style="--img:${iconOf(u.icon)}"></div><div class="ut"><h4>${u.name}</h4><p>${u.text}</p><div class="pips">${Array.from({ length: u.max }, (_, i) => `<i class="${i < lv ? 'on' : ''}"></i>`).join('')}</div></div>`;
    const b = document.createElement('button');
    if (maxed) { b.textContent = 'MAX'; b.disabled = true; }
    else { b.innerHTML = `<i class="ico" style="--img:${iconOf(['items', 0])}"></i>${cost}`; b.disabled = meta.coins < cost; b.onclick = () => { if (meta.coins < cost) return; meta.coins -= cost; meta.up[u.id] = lv + 1; saveMeta(); sfx('coin'); openHangar(); }; }
    el.appendChild(b); ul.appendChild(el);
  }
  $('records').innerHTML = `<span>Best distance</span><b>${meta.best.toFixed(2)} km</b><span>Best sector</span><b>${meta.bestSector}</b>
    <span>Best level</span><b>${meta.bestLv}</b><span>Flights</span><b>${meta.runs}</b><span>Total kills</span><b>${meta.kills}</b>`;
}
function openPause() {
  if (G.state !== 'play' || G.paused) return;
  G.paused = 'pause'; show('pause');
  const bc = buildChips(); $('confirm').classList.add('hidden');
  $('buildList').innerHTML = `<div class="plate sumgrid" style="padding:10px 14px;width:100%"><span>Level</span><b>${P.lvl}</b><span>Gun damage</span><b>${ST.gunDmg.toFixed(0)} × ${(ST.gunRate).toFixed(1)}/s</b>
    <span>Bomb damage</span><b>${ST.bombDmg.toFixed(0)} · ${1 + L('bay')} per drop</b><span>Hearts</span><b>${P.hp}/${P.maxHp}</b>
    <span>Sector</span><b>${G.sector}</b><span>Distance</span><b>${kmFlown().toFixed(2)} km</b><span>Kills</span><b>${G.kills}</b><span>Coins</span><b class="gold">+${G.coins}</b></div>
    ${bc ? '<h3>UPGRADES &amp; RELICS</h3><div class="chips">' + bc + '</div>' : ''}`;
  $('muteBtn').textContent = 'SOUND: ' + (meta.mute ? 'OFF' : 'ON'); focusFirst('pause');
}
function resume() { G.paused = null; show(null); last = performance.now(); }

// ---------- input ----------
cv.addEventListener('pointerdown', (e) => { if (input.down && input.pid != null) return; input.pid = e.pointerId; input.down = true; input.lx = e.clientX; input.ly = e.clientY; initAudio(); cv.setPointerCapture(e.pointerId); });
cv.addEventListener('pointermove', (e) => {
  if (input.pid != null && e.pointerId !== input.pid) return;
  if (!input.down || !P || G.state !== 'play' || G.paused || G.dying) { input.lx = e.clientX; input.ly = e.clientY; return; }
  const k = VW / app.clientWidth * 1.15; // relative drag, a little faster than the finger
  P.x += (e.clientX - input.lx) * k; P.y += (e.clientY - input.ly) * k;
  input.lx = e.clientX; input.ly = e.clientY;
});
const up = (e) => { if (e && input.pid != null && e.pointerId !== input.pid) return; input.down = false; input.pid = null; };
cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
addEventListener('keydown', (e) => { input.keys.add(e.key.length === 1 ? e.key.toLowerCase() : e.key); 
  if (G.paused === 'cards') { if (e.repeat) return; if (e.key >= '1' && e.key <= '3') pickCardAt(+e.key - 1); else if (e.key === 'r' || e.key === 'R') rerollCards(); return; }
  if (e.key === 'm' || e.key === 'M') { toggleMute(); return; }
  if (e.key === 'Escape' || e.key === 'p') { if (!$('confirm').classList.contains('hidden')) $('confirm').classList.add('hidden'); else if (G.paused === 'pause') resume(); else openPause(); } });
addEventListener('keyup', (e) => input.keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
addEventListener('blur', () => input.keys.clear());
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { openPause(); saveRun(); if (G.state === 'over') commitCoins(); if (AC) AC.suspend(); }
  else if (AC && AC.state !== 'running' && AC.state !== 'closed') AC.resume().catch(() => {});
});
addEventListener('pagehide', saveRun);
$('btnPlay').onclick = () => play();
$('btnContinue').onclick = () => { const r = loadRun(); if (r) play(r); else toTitle(); };
// leaving the game-over screen may show an interstitial (ads.js caps it at one per 2 minutes)
// (not after a new player's very first run; ads.js also keeps 60 s after a rewarded ad and 2 min between interstitials)
const afterOver = (fn) => async () => { if (G.state === 'over' && meta.runs > 1) await Ads.interstitial('gameover'); fn(); };
$('btnAgain').onclick = afterOver(() => play());
$('btnHangar').onclick = () => { initAudio(); openHangar(); };
$('btnHangar2').onclick = afterOver(openHangar);
$('btnHome').onclick = afterOver(toTitle);
$('btnRevive').onclick = revive;
$('pauseBtn').onclick = openPause;
$('btnResume').onclick = resume;
$('btnQuit').onclick = () => { $('confirm').classList.remove('hidden'); $('btnKeep').focus({ preventScroll: true }); }; // GIVE UP asks first
$('btnKeep').onclick = () => { $('confirm').classList.add('hidden'); $('btnResume').focus({ preventScroll: true }); };
$('btnGiveUp').onclick = () => { $('confirm').classList.add('hidden'); G.paused = null; show(null); G.dying = 0.01; G.slow = 1; P.hp = 0; G.revived = true; };
let adMuted = false; // set while an ad is up (ads.js hooks)
function toggleMute() { meta.mute = !meta.mute; saveMeta(); if (master) master.gain.value = meta.mute || adMuted ? 0 : 0.6; $('muteBtn').textContent = 'SOUND: ' + (meta.mute ? 'OFF' : 'ON'); }
$('muteBtn').onclick = toggleMute;
$('btnReroll').onclick = rerollCards;
for (const b of document.querySelectorAll('.back')) b.onclick = () => { if (G.state === 'over') show('over'); else toTitle(); };

// ---------- main loop ----------
let last = performance.now(), frames = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = clamp((now - last) / 1000, 0, 0.05); last = Math.max(last, now); frames++; // rAF time can predate a reset of last
  if (P && (G.state === 'play' || G.state === 'over') && !G.paused) {
    let k = G.dying ? G.slow : 1;
    if (G.hitStop > 0) { G.hitStop -= dt; k *= 0.12; } // a short freeze sells the hit
    if (G.state === 'play') step(dt * k);
    updateHud(dt);
  }
  render();
}
window.__g = { G, shiftWorld, spawn, get eshots() { return eshots; }, get camX() { return camX; }, get P() { return P; }, get enemies() { return enemies; }, meta, get frames() { return frames; }, step, render, fieldAt: (x, y) => field(x, y + cam), get segs() { return segs; }, get cam() { return cam; }, get counts() { return { parts: parts.length, eshots: eshots.length, pshots: pshots.length, chunks: chunks.size, booms: booms.length }; } };

(async function boot() {
  resize(); addEventListener('resize', resize);
  await loadSprites();
  try { envMan = await (await fetch('env/manifest.json', { cache: 'no-cache' })).json(); } catch (e) { /* procedural terrain only */ }
  // the island art keeps loading behind the title screen; only PLAY waits for it (a phone on the tunnel can be slow)
  envReady = Promise.all([preloadEnv(START_SECTOR), preloadEnv(START_SECTOR + 1)]);
  if (AUTO || FFWD) await envReady;
  if (SPR.title_bg) $('title').style.setProperty('--bg', 'url(sprites/title_bg.webp)');
  for (const el of document.querySelectorAll('.ico.coin')) el.style.setProperty('--img', iconOf(['items', 0]));
  $('wGun').querySelector('.ico').style.setProperty('--img', iconOf(['ic_gun', 0]));
  $('wBomb').querySelector('.ico').style.setProperty('--img', iconOf(['items', 5]));
  toTitle();
  $('fade').style.opacity = 0;
  requestAnimationFrame(frame);
  if (AUTO || FFWD) play();
})();
