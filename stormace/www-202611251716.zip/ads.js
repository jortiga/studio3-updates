// Ads behind one small API. In the Android build the wrapper defines window.CBAds (AdMob, like Runebound's RBAds);
// on the web a short TEST overlay stands in, so every placement can be tried in the browser.
// Rules (same as Runebound): a rewarded ad has a 60 s cooldown after a claim, an interstitial never comes within 60 s of
// a rewarded ad and at most one per 2 minutes, the game mutes its audio while any ad is up, and a failed rewarded ad
// shows a notice (an ad blocker is the usual cause) and gives nothing. A new placement is only a new label string.
const native = () => window.CBAds;
const REWARD_CD = 60000, INTER_MIN = 120000, INTER_AFTER_REWARD = 60000;
let lastInter = Date.now(); // the first interstitial can only come 2 minutes after launch
let lastReward = 0, readyAt = 0;
const FAIL = /[?&]adfail/.test(location.search); // test: every rewarded ad fails, to see the notice

function overlay(title, seconds) {
  return new Promise((resolve) => {
    if (FAIL) { resolve(false); return; }
    const el = document.createElement('div');
    el.className = 'ad-overlay';
    el.innerHTML = `<div class="ad-box"><b>${title}</b><p>Test ad · <span>${seconds}</span>s</p></div>`;
    document.getElementById('app').appendChild(el);
    let s = seconds;
    const t = setInterval(() => {
      s--; el.querySelector('span').textContent = s;
      if (s <= 0) { clearInterval(t); el.remove(); resolve(true); }
    }, 1000);
  });
}

export const Ads = {
  hooks: { notice() {}, mute() {} }, // main.js: notice(title, text) toast, mute(on) silences / restores the game audio
  canReward() { return native() ? native().canReward() : true; },
  cooldown() { return Math.max(0, Math.ceil((readyAt - Date.now()) / 1000)); }, // seconds until the next rewarded ad may play
  // resolves true when the reward was earned
  async rewarded(placement) {
    const wait = this.cooldown();
    if (wait > 0) { this.hooks.notice('AD COOLING DOWN', `Another ad is ready in ${wait} seconds.`); return false; }
    lastInter = Date.now(); // a rewarded ad also resets the interstitial timer
    let ok = false;
    this.hooks.mute(true);
    try { ok = native() ? !!(await native().rewarded(placement)) : await overlay('REWARDED AD', 3); } catch (e) { ok = false; }
    this.hooks.mute(false);
    if (ok) { lastReward = lastInter = Date.now(); readyAt = lastReward + REWARD_CD; }
    else this.hooks.notice('NO AD RIGHT NOW', 'No ad could be shown (an ad blocker can cause this). Nothing was lost. Try again later.');
    return ok;
  },
  // only at a natural break (after a game over): at most one every 2 minutes, never within 60 s of a rewarded ad
  async interstitial(placement) {
    const now = Date.now();
    if (now - lastInter < INTER_MIN || now - lastReward < INTER_AFTER_REWARD) return;
    lastInter = now;
    this.hooks.mute(true);
    if (native()) { try { await native().interstitial(placement); } catch (e) { /* ignore */ } }
    this.hooks.mute(false);
  },
};
