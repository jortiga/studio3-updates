window.CB_AD_IDS = {"interstitial": "ca-app-pub-5151387136918372/7542062522", "rewarded": "ca-app-pub-5151387136918372/6958986476", "testing": false, "testDevices": [], "ios": {"interstitial": "ca-app-pub-5151387136918372/4628250880", "rewarded": "ca-app-pub-5151387136918372/5645904804", "testing": false, "testDevices": []}};
window.CB_DEV = false;
window.S3A_ID = "G-CDSHVGGQPM";
