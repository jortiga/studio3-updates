// Storm Ace — game data: upgrade cards, relics, enemies, bosses, sectors, hangar.
// Guns hit AIR targets only. Bombs (and torpedoes) hit SURFACE targets only (tanks, flak, boats, subs).

// icon: [sheet, frame]
export const CARDS = {
  // ---- guns (air) ----
  twin:    { kind: 'gun', name: 'Twin Guns', max: 3, icon: ['ic_gun', 0], c: '#ffd34d', text: (l) => `+1 parallel bullet stream (${l + 1} total)` },
  spread:  { kind: 'gun', name: 'Spread Shot', max: 3, icon: ['ic_gun', 1], c: '#ffd34d', text: () => '+2 angled bullets' },
  rapid:   { kind: 'gun', name: 'Rapid Fire', max: 5, icon: ['ic_gun', 2], c: '#ffd34d', text: () => '+18% fire rate' },
  heavy:   { kind: 'gun', name: 'Heavy Rounds', max: 5, icon: ['ic_gun', 3], c: '#ffd34d', text: () => '+25% gun damage' },
  pierce:  { kind: 'gun', name: 'AP Rounds', max: 3, icon: ['ic_gun', 4], c: '#ffd34d', text: () => 'Bullets pierce +1 plane' },
  laser:   { kind: 'gun', name: 'Laser Lance', max: 5, icon: ['ic_gun', 4], c: '#6fd0ff', text: (l) => l ? 'Beam fires longer and burns hotter' : 'A piercing beam burns every plane in its path' },
  barrage: { kind: 'gun', name: 'Missile Barrage', max: 4, icon: ['ic_gun', 5], c: '#ff8a4d', text: (l) => l ? '+4 missiles per barrage, fires sooner' : 'Every 6s a swarm of 8 micro-missiles hunts planes AND ships' },
  railgun: { kind: 'gun', name: 'Railgun', max: 4, icon: ['ic_gun', 3], c: '#9ad8ff', text: (l) => l ? '+40% damage, charges faster' : 'Charges up, then one huge slug pierces everything in a line' },
  missile: { kind: 'gun', name: 'Homing Rockets', max: 5, icon: ['ic_gun', 5], c: '#ff8a4d', text: (l) => l ? '+1 rocket per volley, +15% damage' : 'Fire 2 homing rockets at planes' },
  // ---- bombs (surface) ----
  bay:     { kind: 'bomb', name: 'Bomb Bay', max: 4, icon: ['ic_bomb', 0], c: '#7fd0ff', text: () => '+1 bomb per drop' },
  boom:    { kind: 'bomb', name: 'Big Boom', max: 4, icon: ['ic_bomb', 1], c: '#7fd0ff', text: () => '+25% blast radius, +15% bomb damage' },
  quick:   { kind: 'bomb', name: 'Quick Release', max: 4, icon: ['ic_bomb', 2], c: '#7fd0ff', text: () => '-15% bomb cooldown' },
  napalm:  { kind: 'bomb', name: 'Napalm', max: 3, icon: ['ic_bomb', 3], c: '#ff8a4d', text: (l) => l ? 'Fire burns longer and hotter' : 'Bombs leave a burning patch' },
  cluster: { kind: 'bomb', name: 'Cluster Bombs', max: 3, icon: ['ic_bomb', 4], c: '#7fd0ff', text: (l) => `Blasts scatter ${3 + l * 2} bomblets` },
  torpedo: { kind: 'bomb', name: 'Torpedoes', max: 4, icon: ['ic_bomb', 5], c: '#4dd8c8', text: (l) => l ? 'Faster reload, +25% torpedo damage' : 'Torpedoes hunt ships and DIVING subs' },
  // ---- ship ----
  armor:   { kind: 'ship', name: 'Armor Plating', max: 3, icon: ['ic_ship', 0], c: '#ff7a9a', text: () => '+1 max heart and heal 1' },
  repair:  { kind: 'ship', name: 'Field Repair', max: 99, icon: ['ic_ship', 1], c: '#ff7a9a', text: () => 'Heal 2 hearts', hurtOnly: true },
  shield:  { kind: 'ship', name: 'Bubble Shield', max: 3, icon: ['ic_ship', 2], c: '#9ad8ff', text: (l) => l ? 'Shield recharges faster' : 'Blocks one hit, recharges in 16s' },
  magnet:  { kind: 'ship', name: 'Magnet', max: 3, icon: ['ic_ship', 3], c: '#c9a6ff', text: () => '+45% pickup range, +10% XP' },
  wingman: { kind: 'ship', name: 'Wingman', max: 2, icon: ['ic_ship', 4], c: '#ff9be0', text: () => '+1 escort drone that shoots planes' },
  bounty:  { kind: 'ship', name: 'Bounty', max: 3, icon: ['ic_ship', 5], c: '#ffd34d', text: () => '+25% coins' },
};

export const RELICS = {
  thunder: { name: 'Thunder Core', icon: ['ic_relic', 0], text: 'Chain lightning zaps up to 4 planes every second' },
  phoenix: { name: 'Phoenix Feather', icon: ['ic_relic', 1], text: 'Revive once with full hearts' },
  goldprop: { name: 'Golden Prop', icon: ['ic_relic', 2], text: '+50% coins and XP' },
  doom: { name: 'Doom Skull', icon: ['ic_relic', 3], text: '+30% damage with every weapon' },
  clover: { name: 'Lucky Clover', icon: ['ic_relic', 4], text: '+2 rerolls, epic cards show up 3x more' },
  abyss: { name: 'Abyss Charge', icon: ['ic_relic', 5], text: 'Bombs hit diving subs, +50% vs ships' },
};

// layer: 'air' (guns) | 'land' | 'sea' (bombs). hp at sector 1. r = hit radius. size = drawn length in world units.
export const ENEMIES = {
  drone:  { layer: 'air', hp: 18, r: 20, size: 54, xp: 1, coin: 0.25, score: 10 },
  jet:    { layer: 'air', hp: 26, r: 20, size: 58, xp: 1, coin: 0.3, score: 15 },
  copter: { layer: 'air', hp: 70, r: 28, size: 76, xp: 3, coin: 0.7, score: 40 },
  mine:   { layer: 'air', hp: 30, r: 18, size: 42, xp: 1, coin: 0.2, score: 10 },
  blimp:  { layer: 'air', hp: 210, r: 42, size: 110, xp: 6, coin: 3, score: 90 },
  bomberplane: { layer: 'air', hp: 420, r: 54, size: 150, xp: 12, coin: 6, score: 200, elite: true },
  tank:   { layer: 'land', hp: 50, r: 24, size: 62, xp: 2, coin: 0.5, score: 25 },
  flak:   { layer: 'land', hp: 60, r: 24, size: 58, xp: 2, coin: 0.5, score: 25 },
  sam:    { layer: 'land', hp: 70, r: 24, size: 64, xp: 3, coin: 0.6, score: 30 },
  boat:   { layer: 'sea', hp: 32, r: 24, size: 74, xp: 2, coin: 0.5, score: 25 },
  sub:    { layer: 'sea', hp: 70, r: 26, size: 92, xp: 4, coin: 1.2, score: 50 },
  destroyer: { layer: 'sea', hp: 380, r: 40, size: 150, xp: 12, coin: 6, score: 200, elite: true },
};

export const BOSSES = {
  b_fortress:   { name: 'SKY FORTRESS', layer: 'air', hp: 1500, r: 120, size: 320, terrain: 0 },
  b_battleship: { name: 'IRON LEVIATHAN', layer: 'sea', hp: 900, r: 110, size: 360, terrain: -1 },
  b_megatank:   { name: 'IRON BASTION', layer: 'land', hp: 950, r: 110, size: 300, terrain: 1 },
  b_kraken:     { name: 'DEEP KRAKEN', layer: 'sea', hp: 1000, r: 120, size: 330, terrain: -1, dives: true },
};
export const BOSS_ORDER = ['b_fortress', 'b_battleship', 'b_megatank', 'b_kraken'];

// Terrain palettes: dusk colors, dark like Runebound's dungeon so the lit sprites stand out. bias < 0 = more sea, > 0 = more land. freq = island size.
export const BIOMES = {
  tropic:  { name: 'CORAL BAY', bias: -0.16, freq: 1, deep: '#10283c', shallow: '#1b4a5a', sand: '#7d6c4c', grass: '#34502e', grass2: '#2a4228', line: '#07080c', decor: ['palm', 'palm', 'tree', 'hut', 'rock'] },
  coast:   { name: 'JADE COAST', bias: 0, freq: 0.8, coast: true, deep: '#0f2234', shallow: '#1a4152', sand: '#72644c', grass: '#30482b', grass2: '#253a24', line: '#07080c', decor: ['tree', 'tree', 'hut', 'hut', 'rock'] },
  desert:  { name: 'DUNE SEA', bias: 0.22, freq: 0.9, deep: '#122a36', shallow: '#204a54', sand: '#7e6040', grass: '#6c5034', grass2: '#5c432b', line: '#100a06', decor: ['rock', 'rock', 'palm', 'hut'] },
  arctic:  { name: 'FROST REACH', bias: -0.04, freq: 1.25, deep: '#111c30', shallow: '#233752', sand: '#7c8898', grass: '#6c7a8e', grass2: '#5c6a80', line: '#080b14', decor: ['pine', 'pine', 'rock'] },
  volcano: { name: 'EMBER ISLES', bias: -0.08, freq: 1.1, deep: '#0f0c16', shallow: '#211c2a', sand: '#3a2e2e', grass: '#282026', grass2: '#c8481e', line: '#040306', decor: ['rock', 'rock', 'pine'] },
};
export const BIOME_ORDER = ['tropic', 'coast', 'desert', 'arctic', 'volcano'];

export const SHIPS = {
  sparrow: { name: 'Sparrow', cost: 0, text: 'Balanced fighter. Good at everything.', hp: 3, rate: 1, bomb: 1, mods: [] },
  galleon: { name: 'Sky Galleon', cost: 1500, text: '+1 heart, starts with Bomb Bay. Slower guns.', hp: 4, rate: 0.85, bomb: 1.1, mods: ['bay'] },
  gyro:    { name: 'Gyro Hornet', cost: 2500, text: 'Starts with Homing Rockets and Rapid Fire. -1 heart.', hp: 2, rate: 1.1, bomb: 0.9, mods: ['missile', 'rapid'] },
};

// Hangar upgrades bought with coins between runs.
export const HANGAR = [
  { id: 'hull', name: 'Reinforced Hull', text: '+1 starting heart', max: 2, cost: (l) => 400 + l * 600, icon: ['ic_ship', 0] },
  { id: 'guns', name: 'Gunsmith', text: '+10% gun damage', max: 5, cost: (l) => 150 + l * 150, icon: ['ic_gun', 3] },
  { id: 'ord', name: 'Ordnance', text: '+10% bomb damage', max: 5, cost: (l) => 150 + l * 150, icon: ['ic_bomb', 1] },
  { id: 'mag', name: 'Tractor Beam', text: '+20% pickup range', max: 3, cost: (l) => 120 + l * 120, icon: ['ic_ship', 3] },
  { id: 'reroll', name: 'Flight Plan', text: '+1 card reroll per run', max: 3, cost: (l) => 250 + l * 250, icon: ['ic_relic', 4] },
  { id: 'bounty', name: 'War Chest', text: '+15% coins', max: 4, cost: (l) => 200 + l * 200, icon: ['ic_ship', 5] },
  { id: 'start', name: 'Head Start', text: 'Start each run with a free card pick', max: 2, cost: (l) => 500 + l * 700, icon: ['items', 3] },
];
