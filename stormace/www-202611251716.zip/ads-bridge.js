// Storm Ace ads bridge: AdMob (@capacitor-community/admob 7.2.0) exposed to the game as window.CBAds.
// game/ads.js uses window.CBAds when it exists, otherwise its own 3 s TEST overlay. The interface it calls:
//   CBAds.canReward()             -> boolean (sync): the game hides CONTINUE / x2 COINS until a rewarded ad has loaded
//   CBAds.rewarded(placement)     -> Promise<boolean>: true only when the player watched to the reward
//   CBAds.interstitial(placement) -> Promise: resolves when the ad closes (or at once if none is ready)
// Placements: 'revive', 'double'.
//
// Only runs inside the native app. In a browser CBAds is never defined and the game uses its TEST overlay.
// Inside the app CBAds is ALWAYS defined (even if AdMob fails), so the TEST overlay can never show to players.
//
// Rules (PUBLISHING.md / MOBILE_PERFORMANCE.md):
//  - AdMob is NOT started at app boot. It starts after the first run ends (the #over screen appears), or the first time
//    the game asks for an ad, so SDK start-up and ad loading never compete with gameplay.
//  - Order: initialize -> Google's UMP consent form (where required) -> Apple's tracking prompt (iOS only) -> preload.
//  - iOS uses the "ios" block of ad-ids.json. Our own phones get test ads via "testDevices" (the hash is per app).
//  - Interstitials are at least 2 minutes apart (a safety cap on top of the game's own 3-minute rule).
// Ad ids come from ad-ids.js (written by build_www.py); Google's public test ids fill anything missing.
(() => {
  const C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  const AdMob = C.Plugins && C.Plugins.AdMob;
  const all = window.CB_AD_IDS || {};
  const IDS = C.getPlatform() === 'ios'
    ? (all.ios || { interstitial: 'ca-app-pub-3940256099942544/4411468910', rewarded: 'ca-app-pub-3940256099942544/1712485313', testing: true })
    : all;
  const testing = !!IDS.testing;
  const MIN_GAP = 120000;
  let started = null, ready = false, iLoaded = false, rLoaded = false, iLoading = null, rLoading = null, lastI = 0;

  if (!AdMob) { // no plugin: the game runs without ads (and without the TEST overlay)
    window.CBAds = { canReward: () => false, rewarded: async () => false, interstitial: async () => {}, start: async () => {}, ready: false };
    return;
  }

  const once = (event) => new Promise(resolve => {
    let h; AdMob.addListener(event, v => { if (h) h.remove(); resolve(v); }).then(x => (h = x));
  });
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function prepI() {
    if (iLoaded || iLoading || !ready) return iLoading;
    iLoading = AdMob.prepareInterstitial({ adId: IDS.interstitial, isTesting: testing })
      .then(() => { iLoaded = true; }, () => { iLoaded = false; setTimeout(prepI, 30000); })
      .finally(() => { iLoading = null; });
    return iLoading;
  }
  function prepR() {
    if (rLoaded || rLoading || !ready) return rLoading;
    rLoading = AdMob.prepareRewardVideoAd({ adId: IDS.rewarded, isTesting: testing })
      .then(() => { rLoaded = true; }, () => { rLoaded = false; setTimeout(prepR, 30000); })
      .finally(() => { rLoading = null; });
    return rLoading;
  }

  function start() {
    if (started) return started;
    started = (async () => {
      try {
        await AdMob.initialize({ initializeForTesting: testing || !!(IDS.testDevices && IDS.testDevices.length), testingDevices: IDS.testDevices || [] });
        try {
          const info = await AdMob.requestConsentInfo();
          if (info.isConsentFormAvailable && info.status === 'REQUIRED') await AdMob.showConsentForm();
        } catch { /* consent service unreachable: ads fall back to non-personalised */ }
        // iOS: Apple's tracking prompt (ATT), after the consent form. Ads run either way; a "no" just means no IDFA.
        if (C.getPlatform() === 'ios') { try { await AdMob.requestTrackingAuthorization(); } catch { /* not available */ } }
        ready = true; prepR(); prepI();
      } catch { /* AdMob unavailable: the game runs without ads */ }
    })();
    return started;
  }
  // Wait (briefly) for an ad that is still loading. Returns whether it is loaded.
  async function waitFor(isLoaded, prep, ms) {
    await Promise.race([start(), sleep(ms)]);
    if (!ready) return false;
    if (!isLoaded()) { const p = prep(); if (p) await Promise.race([p, sleep(ms)]); }
    return isLoaded();
  }

  async function rewarded() {
    if (!(await waitFor(() => rLoaded, prepR, 6000))) return false;
    rLoaded = false;
    let got = false;
    const h = await AdMob.addListener('onRewardedVideoAdReward', () => { got = true; });
    const closed = Promise.race([once('onRewardedVideoAdDismissed'), once('onRewardedVideoAdFailedToShow')]);
    try { await AdMob.showRewardVideoAd(); await closed; } catch { /* failed to show */ }
    h.remove(); prepR();
    return got;
  }
  async function interstitial() {
    if (Date.now() - lastI < MIN_GAP) return;
    if (!ready || !iLoaded) { start().then(prepI); return; } // never make the player wait for an interstitial
    iLoaded = false; lastI = Date.now();
    const closed = Promise.race([once('interstitialAdDismissed'), once('interstitialAdFailedToShow')]);
    try { await AdMob.showInterstitial(); await closed; } catch { /* failed to show */ }
    prepI();
  }

  window.CBAds = { canReward: () => rLoaded, rewarded, interstitial, start, get ready() { return ready; } };

  // Start AdMob after the first run ends: the game shows the #over screen (main.js show('over')).
  const hook = () => {
    const over = document.getElementById('over');
    if (!over) return;
    const mo = new MutationObserver(() => { if (!over.classList.contains('hidden')) { mo.disconnect(); setTimeout(start, 1500); } });
    mo.observe(over, { attributes: true, attributeFilter: ['class'] });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hook); else hook();
})();
