window.RB_AD_IDS = {"interstitial": "ca-app-pub-5151387136918372/1781565429", "rewarded": "ca-app-pub-5151387136918372/5585079068", "testing": false, "testDevices": [], "ios": {"appId": "ca-app-pub-5151387136918372~7278338641", "interstitial": "ca-app-pub-5151387136918372/6754886629", "rewarded": "ca-app-pub-5151387136918372/4005434350", "testing": false, "testDevices": []}};
window.RB_DEV = false;
window.S3A_ID = "G-32N46ZL8ST";
