// Live game updates in the store app (Capgo updater plugin, self-hosted on GitHub; nothing goes to Capgo's servers).
// At launch: confirm this bundle works (else the plugin rolls back to the last good one), read <game>/latest.json from the
// public updates repo, and when it is newer than this bundle download it behind a small "Updating" overlay and switch to
// it right away (user: the update should appear when the app launches). A slow or failed download never blocks the game:
// after 25 s the overlay goes and the bundle is applied on the next background/restart instead.
// The last step and any error are kept in localStorage 'rb_upd' and shown next to the build stamp in the pause menu.
// Publish with tools/publish_update.py <app folder>. The same file works in every game's app.
(() => {
  const C = window.Capacitor, U = C && C.Plugins && C.Plugins.CapacitorUpdater;
  if (!U || !(C.isNativePlatform && C.isNativePlatform())) return;
  U.notifyAppReady().catch(() => {});
  const REPO = 'https://raw.githubusercontent.com/jortiga/studio3-updates/main/'; // one public repo, a folder per game: <app>/latest.json
  const note = (s) => { try { localStorage.setItem('rb_upd', s + ' @' + new Date().toISOString().slice(5, 16).replace('T', ' ')); } catch (e) { /* no storage */ } };
  const nums = (v) => String(v || '0').split('.').map((n) => parseInt(n, 10) || 0);
  const atLeast = (a, b) => { a = nums(a); b = nums(b); for (let i = 0; i < 3; i++) if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) > (b[i] || 0); return true; };

  // pause menu: "build <stamp> · <last update step>"
  addEventListener('DOMContentLoaded', () => fetch('bundle.json').then((r) => r.json()).then((B) => {
    const p = document.getElementById('pause'); if (!p || !B.stamp) return;
    const d = document.createElement('div');
    d.style.cssText = 'font-size:11px;opacity:0.45;text-align:center;margin:10px 0 4px;letter-spacing:0.05em';
    const show = () => { let s = ''; try { s = localStorage.getItem('rb_upd') || ''; } catch (e) { /* none */ } d.textContent = 'build ' + B.stamp + (s ? ' · ' + s : ''); };
    show(); new MutationObserver(show).observe(p, { attributes: true, attributeFilter: ['class'] }); p.appendChild(d);
  }).catch(() => {}));

  let veil = null;
  const showVeil = (txt) => {
    if (!veil) {
      veil = document.createElement('div');
      veil.style.cssText = 'position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:#05070dcc;color:#e9dcff;font:600 16px system-ui,sans-serif;letter-spacing:0.08em';
      (document.body || document.documentElement).appendChild(veil);
    }
    veil.textContent = txt;
  };
  const hideVeil = () => { if (veil) veil.remove(); veil = null; };

  (async () => {
    try {
      note('checking');
      const B = await (await fetch('bundle.json', { cache: 'no-store' })).json(), mine = B.stamp; // written by the app's build_www.py
      if (!B.app) return note('no app name');
      const r = await fetch(REPO + B.app + '/latest.json?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) return note('feed ' + r.status);
      const L = await r.json();
      if (!L.url || !L.sha256 || !(+L.stamp > +mine)) return note('up to date (' + L.stamp + ')');
      const nat = (await U.getBuiltinVersion()).version;
      if (L.minNative && !atLeast(nat, L.minNative)) return note('needs app ' + L.minNative + ' (have ' + nat + ')');
      const have = ((await U.list()).bundles || []).find((b) => b.version === String(L.stamp) && b.status !== 'error');
      let b = have, late = false;
      const timer = setTimeout(() => { late = true; hideVeil(); }, 45000); // a slow download keeps going in the background
      if (!b) {
        showVeil('UPDATING…');
        const prog = U.addListener ? await U.addListener('download', (e) => { if (!late && e && e.percent != null) showVeil('UPDATING… ' + Math.round(e.percent) + '%'); }) : null;
        note('downloading ' + L.stamp);
        try { b = await U.download({ url: L.url, version: String(L.stamp), checksum: L.sha256 || '' }); /* the plugin requires the zip's SHA-256 */ } finally { if (prog && prog.remove) prog.remove(); }
      }
      clearTimeout(timer);
      if (!late) { note('installing ' + L.stamp); showVeil('UPDATING…'); await U.set({ id: b.id }); return; } // reloads into the new bundle
      await U.next({ id: b.id }); note('ready ' + L.stamp + ' (next start)');
    } catch (e) { hideVeil(); note('error: ' + String((e && e.message) || e).replace(/https?:\/\/\S+/g, '').slice(0, 160)); }
  })();
})();
