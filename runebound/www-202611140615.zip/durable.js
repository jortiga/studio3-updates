// Durable saves: every localStorage save is mirrored into a second store, and on boot restore() puts back any save
// that localStorage lost.
// - App build: native storage (@capacitor/preferences), because iOS WKWebView can lose the last localStorage writes when
//   iOS kills a backgrounded app.
// - Portal build: the portal's cloud save, when its shim sets window.__portalStore = { ready, get, set, remove }
//   (CrazyGames: SDK.data, synced across devices for logged-in players). ready resolves false if the store is off.
// - Plain web / itch build: neither exists and all of this is a no-op.
// Saves carry a timestamp `t`, so an older copy never overwrites a newer localStorage one, and the caller can pass a
// rank (progress) so a fresh default save never beats real progress whatever its `t`.
// Nothing is mirrored until restore() has compared the two stores: a game that boots on an empty localStorage (new
// device, cleared or partitioned storage, cloud slower than the boot wait) writes a default save with a brand-new `t`
// at once, and mirroring that blindly used to overwrite the player's real cloud save (CrazyGames, Nov 2026).
const prefs = () => { const C = window.Capacitor; return (C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.Preferences) || null; };
const portal = () => window.__portalStore || null;
const parse = (s) => { try { return s ? JSON.parse(s) : null; } catch (e) { return null; } };
const tOf = (s) => { const o = parse(s); return (o && o.t) || 0; };
const lsGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };

let checked = false; // restore() compared localStorage with the store; until then mirror() only queues
let locked = false; // a store copy went into localStorage and the page reloads: no more saves from this page
const held = new Set(); // keys whose store copy beats localStorage but couldn't be applied: never overwritten this session
const pending = new Map(); // mirrors queued before the check (latest value per key)
export const saveLocked = () => locked;
// the caller didn't reload after all: saves go on, but the restored keys never overwrite the store from this page
export function unlock() { if (!locked) return; locked = false; for (const k of lastApplied) held.add(k); }
let lastApplied = [];

// both stores behind one async get/set/remove; null when there is no second store
function store() {
  const p = prefs();
  if (p) return { get: async (key) => (await p.get({ key })).value, set: (key, value) => p.set({ key, value }), remove: (key) => p.remove({ key }) };
  const s = portal();
  if (s) return { get: async (key) => ((await s.ready) ? s.get(key) : null), set: (key, value) => s.ready.then((ok) => ok && s.set(key, value)), remove: (key) => s.ready.then((ok) => ok && s.remove(key)) };
  return null;
}

// fire and forget: value null removes the key
export function mirror(key, value) {
  if (locked || held.has(key)) return;
  const s = store(); if (!s) return;
  if (!checked) { pending.set(key, value); return; }
  try { Promise.resolve(value == null ? s.remove(key) : s.set(key, value)).catch(() => { /* second store unavailable */ }); } catch (e) { /* ignore */ }
}

// keep the store copy? More progress (rank) first, then the newer `t`.
function storeWins(key, nv, lv, rank) {
  if (!nv) return false;
  if (!lv) return true;
  const rn = rank ? +rank(key, parse(nv)) || 0 : 0, rl = rank ? +rank(key, parse(lv)) || 0 : 0;
  return rn !== rl ? rn > rl : tOf(nv) > tOf(lv);
}

// Compares every key, puts the winning store copies into localStorage, then releases the mirror queue. Resolves true
// when localStorage changed (the page is then save-locked until the caller reloads).
async function merge(s, keys, runKey, endKey, opts, late) {
  let changed = false; lastApplied = [];
  try {
    const end = +((await s.get(endKey)) || 0);
    const wins = [];
    for (const key of keys) {
      const nv = await s.get(key), lv = lsGet(key);
      if (storeWins(key, nv, lv, opts.rank)) wins.push([key, nv]);
      else if (lv && !nv && key === runKey && end > tOf(lv)) wins.push([key, null]); // the run ended after this save
    }
    // found late (the game already runs on its local saves): apply only if the caller can reload right away
    if (wins.length && late && !(opts.late && opts.late(wins.map((w) => w[0])))) { for (const [k] of wins) held.add(k); wins.length = 0; }
    for (const [k, v] of wins) {
      try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { /* storage full or blocked */ }
      if (lsGet(k) === v) { changed = true; lastApplied.push(k); } else held.add(k); // couldn't apply: at least never overwrite the store copy
    }
  } catch (e) { /* store unreadable: localStorage alone */ }
  if (changed) locked = true;
  checked = true;
  if (!locked) { // localStorage is the newer/better copy: seed the store with it, then the saves queued meanwhile
    for (const key of keys) { const lv = lsGet(key); if (lv && !held.has(key)) { pending.delete(key); try { if (lv !== (await s.get(key))) mirror(key, lv); } catch (e) { /* ignore */ } } }
    for (const [k, v] of pending) mirror(k, v);
  }
  pending.clear();
  if (opts.debug) console.log('[durable] restore', late ? '(late)' : '', { changed, applied: lastApplied, held: [...held] });
  return changed;
}

// Copies a better stored save into localStorage (and seeds the store from saves made before it existed).
// endKey holds when the run save was last cleared, so a run that ended (shards paid) can't come back from a stale
// localStorage copy. Resolves true when localStorage changed: the caller reloads so every module reads the restored saves.
// opts.rank(key, obj): progress of a save (a fresh default save ranks lowest). opts.late(keys): the cloud answered after
// the boot wait and has better saves; return true to have them applied (the caller then reloads), false to keep playing
// (the store copies are then left alone).
export async function restore(keys, runKey, endKey, opts = {}) {
  const s = store(); if (!s) { checked = true; pending.clear(); return false; }
  const p = portal();
  if (!prefs() && p) {
    const ok = await Promise.race([Promise.resolve(p.ready).catch(() => false), new Promise((r) => setTimeout(() => r('slow'), opts.wait || 4000))]);
    if (ok === 'slow') { // boot on local saves now; compare once the cloud answers. Mirrors stay queued until then.
      Promise.resolve(p.ready).catch(() => false).then((ok2) => (ok2 ? merge(s, keys, runKey, endKey, opts, true) : (checked = true, pending.clear()))).catch(() => {});
      return false;
    }
    if (!ok) { checked = true; pending.clear(); return false; } // cloud save off: localStorage alone
  }
  return merge(s, keys, runKey, endKey, opts, false);
}
