// Runebound Depths ads bridge: makes the game's Monet layer (game/monet.js) work with @capacitor-community/admob 7.2.0.
// Only runs inside the Android app. In a browser it does nothing and Monet shows its own TEST overlay.
//
// monet.js calls Capacitor.Plugins.AdMob.showRewardVideoAd() / .showInterstitial() directly, without preparing an ad
// first. This file swaps Capacitor.Plugins.AdMob for a thin wrapper whose two show calls do prepare + show and resolve
// the way Monet expects (rewarded -> true only when the reward was earned). Every other AdMob call passes through.
//
// Rules (PUBLISHING.md / MOBILE_PERFORMANCE.md):
//  - AdMob is NOT started at app boot. It starts after the first run ends (the #over screen appears), or the first
//    time the game asks for an ad, so SDK start-up and ad loading never compete with gameplay.
//  - Our own phones get Google's test ads: ad-ids.json "testDevices" (the hash is per app; read it from logcat).
//  - Interstitials are at least 2 minutes apart (a safety cap; the game decides when to ask).
// Ad unit IDs come from ad-ids.js (written by build_www.py); Google's public test IDs until real ones are set.
//
// Purchases go through Google Play Billing (cordova-plugin-purchase), wired up in game/monet.js (off on iOS while
// monet.js IOS_IAP is false).
(() => {
  const C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform() || !C.Plugins || !C.Plugins.AdMob) return;
  const AdMob = C.Plugins.AdMob;            // the real plugin
  // iOS uses its own AdMob app and units (ad-ids.json "ios"); Google's iOS test units if none are set.
  const IDS = C.getPlatform() === 'ios' ? (window.RB_AD_IDS.ios || { interstitial: 'ca-app-pub-3940256099942544/4411468910', rewarded: 'ca-app-pub-3940256099942544/1712485313', banner: 'ca-app-pub-3940256099942544/2934735716', testing: true }) : window.RB_AD_IDS;
  const testing = !!IDS.testing;
  const MIN_GAP = 120000;                  // ms between interstitials
  let started = null, ready = false, iLoaded = false, rLoaded = false, iLoading = null, rLoading = null, lastI = 0;

  const once = (event) => new Promise(resolve => {
    let h; AdMob.addListener(event, v => { h?.remove(); resolve(v); }).then(x => (h = x));
  });
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function prepI() {
    if (iLoaded || iLoading || !ready) return iLoading;
    iLoading = AdMob.prepareInterstitial({ adId: IDS.interstitial, isTesting: testing })
      .then(() => { iLoaded = true; }, () => { iLoaded = false; setTimeout(prepI, 30000); })
      .finally(() => { iLoading = null; });
    return iLoading;
  }
  function prepR() {
    if (rLoaded || rLoading || !ready) return rLoading;
    rLoading = AdMob.prepareRewardVideoAd({ adId: IDS.rewarded, isTesting: testing })
      .then(() => { rLoaded = true; }, () => { rLoaded = false; setTimeout(prepR, 30000); })
      .finally(() => { rLoading = null; });
    return rLoading;
  }

  // Start the SDK once: initialize (with our test devices), Google's UMP consent form where required, then preload.
  function start() {
    if (started) return started;
    started = (async () => {
      try {
        await AdMob.initialize({ initializeForTesting: testing || !!IDS.testDevices?.length, testingDevices: IDS.testDevices || [] });
        try {
          const info = await AdMob.requestConsentInfo();
          if (info.isConsentFormAvailable && info.status === 'REQUIRED') await AdMob.showConsentForm();
        } catch { /* consent service unreachable: ads fall back to non-personalised */ }
        // iOS: Apple's tracking prompt (ATT), after the consent form. Ads run either way; a "no" just means no IDFA.
        if (C.getPlatform() === 'ios') { try { await AdMob.requestTrackingAuthorization(); } catch { /* not available */ } }
        ready = true; prepR(); prepI();
      } catch { /* AdMob unavailable: the game runs without ads */ }
    })();
    return started;
  }
  // Wait (briefly) for an ad that is still loading. Returns whether it is loaded.
  async function waitFor(isLoaded, prep, ms) {
    await Promise.race([start(), sleep(ms)]);
    if (!ready) return false;
    if (!isLoaded()) { const p = prep(); if (p) await Promise.race([p, sleep(ms)]); }
    return isLoaded();
  }

  // Monet.rewarded(placement): resolves true only if the player watched to the reward.
  async function showRewarded() {
    if (!(await waitFor(() => rLoaded, prepR, 6000))) return false;
    rLoaded = false;
    let rewarded = false;
    const h = await AdMob.addListener('onRewardedVideoAdReward', () => { rewarded = true; });
    const closed = Promise.race([once('onRewardedVideoAdDismissed'), once('onRewardedVideoAdFailedToShow')]);
    try { await AdMob.showRewardVideoAd(); await closed; } catch { /* failed to show */ }
    h.remove(); prepR();
    return rewarded;
  }
  // Monet.interstitial(placement): resolves when the ad closes, or at once if none is ready / too soon.
  async function showInterstitial() {
    if (Date.now() - lastI < MIN_GAP) return;
    if (!ready || !iLoaded) { start().then(prepI); return; }   // never make the player wait for an interstitial
    iLoaded = false; lastI = Date.now();
    const closed = Promise.race([once('interstitialAdDismissed'), once('interstitialAdFailedToShow')]);
    try { await AdMob.showInterstitial(); await closed; } catch { /* failed to show */ }
    prepI();
  }

  // The wrapper Monet sees as Capacitor.Plugins.AdMob.
  const wrapper = new Proxy(AdMob, {
    get(t, p) {
      if (p === 'showRewardVideoAd') return showRewarded;
      if (p === 'showInterstitial') return showInterstitial;
      const v = Reflect.get(t, p);
      return typeof v === 'function' ? v.bind(t) : v;
    },
  });
  try { C.Plugins.AdMob = wrapper; } catch { /* read-only */ }
  if (C.Plugins.AdMob !== wrapper) { try { Object.defineProperty(C.Plugins, 'AdMob', { value: wrapper, configurable: true, writable: true }); } catch { /* keep the real one */ } }

  // For the game (optional): window.RBAds.canReward() lets it hide a "watch an ad" button until one has loaded.
  window.RBAds = { start, canReward: () => rLoaded, canInterstitial: () => iLoaded, get ready() { return ready; }, wrapped: C.Plugins.AdMob === wrapper };

  // Start AdMob after the first run ends: the game shows the #over screen (main.js showScreen('over')).
  const hook = () => {
    const over = document.getElementById('over');
    if (!over) return;
    const mo = new MutationObserver(() => { if (!over.classList.contains('hidden')) { mo.disconnect(); setTimeout(start, 1500); } });
    mo.observe(over, { attributes: true, attributeFilter: ['class'] });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hook); else hook();
})();
