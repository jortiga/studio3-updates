// Runebound Depths - spell, element, gear and hero data (pure data + small helpers, no rendering).
// Spells: 24 signature spells (3 per element, SIGNATURE), fusions (element pair x base shape), boss spells, legendaries, uniques.

export const ELEMENT_ORDER = ['arcane', 'fire', 'frost', 'storm', 'venom', 'shadow', 'holy', 'earth'];
export const ELEMENTS = {
  // info = the element's signature mechanic, in plain words (shown on every spell card; main.js elementOnHit / killEnemy run it)
  arcane: { name: 'Arcane', adj: 'Arcane', color: '#ff5fd8', icon: 0, dmg: 1.0, cd: 1.0, info: '+20% crit chance' },
  fire: { name: 'Fire', adj: 'Ember', color: '#ff7a1a', icon: 1, dmg: 1.1, cd: 1.0, info: 'Burns and leaves burning ground' },
  frost: { name: 'Frost', adj: 'Frost', color: '#8fe6ff', icon: 2, dmg: 0.9, cd: 1.0, info: 'Slows; 3 hits FREEZE; hit a frozen foe to SHATTER it' },
  storm: { name: 'Storm', adj: 'Storm', color: '#fff36a', icon: 3, dmg: 1.0, cd: 0.9, info: 'Every hit arcs to 2 nearby foes' },
  venom: { name: 'Venom', adj: 'Venom', color: '#7dff6a', icon: 4, dmg: 0.8, cd: 1.0, info: 'Poison stacks; poisoned foes die into a toxic puddle' },
  shadow: { name: 'Shadow', adj: 'Shadow', color: '#a35cff', icon: 5, dmg: 1.0, cd: 1.0, info: 'Curses: cursed foes EXPLODE on death' },
  holy: { name: 'Holy', adj: 'Holy', color: '#ffe9a0', icon: 6, dmg: 1.0, cd: 1.0, info: 'Heals ½ heart every 10 kills; x2 damage to undead' },
  earth: { name: 'Earth', adj: 'Stone', color: '#c8925a', icon: 7, dmg: 1.25, cd: 1.2, info: 'Big knockback and a short STUN' },
};
// you start with these; the rest are unlocked by killing bosses
export const START_ELEMENTS = ['arcane', 'fire', 'frost'];

const FUSION_NAMES = {
  'arcane+fire': 'Phoenix', 'arcane+frost': 'Crystal', 'arcane+storm': 'Ether', 'arcane+venom': 'Hex', 'arcane+shadow': 'Abyss', 'arcane+holy': 'Seraph', 'arcane+earth': 'Geode',
  'fire+frost': 'Steam', 'fire+storm': 'Plasma', 'fire+venom': 'Napalm', 'fire+shadow': 'Hellfire', 'fire+holy': 'Solar', 'fire+earth': 'Magma',
  'frost+storm': 'Blizzard', 'frost+venom': 'Rime', 'frost+shadow': 'Nightfrost', 'frost+holy': 'Aurora', 'frost+earth': 'Glacier',
  'storm+venom': 'Acid', 'storm+shadow': 'Doom', 'storm+holy': 'Judgment', 'storm+earth': 'Tempest',
  'venom+shadow': 'Plague', 'venom+holy': 'Thorn', 'venom+earth': 'Spore',
  'shadow+holy': 'Twilight', 'shadow+earth': 'Grave',
  'holy+earth': 'Titan',
};
export const elKey = (els) => [...els].sort((a, b) => ELEMENT_ORDER.indexOf(a) - ELEMENT_ORDER.indexOf(b)).join('+');

// beh = runtime behaviour; vis = projectile look. Numbers are level-1 values, tuned to roughly equal single-target DPS.
export const SHAPES = {
  bolt: { name: 'Bolt', tier: 0, beh: 'proj', vis: 'bolt', cd: 0.6, dmg: 10, speed: 13, homing: 9, count: 1, life: 1.1, size: 0.85, r: 0.28, range: 9, info: 'Homing shots at the nearest foe' },
  lance: { name: 'Lance', tier: 0, beh: 'proj', vis: 'lance', cd: 1.2, dmg: 18, speed: 24, pierce: 5, count: 1, life: 0.7, size: 1, r: 0.3, range: 10, info: 'A fast lance that pierces a line of foes' },
  orb: { name: 'Orb', tier: 0, beh: 'proj', vis: 'fire', cd: 2.6, dmg: 24, speed: 8.5, aoe: 1.8, count: 1, life: 1.6, size: 1.4, r: 0.32, range: 9, info: 'A slow orb that bursts in an area' },
  nova: { name: 'Nova', tier: 1, beh: 'nova', cd: 4.0, dmg: 16, radius: 3.0, range: 3.4, info: 'A blast all around you' },
  chain: { name: 'Chain', tier: 1, beh: 'chain', cd: 3.0, dmg: 14, jumps: 3, range: 8, info: 'Arcs between nearby foes' },
  halo: { name: 'Halo', tier: 2, beh: 'orbit', cd: 7, dmg: 8, count: 3, dur: 5, radius: 1.6, range: 7, info: 'Orbs circle you and shred what they touch' },
  fan: { name: 'Fan', tier: 0, beh: 'proj', vis: 'venom', cd: 2.0, dmg: 6, speed: 11, count: 5, spread: 0.8, life: 0.6, size: 0.55, r: 0.2, range: 6.5, info: 'A spread of darts', offer: false },
  rain: { name: 'Rain', tier: 2, beh: 'rain', cd: 6.5, dmg: 30, count: 5, aoe: 1.5, range: 10, info: 'Strikes fall from above onto your foes' },
  burst: { name: 'Burst', tier: 0, beh: 'radial', vis: 'venom', cd: 3.4, dmg: 8, count: 12, speed: 9, life: 0.8, size: 0.6, r: 0.22, range: 5, info: 'A ring of shots in every direction', offer: false },
  field: { name: 'Field', tier: 1, beh: 'zone', cd: 5, dmg: 6, radius: 1.8, dur: 3.5, range: 8, info: 'A lingering field under your foes' },
  glaive: { name: 'Glaive', tier: 1, beh: 'proj', vis: 'glaive', cd: 2.4, dmg: 13, speed: 12, boomerang: true, count: 1, life: 1.7, size: 0.9, r: 0.34, pierce: 99, range: 7, info: 'Flies out and comes back, cutting everything' },
  sigil: { name: 'Sigil', tier: 1, beh: 'mine', cd: 2.2, dmg: 32, aoe: 1.7, range: 6, info: 'A rune trap at your feet that bursts on contact' },
  ray: { name: 'Ray', tier: 2, beh: 'beam', cd: 4.5, dmg: 4, dur: 1.4, range: 7, info: 'A beam that locks onto a foe' },
  wisp: { name: 'Wisp', tier: 2, beh: 'summon', cd: 10, dmg: 7, dur: 8, count: 1, range: 8, info: 'A familiar that fights beside you', offer: false },
};
export const SHAPE_ORDER = Object.keys(SHAPES);
// shapes that still come up as new spells. Fan, Burst and Wisp played like Bolt/Nova (a spray of shots at the nearest foe,
// a ring around you, a bolt turret); their ids still load from saves, fuse and show in the codex, they just aren't offered.
export const OFFER_SHAPES = SHAPE_ORDER.filter((s) => SHAPES[s].offer !== false);
// rarity: strong shapes are rare finds; a fusion is one tier above its shape
export const SPELL_TIERS = [{ name: 'COMMON', color: '#d8d8e0', w: 3 }, { name: 'RARE', color: '#5fb4ff', w: 1.3 }, { name: 'EPIC', color: '#c07aff', w: 0.45 }, { name: 'LEGENDARY', color: '#ffa040', w: 0.15 }];
export function spellTier(def) {
  if (!def) return 0;
  if (def.legendary) return 3;
  if (def.bossSpell || def.unique) return 2;
  if (def.sig) return def.tier;
  return Math.min(3, (def.sh.tier || 0) + (def.fused ? 1 : 0));
}

const NAME_OVERRIDES = {
  'arcane.bolt': 'Arcane Bolt', 'fire.orb': 'Fireball', 'frost.nova': 'Frost Nova', 'storm.chain': 'Chain Lightning', 'arcane.halo': 'Arcane Orbs',
  'venom.fan': 'Venom Fan', 'fire.rain': 'Meteor Shower', 'holy.ray': 'Sunbeam', 'shadow.wisp': 'Shade', 'earth.rain': 'Rockslide', 'frost.lance': 'Icicle',
  'storm.ray': 'Arc Beam', 'fire.field': 'Firewall', 'venom.field': 'Toxic Pool', 'holy.nova': 'Divine Light', 'shadow.orb': 'Void Sphere', 'earth.glaive': 'Stone Disc',
};

// boss spells: dropped by bosses, unlocked forever once seen; they are their bosses' own attacks
export const BOSS_SPELLS = {
  'boss.gloop': { name: 'Gloop Slam', boss: 'boss', els: ['venom'], beh: 'gloop', cd: 5, dmg: 30, range: 8, info: 'Leap-slam shockwave and a ring of slime', unlocks: 'venom' },
  'boss.bones': { name: 'Bone Boomerang', boss: 'tyrant', els: ['shadow'], beh: 'bones', cd: 4.5, dmg: 22, range: 8, info: 'A giant bone loops around you and comes back, piercing every foe twice. Lv 3: a second bone the other way. Lv 5: bigger and faster', unlocks: 'shadow' },
  'boss.gaze': { name: 'Hollow Gaze', boss: 'eyeboss', els: ['storm'], beh: 'gaze', cd: 7, dmg: 7, range: 9, info: 'A sweeping laser that cuts the whole room', unlocks: 'storm' },
  'boss.spores': { name: 'Spore Storm', boss: 'sporeboss', els: ['venom'], beh: 'spores', cd: 6, dmg: 7, range: 8, info: 'A spiralling storm of spores', unlocks: null },
  'boss.rocks': { name: 'Rockfall', boss: 'golemboss', els: ['earth'], beh: 'rocks', cd: 5.5, dmg: 28, range: 9, info: 'The ceiling comes down on your foes', unlocks: 'earth' },
  'boss.souls': { name: 'Soul Volley', boss: 'wraithboss', els: ['holy', 'frost'], beh: 'souls', cd: 3.5, dmg: 12, range: 9, info: 'Homing souls that hunt your foes', unlocks: 'holy' },
  'boss.coins': { name: 'Coin Spray', boss: 'mimiclord', els: ['holy'], beh: 'coins', cd: 3, dmg: 14, range: 8, info: 'A fan of gold coins; foes it finishes drop extra gold', unlocks: null },
  'boss.frost': { name: 'Frost Ring', boss: 'frostboss', els: ['frost'], beh: 'fring', cd: 4, dmg: 16, range: 6, info: 'A ring of frost rolls out and chills everything', unlocks: null },
  'boss.gears': { name: 'Gear Storm', boss: 'sentinel', els: ['earth'], beh: 'gears', cd: 6, dmg: 9, range: 6, info: 'Spinning saw gears orbit you and shred', unlocks: null },
};
export const LEGENDARY = {
  meteor: { name: 'Meteor Storm', els: ['fire'], cd: 9, range: 10, info: 'Every 9s a rain of meteors crushes your foes' },
  hole: { name: 'Void Maw', els: ['shadow'], cd: 11, range: 8, info: 'Every 11s a black hole drags foes in, then detonates' },
  still: { name: 'Stillness', els: ['frost'], cd: 15, range: 8, info: 'Every 15s time stops for all foes for 2.5s' },
};
// unique spells: hand-made, each plays by its own rule. They take a slot and level like others (+30% damage at Lv 2 and 4,
// their own perk at Lv 3 and 5, and -5% cooldown per level). No channelling: they auto-cast on their cooldown, except
// Meteor (kills: true), which has no cooldown: kills fill it (main.js meteorKill) and it falls by itself on the biggest crowd.
export const UNIQUE_SPELLS = {
  'u.meteor': { name: 'Meteor', els: ['fire'], beh: 'meteor', kills: true, cd: 0, dmg: 160, range: 9, info: 'No cooldown: every kill charges it (elites and bosses count more). When full, a meteor crushes the biggest crowd. Huge fire damage', up: { 3: '+25% blast area', 5: 'Charges 30% faster' } },
  'u.holybeam': { name: 'Holy Beam', els: ['holy'], beh: 'holybeam', cd: 4, dmg: 5, range: 7.5, info: 'A beam locks onto a foe for 4s and grows brighter and stronger', up: { 3: '+25% beam width', 5: 'Full power in 2s' } },
  'u.momentum': { name: 'Momentum', els: ['storm'], beh: 'momentum', cd: 2.5, dmg: 20, range: 7, info: 'Lightning strikes 3 nearby foes from the sky', up: { 3: '+1 strike', 5: '+2 strikes, 20% faster' } },
  'u.judgment': { name: "Vesper's Judgment", els: ['storm'], color: '#9dffb8', beh: 'judgment', cd: 6, dmg: 110, range: 10, info: "The spell Vesper used: her green bolt falls from the sky on the biggest crowd", up: { 3: '+25% blast area', 5: 'A second strike (60% damage)' } },
  'u.gust': { name: 'Storm Gust', els: ['frost'], beh: 'gust', cd: 7, dmg: 8, range: 8, info: 'A freezing storm over the biggest crowd FREEZES everything inside, then shatters it (bosses are immune to the freeze)', up: { 3: '+20% size, lasts 0.5s longer', 5: 'A second, smaller storm' } },
  'u.spike': { name: 'Earth Spike', els: ['earth'], beh: 'spike', cd: 4, dmg: 35, range: 6, info: 'A line of spikes that STUNS foes (bosses are immune to the stun)', up: { 3: 'A second line of spikes', 5: 'A third line, +2 tiles long' } },
};
// signature spells: the 24 spells that come up in runs, 3 hand-made per element. Each is built on a base shape (SHAPES:
// its behaviour, icon glyph and fusion shape) with its own numbers and a twist flag that main.js castSpell / the update
// loops read. ids are stable; spellDef resolves them before the generated element.shape grid.
export const SIGNATURE = {
  'arcane.missiles': { name: 'Arcane Missiles', base: 'bolt', tier: 0, over: { count: 3, dmg: 5, cd: 0.95, size: 0.6, r: 0.22, lanes: 0.42, speed: 12, homing: 0 }, info: 'A quick burst of 3 small darts' },
  'arcane.prism': { name: 'Prism Lance', base: 'lance', tier: 1, over: { split: 3, dmg: 16, cd: 1.3 }, info: 'A piercing lance that splits into 3 shards on its first hit' },
  'arcane.runes': { name: 'Rune Halo', base: 'halo', tier: 2, over: { breathe: true, vis: 'glaive' }, info: 'Rune blades circle you, sweeping out wide and back in' },
  'fire.ball': { name: 'Fireball', base: 'orb', tier: 0, over: { burnPool: true }, info: 'A slow fireball that bursts and leaves a pool of fire' },
  'fire.wall': { name: 'Flame Wall', base: 'field', tier: 1, over: { wall: true, dmg: 7, cd: 5.5 }, info: 'A straight wall of fire in front of you, across the way to your foes',
    up: { 3: 'A longer wall', 5: 'Burns twice as long' } },
  // Phoenix replaced Fire Ring (user: no blasts around Pip); the id stays 'fire.ring' so saves and codex entries keep it.
  // Base glaive (out-and-back: its icon and fusion shape); beh 'phoenix' routes the cast to main.js addPhoenix.
  'fire.ring': { name: 'Phoenix', base: 'glaive', tier: 1, over: { beh: 'phoenix', dmg: 12, cd: 3.4, range: 7.5 },
    info: 'A bird of flame dives out through your foes, wheels round and swoops back through them, setting them ablaze', up: { 3: 'A second phoenix', 5: 'Bigger and faster; burns hotter and longer' } },
  'frost.spear': { name: 'Ice Spear', base: 'lance', tier: 0, over: { endBurst: 1.2, dmg: 17, cd: 1.3 }, info: 'A piercing ice spear that bursts into frost where it stops' },
  'frost.frozenorb': { name: 'Frozen Orb', base: 'orb', tier: 2, over: { shards: true, vis: 'orb', pierce: 99, aoe: 0, endBurst: 1.6, meshScale: 1.4, speed: 4.5, life: 2.2, dmg: 14, cd: 3.2, size: 1.3 },
    info: 'A slow orb that sprays ice shards to both sides as it flies, then bursts', up: { 3: 'Sprays shards faster', 5: 'A second orb' } },
  // Frost Diver (id kept from the old Ice Trap so saves and codex entries carry over): beh 'diver' = main.js castDiver
  'frost.trap': { name: 'Frost Diver', base: 'ray', tier: 1, over: { beh: 'diver', dmg: 20, cd: 3.2, range: 7 },
    info: 'A line of ice spikes races along the floor to the nearest foe: every foe it crosses is hit and FROZEN solid for 2s (bosses are only slowed)',
    up: { 3: 'A second line, at the next foe', 5: 'A third line; foes stay frozen 40% longer' } },
  'storm.chain': { name: 'Chain Lightning', base: 'chain', tier: 1, over: { jumps: 3 }, info: 'Lightning that jumps between 4 foes' },
  'storm.thunder': { name: 'Thunderfall', base: 'rain', tier: 2, over: { thunder: true, count: 4, dmg: 26, cd: 5.5 }, info: 'Bolts strike your foes straight from the sky, with no warning' },
  'storm.static': { name: 'Static Ray', base: 'ray', tier: 2, over: { spark: true }, info: 'A beam that locks onto a foe and sparks to 2 foes near it' },
  'venom.spit': { name: 'Spit Volley', base: 'bolt', tier: 0, over: { volley: true, count: 3, dmg: 6, cd: 1.3, homing: 3, vis: 'venom', speed: 15, size: 0.6, r: 0.22 }, info: '3 quick poison shots in a burst',
    up: { 3: '+1 shot', 5: '+1 shot, 15% faster' } },
  'venom.toxglaive': { name: 'Venom Glaive', base: 'glaive', tier: 1, over: { trail: true, dmg: 11 }, info: 'A boomerang that leaves a trail of poison' },
  'venom.cloud': { name: 'Toxic Cloud', base: 'field', tier: 1, over: { drift: true, dur: 5, radius: 1.6, dmg: 5, cd: 5.5 }, info: 'A poison cloud that drifts after your foes' },
  'shadow.scythe': { name: 'Reaper Scythe', base: 'glaive', tier: 1, over: { reap: 0.15, meshScale: 1.9, size: 1.6, r: 0.55, dmg: 15, cd: 2.8 }, info: 'A huge boomerang scythe; it reaps foes under 15% health (not bosses)' },
  'shadow.hex': { name: 'Corpse Blast', base: 'burst', tier: 1, over: { corpse: true, count: 3, dmg: 20, aoe: 1.7, cd: 3.4, range: 8 }, // id kept from Hex Sigil (saves)
    info: 'Fresh corpses near your foes burst into black fire, one after another; a foe it kills bursts too (chain reaction). No corpses: a dark bolt bursts on a foe',
    up: { 3: '+1 corpse, +25% blast size', 5: 'Longer chain reactions; blasted foes stay CURSED longer and explode harder' } },
  'shadow.void': { name: 'Void Halo', base: 'halo', tier: 2, over: { pull: true, dmg: 7 }, info: 'Dark orbs circle you and drag nearby foes into their path' },
  'holy.smite': { name: 'Smite', base: 'rain', tier: 2, over: { smite: true, count: 1, dmg: 90, aoe: 2.0, cd: 6 }, info: 'One big pillar of light on the toughest foe',
    up: { 3: '+25% pillar size', 5: 'A second pillar on the next toughest foe' } },
  // Angel Swords keeps Radiance's old id so saves carry over; base 'rain' (strikes from above) gives it the falling-light icon
  'holy.radiance': { name: 'Angel Swords', base: 'rain', tier: 1, over: { swords: true, count: 4, dmg: 14, aoe: 0.9, cd: 4, range: 8 },
    info: '4 holy swords appear high above 4 of your foes, hang for a moment, then drop on them like guillotines', up: { 3: '6 swords', 5: '8 swords, bigger impacts' } },
  'holy.guard': { name: 'Guardian Orbs', base: 'halo', tier: 2, over: { guard: true, count: 2, dmg: 6, dur: 4.5, cd: 11 }, info: 'Orbs circle you and destroy enemy shots they touch' },
  'earth.boulder': { name: 'Boulder', base: 'orb', tier: 0, over: { roll: true, vis: 'orb', pierce: 99, aoe: 0, kb: 9, meshScale: 1.6, speed: 7, life: 1.5, dmg: 20, cd: 2.8, size: 1.6, r: 0.45, endBurst: 1.1 },
    info: 'A rolling boulder that ploughs through foes and knocks them flying' },
  // id kept from Quake (saves); base sigil for the painted icon (a stone spike rising out of the floor), main.js castPillars
  'earth.quake': { name: 'Stone Pillars', base: 'sigil', tier: 1, over: { pillars: true, count: 3, dmg: 15, aoe: 1.0, cd: 4.2, range: 7 },
    info: 'Stone pillars burst up under 3 foes, launching them into the air and STUNNING them for 1.2s (not bosses)', up: { 3: '+1 pillar', 5: '+1 pillar, taller and wider' } },
  'earth.pebbles': { name: 'Pebble Storm', base: 'rain', tier: 2, over: { pebbles: true, count: 9, dmg: 9, aoe: 0.8 }, info: 'Many small rocks rain down on your foes', up: { 3: '+3 rocks', 5: '+4 rocks' } },
};
export const SIG_IDS = Object.keys(SIGNATURE);
for (const id of SIG_IDS) SIGNATURE[id].el = id.split('.')[0];
// old generated ids ('element.shape' from the 8x11 grid) -> the closest signature spell of the same element (_ = default)
const SIG_MIGRATE = {
  arcane: { _: 'arcane.missiles', lance: 'arcane.prism', ray: 'arcane.prism', glaive: 'arcane.prism', halo: 'arcane.runes', nova: 'arcane.runes', field: 'arcane.runes', sigil: 'arcane.runes', rain: 'arcane.runes' },
  fire: { _: 'fire.ball', field: 'fire.wall', rain: 'fire.wall', sigil: 'fire.wall', ray: 'fire.wall', nova: 'fire.ring', halo: 'fire.ring' },
  frost: { _: 'frost.spear', orb: 'frost.frozenorb', burst: 'frost.frozenorb', wisp: 'frost.frozenorb', halo: 'frost.frozenorb', rain: 'frost.frozenorb', sigil: 'frost.trap', nova: 'frost.trap', field: 'frost.trap' },
  storm: { _: 'storm.chain', rain: 'storm.thunder', orb: 'storm.thunder', nova: 'storm.thunder', field: 'storm.thunder', sigil: 'storm.thunder', ray: 'storm.static', halo: 'storm.static' },
  venom: { _: 'venom.spit', glaive: 'venom.toxglaive', chain: 'venom.toxglaive', ray: 'venom.toxglaive', halo: 'venom.toxglaive', field: 'venom.cloud', nova: 'venom.cloud', rain: 'venom.cloud', sigil: 'venom.cloud' },
  shadow: { _: 'shadow.scythe', sigil: 'shadow.hex', burst: 'shadow.hex', nova: 'shadow.hex', field: 'shadow.hex', rain: 'shadow.hex', halo: 'shadow.void', wisp: 'shadow.void' },
  holy: { _: 'holy.smite', nova: 'holy.radiance', field: 'holy.radiance', sigil: 'holy.radiance', burst: 'holy.radiance', halo: 'holy.guard', wisp: 'holy.guard' },
  earth: { _: 'earth.boulder', nova: 'earth.quake', sigil: 'earth.quake', field: 'earth.quake', burst: 'earth.quake', rain: 'earth.pebbles', halo: 'earth.pebbles', wisp: 'earth.pebbles' },
};
// old save ids -> new ids (the very first saves used bare names)
export const LEGACY_IDS = { bolt: 'arcane.missiles', fire: 'fire.ball', frost: 'frost.trap', chain: 'storm.chain', orbs: 'arcane.runes', venom: 'venom.spit' };
// any saved id -> the id it plays as today (unchanged when it is still current: signatures, fusions, boss/legendary/unique)
export function migrateId(id) {
  if (typeof id !== 'string') return id;
  if (LEGACY_IDS[id]) return LEGACY_IDS[id];
  if (SIGNATURE[id]) return id;
  const [ek, shape] = id.split('.');
  const M = SIG_MIGRATE[ek];
  if (M && shape && SHAPES[shape]) return M[shape] || M._;
  return id;
}
// a saved spell list ({ id, lv, ... }) moved to today's ids: duplicates merge and keep the higher level
export function migrateSpells(list) {
  if (!Array.isArray(list)) return list;
  const out = [];
  for (const s of list) {
    if (!s || typeof s.id !== 'string') continue;
    const id = migrateId(s.id), had = out.find((x) => x.id === id);
    if (had) { had.lv = Math.max(had.lv || 1, s.lv || 1); continue; }
    out.push({ ...s, id });
  }
  return out;
}

function mixHex(a, b) {
  const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const x = p(a), y = p(b);
  return '#' + x.map((v, i) => Math.round((v + y[i]) / 2).toString(16).padStart(2, '0')).join('');
}
const cache = new Map();
export function spellDef(id) {
  if (cache.has(id)) return cache.get(id);
  let d;
  if (UNIQUE_SPELLS[id]) {
    const U = UNIQUE_SPELLS[id];
    d = { id, name: U.name, els: U.els, color: U.color || ELEMENTS[U.els[0]].color, cd: U.cd, dmg: U.dmg, range: U.range, info: U.info, unique: true, kills: !!U.kills,
      up: U.up, shape: 'unique', sh: { beh: U.beh } };
  } else if (LEGENDARY[id]) {
    const L = LEGENDARY[id];
    d = { id, name: L.name, els: L.els, color: ELEMENTS[L.els[0]].color, cd: L.cd, range: L.range, info: L.info, legendary: true, shape: 'legend', sh: {} };
  } else if (BOSS_SPELLS[id]) {
    const B = BOSS_SPELLS[id];
    d = { id, name: B.name, els: B.els, color: B.els.length > 1 ? mixHex(ELEMENTS[B.els[0]].color, ELEMENTS[B.els[1]].color) : ELEMENTS[B.els[0]].color,
      cd: B.cd, dmg: B.dmg, range: B.range, info: B.info, bossSpell: true, boss: B.boss, shape: 'boss', sh: { beh: B.beh } };
  } else if (SIGNATURE[id]) {
    const S = SIGNATURE[id], E = ELEMENTS[S.el], sh = { ...SHAPES[S.base], ...S.over };
    d = { id, name: S.name, els: [S.el], shape: S.base, sh, sig: true, tier: S.tier, up: S.up, color: E.color,
      cd: +(sh.cd * E.cd).toFixed(2), dmg: sh.dmg * E.dmg, range: sh.range, info: S.info + '. ' + E.info };
  } else {
    const [ek, shape] = id.split('.');
    const els = ek.split('+'), sh = SHAPES[shape];
    if (!sh || els.some((e) => !ELEMENTS[e])) return null;
    const fused = els.length > 1;
    const E = els.map((e) => ELEMENTS[e]);
    const dmgM = E.reduce((a, e) => a + e.dmg, 0) / E.length * (fused ? 1.2 : 1);
    const cdM = Math.min(...E.map((e) => e.cd));
    const name = NAME_OVERRIDES[id] || `${fused ? FUSION_NAMES[ek] : E[0].adj} ${sh.name}`;
    d = { id, name, els, shape, sh, fused, color: fused ? mixHex(E[0].color, E[1].color) : E[0].color,
      cd: +(sh.cd * cdM).toFixed(2), dmg: sh.dmg * dmgM, range: sh.range,
      info: sh.info + '. ' + (fused ? E.map((x) => `${x.name}: ${x.info[0].toLowerCase()}${x.info.slice(1)}`).join('. ') : E[0].info) };
  }
  cache.set(id, d);
  return d;
}
// fusions that can actually happen: an element pair and a base shape one of the pair's signature spells has
export function fusionIds() {
  const ids = [], shapesOf = (el) => SIG_IDS.filter((id) => SIGNATURE[id].el === el).map((id) => SIGNATURE[id].base);
  for (let i = 0; i < ELEMENT_ORDER.length; i++) for (let j = i + 1; j < ELEMENT_ORDER.length; j++) {
    const a = ELEMENT_ORDER[i], b = ELEMENT_ORDER[j];
    for (const sh of new Set([...shapesOf(a), ...shapesOf(b)])) ids.push(a + '+' + b + '.' + sh);
  }
  return ids;
}
export const FUSION_IDS = fusionIds();
export function allSpellIds() {
  return SIG_IDS.concat(FUSION_IDS, Object.keys(BOSS_SPELLS), Object.keys(LEGENDARY), Object.keys(UNIQUE_SPELLS));
}
export const ALL_SPELL_SET = new Set(allSpellIds());
export const TOTAL_SPELLS = ALL_SPELL_SET.size;
// what each level adds, per behaviour
export function levelText(def, lv) {
  if (lv === 2 || lv === 4) return '+30% damage';
  if (def.unique) return (def.up && def.up[lv]) || '+30% damage';
  if (def.sig && def.up && def.up[lv]) return def.up[lv];
  const b = def.sh.beh;
  if (lv === 3) return { proj: '+1 projectile', chain: '+2 jumps', orbit: '+1 orb', rain: '+2 strikes', radial: '+4 shots', nova: '+25% area', zone: '+25% area', mine: '+25% area', beam: '+50% duration', summon: '+1 familiar' }[b] || '+30% damage';
  if (lv === 5) return { proj: '+1 projectile, 15% faster', chain: '+3 jumps', orbit: '+2 orbs', rain: '+3 strikes', radial: '+6 shots', nova: 'Casts twice', zone: 'Lasts twice as long', mine: 'Drops two', beam: 'Splits to 2 foes', summon: '+1 familiar, faster' }[b] || '+30% damage';
  return '';
}
export function fusionOf(a, b) {
  const A = spellDef(a.id), B = spellDef(b.id);
  if (!A || !B || A.fused || B.fused || A.legendary || B.legendary || A.bossSpell || B.bossSpell || A.unique || B.unique) return null;
  if (A.els[0] === B.els[0]) return null;
  const main = b.lv > a.lv ? B : A; // the higher-level spell keeps its shape
  return elKey([A.els[0], B.els[0]]) + '.' + main.shape;
}

// ---------- enemy resistances (multipliers; 0 = immune) ----------
export const RES = {
  slime: { fire: 1.5, venom: 0.5 }, big: { fire: 1.5, venom: 0.5 }, boss: { fire: 1.3, venom: 0.4 },
  eye: { arcane: 0.5, storm: 1.5 }, eyeboss: { arcane: 0.5, storm: 1.4, holy: 1.3 },
  imp: { shadow: 0, holy: 1.75, fire: 0.75 },
  skeleton: { venom: 0, holy: 1.75, earth: 1.5, frost: 0.75 }, tyrant: { venom: 0, holy: 1.6, earth: 1.3, shadow: 0.5 },
  bomber: { fire: 0, frost: 1.75 },
  ghost: { shadow: 0.5, holy: 2, earth: 0.5, arcane: 1.3 }, wraithboss: { shadow: 0.3, holy: 1.8, frost: 0.6 },
  shroom: { venom: 0, fire: 1.75, frost: 0.75 }, sporeboss: { venom: 0, fire: 1.6 },
  golem: { earth: 0.25, storm: 1.5, venom: 0.5, fire: 0.75 }, golemboss: { earth: 0.25, storm: 1.4, venom: 0.5 },
  mimic: { arcane: 0.75, fire: 1.25 }, mimiclord: { arcane: 0.6, fire: 1.3, venom: 1.2 },
  frostboss: { frost: 0.2, fire: 1.6, storm: 0.8 },
  sentinel: { venom: 0, storm: 1.5, earth: 0.6, fire: 0.75 },
  cursed: { venom: 0, holy: 1.75, earth: 1.5, frost: 0.75 }, reaper: { venom: 0, holy: 1.75, shadow: 0.5, earth: 1.3 }, boneknight: { venom: 0, holy: 1.6, earth: 1.3, storm: 0.75 },
  archer: { venom: 0, holy: 1.75, earth: 1.5, frost: 0.75 },
  runegolem: { earth: 0.25, arcane: 0.6, storm: 0.75, fire: 1.3 }, crystalgolem: { earth: 0.4, arcane: 0.5, storm: 1.5, venom: 0.5 }, magmagolem: { fire: 0, earth: 0.4, frost: 1.75, venom: 0.5 },
  spider: { venom: 0, fire: 1.5, frost: 0.75 }, salamander: { fire: 0, frost: 1.75, venom: 0.75 },
  shieldk: { storm: 1.5, earth: 0.75, shadow: 0.75 }, cultist: { shadow: 0.5, holy: 1.5, arcane: 1.25 }, beetle: { earth: 0.5, storm: 1.3, venom: 1.25 },
};
export const UNDEAD = new Set(['skeleton', 'ghost', 'tyrant', 'wraithboss', 'cursed', 'reaper', 'boneknight', 'archer']);
export function resistOf(type, els, extra) {
  let m = 0;
  for (const el of els) m += (extra && extra[el] !== undefined ? extra[el] : (RES[type] && RES[type][el] !== undefined ? RES[type][el] : 1));
  return els.length ? m / els.length : 1;
}

// ---------- heroes (same mechanics, different look and a small passive) ----------
// cls decides what the Ragnarok-style stats do (see derive)
export const HEROES = {
  wizard: { name: 'Wizard', cls: 'mage', sprite: 'wizard', vis: null, cost: 0, info: 'Mage: INT = damage, DEX = faster casting', start: 'arcane.missiles', tipColor: 0xff7fe0,
    base: { str: 1, agi: 2, vit: 2, int: 6, dex: 4, luk: 2 } },
  amazon: { name: 'Amazon', cls: 'hunter', sprite: 'amazon', vis: 'javelin', cost: 80, info: 'Hunter: STR + DEX = damage, throws pierce one more foe', start: 'arcane.prism', tipColor: 0xffd27a,
    base: { str: 4, agi: 5, vit: 3, int: 1, dex: 4, luk: 2 } },
  berserker: { name: 'Berserker', cls: 'warrior', sprite: 'berserker', vis: 'axe', cost: 110, info: 'Warrior: STR = damage, VIT gives more hearts', start: 'earth.boulder', tipColor: 0xc8d4e0,
    base: { str: 7, agi: 3, vit: 6, int: 1, dex: 2, luk: 1 } },
  ranger: { name: 'Ranger', cls: 'archer', sprite: 'ranger', vis: 'arrow', cost: 90, info: 'Archer: DEX = damage, AGI = attack speed, +2 range', start: 'arcane.missiles', tipColor: 0xb8f07a,
    base: { str: 2, agi: 5, vit: 2, int: 1, dex: 6, luk: 3 } },
  necro: { name: 'Necromancer', cls: 'mage', sprite: 'necro', vis: 'skull', cost: 140, info: 'Mage: every hit curses, cursed foes explode harder', start: 'shadow.scythe', tipColor: 0x7dff9a,
    base: { str: 1, agi: 2, vit: 3, int: 6, dex: 3, luk: 3 } },
};
export const STATS = ['str', 'agi', 'vit', 'int', 'dex', 'luk'];
export const STAT_NAMES = { str: 'STR', agi: 'AGI', vit: 'VIT', int: 'INT', dex: 'DEX', luk: 'LUK' };
// Stats (same for every hero): VIT = hearts + damage resistance, STR = impact (knockback, boss/elite damage, stagger),
// INT = damage, DEX = cast speed, AGI = dodge (no move speed), LUK = crit. The hero's own base keeps the old class formulas, so a fresh hero plays as before;
// every point above it (level-ups, Sanctum, victories, legacy, gear) uses the stronger numbers below.
// A point above the base counts in full up to 10, then 60%, then 35% past 20, so big meta stats can't run away.
export const soft = (v) => (v <= 10 ? v : v <= 20 ? 10 + (v - 10) * 0.6 : 16 + (v - 20) * 0.35);
// Raising a stat in a run costs more the higher it already is (permanent + run, gear not counted): 1 point below 5,
// 2 below 10, 3 below 15, then +1 per 5. Level-ups give 3 points, 4 from level 10 (lvPts).
export const statPtCost = (v) => (v < 5 ? 1 : v < 10 ? 2 : v < 15 ? 3 : 4 + Math.floor((v - 15) / 5));
export const lvPts = (lv) => 3 + Math.floor(lv / 10);
// milestones at a stat's total (gear included): derive applies them, the STATS panel shows the next one
export const MILESTONES = {
  str: [[5, 'hits stagger normal foes (never bosses)'], [10, '+25% boss damage'], [15, 'kills knock nearby foes back']],
  int: [[5, '+12% area'], [10, '+20% damage'], [15, 'your strongest spell casts twice every 4th cast']], // user: double cast needs more INT, one spell only
  dex: [[5, '+15% projectile speed'], [10, '+1 projectile on every spell'], [15, '-12% cooldowns']],
  agi: [[5, 'a dodge gives a 0.8s invulnerable dash'], [10, 'a dodge strikes back at foes around you'], [15, '+8% dodge']],
  luk: [[5, 'chests drop extra loot, kills rain coins'], [10, '+100% crit damage'], [15, 'crits chain to a nearby foe']],
  vit: [[5, '+1 heart'], [10, '+1 heart'], [15, '+2 hearts']],
};
export const msTier = (v) => (v >= 15 ? 3 : v >= 10 ? 2 : v >= 5 ? 1 : 0);
export function derive(cls, st, base = st) {
  const up = (k) => Math.max(0, soft(st[k] || 0) - soft(base[k] || 0));
  const b = (k) => base[k] || 0;
  const T = {}; for (const k of STATS) T[k] = msTier(st[k] || 0);
  // the old class formulas, read at the hero's base only
  const bDmg = { mage: 0.04 * b('int') + 0.005 * b('str'), archer: 0.04 * b('dex') + 0.01 * b('str'), warrior: 0.04 * b('str') + 0.01 * b('dex') }[cls] ?? 0.025 * (b('str') + b('dex'));
  const bCd = { mage: 0.015 * b('dex') + 0.004 * b('agi'), archer: 0.015 * b('agi') + 0.004 * b('dex'), warrior: 0.012 * b('agi') }[cls] ?? 0.013 * b('agi');
  const d = { T,
    dmg: (1 + bDmg + up('int') * 0.10) * (T.int >= 2 ? 1.2 : 1), // INT: +10% damage a point
    cd: 1 / (1 + bCd + up('dex') * 0.045) * (T.dex >= 3 ? 0.88 : 1), // DEX: ~4.5% faster casting a point
    hearts: Math.floor(b('vit') / (cls === 'warrior' ? 4 : 5)) + Math.floor(up('vit') / 3) + (T.vit >= 1) + (T.vit >= 2) + 2 * (T.vit >= 3), // VIT: a heart per 3
    resist: Math.min(0.4, up('vit') * 0.025), // VIT: -2.5% damage taken a point (max 40%), fractions carry over (damagePlayer)
    dodge: Math.min(0.45, 0.006 * b('agi') + up('agi') * 0.02 + (T.agi >= 3 ? 0.08 : 0)), // AGI: +2% dodge a point
    speed: 1, // move speed comes from gear only (Fleet, boots)
    crit: 0.008 * b('luk') + up('luk') * 0.02, critDmg: 0.02 * b('luk') + up('luk') * 0.04 + (T.luk >= 2 ? 1 : 0), // LUK: +2% crit a point
    loot: 0.02 * b('luk') + up('luk') * 0.04,
    kb: 1 + up('str') * 0.06, // STR: +6% knockback a point
    eliteDmg: 1 + up('str') * 0.05, bossDmg: 1 + up('str') * 0.05 + (T.str >= 2 ? 0.25 : 0), // STR: +5% vs bosses and elites a point, 10: +25% vs bosses
    stagger: T.str >= 1, quake: T.str >= 3, // STR 5: hits stagger normal foes, 15: kills knock nearby foes back
    status: 1 + 0.03 * b('int') + up('int') * 0.06, area: T.int >= 1 ? 1.12 : 1, echo: T.int >= 3,
    projSpd: 1 + up('dex') * 0.02 + (T.dex >= 1 ? 0.15 : 0), proj: T.dex >= 2 ? 1 : 0,
    dash: T.agi >= 1, counter: T.agi >= 2, chestLoot: T.luk >= 1, chain: T.luk >= 3 };
  return d;
}
export function statInfo(cls, k) {
  return { str: 'knockback, damage vs bosses and elites', int: 'damage, status power', dex: 'cast speed, projectile speed', agi: 'dodge chance',
    luk: 'crit chance, crit damage, loot', vit: 'hearts (+1 per 3 points), resist damage' }[k];
}
// Progression retune (user: "level 10 with two spells at Lv 5 on floor 4", a run is 50 floors). XP per kill: 1, big/golem 2,
// elite 3 (was 6), champion 15 (was 25), boss 60. A floor pays ~40 XP on floor 1, ~250 on floor 4, ~1000 by floor 8 and
// levels off near ~1300 (wave size and elite share stop growing). Level L needs:
//   L1 15 (first level-up inside the first fight), L2 60, then 150 per level above 2: L3 150, L4 300, L5 450 ... L10 1200, L20 2700
//   total to reach L5 525, L10 4275, L14 ~10000, L26 ~41500  ->  aim: Lv 4-5 on floor 4, ~13 by floor 15, 25+ by floor 40.
// Spell levels are capped by depth as well (main.js spellCap: Lv 3 from floor 5, Lv 4 from 10, Lv 5 from 20), and level-up
// stat cards give +2 (was +3), Meteor needs 22-14 kills (was 14-9).
// (was: L1 8, L2 22, then 12 + 8L + 1.6L^2: total 898 XP to reach L10.)
export const xpNeed = (lv) => (lv === 1 ? 15 : lv === 2 ? 60 : 150 * (lv - 2));

// ---------- gear ----------
export const SLOTS = ['hat', 'robe', 'staff', 'ring', 'amulet', 'boots'];
export const SLOT_NAMES = { hat: 'Hat', robe: 'Robe', staff: 'Staff', ring: 'Ring', amulet: 'Amulet', boots: 'Boots' };
const BASE_NAMES = { hat: ['Hood', 'Cowl', 'Hat', 'Circlet'], robe: ['Robe', 'Vestments', 'Cloak', 'Mantle'], staff: ['Staff', 'Rod', 'Wand', 'Scepter'],
  ring: ['Ring', 'Band', 'Loop', 'Signet'], amulet: ['Amulet', 'Pendant', 'Talisman', 'Charm'], boots: ['Boots', 'Slippers', 'Treads', 'Sandals'] };
export const RARITY = [
  { key: 'common', name: 'Common', color: '#d8d8e0', n: 1, mult: 1 },
  { key: 'rare', name: 'Rare', color: '#5fb4ff', n: 2, mult: 1.15 },
  { key: 'epic', name: 'Epic', color: '#c07aff', n: 3, mult: 1.3 },
  { key: 'legendary', name: 'Legendary', color: '#ffa040', n: 3, mult: 1.5 },
];
export const AFFIXES = {
  power: { pre: 'Mighty', lo: 6, hi: 14, fmt: (v) => `+${v}% spell damage` },
  haste: { pre: 'Quick', lo: 4, hi: 9, fmt: (v) => `-${v}% cooldowns` },
  vit: { pre: 'Sturdy', lo: 1, hi: 1, fmt: () => '+1 heart', slots: ['hat', 'robe', 'amulet'] },
  speed: { pre: 'Fleet', lo: 5, hi: 10, fmt: (v) => `+${v}% move speed`, slots: ['boots', 'robe'] },
  crit: { pre: 'Keen', lo: 4, hi: 9, fmt: (v) => `+${v}% crit chance` },
  critdmg: { pre: 'Cruel', lo: 20, hi: 45, fmt: (v) => `+${v}% crit damage` },
  area: { pre: 'Vast', lo: 8, hi: 18, fmt: (v) => `+${v}% area` },
  dur: { pre: 'Lasting', lo: 10, hi: 25, fmt: (v) => `+${v}% duration` },
  proj: { pre: 'Twin', lo: 1, hi: 1, fmt: () => '+1 projectile', slots: ['staff', 'amulet'], minRarity: 1 },
  magnet: { pre: 'Magnetic', lo: 20, hi: 50, fmt: (v) => `+${v}% pickup range`, slots: [] }, // no longer rolls (room clears collect coins); kept so old gear still reads
  luck: { pre: 'Lucky', lo: 10, hi: 25, fmt: (v) => `+${v}% luck` },
  dodge: { pre: 'Nimble', lo: 4, hi: 8, fmt: (v) => `${v}% chance to dodge`, slots: ['robe', 'boots', 'ring'] },
  el: { pre: null, lo: 15, hi: 35, fmt: (v, el) => `+${v}% ${ELEMENTS[el].name} damage` },
  str: { pre: 'Brutal', lo: 1, hi: 3, fmt: (v) => `+${v} STR`, stat: true },
  agi: { pre: 'Swift', lo: 1, hi: 3, fmt: (v) => `+${v} AGI`, stat: true },
  vitst: { pre: 'Hale', lo: 1, hi: 3, fmt: (v) => `+${v} VIT`, stat: true },
  int: { pre: 'Sage', lo: 1, hi: 3, fmt: (v) => `+${v} INT`, stat: true },
  dex: { pre: 'Deft', lo: 1, hi: 3, fmt: (v) => `+${v} DEX`, stat: true },
  luk: { pre: 'Fortunate', lo: 1, hi: 3, fmt: (v) => `+${v} LUK`, stat: true },
};
const EL_PRE = { arcane: 'Mystic', fire: 'Emberwoven', frost: 'Rimed', storm: 'Charged', venom: 'Toxic', shadow: 'Umbral', holy: 'Blessed', earth: 'Stoneset' };
export const UNIQUES = {
  hat: [{ id: 'cinders', name: 'Crown of Cinders', info: 'Burning foes explode when they die' }, { id: 'glass', name: 'Glass Hat', info: '+50% damage, but -1 heart' }],
  robe: [{ id: 'mirror', name: 'Robe of Mirrors', info: 'The first hit in every room is blocked' }, { id: 'shroud', name: 'Shroud of Night', info: 'Curse explosions are twice as big' }],
  staff: [{ id: 'stormcaller', name: 'Stormcaller', info: 'Every 8th cast fires twice' }, { id: 'prism', name: 'Prism Staff', info: 'Every hit adds a random element' }],
  ring: [{ id: 'echo', name: 'Ring of Echoes', info: '20% chance for spells to cast twice' }, { id: 'ouro', name: 'Ouroboros', info: 'Kills shave 0.1s off every cooldown' }],
  amulet: [{ id: 'lich', name: 'Heart of the Lich', info: 'Heal half a heart every 15 kills' }, { id: 'hourglass', name: 'Hourglass', info: '-20% cooldowns' }],
  boots: [{ id: 'frostwalk', name: 'Frostwalkers', info: 'You leave a chilling trail' }, { id: 'league', name: 'Seven-League Boots', info: '+30% speed, pickups fly to you' }],
};
export function rollRarity(rnd, floor, luck = 0, min = 0) {
  const w = [60, 28 + floor, 10 + floor * 0.8, (2 + floor * 0.4) * (1 + luck)];
  for (let i = 0; i < min; i++) w[i] = 0;
  let t = w.reduce((a, b) => a + b, 0) * rnd();
  for (let i = 0; i < 4; i++) if ((t -= w[i]) <= 0) return i;
  return 3;
}
export function rollGear(rnd, floor, luck = 0, minRarity = 0, slot = null) {
  const pickA = (a) => a[Math.floor(rnd() * a.length)];
  slot = slot || pickA(SLOTS);
  const r = rollRarity(rnd, floor, luck, minRarity), R = RARITY[r];
  const scale = R.mult * (1 + 0.04 * Math.min(floor, 20));
  const pool = Object.keys(AFFIXES).filter((k) => (!AFFIXES[k].slots || AFFIXES[k].slots.includes(slot)) && (AFFIXES[k].minRarity || 0) <= r);
  const affixes = [];
  while (affixes.length < R.n && pool.length) {
    const id = pool.splice(Math.floor(rnd() * pool.length), 1)[0], A = AFFIXES[id];
    let v = A.lo + Math.round(rnd() * (A.hi - A.lo));
    if (A.stat) v = Math.max(1, Math.round(v * R.mult + Math.floor(floor / 6)));
    else if (A.hi > 1) v = Math.round(v * scale);
    affixes.push(id === 'el' ? { id, v, el: pickA(ELEMENT_ORDER) } : { id, v });
  }
  const item = { slot, rarity: r, affixes, uid: Math.floor(rnd() * 1e9) };
  if (r === 3) { const u = pickA(UNIQUES[slot]); item.unique = u.id; item.name = u.name; item.uinfo = u.info; }
  else {
    const a = affixes[0];
    item.name = `${a.id === 'el' ? EL_PRE[a.el] : AFFIXES[a.id].pre} ${pickA(BASE_NAMES[slot])}`;
  }
  return item;
}
export function gearLines(item) {
  const out = item.affixes.map((a) => AFFIXES[a.id].fmt(a.v, a.el));
  if (item.uinfo) out.push(item.uinfo);
  return out;
}
export function gearScore(item) {
  return item.rarity * 10 + item.affixes.reduce((s, a) => s + (AFFIXES[a.id].stat ? a.v : AFFIXES[a.id].hi > 1 ? a.v / AFFIXES[a.id].hi * 3 : 3), 0) + (item.unique ? 6 : 0);
}
// totals from everything equipped
export function gearTotals(equipped) {
  const t = { st: { str: 0, agi: 0, vit: 0, int: 0, dex: 0, luk: 0 }, dmg: 1, cd: 1, hp: 0, speed: 1, crit: 0, critDmg: 0, area: 1, dur: 1, proj: 0, magnet: 1, luck: 0, dodge: 0, el: {}, flags: {} };
  for (const it of Object.values(equipped)) {
    if (!it) continue;
    for (const a of it.affixes) {
      const v = a.v;
      switch (a.id) {
        case 'power': t.dmg *= 1 + v / 100; break;
        case 'haste': t.cd *= 1 - v / 100; break;
        case 'vit': t.hp += 2 * v; break;
        case 'speed': t.speed *= 1 + v / 100; break;
        case 'crit': t.crit += v / 100; break;
        case 'critdmg': t.critDmg += v / 100; break;
        case 'area': t.area *= 1 + v / 100; break;
        case 'dur': t.dur *= 1 + v / 100; break;
        case 'proj': t.proj += 1; break;
        case 'magnet': t.magnet *= 1 + v / 100; break;
        case 'luck': t.luck += v / 100; break;
        case 'dodge': t.dodge += v / 100; break;
        case 'el': t.el[a.el] = (t.el[a.el] || 1) * (1 + v / 100); break;
        case 'str': case 'agi': case 'int': case 'dex': case 'luk': t.st[a.id] += v; break;
        case 'vitst': t.st.vit += v; break;
      }
    }
    if (it.unique) {
      t.flags[it.unique] = true;
      if (it.unique === 'glass') { t.dmg *= 1.5; t.hp -= 2; }
      if (it.unique === 'hourglass') t.cd *= 0.8;
      if (it.unique === 'league') { t.speed *= 1.3; t.magnet *= 3; }
    }
  }
  return t;
}

// ---------- spell damage model (main.js enemy HP model) ----------
// SPELL_HITS[id][lv - 1]: single-target damage of one spell per second, per unit of def.dmg / def.cd (legendaries: per 1),
// with the player's global multipliers taken out. Measured, not guessed: tools/hp_calib.mjs casts every spell at every
// level at a dummy that walks in and out around Pip (0.6-3.5 tiles, 2 x 20 s) and writes this table, so it includes shot counts, pierce,
// burn pools, poison, freeze/shatter and the per-level perks. Re-run it after changing a spell's behaviour (a change to
// its dmg or cd alone needs no re-run). Fusions use the mean of 2-3 measured fusions of their base shape ('fusion.<shape>').
// Meteor (charged by kills) is computed in main.js; Stillness deals no damage.
export const SPELL_HITS = {
  'arcane.missiles': [3.25, 4.44, 7.59, 8.48, 14.95],
  'arcane.prism': [1.27, 1.3, 3.72, 4.42, 8.71],
  'arcane.runes': [6.21, 7.45, 12.37, 15.6, 22.78],
  'boss.bones': [1.62, 2.12, 5.81, 7.12, 10.5],
  'boss.coins': [3.42, 4.97, 6.75, 8.39, 10.59],
  'boss.frost': [0.97, 1.14, 1.4, 1.66, 1.93],
  'boss.gaze': [7.44, 9.67, 11.9, 14.13, 16.36],
  'boss.gears': [2.63, 4.27, 7.78, 10.49, 15.94],
  'boss.gloop': [6.83, 8.98, 12.93, 17.72, 20.91],
  'boss.rocks': [6.42, 9.07, 12.08, 16.98, 21.61],
  'boss.souls': [6.14, 8.99, 12.7, 17.43, 24.58],
  'boss.spores': [9.4, 12.47, 19.29, 23.74, 29.45],
  'earth.boulder': [0.88, 1.15, 2.83, 3.5, 7.53],
  'earth.pebbles': [2.99, 3.85, 5.49, 6.97, 10.89],
  'earth.quake': [0.88, 1.15, 1.6, 1.68, 2.2],
  'fire.ball': [3.69, 4.61, 8.47, 9.93, 18.99],
  'fire.ring': [3.62, 5.05, 9.15, 11.88, 14.51],
  'fire.wall': [5.35, 6.95, 10.36, 12.3, 14.24],
  'frost.frozenorb': [2.33, 2.82, 3.99, 4.79, 11.8],
  'frost.spear': [1.23, 1.67, 4.23, 4.98, 10.01],
  'frost.trap': [1.05, 1.37, 1.57, 1.86, 2.16],
  'hole': [5.25, 5.25, 5.25, 5.25, 5.25],
  'holy.guard': [3.55, 4.4, 8.87, 9.32, 19.28],
  'holy.radiance': [3.69, 4.79, 8.7, 10.85, 17.02],
  'holy.smite': [0.79, 1.2, 1.26, 1.5, 2.04],
  'meteor': [39.33, 30.36, 35.69, 33.9, 33.92],
  'shadow.hex': [1.43, 1.85, 2.13, 2.54, 3.19],
  'shadow.scythe': [2.51, 3.04, 7.02, 8.06, 14.77],
  'shadow.void': [4.91, 6.14, 8.95, 11.33, 21.28],
  'storm.chain': [1.07, 1.23, 1.61, 1.91, 2.22],
  'storm.static': [12.2, 15.86, 28.74, 34.13, 39.52],
  'storm.thunder': [4.54, 5.72, 11.33, 13.23, 21.92],
  'u.gust': [18.74, 28.31, 36.8, 47.03, 52.62],
  'u.holybeam': [19.33, 25.12, 30.92, 37.44, 49.38],
  'u.judgment': [0.79, 1.37, 1.9, 2.26, 4.05],
  'u.momentum': [1.45, 1.6, 2.53, 2.6, 4.07],
  'u.spike': [0.88, 1.6, 1.68, 2, 3.1],
  'venom.cloud': [16.6, 21.57, 26.63, 31.63, 57.36],
  'venom.spit': [4.99, 6.23, 8.75, 11.12, 17],
  'venom.toxglaive': [5.37, 6.78, 9.94, 12.54, 19.95],
  'fusion.bolt': [2.08, 2.69, 5.34, 6.46, 11.04],
  'fusion.chain': [1.19, 1.55, 2.01, 2.73, 2.49],
  'fusion.field': [7.54, 9.8, 14.16, 16.82, 25.25],
  'fusion.glaive': [4.05, 5.01, 8.73, 10.88, 17.24],
  'fusion.halo': [10.19, 12.95, 17.91, 21.48, 33.19],
  'fusion.lance': [2.58, 3.14, 6.3, 7.43, 12.17],
  'fusion.nova': [3, 3.85, 4.62, 5.55, 10.23],
  'fusion.orb': [2.13, 2.87, 5.25, 6.13, 10.99],
  'fusion.rain': [4.7, 6.15, 9.01, 11.13, 17.08],
  'fusion.ray': [10.05, 13.07, 22.71, 26.97, 31.23],
  'fusion.sigil': [1.03, 1.23, 1.64, 1.95, 4.91],
};
export function spellHits(def, lv) {
  const L = Math.min(5, Math.max(1, lv || 1)) - 1;
  const row = SPELL_HITS[def.fused ? 'fusion.' + def.shape : def.id];
  if (row) return row[L];
  return (1 + 0.3 * L) * ((def.sh && def.sh.count) || 1); // anything not measured: its shots per cast x the level bonus
}
