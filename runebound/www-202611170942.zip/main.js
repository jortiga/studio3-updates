// Runebound Depths — auto-casting wizard dungeon crawler (three.js, portrait first).
// ?auto=1 lets a bot play (for recording / testing), ?t=N fast-forwards N seconds, ?seed=N fixes the dungeon.
import * as THREE from './vendor/three.module.min.js'; // the official minified r160 build (same code, half the download)
import { Monet, PRODUCTS } from './monet.js';
import { mirror, restore, saveLocked, unlock } from './durable.js';
import { ELEMENTS, ELEMENT_ORDER, START_ELEMENTS, SHAPES, OFFER_SHAPES, BOSS_SPELLS, LEGENDARY, UNIQUE_SPELLS, LEGACY_IDS, SIGNATURE, SIG_IDS, CUT_IDS, FUSION_IDS, ALL_SPELL_SET, migrateId, migrateSpells, spellDef, TOTAL_SPELLS, levelText, fusionOf, RES, UNDEAD, resistOf,
  SPELL_TIERS, spellTier, HEROES, STATS, STAT_NAMES, derive, statInfo, MILESTONES, msTier, statPtCost, lvPts, xpNeed, SLOTS, SLOT_NAMES, RARITY, rollGear, gearLines, gearScore, gearTotals, spellHits } from './arcana.js';

const params = new URLSearchParams(location.search);
const AUTO = params.has('auto');
const DMGLOG = params.has('dmglog') ? (window.__dmgByCol = {}) : null; // ?dmglog: damage dealt per hit colour (test sims attribute it to spells)
const FFWD = parseFloat(params.get('t') || '0');
const BENCH = params.has('bench');
const SPELLV = params.has('spells') && !AUTO && !BENCH; // ?spells: the spell viewer dev page (every spell on training dummies, one at a time; see spvStart). Built on the zoo: ZOO is on too
const ZOO = (params.has('zoo') || SPELLV) && !AUTO && !BENCH; // ?zoo: the monster zoo dev page (every foe's attack, one at a time; see zooStart). Nothing is saved in it
const START_FLOOR = parseInt(params.get('floor') || (BENCH ? '8' : ZOO ? '5' : '1'), 10);
const REC = parseFloat(params.get('rec') || '0');
const PROLOGUE = params.has('prologue') && !BENCH && !ZOO; // ?prologue=1: play the first-visit prologue every time (teaser recording)
// testing: ?spell=meteor,holybeam,momentum,judgment,spike (or any spell id) grants those spells at the start of a run; ?spelllv=5 sets their level
const DEBUG_SPELLS = (params.get('spell') || '').split(',').filter(Boolean).map((k) => (UNIQUE_SPELLS['u.' + k] ? 'u.' + k : (!k.includes('.') && SIG_IDS.find((x) => x.endsWith('.' + k))) || migrateId(k))).filter((id) => spellDef(id));
const DEBUG_SPELL_LV = Math.min(5, Math.max(1, +params.get('spelllv') || 1));
let seed = params.has('seed') ? +params.get('seed') : (Math.random() * 1e9) | 0;
function rand() {
  seed = (seed + 0x6D2B79F5) | 0;
  let t = seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const rr = (a, b) => a + rand() * (b - a);
const ri = (a, b) => Math.floor(rr(a, b + 1));
const pick = (a) => a[Math.floor(rand() * a.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const damp = (k, dt) => 1 - Math.exp(-k * dt);
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

// ---------- dungeon layout constants ----------
const RW = 11, RH = 13;                 // room interior in tiles
const PILLAR_H = 0.8;                   // room pillars stay low so monsters behind them are visible
const SX = RW + 2 + 5, SZ = RH + 2 + 5; // room grid spacing (5-tile corridors)
const GW = 7, GH = 7;
const MW = GW * SX, MH = GH * SZ;
const VOID = 0, FLOOR = 1, WALL = 2, BAR = 3, OBST = 4;
const TALL = 1.5, LOW = 0.55;

// ---------- DOM ----------
const $ = (id) => document.getElementById(id);
const app = $('app'), fxCanvas = $('fx'), fx = fxCanvas.getContext('2d'), lowEl = $('low');

// ---------- renderer / scene ----------
const MOBILE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && innerWidth < 900);
const renderer = new THREE.WebGLRenderer({ antialias: !MOBILE, // MSAA is expensive on phone GPUs (MOBILE_PERFORMANCE.md)
  powerPreference: 'high-performance', preserveDrawingBuffer: AUTO });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
// phones: real shadow maps cost ~25% of the frame; the blob shadows under everything are enough
renderer.shadowMap.enabled = !MOBILE && !params.has('noshadow');
renderer.shadowMap.type = THREE.PCFShadowMap;
$('view').appendChild(renderer.domElement);
const scene = new THREE.Scene();
const BG = 0x010103;
scene.background = new THREE.Color(BG);
scene.fog = new THREE.Fog(BG, 30, 46);
const camera = new THREE.PerspectiveCamera(36, 1, 0.5, 140);
const PITCH = 57 * Math.PI / 180;
let camDist = 28, W = 1, H = 1, DPR = 1;
// landscape (wider than ~1.1:1): the game fills the whole window instead of a portrait column. Everything landscape-only
// hangs off this flag and the html.land class; portrait is untouched.
let LAND = false;
const isLand = () => innerWidth > innerHeight * 1.1;

const hemi = new THREE.HemisphereLight(0x4a5c80, 0x0c0812, 0.28);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0x8fa6ff, 0.3); // cold moonlight through cracks
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -15, right: 15, top: 15, bottom: -15, near: 1, far: 60 });
sun.shadow.bias = -0.0006;
scene.add(sun, sun.target);
const pLight = new THREE.PointLight(0xe8d4ff, 18, 8, 1.5);
scene.add(pLight);
const torchLights = [0, 1, 2, 3].map(() => { const l = new THREE.PointLight(0xff7a2a, 14, 6.5, 1.7); scene.add(l); return l; });
const fxLight = new THREE.PointLight(0xffa040, 0, 9, 1.2);
scene.add(fxLight);
// phones: every point light is a loop in every lit pixel, so keep the player light and one torch; the other torches get
// painted light pools on the floor (torchPools) and spell flashes brighten the player light instead of fxLight
if (MOBILE) { for (const l of torchLights.slice(1)) scene.remove(l); scene.remove(fxLight); }

function resize() {
  LAND = isLand(); document.documentElement.classList.toggle('land', LAND); // before measuring: the class sets #app's size
  W = app.clientWidth; H = app.clientHeight; DPR = REC ? Math.min(3, 1080 / W) : Math.min(devicePixelRatio, MOBILE ? 1.35 : 1.5);
  renderer.setPixelRatio(DPR);
  renderer.setSize(W, H);
  camera.aspect = W / H;
  const vf = camera.fov * Math.PI / 180;
  const hf = 2 * Math.atan(Math.tan(vf / 2) * camera.aspect);
  camDist = Math.min(16.5 / (2 * Math.tan(hf / 2)), 22 / (2 * Math.tan(vf / 2)));
  if (LAND) camDist = 18 / (2 * Math.tan(vf / 2)); // a wide slice of the dungeon at a slightly closer, sprite-friendly height
  if (LAND) document.documentElement.style.setProperty('--lz', Math.min(1.7, Math.max(1, H / 640)).toFixed(3)); // UI scale on big screens
  scene.fog.near = camDist + 1; scene.fog.far = camDist + 11;
  camera.updateProjectionMatrix();
  fxCanvas.width = W * DPR; fxCanvas.height = H * DPR;
  glowMat.uniforms.uScale.value = (H * DPR) / (2 * Math.tan(vf / 2)); glowMat.uniforms.uDpr.value = DPR;
}

// ---------- pixel textures ----------
function canvasTex(w, h, draw, srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const hash = (x, y, s = 0) => { const n = Math.sin(x * 127.1 + y * 311.7 + s * 74.7) * 43758.5453; return n - Math.floor(n); };
function stonePixels(g, w, h, base, dark, s) {
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const n = hash(x, y, s);
    const v = base + (n - 0.5) * 22;
    g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(x, y, 1, 1);
  }
  g.fillStyle = `rgb(${dark},${dark},${dark})`;
}
const floorTex = canvasTex(16, 16, (g, w, h) => {
  stonePixels(g, w, h, 196, 120, 1);
  g.fillRect(0, 0, w, 1); g.fillRect(0, 0, 1, h);
  g.fillStyle = 'rgb(225,225,225)'; g.fillRect(1, 1, w - 1, 1); g.fillRect(1, 1, 1, h - 1);
  g.fillStyle = 'rgb(150,150,150)'; g.fillRect(1, h - 1, w - 1, 1); g.fillRect(w - 1, 1, 1, h - 1);
});
const floorTex2 = canvasTex(16, 16, (g, w, h) => {
  stonePixels(g, w, h, 190, 110, 2);
  g.fillRect(0, 0, w, 1); g.fillRect(0, 0, 1, h);
  g.fillStyle = 'rgb(140,140,140)';
  for (let i = 3; i < 13; i++) { g.fillRect(i, 3, 1, 1); g.fillRect(i, 12, 1, 1); g.fillRect(3, i, 1, 1); g.fillRect(12, i, 1, 1); }
  g.fillRect(6, 6, 4, 4); g.fillStyle = 'rgb(215,215,215)'; g.fillRect(7, 7, 2, 2);
});
const wallTex = canvasTex(16, 24, (g, w, h) => {
  stonePixels(g, w, h, 190, 110, 3);
  for (let r = 0; r < 4; r++) {
    const y = r * 6; g.fillStyle = 'rgb(110,110,110)'; g.fillRect(0, y, w, 1);
    const off = r % 2 ? 4 : 10; g.fillRect(off, y, 1, 6);
    g.fillStyle = 'rgb(222,222,222)'; g.fillRect(0, y + 1, w, 1);
  }
});
// torch brackets: their own material, since sharing the instanced walls' one made three.js re-resolve its program every frame
const bracketMat = new THREE.MeshLambertMaterial({ map: wallTex });
const plinthTex = canvasTex(16, 96, (g, w, h) => {
  stonePixels(g, w, h, 150, 80, 4);
  for (let r = 0; r < 12; r++) {
    const y = r * 8; g.fillStyle = 'rgb(70,70,70)'; g.fillRect(0, y, w, 1);
    g.fillRect(r % 2 ? 3 : 11, y, 1, 8);
  }
  const grd = g.createLinearGradient(0, 0, 0, h); grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, 'rgba(0,0,0,.85)');
  g.fillStyle = grd; g.fillRect(0, 0, w, h);
});
const runeTex = canvasTex(48, 48, (g, w, h) => {
  stonePixels(g, w, h, 170, 90, 5);
  g.strokeStyle = 'rgb(235,235,235)'; g.lineWidth = 2;
  g.strokeRect(4, 4, 40, 40); g.strokeRect(10, 10, 28, 28);
  g.beginPath(); g.moveTo(24, 6); g.lineTo(42, 24); g.lineTo(24, 42); g.lineTo(6, 24); g.closePath(); g.stroke();
  g.fillStyle = 'rgb(240,240,240)'; g.fillRect(21, 21, 6, 6);
  for (const [x, y] of [[4, 4], [40, 4], [4, 40], [40, 40]]) g.fillRect(x, y, 4, 4);
});
const glowTex = canvasTex(64, 64, (g) => {
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)'); grd.addColorStop(0.25, 'rgba(255,255,255,.6)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
});
glowTex.magFilter = THREE.LinearFilter;
const blobTex = canvasTex(32, 32, (g) => {
  const grd = g.createRadialGradient(16, 16, 0, 16, 16, 16);
  grd.addColorStop(0, 'rgba(0,0,0,.9)'); grd.addColorStop(0.6, 'rgba(0,0,0,.6)'); grd.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 32, 32);
});
blobTex.magFilter = THREE.LinearFilter;
const splatTex = canvasTex(32, 32, (g) => {
  g.fillStyle = '#fff';
  const blob = (x, y, r) => { for (let yy = -r; yy <= r; yy++) for (let xx = -r; xx <= r; xx++) if (xx * xx + yy * yy <= r * r) g.fillRect(Math.round(x + xx), Math.round(y + yy), 1, 1); };
  blob(16, 16, 6);
  for (let i = 0; i < 14; i++) { const a = i * 2.4, d = 5 + (i * 37 % 9); blob(16 + Math.cos(a) * d, 16 + Math.sin(a) * d, 1 + (i % 3)); }
});

const webTex = canvasTex(64, 64, (g) => {
  // web anchored in the top-left corner: radial threads + sagging rings
  g.strokeStyle = 'rgba(230,235,245,.75)'; g.lineWidth = 1;
  const rays = 6;
  for (let k = 0; k <= rays; k++) { const a = k / rays * Math.PI / 2; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * 64, Math.sin(a) * 64); g.stroke(); }
  for (let r = 10; r < 64; r += 9) {
    g.beginPath();
    for (let k = 0; k <= rays; k++) { const a = k / rays * Math.PI / 2, rr2 = r - (k % 2) * 3; const x = Math.cos(a) * rr2, y = Math.sin(a) * rr2; k ? g.lineTo(x, y) : g.moveTo(x, y); }
    g.stroke();
  }
}, true);
const fogTex = canvasTex(64, 64, (g) => {
  for (let k = 0; k < 18; k++) {
    const x = 10 + hash(k, 1) * 44, y = 10 + hash(k, 2) * 44, r = 8 + hash(k, 3) * 14;
    const grd = g.createRadialGradient(x, y, 0, x, y, r); grd.addColorStop(0, 'rgba(255,255,255,.35)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
  }
  // fade to nothing toward the edges (user 11-15: the fog's square edge showed): a round soft mask, alpha 0 at the border
  g.globalCompositeOperation = 'destination-in'; const m = g.createRadialGradient(32, 32, 6, 32, 32, 32);
  m.addColorStop(0, 'rgba(0,0,0,1)'); m.addColorStop(0.65, 'rgba(0,0,0,.6)'); m.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = m; g.fillRect(0, 0, 64, 64);
});
fogTex.magFilter = THREE.LinearFilter;

// ---------- sprite sheets ----------
const sheets = {};
// One main image per character; every bit of motion (hop, squash, waddle, flip) is done in code.
const SPRITE_H = { wizard: 0.95, slime: 0.62, eye: 0.72, imp: 0.8, skeleton: 1.0, boss: 2.5, bomber: 0.62, ghost: 0.8, shroom: 0.72, golem: 1.3, shrine: 1.2, mimic: 1.05, amazon: 0.95, berserker: 0.95, ranger: 0.95, necro: 0.95, elements: 0.6, gear: 0.6, tyrant: 3.0, sporemother: 2.8, wraith: 3.0, hollow: 2.6, stoneking: 3.2, mimiclord: 2.7, frostmatriarch: 3.1, sentinel: 3.0, items: 0.55, spells: 0.75, venom_glaive: 0.8 , holy_hammer: 1.1, razor_saw: 1.5, shadow_hand: 1, dragon: 2.6 };
// Armed foes are two sprites: the body and a separate hand + weapon (or a golem's front arm) that swings around the wrist /
// shoulder, so attacks are real swings (tools/make_parts.py cuts them; numbers from tools/raw_parts/parts.json).
// at: the pivot in the body sheet (u from the left, v from the bottom); pv: the same point in the part sheet; hr: part
// height / body height; tip: the weapon tip's angle (deg, painted pose) and reach (x part height); behind: drawn behind
// the body (the spear behind the shield). The part sheet is '<body>_w'.
const PARTS = {
  skeleton_b: { at: [0.844, 0.3081], pv: [0.1279, 0.2805], hr: 0.4386, tip: [47, 0.925] },
  skel_1: { at: [0.9362, 0.4212], pv: [0.05, 0.218], hr: 0.6352, tip: [62, 0.859] },
  skel_2: { at: [0.9854, 0.3769], pv: [0.1799, 0.3356], hr: 0.5123, tip: [59, 0.697] },
  skel_3: { at: [0.887, 0.5258], pv: [0.0416, 0.2936], hr: 0.5357, tip: [40, 1.044] },
  shieldk: { at: [0.9621, 0.4289], pv: [0.7055, 0.3527], hr: 0.2248, tip: [4, 0.5], behind: true },
  golem_b: { at: [0.9384, 0.5146], pv: [0.2278, 0.8776], hr: 0.4163, tip: [-66, 0.9] },
  golem_1: { at: [0.8768, 0.4914], pv: [0.3365, 0.879], hr: 0.461, tip: [-73, 0.875] },
  golem_2: { at: [0.9029, 0.4765], pv: [0.3767, 0.9004], hr: 0.3831, tip: [-97, 0.865] },
  golem_3: { at: [0.9747, 0.5078], pv: [0.3075, 0.8874], hr: 0.3929, tip: [-80, 0.858] },
  // bosses: the Bone Tyrant's greatsword hand; the Stone King's big near fist (on his back side: it swings up and forward over him)
  tyrant_b: { at: [0.9354, 0.2883], pv: [0.0661, 0.2254], hr: 0.6628, tip: [47, 1.04] },
  stoneking_b: { at: [0.126, 0.5537], pv: [0.5231, 0.8522], hr: 0.5891, tip: [-92, 0.75] },
};
// the 12 newer foes: skel_1 cursed warrior, skel_2 grave reaper, skel_3 bone knight, golem_1 rune, golem_2 crystal ruin,
// golem_3 obsidian magma; archer, spider, salamander, shieldk (shield knight), cultist, beetle. skeleton_b / golem_b are the
// old skeleton and golem without the sword hand / front arm (skeleton.png and golem.png stay for the death flash)
Object.assign(SPRITE_H, { tyrant_b: 3.0, stoneking_b: 3.2, skeleton_b: 1.0, golem_b: 1.3, skel_1: 1.05, skel_2: 1.0, skel_3: 1.15, golem_1: 1.4, golem_2: 1.4, golem_3: 1.45,
  archer: 1.0, spider: 0.55, salamander: 0.52, shieldk: 1.15, cultist: 1.0, beetle: 0.72 });
for (const [b, P] of Object.entries(PARTS)) SPRITE_H[b + '_w'] = SPRITE_H[b] * P.hr;
const WEBP_SHEETS = new Set(['mimiclord', 'frostmatriarch', 'sentinel', ...Object.keys(PARTS), ...Object.keys(PARTS).map((b) => b + '_w'), 'archer', 'spider', 'salamander', 'cultist', 'beetle', 'venom_glaive', 'holy_hammer', 'razor_saw', 'shadow_hand', 'dragon']); // newer art ships as WebP
const spriteURL = (name) => `sprites/${name}.${WEBP_SHEETS.has(name) ? 'webp' : 'png'}`;
const SHEET_FRAMES = { items: 6, spells: 6, elements: 8, gear: 6 };
function loadImg(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
function fallbackSheet(name, n = 1) {
  const c = document.createElement('canvas'); c.width = 16 * n; c.height = 16; // transparent until the real art loads
  return { canvas: c, frames: n, w: 16, h: 16 };
}
// load one sheet image into a canvas; retried, because a phone on a flaky connection can drop a request
async function loadSheetImage(name, frames, tries = 3) {
  for (let k = 0; k < tries; k++) {
    try {
      const img = await loadImg(spriteURL(name) + (k ? '?r=' + k + Date.now() % 100000 : '')); // the first try may come from the browser cache
      if (img.decode) await img.decode().catch(() => {}); // decode off the main thread, not inside drawImage
      const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      c.getContext('2d').drawImage(img, 0, 0);
      return { canvas: c, frames, w: Math.floor(img.width / frames), h: img.height };
    } catch (e) { await new Promise((r) => setTimeout(r, 400 * (k + 1))); }
  }
  return null;
}
const LATE_SHEETS = ['tyrant', 'tyrant_b', 'tyrant_b_w', 'sporemother', 'hollow', 'mimiclord', 'frostmatriarch', 'sentinel']; // bosses of the deeper floors; not needed to start playing
// First visit: the prologue's art (tier 1) loads behind the LOADING bar before it starts; everything else follows at
// idle during the prologue (tier 2). A floor whose art isn't in yet waits behind a short loading overlay (loadGate),
// then drops in normally: a fall is never held.
const PRO_SHEETS = new Set(['necro', 'stoneking', 'stoneking_b', 'stoneking_b_w', 'slime', 'eye', 'skeleton', 'skeleton_b', 'skeleton_b_w', 'imp', 'ghost', 'golem', 'golem_b', 'golem_b_w', 'items', 'gear', 'spells', 'elements', 'shrine']);
const PRO_PORTRAITS = ['vesper', 'pip'], LATE_PORTRAITS = ['pip_shock', 'vesper_evil'];
const pending = new Set(); // sheets still showing placeholder art
// the menu is up (and PLAY tappable) before loadSheets has made every sheet: a run asked for before that waits for it
// (a quick tap on PLAY on a slow phone used to crash in makeSprite: sheets[name] undefined)
let sheetsIn = false, sheetsInRes; const sheetsInP = new Promise((r) => { sheetsInRes = r; });
function whenArt(fn) { if (sheetsIn) return false; if (!whenArt.q) sheetsInP.then(() => { const f = whenArt.q; whenArt.q = null; f(); }); whenArt.q = fn; return true; }
let tier1 = Promise.resolve(), tier1Done = true;
const sheetTip = (name, s) => { if (name === 'wizard') s.tip = findStaffTip(s.canvas); else if (['amazon', 'berserker', 'ranger', 'necro'].includes(name)) s.tip = findWeaponTip(s.canvas); };
async function loadSheets(proFirst = false) {
  let man = {};
  try { man = await (await fetch('sprites/manifest.json', { cache: 'no-cache' })).json(); } catch (e) { /* fallback art */ }
  const later1 = [], later2 = [];
  await Promise.all(Object.keys(SPRITE_H).map(async (name) => {
    const frames = SHEET_FRAMES[name] || (man[name] ? man[name].frames : 1);
    const t1 = proFirst && PRO_SHEETS.has(name), t2 = proFirst && name !== 'wizard' && !t1;
    const late = t1 || t2 || LATE_SHEETS.includes(name) && !(meta.fairy && FAIRY[meta.fairy] && FAIRY[meta.fairy].sheet === name); // your fairy loads up front
    let s = late ? null : await loadSheetImage(name, frames); // late: placeholder now, real art in the background
    const failed = !s;
    s = s || fallbackSheet(name, frames);
    const tex = new THREE.CanvasTexture(s.canvas);
    tex.magFilter = THREE.LinearFilter; tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.generateMipmaps = true; tex.anisotropy = 4;
    s.tex = tex;
    sheetTip(name, s);
    sheets[name] = s;
    if (failed) pending.add(name);
    if (t1) later1.push({ name, frames }); else if (t2) later2.push({ name, frames }); else if (failed) retrySheet(name, frames);
  }));
  sheetsIn = true; sheetsInRes();
  if (!proFirst) { const logo = $('titleLogo'); if (logo && !logo.src) logo.src = logo.dataset.src; document.documentElement.classList.remove('noart'); return; }
  // tier 1 now, in parallel, behind the LOADING bar: the prologue starts once it is in
  tier1Done = false;
  const n1 = later1.length + PRO_PORTRAITS.length; let d1 = 0;
  const step = () => { d1++; loadBar($('autoLoad'), d1 / n1); };
  loadBar($('autoLoad'), 0);
  tier1 = Promise.all([...later1.map(async ({ name, frames }) => { const r = await loadSheetImage(name, frames, 4); if (r) swapSheet(name, r); else retrySheet(name, frames); step(); }),
    ...PRO_PORTRAITS.map((f) => loadImg(`portraits/${f}.webp`).catch(() => {}).then(step))]).then(() => { tier1Done = true; });
  await tier1;
  // tier 2 in the background, one at a time when the main thread is idle, so the prologue never stutters
  (async () => {
    const idle = () => new Promise((r) => (window.requestIdleCallback ? requestIdleCallback(r, { timeout: 600 }) : setTimeout(r, 50)));
    for (const f of LATE_PORTRAITS) { await idle(); await loadImg(`portraits/${f}.webp`).catch(() => {}); }
    for (const { name, frames } of later2) { await idle(); const r = await loadSheetImage(name, frames, 4); if (r) swapSheet(name, r); else retrySheet(name, frames); }
    await idle(); const logo = $('titleLogo'); if (logo && !logo.src) logo.src = logo.dataset.src; // the menu logo and art come last
    await idle(); document.documentElement.classList.remove('noart'); // the hidden menu won't fetch it by itself, so warm the cache
    loadImg(document.documentElement.classList.contains('land') ? 'sprites/title_A_land.webp' : 'sprites/title_A_port.webp').catch(() => {});
  })();
}
// real art arrived: sprites share the texture, and the ones made from the placeholder get the right width
function swapSheet(name, r) {
  const s = sheets[name];
  Object.assign(s, { canvas: r.canvas, w: r.w, h: r.h }); sheetTip(name, s);
  s.tex.image = r.canvas; s.tex.needsUpdate = true;
  scene.traverse((m) => { const u = m.userData; if (u.sheet === name && u.bh) { const sy = m.scale.y / u.bh; u.bw = u.bh * s.w / s.h; m.scale.x = u.bw * sy; } });
  pending.delete(name);
}
// keep trying in the background and swap the real art in when it arrives
function retrySheet(name, frames) {
  setTimeout(async () => {
    const r = await loadSheetImage(name, frames, 2);
    if (!r) return retrySheet(name, frames);
    swapSheet(name, r);
  }, 2500);
}
// may Pip land? The prologue needs its own art; a floor needs everything except the bosses it won't meet
function fallNeeds() {
  if (G.prologue) return tier1Done ? [] : ['prologue'];
  const bossSheet = G.boss && G.floor % 3 === 0 && ((ENEMY[G.boss.type] && ENEMY[G.boss.type].sheet) || G.boss.type); // boss floors only
  const bossBody = bossSheet && ENEMY[G.boss.type] && ENEMY[G.boss.type].body; // a boss with a swinging part needs its body + part sheets too
  return [...pending].filter((n) => !LATE_SHEETS.includes(n) || n === bossSheet || (bossBody && (n === bossBody || n === bossBody + '_w')));
}
const SLOWLOAD = +params.get('slowload') || 0; // testing: ?slowload=4 keeps each floor's art "loading" for 4 s, to see the overlay
const fallReady = () => !fallNeeds().length && !(G.slowUntil > performance.now());
// "LOADING..." with a thin progress bar under it (the first-visit title and the floor overlay share it)
function loadBar(el, f) {
  if (!el) return;
  let b = el.querySelector('.bar'); if (!b) { b = document.createElement('span'); b.className = 'bar'; b.innerHTML = '<i></i>'; el.appendChild(b); }
  b.firstChild.style.width = Math.round(100 * Math.min(1, f)) + '%';
}
// a floor whose art isn't in yet: a plain loading overlay over the floor until it is, then the normal drop
function loadGate(on) {
  let el = $('loadGate');
  if (!on) { if (el) el.classList.remove('on'); return; }
  if (!el) { el = document.createElement('div'); el.id = 'loadGate'; el.innerHTML = '<p>LOADING...</p>'; $('app').appendChild(el); G.gateN = fallNeeds().length || 1; }
  const p = el.querySelector('p'), left = fallNeeds().length;
  loadBar(p, SLOWLOAD && !left ? Math.min(0.95, (G.fallT || 0) / SLOWLOAD) : 1 - left / Math.max(G.gateN || 1, left, 1));
  el.classList.add('on');
}
function findStaffTip(c) {
  try {
    const w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data;
    const pts = [];
    // the crystal is lavender-pink (blue about as strong as red); the hat is a warmer pink, so it is skipped
    for (let y = 0; y < h * 0.7; y++) for (let x = Math.floor(w * 0.6); x < w; x++) {
      const k = (y * w + x) * 4, r = d[k], b = d[k + 2], a = d[k + 3];
      if (a > 200 && b > 190 && r > 170 && b > r * 0.85) pts.push([x, y]);
    }
    if (!pts.length) return [0.82, 0.78];
    const top = Math.min(...pts.map((q) => q[1])), near = pts.filter((q) => q[1] < top + h * 0.15);
    const cx = near.reduce((a, q) => a + q[0], 0) / near.length, cy = near.reduce((a, q) => a + q[1], 0) / near.length;
    return [cx / w, 1 - cy / h];
  } catch (e) { return [0.82, 0.78]; }
}
// the highest point on the right side of a hero sprite (spear tip, axe head, bow tip, skull)
function findWeaponTip(c) {
  try {
    const w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data;
    let top = h;
    for (let y = 0; y < h && top === h; y++) for (let x = Math.floor(w * 0.6); x < w; x++) if (d[(y * w + x) * 4 + 3] > 200) { top = y; break; }
    let sx = 0, n = 0;
    for (let y = top; y < Math.min(h, top + h * 0.08); y++) for (let x = Math.floor(w * 0.6); x < w; x++) if (d[(y * w + x) * 4 + 3] > 200) { sx += x; n++; }
    return n ? [sx / n / w, 1 - (top + h * 0.04) / h] : [0.82, 0.78];
  } catch (e) { return [0.82, 0.78]; }
}
// the treasure chest as a plain file (items sheet frame 4): every chest reveal and chest button uses it, so the chest shows even
// before the sheets load or when the phone refuses a new canvas (iOS caps total canvas memory: toDataURL then gives a blank image)
const CHEST_IMG = 'icons/chest.webp';
const sheetIconCache = new Map(); // sheet canvas -> 'i:size' -> data URL: one small canvas per icon, not one per menu render
// the fixed icon sheets ship pre-cut as square WebP frames (icons/frames/<sheet>_<i>.webp, tools: cut from sprites/<sheet>.png),
// so hearts, coins, relics, upgrades, empty gear slots and element chips never depend on a runtime canvas either
const FRAME_SHEETS = { items: 6, gear: 6, spells: 6, elements: 8 };
function iconURL(sheet, i, size = 64) {
  if (FRAME_SHEETS[sheet] > i && i >= 0) return `icons/frames/${sheet}_${i}.webp`;
  const s = sheets[sheet];
  if (!s) return ''; // still loading
  let m = sheetIconCache.get(s.canvas); const key = i + ':' + size;
  if (m && m.has(key)) return m.get(key);
  const c = document.createElement('canvas'); c.width = size; c.height = size;
  const g = c.getContext('2d'); if (!g) return '';
  g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
  const k = size / Math.max(s.w, s.h);
  g.drawImage(s.canvas, i * s.w, 0, s.w, s.h, (size - s.w * k) / 2, (size - s.h * k) / 2, s.w * k, s.h * k);
  const u = c.toDataURL(); c.width = c.height = 0; // hand the backing store back right away
  if (u.length < 32) return ''; // 'data:,' = no canvas memory left
  if (!pending.has(sheet)) { if (!m) sheetIconCache.set(s.canvas, m = new Map()); m.set(key, u); } // placeholder art isn't cached
  return u;
}

const spriteGeo = new THREE.PlaneGeometry(1, 1).translate(0, 0.5, 0);
const spriteVS = `
uniform float uFrame, uFrames, uFlip, uBias;
varying vec2 vUv;
void main(){
  vec2 u = uv; if (uFlip > 0.5) u.x = 1.0 - u.x;
  vUv = vec2((uFrame + u.x) / uFrames, u.y);
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  mv.z += uBias;
  gl_Position = projectionMatrix * mv;
}`;
const spriteFS = `
uniform sampler2D uMap; uniform float uFlash, uAlpha, uRim, uFrames; uniform vec3 uTint, uFlashCol, uRimCol;
varying vec2 vUv;
void main(){
  vec4 c = texture2D(uMap, vUv);
  if (c.a < 0.04) discard;
  vec3 col = c.rgb * uTint;
  #ifdef RIM
  { /* rim light: the art's outer edge glows (dark foes on dark floors); a define, so other sprites don't pay the 4 extra fetches */
    float ox = 0.035 / uFrames, oy = 0.03;
    float n = min(min(texture2D(uMap, vUv + vec2(ox, 0.0)).a, texture2D(uMap, vUv - vec2(ox, 0.0)).a), min(texture2D(uMap, vUv + vec2(0.0, oy)).a, texture2D(uMap, vUv - vec2(0.0, oy)).a));
    col = mix(col, uRimCol, uRim * (1.0 - n));
  }
  #endif
  gl_FragColor = vec4(mix(col, uFlashCol, uFlash), c.a * uAlpha);
}`;
function makeSprite(name, height = SPRITE_H[name], frame = 0) {
  const s = sheets[name];
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uMap: { value: s.tex }, uFrame: { value: frame }, uFrames: { value: s.frames }, uFlip: { value: 0 }, uBias: { value: 1.1 },
      uFlash: { value: 0 }, uAlpha: { value: 1 }, uTint: { value: new THREE.Color(1, 1, 1) }, uFlashCol: { value: new THREE.Color(1, 1, 1) }, uRim: { value: 0 }, uRimCol: { value: new THREE.Color(1, 1, 1) },
    },
    vertexShader: spriteVS, fragmentShader: spriteFS, alphaToCoverage: true,
  });
  const m = new THREE.Mesh(spriteGeo, mat);
  m.userData.bw = height * s.w / s.h; m.userData.bh = height; m.userData.sheet = name; // sheet: swapSheet fixes the width when real art replaces a placeholder
  m.scale.set(m.userData.bw, height, 1);
  m.frustumCulled = false;
  scene.add(m);
  return m;
}
function setSpriteScale(m, sx = 1, sy = 1) { m.scale.set(m.userData.bw * sx, m.userData.bh * sy, 1); }
// face the camera, then lean around the feet (the plane's origin is at the bottom centre)
function billboard(m, tilt = 0) { m.quaternion.copy(camera.quaternion); if (tilt) m.rotateZ(tilt); }
function killMesh(m) { if (!m) return; scene.remove(m); if (m.material && m.material.isShaderMaterial) m.material.dispose(); }
// the art's real top (share of the sheet height up from the bottom), measured once from the alpha: a sheet with empty rows on
// top would put an HP bar in the air, and a bar at the sprite height alone sat on raised weapons / crests
function sheetTop(name) {
  const s = sheets[name];
  if (!s || pending.has(name) || !s.canvas || !s.canvas.getContext) return 1;
  if (s.topF === undefined) {
    s.topF = 1;
    try {
      const g = s.canvas.getContext('2d', { willReadFrequently: true }), W = s.w || s.canvas.width, H = s.canvas.height;
      for (let y = 0; y < H; y += 4) { const a = g.getImageData(0, y, W, Math.min(4, H - y)).data; let hit = false; for (let i = 3; i < a.length; i += 4) if (a[i] > 60) { hit = true; break; } if (hit) { s.topF = 1 - y / H; break; } }
    } catch (err) { s.topF = 1; }
  }
  return s.topF;
}
const barRects = []; // this frame's HP bars (x, y, w), so a stacked foe's bar steps up instead of overlapping
// height of a foe's top along the sprite's up axis (body art + the weapon / arm part at rest), for its HP bar
function foeTop(e) {
  const u = e.mesh.userData; let h = u.bh * sheetTop(u.sheet);
  if (e.wpn && PARTS[e.body]) { const P = PARTS[e.body], wu = e.wpn.userData; h = Math.max(h, P.at[1] * u.bh + (sheetTop(wu.sheet) - P.pv[1]) * wu.bh); }
  return h;
}

// ---------- batched blob shadows and glows: one instanced draw each instead of a mesh / sprite (and material) per object ----------
// makeShadow / makeGlow hand out stand-ins: plain Object3Ds in the scene, so scene.remove, visible, position and scale work as
// before, and a glow's fake .material keeps color / opacity / depthTest. flushBatches() packs the live ones right before each render.
// every see-through ground decal (shadows, rings, markers, pools) is pulled toward the camera by a few depth steps. Units count
// in the depth buffer's own steps, so this holds on phones with a coarse (16-bit-ish) buffer, where a few mm of height didn't.
const DECAL = { polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -6 };
const shadowGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
const shadowMat = new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, color: 0x000000, opacity: 0.5, ...DECAL });
const MAXB = 640;
const shadowBatch = new THREE.InstancedMesh(shadowGeo, shadowMat, MAXB);
shadowBatch.instanceMatrix.setUsage(THREE.DynamicDrawUsage); shadowBatch.frustumCulled = false; shadowBatch.renderOrder = 1; shadowBatch.count = 0;
scene.add(shadowBatch);
// the glow quad faces the camera in the vertex shader (like THREE.Sprite); size = the instance's x / y scale
const glowQuadMat = (top) => new THREE.ShaderMaterial({
  uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uMap: { value: null } }]),
  vertexShader: `attribute vec4 aCol; varying vec4 vC; varying vec2 vUv;
    #include <fog_pars_vertex>
    void main(){ vUv = uv; vC = aCol; vec4 mvPosition = modelViewMatrix * vec4(instanceMatrix[3].xyz, 1.0);
      vec2 gs = vec2(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz)); mvPosition.xy += position.xy * gs; gl_Position = projectionMatrix * mvPosition;
      /* depth only, pulled toward the camera by ~the quad's half height: a camera-facing quad near the ground cut into the floor
         along a screen-horizontal line, and on lava that line z-fought into stripes. Screen position is unchanged. */
      vec4 pc = projectionMatrix * vec4(mvPosition.xy, min(mvPosition.z + gs.y * 0.75, -0.6), 1.0); gl_Position.z = pc.z / pc.w * gl_Position.w;
      #include <fog_vertex>
    }`,
  fragmentShader: `uniform sampler2D uMap; varying vec4 vC; varying vec2 vUv;
    #include <fog_pars_fragment>
    void main(){ vec4 t = texture2D(uMap, vUv); gl_FragColor = vec4(vC.rgb * t.rgb, vC.a * t.a);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      #include <fog_fragment>
    }`,
  blending: THREE.AdditiveBlending, depthWrite: false, depthTest: !top, transparent: true, fog: true,
});
function glowBatchOf(top) {
  const mat = glowQuadMat(top); mat.uniforms.uMap.value = glowTex;
  const m = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), mat, MAXB);
  m.geometry.setAttribute('aCol', new THREE.InstancedBufferAttribute(new Float32Array(MAXB * 4), 4).setUsage(THREE.DynamicDrawUsage));
  m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0;
  m.renderOrder = top ? 10 : -1; // world glows before the room shrouds (they hide unvisited rooms); top ones over the wizard
  scene.add(m); return m;
}
const glowBatch = glowBatchOf(false), glowTopBatch = glowBatchOf(true);
// phones only (they keep one torch light): a soft additive pool on the floor under every other torch
const torchPools = MOBILE ? new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2),
  new THREE.MeshBasicMaterial({ map: glowTex, color: 0xff7a2a, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }), MAXB) : null;
if (torchPools) { torchPools.instanceMatrix.setUsage(THREE.DynamicDrawUsage); torchPools.frustumCulled = false; torchPools.count = 0; torchPools.renderOrder = -1; scene.add(torchPools); }
let shadowsLive = [], glowsLive = [];
const bMat = new THREE.Matrix4();
function makeShadow(size) { const m = new THREE.Object3D(); m.matrixAutoUpdate = false; m.scale.set(size, 1, size * 0.8); m.position.y = 0.04; scene.add(m); shadowsLive.push(m); return m; }
function makeGlow(color, size, opacity = 1) {
  const m = new THREE.Object3D(); m.matrixAutoUpdate = false; /* placeholders: flushBatches builds their matrix, so the scene walk skips ~300 of them */ m.material = { color: new THREE.Color(color), opacity, depthTest: true, dispose() {} };
  m.scale.set(size, size, 1); scene.add(m); glowsLive.push(m); return m;
}
function killGlow(m) { if (!m) return; scene.remove(m); }
const placeOf = (o) => { if (o.parent === scene) return bMat.compose(o.position, o.quaternion, o.scale); o.updateMatrix(); o.updateWorldMatrix(true, false); return o.matrixWorld; };
function flushBatches() {
  let n = 0;
  shadowsLive = shadowsLive.filter((o) => o.parent);
  for (const o of shadowsLive) if (o.visible && n < MAXB) shadowBatch.setMatrixAt(n++, placeOf(o));
  shadowBatch.count = n; shadowBatch.instanceMatrix.needsUpdate = true;
  glowsLive = glowsLive.filter((o) => o.parent);
  const ns = [0, 0];
  for (const o of glowsLive) {
    const mt = o.material; if (!o.visible || mt.opacity <= 0) continue;
    const top = mt.depthTest === false ? 1 : 0, b = top ? glowTopBatch : glowBatch, k = ns[top]; if (k >= MAXB) continue;
    b.setMatrixAt(k, placeOf(o)); b.geometry.attributes.aCol.setXYZW(k, mt.color.r, mt.color.g, mt.color.b, mt.opacity); ns[top]++;
  }
  for (const [b, k] of [[glowBatch, ns[0]], [glowTopBatch, ns[1]]]) { b.count = k; b.instanceMatrix.needsUpdate = true; b.geometry.attributes.aCol.needsUpdate = true; }
}

// ---------- ground effects: "bright soft spell = mine, dark spiky pool = danger" ----------
// Pip's own patches look like the spell itself: fire = a glowing ember scorch with real flame tongues licking up (additive);
// venom = a glossy bright-green puddle with a light rim and a highlight; Toxic Cloud = drifting soft gas puffs. No hard
// edges, no rings. Hazards that hurt Pip (spore gas, vent puffs) get a dark murky pool with a jagged black rim.
// One instanced draw each, refilled every frame by gfxBegin / gfxPut / gfxFlame / gfxEnd (no allocations).
function blobPath(g, R, w) { // a wobbly closed blob of radius ~R
  g.beginPath();
  for (let k = 0; k <= 48; k++) { const a = k / 48 * 6.2832, r = R * (1 + w * (0.55 * Math.sin(3 * a + 1) + 0.35 * Math.sin(5 * a + 2.3) + 0.25 * Math.sin(7 * a + 0.4))); k ? g.lineTo(Math.cos(a) * r, Math.sin(a) * r) : g.moveTo(Math.cos(a) * r, Math.sin(a) * r); }
  g.closePath();
}
const emberTex = canvasTex(128, 128, (g) => { // scorched ground glowing from below: soft orange heat, golden ember cracks
  g.translate(64, 64);
  for (let k = 0; k < 7; k++) { // soft lumpy heat blotches, no hard edge
    const a = hash(k, 31) * 6.2832, d = k ? 14 + hash(k, 32) * 22 : 0, rr = k ? 26 + hash(k, 33) * 12 : 46;
    const x = Math.cos(a) * d, y = Math.sin(a) * d, grd = g.createRadialGradient(x, y, 0, x, y, rr);
    grd.addColorStop(0, 'rgba(255,120,30,0.55)'); grd.addColorStop(0.6, 'rgba(200,50,8,0.3)'); grd.addColorStop(1, 'rgba(120,20,0,0)');
    g.fillStyle = grd; g.beginPath(); g.arc(x, y, rr, 0, 6.2832); g.fill();
  }
  g.lineCap = 'round';
  for (let k = 0; k < 9; k++) { // glowing cracks wandering out from the middle
    let a = hash(k, 41) * 6.2832, x = Math.cos(a) * 6, y = Math.sin(a) * 6;
    g.beginPath(); g.moveTo(x, y);
    for (let s = 0; s < 6; s++) { a += (hash(k, s + 50) - 0.5) * 1.2; x += Math.cos(a) * 7; y += Math.sin(a) * 7; g.lineTo(x, y); }
    g.strokeStyle = 'rgba(255,140,30,0.5)'; g.lineWidth = 5; g.stroke();
    g.strokeStyle = 'rgba(255,230,120,0.9)'; g.lineWidth = 1.8; g.stroke();
  }
  for (let k = 0; k < 16; k++) { const a = hash(k, 61) * 6.2832, d = hash(k, 62) * 40; g.fillStyle = k % 3 ? 'rgba(255,190,60,0.85)' : 'rgba(255,250,200,0.95)'; g.beginPath(); g.arc(Math.cos(a) * d, Math.sin(a) * d, 1.2 + hash(k, 63) * 1.8, 0, 6.2832); g.fill(); }
});
emberTex.magFilter = THREE.LinearFilter;
// puddle data texture: R = body lightness (lighter toward the rim), G = glossy highlight, A = coverage (soft edge)
const poolTex = canvasTex(128, 128, (g) => {
  g.translate(64, 64);
  g.fillStyle = 'rgba(255,0,0,0.22)'; blobPath(g, 55, 0.07); g.fill(); // soft outer fringe
  g.fillStyle = 'rgba(255,0,0,0.45)'; blobPath(g, 52, 0.07); g.fill();
  const grd = g.createRadialGradient(-6, -6, 0, 0, 0, 50);
  grd.addColorStop(0, 'rgb(130,0,0)'); grd.addColorStop(0.75, 'rgb(170,0,0)'); grd.addColorStop(1, 'rgb(255,0,0)');
  g.fillStyle = grd; blobPath(g, 49, 0.07); g.fill();
  g.strokeStyle = 'rgba(255,0,0,0.9)'; g.lineWidth = 3; blobPath(g, 47, 0.07); g.stroke(); // bright wet rim
  g.globalCompositeOperation = 'lighter'; // highlights go into G only
  g.save(); g.translate(-17, -20); g.rotate(-0.6); g.scale(1, 0.42);
  const hl = g.createRadialGradient(0, 0, 0, 0, 0, 17); hl.addColorStop(0, 'rgba(0,255,0,1)'); hl.addColorStop(0.5, 'rgba(0,200,0,0.75)'); hl.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = hl; g.beginPath(); g.arc(0, 0, 17, 0, 6.2832); g.fill(); g.restore();
  g.fillStyle = 'rgba(0,255,0,0.9)'; g.beginPath(); g.arc(8, -27, 3, 0, 6.2832); g.fill(); g.beginPath(); g.arc(22, 16, 2.2, 0, 6.2832); g.fill();
  g.fillStyle = 'rgba(0,120,0,0.6)'; g.beginPath(); g.ellipse(14, 26, 12, 3, -0.3, 0, 6.2832); g.fill();
}, false);
poolTex.magFilter = THREE.LinearFilter;
const hazardTex = canvasTex(128, 128, (g) => {
  g.translate(64, 64);
  const N = 22; g.beginPath();
  for (let k = 0; k < N * 2; k++) { const a = k / (N * 2) * 6.2832, r = k % 2 ? 46 + hash(k, 1) * 6 : 57 + hash(k, 2) * 5; k ? g.lineTo(Math.cos(a) * r, Math.sin(a) * r) : g.moveTo(Math.cos(a) * r, Math.sin(a) * r); }
  g.closePath();
  const grd = g.createRadialGradient(0, 0, 0, 0, 0, 58);
  grd.addColorStop(0, 'rgba(200,200,200,0.55)'); grd.addColorStop(0.75, 'rgba(120,120,120,0.8)'); grd.addColorStop(1, 'rgba(40,40,40,0.9)');
  g.fillStyle = grd; g.fill();
  g.strokeStyle = 'rgba(0,0,0,0.95)'; g.lineWidth = 5; g.stroke();
  g.fillStyle = 'rgba(0,0,0,0.35)';
  for (let k = 0; k < 8; k++) { const a = hash(k, 5) * 6.2832, d = hash(k, 6) * 34; g.beginPath(); g.arc(Math.cos(a) * d, Math.sin(a) * d, 4 + hash(k, 7) * 7, 0, 6.2832); g.fill(); }
});
hazardTex.magFilter = THREE.LinearFilter;
const flameTex = canvasTex(64, 128, (g) => { // one flame tongue: white-yellow core at the base, orange body, red wispy tip
  const tongue = (w, top, wob) => { g.beginPath(); g.moveTo(32, top);
    g.bezierCurveTo(32 + w * 0.35 + wob, top + 34, 32 + w, 78, 32 + w * 0.8, 104); g.bezierCurveTo(32 + w * 0.6, 126, 32 - w * 0.6, 126, 32 - w * 0.8, 104);
    g.bezierCurveTo(32 - w, 78, 32 - w * 0.25 + wob, top + 40, 32, top); g.closePath(); };
  let grd = g.createLinearGradient(0, 4, 0, 124);
  grd.addColorStop(0, 'rgba(200,30,0,0)'); grd.addColorStop(0.3, 'rgba(240,70,10,0.75)'); grd.addColorStop(0.75, 'rgba(255,130,30,1)'); grd.addColorStop(1, 'rgba(255,150,40,0.6)');
  g.fillStyle = grd; tongue(26, 4, 8); g.fill();
  grd = g.createLinearGradient(0, 34, 0, 124);
  grd.addColorStop(0, 'rgba(255,190,60,0)'); grd.addColorStop(0.45, 'rgba(255,210,80,0.9)'); grd.addColorStop(1, 'rgba(255,230,120,0.8)');
  g.fillStyle = grd; tongue(16, 34, 4); g.fill();
  grd = g.createLinearGradient(0, 66, 0, 124);
  grd.addColorStop(0, 'rgba(255,255,230,0)'); grd.addColorStop(0.5, 'rgba(255,252,225,1)'); grd.addColorStop(1, 'rgba(255,245,200,0.7)');
  g.fillStyle = grd; tongue(8, 66, 1); g.fill();
});
flameTex.magFilter = THREE.LinearFilter;
const puffTex = canvasTex(64, 64, (g) => { // a soft lumpy gas puff (tinted per instance)
  for (let k = 0; k < 6; k++) {
    const x = 32 + (hash(k, 71) - 0.5) * 22, y = 34 + (hash(k, 72) - 0.5) * 18, r = 13 + hash(k, 73) * 9;
    const grd = g.createRadialGradient(x, y - 3, 0, x, y, r);
    grd.addColorStop(0, 'rgba(255,255,255,0.55)'); grd.addColorStop(0.6, 'rgba(225,225,225,0.3)'); grd.addColorStop(1, 'rgba(200,200,200,0)');
    g.fillStyle = grd; g.beginPath(); g.arc(x, y, r, 0, 6.2832); g.fill();
  }
});
puffTex.magFilter = THREE.LinearFilter;
function groundBatch(tex, additive, max, frag) { // flat decals on the floor
  const mat = new THREE.ShaderMaterial({
    uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uMap: { value: null } }]),
    vertexShader: `attribute vec4 aCol; varying vec4 vC; varying vec2 vUv;
      #include <fog_pars_vertex>
      void main(){ vUv = uv; vC = aCol; vec4 mvPosition = modelViewMatrix * instanceMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: `uniform sampler2D uMap; varying vec4 vC; varying vec2 vUv;
      #include <fog_pars_fragment>
      void main(){ vec4 t = texture2D(uMap, vUv); ${frag || 'gl_FragColor = vec4(vC.rgb * t.rgb, vC.a * t.a);'}
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #include <fog_fragment>
      }`,
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, depthWrite: false, transparent: true, fog: true,
    ...DECAL,
  });
  mat.uniforms.uMap.value = tex;
  const m = new THREE.InstancedMesh(new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2), mat, max);
  m.geometry.setAttribute('aCol', new THREE.InstancedBufferAttribute(new Float32Array(max * 4), 4).setUsage(THREE.DynamicDrawUsage));
  m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; m.renderOrder = -1;
  m.userData.n = 0; m.userData.max = max; scene.add(m); return m;
}
function billboardBatch(tex, additive, max) { // upright camera-facing quads anchored at their base (flame tongues, gas puffs)
  // instance matrix layout (written by gfxFlame): [0] width, [4] sway (tip shear), [5] height, [12..14] base position
  const mat = new THREE.ShaderMaterial({
    uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uMap: { value: null } }]),
    vertexShader: `attribute vec4 aCol; varying vec4 vC; varying vec2 vUv;
      #include <fog_pars_vertex>
      void main(){ vUv = uv; vC = aCol; vec4 mvPosition = modelViewMatrix * vec4(instanceMatrix[3].xyz, 1.0);
        mvPosition.xy += vec2(position.x * instanceMatrix[0][0] + position.y * position.y * instanceMatrix[1][0], position.y * instanceMatrix[1][1]);
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: `uniform sampler2D uMap; varying vec4 vC; varying vec2 vUv;
      #include <fog_pars_fragment>
      void main(){ vec4 t = texture2D(uMap, vUv); gl_FragColor = vec4(vC.rgb * t.rgb, vC.a * t.a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #include <fog_fragment>
      }`,
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, depthWrite: false, transparent: true, fog: true,
  });
  mat.uniforms.uMap.value = tex;
  const m = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).translate(0, 0.5, 0), mat, max);
  m.geometry.setAttribute('aCol', new THREE.InstancedBufferAttribute(new Float32Array(max * 4), 4).setUsage(THREE.DynamicDrawUsage));
  m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0;
  m.userData.n = 0; m.userData.max = max; scene.add(m); return m;
}
const hazardBatch = groundBatch(hazardTex, false, 48), emberBatch = groundBatch(emberTex, true, 80);
// puddle: tinted body, lighter rim, white gloss on top
const poolBatch = groundBatch(poolTex, false, 64, 'gl_FragColor = vec4(vC.rgb * (0.5 + 0.75 * t.r) + vec3(0.92, 1.0, 0.9) * t.g * 0.85, vC.a * t.a);');
emberBatch.renderOrder = poolBatch.renderOrder = 0; // Pip's burning ground / puddles draw after the splats, scorch and torch pools (-1): always on top of decals
const flameBatch = billboardBatch(flameTex, true, MOBILE ? 110 : 180), puffBatch = billboardBatch(puffTex, false, 80); // 80: Toxic Clouds + gas vents (up to 5 puffs each)
// a cast field's hit area (user 11-15: Toxic Cloud "needs to be clear where is affected"): a faint fill that brightens
// toward the edge, a thin solid rim and brighter dashes, all at the texture's edge = exactly the field's hit radius
const zoneTex = canvasTex(128, 128, (g) => {
  g.translate(64, 64);
  const grd = g.createRadialGradient(0, 0, 0, 0, 0, 62);
  grd.addColorStop(0, 'rgba(255,255,255,0.03)'); grd.addColorStop(0.65, 'rgba(255,255,255,0.09)'); grd.addColorStop(1, 'rgba(255,255,255,0.26)');
  g.fillStyle = grd; g.beginPath(); g.arc(0, 0, 62, 0, 6.2832); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = 2; g.beginPath(); g.arc(0, 0, 61, 0, 6.2832); g.stroke();
  g.strokeStyle = '#fff'; g.lineWidth = 4.5; g.lineCap = 'round';
  for (let k = 0; k < 18; k++) { const a = k * 6.2832 / 18; g.beginPath(); g.arc(0, 0, 60.5, a, a + 0.19); g.stroke(); }
}, false);
zoneTex.magFilter = THREE.LinearFilter;
const zoneBatch = groundBatch(zoneTex, true, 24); zoneBatch.renderOrder = 0;
const gfxM = new THREE.Matrix4(), gfxQ = new THREE.Quaternion(), gfxV = new THREE.Vector3(), gfxS = new THREE.Vector3(), gfxUp = new THREE.Vector3(0, 1, 0), gfxC = new THREE.Color();
const GFX_BATCHES = [hazardBatch, emberBatch, poolBatch, flameBatch, puffBatch, zoneBatch];
function gfxBegin() { for (const m of GFX_BATCHES) m.userData.n = 0; }
function gfxPut(m, x, y, z, r, rot, color, a) {
  const n = m.userData.n; if (n >= m.userData.max || a <= 0.01) return;
  m.setMatrixAt(n, gfxM.compose(gfxV.set(x, y, z), gfxQ.setFromAxisAngle(gfxUp, rot), gfxS.set(r, 1, r)));
  gfxC.set(color); m.geometry.attributes.aCol.setXYZW(n, gfxC.r, gfxC.g, gfxC.b, a); m.userData.n = n + 1;
}
function gfxFlame(m, x, y, z, w, h, sway, color, a) { // one billboard: base at (x,y,z), w x h, tip pushed sideways by sway
  const n = m.userData.n; if (n >= m.userData.max || a <= 0.01 || h <= 0.01) return;
  const e = m.instanceMatrix.array, o = n * 16;
  e.fill(0, o, o + 16); e[o] = w; e[o + 4] = sway; e[o + 5] = h; e[o + 12] = x; e[o + 13] = y; e[o + 14] = z; e[o + 15] = 1;
  gfxC.set(color); m.geometry.attributes.aCol.setXYZW(n, gfxC.r, gfxC.g, gfxC.b, a); m.userData.n = n + 1;
}
function gfxEnd() { for (const m of GFX_BATCHES) { m.count = m.userData.n; m.visible = m.count > 0; /* an empty batch costs no draw call */ if (m.count) { m.instanceMatrix.needsUpdate = true; m.geometry.attributes.aCol.needsUpdate = true; } } }
const GFX_K = MOBILE ? 0.7 : 1; // phones: 30% fewer ground-effect particles
function gfxEmit(o, key, rate, dt) { const v = (o[key] || 0) + rate * GFX_K * dt, n = Math.floor(v); o[key] = v - n; return n; }

// ---------- particles: additive glow points + debris cubes ----------
const MAXG = MOBILE ? 700 : 1400; // phones: half the pool (the oldest sparks recycle sooner)
const gPos = new Float32Array(MAXG * 3), gCol = new Float32Array(MAXG * 3), gSize = new Float32Array(MAXG);
const gData = Array.from({ length: MAXG }, () => ({ life: 0, max: 1, vx: 0, vy: 0, vz: 0, s: 0, drag: 0, grav: 0, r: 0, g: 0, b: 0 }));
const glowGeo = new THREE.BufferGeometry();
glowGeo.setAttribute('position', new THREE.BufferAttribute(gPos, 3).setUsage(THREE.DynamicDrawUsage));
glowGeo.setAttribute('color', new THREE.BufferAttribute(gCol, 3).setUsage(THREE.DynamicDrawUsage));
glowGeo.setAttribute('size', new THREE.BufferAttribute(gSize, 1).setUsage(THREE.DynamicDrawUsage));
const glowMat = new THREE.ShaderMaterial({
  uniforms: { uScale: { value: 500 }, uDpr: { value: 1 } },
  // a negative size draws a hollow ring instead of a soft dot (poison bubbles)
  // a point under ~2 CSS px can't show its soft falloff: it reads as a hard 1-px dot, so it dims out instead (gone below ~0.7 px)
  vertexShader: `attribute float size; attribute vec3 color; varying vec3 vC; varying float vRing; uniform float uScale; uniform float uDpr;
    void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); float ps = abs(size) * uScale / -mv.z; float k = smoothstep(0.7, 2.2, ps / uDpr);
      gl_PointSize = k > 0.0 ? ps : 0.0; vRing = step(size, -0.0001); vC = color * k; gl_Position = projectionMatrix * mv; }`,
  fragmentShader: `varying vec3 vC; varying float vRing; void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; float a = 1.0 - d * 2.0;
    float ring = smoothstep(0.28, 0.4, d) * (1.0 - smoothstep(0.42, 0.5, d)) * 1.9 + a * 0.25;
    gl_FragColor = vec4(vC * mix(a * a * 1.6, ring, vRing), 1.0); }`,
  blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
});
const glowPoints = new THREE.Points(glowGeo, glowMat);
glowPoints.frustumCulled = false;
scene.add(glowPoints);
let gHead = 0;
// per-frame emitters use these so a 120-144 Hz screen makes the same number of sparks per second as a 60 Hz one (it used to make
// 2-2.4x as many: clouds of dots). FX_FR = this frame's length in 60 Hz frames, set in tick().
let FX_FR = 1;
const fxP = (p) => Math.random() < p * FX_FR;
const fxN = (n) => Math.floor(n * FX_FR + Math.random());
const tmpC = new THREE.Color();
function spark(x, y, z, color, { vx = 0, vy = 0, vz = 0, s = 0.25, life = 0.5, drag = 3, grav = 0, spread = 0 } = {}) {
  const i = gHead; gHead = (gHead + 1) % MAXG;
  const d = gData[i];
  tmpC.set(color);
  Object.assign(d, { life, max: life, vx: vx + (Math.random() - 0.5) * spread, vy: vy + (Math.random() - 0.5) * spread, vz: vz + (Math.random() - 0.5) * spread, s, drag, grav, r: tmpC.r, g: tmpC.g, b: tmpC.b });
  gPos[i * 3] = x; gPos[i * 3 + 1] = y; gPos[i * 3 + 2] = z; d.amb = sparkAmb;
}
let sparkAmb = false; // set while the biome's floating particles spawn: Stillness freezes those in mid-air (user 11-15)
function burst(x, y, z, color, n, speed = 4, s = 0.3, life = 0.5) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, u = Math.random() * 2 - 1, v = speed * (0.4 + Math.random() * 0.6);
    const q = Math.sqrt(1 - u * u);
    spark(x, y, z, color, { vx: Math.cos(a) * q * v, vy: Math.abs(u) * v * 0.8, vz: Math.sin(a) * q * v, s: s * (0.6 + Math.random() * 0.7), life: life * (0.6 + Math.random() * 0.8), drag: 4, grav: -4 });
  }
}
let gLo = 0, gHi = -1; // index range of live sparks last frame
function updateGlows(dt) {
  let lo = MAXG, hi = -1;
  for (let i = 0; i < MAXG; i++) {
    const d = gData[i];
    if (d.life <= 0) { gSize[i] = 0; continue; }
    if (i < lo) lo = i; hi = i;
    if (d.amb && G.still > 0) continue; // time stopped: dust, embers, snow hang where they are
    d.life -= dt;
    const k = Math.exp(-d.drag * dt);
    d.vx *= k; d.vy = d.vy * k + d.grav * dt; d.vz *= k;
    gPos[i * 3] += d.vx * dt; gPos[i * 3 + 1] += d.vy * dt; gPos[i * 3 + 2] += d.vz * dt;
    const t = Math.max(0, d.life / d.max);
    // the last 40% of its life a spark fades out while it shrinks to half size (shrinking all the way to 0 left a trail of pin-point dots)
    const f = Math.min(1, t * 2.5);
    gSize[i] = d.s * (0.5 + 0.5 * f);
    gCol[i * 3] = d.r * f; gCol[i * 3 + 1] = d.g * f; gCol[i * 3 + 2] = d.b * f;
  }
  // upload only the span that holds live sparks now or did last frame (those just died need their size 0 sent)
  const a = Math.min(lo, gLo), b = Math.max(hi, gHi); gLo = lo; gHi = hi;
  if (b < a) return;
  for (const at of [glowGeo.attributes.position, glowGeo.attributes.color, glowGeo.attributes.size]) { at.clearUpdateRanges(); at.addUpdateRange(a * at.itemSize, (b - a + 1) * at.itemSize); at.needsUpdate = true; }
}

const MAXD = 500;
const debrisMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshLambertMaterial(), MAXD);
debrisMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
debrisMesh.castShadow = true;
debrisMesh.frustumCulled = false;
scene.add(debrisMesh);
const debris = Array.from({ length: MAXD }, () => ({ life: 0 }));
let dHead = 0;
const dm = new THREE.Matrix4(), dq = new THREE.Quaternion(), de = new THREE.Euler(), dv = new THREE.Vector3(), ds = new THREE.Vector3();
for (let i = 0; i < MAXD; i++) { debrisMesh.setMatrixAt(i, dm.makeScale(0, 0, 0)); debrisMesh.setColorAt(i, tmpC.set(0xffffff)); }
function chunk(x, y, z, color, n = 6, speed = 5, size = 0.12) {
  for (let k = 0; k < n; k++) {
    const i = dHead; dHead = (dHead + 1) % MAXD;
    const a = Math.random() * Math.PI * 2, v = speed * (0.3 + Math.random() * 0.7);
    debris[i] = { life: 1.2 + Math.random() * 1.2, x, y, z, vx: Math.cos(a) * v, vy: 3 + Math.random() * 4, vz: Math.sin(a) * v, rx: Math.random() * 6, ry: Math.random() * 6, s: size * (0.6 + Math.random() * 0.8) };
    debrisMesh.setColorAt(i, tmpC.set(color).offsetHSL(0, 0, (Math.random() - 0.5) * 0.15));
  }
  debrisMesh.instanceColor.needsUpdate = true;
}
function updateDebris(dt) {
  for (let i = 0; i < MAXD; i++) {
    const d = debris[i];
    if (d.life <= 0) continue;
    d.life -= dt;
    d.vy -= 22 * dt; d.x += d.vx * dt; d.y += d.vy * dt; d.z += d.vz * dt;
    if (d.y < d.s / 2) { d.y = d.s / 2; d.vy *= -0.35; d.vx *= 0.6; d.vz *= 0.6; d.rx *= 0.5; }
    if (solid(d.x, d.z, false)) { d.vx *= -0.5; d.vz *= -0.5; d.x += d.vx * dt * 2; d.z += d.vz * dt * 2; }
    d.rx *= 0.99;
    const sc = d.life < 0.4 ? d.s * d.life / 0.4 : d.s;
    de.set(d.rx * d.life * 3, d.ry * d.life * 3, 0);
    debrisMesh.setMatrixAt(i, dm.compose(dv.set(d.x, d.y, d.z), dq.setFromEuler(de), ds.set(sc, sc, sc)));
    if (d.life <= 0) debrisMesh.setMatrixAt(i, dm.makeScale(0, 0, 0));
  }
  debrisMesh.instanceMatrix.needsUpdate = true;
}

// ---------- floor decals (splats stay for the whole floor, like the reference) ----------
const MAXS = 450;
const splatMesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2),
  new THREE.MeshBasicMaterial({ map: splatTex, transparent: true, depthWrite: false, ...DECAL }), MAXS);
splatMesh.renderOrder = -1; // always drawn before every other see-through layer, so floor splats never cover particles
splatMesh.frustumCulled = false;
scene.add(splatMesh);
let sHead = 0;
function clearSplats() { for (let i = 0; i < MAXS; i++) { splatMesh.setMatrixAt(i, dm.makeScale(0, 0, 0)); splatMesh.setColorAt(i, tmpC.set(0)); } splatMesh.instanceMatrix.needsUpdate = true; splatMesh.instanceColor.needsUpdate = true; }
const plateRects = []; // [cx, cz, ...] of the 3x3 rune plates (top at y 0.05)
const onPlate = (x, z) => { for (let i = 0; i < plateRects.length; i += 2) if (Math.abs(x - plateRects[i]) < 1.5 && Math.abs(z - plateRects[i + 1]) < 1.5) return true; return false; };
function splat(x, z, color, size = 1, opacity = 1) {
  if (cellAt(x, z) !== FLOOR) return;
  const i = sHead; sHead = (sHead + 1) % MAXS;
  de.set(0, Math.random() * Math.PI * 2, 0);
  splatMesh.setMatrixAt(i, dm.compose(dv.set(x, (onPlate(x, z) ? 0.056 : 0.015) + i * 0.00002, z), dq.setFromEuler(de), ds.set(size, 1, size)));
  splatMesh.setColorAt(i, tmpC.set(color).multiplyScalar(opacity));
  splatMesh.instanceMatrix.needsUpdate = true; splatMesh.instanceColor.needsUpdate = true;
}

// ---------- world ----------
let map = new Uint8Array(MW * MH), wallH = new Float32Array(MW * MH);
let rooms = [], roomGrid = [], world = null, torchFlames = [], fogPlanes = [], flickT = 0;
const coffinCells = new Set();
const cellAt = (x, z) => { const i = Math.floor(x), j = Math.floor(z); return i < 0 || j < 0 || i >= MW || j >= MH ? VOID : map[j * MW + i]; };
function solid(x, z, fly) { const c = cellAt(x, z); return c === VOID || c === WALL || c === BAR || (!fly && c === OBST); }
// ---------- biomes: every floor rolls one; each changes materials, surroundings, light, particles, props and hazards ----------
const BIOMES = {
  crypt: { names: ['THE DROWNED CRYPT', 'THE VIOLET CATACOMBS', 'HALLS OF THE DEAD'], floor: 0x9aa5ad, wall: 0x7fb0ae, cap: 0xa8d4cf, fog: 0x010103,
    hemi: [0x4a5c80, 0x0c0812], hemiI: 0.28, sun: 0x8fa6ff, sunI: 0.3, torch: 0xff7a2a, flame: 0xff9a40, mist: 0x9ab4d8, particle: 'dust', hazard: 'spikes',
    merlons: true, crypt: true, moss: 0.35, splats: [0x2a0505, 0x1c150c, 0x101a0c, 0x200814] },
  woods: { names: ['THE OVERGROWN RUINS', 'THE WHISPERING GROVE', 'THE THORNWOOD'], floor: 0x8a9a7a, wall: 0x6f8a5a, cap: 0x9fb88a, fog: 0x07100a,
    hemi: [0x6a8a5a, 0x0c1408], hemiI: 0.34, sun: 0xd8e8a0, sunI: 0.35, torch: 0xffb060, flame: 0xffc070, mist: 0x8ab088, particle: 'fireflies', hazard: 'vents',
    merlons: true, moss: 0.7, ground: { color: 0x1c2a14, y: -1.2 }, splats: [0x1a2a0c, 0x2a1a0a, 0x0c1a08] },
  caverns: { names: ['THE HOLLOW MOUNTAIN', 'THE DEEP MINES', 'THE CRYSTAL CAVES'], floor: 0x8a8178, wall: 0x7a7068, cap: 0x9a9088, fog: 0x050507,
    hemi: [0x6a6a8a, 0x100c0a], hemiI: 0.28, sun: 0xa8b8ff, sunI: 0.22, torch: 0xffa050, flame: 0xffb060, mist: 0x8a8a9a, particle: 'dust', hazard: 'spikes',
    rock: true, moss: 0.15, ground: { color: 0x121216, y: -6 }, splats: [0x1a1612, 0x24201a, 0x120e14] },
  forge: { names: ['THE EMBER FORGE', 'THE MOLTEN HALLS', 'THE ASHEN DEEP'], floor: 0x6e5c56, wall: 0x5a4a48, cap: 0x9a5a3a, fog: 0x140603,
    hemi: [0xff8a50, 0x1a0804], hemiI: 0.3, sun: 0xffa070, sunI: 0.25, torch: 0xff6a20, flame: 0xff7a2a, mist: 0x8a5040, particle: 'embers', hazard: 'lava',
    merlons: true, rock: true, moss: 0, ground: { color: 0xff5a10, y: -2.4, lava: true }, splats: [0x1a0a04, 0x2a0a04, 0x120604] },
  frozen: { names: ['THE FROZEN DEEP', 'THE RIME HALLS', 'THE GLACIER TOMB'], floor: 0xb8c8d8, wall: 0x8aa8c0, cap: 0xeaf4ff, fog: 0x080e16,
    hemi: [0x9ab8e0, 0x0a1018], hemiI: 0.34, sun: 0xcfe0ff, sunI: 0.35, torch: 0xffa050, flame: 0xffb060, mist: 0xcfe0f0, particle: 'snow', hazard: 'spikes',
    merlons: true, moss: 0, ground: { color: 0xc8d8e8, y: -1.0 }, splats: [0x5a7a9a, 0x3a5a7a, 0x8aa0b8] },
  swamp: { names: ['THE SUNKEN FEN', 'THE ROTTING MIRE', 'THE FUNGAL MARSH'], floor: 0x7a8070, wall: 0x5a6a5a, cap: 0x7a8a6a, fog: 0x07100b,
    hemi: [0x6a8a7a, 0x0a120c], hemiI: 0.3, sun: 0xb0e0c0, sunI: 0.28, torch: 0xffb060, flame: 0xc0ff70, mist: 0x7aa08a, particle: 'spores', hazard: 'vents',
    merlons: false, moss: 0.6, ground: { color: 0x14221a, y: -0.6, water: true }, splats: [0x1a2a14, 0x101a0c, 0x22142a] },
};
const BIOME_KEYS = Object.keys(BIOMES);
const FORCE_BOSS = params.get('boss'); // testing: ?boss=sentinel&floor=3 puts that boss on the floor
const WIN_FLOOR = 50; // clear this floor's boss to win the run
const DUNGEON_INFO = {
  crypt: ['The Crypt', 'Bones, coffins and cobwebs in the dark. Spike traps.'],
  woods: ['Overgrown Ruins', 'Ruins swallowed by a forest. Spore vents, fireflies.'],
  caverns: ['Hollow Mountain', 'A chasm of stalagmites and glowing crystals. Spike traps.'],
  forge: ['Ember Forge', 'A fortress over a lava sea. Lava cracks, embers.'],
  frozen: ['Frozen Deep', 'Ice halls in a snowfield. Spike traps, falling snow.'],
  swamp: ['Sunken Fen', 'A rotting marsh of giant mushrooms. Gas vents, spores.'],
};
function pickBiome(n) {
  if (params.get('biome') && BIOMES[params.get('biome')]) return params.get('biome');
  return BIOMES[G.runDungeon] ? G.runDungeon : 'crypt'; // the whole run stays in the dungeon it rolled
}
// a floor's palette: the biome's colours with a little random drift so no two floors look the same
function biomePalette(b) {
  const j = (hex) => tmpC.set(hex).offsetHSL((rand() - 0.5) * 0.04, (rand() - 0.5) * 0.12, (rand() - 0.5) * 0.06).getHex();
  return { floor: j(b.floor), wall: j(b.wall), cap: j(b.cap), name: pick(b.names) };
}
function applyBiomeLight(b) {
  scene.background.set(b.fog); scene.fog.color.set(b.fog);
  hemi.color.set(b.hemi[0]); hemi.groundColor.set(b.hemi[1]); hemi.intensity = b.hemiI;
  sun.color.set(b.sun); sun.intensity = b.sunI;
  for (const l of torchLights) l.color.set(b.torch);
  fogMat.color.set(b.mist);
}
const PALETTES = [
  { floor: 0x9aa5ad, wall: 0x7fb0ae, cap: 0xa8d4cf, name: 'THE DROWNED HALLS' },
  { floor: 0xa59cab, wall: 0x8c8fbf, cap: 0xb8b6e6, name: 'THE VIOLET CRYPT' },
  { floor: 0xa0a693, wall: 0x7f9f86, cap: 0xaccdb0, name: 'THE MOSS VAULTS' },
  { floor: 0xb0a194, wall: 0xb08c7a, cap: 0xd9b7a2, name: 'THE EMBER DEEP' },
];

// combat room interiors on the 11 x 13 floor (x, z), before mirroring. Single, low pillars only, kept 2 tiles off the
// walls and apart from each other, so nothing forms a pocket that traps monsters or coins.
const ROOM_LAYOUTS = [
  [[2, 2], [8, 2], [2, 10], [8, 10]], // corner pillars
  [[3, 4], [7, 4], [3, 8], [7, 8]], // inner pillars
  [[3, 3], [7, 9]], // two pillars on a diagonal
  [], // open hall
  [[5, 6]], // one centre pillar
  [[3, 3], [7, 3], [5, 6], [3, 9], [7, 9]], // five
  [[2, 2], [5, 4], [8, 2], [2, 10], [5, 8], [8, 10]], // staggered
  [[3, 6], [7, 6]], // a pair across the middle
  'scatter', // a few random pillars
];
let layoutBag = [];
function genFloor(n) {
  map.fill(VOID); wallH.fill(0); coffinCells.clear(); layoutBag = [];
  rooms = []; roomGrid = new Array(GW * GH).fill(null);
  const want = G.daily ? 4 + n : Math.min(6 + n, 13); // daily floors are short
  const add = (gx, gy, parent) => {
    const r = { gx, gy, x0: gx * SX, z0: gy * SZ, w: RW, h: RH, links: [], type: 'combat', cleared: false, visited: false, seen: false, active: false, depth: 0 };
    r.cx = r.x0 + 1 + r.w / 2; r.cz = r.z0 + 1 + r.h / 2;
    rooms.push(r); roomGrid[gy * GW + gx] = r;
    if (parent) { r.links.push(parent); parent.links.push(r); r.depth = parent.depth + 1; }
    return r;
  };
  const start = add(3, 3, null);
  if (G.prologue) add(3, 2, start); // the prologue: Pip lands in the start room; one door north leads to the Stone King's chamber
  let guard = 0;
  while (!G.prologue && rooms.length < want && guard++ < 2000) {
    const p = pick(rooms);
    const [dx, dy] = pick([[1, 0], [-1, 0], [0, 1], [0, -1]]);
    const gx = p.gx + dx, gy = p.gy + dy;
    if (gx < 0 || gy < 0 || gx >= GW || gy >= GH || roomGrid[gy * GW + gx]) continue;
    let nb = 0;
    for (const [ax, ay] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (roomGrid[(gy + ay) * GW + gx + ax] && gy + ay >= 0 && gy + ay < GH && gx + ax >= 0 && gx + ax < GW) nb++;
    if (nb > 1 && rand() < 0.8) continue;
    add(gx, gy, p);
  }
  start.type = 'start'; start.cleared = true;
  const exit = rooms.reduce((a, b) => (b.depth > a.depth ? b : a));
  exit.type = n % 3 === 0 || n === WIN_FLOOR ? 'boss' : 'exit';
  if (G.prologue) { exit.type = 'pro'; exit.cleared = true; } // the chamber: no waves, no layout; the prologue script runs it
  const dead = shuffle(rooms.filter((r) => r.links.length === 1 && r !== start && r !== exit));
  if (dead[0]) dead[0].type = 'treasure';
  if (dead[1]) dead[1].type = 'shop';
  else { const c = rooms.filter((r) => r.type === 'combat'); if (c.length > 3) pick(c).type = 'shop'; }
  const extra = shuffle(rooms.filter((r) => r.type === 'combat' && r.depth > 1));
  if (n >= 2 && extra[0] && rand() < 0.7) extra[0].type = 'shrine';
  if (n >= 2 && extra[1] && rand() < 0.6) extra[1].type = 'challenge';
  // calm rooms: about 35% (at least one) of the fight rooms off the stairs path never lock or spawn: a small cache, a
  // blessing shrine, a healing fountain or a quiet breather, lit warm gold. Never on boss floors. The rooms that still fight
  // give more XP (G.xpMul) so a floor levels you about as much as before. A run saved before calm rooms keeps its floor.
  G.xpMul = 1;
  if (!G.noCalm && n % 3 !== 0 && n !== WIN_FLOOR) {
    const onPath = new Set(); for (let r = exit; r; r = r.type === 'start' ? null : r.links[0]) onPath.add(r);
    const side = shuffle(rooms.filter((r) => r.type === 'combat' && !onPath.has(r)));
    const fightsBefore = rooms.filter((r) => r.type === 'combat' || r.type === 'challenge' || r.type === 'exit').length;
    const kinds = shuffle(['cache', 'blessing', 'fountain', 'quiet']);
    side.slice(0, side.length ? Math.max(1, Math.round(side.length * 0.35)) : 0).forEach((r, k) => { r.type = 'calm'; r.calm = kinds[k % kinds.length]; r.cleared = true; });
    G.xpMul = Math.min(1.6, fightsBefore / Math.max(1, fightsBefore - rooms.filter((r) => r.type === 'calm').length));
  }
  const plain = shuffle(rooms.filter((r) => r.type === 'combat'));
  if (n >= 2 && plain[0] && rand() < 0.6) plain[0].variant = 'swarm';
  if (n >= 2 && plain[1] && rand() < 0.55) plain[1].variant = 'dark';
  if (n >= 3 && plain[2] && rand() < 0.6) plain[2].variant = 'traps';
  for (const r of rooms) if (r.type === 'treasure' || r.type === 'shop' || r.type === 'shrine') r.cleared = true;
  // room sizes vary: small side rooms, combat rooms from snug to wide, a big boss arena. Sizes stay odd so every room is
  // centred in its grid slot and the corridors (which run through the slot centre) still meet the doors.
  for (const r of rooms) {
    const inner = r.gx > 0 && r.gy > 0 && r.gx < GW - 1 && r.gy < GH - 1; // rooms on the grid edge never grow past the slot
    if (r.type === 'boss') { r.w = inner ? 13 : RW; r.h = inner ? 15 : RH; }
    else if (r.type === 'treasure' || r.type === 'shop' || r.type === 'shrine') { r.w = 9; r.h = 11; }
    else if (r.type !== 'start' && r.type !== 'pro') { r.w = pick(inner ? [9, 11, 11, 13] : [9, 11]); r.h = pick(inner ? [11, 13, 13, 15] : [11, 13]); }
    r.x0 = r.gx * SX + (RW - r.w) / 2; r.z0 = r.gy * SZ + (RH - r.h) / 2;
    r.cx = r.x0 + 1 + r.w / 2; r.cz = r.z0 + 1 + r.h / 2;
  }

  const set = (i, j, v, h = 0) => { if (i < 0 || j < 0 || i >= MW || j >= MH) return; map[j * MW + i] = v; wallH[j * MW + i] = h; };
  const setWallIfVoid = (i, j, h) => { if (map[j * MW + i] === VOID) set(i, j, WALL, h); };
  for (const r of rooms) {
    for (let j = 0; j < r.h + 2; j++) for (let i = 0; i < r.w + 2; i++) {
      const edge = i === 0 || j === 0 || i === r.w + 1 || j === r.h + 1;
      const corner = (i === 0 || i === r.w + 1) && (j === 0 || j === r.h + 1);
      set(r.x0 + i, r.z0 + j, edge ? WALL : FLOOR, corner ? (j === 0 ? TALL + 0.5 : LOW + 0.35) : j === r.h + 1 ? LOW : TALL);
    }
    r.doors = [];
    if (r.type === 'combat' || r.type === 'exit' || r.type === 'challenge') {
      // each room on a floor gets a different layout (shuffled bag), randomly mirrored; door lanes always stay open
      if (!layoutBag.length) layoutBag = shuffle(ROOM_LAYOUTS.map((_, k) => k));
      const L = ROOM_LAYOUTS[layoutBag.pop()], fx = rand() < 0.5, fz = rand() < 0.5;
      const cells = L === 'scatter' ? Array.from({ length: ri(3, 5) }, () => [ri(2, r.w - 3), ri(2, r.h - 3)]) : L;
      const placed = [];
      for (let [i, j] of cells) {
        if (L !== 'scatter') { // layouts are drawn for the standard 11 x 13 room: mirror there, then centre in this room
          if (fx) i = RW - 1 - i; if (fz) j = RH - 1 - j;
          i += (r.w - RW) / 2; j += (r.h - RH) / 2;
          if (i < 0 || j < 0 || i >= r.w || j >= r.h) continue;
        }
        const midJ = Math.floor(r.h / 2), midI = Math.floor(r.w / 2);
        if ((Math.abs(j - midJ) <= 1 && (i <= 1 || i >= r.w - 2)) || (Math.abs(i - midI) <= 1 && (j <= 1 || j >= r.h - 2))) continue;
        if (i < 2 || j < 2 || i > r.w - 3 || j > r.h - 3 || placed.some(([a, b]) => Math.abs(a - i) <= 1 && Math.abs(b - j) <= 1)) continue; // no pockets
        if ((r.type === 'exit' || r.type === 'challenge') && Math.abs(i - midI) <= 1 && Math.abs(j - midJ) <= 1) continue; // stairs / golden chest appear in the centre
        placed.push([i, j]);
        set(r.x0 + 1 + i, r.z0 + 1 + j, OBST, 0.8); // low enough that monsters behind stay visible
      }
      r.coffins = [];
      if (G.biome.crypt && rand() < 0.55) for (const side of [0, r.w - 1]) {
        if (rand() < 0.4) continue;
        const j = pick([1, 2, r.h - 4, r.h - 3]);
        const ci = r.x0 + 1 + side, cj = r.z0 + 1 + j;
        if (map[cj * MW + ci] !== FLOOR || map[(cj + 1) * MW + ci] !== FLOOR) continue;
        set(ci, cj, OBST, 0.4); set(ci, cj + 1, OBST, 0.4);
        coffinCells.add(cj * MW + ci); coffinCells.add((cj + 1) * MW + ci);
        r.coffins.push([ci, cj]);
      }
    }
  }
  const corr = [];
  for (const r of rooms) for (const o of r.links) {
    if (o.gx === r.gx + 1) corr.push(['h', r, o]);
    if (o.gy === r.gy + 1) corr.push(['v', r, o]);
  }
  for (const [dir, a, b] of corr) {
    if (dir === 'h') {
      const zc = a.z0 + 1 + Math.floor(a.h / 2);
      for (let i = a.x0 + a.w + 1; i <= b.x0; i++) {
        for (let k = -1; k <= 1; k++) set(i, zc + k, FLOOR);
        setWallIfVoid(i, zc - 2, 1.0); setWallIfVoid(i, zc + 2, LOW);
      }
      a.doors.push({ cells: [-1, 0, 1].map((k) => [a.x0 + a.w + 1, zc + k]), axis: 'x' });
      b.doors.push({ cells: [-1, 0, 1].map((k) => [b.x0, zc + k]), axis: 'x' });
    } else {
      const xc = a.x0 + 1 + Math.floor(a.w / 2);
      for (let j = a.z0 + a.h + 1; j <= b.z0; j++) {
        for (let k = -1; k <= 1; k++) set(xc + k, j, FLOOR);
        setWallIfVoid(xc - 2, j, 0.9); setWallIfVoid(xc + 2, j, 0.9);
      }
      a.doors.push({ cells: [-1, 0, 1].map((k) => [xc + k, a.z0 + a.h + 1]), axis: 'z' });
      b.doors.push({ cells: [-1, 0, 1].map((k) => [xc + k, b.z0]), axis: 'z' });
    }
  }
  return start;
}

const boxGeo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
const floorGeo = new THREE.BoxGeometry(1, 0.3, 1).translate(0, -0.15, 0);
const floorInst = new Map(); // map cell -> [instanced floor mesh, index], so hazards can move their tile
function buildWorld(pal) {
  if (world) { scene.remove(world); world.traverse((o) => { if (o.isInstancedMesh) o.dispose(); if (o.material && o.userData.own) o.material.dispose(); }); }
  world = new THREE.Group(); scene.add(world);
  torchFlames.forEach(killGlow); torchFlames = [];
  const floors = [], floors2 = [], walls = [], obst = [];
  for (let j = 0; j < MH; j++) for (let i = 0; i < MW; i++) {
    const c = map[j * MW + i];
    if (c === FLOOR || c === OBST) (hash(i, j, 9) < 0.12 ? floors2 : floors).push([i, j]);
    if (c === WALL) walls.push([i, j]);
    if (c === OBST && !coffinCells.has(j * MW + i)) obst.push([i, j]);
  }
  const mk = (geo, mat, list, place, cast = true) => {
    const im = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length));
    im.count = list.length; im.castShadow = cast; im.receiveShadow = true; mat.userData = {};
    im.userData.own = true;
    list.forEach((it, k) => place(im, k, it));
    im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
    world.add(im); return im;
  };
  const fc = new THREE.Color(pal.floor), wc = new THREE.Color(pal.wall), cc = new THREE.Color(pal.cap);
  const B = G.biome || BIOMES.crypt, moss = new THREE.Color(B.key === 'frozen' ? 0xe8f4ff : 0x4f6a3a);
  const nearWall = (i, j) => map[j * MW + i - 1] === WALL || map[j * MW + i + 1] === WALL || map[(j - 1) * MW + i] === WALL || map[(j + 1) * MW + i] === WALL;
  floorInst.clear();
  const placeFloor = (im, k, [i, j]) => {
    floorInst.set(j * MW + i, [im, k]);
    const sunk = hash(i, j, 7) < 0.07; // cracked, sunken tiles
    im.setMatrixAt(k, dm.makeTranslation(i + 0.5, sunk ? -0.06 : (hash(i, j, 3) - 0.5) * 0.03, j + 0.5));
    tmpC.copy(fc).multiplyScalar((0.72 + hash(i, j, 4) * 0.26) * (sunk ? 0.55 : 1));
    if (B.moss && (nearWall(i, j) || hash(i, j, 11) < B.moss * 0.3) && hash(i, j, 8) < 0.45 + B.moss * 0.3) tmpC.lerp(moss, (0.35 + hash(i, j, 9) * 0.25) * Math.min(1, B.moss + 0.4));
    im.setColorAt(k, tmpC);
  };
  mk(floorGeo, new THREE.MeshLambertMaterial({ map: floorTex }), floors, placeFloor, false);
  mk(floorGeo, new THREE.MeshLambertMaterial({ map: floorTex2 }), floors2, placeFloor, false);
  const wallMat = new THREE.MeshLambertMaterial({ map: wallTex });
  mk(boxGeo, wallMat, walls, (im, k, [i, j]) => {
    let h = wallH[j * MW + i];
    if (B.rock) { h *= 0.8 + hash(i, j, 12) * 0.7; wallH[j * MW + i] = h; } // jagged rock instead of laid stone
    de.set(0, B.rock ? (hash(i, j, 13) - 0.5) * 0.5 : 0, 0);
    im.setMatrixAt(k, dm.compose(dv.set(i + 0.5, 0, j + 0.5), dq.setFromEuler(de), ds.set(B.rock ? 1.08 : 1, h, B.rock ? 1.08 : 1)));
    im.setColorAt(k, tmpC.copy(wc).multiplyScalar((0.7 + hash(i, j, 5) * 0.3) * (hash(i, j, 6) < 0.12 ? 0.6 : 1)).lerp(moss, hash(i, j, 10) < 0.2 ? 0.3 : 0));
  });
  mk(boxGeo, new THREE.MeshLambertMaterial({ map: plinthTex }), walls, (im, k, [i, j]) => {
    im.setMatrixAt(k, dm.compose(dv.set(i + 0.5, -8, j + 0.5), dq.identity(), ds.set(1, 8, 1)));
    im.setColorAt(k, tmpC.copy(wc).multiplyScalar(0.6));
  }, false);
  const capMat = new THREE.MeshLambertMaterial({ map: floorTex });
  mk(boxGeo, capMat, walls, (im, k, [i, j]) => {
    const h = wallH[j * MW + i];
    im.setMatrixAt(k, dm.compose(dv.set(i + 0.5, h, j + 0.5), dq.identity(), ds.set(1.04, 0.14, 1.04)));
    im.setColorAt(k, cc);
  });
  const merl = B.merlons && !B.rock ? walls.filter(([i, j]) => wallH[j * MW + i] >= 1 && (i + j) % 2 === 0) : [];
  mk(boxGeo, wallMat, merl, (im, k, [i, j]) => {
    const h = wallH[j * MW + i];
    im.setMatrixAt(k, dm.compose(dv.set(i + 0.5, h + 0.14, j + 0.5), dq.identity(), ds.set(0.62, 0.36, 0.62)));
    im.setColorAt(k, tmpC.copy(wc).multiplyScalar(1.05));
  });
  mk(boxGeo, wallMat, obst, (im, k, [i, j]) => {
    im.setMatrixAt(k, dm.compose(dv.set(i + 0.5, 0, j + 0.5), dq.identity(), ds.set(0.8, PILLAR_H, 0.8)));
    im.setColorAt(k, tmpC.copy(wc).multiplyScalar(0.95));
  });
  mk(boxGeo, capMat, obst, (im, k, [i, j]) => {
    im.setMatrixAt(k, dm.compose(dv.set(i + 0.5, PILLAR_H, j + 0.5), dq.identity(), ds.set(0.98, 0.18, 0.98)));
    im.setColorAt(k, cc);
  });
  // ornate rune plates in the special rooms (the reference has these under every altar)
  const plates = rooms.filter((r) => r.type !== 'combat' && r.type !== 'challenge');
  const plateMat = new THREE.MeshLambertMaterial({ map: runeTex, color: pal.cap });
  plateRects.length = 0;
  for (const r of plates) {
    plateRects.push(r.cx, r.cz); // floor stains / cracks on a plate sit on its top, not under it (user 11-15: the room's centre plate hid them)
    const m = new THREE.Mesh(new THREE.BoxGeometry(3, 0.06, 3), plateMat);
    m.position.set(r.cx, 0.02, r.cz); m.receiveShadow = true; world.add(m); // top at 0.05: clear of the floor's +-1.5 cm jitter
  }
  // torches on the north wall of every room
  for (const r of rooms) {
    r.torches = []; r.flames = [];
    const spots = [[r.x0 + 3.5, r.z0 + 1.08, 0, 1], [r.x0 + r.w - 1.5, r.z0 + 1.08, 0, 1],
      [r.x0 + 1.08, r.z0 + 4.5, 1, 0], [r.x0 + 1.08, r.z0 + r.h - 2.5, 1, 0],
      [r.x0 + r.w + 0.92, r.z0 + 4.5, -1, 0], [r.x0 + r.w + 0.92, r.z0 + r.h - 2.5, -1, 0]];
    spots.forEach(([x, z, nx, nz], k) => {
      const p = new THREE.Vector3(x, 1.05, z);
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.34, 0.18), bracketMat); b.position.set(x - nx * 0.05, 0.9, z - nz * 0.05); world.add(b);
      const f = makeGlow(B.flame, 0.9, 0.9); f.position.set(x + nx * 0.06, 1.17, z + nz * 0.06); f.userData.pool = [x + nx * 0.9, z + nz * 0.9];
      const core = makeGlow(0xfff0a0, 0.35, 1); core.position.copy(f.position); f.userData.core = core;
      torchFlames.push(f, core); r.flames.push(f);
      if (k < 2) r.torches.push(p);
    });
  }
  dressRooms(wallMat);
  buildEnvironment(B);
}

// ---------- what surrounds the rooms (and grows inside them), per biome ----------
const envGeo = { cone: new THREE.ConeGeometry(1, 1, 6).translate(0, 0.5, 0), cyl: new THREE.CylinderGeometry(1, 1, 1, 6).translate(0, 0.5, 0),
  ball: new THREE.IcosahedronGeometry(1, 0), gem: new THREE.OctahedronGeometry(1, 0), cap: new THREE.SphereGeometry(1, 8, 5, 0, Math.PI * 2, 0, Math.PI / 2) };
function buildEnvironment(B) {
  G.lavaTex = null;
  // distance (in cells) from the nearest walkable/wall cell, so props hug the rooms and leave the corridors clear
  const dist = new Uint8Array(MW * MH).fill(255), q = [];
  for (let k = 0; k < MW * MH; k++) if (map[k] !== VOID) { dist[k] = 0; q.push(k); }
  for (let h = 0; h < q.length; h++) {
    const k = q[h], i = k % MW, j = (k / MW) | 0, d = dist[k];
    if (d >= 9) continue;
    for (const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const ni = i + a, nj = j + b; if (ni < 0 || nj < 0 || ni >= MW || nj >= MH) continue; const nk = nj * MW + ni; if (dist[nk] > d + 1) { dist[nk] = d + 1; q.push(nk); } }
  }
  const lists = new Map();
  const put = (key, geo, mat, x, y, z, sx, sy, sz, color, yaw = 0, tilt = 0) => {
    if (!lists.has(key)) lists.set(key, { geo, mat, items: [] });
    lists.get(key).items.push([x, y, z, sx, sy, sz, color, yaw, tilt]);
  };
  const lam = (c, e = 0) => new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: e });
  const M = { trunk: lam(), leaf: lam(), rock: lam(), glow: new THREE.MeshBasicMaterial({ color: 0xffffff }), ice: new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 }) };
  const out = (lo, hi, p) => { const r = []; for (let j = 0; j < MH; j++) for (let i = 0; i < MW; i++) { const d = dist[j * MW + i]; if (d >= lo && d <= hi && hash(i, j, 21) < p) r.push([i + 0.5 + (hash(i, j, 22) - 0.5) * 0.8, j + 0.5 + (hash(i, j, 23) - 0.5) * 0.8, i, j]); } return r; };
  const vary = (hex, k) => tmpC.set(hex).multiplyScalar(0.8 + k * 0.4).getHex();
  if (B.ground) {
    const g = B.ground;
    let mat;
    if (g.lava) { const t = lavaTex.clone(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(MW / 3, MH / 3); t.needsUpdate = true; G.lavaTex = t; mat = new THREE.MeshBasicMaterial({ map: t, color: 0xffffff }); }
    else if (g.water) mat = new THREE.MeshPhongMaterial({ color: g.color, shininess: 90, specular: 0x4a6a5a, transparent: true, opacity: 0.92 });
    else mat = new THREE.MeshLambertMaterial({ color: g.color });
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(MW + 40, MH + 40).rotateX(-Math.PI / 2), mat);
    plane.position.set(MW / 2, g.y, MH / 2); plane.receiveShadow = true; plane.userData.own = true; world.add(plane);
  }
  const key = Object.keys(BIOMES).find((k) => BIOMES[k] === B);
  if (key === 'woods') {
    for (const [x, z, i, j] of out(2, 8, 0.32)) { // trees
      const h = 1.4 + hash(i, j, 24) * 1.6, y0 = B.ground.y, gc = vary(pick([0x2f5a2a, 0x3a6a2a, 0x2a4a22, 0x4a6a2a]), hash(i, j, 25));
      put('trunk', envGeo.cyl, M.trunk, x, y0, z, 0.14, h * 0.6, 0.14, 0x4a3020);
      for (let t = 0; t < 3; t++) put('leaf', envGeo.cone, M.leaf, x, y0 + h * 0.45 + t * h * 0.32, z, 1.1 - t * 0.28, h * 0.55, 1.1 - t * 0.28, gc, hash(i, j, 26) * 6);
    }
    for (const [x, z, i, j] of out(1, 3, 0.18)) put('bush', envGeo.ball, M.leaf, x, B.ground.y + 0.3, z, 0.6, 0.45, 0.6, vary(0x3a5a2a, hash(i, j, 27)));
  }
  if (key === 'caverns') {
    for (const [x, z, i, j] of out(1, 9, 0.38)) { // stalagmites rising out of the chasm
      const h = 4 + hash(i, j, 24) * 6.5, r = 0.4 + hash(i, j, 25) * 0.6;
      put('rock', envGeo.cone, M.rock, x, B.ground.y, z, r, h, r, vary(0x4a4440, hash(i, j, 26)), hash(i, j, 27) * 6);
      if (hash(i, j, 28) < 0.25) { const c = pick([0x7ad8ff, 0xc07aff, 0x7affc8]); put('gem', envGeo.gem, M.glow, x, B.ground.y + h + 0.1, z, 0.22, 0.45, 0.22, c, hash(i, j, 29) * 6); const g = makeGlow(c, 1.6, 0.5); g.position.set(x, B.ground.y + h + 0.2, z); torchFlames.push(g); }
    }
  }
  if (key === 'forge') {
    for (const [x, z, i, j] of out(1, 7, 0.22)) { const h = 2 + hash(i, j, 24) * 3.5; put('rock', boxGeo, M.rock, x, B.ground.y - 0.5, z, 0.6 + hash(i, j, 25) * 0.6, h, 0.6 + hash(i, j, 26) * 0.6, vary(0x2a2424, hash(i, j, 27)), hash(i, j, 28)); }
    if (!MOBILE) { const lg = makeGlow(0xff5a10, 30, 0.08); lg.position.set(MW / 2, B.ground.y + 0.5, MH / 2); torchFlames.push(lg); } // phones: no screen-filling additive glow
  }
  if (key === 'frozen') {
    for (const [x, z, i, j] of out(1, 5, 0.26)) { const h = 0.8 + hash(i, j, 24) * 2; put('ice', envGeo.cone, M.ice, x, B.ground.y, z, 0.25 + hash(i, j, 25) * 0.3, h, 0.25 + hash(i, j, 25) * 0.3, vary(0x9fd0ff, hash(i, j, 26)), 0, (hash(i, j, 27) - 0.5) * 0.4); }
    for (const [x, z, i, j] of out(4, 9, 0.22)) { const h = 1.8 + hash(i, j, 24) * 1.4; for (let t = 0; t < 3; t++) put('leaf', envGeo.cone, M.leaf, x, B.ground.y + t * h * 0.3, z, 0.95 - t * 0.25, h * 0.5, 0.95 - t * 0.25, t === 2 ? 0xf2f8ff : vary(0x2a4a3a, hash(i, j, 25))); }
  }
  if (key === 'swamp') {
    for (const [x, z, i, j] of out(2, 8, 0.16)) { // giant glowing mushrooms
      const h = 1.2 + hash(i, j, 24) * 2.2, r = 0.7 + hash(i, j, 25) * 0.8, c = pick([0x5affd0, 0xc07aff, 0x7aff7a]);
      put('trunk', envGeo.cyl, M.trunk, x, B.ground.y, z, 0.16, h, 0.16, 0xd8d0b8);
      put('capm', envGeo.cap, lam(0xffffff, 0x000000), x, B.ground.y + h, z, r, r * 0.55, r, vary(c, 0.5));
      if (hash(i, j, 26) < 0.5) { const g = makeGlow(c, r * 2.2, 0.35); g.position.set(x, B.ground.y + h + 0.2, z); torchFlames.push(g); }
    }
    for (const [x, z, i, j] of out(1, 3, 0.25)) put('reed', envGeo.cone, M.leaf, x, B.ground.y, z, 0.05, 0.9 + hash(i, j, 27) * 0.6, 0.05, 0x5a7a3a, 0, (hash(i, j, 28) - 0.5) * 0.3);
  }
  // little things on the floors inside the rooms
  for (const r of rooms) {
    for (let k = 0; k < ri(4, 9); k++) {
      const i = ri(0, r.w - 1), j = ri(0, r.h - 1), ci = r.x0 + 1 + i, cj = r.z0 + 1 + j;
      if (map[cj * MW + ci] !== FLOOR || (Math.abs(i - 5) <= 1 && Math.abs(j - 6) <= 1)) continue;
      const x = ci + rand(), z = cj + rand();
      if (key === 'woods') { for (let t = 0; t < 4; t++) put('grass', envGeo.cone, M.leaf, x + rr(-0.15, 0.15), 0, z + rr(-0.15, 0.15), 0.04, rr(0.2, 0.4), 0.04, vary(0x5a8a3a, rand()), 0, rr(-0.3, 0.3)); }
      else if (key === 'swamp') { put('capm', envGeo.cap, lam(0xffffff, 0x000000), x, 0.12, z, 0.16, 0.1, 0.16, pick([0xc07aff, 0x7affc0])); put('trunk', envGeo.cyl, M.trunk, x, 0, z, 0.03, 0.13, 0.03, 0xd8d0b8); }
      else if (key === 'caverns') { const c = pick([0x7ad8ff, 0xc07aff]); put('gem', envGeo.gem, M.glow, x, 0.15, z, 0.08, 0.2, 0.08, c, rand() * 6, rr(-0.3, 0.3)); }
      else if (key === 'frozen') put('snowp', envGeo.ball, M.rock, x, 0, z, rr(0.25, 0.45), 0.12, rr(0.25, 0.45), 0xf2f8ff);
      else if (key === 'forge') put('coal', envGeo.gem, M.glow, x, 0.04, z, 0.08, 0.05, 0.08, pick([0xff5a10, 0xff8a20]), rand() * 6);
    }
  }
  for (const L of lists.values()) {
    const im = new THREE.InstancedMesh(L.geo, L.mat, L.items.length);
    L.items.forEach(([x, y, z, sx, sy, sz, color, yaw, tilt], k) => { de.set(tilt || 0, yaw || 0, 0); im.setMatrixAt(k, dm.compose(dv.set(x, y, z), dq.setFromEuler(de), ds.set(sx, sy, sz))); im.setColorAt(k, tmpC.set(color)); });
    im.instanceMatrix.needsUpdate = true; im.instanceColor.needsUpdate = true;
    im.castShadow = L.mat !== M.glow; im.receiveShadow = true; im.userData.own = true; world.add(im);
  }
}
const boneMat = new THREE.MeshLambertMaterial({ color: 0xd9cfb6, emissive: 0x2a251c });
const ironMat = new THREE.MeshLambertMaterial({ color: 0x2c2c36 });
const rubbleMat = new THREE.MeshLambertMaterial({ color: 0x6a6e78 });
const waxMat = new THREE.MeshLambertMaterial({ color: 0xe9dcc0, emissive: 0x3a2a10 });
const woodMat = new THREE.MeshLambertMaterial({ color: 0x3a2418 });
const lidMat = new THREE.MeshLambertMaterial({ color: 0x4e3222 });
const webMat = new THREE.MeshBasicMaterial({ map: webTex, transparent: true, depthWrite: false, side: THREE.DoubleSide, forceSinglePass: true, opacity: 0.8 }); // flat quads: one pass (two-pass DoubleSide re-resolves the program twice a frame)
const fogMat = new THREE.MeshBasicMaterial({ map: fogTex, transparent: true, depthWrite: false, color: 0x9ab4d8, opacity: 0.4 });
const shroudMat = new THREE.MeshBasicMaterial({ map: fogTex, color: 0x0a0c14, transparent: true, opacity: 0.6, depthWrite: false });
function dressRooms(wallMat) {
  const bones = [], irons = [], wax = [], wood = [], lids = [], rubble = [];
  const box = (list, x, y, z, sx, sy, sz, yaw = 0, roll = 0) => list.push([x, y, z, sx, sy, sz, yaw, roll]);
  fogPlanes = [];
  for (const r of rooms) {
    const lane = (i, j) => Math.abs(i - Math.floor(r.w / 2)) <= 1 || Math.abs(j - Math.floor(r.h / 2)) <= 1;
    const free = (i, j) => map[(r.z0 + 1 + j) * MW + r.x0 + 1 + i] === FLOOR && !lane(i, j);
    // bone piles and skulls along the walls (fewer outside the crypt)
    const crypt = !!(G.biome || BIOMES.crypt).crypt;
    const piles = crypt ? (r.type === 'start' ? 3 : ri(5, 9)) : ri(0, 2);
    for (let n = 0, tries = 0; n < piles && tries < 40; tries++) {
      const edge = ri(0, 3), i = edge === 0 ? 0 : edge === 1 ? r.w - 1 : ri(0, r.w - 1), j = edge === 2 ? 0 : edge === 3 ? r.h - 1 : ri(0, r.h - 1);
      if (!free(i, j)) continue;
      n++;
      const cx = r.x0 + 1.5 + i, cz = r.z0 + 1.5 + j;
      for (let b = 0; b < ri(3, 6); b++) box(bones, cx + rr(-0.35, 0.35), 0.03 + b * 0.015, cz + rr(-0.35, 0.35), rr(0.32, 0.5), 0.08, 0.09, rr(0, 3.14), rr(-0.2, 0.2));
      if (rand() < 0.6) {
        const sx = cx + rr(-0.15, 0.15), sz = cz + rr(-0.15, 0.15);
        box(bones, sx, 0.02, sz, 0.28, 0.24, 0.26);
        box(irons, sx - 0.07, 0.13, sz + 0.13, 0.08, 0.07, 0.02); box(irons, sx + 0.07, 0.13, sz + 0.13, 0.08, 0.07, 0.02);
      }
    }
    // rubble and loose bones scattered over the floor
    for (let k = 0; k < ri(10, 18); k++) {
      const i = ri(0, r.w - 1), j = ri(0, r.h - 1);
      if (map[(r.z0 + 1 + j) * MW + r.x0 + 1 + i] !== FLOOR) continue;
      const x = r.x0 + 1.5 + i + rr(-0.4, 0.4), z = r.z0 + 1.5 + j + rr(-0.4, 0.4);
      if (rand() < 0.7) box(rubble, x, 0, z, rr(0.08, 0.2), rr(0.05, 0.14), rr(0.08, 0.2), rr(0, 3));
      else box(bones, x, 0.02, z, rr(0.25, 0.4), 0.07, 0.08, rr(0, 3));
    }
    // skulls on some pillar tops
    for (let j = 1; j <= r.h; j++) for (let i = 1; i <= r.w; i++) {
      const c = (r.z0 + j) * MW + r.x0 + i;
      if (!crypt || map[c] !== OBST || coffinCells.has(c) || rand() > 0.35) continue;
      const x = r.x0 + i + 0.5, z = r.z0 + j + 0.5;
      box(bones, x, PILLAR_H + 0.18, z, 0.3, 0.26, 0.28, rr(-0.5, 0.5));
      box(irons, x - 0.07, PILLAR_H + 0.3, z + 0.14, 0.08, 0.07, 0.02); box(irons, x + 0.07, PILLAR_H + 0.3, z + 0.14, 0.08, 0.07, 0.02);
      const c2 = makeGlow(0xffb050, 0.3, 0.8); c2.position.set(x + 0.25, PILLAR_H + 0.37, z - 0.1); torchFlames.push(c2);
      box(wax, x + 0.25, PILLAR_H + 0.18, z - 0.1, 0.07, 0.16, 0.07);
    }
    // chains hanging on the north wall
    for (const cxw of shuffle([2.5, 5.5, 7.5, 9.5]).slice(0, crypt ? ri(1, 2) : 0)) {
      const x = r.x0 + cxw, len = ri(4, 8);
      for (let k = 0; k < len; k++) box(irons, x, 1.42 - k * 0.14, r.z0 + 1.08, 0.11, 0.13, 0.05, k % 2 ? Math.PI / 2 : 0);
      box(irons, x, 1.42 - len * 0.14, r.z0 + 1.1, 0.2, 0.2, 0.06); // shackle
    }
    // candle clusters in a corner or two
    for (const [i, j] of shuffle([[0, 0], [r.w - 1, 0], [0, r.h - 1], [r.w - 1, r.h - 1]]).slice(0, crypt ? ri(1, 2) : 0)) {
      if (!free(i, j)) continue;
      const cx = r.x0 + 1.5 + i + (i ? 0.2 : -0.2), cz = r.z0 + 1.5 + j + (j ? 0.2 : -0.2);
      for (let k = 0; k < ri(3, 5); k++) {
        const x = cx + rr(-0.25, 0.25), z = cz + rr(-0.25, 0.25), h = rr(0.1, 0.32);
        box(wax, x, 0, z, 0.07, h, 0.07);
        const fl = makeGlow(0xffb050, 0.3, 0.85); fl.position.set(x, h + 0.05, z); torchFlames.push(fl);
      }
    }
    // cobwebs in the two back corners
    for (const [x, rot, flip] of [[r.x0 + 1, Math.PI / 4, 1], [r.x0 + r.w + 1, -Math.PI / 4, -1]]) {
      if (rand() < 0.3 || !(crypt || (G.biome || {}).rock)) continue;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(2, 2).translate(1, -1, 0), webMat);
      m.position.set(x, 1.7, r.z0 + 1.02); m.rotation.x = -PITCH; m.scale.x = flip; world.add(m); // tilted to face the camera
    }
    // coffins
    for (const [ci, cj] of r.coffins || []) {
      box(wood, ci + 0.5, 0, cj + 1, 0.66, 0.34, 1.5);
      box(lids, ci + 0.5, 0.34, cj + 1, 0.58, 0.07, 1.4);
      box(irons, ci + 0.5, 0.41, cj + 0.8, 0.06, 0.03, 0.42); box(irons, ci + 0.5, 0.41, cj + 0.75, 0.3, 0.03, 0.06);
    }
    // low drifting fog (its texture fades out to the edges: no square, user 11-15)
    for (let k = 0; k < 2; k++) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(9, 9).rotateX(-Math.PI / 2), fogMat);
      m.position.set(r.cx + rr(-2, 2), 0.3 + k * 0.25, r.cz + rr(-2, 2)); m.renderOrder = 2;
      m.userData.base = m.position.clone(); m.userData.ph = rand() * 6; world.add(m); fogPlanes.push(m);
    }
    // rooms you haven't entered are pitch black
    if (r.type !== 'start') {
      const sh = new THREE.Mesh(new THREE.PlaneGeometry(r.w + 2.6, r.h + 2.6).rotateX(-Math.PI / 2), shroudMat.clone());
      sh.position.set(r.cx, 1.0, r.cz); sh.renderOrder = 5; world.add(sh); r.shroud = sh;
      const dim = new THREE.Mesh(new THREE.PlaneGeometry(r.w + 2, r.h + 2).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.45, depthWrite: false }));
      dim.position.y = -0.4; sh.add(dim); // a second, flat darkening layer under the mist
      for (const f of r.flames) { f.visible = false; f.userData.core.visible = false; }
    }
  }
  const inst = (mat, list) => {
    if (!list.length) return;
    const im = new THREE.InstancedMesh(boxGeo, mat, list.length);
    list.forEach(([x, y, z, sx, sy, sz, yaw, roll], k) => { de.set(0, yaw, roll); im.setMatrixAt(k, dm.compose(dv.set(x, y, z), dq.setFromEuler(de), ds.set(sx, sy, sz))); });
    im.castShadow = true; im.receiveShadow = true; im.userData.own = true; world.add(im);
  };
  inst(boneMat, bones); inst(ironMat, irons); inst(rubbleMat, rubble); inst(waxMat, wax); inst(woodMat, wood); inst(lidMat, lids);
}
// old stains so the place looks lived (and died) in
function biomeParticles(dt) {
  const px = player.x, pz = player.z, X = () => px + rr(-7, 7), Z = () => pz + rr(-9, 5);
  switch (G.biome.particle) {
    case 'dust': if (fxP(0.35)) spark(X(), rr(0.3, 2.6), Z(), 0x2c3038, { vx: rr(-0.15, 0.15), vy: rr(-0.05, 0.12), vz: rr(-0.15, 0.15), s: rr(0.06, 0.14), life: rr(2, 4), drag: 0 }); break;
    case 'fireflies': if (fxP(0.3)) spark(X(), rr(0.3, 2.2), Z(), Math.random() < 0.5 ? 0xd8ff6a : 0xffe46a, { vx: rr(-0.4, 0.4), vy: rr(-0.1, 0.25), vz: rr(-0.4, 0.4), s: rr(0.12, 0.24), life: rr(1.5, 3), drag: 0 }); break;
    case 'snow': for (let k = fxN(2); k > 0; k--) spark(X(), rr(3, 5), Z(), 0xdfeaff, { vx: rr(-0.4, 0.4), vy: rr(-1.3, -0.6), vz: rr(-0.2, 0.2), s: rr(0.07, 0.15), life: 4, drag: 0 }); break;
    case 'embers': if (fxP(0.6)) spark(X(), rr(-0.3, 0.6), Z(), pick([0xff7a1a, 0xffb040, 0xff4a10]), { vy: rr(0.8, 1.9), vx: rr(-0.3, 0.3), vz: rr(-0.3, 0.3), s: rr(0.08, 0.18), life: rr(2, 3.5), drag: 0 }); break;
    case 'spores': if (fxP(0.4)) spark(X(), rr(0.2, 2.2), Z(), pick([0x9aff7a, 0xc07aff, 0x7affd8]), { vx: rr(-0.2, 0.2), vy: rr(0, 0.2), vz: rr(-0.2, 0.2), s: rr(0.1, 0.2), life: rr(2.5, 4), drag: 0 }); break;
  }
}
function grimeFloor() {
  for (const r of rooms) {
    for (let k = 0; k < ri(4, 9); k++) splat(r.x0 + 1.5 + rand() * (r.w - 1), r.z0 + 1.5 + rand() * (r.h - 1), pick(G.biome.splats), rr(0.6, 1.9));
  }
}

// ---------- audio: CC0 recordings (audio/manifest.json), with the tiny synth below as the fallback ----------
// Everything plays through AC -> master (never <audio> elements: portal shims mute by suspending the WebAudio context).
// Which file plays for which name, and how loud, lives only in audio/manifest.json: swapping a sound = new file + that list.
// Nothing here is fetched before play: SFX + the boss track load a moment after the game starts (the prologue is a boss
// fight), then explore + combat. Until a name's file is in (or if it has none) its synth recipe plays.
let AC = null, master = null, noiseBuf = null, muted = false, silent = false, music = null;
const AUD = { man: null, buf: {}, started: false };
const rnd = (a) => a[Math.floor(Math.random() * a.length)]; // not pick(): that one draws from the seeded game RNG
function initAudio() {
  if (AC) { if (AC.state === 'suspended') AC.resume(); return; }
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    // compressor on the master lets hits and booms be loud without clipping
    const comp = AC.createDynamicsCompressor();
    comp.threshold.value = -16; comp.ratio.value = 6; comp.attack.value = 0.003; comp.release.value = 0.2;
    master = AC.createGain(); master.gain.value = muted ? 0 : 0.8; master.connect(comp).connect(AC.destination);
    noiseBuf = AC.createBuffer(1, AC.sampleRate, AC.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    music = startMusic();
    // the first visit drops straight into the prologue, so AC is born without a gesture (suspended): the first dialogue
    // tap / stick touch / key resumes it, and the music that already started on it becomes audible
    const unlock = () => { if (AC.state !== 'running') AC.resume().catch(() => {}); else for (const ev of ['pointerdown', 'touchend', 'keydown']) removeEventListener(ev, unlock, true); };
    for (const ev of ['pointerdown', 'touchend', 'keydown']) addEventListener(ev, unlock, true);
    if (!BENCH) setTimeout(loadAudio, 400);
  } catch (e) { AC = null; }
}
const AUDIO_DIR = ['cc0', 'b'].includes(params.get('audio')) ? `audio/${params.get('audio')}/` : 'audio/'; // ?audio=cc0 / ?audio=b: comparison sets on the test link (not in app/portal builds)
const decodeIn = (ctx, ab) => new Promise((res, rej) => { const p = ctx.decodeAudioData(ab, res, rej); if (p && p.then) p.then(res, rej); });
// MP3 encoders put ~25 ms of silence in front; skip it so hits land on the frame (and music loops stay tight)
function leadOf(b, th) {
  const d = b.getChannelData(0), n = Math.min(d.length, b.sampleRate * 0.25 | 0);
  let pk = 0; for (let i = 0; i < n; i++) pk = Math.max(pk, Math.abs(d[i]));
  const lim = th != null ? th : pk * 0.02;
  for (let i = 0; i < n; i++) if (Math.abs(d[i]) > lim) return i / b.sampleRate;
  return 0;
}
async function fetchBuf(file, ctx) {
  const r = await fetch(AUDIO_DIR + file + (AUD.man.v ? '?v=' + AUD.man.v : ''));
  if (!r.ok && r.status !== 0) throw new Error(file + ' ' + r.status); // status 0: the iOS app (Capacitor serves .mp3 with a non-HTTP response)
  const ab = await r.arrayBuffer();
  try { return await decodeIn(ctx, ab.slice(0)); } catch (e) { if (ctx === AC) throw e; return decodeIn(AC, ab); }
}
async function loadAudio() {
  if (AUD.started || !AC) return; AUD.started = true;
  try {
    const r = await fetch(AUDIO_DIR + 'manifest.json', { cache: 'no-cache' });
    AUD.man = await r.json();
  } catch (e) { console.warn('audio manifest', e); return; }
  // ?combat=c2 / ?menu=m1: an alt take from audio/alt/ on the test link (manifest volume, loop = the file's length)
  for (const k of ['combat', 'menu']) { const a = params.get(k); if (a && /^\w+$/.test(a) && AUD.man.music && AUD.man.music[k]) AUD.man.music[k] = { ...AUD.man.music[k], file: (AUDIO_DIR === 'audio/' ? '' : '../') + `alt/${k}_${a}.mp3`, loop: 0 }; }
  const man = AUD.man, t0 = performance.now();
  // the track needed right now (menu on the title, else boss: the prologue is the Stone King's) loads FIRST, alongside the
  // SFX, so the music doesn't wait behind 90 sound files (it started late on phones)
  let mctx = null;
  if (man.musicRate) try { mctx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, man.musicRate); } catch (e) { mctx = null; }
  const loadMusic = async (k) => {
    const m = man.music && man.music[k]; if (!m) return;
    try {
      let buf = await fetchBuf(m.file, mctx || AC);
      if (man.musicMono && buf.numberOfChannels > 1) {
        const mono = (mctx || AC).createBuffer(1, buf.length, buf.sampleRate), o = mono.getChannelData(0), n = buf.numberOfChannels;
        for (let c = 0; c < n; c++) { const d = buf.getChannelData(c); for (let i = 0; i < d.length; i++) o[i] += d[i] / n; }
        buf = mono;
      }
      music.add(k, buf, m);
    } catch (e) { console.warn('music', k, e.message || e); }
  };
  const order = G.state === 'title' ? ['menu', 'boss', 'explore', 'combat'] : ['boss', 'explore', 'combat', 'menu'];
  const firstTrack = loadMusic(order[0]);
  // 1) SFX, a few at a time
  const jobs = [];
  for (const [name, m] of Object.entries(man.sfx || {})) for (const f of m.files || []) jobs.push([name, f]);
  const worker = async () => {
    for (let j; (j = jobs.shift());) {
      try { const buf = await fetchBuf(j[1], AC); (AUD.buf[j[0]] = AUD.buf[j[0]] || []).push({ buf, lead: leadOf(buf) }); } catch (e) { console.warn('sfx', j[1], e.message || e); }
    }
  };
  await Promise.all([worker(), worker(), worker(), firstTrack]);
  // 2) the other tracks. Full stereo at the context's own rate by default (four ~1 min loops are ~100 MB of samples). A
  // manifest can still ask for a lower decode rate (musicRate) or a mono fold (musicMono) if phone memory is the problem.
  for (const k of order.slice(1)) await loadMusic(k);
  window.__audioLoaded = { sfx: Object.keys(AUD.buf).length, music: Object.keys(man.music || {}).length, ms: Math.round(performance.now() - t0) };
}
// the title screen: make the (suspended) context at once so the menu track is loaded and starts the moment anything is
// touched (not just a button), or plays straight away where the page may autoplay (portal iframes with allow=autoplay)
for (const ev of ['pointerdown', 'touchend', 'keydown']) addEventListener(ev, () => initAudio(), { capture: true, once: true });
setTimeout(() => { if (G.state === 'title' && !BENCH) initAudio(); }, 0);
const mtof = (n) => 440 * Math.pow(2, (n - 69) / 12);
function tone(t, f0, f1, dur, type = 'square', vol = 0.08, dest = master) {
  const o = AC.createOscillator(), g = AC.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(dest); o.start(t); o.stop(t + dur + 0.02);
}
function noiz(t, dur, vol, f0 = 2000, f1 = 300, type = 'lowpass', dest = master) {
  const s = AC.createBufferSource(); s.buffer = noiseBuf;
  const f = AC.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
  const g = AC.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f).connect(g).connect(dest); s.start(t, Math.random() * 0.5); s.stop(t + dur);
}
// Holy Beam's energy build-up (user 11-15: "it should sound like energy building up"): a 3-voice holy chord that rises in pitch
// and swells over 0.9 s while a shimmer overtone brightens, holds at full power with a slow throb, and fades when the beam
// ends (stop() cuts it early). Synthesized, no file.
function holyHum(dur) {
  if (!AC || muted || silent) return null;
  const t = AC.currentTime, out = AC.createGain(), lp = AC.createBiquadFilter(), oscs = [];
  lp.type = 'lowpass'; lp.frequency.setValueAtTime(700, t); lp.frequency.exponentialRampToValueAtTime(5200, t + 0.9);
  out.gain.setValueAtTime(0.0001, t); out.gain.exponentialRampToValueAtTime(0.16, t + 0.9); out.gain.setValueAtTime(0.16, t + Math.max(1, dur - 0.35)); out.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  lp.connect(out).connect(master);
  for (const [f, type, v] of [[261.6, 'sawtooth', 0.22], [329.6, 'triangle', 0.3], [392, 'triangle', 0.3], [1046, 'sine', 0.12]]) {
    const o = AC.createOscillator(), g = AC.createGain(); o.type = type;
    o.frequency.setValueAtTime(f * 0.5, t); o.frequency.exponentialRampToValueAtTime(f, t + 0.9); // the rise
    o.detune.setValueAtTime((Math.random() - 0.5) * 14, t); g.gain.value = v; o.connect(g).connect(lp); o.start(t); o.stop(t + dur + 0.05); oscs.push(o);
  }
  const lfo = AC.createOscillator(), lg = AC.createGain(); lfo.frequency.value = 5.5; lg.gain.value = 0.035; lfo.connect(lg).connect(out.gain); lfo.start(t + 0.9); lfo.stop(t + dur); // the throb at full power
  return { stop() { const n = AC.currentTime; out.gain.cancelScheduledValues(n); out.gain.setValueAtTime(Math.max(0.0001, out.gain.value), n); out.gain.exponentialRampToValueAtTime(0.0001, n + 0.25); for (const o of oscs) try { o.stop(n + 0.3); } catch (e) {} try { lfo.stop(n + 0.3); } catch (e) {} } };
}
const vr = (k = 0.12) => 1 + (Math.random() - 0.5) * k; // pitch variation so repeats don't sound robotic
const SFX = {
  bolt: (t) => { const v = vr(); tone(t, 1500 * v, 520, 0.08, 'square', 0.03); tone(t, 320 * v, 140, 0.06, 'sine', 0.07); },
  fire: (t) => { noiz(t, 0.3, 0.16, 1800, 250); tone(t, 180 * vr(), 70, 0.25, 'sawtooth', 0.05); },
  boom: (t) => { noiz(t, 0.7, 0.55, 1400, 45); tone(t, 95 * vr(), 28, 0.55, 'sine', 0.6); noiz(t + 0.05, 0.35, 0.12, 6000, 2500, 'highpass'); },
  frost: (t) => { noiz(t, 0.45, 0.16, 7000, 2200, 'highpass'); [2093, 2637, 3136].forEach((f, i) => tone(t + i * 0.03, f, f * 1.02, 0.3, 'triangle', 0.03)); tone(t, 200, 60, 0.25, 'sine', 0.2); },
  zap: (t) => { for (let i = 0; i < 4; i++) tone(t + i * 0.025, 700 + Math.random() * 1400, 150, 0.06, 'sawtooth', 0.045); noiz(t, 0.15, 0.15, 8000, 3000, 'highpass'); },
  orb: (t) => { tone(t, 260, 780, 0.35, 'sine', 0.1); tone(t + 0.05, 520, 1560, 0.3, 'triangle', 0.03); },
  venom: (t) => { noiz(t, 0.2, 0.14, 3500 * vr(), 900, 'bandpass'); tone(t, 900 * vr(), 400, 0.08, 'square', 0.02); },
  hit: (t) => { const v = vr(0.3); noiz(t, 0.05, 0.16, 4200 * v, 1200); tone(t, 170 * v, 55, 0.08, 'sine', 0.22); },
  kill: (t) => { const v = vr(0.2); tone(t, 210 * v, 38, 0.2, 'sine', 0.42); noiz(t, 0.16, 0.22, 3200 * v, 180); tone(t + 0.02, 1100 * v, 2200 * v, 0.06, 'square', 0.025); },
  hurt: (t) => { tone(t, 320, 55, 0.35, 'sawtooth', 0.16); noiz(t, 0.25, 0.3, 1600, 90); tone(t, 90, 30, 0.3, 'sine', 0.4); },
  coin: (t, n = 0) => { const f = 1320 * Math.pow(2, Math.min(n, 14) / 12); tone(t, f, f, 0.05, 'square', 0.03); tone(t + 0.05, f * 1.5, f * 1.5, 0.09, 'square', 0.03); },
  heal: (t) => [523, 659, 784, 1046].forEach((f, i) => tone(t + i * 0.06, f, f, 0.18, 'triangle', 0.08)),
  whoosh: (t) => { noiz(t, 0.2, 0.18, 700, 4000, 'bandpass'); tone(t, 300, 700, 0.12, 'sine', 0.05); },
  portal: (t) => { tone(t, 180, 720, 0.4, 'sine', 0.07); noiz(t, 0.4, 0.05, 1500, 5000, 'bandpass'); },
  spit: (t) => tone(t, 520 * vr(), 240, 0.12, 'triangle', 0.06),
  clear: (t) => { // victory fanfare: low impact, a rising major arpeggio into a held chord, a bright bell on top, a shimmer tail
    tone(t, 90, 45, 0.5, 'sine', 0.5); noiz(t, 0.35, 0.18, 1200, 120);
    [60, 64, 67, 72].forEach((n, i) => { const f = mtof(n); tone(t + i * 0.07, f, f, 0.22, 'square', 0.035); tone(t + i * 0.07, f, f, 0.3, 'triangle', 0.06); });
    [72, 76, 79, 84].forEach((n) => { const f = mtof(n); tone(t + 0.3, f, f, 1.4, 'triangle', 0.045); tone(t + 0.3, f * 1.004, f * 1.004, 1.4, 'sine', 0.03); });
    tone(t + 0.3, mtof(96), mtof(96), 1.8, 'sine', 0.05); tone(t + 0.3, mtof(96) * 2.76, mtof(96) * 2.7, 0.9, 'sine', 0.015);
    noiz(t + 0.28, 1.6, 0.06, 9000, 4000, 'highpass');
  },
  cleared: (t) => [67, 72, 76].forEach((n, i) => { const f = mtof(n); tone(t + i * 0.06, f, f, 0.35, 'triangle', 0.05); }), // soft chime for a normal room
  card: (t) => { tone(t, 660, 990, 0.09, 'sine', 0.05); tone(t + 0.04, 990, 1320, 0.1, 'sine', 0.03); },
  tap: (t) => { tone(t, 1250, 950, 0.045, 'sine', 0.045); tone(t, 620, 480, 0.06, 'triangle', 0.03); }, // soft UI click
  buy: (t) => [76, 83].forEach((n, i) => { const f = mtof(n); tone(t + i * 0.07, f, f, 0.28, 'sine', 0.06); tone(t + i * 0.07, f * 2, f * 2, 0.12, 'sine', 0.015); }),
  lock: (t) => { tone(t, 110, 70, 0.45, 'square', 0.08); noiz(t, 0.35, 0.3, 700, 60); tone(t, 60, 30, 0.4, 'sine', 0.4); },
  wave: (t) => [196, 233, 294].forEach((f, i) => tone(t + i * 0.09, f, f, 0.25, 'sawtooth', 0.04)),
  stairs: (t) => [262, 330, 392, 523, 659].forEach((f, i) => tone(t + i * 0.09, f, f * 0.5, 0.35, 'triangle', 0.09)),
  land: (t) => { tone(t, 120, 40, 0.25, 'sine', 0.5); noiz(t, 0.25, 0.25, 900, 80); },
  slam: (t) => { noiz(t, 0.7, 0.5, 600, 35); tone(t, 70, 25, 0.6, 'sine', 0.6); },
  pot: (t) => { noiz(t, 0.14, 0.2, 2800 * vr(), 600, 'bandpass'); tone(t, 700 * vr(), 300, 0.05, 'square', 0.03); },
  drip: (t) => { const f = 1300 * vr(0.3); tone(t, f, f * 0.4, 0.09, 'sine', 0.05); tone(t + 0.12, f * 0.8, f * 0.35, 0.06, 'sine', 0.02); },
  moan: (t) => {
    const o = AC.createOscillator(), f = AC.createBiquadFilter(), g = AC.createGain(), base = rr(95, 140);
    o.type = 'sawtooth'; o.frequency.setValueAtTime(base, t); o.frequency.linearRampToValueAtTime(base * 1.12, t + 0.8); o.frequency.linearRampToValueAtTime(base * 0.72, t + 2.6);
    f.type = 'bandpass'; f.frequency.setValueAtTime(500, t); f.frequency.linearRampToValueAtTime(800, t + 1); f.frequency.linearRampToValueAtTime(380, t + 2.6); f.Q.value = 5;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.03, t + 0.4); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
    o.connect(f).connect(g).connect(master); o.start(t); o.stop(t + 2.9);
  },
  chains: (t) => { for (let i = 0; i < 7; i++) { const tt = t + i * 0.08 + Math.random() * 0.04; tone(tt, 2600 + Math.random() * 1600, 1900, 0.05, 'square', 0.012); noiz(tt, 0.04, 0.03, 9000, 5000, 'highpass'); } },
  creak: (t) => { const o = AC.createOscillator(), g = AC.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(70, t); for (let k = 1; k < 12; k++) o.frequency.setValueAtTime(60 + Math.random() * 40, t + k * 0.08); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.03, t + 0.2); g.gain.exponentialRampToValueAtTime(0.0001, t + 1); const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 700; o.connect(f).connect(g).connect(master); o.start(t); o.stop(t + 1.05); },
  spike: (t) => { noiz(t, 0.08, 0.2, 7000, 3000, 'highpass'); tone(t, 1900, 900, 0.07, 'square', 0.03); },
  hiss: (t) => noiz(t, 0.8, 0.12, 6000, 2000, 'highpass'),
  puff: (t) => { noiz(t, 0.3, 0.07, 2500, 600, 'bandpass'); }, // a vent's short gas puff
  laser: (t) => { tone(t, 90, 160, 0.9, 'sawtooth', 0.08); noiz(t, 0.9, 0.06, 3000, 6000, 'bandpass'); },
  // monster attacks (short, punchy arcade hits)
  swing: (t) => { const v = vr(0.2); noiz(t, 0.13, 0.3, 900 * v, 5200 * v, 'bandpass'); tone(t, 420 * v, 950 * v, 0.08, 'triangle', 0.04); },
  clink: (t) => { const v = vr(0.1); tone(t, 2200 * v, 2100 * v, 0.16, 'square', 0.03); tone(t, 3300 * v, 3240 * v, 0.22, 'triangle', 0.05); tone(t, 5100 * v, 5000 * v, 0.1, 'sine', 0.03); noiz(t, 0.05, 0.2, 9000, 4000, 'highpass'); },
  thud: (t) => { tone(t, 115 * vr(), 32, 0.32, 'sine', 0.6); noiz(t, 0.22, 0.42, 900, 60); tone(t, 230, 60, 0.07, 'square', 0.05); },
  bowdraw: (t) => { tone(t, 140, 210, 0.45, 'sawtooth', 0.015); noiz(t, 0.4, 0.03, 1200, 2600, 'bandpass'); },
  twang: (t) => { tone(t, 330 * vr(), 250, 0.18, 'sawtooth', 0.05); tone(t, 660, 520, 0.1, 'triangle', 0.04); noiz(t + 0.02, 0.12, 0.14, 2500, 7000, 'bandpass'); },
  roll: (t) => { noiz(t, 0.5, 0.25, 320, 110); tone(t, 70, 95, 0.5, 'sawtooth', 0.04); },
  chant: (t) => { [0, 3, 7].forEach((n, i) => { const f = mtof(57 + n); tone(t + i * 0.08, f, f * 1.01, 0.5, 'sawtooth', 0.018); }); noiz(t, 0.6, 0.05, 800, 2400, 'bandpass'); },
  splat: (t) => { const v = vr(0.2); noiz(t, 0.14, 0.22, 900 * v, 250, 'bandpass'); tone(t, 260 * v, 90, 0.12, 'sine', 0.12); }, // a wet slime landing
  scream: (t) => { tone(t, 900, 1500, 0.35, 'sawtooth', 0.025); tone(t, 1210, 1900, 0.3, 'triangle', 0.03); noiz(t, 0.35, 0.08, 2500, 6000, 'bandpass'); },
  skitter: (t) => { for (let i = 0; i < 4; i++) noiz(t + i * 0.035, 0.025, 0.07, 6000, 3000, 'highpass'); },
  rockfall: (t) => SFX.slam(t), revive: (t) => SFX.heal(t), levelup: (t) => SFX.heal(t), chest: (t) => SFX.clear(t),
  beat: (t) => { // low-HP heartbeat: a sub thump plus a 2nd harmonic and a soft knock, so phone speakers can hear it
    tone(t, 70, 45, 0.14, 'sine', 0.55); tone(t, 140, 90, 0.1, 'sine', 0.22); noiz(t, 0.04, 0.12, 900, 200);
    tone(t + 0.17, 65, 40, 0.13, 'sine', 0.4); tone(t + 0.17, 130, 80, 0.09, 'sine', 0.16); noiz(t + 0.17, 0.035, 0.08, 800, 200); },
};
for (const k of ['moan', 'drip', 'hiss', 'puff', 'chains', 'creak']) SFX[k] = () => {}; // no ambient wails, drips, hisses or creaks: the user hates them
const lastSfx = {};
// ?sndlog: an on-screen list of every sound as it plays (name, how many times in the last 10 s, how long ago) plus the
// music mode, so a mystery sound can be named from the phone
const SNDLOG = params.has('sndlog'), sndHits = [];
let sndEl = null;
function sndLog(name) {
  const now = performance.now(); sndHits.push([name, now]);
  if (!sndEl) {
    sndEl = document.createElement('div');
    sndEl.style.cssText = 'position:fixed;left:6px;top:40%;z-index:9999;pointer-events:none;font:12px/1.35 monospace;color:#fff;background:rgba(0,0,0,.6);padding:6px 8px;border-radius:6px;white-space:pre';
    document.body.appendChild(sndEl);
    setInterval(() => {
      const t = performance.now(); while (sndHits.length && t - sndHits[0][1] > 10000) sndHits.shift();
      const c = {}; for (const [n, at] of sndHits) c[n] = { k: ((c[n] || {}).k || 0) + 1, at };
      const rows = Object.entries(c).sort((a, b) => b[1].at - a[1].at).slice(0, 12).map(([n, v]) => `${n.padEnd(9)} x${v.k}  ${((t - v.at) / 1000).toFixed(1)}s ago`);
      const NL = String.fromCharCode(10); sndEl.textContent = 'music: ' + (music ? music.mode : '-') + NL + (rows.join(NL) || '(no sounds)');
    }, 250);
  }
}
function sfx(name, arg) {
  if (!AC || muted || silent) return;
  const t = AC.currentTime, m = AUD.man && AUD.man.sfx && AUD.man.sfx[name];
  if (lastSfx[name] && t - lastSfx[name] < ((m && m.gap) || 0.035)) return;
  lastSfx[name] = t; if (SNDLOG) sndLog(name);
  const bs = AUD.buf[name];
  if (!bs) { if (SFX[name]) SFX[name](t, arg); return; }
  const b = rnd(bs), s = AC.createBufferSource(), g = AC.createGain();
  s.buffer = b.buf;
  let rate = 1 + (Math.random() - 0.5) * (m.pitch != null ? m.pitch : 0.1); // slight random pitch so repeats don't sound robotic
  if (name === 'coin' && arg) rate *= Math.pow(2, Math.min(arg, 14) / 12); // a coin chain climbs in semitones
  s.playbackRate.value = rate;
  g.gain.value = m.vol != null ? m.vol : 0.5;
  s.connect(g).connect(master); s.start(t, b.lead);
}
// Music: looping recordings (menu, explore, combat, boss) on their own gains, crossfaded by mode. menu(v) is the title
// screen, combat(v) a locked room, boss(v) a boss room or the prologue; menu > boss > combat > explore. A track that has been silent for a while
// starts again from its top when it comes back, so a fight opens with its intro. Nothing plays until a file is in.
function startMusic() {
  const bus = AC.createGain(); bus.gain.value = 1; bus.connect(master); let ducked = false;
  const tracks = {}; // name -> { g, buf, vol, loop, src, quietAt }
  let combat = false, boss = false, menu = false, cur = null;
  const PREF = { menu: ['menu'], explore: ['explore'], combat: ['combat', 'boss'], boss: ['boss', 'combat'] };
  const want = () => (menu ? 'menu' : boss ? 'boss' : combat ? 'combat' : 'explore');
  const log = (t) => { if (window.__musicLog) window.__musicLog.push(t); };
  const tailOf = (b) => { const d = b.getChannelData(0), n = Math.min(d.length, b.sampleRate * 0.25 | 0); for (let i = d.length - 1; i > d.length - n; i--) if (Math.abs(d[i]) > 0.0005) return (i + 1) / b.sampleRate; return b.duration; };
  const play = (k) => {
    const tr = tracks[k];
    if (tr.src) { try { tr.src.stop(); } catch (e) { /* already stopped */ } tr.src.disconnect(); }
    const s = AC.createBufferSource(); s.buffer = tr.buf; s.loop = true;
    const lead = leadOf(tr.buf, 0.0005), end = tr.loop ? Math.min(tr.buf.duration, lead + tr.loop) : tailOf(tr.buf); // no gap from MP3 padding
    s.loopStart = lead; s.loopEnd = end; s.connect(tr.g); s.start(AC.currentTime + 0.02, lead); tr.src = s; log('playing ' + k + ' ctx=' + AC.state);
  };
  const apply = () => {
    const k = PREF[want()].find((n) => tracks[n]) || null; // a fight before its track is in borrows the other fight track
    if (k === cur) return;
    const now = AC.currentTime;
    for (const [n, tr] of Object.entries(tracks)) {
      if (n === k) {
        if (!tr.src || (tr.quietAt != null && now - tr.quietAt > 10)) play(n);
        tr.quietAt = null;
        tr.g.gain.cancelScheduledValues(now); tr.g.gain.setTargetAtTime(tr.vol, now, n === 'explore' ? 1.2 : 0.25);
      } else if (n === cur) {
        tr.quietAt = now; tr.g.gain.cancelScheduledValues(now); tr.g.gain.setTargetAtTime(0, now, k === 'explore' ? 0.9 : 0.3);
      }
    }
    cur = k;
  };
  return {
    add(k, buf, m) { // a decoded track arrived
      const g = AC.createGain(); g.gain.value = 0; g.connect(bus);
      tracks[k] = { g, buf, vol: m.vol != null ? m.vol : 0.5, loop: m.loop, src: null, quietAt: null };
      log('loaded ' + k); apply();
    },
    combat(v) { if (v === combat) return; combat = v; log('mode ' + want()); apply(); },
    boss(v) { if (v === boss) return; boss = v; log('mode ' + want()); apply(); },
    menu(v) { if (v === menu) return; menu = v; log('mode ' + want()); apply(); },
    duck(v) { if (v === ducked) return; ducked = v; bus.gain.setTargetAtTime(v ? 0.4 : 1, AC.currentTime, v ? 0.25 : 0.6); }, // low HP: music sinks under the heartbeat
    get mode() { return cur; },
  };
}

// ---------- game data ----------
const SPELLS = new Proxy({}, { get: (_, id) => spellDef(id) || { name: '?', color: '#ffffff', cd: 1, els: [], sh: {} } });
const RELICS = [
  { id: 'boots', name: 'Swift Boots', info: '+15% move speed', icon: ['items', 5], apply: () => { player.speed *= 1.15; } },
  { id: 'vessel', name: 'Heart Vessel', info: '+1 heart and full heal', icon: ['items', 2], apply: () => { player.maxHp += 2; player.hp = player.maxHp; } },
  { id: 'prism', name: 'Mana Prism', info: 'All cooldowns -10%', icon: ['items', 3], apply: () => { player.cdMul *= 0.9; } },
  { id: 'lens', name: 'Cruel Lens', info: '+12% critical hit chance', icon: ['spells', 0], apply: () => { player.crit += 0.12; } },
  { id: 'lode', name: 'Golden Idol', info: '+30% coins', icon: ['items', 0], apply: () => { G.coinMul = (G.coinMul || 1) + 0.3; } }, // was Lodestone (pickup range): room clears now collect every coin
  { id: 'tome', name: 'Grimoire', info: '+20% spell damage', icon: ['items', 4], apply: () => { player.dmgMul *= 1.2; } },
  { id: 'feather', name: 'Phoenix Feather', info: 'Revive once with a fire burst', icon: ['spells', 1], apply: () => { player.revive++; } },
  { id: 'cloak', name: 'Shadow Cloak', info: '+10% dodge chance', icon: ['items', 1], apply: () => { player.cloakDodge = (player.cloakDodge || 0) + 0.1; } },
  { id: 'ember', name: 'Ember Heart', info: 'Getting hit sets off a fire burst', icon: ['spells', 1], apply: () => { player.ember = true; } },
];
const ENEMY = {
  slime: { hp: 24, r: 0.36, speed: 4.4, splat: 0x1a8a5a, chunk: 0x6affa8, coin: 0.45 }, // green jelly (user: not Pip pink)
  eyeboss: { hp: 950, r: 1.0, speed: 2.6, splat: 0x9b0f22, chunk: 0xf3e6ea, coin: 1, sheet: 'hollow', fly: true, band: [5.2, 0.3] },
  golemboss: { hp: 1300, r: 1.1, speed: 1.6, splat: 0x4a545e, chunk: 0x8a96a0, coin: 1, sheet: 'stoneking' },
  tyrant: { hp: 1150, r: 1.0, speed: 2.1, splat: 0x6e6658, chunk: 0xe8e0cc, coin: 1, sheet: 'tyrant' },
  sporeboss: { hp: 1050, r: 1.1, speed: 0.9, splat: 0x5a2a7a, chunk: 0xb070ff, coin: 1, sheet: 'sporemother', tellCol: 0x9add4a },
  wraithboss: { hp: 900, r: 0.9, speed: 2.4, splat: 0x5fc8d8, chunk: 0xbff3ff, coin: 1, sheet: 'wraith', fly: true, band: [5, 1.4] },
  mimic: { hp: 150, r: 0.45, speed: 5, splat: 0x3a2418, chunk: 0x8a5a2a, coin: 1 },
  mimiclord: { hp: 1150, r: 1.1, speed: 2.2, splat: 0x3a2418, chunk: 0xffd34f, coin: 1, sheet: 'mimiclord', band: [5.5, 0.5] }, // band: before a coin fan
  frostboss: { hp: 1000, r: 0.9, speed: 2.3, splat: 0x6fb8d8, chunk: 0xd8f4ff, coin: 1, sheet: 'frostmatriarch', tellCol: 0xcdf0ff, band: [5.5, 1.4] }, // tellCol: her cast tell glows icy, not the shared red
  sentinel: { hp: 1250, r: 1.05, speed: 1.5, splat: 0x3a2a1a, chunk: 0xc89a4a, coin: 1, sheet: 'sentinel', band: [5.2, 0.5] },
  big: { hp: 140, r: 0.6, speed: 3.6, splat: 0x1a8a5a, chunk: 0x6affa8, coin: 0.9, sheet: 'slime', h: 1.35 },
  eye: { hp: 20, r: 0.34, speed: 2.6, splat: 0x9b0f22, chunk: 0xf3e6ea, coin: 0.5, fly: true, band: [4.8, 1.2] },
  imp: { hp: 12, r: 0.3, speed: 3.45, splat: 0x170b1e, chunk: 0x3a1a44, coin: 0.4 },
  skeleton: { hp: 70, r: 0.36, speed: 2.3, splat: 0x6e6658, chunk: 0xe8e0cc, coin: 0.6 },
  boss: { hp: 1100, r: 1.15, speed: 6, splat: 0x1a1a8a, chunk: 0x6a7aff, coin: 1 }, // King Gloop: royal blue (was Pip pink)
  bomber: { hp: 10, r: 0.32, speed: 4.8, splat: 0x2a1a10, chunk: 0xff8a2a, coin: 0.4 },
  ghost: { hp: 30, r: 0.32, speed: 2.6, splat: 0x5fc8d8, chunk: 0xbff3ff, coin: 0.5, fly: true, band: [5, 0.7] }, // floats at a distance; it only comes close by a blink that ends in its scream
  shroom: { hp: 55, r: 0.36, speed: 1.1, splat: 0x5a2a7a, chunk: 0xb070ff, coin: 0.5, band: [5, 0.4] }, // shuffles back when Pip closes in (was rooted: Pip just walked up to it)
  golem: { hp: 320, r: 0.6, speed: 1.7, splat: 0x4a545e, chunk: 0x8a96a0, coin: 0.9, body: 'golem_b', h: 1.65 }, // h: golems ~25% bigger than the art's default (user: too small)
  // the newer foes (see PARTS): body = the in-game sprite when it differs from sheet; skeleton keeps skeleton.png for its death flash
  cursed: { hp: 80, r: 0.4, speed: 2.1, splat: 0x5a3a20, chunk: 0xe8c890, coin: 0.7, sheet: 'skel_1' },
  reaper: { hp: 58, r: 0.42, speed: 2.9, splat: 0x4a1a40, chunk: 0xe8d8c8, coin: 0.7, sheet: 'skel_2' },
  boneknight: { hp: 150, r: 0.42, speed: 2.0, splat: 0x2a2a30, chunk: 0xe8e0cc, coin: 0.9, sheet: 'skel_3' },
  runegolem: { hp: 330, r: 0.62, speed: 1.6, splat: 0x2a3050, chunk: 0x6a70a8, coin: 0.9, sheet: 'golem_1', h: 1.75 },
  crystalgolem: { hp: 340, r: 0.62, speed: 1.6, splat: 0x6a4a2a, chunk: 0xd8a868, coin: 0.9, sheet: 'golem_2', h: 1.75 },
  magmagolem: { hp: 360, r: 0.64, speed: 1.7, splat: 0x1a0a08, chunk: 0xff6a20, coin: 0.9, sheet: 'golem_3', h: 1.8 },
  archer: { hp: 40, r: 0.36, speed: 2.4, splat: 0x3a2a20, chunk: 0xe8e0cc, coin: 0.6, band: [5.2, 0.9] },
  spider: { hp: 16, r: 0.3, speed: 3.4, splat: 0x2a0a3a, chunk: 0x8fe8ff, coin: 0.35 },
  salamander: { hp: 40, r: 0.33, speed: 4.2, splat: 0x3a0a04, chunk: 0xff7a2a, coin: 0.5, h: 0.65 }, // h: 1.25x (it was a speck on a phone)
  shieldk: { hp: 150, r: 0.48, speed: 1.5, splat: 0x2a1a3a, chunk: 0xb070ff, coin: 0.9 },
  cultist: { hp: 55, r: 0.36, speed: 2.0, splat: 0x5a0a10, chunk: 0xffd34f, coin: 0.8, tellCol: 0xffd34f, band: [6.5, 0.6] },
  beetle: { hp: 90, r: 0.42, speed: 1.7, splat: 0x3a1a08, chunk: 0xc86a2a, coin: 0.7 },
};
ENEMY.skeleton.body = 'skeleton_b'; ENEMY.golemboss.body = 'stoneking_b'; ENEMY.tyrant.body = 'tyrant_b'; // bosses with a swinging fist / greatsword
const GHOST_CONE = 3.4; // the ghost's scream cone: it blinks in 2.5-2.9 from Pip, the cone reaches past him
const SKELS = new Set(['skeleton', 'cursed', 'reaper', 'boneknight']), GOLEMS = new Set(['golem', 'runegolem', 'crystalgolem', 'magmagolem']);
// telegraphed melee foes: they stop at a standoff (body r + Pip r + STAND_GAP) and only their marked blows hurt
const MELEE = new Set([...SKELS, ...GOLEMS, 'shieldk', 'salamander', 'spider', 'beetle', 'archer', 'cultist']), STAND_GAP = 0.15;
const touchHurts = (e) => e.type === 'golemboss' ? e.state === 'charge' : e.type === 'tyrant' ? false : !MELEE.has(e.type) || (GOLEMS.has(e.type) && e.state === 'charge') || (e.type === 'beetle' && e.state === 'roll');
const isGolem = (e) => GOLEMS.has(e.type), isBigFoe = (e) => e.type === 'big' || GOLEMS.has(e.type) || e.type === 'shieldk' || e.type === 'boneknight';

// ---------- state ----------
const BOSSES = [
  { type: 'boss', name: 'KING GLOOP', sub: 'THE JELLY TYRANT' },
  { type: 'eyeboss', name: 'THE HOLLOW EYE', sub: 'IT HAS ALREADY SEEN YOU' },
  { type: 'golemboss', name: 'THE STONE KING', sub: 'OLDER THAN THE DUNGEON' },
  { type: 'tyrant', name: 'THE BONE TYRANT', sub: 'HE RULES THE DEAD' },
  { type: 'sporeboss', name: 'MOTHER SPORE', sub: 'SHE FEEDS THE DARK' },
  { type: 'wraithboss', name: 'THE WRAITH QUEEN', sub: 'SHE WAS ONCE A WIZARD' },
  { type: 'mimiclord', name: 'THE MIMIC LORD', sub: 'ALL THAT GLITTERS BITES' },
  { type: 'frostboss', name: 'THE FROST MATRIARCH', sub: 'WINTER NEVER LEFT' },
  { type: 'sentinel', name: 'THE CLOCKWORK SENTINEL', sub: 'IT STILL KEEPS ITS WATCH' },
];
const G = { biomeKey: 'crypt', biome: null, boss: BOSSES[0], combo: 0, comboT: 0, comboPop: 0, coinChain: 0, coinT: 0, state: 'title', floor: 1, time: 0, hitstop: 0, slowmo: 0, kills: 0, coins: 0, curRoom: null, waveDelay: 0, best: 0, deadT: 0, pal: PALETTES[0], cardsOpen: 0 };
// ---------- meta progression: soul shards + permanent upgrades, saved on this device ----------
const META_KEY = 'rbd_meta_v1';
const UPGRADES = [
  { id: 'vit', name: 'Vitality', info: '+1 starting heart', max: 3, cost: [150, 350, 700], icon: ['items', 2] },
  { id: 'pow', name: 'Arcane Power', info: '+8% spell damage', max: 5, cost: [100, 200, 350, 550, 800], icon: ['spells', 0] },
  { id: 'haste', name: 'Haste', info: '-5% spell cooldowns', max: 5, cost: [125, 250, 425, 650, 900], icon: ['items', 3] },
  { id: 'swift', name: 'Swiftness', info: '+5% move speed', max: 3, cost: [100, 225, 400], icon: ['items', 5] },
  { id: 'greed', name: 'Greed', info: '+20% coins', max: 3, cost: [75, 175, 300], icon: ['items', 0] },
  { id: 'reach', name: 'Keen Eye', info: '+3% critical hit chance', max: 3, cost: [50, 125, 225], icon: ['items', 1] }, // id kept for old saves (was pickup range)
  { id: 'fate', name: 'Fate', info: 'Legendary spells show up more', max: 3, cost: [200, 450, 800], icon: ['spells', 4] },
  { id: 'relic', name: 'Heirloom', info: 'Start every run with a relic', max: 1, cost: [600], icon: ['items', 4] },
  { id: 'life', name: 'Second Life', info: 'Revive once per run', max: 1, cost: [1000], icon: ['spells', 1] },
];
function loadMeta() {
  const d = { shards: 0, up: {}, codex: [], elements: START_ELEMENTS.slice(), hero: 'wizard', heroes: Object.keys(HEROES), dungeon: 'crypt', legacy: 0, legacyXp: 0, vault: {}, stash: [], tutDone: false, statBuy: {}, wins: 0, winStats: 0, winLegend: null, winRevive: 0, start: 'arcane.missiles', stats: { runs: 0, bestFloor: 0, kills: 0, bosses: 0, champs: 0, coins: 0, time: 0, bestCombo: 0, dmg: 0, shardsTotal: 0 } };
  try {
    const m = JSON.parse(localStorage.getItem(META_KEY) || 'null');
    if (m) { const r = { ...d, ...m, up: { ...m.up }, stats: { ...d.stats, ...m.stats } }; r.hero = 'wizard'; r.start = migrateId(r.start); r.codex = [...new Set((Array.isArray(r.codex) ? r.codex : []).map(migrateId))]; return r; } // old element.shape ids -> signature spells
    d.stats.bestFloor = +localStorage.getItem('rbd_best') || 0; // carry over the old best
    d.fresh = 1; // a default save made on this device: ranks below any real progress (durable.js); cleared by the prologue / a finished run
  } catch (e) { /* storage blocked: progress lives for this session only */ }
  return d;
}
const meta = loadMeta();
function saveMeta() { if (ZOO || saveLocked()) return; /* the zoo never touches the save; locked: a restored save waits for the reload */ meta.t = Date.now(); const j = JSON.stringify(meta); try { localStorage.setItem(META_KEY, j); } catch (e) { /* ignore */ } mirror(META_KEY, j); }
const mlv = (id) => meta.up[id] || 0;
G.best = meta.stats.bestFloor;
let player = null;
let meteors = [], mines = [], rays = [], wisps = [], clouds = [], beams = [], frings = [], ices = [], hazards = [], holes = [], enemies = [], projs = [], eprojs = [], pickups = [], portals = [], rings = [], bolts = [], texts = [], orbs = [], pots = [], fires = [], props = [], barriers = [];
let spells = [];
let gusts = []; // Storm Gust clouds (unique spell)
const input ={ x: 0, z: 0, keys: new Set(), stick: null };

function newPlayer() {
  const hid = 'wizard', hero = { ...HEROES[hid], id: hid }; // single hero for now
  return {
    hero, lv: 1, xp: 0, statPts: 0, alloc: { str: 0, agi: 0, vit: 0, int: 0, dex: 0, luk: 0 }, st: { ...hero.base }, der: derive(hero.cls, hero.base),
    g: gearTotals({}), gear: {}, bag: [], bonusHp: 0, casts: 0, critDmg: 2, area: 1, dur: 1, extraProj: 0, luck: 0, elPow: {},
    x: 0, z: 0, vx: 0, vz: 0, r: 0.3, hp: 6, maxHp: 6, speed: 5.4, iframe: 0,
    face: 1, anim: 0, step: 0, crit: 0.05, cdMul: 1, dmgMul: 1, magnet: 2.2, revive: 0, ember: false, relics: [], resAcc: 0,
    mesh: makeSprite(hero.sprite), shadow: makeShadow(0.8), staffGlow: (() => { const g = makeGlow(hero.tipColor, 0.45, 0.75); g.material.depthTest = false; g.renderOrder = 10; return g; })(), /* drawn over the wizard */ alive: true, aimX: 0, aimZ: -1, squash: 0,
  };
}

function resetLevelObjects(keep = false) { // keep (the zoo): the room's pots, props, barriers and floor hazards stay
  const kept = keep ? { pots, props, barriers, hazards } : null;
  $('bossbar').classList.add('hidden');
  for (const e of enemies) { killMesh(e.mesh); killMesh(e.wpn); scene.remove(e.shadow); freeFoeFx(e); }
  resetFoeFx();
  for (const p of projs) killProj(p);
  for (const p of eprojs) killProj(p);
  for (const p of pickups) { killMesh(p.mesh); scene.remove(p.shadow); if (p.beam) scene.remove(p.beam); if (p.glow) killGlow(p.glow); }
  for (const p of portals) { scene.remove(p.mesh); p.mesh.material.dispose(); }
  for (const r of rings) { scene.remove(r.mesh); ringPool.push(r.mesh); }
  for (const o of orbs) { killGlow(o.glow); scene.remove(o.mesh); scene.remove(o.shadow); }
  if (!keep) for (const p of pots) scene.remove(p.mesh);
  for (const f of fires) killGlow(f.glow);
  for (const m of mines) killGlow(m.glow);
  for (const w of wisps) { killGlow(w.glow); scene.remove(w.mesh); scene.remove(w.shadow); }
  for (const m of meteors) { scene.remove(m.g); killGlow(m.glow); }
  for (const r of rays) { for (const L of r.lasers) releaseLaser(L); if (r.eye) { killMesh(r.eye); r.eye.material.dispose(); } if (r.eyeGlow) killGlow(r.eyeGlow); }
  for (const m of mines) killRune(m.rune);
  resetStones(); resetSaws(); resetHammers(); resetSpits(); resetLobRocks(); resetDragons(); resetStormEye(); for (const m of holyRunes) { scene.remove(m); m.material.dispose(); } holyRunes.length = 0;
  mines = []; rays = []; wisps = []; meteors = [];
  for (const h of holes) killHole(h);
  for (const g of gusts) { for (const gl of g.glows) killGlow(gl); scene.remove(g.shadow); scene.remove(g.ring); g.ring.material.dispose(); } gusts = [];
  for (const b of booms) { b.on = false; b.out.clear(); b.back.clear(); } boomMesh.count = boomGhost.count = 0; resetGloops();
  for (const b of phxs) if (b.on) phxEnd(b, false); phxBody.count = phxWing.count = phxTail.count = 0;
  for (const w of angels) { w.on = false; w.e = null; } angelMesh.count = angelGlow.count = angelMark.count = 0;
  for (const p of pils) p.on = false; pilLive = false; for (const m of PIL_MESHES) m.count = 0;
  for (const b of beams) beamEnd(b);
  if (!keep) for (const h of hazards) { if (h.mesh) scene.remove(h.mesh); if (h.glow) killGlow(h.glow); }
  spikePlates.count = spikeCones.count = 0; for (const m of GFX_BATCHES) m.count = 0; lavaRims.count = 0;
  for (const p of ices) { scene.remove(p.mk); p.mk.material.dispose(); }
  beams = []; hazards = []; clouds = []; frings = []; ices = []; fringMesh.count = 0; fdReset(); for (const o of icls) o.on = false; G.swarm = null; G.dark = null;
  holes = []; G.still = 0; G.finisher = null; stillTint(false);
  if (!keep) { for (const p of props) { if (p.group) scene.remove(p.group); killMesh(p.mesh); killGlow(p.glow); } for (const b of barriers) scene.remove(b); }
  enemies = []; projs = []; eprojs = []; pickups = []; portals = []; rings = []; bolts = []; texts = []; orbs = []; pots = []; fires = []; props = []; barriers = [];
  if (kept) ({ pots, props, barriers, hazards } = kept);
  for (const d of gData) d.life = 0;
  // dead chunks keep their last matrix unless it is zeroed: without this the old floor's slime and pot bits stayed lying around
  // the new floor (little coloured dots everywhere as Pip drops in)
  for (let i = 0; i < MAXD; i++) { debris[i].life = 0; debrisMesh.setMatrixAt(i, dm.makeScale(0, 0, 0)); }
  debrisMesh.instanceMatrix.needsUpdate = true;
  clearSplats();
}

function newGame() {
  if (player) { killMesh(player.mesh); scene.remove(player.shadow); killGlow(player.staffGlow); }
  player = newPlayer();
  const sd = spellDef(meta.start);
  const startId = sd && meta.codex.includes(meta.start) && sd.els.every((e) => meta.elements.includes(e)) ? meta.start : player.hero.start;
  spells = [{ id: startId, lv: 1, t: 0.3 }];
  if (!meta.codex.includes(startId)) { meta.codex.push(startId); saveMeta(); }
  G.kills = 0; G.coins = 0; G.floor = G.daily ? 1 : START_FLOOR; G.bossOrder = G.daily ? [G.daily.boss.type] : null; G.adapt = 1; G.lvPicks = 0; G.dRockT = 3;
  player.maxHp += 2 * mlv('vit'); player.hp = player.maxHp;
  player.dmgMul *= 1 + 0.08 * mlv('pow'); player.cdMul *= Math.pow(0.95, mlv('haste'));
  player.speed *= 1 + 0.05 * mlv('swift'); player.crit += 0.03 * mlv('reach'); player.revive += mlv('life');
  G.coinMul = 1 + 0.2 * mlv('greed');
  G.run = { kills: 0, dmg: 0, bosses: 0, champs: 0, coins: 0, bestCombo: 0, time: 0 };
  G.pendT = null; // the last run's pending-save time: left over, the DAILY button stayed 'busy' ("Clear the room first") after a death until this run's clock passed it (user 11-15)
  // hero passives
  const hid = player.hero.id;
  if (hid === 'amazon') { player.pierceBonus = 1; player.projSpeed = 1.2; }
  if (hid === 'ranger') player.rangeBonus = 2;
  // Legacy: each level of account progress = +1 main stat (and +1 VIT every 3rd level) on every run
  const mainStat = { mage: 'int', archer: 'dex', warrior: 'str', hunter: 'str' }[player.hero.cls];
  const alloc0 = { ...player.alloc };
  for (const k of STATS) player.alloc[k] += 2 * (meta.winStats || 0) + ((meta.statBuy || {})[k] || 0) + ((meta.loginStats || {})[k] || 0); // + Daily Rewards stats
  player.revive += meta.winRevive || 0;
  if (meta.winLegend && spellDef(meta.winLegend) && !spells.some((x) => x.id === meta.winLegend)) spells.push({ id: meta.winLegend, lv: 1, t: 2 });
  player.alloc[mainStat] += meta.legacy || 0; player.alloc.vit += Math.floor((meta.legacy || 0) / 3);
  player.metaAlloc = Object.fromEntries(STATS.map((k) => [k, player.alloc[k] - alloc0[k]])); // bought / legacy / victory stats
  for (const [slot, it] of Object.entries(meta.vault || {})) if (it) player.gear[slot] = { ...it, vault: true };
  recalcStats();
  const mod = G.daily && G.daily.mod.id; // the Daily Dungeon's modifier
  if (mod === 'glass') { player.dmgMul *= 1.5; player.maxHp = Math.max(2, Math.ceil(player.maxHp / 4) * 2); player.hp = player.maxHp; }
  if (mod === 'frenzy') player.cdMul *= 0.77;
  if (mlv('relic') && !ZOO) later(1.3, () => { const r = relicOptions(1)[0]; if (r && player.alive) { r.pick(); G.saveDue = true; } });
  if (START_FLOOR > 1) { spells.push({ id: 'fire.ball', lv: 2, t: 1 }, { id: 'frost.trap', lv: 1, t: 1 }); player.maxHp = player.hp = 8; }
  for (const id of DEBUG_SPELLS) if (!spells.some((x) => x.id === id)) { spells.push({ id, lv: DEBUG_SPELL_LV, t: 0.5 }); discover(id); }
  buildSpellHud();
  renderHearts(); $('coins').textContent = 0;
  G.tut = !meta.tutDone && !AUTO && !ZOO ? { step: 0, moved: 0 } : null;
  if (G.tut) later(1.2, () => G.tut && G.tut.step === 0 && !G.prologue && tutShow(matchMedia('(pointer: coarse)').matches ? 'DRAG ANYWHERE TO MOVE' : 'WASD / ARROWS OR DRAG TO MOVE', true));
  { const kept = SLOTS.map((k) => meta.vault[k]).filter(Boolean); if (kept.length) later(2.6, () => toast('EQUIPPED FROM VAULT', kept.map((it) => `<span style="color:${RARITY[it.rarity].color}">${it.name}</span>`).join(' · '))); }
  startFloor(G.floor);
  // very first run: a few weak slimes crawl into the start room right after you land, so the first seconds are a fight
  const rid = G.runId = (G.runId || 0) + 1;
  if ((meta.stats.runs || 0) === 0 && G.floor === 1) later(1.8, () => {
    if (!player || !player.alive || G.floor !== 1 || G.runId !== rid || G.prologue) return;
    for (let k = 0; k < 5; k++) {
      let x = player.x, z = player.z;
      for (let tries = 0; tries < 20; tries++) { const a = k / 5 * Math.PI * 2 + rr(-0.4, 0.4), d = rr(3.8, 5); x = player.x + Math.cos(a) * d; z = player.z + Math.sin(a) * d; if (cellAt(x, z) === FLOOR) break; }
      const pt = makePortal(x, z, 'slime', 0.7, k * 0.15); pt.weak = true; portals.push(pt);
    }
    sfx('portal');
  });
  if (!ZOO) spawnFairy();
  G.state = 'play';
  $('hud').classList.remove('hidden');
  checkpoint();
}

// ---------- run save: one checkpoint of the current run, so a run closed mid-way can be continued from the title ----------
// Written at every floor start, and after a room clear / card pick / chest / shop buy once nothing is fighting and no
// reward pick is pending, at a Save Crystal, and with the live state (even mid-fight) when the app is closed or hidden.
// Plain data only: the floor is rebuilt from its seed with the rooms you cleared, you stand in the last safe room, and a
// fight you left resumes at its wave. Older saves without the newer fields load as before. Cleared on death, victory and quit. Shards are only paid when a run ends, so a continue can't pay twice.
const RUN_KEY = 'rbd_run_v1', RUN_END = 'rbd_run_end', RUN_VER = 1; // RUN_END: when the save was last cleared (native copy only)
const PLAYER_SKIP = new Set(['mesh', 'shadow', 'staffGlow', 'mirrorRoom', 'hero', 'st', 'der', 'g']); // three.js / derived
let lastRun = null; // the last checkpoint as JSON, written again on pagehide
function runSnapshot() {
  const p = {}; for (const [k, v] of Object.entries(player)) if (!PLAYER_SKIP.has(k)) p[k] = v;
  return { v: RUN_VER, t: Date.now(), floor: G.floor, fseed: G.floorSeed, seed, dungeon: G.runDungeon, bossOrder: G.bossOrder, kills: G.kills, coins: G.coins,
    coinMul: G.coinMul, adapt: G.adapt, lvPicks: G.lvPicks || 0, picks: (player.wowDone ? 1 : 0) | (player.rareDone ? 2 : 0), curse: G.curse || 0, run: G.run, room: rooms.indexOf(G.safeRoom),
    rooms: rooms.map((r) => (r.cleared ? 1 : 0) | (r.visited ? 2 : 0) | (r.seen ? 4 : 0)),
    props: props.map((q, i) => (q.opened || q.sold || q.used ? i : -1)).filter((i) => i >= 0),
    gold: props.filter((q) => q.gold && !q.opened).map((q) => rooms.indexOf(q.room)), hero: player.hero.id, player: p, spells, fights: fightSnapshot(), calm: 1 /* floors have calm rooms */ };
}
// rooms fought part-way, as [room, waves left, swarm seconds left]: the fight on screen counts its current wave as left (it
// is fought again), a room left earlier keeps what it had. So a continue can't restart a room from wave 1 and farm it.
function fightSnapshot() {
  const live = portals.length > 0 || enemies.some((e) => !e.dead), out = [];
  rooms.forEach((r, i) => {
    if (r.cleared || (!r.totalWaves && r.swarmLeft == null)) return;
    const w = (r.waves || 0) + (r.active && live ? 1 : 0), sw = r.active && G.swarm && G.swarm.room === r ? G.swarm.t : r.swarmLeft ?? null;
    if ((r.active || w < r.totalWaves || sw != null) && (r.visited || r.active)) out.push([i, w, sw]);
  });
  return out;
}
function checkpoint() { if (BENCH || ZOO || G.prologue || G.daily || !player || !player.alive) return; /* a daily run is never saved: the normal run's save stays as it was */ G.saveDue = false; lastRun = JSON.stringify(runSnapshot()); storeRun(); }
function storeRun() { if (!lastRun || ZOO || saveLocked()) return; try { localStorage.setItem(RUN_KEY, lastRun); } catch (e) { /* storage full or blocked: no continue */ } mirror(RUN_KEY, lastRun); }
function clearRun() { if (ZOO || saveLocked()) return; lastRun = null; G.saveDue = false; try { localStorage.removeItem(RUN_KEY); } catch (e) { /* ignore */ } mirror(RUN_KEY, null); mirror(RUN_END, String(Date.now())); }
function loadRun() { // a broken or older save is dropped quietly
  try {
    const s = JSON.parse(localStorage.getItem(RUN_KEY) || 'null');
    if (!s) return null;
    if (Array.isArray(s.spells)) s.spells = migrateSpells(s.spells); // old element.shape ids -> signature spells (levels kept)
    if (s.v === RUN_VER && s.floor >= 1 && HEROES[s.hero] && s.player && Array.isArray(s.spells) && s.spells.every((x) => spellDef(x.id)) && Array.isArray(s.rooms)) return s;
  } catch (e) { /* unreadable */ }
  clearRun(); return null;
}
// safe = nothing is fighting, no reward pick is open or about to open
const runSafe = () => G.state === 'play' && player && player.alive && !rooms.some((q) => q.active) && !G.lvPicks && G.run.time - (G.pendT ?? -9) > 1.2;
function continueRun(s) {
  if (whenArt(() => continueRun(s))) return;
  initAudio(); for (const sId of screens) $(sId).classList.add('hidden'); G.daily = null; G.dailyWon = null; G.dailyRet = null;
  if (player) { killMesh(player.mesh); scene.remove(player.shadow); killGlow(player.staffGlow); }
  player = newPlayer();
  Object.assign(player, s.player, { hero: { ...HEROES[s.hero], id: s.hero }, alive: true, iframe: 0, vx: 0, vz: 0 });
  spells = s.spells;
  Object.assign(G, { floor: s.floor, kills: s.kills, coins: s.coins, coinMul: s.coinMul, adapt: s.adapt, lvPicks: s.lvPicks, lvPickT: 0.7, run: s.run,
    bossOrder: s.bossOrder, runDungeon: s.dungeon, tut: null, combo: 0, pendT: null });
  { const pk = s.picks ?? (player.lv > 1 ? 3 : 0); player.wowDone = !!(pk & 1); player.rareDone = !!(pk & 2); } // POWER / RARE PICK already had (old saves: assume yes past Lv 1)
  recalcStats(); buildSpellHud(); $('coins').textContent = G.coins;
  if (flushRunPts()) recalcStats(); // an old save's unspent run points: into the main stat (no points to spend any more)
  G.noCalm = !s.calm; startFloor(G.floor, s.fseed); G.noCalm = false; // a save from before calm rooms rebuilds its floor without them
  if (s.rooms.length === rooms.length) rooms.forEach((r, i) => {
    r.cleared = !!(s.rooms[i] & 1); r.visited = !!(s.rooms[i] & 2); r.seen = !!(s.rooms[i] & 4);
    if (r.cleared && (r.type === 'exit' || r.type === 'boss')) spawnStairs(r);
  });
  for (const i of s.props || []) {
    const q = props[i]; if (!q) continue;
    if (q.kind === 'crystal') { q.used = true; continue; } // the heal is spent; the crystal still saves
    if (q.kind === 'chest') q.opened = true; else if (q.kind === 'shop') q.sold = true; else if (q.kind === 'shrine') { q.used = true; q.mesh.material.uniforms.uTint.value.set(0x555566); } else if (q.kind === 'fountain') q.used = true;
    if (q.kind !== 'shrine') { killMesh(q.mesh); q.mesh = null; }
    killGlow(q.glow); q.glow = null;
  }
  for (const i of s.gold || []) if (rooms[i]) addGoldChest(rooms[i]);
  for (const [i, w, sw] of s.fights || []) { // fights that were left: they resume at their wave when you walk back in
    const f = rooms[i]; if (!f || f.cleared) continue;
    if (f.totalWaves) f.waves = clamp(w, 0, f.totalWaves);
    if (sw != null) f.swarmLeft = Math.max(5, sw);
  }
  const r = rooms[s.room], cry = props.find((q) => q.kind === 'crystal' && q.room === r);
  if (r && r.type !== 'start') { // stand in the last safe room: beside its Save Crystal, else off its centre (chest, stairs, shrine)
    const at = cry ? [[0, 1.2], [1.2, 0], [-1.2, 0], [0, -1.2]].map(([dx, dz]) => [cry.x + dx, cry.z + dz]) : [];
    const spot = at.concat([[0, 3], [0, -3], [2, 3], [-2, 3], [3, 0], [-3, 0]].map(([dx, dz]) => [r.cx + dx, r.cz + dz])).find(([x, z]) => cellAt(x, z) === FLOOR && !hazards.some((h) => h.i === Math.floor(x) && h.j === Math.floor(z))) || [r.cx, r.cz];
    player.x = spot[0]; player.z = spot[1]; camTarget.set(player.x, 0, player.z); G.safeRoom = r;
    if (cry) cry.armed = false; // standing on it: it saves again once you step away and back
  }
  seed = s.seed; G.curse = s.curse;
  spawnFairy();
  G.state = 'play';
  $('hud').classList.remove('hidden');
  checkpoint();
}
// closing / backgrounding the app: save the live run, even mid-fight (level, cards, coins, kills are kept; a continue puts
// you in the last safe room and the fight you left resumes at its wave). An open level-up pick comes back as a pending pick.
// The death screen and other card picks keep the last checkpoint.
function saveOnHide() {
  if (!lastRun) return;
  if (G.state === 'play' || G.state === 'paused') checkpoint();
  else if (G.state === 'cards' && G.cardsTitle === 'LEVEL UP') { G.lvPicks = (G.lvPicks || 0) + 1; checkpoint(); G.lvPicks--; }
  storeRun();
}
function pauseGame(view) { if (G.state !== 'play' || !player || !player.alive) return; G.state = 'paused'; { const fv = $('focusVeil'); if (fv) fv.remove(); G.focusHold = false; } /* the menu replaces a CLICK TO CONTINUE veil */ $('btnSaveExit').classList.toggle('hidden', !!G.daily); /* a daily can't be saved */
  G.statUndo = []; G.statPop = null; G.lastNums = null; // a new visit: only points spent from here can be undone
  G.buildView = view || 'menu'; /* the prologue gets the painted menu too (SAVE & EXIT / GIVE UP hide under .proHud) */ renderBuild(); $('pause').scrollTop = 0; $('pause').classList.remove('hidden'); }
// leaving the app: save first, then pause (the prologue too), so coming back shows the pause menu.
function onHide() { saveOnHide(); pauseGame(); }
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') onHide(); });
addEventListener('pagehide', onHide);
document.addEventListener('pause', onHide); // Cordova / Capacitor app event (Android), same as hidden
{ const A = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App; if (A && A.addListener) try { A.addListener('pause', onHide); } catch (e) { /* no App plugin */ } }

function startFloor(n, fseed) {
  resetLevelObjects();
  if (!G.bossOrder) { // per run: bosses that still guard a locked element come first, so replays can unlock them early
    const unlocks = (t) => Object.values(BOSS_SPELLS).find((b) => b.boss === t)?.unlocks;
    const types = BOSSES.map((b) => b.type), locked = types.filter((t) => unlocks(t) && !meta.elements.includes(unlocks(t)));
    G.bossOrder = shuffle(locked.slice()).concat(shuffle(types.filter((t) => !locked.includes(t))));
  }
  // everything below is built from this seed: a continued run passes the saved one and gets the same floor back
  if (fseed != null) seed = fseed;
  else if (G.daily) seed = (G.daily.seed + n * 7919) | 0; // every daily floor is the same for everyone, however floor 1 went
  G.floorSeed = seed; G.safeRoom = null;
  G.biomeKey = pickBiome(n); G.biome = BIOMES[G.biomeKey]; G.pal = biomePalette(G.biome); G.curse = 0;
  applyBiomeLight(G.biome);
  G.boss = BOSSES.find((b) => b.type === (FORCE_BOSS || G.bossOrder[Math.max(0, Math.floor(n / 3) - 1) % G.bossOrder.length])) || BOSSES[0];
  const start = genFloor(n);
  buildWorld(G.pal); grimeFloor();
  for (const r of rooms) setupRoom(r);
  placeCrystal();
  G.champion = null;
  const champRooms = rooms.filter((r) => r.type === 'combat' && r.depth >= 2);
  if (n >= 2 && champRooms.length && !ZOO && rand() < 0.75) {
    const name = pick(['Grubnak', 'Old Mother Gloop', 'Skreev', 'Vexis', 'Krull', 'Morrow', 'Hollow Jack', 'Sister Ash']) + ' ' + pick(['the Hungry', 'the Hollow', 'of the Deep', 'the Unburied', 'the Weeping', 'the Rotten', 'Bonegnawer']);
    const pool = ['big', 'skeleton', 'imp', 'eye'].concat(n >= 3 ? ['ghost', 'shroom', 'archer'] : [], n >= 4 ? ['golem', 'golem', 'cursed', 'reaper'] : [], n >= 5 ? ['shieldk', 'runegolem', 'crystalgolem'] : [], n >= 7 ? ['boneknight', 'magmagolem'] : []);
    G.champion = { name, type: pick(pool), room: pick(champRooms) };
    G.champion.room.champ = G.champion;
  }
  player.x = start.cx; player.z = start.cz + 2; player.vx = player.vz = 0; player.drop = 0.22; player.dropDelay = 1.5; // let the floor fade in first
  if (SLOWLOAD && !G.prologue) G.slowUntil = performance.now() + SLOWLOAD * 1000;
  camTarget.set(player.x, 0, player.z);
  G.curRoom = null;
  $('floorLbl').textContent = G.daily ? `DAILY · ${n} / ${DAILY_FLOORS}` : `FLOOR ${n} / ${WIN_FLOOR}`;
  banner(`FLOOR ${n}`, n % 3 === 0 ? (G.daily ? `${G.boss.name} AWAITS` : 'A GREAT EVIL STIRS') : G.pal.name);
  if (G.champion) { const cn = G.champion.name; later(2.4, () => toast(cn.toUpperCase(), 'stalks this floor...')); } // the floor may already be gone
  $('fade').style.opacity = 0;
}

function setupRoom(r) {
  const fl = G.floor;
  if (r.type === 'combat' || r.type === 'exit' || r.type === 'boss' || r.type === 'challenge') {
    r.waves = r.totalWaves = r.type === 'boss' ? 3 : Math.min(2 + Math.floor((fl - 1) / 2), 4) + (r.type === 'exit' || r.type === 'challenge' ? 1 : 0);
    const nPots = ri(1, 4);
    for (let k = 0; k < nPots; k++) {
      const i = pick([1, 2, r.w - 2, r.w - 1]), j = ri(1, r.h - 1);
      if (map[(r.z0 + j) * MW + r.x0 + i] !== FLOOR) continue;
      addPot(r.x0 + i + 0.5, r.z0 + j + 0.5);
    }
    placeHazards(r);
    for (let k = 0; k < ri(0, 3); k++) {
      const i = ri(2, r.w - 1), j = ri(2, r.h - 1);
      if (Math.abs(i - 1 - Math.floor(r.w / 2)) <= 1 || Math.abs(j - 1 - Math.floor(r.h / 2)) <= 1) continue;
      if (map[(r.z0 + j) * MW + r.x0 + i] !== FLOOR) continue;
      addBarrel(r.x0 + i + 0.5, r.z0 + j + 0.5);
    }
  }
  if (r.type === 'shrine') {
    const m = makeSprite('shrine'); m.position.set(r.cx, 0.04, r.cz);
    props.push({ kind: 'shrine', room: r, x: r.cx, z: r.cz, mesh: m, glow: makeGlowAt(r.cx, 1.1, r.cz, 0xff2a4a, 2, 0.45) });
  }
  if (r.type === 'treasure') {
    const chest = makeSprite('items', 0.9, 4);
    chest.position.set(r.cx, 0.08, r.cz);
    props.push({ mimic: G.floor >= 2 && rand() < 0.3, kind: 'chest', room: r, x: r.cx, z: r.cz, mesh: chest, glow: makeGlowAt(r.cx, 0.5, r.cz, 0xffc040, 2.2, 0.35) });
  }
  if (r.type === 'shop') {
    const offers = [
      { kind: 'heal', icon: ['items', 2], price: 10 + fl * 3, label: 'Heal 1 heart' },
      { kind: 'upgrade', icon: ['items', 3], price: 24 + fl * 6, label: 'Spell upgrade' },
      { kind: 'relic', icon: ['items', 5], price: 34 + fl * 8, label: 'Random relic' },
      { kind: 'gear', icon: ['gear', 3], price: 30 + fl * 7, label: 'Rare+ gear' },
    ];
    offers.forEach((o, k) => {
      const x = r.cx + (k - 1.5) * 2.2, z = r.cz - 1;
      const group = new THREE.Group();
      const base = new THREE.Mesh(boxGeo, new THREE.MeshLambertMaterial({ map: wallTex, color: G.pal.wall }));
      base.scale.set(0.9, 0.45, 0.9); base.castShadow = true; group.add(base); group.position.set(x, 0, z); scene.add(group);
      const m = makeSprite(o.icon[0], 0.6, o.icon[1]); m.position.set(x, 0.75, z);
      props.push({ kind: 'shop', offer: o, x, z, mesh: m, group, glow: makeGlowAt(x, 0.9, z, 0x7fffd4, 1.6, 0.4), sold: false });
    });
  }
  if (r.type === 'calm') setupCalmRoom(r);
}
// a calm room (genFloor): never locks. Warm gold torches and haze say "safe"; what's in the middle depends on r.calm.
const CALM_LIGHT = 0xffc870;
const CALM_INFO = { cache: ['A QUIET CACHE', 'NO MONSTERS HERE'], blessing: ['SHRINE OF LIGHT', 'A MOMENT OF GRACE'], fountain: ['HEALING SPRING', 'DRINK AND REST'], quiet: ['A QUIET ROOM', 'CATCH YOUR BREATH'] };
function setupCalmRoom(r) {
  for (const f of r.flames || []) f.material.color.set(CALM_LIGHT);
  props.push({ kind: 'calmglow', room: r, x: r.cx, z: r.cz, glow: makeGlowAt(r.cx, 0.6, r.cz, CALM_LIGHT, 6, 0.16) });
  const nPots = r.calm === 'cache' ? ri(4, 6) : r.calm === 'quiet' ? ri(3, 5) : ri(1, 3);
  for (let k = 0; k < nPots; k++) {
    const i = pick([1, 2, r.w - 2, r.w - 1]), j = ri(1, r.h - 1);
    if (map[(r.z0 + j) * MW + r.x0 + i] !== FLOOR || Math.abs(j - 1 - Math.floor(r.h / 2)) <= 1) continue;
    addPot(r.x0 + i + 0.5, r.z0 + j + 0.5);
  }
  if (r.calm === 'quiet') for (let k = 0; k < ri(1, 2); k++) {
    const i = ri(2, r.w - 1), j = ri(2, r.h - 1);
    if (Math.abs(i - 1 - Math.floor(r.w / 2)) <= 1 || Math.abs(j - 1 - Math.floor(r.h / 2)) <= 1 || map[(r.z0 + j) * MW + r.x0 + i] !== FLOOR) continue;
    addBarrel(r.x0 + i + 0.5, r.z0 + j + 0.5);
  }
  if (r.calm === 'cache') { // a small chest: coins and maybe a piece of gear, never a mimic, no card pick
    const chest = makeSprite('items', 0.7, 4); chest.position.set(r.cx, 0.08, r.cz);
    props.push({ kind: 'chest', small: true, room: r, x: r.cx, z: r.cz, mesh: chest, glow: makeGlowAt(r.cx, 0.5, r.cz, CALM_LIGHT, 1.8, 0.35) });
  }
  if (r.calm === 'blessing') {
    const m = makeSprite('shrine'); m.position.set(r.cx, 0.04, r.cz); m.material.uniforms.uTint.value.set(0xffe2a0);
    props.push({ kind: 'shrine', bless: true, room: r, x: r.cx, z: r.cz, mesh: m, glow: makeGlowAt(r.cx, 1.1, r.cz, CALM_LIGHT, 2, 0.45) });
  }
  if (r.calm === 'fountain') { // a basin of glowing water with a heart over it: step in for +2 hearts, once
    const group = new THREE.Group(), basin = new THREE.Mesh(crystalBaseGeo, crystalBaseMat);
    basin.scale.set(2.4, 1, 2.4); basin.castShadow = true;
    const water = new THREE.Mesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: softRingTex, color: 0x8fe0ff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }));
    water.position.y = 0.32; water.scale.setScalar(0.95); group.add(basin, water); group.position.set(r.cx, 0, r.cz); scene.add(group);
    const heart = makeSprite('items', 0.55, 2); heart.position.set(r.cx, 1.0, r.cz);
    props.push({ kind: 'fountain', room: r, x: r.cx, z: r.cz, mesh: heart, group, water, used: false, glow: makeGlowAt(r.cx, 0.8, r.cz, 0xff8aa0, 2.2, 0.4) });
  }
}
// two of these at a Shrine of Light: small, for the rest of the run (or right now)
function blessOptions(p) {
  const done = () => { p.mesh.material.uniforms.uTint.value.set(0x555566); killGlow(p.glow); p.glow = null; burst(p.x, 1, p.z, CALM_LIGHT, 30, 5, 0.5, 0.8); sfx('heal'); };
  const coins = 20 + G.floor * 4, up = spells.filter((s) => canLevel(s));
  const pool = [
    { tag: 'BLESSING', name: 'Might', info: '+8% spell damage for this run.', color: '#ffb340', icon: ['items', 4], pick: () => { player.dmgMul *= 1.08; done(); toast('MIGHT', '+8% spell damage'); } },
    { tag: 'BLESSING', name: 'Focus', info: 'All cooldowns -5% for this run.', color: '#7fd8ff', icon: ['items', 3], pick: () => { player.cdMul *= 0.95; done(); toast('FOCUS', 'cooldowns -5%'); } },
    { tag: 'BLESSING', name: 'Swiftness', info: '+8% move speed for this run.', color: '#9aff7a', icon: ['items', 5], pick: () => { player.speed *= 1.08; done(); toast('SWIFTNESS', '+8% move speed'); } },
    { tag: 'BLESSING', name: 'Fortune', info: `Gain ${coins} coins.`, color: '#ffd34f', icon: ['items', 0], pick: () => { G.coins += coins; G.run.coins += coins; $('coins').textContent = G.coins; done(); for (let k = 0; k < 6; k++) dropPickup(p.x, p.z + 0.6, 'coin'); } },
    { tag: 'BLESSING', name: 'Renewal', info: 'Heal to full hearts.', color: '#ff6a8a', icon: ['items', 2], pick: () => { player.hp = player.maxHp; renderHearts(); done(); toast('RENEWAL', 'fully healed'); } },
  ];
  if (up.length) pool.push({ tag: 'BLESSING', name: 'Insight', info: 'A random spell gains +1 level.', color: '#c070ff', icon: ['items', 3], pick: () => { const s = pick(up); s.lv++; buildSpellHud(); done(); toast(spellDef(s.id).name.toUpperCase() + ' LV' + s.lv, levelText(spellDef(s.id), s.lv)); } });
  return shuffle(pool.filter((o) => o.name !== 'Renewal' || player.hp < player.maxHp)).slice(0, 2);
}
// Save Crystal: one per floor, in a room halfway along the way to the exit (no rand(): a continued floor must come back
// the same). Touch it once its room is clear: PROGRESS SAVED, and the first touch heals a heart.
const CRYSTAL = 0x7fe8ff;
const crystalGeo = new THREE.OctahedronGeometry(0.34).scale(1, 2.1, 1), crystalMat = new THREE.MeshLambertMaterial({ color: 0x9feeff, emissive: 0x2a90b8, flatShading: true });
const crystalCoreMat = new THREE.MeshBasicMaterial({ color: CRYSTAL, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false });
const crystalBaseGeo = new THREE.CylinderGeometry(0.34, 0.46, 0.3, 6).translate(0, 0.15, 0), crystalBaseMat = new THREE.MeshLambertMaterial({ color: 0x3a3a50 });
let crystalRingMat = null; // made on first use: softRingTex is defined further down
function placeCrystal() {
  if (G.daily) return; // a daily is never saved, so no Save Crystal
  const exit = rooms.find((r) => r.type === 'exit' || r.type === 'boss'), path = [];
  for (let r = exit && exit.links[0]; r && r.type !== 'start'; r = r.links[0]) path.unshift(r);
  // late in the floor, about 3/4 of the way to the stairs and never the first room in (it felt like a free save at the door)
  const mid = Math.max(Math.min(1, path.length - 1), (path.length - 1) * 0.75), near = (q) => Math.abs(path.indexOf(q) - mid) + (path.indexOf(q) === 0 && path.length > 1 ? 99 : 0);
  const nextToStart = (q) => q.type === 'start' || (q.links || []).some((l) => l.type === 'start'); // never the drop room or the first room after it (user, twice)
  const r = path.filter((q) => q.type === 'combat' && !q.variant && !nextToStart(q)).sort((a, b) => near(a) - near(b))[0];
  if (!r || path.length < 2) return; // no crystal when the only room before the stairs is the first one after the drop
  // a spot with room for the pedestal and a walk around it: every tile within CLR is open floor (no pillar, wall, spike,
  // vent or lava), no pot / barrel / prop close by, and off the door lanes. Fixed candidate order (no rand()), so a
  // continued floor puts it in the same place.
  const CLR = 0.85, lane = (x, z) => Math.abs(x - r.cx) < 1.6 || Math.abs(z - r.cz) < 1.6;
  const tileOk = (x, z) => cellAt(x, z) === FLOOR && !hazards.some((h) => h.i === Math.floor(x) && h.j === Math.floor(z));
  const clear = (x, z) => [[0, 0], [CLR, 0], [-CLR, 0], [0, CLR], [0, -CLR], [CLR * 0.7, CLR * 0.7], [-CLR * 0.7, CLR * 0.7], [CLR * 0.7, -CLR * 0.7], [-CLR * 0.7, -CLR * 0.7]].every(([dx, dz]) => tileOk(x + dx, z + dz))
    && !pots.some((p) => Math.hypot(p.x - x, p.z - z) < 1.4) && !props.some((p) => Math.hypot(p.x - x, p.z - z) < 2);
  const cand = [[0, 0]]; for (const d of [2.5, 3.5, 1.5, 4.2]) for (const [ux, uz] of [[1, -1], [-1, -1], [1, 1], [-1, 1], [1, 0], [-1, 0], [0, 1], [0, -1]]) cand.push([ux * d, uz * d]);
  const pos = cand.map(([dx, dz]) => [r.cx + dx, r.cz + dz]);
  const [x, z] = (clear(r.cx, r.cz) && [r.cx, r.cz]) || pos.find(([x, z]) => !lane(x, z) && clear(x, z)) || pos.find(([x, z]) => clear(x, z)) || [r.cx + 2.5, r.cz - 2.5];
  const group = new THREE.Group(), gem = new THREE.Mesh(crystalGeo, crystalMat), core = new THREE.Mesh(crystalGeo, crystalCoreMat);
  crystalRingMat = crystalRingMat || new THREE.MeshBasicMaterial({ map: softRingTex, color: CRYSTAL, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL });
  const base = new THREE.Mesh(crystalBaseGeo, crystalBaseMat), ring = new THREE.Mesh(flatRingGeo, crystalRingMat);
  core.scale.setScalar(1.3); gem.add(core); gem.rotation.z = 0.12; gem.position.y = 1.05; base.castShadow = true; ring.position.y = 0.045; ring.scale.setScalar(0.85);
  group.add(base, ring, gem); group.position.set(x, 0, z); scene.add(group);
  props.push({ kind: 'crystal', room: r, x, z, group, gem, ring, used: false, glow: makeGlowAt(x, 1.05, z, CRYSTAL, 3, 0.5) });
}
function touchCrystal(p) {
  p.armed = false; G.safeRoom = p.room;
  const heal = !p.used && player.hp < player.maxHp; // the heart is kept for a later touch if you are already full
  if (heal) { p.used = true; player.hp = Math.min(player.maxHp, player.hp + 2); renderHearts(); }
  checkpoint();
  toast(`<span style="color:#bff4ff">SAVED</span>${heal ? ' · +1 HEART' : ''}`, ''); // one small line, not a big banner
  sfx('heal'); flash(0.15); addRing(p.x, p.z, 0.2, 2.6, 0.5, CRYSTAL); burst(p.x, 1, p.z, 0xbff4ff, 26, 4, 0.5, 0.7);
}
function makeGlowAt(x, y, z, c, s, o) { const g = makeGlow(c, s, o); g.position.set(x, y, z); return g; }
const spikeBaseMat = new THREE.MeshLambertMaterial({ color: 0x3a3a44 });
const spikeMat = new THREE.MeshLambertMaterial({ color: 0xc8ccd8 });
const spikeGeo = new THREE.ConeGeometry(0.08, 0.42, 4).translate(0, 0.21, 0);
const lavaTex = canvasTex(16, 16, (g) => {
  g.fillStyle = '#1a0500'; g.fillRect(0, 0, 16, 16);
  g.fillStyle = '#ff6a10';
  let x = 1, y = 8; for (let k = 0; k < 18; k++) { g.fillRect(x, y, 2, 1); x += 1; y += Math.round((hash(k, 3) - 0.5) * 3); y = Math.max(1, Math.min(14, y)); }
  x = 8; y = 1; for (let k = 0; k < 16; k++) { g.fillRect(x, y, 1, 2); y += 1; x += Math.round((hash(k, 7) - 0.5) * 3); x = Math.max(1, Math.min(14, x)); }
  g.fillStyle = '#ffd040'; g.fillRect(7, 7, 2, 2);
});
// hazard lava tile: a molten pool, not a floor decal. One shared shader (world-space, so a run of tiles flows as one pool):
// churning orange-yellow melt, dark cooled crust plates with glowing cracks, heat bubbles that swell and pop. A raised
// dark rock rim (instanced, only on edges that don't touch another lava tile) makes it read as its own sunken surface.
// Pip's fire is soft flames on the floor; lava is a liquid with crust inside rock.
const lavaMat = new THREE.ShaderMaterial({
  uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uTime: { value: 0 } }]),
  vertexShader: `varying vec2 vW;
    #include <fog_pars_vertex>
    void main(){ vec4 wp = modelMatrix * vec4(position, 1.0); vW = wp.xz - floor(modelMatrix[3].xz / 64.0) * 64.0; /* wrap per tile, not per vertex: mod() per vertex smeared tiles crossing x/z = 64 into stripes */ vec4 mvPosition = viewMatrix * wp; gl_Position = projectionMatrix * mvPosition;
      #include <fog_vertex>
    }`,
  fragmentShader: `uniform float uTime; varying vec2 vW;
    #include <fog_pars_fragment>
    float h2(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
    float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
      return mix(mix(h2(i), h2(i + vec2(1.0, 0.0)), f.x), mix(h2(i + vec2(0.0, 1.0)), h2(i + vec2(1.0, 1.0)), f.x), f.y); }
    void main(){
      float t = uTime; vec2 p = vW * 2.2;
      float fl = vn(p + vec2(t * 0.35, t * 0.22)) * 0.6 + vn(p * 2.1 - vec2(t * 0.3, -t * 0.4)) * 0.4;
      vec3 col = mix(vec3(0.5, 0.03, 0.0), vec3(1.0, 0.3, 0.02), smoothstep(0.25, 0.7, fl));
      col = mix(col, vec3(1.0, 0.82, 0.3), smoothstep(0.66, 0.88, fl));
      float c = vn(vW * 1.7 + vec2(t * 0.05, t * 0.03)) * 0.65 + vn(vW * 4.3 + t * 0.04) * 0.35;
      float plate = smoothstep(0.54, 0.59, c);
      col += vec3(1.0, 0.55, 0.08) * smoothstep(0.42, 0.55, c) * (1.0 - plate) * 0.7; // cracks glow hottest right at the crust edge
      vec3 crust = vec3(0.05, 0.018, 0.012) + vec3(0.3, 0.05, 0.0) * (1.0 - smoothstep(0.59, 0.7, c));
      col = mix(col, crust, plate);
      vec2 q = vW * 3.0, ci = floor(q); float rb = h2(ci + 7.0), ph = fract(t * 0.45 + rb * 7.0);
      vec2 o = fract(q) - 0.5 - (vec2(h2(ci + 3.0), h2(ci + 5.0)) - 0.5) * 0.4; float d = length(o), rad = 0.06 + 0.22 * ph;
      float b = step(0.55, rb) * (1.0 - plate) * (1.0 - smoothstep(rad - 0.04, rad, d)) * (1.0 - smoothstep(0.85, 1.0, ph));
      col = mix(col, mix(vec3(1.0, 0.95, 0.6), vec3(1.0, 0.4, 0.04), d / rad), b * 0.9); // heat bubble swelling, then gone
      col *= 0.9 + 0.1 * sin(t * 2.5 + vW.x * 1.3 + vW.y);
      gl_FragColor = vec4(col, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      #include <fog_fragment>
    }`,
  fog: true, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
});
const lavaGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
const lavaRims = new THREE.InstancedMesh(boxGeo, new THREE.MeshLambertMaterial({ color: 0x2a1a16, emissive: 0x3a0c02 }), 4 * 240);
lavaRims.count = 0; lavaRims.frustumCulled = false; lavaRims.receiveShadow = true; scene.add(lavaRims);
// one rim height for every piece: the pieces overlap at corners and along runs, and same-height faces there don't flicker
const LAVA_EDGE = [[0, -0.5, 1.12, 0.16], [0, 0.5, 1.12, 0.16], [-0.5, 0, 0.16, 1.12], [0.5, 0, 0.16, 1.12]]; // N S W E: dx, dz, sx, sz
const HAZ_GAS = 0x3a7a2a; // hazard gas pools: murky olive under the dark spiky rim
function hazardFree(r, i, j) {
  // keep the door lanes and the area right inside each door clear
  if (Math.abs(i - Math.floor(r.w / 2)) <= 1 || Math.abs(j - Math.floor(r.h / 2)) <= 1) return false;
  return map[(r.z0 + 1 + j) * MW + r.x0 + 1 + i] === FLOOR && !hazards.some((h) => h.i === r.x0 + 1 + i && h.j === r.z0 + 1 + j);
}
function placeHazards(r) {
  const spikes = r.variant === 'traps' ? 3 : G.biome.hazard === 'spikes' && G.floor >= 2 ? ri(1, 2) : 0;
  for (let row = 0; row < spikes; row++) {
    const horizontal = rand() < 0.5, grp = row % 2;
    const j0 = ri(1, r.h - 2), i0 = ri(1, r.w - 2), len = ri(3, 6);
    for (let k = 0; k < len; k++) {
      const i = horizontal ? i0 - 2 + k : i0, j = horizontal ? j0 : j0 - 2 + k;
      if (i < 0 || j < 0 || i >= r.w || j >= r.h || !hazardFree(r, i, j)) continue;
      addSpike(r.x0 + 1 + i, r.z0 + 1 + j, grp * 1.2);
    }
  }
  if (r.variant === 'traps') for (let k = 0; k < 10; k++) { const i = ri(0, r.w - 1), j = ri(0, r.h - 1); if (hazardFree(r, i, j)) addSpike(r.x0 + 1 + i, r.z0 + 1 + j, (i + j) % 2 * 1.2); }
  if (G.biome.hazard === 'vents' && G.floor >= 2) for (let k = 0; k < ri(2, 3); k++) { const i = ri(1, r.w - 2), j = ri(1, r.h - 2); if (hazardFree(r, i, j)) addVent(r.x0 + 1 + i, r.z0 + 1 + j); }
  if (G.biome.hazard === 'lava' && G.floor >= 2) for (let c = 0; c < ri(2, 3); c++) {
    let i = ri(1, r.w - 2), j = ri(1, r.h - 2);
    for (let k = 0; k < ri(2, 4); k++) { if (i >= 0 && j >= 0 && i < r.w && j < r.h && hazardFree(r, i, j)) addLava(r.x0 + 1 + i, r.z0 + 1 + j); if (rand() < 0.5) i += pick([-1, 1]); else j += pick([-1, 1]); }
  }
}
// every spike trap of the floor: two instanced draws (plates, cones) instead of 6 meshes per trap
const MAXSPK = 400, SPK_AT = [[-0.22, -0.22], [0.22, -0.22], [-0.22, 0.22], [0.22, 0.22], [0, 0]];
const spikePlates = new THREE.InstancedMesh(boxGeo, spikeBaseMat, MAXSPK), spikeCones = new THREE.InstancedMesh(spikeGeo, spikeMat, MAXSPK * 5);
spikePlates.receiveShadow = true; spikeCones.castShadow = true; spikeCones.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
for (const m of [spikePlates, spikeCones]) { m.count = 0; m.frustumCulled = false; scene.add(m); }
function setSpikeY(h, y) {
  for (let k = 0; k < 5; k++) spikeCones.setMatrixAt(h.spk * 5 + k, bMat.makeTranslation(h.x + SPK_AT[k][0], y, h.z + SPK_AT[k][1]));
  spikeCones.instanceMatrix.needsUpdate = true;
}
function addSpike(i, j, off) {
  const n = spikePlates.count; if (n >= MAXSPK) return;
  spikePlates.setMatrixAt(n, bMat.makeScale(0.92, 0.03, 0.92).setPosition(i + 0.5, 0, j + 0.5)); spikePlates.count = n + 1; spikePlates.instanceMatrix.needsUpdate = true;
  spikeCones.count = (n + 1) * 5;
  const h = { kind: 'spike', i, j, x: i + 0.5, z: j + 0.5, spk: n, y: -0.45, off, state: 'down' }; setSpikeY(h, h.y);
  hazards.push(h);
}
function addVent(i, j) {
  const m = new THREE.Mesh(boxGeo, spikeBaseMat); m.scale.set(0.8, 0.04, 0.8); m.position.set(i + 0.5, 0, j + 0.5);
  for (let k = -1; k <= 1; k++) { const bar = new THREE.Mesh(boxGeo, ironMat); bar.scale.set(0.12, 1.5, 0.9); bar.position.set(k * 0.3, 0, 0); m.add(bar); }
  scene.add(m);
  hazards.push({ kind: 'vent', i, j, x: i + 0.5, z: j + 0.5, mesh: m, off: rand() * 4.5, state: 'idle' });
}
function addLava(i, j) {
  if (hazards.some((o) => o.kind === 'lava' && o.i === i && o.j === j)) return;
  const fl = floorInst.get(j * MW + i); // the floor tile under the melt drops out of the way: nothing opaque within 15 cm of the lava surface
  if (fl) { fl[0].setMatrixAt(fl[1], dm.makeTranslation(i + 0.5, -0.12, j + 0.5)); fl[0].instanceMatrix.needsUpdate = true; }
  const m = new THREE.Mesh(lavaGeo, lavaMat); m.position.set(i + 0.5, 0.03, j + 0.5); scene.add(m); // 0.012 flickered against the floor on phone depth buffers
  const h = { kind: 'lava', i, j, x: i + 0.5, z: j + 0.5, mesh: m, glow: makeGlowAt(i + 0.5, 0.15, j + 0.5, 0xff4a10, 1.9, 0.4), state: 'hot', rim: [-1, -1, -1, -1] };
  const nb = [[0, -1], [0, 1], [-1, 0], [1, 0]];
  for (let k = 0; k < 4; k++) { // rock rim on open edges; an edge shared with another lava tile is removed from both
    const o = hazards.find((q) => q.kind === 'lava' && q.i === i + nb[k][0] && q.j === j + nb[k][1]);
    if (o) { const ko = k ^ 1; if (o.rim[ko] >= 0) { lavaRims.setMatrixAt(o.rim[ko], bMat.makeScale(0, 0, 0)); lavaRims.instanceMatrix.needsUpdate = true; o.rim[ko] = -1; } continue; }
    const n = lavaRims.count; if (n >= 4 * 240) continue;
    const E = LAVA_EDGE[k]; lavaRims.setMatrixAt(n, bMat.makeScale(E[2], 0.09, E[3]).setPosition(i + 0.5 + E[0], 0, j + 0.5 + E[1]));
    lavaRims.count = n + 1; lavaRims.instanceMatrix.needsUpdate = true; h.rim[k] = n;
  }
  hazards.push(h);
}
function updateHazards(dt) {
  const pi = Math.floor(player.x), pj = Math.floor(player.z), onFloor = player.alive && !(player.drop > 0);
  for (const h of hazards) {
    if (h.kind === 'spike') {
      const ph = (G.time + h.off) % 2.4;
      const st = ph < 1.4 ? 'down' : ph < 1.9 ? 'warn' : 'up';
      const y = st === 'down' ? -0.45 : st === 'warn' ? -0.32 + Math.sin(G.time * 50) * 0.02 : 0;
      if (y !== h.y) { h.y = y; setSpikeY(h, y); }
      if (st === 'up' && h.state !== 'up') { if (Math.hypot(h.x - player.x, h.z - player.z) < 6) sfx('spike'); chunkDust(h.x, h.z, 0x8a8a96); }
      h.state = st;
      if (st === 'up') {
        if (onFloor && pi === h.i && pj === h.j) damagePlayer(1, h.x, h.z + 0.01);
        for (const e of enemies) if (!e.dead && !e.d.fly && e.y < 0.3 && Math.floor(e.x) === h.i && Math.floor(e.z) === h.j && (e.spikeCd || 0) < G.time) { e.spikeCd = G.time + 0.5; hurtEnemyRaw(e, 18 + G.floor * 3, '#c8ccd8'); }
      }
    } else if (h.kind === 'vent') {
      const ph = (G.time + h.off) % 4.5;
      const st = ph < 2.7 ? 'idle' : ph < 3.4 ? 'warn' : 'puff';
      // gas looks like Toxic Cloud poison (user 11-16: was yellow sparks): soft green puffs. Idle = a thin wisp, warn = puffs
      // bubbling up at the grate, puff = a billowing cloud that swells to the hit radius and fades
      const vp = ph - 3.4, vs = h.i * 1.7 + h.j;
      if (st === 'idle') gfxFlame(puffBatch, h.x, 0.05 + 0.25 * ((G.time * 0.4 + vs) % 1), h.z, 0.35, 0.3, Math.sin(G.time + vs) * 0.1, 0x38c02c, 0.18 * Math.sin(3.14 * ((G.time * 0.4 + vs) % 1)));
      else if (st === 'warn') { const w = (ph - 2.7) / 0.7; for (let q = 0; q < 2; q++) gfxFlame(puffBatch, h.x + (q ? 0.18 : -0.15), 0.02, h.z + (q ? -0.1 : 0.12), 0.35 + 0.35 * w, 0.3 + 0.35 * w, Math.sin(G.time * 4 + q) * 0.12, q ? 0x7cf04e : 0x38c02c, 0.35 + 0.35 * w); }
      else { const t = vp / 1.1, R = 0.45 + 1.0 * Math.min(1, t * 1.6), al = 0.8 * Math.min(1, t * 6) * (1 - Math.max(0, (t - 0.55) / 0.45));
        const nP = MOBILE ? 4 : 5;
        for (let q = 0; q < nP; q++) { const a = vs + q * 6.2832 / nP + G.time * (q % 2 ? 0.5 : -0.4), d = R * 0.42;
          gfxFlame(puffBatch, h.x + Math.cos(a) * d, -0.1 + 0.35 * t, h.z + Math.sin(a) * d, R * 1.15, R * (0.95 + 0.25 * t), Math.sin(G.time * 1.3 + q) * 0.1, q % 2 ? 0x7cf04e : 0x38c02c, al); }
      }
      h.dk = (h.dk || 0) + ((st === 'puff' ? 0.9 : st === 'warn' ? 0.45 : 0) - (h.dk || 0)) * Math.min(1, dt * 6); // dark gas pool: danger
      gfxPut(hazardBatch, h.x, 0.035, h.z, 1.35 * (0.7 + 0.3 * h.dk), h.i * 1.7 + h.j, HAZ_GAS, h.dk);
      if (st === 'puff') {
        if (h.state !== 'puff') { h.hit = false; if (Math.hypot(h.x - player.x, h.z - player.z) < 3.5) sfx('puff'); } // only right next to a vent: from 7 tiles away the repeating hiss read as looping wind
        for (let k = gfxEmit(h, 'eW', 5, dt); k > 0; k--) { const a = Math.random() * 6.28, d = Math.random() * 1.2; spark(h.x + Math.cos(a) * d, rr(0.3, 0.9), h.z + Math.sin(a) * d, 0x2a8a20, { vx: rr(-0.3, 0.3), vy: 0.25, vz: rr(-0.3, 0.3), s: rr(0.8, 1.2), life: rr(0.8, 1.2), drag: 0 }); } // green wisps trailing off, like Toxic Cloud
        if (!h.hit && onFloor && Math.hypot(player.x - h.x, player.z - h.z) < 1.3) { h.hit = true; damagePlayer(1, h.x, h.z); }
        for (const e of enemies) if (!e.dead && Math.hypot(e.x - h.x, e.z - h.z) < 1.4) { e.poison = 2; e.poisonDps = Math.max(e.poisonDps || 0, 8 + G.floor * 2); }
      }
      h.state = st;
    } else if (h.kind === 'lava') {
      h.glow.material.opacity = 0.4 + Math.sin(G.time * 3 + h.x) * 0.1;
      if ((h.pop = (h.pop || rr(0.6, 2.2)) - dt) <= 0) { // now and then a heat bubble bursts: a few hot spatters
        h.pop = rr(0.8, 2.4); const x = h.x + rr(-0.35, 0.35), z = h.z + rr(-0.35, 0.35);
        for (let q = 0; q < 3; q++) { const b = Math.random() * 6.28; spark(x, 0.06, z, q ? 0xff6a14 : 0xffd040, { vx: Math.cos(b) * 0.8, vy: rr(1.2, 2), vz: Math.sin(b) * 0.8, s: 0.12, life: 0.4, drag: 1, grav: -5 }); }
      }
      if (onFloor && pi === h.i && pj === h.j) damagePlayer(1, h.x, h.z + 0.01);
      for (const e of enemies) if (!e.dead && !e.d.fly && e.y < 0.3 && Math.floor(e.x) === h.i && Math.floor(e.z) === h.j && (e.lavaCd || 0) < G.time) { e.lavaCd = G.time + 0.5; hurtEnemyRaw(e, 10 + G.floor * 2, '#ff8a2a'); }
    }
  }
}
// shared by every pot and barrel (they were a new material each)
const barrelMat = new THREE.MeshLambertMaterial({ color: 0xa8231c, emissive: 0x220000 }), barrelTopMat = new THREE.MeshBasicMaterial({ color: 0xffb020 });
const potMat = new THREE.MeshLambertMaterial({ color: 0xa8643c }), potLidMat = new THREE.MeshLambertMaterial({ color: 0x6e3a22 });
function addBarrel(x, z) {
  const m = new THREE.Mesh(boxGeo, barrelMat);
  m.scale.set(0.5, 0.62, 0.5); m.position.set(x, 0, z); m.castShadow = true;
  for (const y of [0.22, 0.75]) { const b = new THREE.Mesh(boxGeo, ironMat); b.scale.set(1.06, 0.1, 1.06); b.position.y = y; m.add(b); }
  const top = new THREE.Mesh(boxGeo, barrelTopMat); top.scale.set(0.3, 0.05, 0.3); top.position.y = 1; m.add(top);
  scene.add(m); pots.push({ x, z, mesh: m, barrel: true });
}
function addPot(x, z) {
  const m = new THREE.Mesh(boxGeo, potMat);
  m.scale.set(0.42, 0.5, 0.42); m.position.set(x, 0, z); m.castShadow = true; m.rotation.y = Math.random();
  const lid = new THREE.Mesh(boxGeo, potLidMat); lid.scale.set(0.7, 0.16, 0.7); lid.position.y = 1; m.add(lid);
  scene.add(m); pots.push({ x, z, mesh: m });
}

// ---------- room flow ----------
function roomAt(x, z) {
  const gx = Math.floor(x / SX), gy = Math.floor(z / SZ);
  if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) return null;
  const r = roomGrid[gy * GW + gx];
  if (!r) return null;
  const lx = x - r.x0, lz = z - r.z0;
  return lx > 1.2 && lx < r.w + 0.8 && lz > 1.2 && lz < r.h + 0.8 ? r : null;
}
function enterRoom(r) {
  G.curRoom = r;
  r.visited = true; r.seen = true;
  for (const o of r.links) o.seen = true;
  r.flames.slice(0, 4).forEach((f, k) => { const nx = k < 2 ? 0 : k === 2 ? 0.6 : -0.6, nz = k < 2 ? 0.6 : 0; torchLights[k].position.set(f.position.x + nx, f.position.y + 0.3, f.position.z + nz); });
  for (const l of torchLights) l.color.set(r.type === 'calm' ? CALM_LIGHT : G.biome.torch); // calm rooms burn warm gold
  if (!r.lit) {
    r.lit = true;
    for (const f of r.flames) { f.visible = true; f.userData.core.visible = true; f.userData.flare = 1; burst(f.position.x, f.position.y, f.position.z, 0xffa040, 6, 2, 0.3, 0.4); }
    sfx('fire');
    if (r.type === 'calm') { const [a, b] = CALM_INFO[r.calm] || CALM_INFO.quiet; toast(`<span style="color:#ffd89a">${a}</span> · ${b}`, ''); } // one small line up top: the big centre banner sat on the spring / shrine
  }
  if (!r.cleared && !r.active) {
    r.active = true; r.fightT = G.run.time;
    lockRoom(r, true);
    G.waveDelay = 0.6;
    if (r.type === 'boss') { banner('BOSS LAIR', 'SURVIVE THE WAVES. SOMETHING IS COMING'); }
    if (r.type === 'challenge') { banner('CHALLENGE', 'ELITES GUARD A GOLDEN CHEST'); }
    if (r.variant === 'swarm') { r.waves = 0; G.swarm = { room: r, t: r.swarmLeft ?? 20 + Math.min(10, G.floor), spawnT: 0.6 }; r.swarmLeft = null; banner('SURVIVE', `${Math.round(G.swarm.t)} SECONDS`); sfx('wave'); }
    if (r.variant === 'dark') { G.dark = r; r.lit = true; for (const f of r.flames) { f.visible = false; f.userData.core.visible = false; } banner('DARKNESS', 'THE TORCHES DIE'); sfx('moan'); }
    if (r.variant === 'traps') banner('TRAP ROOM', 'MIND THE FLOOR');
  }
}
// vertical gradient with faint scanlines: bright at the floor, fading upward
const veilTex = canvasTex(16, 64, (g) => {
  const grd = g.createLinearGradient(0, 64, 0, 0); grd.addColorStop(0, 'rgba(255,255,255,.9)'); grd.addColorStop(0.5, 'rgba(255,255,255,.35)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 16, 64);
  g.fillStyle = 'rgba(255,255,255,.25)'; for (let y = 2; y < 64; y += 6) g.fillRect(0, y, 16, 1);
});
veilTex.magFilter = THREE.LinearFilter;
function lockRoom(r, on) {
  for (const d of r.doors) for (const [i, j] of d.cells) map[j * MW + i] = on ? BAR : FLOOR;
  if (on) {
    sfx('lock'); addShake(0.25);
    // every gate bar of the room in one instanced draw
    const at = [];
    for (const d of r.doors) for (const [i, j] of d.cells) {
      for (let k = 0; k < 3; k++) { const off = (k - 1) * 0.3; at.push([i + 0.5 + (d.axis === 'z' ? off : 0), j + 0.5 + (d.axis === 'x' ? off : 0)]); }
      spark(i + 0.5, 0.3, j + 0.5, 0xff4fd8, { vy: 3, s: 0.6, life: 0.6 });
    }
    const bars = new THREE.InstancedMesh(boxGeo, new THREE.MeshBasicMaterial({ color: 0xff4fd8, transparent: true, opacity: 0.85 }), at.length);
    bars.instanceMatrix.setUsage(THREE.DynamicDrawUsage); bars.frustumCulled = false; bars.userData = { t: 0, bars: at };
    at.forEach(([x, z], k) => bars.setMatrixAt(k, bMat.makeScale(0.09, 0.01, 0.09).setPosition(x, 0, z)));
    scene.add(bars); barriers.push(bars);
    // a glowing energy wall across each doorway: a soft additive veil plus a glow halo at its centre
    for (const d of r.doors) {
      const cx = d.cells.reduce((a, c) => a + c[0] + 0.5, 0) / d.cells.length, cz = d.cells.reduce((a, c) => a + c[1] + 0.5, 0) / d.cells.length;
      const veil = new THREE.Mesh(new THREE.PlaneGeometry(3.1, 1.3).translate(0, 0.65, 0), new THREE.MeshBasicMaterial({ map: veilTex, color: 0xff4fd8, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, forceSinglePass: true }));
      veil.position.set(cx, 0, cz); if (d.axis === 'x') veil.rotation.y = Math.PI / 2;
      veil.userData = { t: 0, veil: true }; scene.add(veil); barriers.push(veil);
      const g = makeGlow(0xff4fd8, 3.2, 0); g.position.set(cx, 0.7, cz); g.userData = { t: 0, halo: true }; barriers.push(g);
    }
  } else {
    for (const b of barriers) { if (b.userData.bars) { for (const [x, z] of b.userData.bars) burst(x, 0.6, z, 0xff4fd8, 3, 3, 0.25, 0.5); b.dispose(); } scene.remove(b); if (b.material && b.material.dispose) b.material.dispose(); }
    barriers = [];
  }
}
function spawnWave(r) {
  const fl = G.floor;
  const bossNow = r.type === 'boss' && r.waves === 1; // the boss arrives together with the final wave
  if (bossNow) { portals.push(makePortal(r.cx, r.cz - 2, G.boss.type, 1.6, 0.6)); sfx('lock'); addShake(0.5); flash(0.3); }
  const pool = [['slime', 3]];
  if (fl >= 1) pool.push(['eye', 1.6]);
  if (fl >= 2) pool.push(['imp', 2.2]);
  if (fl >= 2) pool.push(['bomber', 1.3], ['shroom', 0.9]);
  if (fl >= 2) pool.push(['spider', 0.7]); // a pack of 3-5 (below)
  if (fl >= 3) pool.push(['skeleton', 1.6], ['big', 0.8], ['ghost', 1.3], ['archer', 0.8], ['beetle', 0.6], ['cursed', 0.5]);
  if (fl >= 4) pool.push(['golem', 0.8], ['salamander', 0.8], ['cultist', 0.5], ['reaper', 0.6], ['runegolem', 0.3]);
  if (fl >= 5) pool.push(['shieldk', 0.6], ['crystalgolem', 0.3], ['cursed', 0.4], ['archer', 0.4]);
  if (fl >= 6) pool.push(['skeleton', 1], ['big', 0.6], ['magmagolem', 0.35], ['reaper', 0.4]);
  if (fl >= 7) pool.push(['boneknight', 0.6], ['spider', 0.4], ['shieldk', 0.3]);
  if (fl >= 9) pool.push(['runegolem', 0.25], ['crystalgolem', 0.25], ['magmagolem', 0.25], ['boneknight', 0.4]);
  const total = pool.reduce((a, b) => a + b[1], 0);
  let n = Math.floor(3 + (fl <= 1 ? 0.8 : fl * 0.9) + rand() * 2 + (r.type === 'exit' ? 2 : 0));
  n = Math.min(Math.round(n * (1 + Math.min(0.6, fl * 0.04)) * Math.sqrt(Math.max(1, G.adapt || 1))), 32); // adapt: mostly on HP now (spawnEnemy)
  const pts = [];
  for (let k = 0; k < n; k++) {
    let roll = rand() * total, type = pool[0][0];
    for (const [t, w] of pool) { if ((roll -= w) <= 0) { type = t; break; } }
    let x, z, tries = 0;
    do { x = r.x0 + 1.5 + rand() * (r.w - 1); z = r.z0 + 1.5 + rand() * (r.h - 1); tries++; }
    while (tries < 30 && (cellAt(x, z) !== FLOOR || Math.hypot(x - player.x, z - player.z) < 3.5 || pts.some((p) => Math.hypot(p[0] - x, p[1] - z) < 1)));
    pts.push([x, z]);
    if (type === 'imp' && rand() < 0.6) { for (let q = 0; q < 2; q++) portals.push(makePortal(x + rr(-0.6, 0.6), z + rr(-0.6, 0.6), 'imp', 0.6, k * 0.12)); }
    else if (type === 'spider') { const m = fl < 5 ? 3 : ri(3, fl < 8 ? 4 : 5); for (let q = 0; q < m; q++) { const a = q / m * 6.283, sx = x + Math.cos(a) * 0.7, sz = z + Math.sin(a) * 0.7; if (cellAt(sx, sz) === FLOOR) portals.push(makePortal(sx, sz, 'spider', 0.5, k * 0.12 + q * 0.06)); } k += 1; } // a pack costs 2 of the wave's slots
    else {
      const elite = fl >= 2 && rand() < Math.min(0.5, 0.06 * fl + (r.type === 'challenge' ? 0.3 : 0));
      const pt = makePortal(x, z, type, type === 'big' || GOLEMS.has(type) || type === 'shieldk' ? 1.0 : 0.7, k * 0.12);
      if (elite) { pt.elite = true; pt.mesh.children[0].material.color.set(0xffc84f); }
      portals.push(pt);
    }
  }
  if (r.champ && !r.champ.spawned && r.waves === 1) { // the champion arrives with the final wave
    r.champ.spawned = true;
    const pt = makePortal(r.cx, r.z0 + 3, r.champ.type, 1.4, 0.4); pt.elite = true; pt.champ = r.champ; pt.mesh.children[0].material.color.set(0xff3050);
    portals.push(pt);
  }
  r.waves--;
  sfx('portal');
  if (bossNow) { banner(G.boss.name, 'FINAL WAVE'); bannerT = 2.2; }
  else if (r.totalWaves > 1) { banner(r.waves === 0 ? 'FINAL WAVE' : `WAVE ${r.totalWaves - r.waves}`, ''); bannerT = 1; sfx('wave'); }
}
// feathered rings (soft falloff on both sides of the rim) instead of hard-edged flat ring geometry
function ringTexture(stops) {
  const t = canvasTex(128, 128, (g) => {
    const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    for (const [o, a] of stops) grd.addColorStop(o, `rgba(255,255,255,${a})`);
    g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
  });
  t.magFilter = THREE.LinearFilter;
  return t;
}
const softRingTex = ringTexture([[0, 0], [0.45, 0], [0.72, 0.35], [0.86, 1], [0.93, 0.45], [1, 0]]);
const markTex = ringTexture([[0, 0.14], [0.6, 0.2], [0.8, 0.55], [0.9, 0.9], [0.96, 0.35], [1, 0]]);
const flatRingGeo = new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2);
const portalGeo = flatRingGeo;
const crackGeo = new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2);
function makePortal(x, z, type, size, delay = 0) {
  const mesh = new THREE.Mesh(crackGeo, new THREE.MeshBasicMaterial({ map: splatTex, color: 0x000000, transparent: true, opacity: 0.92, depthWrite: false, ...DECAL }));
  const glow = new THREE.Mesh(portalGeo, new THREE.MeshBasicMaterial({ map: softRingTex, color: 0x8a2aff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }));
  glow.position.y = 0.01; glow.scale.setScalar(0.55); mesh.add(glow);
  mesh.rotation.y = Math.random() * 6; mesh.position.set(x, 0.045, z); mesh.scale.setScalar(0.01); scene.add(mesh);
  mesh.material.color.userData = glow;
  return { x, z, type, size, t: 0, dur: 0.9 + delay, delay, mesh };
}
const BENCH_FOES = (params.get('foes') || '').split(',').filter((t) => ENEMY[t]);
function updateSwarm(r, dt) {
  const sw = G.swarm;
  sw.t -= dt; sw.spawnT -= dt;
  if (sw.t > 0) {
    if (sw.spawnT <= 0 && enemies.length + portals.length < (BENCH ? (+params.get('stress') || 40) /* ?bench&stress=N: enemy cap */ : Math.min(40, Math.round((16 + G.floor) * Math.max(1, G.adapt || 1))))) {
      sw.spawnT = BENCH ? 0.08 : Math.max(0.2, 0.75 - G.floor * 0.04) / Math.max(1, G.adapt || 1) / (1 + Math.min(0.25, Math.max(0, G.floor - 2) * 0.05)); // deeper: up to 25% faster
      const pool = BENCH_FOES.length ? BENCH_FOES : ['slime', 'slime', 'eye'].concat(G.floor >= 2 ? ['imp', 'imp', 'bomber'] : []); // ?bench&foes=a,b: the bench's swarm
      for (let k = 0; k < ri(1, 2); k++) {
        let x, z, tries = 0;
        do { x = r.x0 + 1.5 + rand() * (r.w - 1); z = r.z0 + 1.5 + rand() * (r.h - 1); } while (++tries < 20 && (cellAt(x, z) !== FLOOR || Math.hypot(x - player.x, z - player.z) < 3.5));
        const pt = makePortal(x, z, pick(pool), 0.6, k * 0.1); pt.weak = true; portals.push(pt);
      }
    }
    return;
  }
  // time's up: everything left pops, one after another
  G.swarm = null;
  for (const pt of portals) { scene.remove(pt.mesh); pt.mesh.material.dispose(); }
  portals = [];
  enemies.filter((e) => !e.dead).forEach((e, k) => later(k * 0.05, () => { if (!e.dead) { e.hp = 0; killEnemy(e); } }));
  banner('SURVIVED', ''); // the fanfare plays in clearRoom once the last one pops
}
// Adaptive difficulty: a fight cleared faster than the target pushes G.adapt up, a slow one pulls it down. It moves a
// little per room and stays inside 0.8-2x (1.3x on the easy floors 1-10). More of it means more monsters first, then HP.
// how much faster you kill thanks to gear and permanent upgrades (stat buys, legacy, victories, Power, Haste)
function metaEdge() {
  const p = player, st = {};
  for (const k of STATS) st[k] = (p.hero.base[k] || 0) + (p.alloc[k] || 0) - ((p.metaAlloc || {})[k] || 0);
  const base = derive(p.hero.cls, st, p.hero.base), full = p.der, g = p.g;
  const fullOut = full.dmg * g.dmg * (1 + 0.08 * mlv('pow')) / (full.cd * g.cd * Math.pow(0.95, mlv('haste')));
  return Math.max(1, fullOut / (base.dmg / base.cd));
}
// Difficulty retune (Pip got much stronger: signature spells, element mechanics, INT +10%/pt). Before -> now:
//   enemy HP per floor        x1.33 -> x1.42 (HP_GROWTH; floor 6 = 5.8x floor 1 instead of 4.2x)
//   adapt on HP               sqrt(adapt) -> adapt in full; on the monster count adapt -> sqrt(adapt)
//   adapt range               0.8-1.3 on floors 1-10, 2 after -> floor 1: 0.8-1.15 (gentle first floor),
//                             floors 2-10: 0.8-1.6, 11+: 0.8-2.2; per-room step 0.88-1.15 -> 0.88-1.2
//   player level              -> +3% enemy HP per run level above 1 from floor 2 (lvHpMul; cards make each level stronger)
//   elites (floor 2+)         5%/floor, max 45% -> 6%/floor, max 50%
//   wave size                 3 + 0.8/floor -> 3 + 0.9/floor (floor 1 unchanged); Survive rooms spawn up to 25% faster deeper
//   progression retune        player levels ~half as fast and spell levels are capped by depth (gainXp, spellCap), so the
//                             enemy side eases a little: HP per floor x1.42 -> x1.40, run-level HP +3% -> +2% a level
//   HP model (user: "player overpowered"): the fixed x1.40 a floor and +2% a run level are replaced by enemyHpMul below,
//   which reads the player's actual build; adapt range 0.8-1.6/2.2 -> 0.8-1.3 (the model does the heavy lifting now)
//
// ---------- enemy HP model ----------
// Enemy HP follows the damage the build can actually deal, so a kill takes about as long on floor 12 as on floor 2 (a
// little longer, by design), whatever you picked. Base HP (ENEMY table) is tuned for a fresh start: Arcane Missiles Lv 1,
// no upgrades, where a slime takes ~1 s. Then
//   hp = base HP x power x ramp(floor) x adapt x (elite x3 / champion x2.6 / boss x0.9 / curse / daily mods)
//   power = (runDps / freshDps) ^ 0.8 x metaEdge ^ 0.5
//     runDps    expected single-target damage per second of this run's build (expectedDps): every spell's measured
//               hits-per-second table (arcana.js SPELL_HITS) x its dmg / cooldown, x damage, crit, cooldown, element,
//               echo and extra-shot multipliers from level-up stat cards, relics, blessings and gear found this run
//     freshDps  the same for this hero at a fresh start (Arcane Missiles Lv 1, no upgrades): power = 1 on floor 1
//     metaEdge  how much the permanent upgrades multiply it (Sanctum Power/Haste/Reach, bought/legacy/victory stats,
//               stored vault gear)
//   Exponent 0.8: an upgrade that doubles your damage makes foes 1.74x tougher, so you still kill 13% faster for it;
//   upgrades never feel pointless, but stacking them can't trivialise a floor. Permanent upgrades count at 0.5: doubling
//   your damage in the Sanctum still cuts kill times by 30%.
//   ramp = 1 + 0.06 per floor below: kill times hold up with depth (power alone would let them shrink as you grow).
//   Single-target time-to-kill (HP / expected DPS) this gives typical and strong builds on floors 4-12: a slime
//   ~0.65-0.75 s (floor 1: ~1 s), a skeleton ~2 s, elites ~2 s (slime) to ~6 s (skeleton), bosses ~25-30 s.
//   The bot's measured times run ~2x these (walking, misses, overkill). Early floors: power is capped (enemyHpMul).
//   Tuning: HP_POWER_EXP (how much upgrades are matched), HP_RAMP (depth), ELITE_HP_MUL / BOSS_HP_MUL.
const HP_POWER_EXP = 0.92, HP_META_EXP = 0.8, HP_RAMP = 0.1, ELITE_HP_MUL = 3.5, BOSS_HP_MUL = 1, HP_AOE = 1.25; // raised (user: still overpowered)
const hpRamp = (fl) => 1 + HP_RAMP * Math.max(0, fl - 1);
// a build's damage multipliers. strip: without the permanent upgrades (the run's own power only)
function dpsMuls(p, strip) {
  const cls = p.hero.cls, base = p.hero.base;
  let g = p.g, der = p.der, dmg = p.dmgMul, cd = p.cdMul, crit = p.crit;
  if (strip) {
    const run = {}; for (const [k, it] of Object.entries(p.gear || {})) if (it && !it.vault) run[k] = it;
    g = gearTotals(run);
    const st = {}; for (const k of STATS) st[k] = (base[k] || 0) + runOf(p, k) + (g.st[k] || 0);
    der = derive(cls, st, base);
    dmg /= 1 + 0.08 * mlv('pow'); cd /= Math.pow(0.95, mlv('haste')); crit -= 0.03 * mlv('reach');
  }
  const c = Math.min(1, Math.max(0, crit + g.crit + der.crit)), cdm = p.critDmg + g.critDmg + der.critDmg;
  return { g, der, out: dmg * g.dmg * der.dmg * (1 + c * (cdm - 1)) / Math.max(0.2, cd * g.cd * der.cd), proj: (p.extraProj || 0) + g.proj + der.proj };
}
// INT 15 double cast: only the strongest spell (highest level, first slot on a tie; never a unique or Meteor)
function echoSpell(list) { let b = null; for (const s of list) { const d = spellDef(s.id); if (!d || d.unique || d.kills) continue; if (!b || s.lv > b.lv) b = s; } return b; }
// expected single-target damage per second of a spell list under a set of multipliers (see the model above)
function spellListDps(list, m) {
  let sum = 0;
  for (const s of list) {
    const def = spellDef(s.id); if (!def) continue;
    let d;
    if (def.kills) d = def.dmg * lvMul(s.lv) * 0.7 / METEOR_KILLS[clamp(s.lv, 1, 5) - 1]; // Meteor: ~0.7 kills a second charge it
    else d = (def.legendary ? 1 : def.dmg / Math.max(0.3, def.cd)) * spellHits(def, s.lv); // the table counts the per-level cooldown cuts
    let el = 0; for (const e of def.els || []) el += (player.elPow[e] || 1) * (m.g.el[e] || 1);
    if (def.els && def.els.length) d *= el / def.els.length;
    if (m.der.echo && s === echoSpell(list)) d *= 1.25; // INT 15: the strongest spell's every 4th cast twice
    if (m.g.flags.echo) d *= 1.2;
    if (m.g.flags.stormcaller) d *= 1.125;
    if (m.proj > 0 && def.sh && def.sh.beh === 'proj') d *= 1 + 0.7 * (def.sh.shards ? Math.min(1, m.proj) : m.proj) / Math.max(1, def.sh.count || 1);
    sum += d;
  }
  return sum * m.out;
}
const FRESH_START = [{ id: 'arcane.missiles', lv: 1 }];
function expectedDps(detail) {
  const p = player; if (!p) return detail ? null : 0;
  const run = dpsMuls(p, true), full = dpsMuls(p, false);
  const runDps = spellListDps(spells, run), fullDps = spellListDps(spells, full);
  const fm = dpsMuls({ ...p, gear: {}, alloc: { ...p.metaAlloc }, dmgMul: 1 + 0.08 * mlv('pow'), cdMul: Math.pow(0.95, mlv('haste')), crit: 0.05 + 0.03 * mlv('reach'), critDmg: 2, extraProj: 0 }, true); // this hero, fresh (strip takes the Sanctum back out)
  const freshDps = spellListDps(FRESH_START, fm);
  if (!detail) return fullDps;
  return { runDps, fullDps, freshDps, meta: Math.max(1, fullDps / Math.max(1e-6, runDps)) };
}
let hpMulCache = null; // { key, v }: recomputed when the build changes (cheap, but spawns come in bursts)
function enemyHpMul() {
  if (!player || G.prologue || BENCH) return 1;
  const key = spells.map((s) => s.id + s.lv).join() + '|' + player.lv + '|' + player.dmgMul + '|' + player.cdMul + '|' + player.crit + '|' + JSON.stringify(player.alloc) + '|' + Object.values(player.gear || {}).map((it) => it && it.name).join() + '|' + G.floor;
  if (hpMulCache && hpMulCache.key === key) return hpMulCache.v;
  const d = expectedDps(true);
  const power = d && d.freshDps > 0 ? Math.pow(Math.max(1, d.runDps / d.freshDps), HP_POWER_EXP) * Math.pow(d.meta, HP_META_EXP) : 1;
  // early floors stay gentle for new players: power counts at most x1.8 on floor 1, then that ceiling grows x1.6 a floor
  // (x4.6 on floor 3, x7.4 on floor 4): only a very fast start is held back. From floor 2 on, x HP_AOE more: the model counts
  // single-target damage, but piercing / line / beam spells kill several foes at once (user: still overpowered on floor 3)
  // the Daily's head start (level 5, 4 picks) stays a head start, but foes follow the build up to x2 (x2.7, x3.6 on daily floors 2, 3); x1.3 was too easy (user 11-15)
  // user 11-17: x3.0 (x4.05, x5.47), +50%: the Daily has all elements + an awesome spell
  // user 11-17 ('monsters on daily die immediately'): the Daily's HP no longer follows the build (a weak-looking build on
  // paper got weak monsters, and the cap above only mattered for strong ones): it is FIXED at x3.0 / x4.05 / x5.47, the same for everyone
  const v = (G.daily ? 3.0 * Math.pow(1.35, G.floor - 1) : Math.min(power, 1.8 * Math.pow(1.6, Math.max(0, G.floor - 1)))) * hpRamp(G.floor) * (G.floor >= 2 ? HP_AOE : 1);
  hpMulCache = { key, v }; return v;
}
const adaptCap = () => (G.floor <= 1 ? 1.15 : 1.3);
function adaptAfter(r) {
  if (r.fightT == null || !(r.type === 'combat' || r.type === 'exit' || r.type === 'challenge') || r.variant === 'swarm') return;
  // the clock is scaled by your gear + permanent-upgrade edge, so the game reacts to your base build and those stay an advantage
  const took = Math.max(1, G.run.time - r.fightT) * metaEdge(), target = 14 + 3 * r.totalWaves; // seconds a fair fight should last
  const step = clamp(Math.pow(target / took, 0.35), 0.88, 1.2);
  G.adapt = clamp((G.adapt || 1) * step, 0.8, adaptCap());
}
// An interstitial on the way down the stairs, while the screen is faded out: at most one per 2.5 minutes of play, never
// on a player's very first run, never with Remove Ads.
function floorAdDue() {
  if (AUTO || BENCH || ZOO || G.daily || Monet.adsRemoved || (meta.stats.runs || 0) < 1) return false; // a daily is only 3 short floors: no ad between them
  if (G.run.time - (G.run.lastAdT ?? -999) < 150) return false;
  G.run.lastAdT = G.run.time; return true;
}
function clearRoom(r) {
  r.cleared = true; r.active = false; adaptAfter(r);
  G.saveDue = true; G.pendT = G.run.time; // checkpoint once the room's reward pick (if any) is done
  if (G.dark === r) { G.dark = null; for (const f of r.flames) { f.visible = true; f.userData.core.visible = true; } }
  lockRoom(r, false);
  const big = r.type === 'boss' || r.champDrop || r.variant === 'swarm'; // the full fanfare is kept for boss, champion and survive rooms
  flash(0.15); sfx(big ? 'clear' : 'cleared'); if (big) addShake(0.2); // the card screen that follows says ROOM CLEARED
  for (const f of r.flames || []) { f.userData.flare = 1; burst(f.position.x, f.position.y, f.position.z, 0xffa040, 10, 3, 0.3, 0.6); }
  fxLight.position.set(r.cx, 2.5, r.cz); fxLight.intensity = 60;
  if (r.type === 'boss' && G.daily && G.floor >= DAILY_FLOORS) { later(1.4, () => dailyWin()); return; }
  if (r.type === 'boss' && G.floor === WIN_FLOOR) { later(1.4, () => showVictory()); return; }
  if (r.type === 'exit' || r.type === 'boss') spawnStairs(r);
  if (r.type === 'challenge') { addGoldChest(r); burst(r.cx, 0.6, r.cz, 0xffd34f, 30, 5, 0.5, 0.7); }
  for (let k = 0; k < Math.round((3 + Math.floor(G.floor / 2)) * (G.xpMul || 1)); k++) dropPickup(r.cx + rr(-1, 1), r.cz + rr(-1, 1), 'coin');
  if (player.hp < player.maxHp && rand() < 0.05) dropPickup(r.cx, r.cz, 'heart');
  later(0.6, () => { for (const c of pickups) if (c.kind === 'coin' && roomAt(c.x, c.z) === r) c.homing = true; }); // room clear: every coin left in the room flies to Pip
  const champ = r.champDrop, bsId = G.bossSpell; G.bossSpell = null;
  if (bsId) later(0.9, () => { if (G.state === 'play') openCards('BOSS SPELL', bossOffer(bsId)); });
  else if (r.mimic || champ) later(0.9, () => { if (G.state === 'play') { G.rerollFn = () => upgradeOptions(); G.rerolled = false; openCards(r.mimic ? 'MIMIC SLAIN' : 'CHAMPION SLAIN', relicOptions(2).concat(upgradeOptions().slice(0, 1))); } });
  else if (r.type === 'exit') later(0.9, () => { if (G.state === 'play') { G.rerollFn = () => upgradeOptions(); G.rerolled = false; openCards('FLOOR CLEARED', upgradeOptions()); } });
  // ordinary rooms only drop loot: power-up picks come from level ups, floor clears, champions, bosses and treasure
  r.mimic = false; r.champDrop = false;
}
function addGoldChest(r) {
  const chest = makeSprite('items', 1.1, 4); chest.position.set(r.cx, 0.08, r.cz);
  chest.material.uniforms.uTint.value.set(0xffe08a);
  props.push({ kind: 'chest', gold: true, room: r, x: r.cx, z: r.cz, mesh: chest, glow: makeGlowAt(r.cx, 0.5, r.cz, 0xffd34f, 2.6, 0.45) });
}
function spawnStairs(r) {
  const group = new THREE.Group();
  const hole = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.05, 1.6), new THREE.MeshBasicMaterial({ color: 0x000000 }));
  hole.position.y = 0.03; group.add(hole);
  for (let k = 0; k < 4; k++) {
    const step = new THREE.Mesh(boxGeo, new THREE.MeshLambertMaterial({ color: G.pal.cap }));
    step.scale.set(1.6 - k * 0.3, 0.06, 0.3); step.position.set(0, 0.04, -0.6 + k * 0.32); group.add(step);
  }
  group.position.set(r.cx, 0, r.cz); scene.add(group);
  const ring = new THREE.Mesh(portalGeo, new THREE.MeshBasicMaterial({ map: softRingTex, color: 0xff4fd8, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }));
  ring.position.set(r.cx, 0.06, r.cz); ring.scale.setScalar(1.1); ring.material.opacity = 0.6; scene.add(ring);
  props.push({ kind: 'stairs', x: r.cx, z: r.cz, group, ring, glow: makeGlowAt(r.cx, 0.3, r.cz, 0xff4fd8, 1.8, 0.22) });
  burst(r.cx, 0.5, r.cz, 0xff4fd8, 40, 6, 0.5, 0.9);
}
function nextFloor() {
  if (G.state !== 'play') return;
  G.state = 'trans'; sfx('stairs');
  $('fade').style.opacity = 1;
  later(0.55, () => {
    for (const p of props) if (p.ring) scene.remove(p.ring);
    G.floor++;
    startFloor(G.floor); checkpoint();
    if (floorAdDue()) { G.state = 'ad'; Monet.interstitial('next_floor').then(() => { if (G.state === 'ad') G.state = 'play'; }); }
    else G.state = 'play';
  });
}

// ---------- enemies ----------
// a long boss name ("THE CLOCKWORK SENTINEL") was cut off on a 390 px phone: tighter letters, then a smaller font, on one line
function fitBossName() {
  const el = $('bossname'); if (!el) return;
  el.style.whiteSpace = 'nowrap'; el.style.letterSpacing = ''; el.style.fontSize = '';
  const fits = () => el.scrollWidth <= el.clientWidth + 1;
  if (!el.clientWidth || fits()) return;
  for (const [ls, fs] of [['2px', ''], ['1px', ''], ['1px', '12px'], ['0.5px', '11px'], ['0px', '10px']]) { el.style.letterSpacing = ls; el.style.fontSize = fs; if (fits()) return; }
}
addEventListener('resize', () => { const b = $('bossbar'); if (b && !b.classList.contains('hidden')) fitBossName(); });
const FOE_RIM = { reaper: [0xb8ff8a, 0.7], imp: [0xffb07a, 0.75], runegolem: [0x9fefff, 0.5], shieldk: [0xd8c0ff, 0.4] };
function spawnEnemy(type, x, z, elite = false) {
  const d = ENEMY[type], fl = G.floor;
  const isBoss = BOSSES.some((b) => b.type === type);
  const hpMul = (1 + (G.curse || 0)) * enemyHpMul() * (elite ? (G.prologue ? 3 : ELITE_HP_MUL) : 1) * (isBoss ? BOSS_HP_MUL : 1) * clamp(G.adapt || 1, 0.8, adaptCap()); // follows your build (an old save's adapt above the new cap is capped) (see enemyHpMul)
  const sheet = d.sheet || type;
  const h = (d.h || SPRITE_H[sheet]) * (elite ? 1.35 : 1);
  const e = {
    type, x, z, vx: 0, vz: 0, kx: 0, kz: 0, y: 0, r: d.r, hp: d.hp * hpMul, maxHp: d.hp * hpMul, d,
    speed: d.speed * (1 + Math.min(0.6, fl * 0.035)), t: rand() * 2, state: 'idle', st: rr(0.2, 0.8), flash: 0, slow: 0, freeze: 0, poison: 0, poisonDps: 0, stun: 0,
    face: 1, spawn: 0, anim: rand() * 4, mesh: makeSprite(d.body || sheet, h, d.frame || 0), shadow: makeShadow(d.r * 2.3), hits: new Map(), shots: 0, jumps: 0,
  };
  e.isBoss = isBoss;
  if (PARTS[d.body || sheet]) { e.body = d.body || sheet; e.wpn = makePart(e.body, h); e.wa = 0; e.wx = 0; } // the swinging hand / arm
  const mod = G.daily && G.daily.mod.id;
  if (mod === 'frenzy' && !e.isBoss) e.speed *= 1.3;
  if (mod === 'greed' && !e.isBoss) { e.hp *= 1.25; e.maxHp = e.hp; }
  if (mod === 'swarm' && !e.isBoss) { // half the monsters bring a twin; both a little weaker
    e.hp *= 0.7; e.maxHp = e.hp;
    if (!G.dupe && rand() < 0.5) { G.dupe = true; try { const t = spawnEnemy(type, x + rr(-0.6, 0.6), z + rr(-0.6, 0.6), elite); t.spawn = e.spawn; t.state = e.state; t.st = e.st; } finally { G.dupe = false; } }
  }
  if (e.isBoss && G.floor === WIN_FLOOR) { e.hp *= 2; e.maxHp = e.hp; e.mesh.userData.bw *= 1.2; e.mesh.userData.bh *= 1.2; if (e.wpn) { e.wpn.userData.bw *= 1.2; e.wpn.userData.bh *= 1.2; } }
  if (e.isBoss) { e.state = type === 'boss' ? 'wait' : 'idle'; e.st = 1.2; $('bossname').textContent = G.boss.name; $('bossbar').classList.remove('hidden'); fitBossName(); }
  if (G.still > 0) e.freeze = G.still; // born into stopped time
  if (elite) { e.elite = true; e.r *= 1.25; e.shadow.scale.multiplyScalar(1.25); const el = pick(ELEMENT_ORDER); e.affinity = { [el]: 0.25 }; e.affColor = new THREE.Color(ELEMENTS[el].color).getHex(); }
  if (type === 'cursed' || type === 'shieldk' || type === 'beetle') { e.guardable = true; e.guard = true; }
  const rim = FOE_RIM[type]; if (rim) { const u = e.mesh.material.uniforms; u.uRim.value = rim[1]; u.uRimCol.value.set(rim[0]); e.mesh.material.defines = { RIM: 1 }; e.mesh.material.needsUpdate = true; } // dark foes on dark floors: a lit edge
  if (type === 'ghost' || GOLEMS.has(type) || type === 'shroom' || type === 'cultist' || type === 'archer') e.st = rr(1, 2);
  e.mesh.position.set(x, 0, z);
  enemies.push(e);
  return e;
}
function nearestEnemy(x, z, range, exclude) {
  let best = null, bd = range;
  for (const e of enemies) {
    if (e.spawn < 0.3 || e.dead || e.hidden || (exclude && exclude.has(e))) continue;
    const d = Math.hypot(e.x - x, e.z - z);
    if (d < bd) { bd = d; best = e; }
  }
  return best;
}
// how far a foe slides from a hit: bosses and mushrooms barely, golems a bit, big ones and elites less
function kbMul(e) { return e.isBoss || e.type === 'shroom' ? 0.05 : isGolem(e) ? 0.15 : e.type === 'shieldk' ? 0.3 : e.type === 'big' || e.elite || e.type === 'boneknight' ? 0.4 : e.type === 'beetle' ? 0.6 : 1; }
// STR: extra damage against bosses (incl. the 10-milestone +25%) and elites/champions
function strMul(e) { const d = player.der; return e.isBoss ? d.bossDmg || 1 : e.elite || e.name ? d.eliteDmg || 1 : 1; }
function hurtEnemy(e, dmg, kx = 0, kz = 0, kb = 3, color = 0xffffff, els = null) {
  if (e.dead) return;
  if (e.guardable) { const gm = foeGuard(e, kx, kz); if (gm < 1) { if (gm <= 0) { e.flash = Math.max(e.flash, 0.3); return; } dmg *= gm; kb *= 0.2; } } // shields and shells (cursed warrior, shield knight, rolling beetle)
  const g = player.g, der = player.der, base = dmg, iced = e.ice && e.freeze > 0; // iced: frozen by frost chills, the next hit shatters it
  let crit = false, tag = '';
  dmg *= player.dmgMul * g.dmg * der.dmg * strMul(e);
  kb *= der.kb || 1; // STR: more knockback
  if (els && els.length) {
    if (g.flags.prism && Math.random() < 0.5) els = els.concat([pick(ELEMENT_ORDER)]);
    const res = resistOf(e.type, els, e.affinity);
    let ep = 0; for (const el of els) ep += (player.elPow[el] || 1) * (g.el[el] || 1);
    dmg *= res * ep / els.length;
    if (els.includes('holy') && UNDEAD.has(e.type)) dmg *= 2;
    tag = res === 0 ? 'IMMUNE' : res < 0.8 ? 'RESIST' : res > 1.2 ? 'WEAK' : '';
    if (els.includes('earth')) kb *= 2.6; // earth: big knockback (plus the stun in elementOnHit)
    e.lastEls = els;
  }
  if (e.shock > 0) dmg *= 1 + (e.shockAmt || 0.25);
  if (e.curse > 0) dmg *= 1.15;
  if ((isGolem(e) && e.state === 'stun') || (e.type === 'beetle' && e.state === 'dizzy')) dmg *= 1.5; // golem stunned by a wall / beetle dizzy after a roll
  if (e.type === 'sentinel' && e.state === 'overheat') dmg *= 2; // its core is exposed
  if (dmg > 0 && Math.random() < player.crit + g.crit + der.crit + (els && els.includes('arcane') ? 0.2 : 0)) { dmg *= player.critDmg + g.critDmg + der.critDmg; crit = true; if (els && els.includes('arcane')) burst(e.x, 0.8, e.z, 0xff5fd8, 8, 4, 0.35, 0.3); }
  if (DMGLOG) DMGLOG[color] = (DMGLOG[color] || 0) + Math.min(dmg, Math.max(0, e.hp));
  G.run.dmg += Math.min(dmg, Math.max(0, e.hp)); e.hp -= dmg; e.flash = 1;
  if (e.type === 'cultist' && e.state === 'cast') cultistHurt(e, dmg);
  const kmul = kbMul(e);
  const kl = Math.hypot(kx, kz) || 1;
  e.kx += kx / kl * kb * kmul; e.kz += kz / kl * kb * kmul;
  e.squash = 0.25;
  if (der.stagger && dmg > 0 && !e.isBoss && !e.elite && !e.name && G.time > (e.stagImm || 0)) { e.stun = Math.max(e.stun || 0, 0.3); e.stagImm = G.time + 1; } // STR 5: a short stagger, never bosses/elites
  const ty = 1.1 + (e.isBoss ? 2 : 0);
  if (tag === 'IMMUNE') addText(e.x, ty, e.z, 'IMMUNE', '#8a8aa0', 0.9);
  else dmgText(e, ty, dmg, crit ? '#ffe14f' : tag === 'WEAK' ? '#ffb43a' : tag === 'RESIST' ? '#a0a0b8' : '#ffffff', crit ? 1.5 : tag === 'WEAK' ? 1.2 : 1, tag === 'WEAK' ? '!' : '');
  spark(e.x, 0.5, e.z, color, { s: 0.5, life: 0.15, drag: 0 });
  for (let k = 0; k < 3; k++) spark(e.x, 0.5, e.z, color, { vx: kx / kl * rr(3, 7), vz: kz / kl * rr(3, 7), vy: rr(0.5, 2.5), s: 0.22, life: 0.25, drag: 5, spread: 2 });
  if (Math.random() < 0.35) splat(e.x + rr(-0.3, 0.3), e.z + rr(-0.3, 0.3), e.d.splat, rr(0.3, 0.6));
  if (crit && der.chain && !critChain) { // LUK 15: a crit jumps to the nearest other foe for half its damage
    const nx = nearestEnemy(e.x, e.z, 3.4, new Set([e]));
    if (nx) { critChain = true; bolts.push({ pts: [new THREE.Vector3(e.x, 0.7, e.z), new THREE.Vector3(nx.x, 0.7, nx.z)], life: 0.14, color: '#ffe14f' }); hurtEnemy(nx, base * 0.5, nx.x - e.x, nx.z - e.z, 1, 0xffe14f, els); critChain = false; }
  }
  if (els && dmg > 0) applyStatus(e, els, dmg);
  if (els && els.includes('frost') && ccMul(e) < 0.6 && Math.random() < 0.15) addText(e.x, ty + 0.4, e.z, 'TOUGH', '#9fe7ff', 0.7);
  if (player.hero.id === 'necro' && dmg > 0) { e.curse = 4; e.curseDmg = Math.max(e.curseDmg || 0, dmg * 1.2 * der.status); }
  sfx('hit');
  if (!elFx && dmg > 0) elementOnHit(e, els, base, iced);
  if (e.hp <= 0 && !e.dead) killEnemy(e, kx, kz); // (a shatter may already have finished it)
}
// ---------- element signatures (arcana.js ELEMENTS.info): one mechanic per element, on direct hits ----------
// elFx guards against chains: arcs, shatters and patches hit with it set, so they never trigger more of themselves.
let elFx = false;
let critChain = false; // LUK 15 crit chains never chain again
const arcSeen = new Set(); // reused exclusion set for storm arcs (no per-hit allocation)
const EL_PATCH_MAX = 10; // live burning-ground / toxic-puddle patches, all elements together
function elPatch(x, z, r, life, dmg, el, color) {
  let n = 0;
  for (const f of fires) if (f.elfx) { n++; if (f.el === el && Math.abs(f.x - x) < r && Math.abs(f.z - z) < r) { f.life = Math.max(f.life, life * 0.8); return; } } // refresh a patch already there
  if (n >= EL_PATCH_MAX || cellAt(x, z) !== FLOOR) return;
  fires.push({ x, z, r, life, dmg, tick: 0.2, els: [el], el, color, elfx: true, glow: makeGlowAt(x, 0.2, z, color, r * 2.6, 0.55) });
  addRing(x, z, 0.2, r, 0.3, color);
}
// Pip's own ground patches (they only ever hurt foes) look like the spell itself, soft-edged and bright. Fire = a glowing
// ember scorch with flame tongues that grow, flicker and die back in turn, plus rising embers (lava is a dark-crusted
// molten pool inside a rock rim). Venom = a glossy green puddle with bubbles and droplet pops; Toxic Cloud = drifting gas
// puffs (hazard gas is murky olive/purple on a dark jagged pool). Rates are per second.
function playerGroundFx(f, dt, fade, fin) {
  const k = f.kind, r = f.r, area = clamp(r / 0.8, 0.6, 1.8), sd = f.rot * 10;
  if (k === 'fire') {
    f.glow.material.opacity = f.g0 * fade * (0.78 + 0.22 * Math.sin(G.time * 21 + f.x * 5) * Math.sin(G.time * 13.7 + f.z * 3));
    gfxPut(emberBatch, f.x, 0.05, f.z, r * 1.2 * (0.8 + 0.2 * fin), f.rot, 0xffffff, fade * (0.65 + 0.15 * Math.sin(G.time * 9 + f.x * 3)));
    const nT = clamp(Math.round(r * r * 7 + 1), 2, MOBILE ? 5 : 7), hs = clamp(r * 1.1, 0.55, 1.05) * (0.45 + 0.55 * fade);
    for (let t = 0; t < nT; t++) { // each tongue: grows, flickers and dies back, then reappears somewhere else in the patch
      const u = G.time * (1.5 + hash(t, sd, 1) * 1.1) + hash(t, sd, 2), cyc = Math.floor(u), ph = u - cyc, env = Math.sin(ph * Math.PI);
      const a = hash(cyc, t, sd) * 6.2832, d = Math.sqrt(hash(cyc, t, sd + 1)) * r * 0.62;
      const h = hs * (0.55 + 0.45 * hash(cyc, t, sd + 2)) * (0.3 + 0.7 * env) * (0.88 + 0.12 * Math.sin(G.time * 23 + t * 3.1));
      gfxFlame(flameBatch, f.x + Math.cos(a) * d, 0.02, f.z + Math.sin(a) * d, h * 0.52, h, Math.sin(G.time * 5 + t * 1.7 + f.x) * 0.14 * h, 0xffffff, fade * (0.5 + 0.25 * env));
    }
    for (let n = gfxEmit(f, 'eA', 8 * area, dt); n > 0; n--) { // embers: small, bright, rising fast and swaying
      const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r * 0.85;
      spark(f.x + Math.cos(a) * d, 0.08, f.z + Math.sin(a) * d, Math.random() < 0.55 ? 0xffd25a : 0xff8a1a, { vx: rr(-0.35, 0.35), vy: rr(1.7, 2.8), vz: rr(-0.35, 0.35), s: rr(0.1, 0.2), life: rr(0.5, 0.85), drag: 0.5 });
    }
    if (gfxEmit(f, 'eC', 1.2 * area, dt)) spark(f.x + rr(-0.3, 0.3) * r, 0.6, f.z + rr(-0.3, 0.3) * r, 0x40200a, { vy: 1.1, s: rr(0.9, 1.3), life: 0.7, drag: 0 }); // heat haze
  } else if (k === 'venom') {
    f.glow.material.opacity = f.g0 * fade * (f.drift ? 0.3 : 0.55) * (0.88 + 0.12 * Math.sin(G.time * 3 + f.x)); // a soft halo only: the puddle / puffs carry the look
    if (f.drift) { // Toxic Cloud: a clump of soft gas puffs rolling around each other
      const nP = MOBILE ? 5 : 6;
      for (let p = 0; p < nP; p++) {
        const a = f.rot + p * 6.2832 / nP + G.time * (p % 2 ? 0.45 : -0.35), d = r * (0.2 + 0.4 * hash(p, sd, 4)), s = r * (1 + 0.18 * Math.sin(G.time * 1.4 + p * 2.1)) * (0.6 + 0.4 * fin);
        gfxFlame(puffBatch, f.x + Math.cos(a) * d, -0.12 + 0.1 * Math.sin(G.time * 0.9 + p), f.z + Math.sin(a) * d, s * 1.35, s * 1.1, 0, p % 2 ? (f.look === 'plague' ? 0x9a5cff : 0x7cf04e) : 0x38c02c, 0.78 * fade); // Plague Cloud: green and curse-purple puffs
      }
      for (let n = gfxEmit(f, 'eC', 2.5 * area, dt); n > 0; n--) // wisps trailing off the cloud
        spark(f.x + rr(-0.7, 0.7) * r, rr(0.3, 0.8), f.z + rr(-0.7, 0.7) * r, 0x2a8a20, { vx: rr(-0.3, 0.3), vy: 0.2, vz: rr(-0.3, 0.3), s: rr(0.8, 1.2), life: rr(0.9, 1.3), drag: 0 });
      return;
    }
    gfxPut(poolBatch, f.x, 0.045, f.z, r * 1.12 * (0.75 + 0.25 * fin) * (1 + 0.025 * Math.sin(G.time * 2.2 + f.x)), f.rot, f.look === 'mire' ? 0x8a9a2a : 0x3cf03a, 0.92 * fade); // Toxic Mire: a muddy olive bog
    for (let n = gfxEmit(f, 'eA', 6 * area, dt); n > 0; n--) { // bubbles: hollow rings swelling up slowly
      const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r * 0.75;
      spark(f.x + Math.cos(a) * d, 0.05, f.z + Math.sin(a) * d, Math.random() < 0.6 ? 0xb8ff90 : 0x6aff4a, { vy: rr(0.2, 0.45), s: -rr(0.18, 0.32), life: rr(0.45, 0.75), drag: 0 });
    }
    for (let n = gfxEmit(f, 'eB', 2.5 * area, dt); n > 0; n--) { // pops: a few droplets flicked out of the surface
      const a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * r * 0.7, x = f.x + Math.cos(a) * d, z = f.z + Math.sin(a) * d;
      for (let q = 0; q < 3; q++) { const b = Math.random() * 6.28; spark(x, 0.22, z, 0xe0ffc8, { vx: Math.cos(b) * 1.3, vy: rr(0.6, 1.2), vz: Math.sin(b) * 1.3, s: 0.08, life: 0.18, drag: 2, grav: -6 }); }
    }
    for (let n = gfxEmit(f, 'eC', 1.4 * area, dt); n > 0; n--) // faint mist
      spark(f.x + rr(-0.6, 0.6) * r, 0.3, f.z + rr(-0.6, 0.6) * r, 0x1e5a1a, { vx: rr(-0.3, 0.3), vy: 0.15, vz: rr(-0.3, 0.3), s: rr(1, 1.5), life: rr(1.1, 1.6), drag: 0 });
  } else { // other elements (frost trail...): a soft tinted puddle
    f.glow.material.opacity = f.g0 * fade;
    gfxPut(poolBatch, f.x, 0.045, f.z, r * 1.1 * (0.75 + 0.25 * fin), f.rot, f.color || 0xffffff, 0.6 * fade);
    for (let n = gfxEmit(f, 'eA', 7 * area, dt); n > 0; n--) spark(f.x + rr(-r, r) * 0.8, 0.1, f.z + rr(-r, r) * 0.8, f.color || 0xffffff, { vy: 1, s: 0.3, life: 0.6, drag: 0 });
  }
}
function elementOnHit(e, els, base, iced) {
  elFx = true;
  if (iced && !e.isBoss) { // frost: a hit on a frozen foe shatters it, hurting everything around
    e.ice = false; e.freeze = 0;
    const R = 1.9, sd = Math.max(8, base * 1.2);
    addRing(e.x, e.z, 0.3, R, 0.35, 0x9fe8ff); addRing(e.x, e.z, 0.2, R * 0.7, 0.4, 0xffffff);
    burst(e.x, 0.7, e.z, 0xdff8ff, 22, 6, 0.4, 0.45); chunk(e.x, 0.6, e.z, 0xbfefff, 6, 5, 0.1);
    addText(e.x, 1.7, e.z, 'SHATTER', '#bff4ff', 1.1); sfx('frost'); addShake(0.15);
    for (const o of enemies) if (!o.dead && o !== e && Math.hypot(o.x - e.x, o.z - e.z) < R + o.r) hurtEnemy(o, sd, o.x - e.x, o.z - e.z, 3, 0x9fe8ff, null);
    if (!e.dead) hurtEnemy(e, sd, 0, 0, 1, 0x9fe8ff, null);
  }
  if (els) for (const el of els) {
    if (statusMul(e, el) <= 0) continue; // immune foes get no signature either
    switch (el) {
      case 'fire': elPatch(e.x, e.z, 0.95, 2.6, Math.max(2, base * 0.25), 'fire', 0xff5a10); break; // burning ground, ticks every 0.4s
      case 'storm': { // every hit arcs to 2 nearby foes for 45%
        if (momQuiet || G.time - (e.arcT || -9) < 0.2) break; e.arcT = G.time;
        arcSeen.clear(); arcSeen.add(e);
        let from = e;
        for (let k = 0; k < 2; k++) {
          const nx = nearestEnemy(from.x, from.z, 3.4, arcSeen); if (!nx) break;
          arcSeen.add(nx);
          if (skyArcs) { skyBolt(nx.x, nx.z, '#cfe4ff', 0.2, 7); bolts[bolts.length - 1].glow = 'rgba(110,160,255,.45)'; } // Thunderfall (user 11-15): its arcs fall from the sky, never sideways
          else bolts.push({ pts: [new THREE.Vector3(from.x, 0.7, from.z), new THREE.Vector3((from.x + nx.x) / 2 + rr(-0.3, 0.3), 0.9, (from.z + nx.z) / 2 + rr(-0.3, 0.3)), new THREE.Vector3(nx.x, 0.7, nx.z)], life: 0.16, color: '#fff36a' });
          hurtEnemy(nx, base * 0.45, nx.x - from.x, nx.z - from.z, 1, 0xfff36a, ['storm']);
          from = nx;
        }
        if (from !== e) sfx('zap');
        break;
      }
      case 'earth': // knockback (hurtEnemy) + a 0.6s stun, then 1.2s before it can be stunned again; never bosses
        if (!e.isBoss && G.time > (e.stunImm || 0)) { e.stun = Math.max(e.stun || 0, 0.6 * Math.min(1, ccMul(e) * 1.4)); e.stunImm = G.time + 1.8; chunkDust(e.x, e.z, 0xc8925a); }
        break;
    }
  }
  elFx = false;
}
function killEnemy(e, kx = 0, kz = 0) {
  e.dead = true; killMarker(e);
  const lockedRoom = rooms.find((q) => q.active);
  if (lockedRoom && lockedRoom.waves <= 0 && portals.length === 0 && enemies.every((o) => o.dead || o === e) && G.state === 'play') {
    // slow-motion finisher only for bosses; ordinary rooms just get a short freeze-frame
    if (e.isBoss) G.finisher = { x: e.x, z: e.z, t: 0.85 };
    G.hitstop = e.isBoss ? 0.1 : 0.08; flash(0.35); addShake(0.5);
  }
  G.kills++; G.combo++; G.comboT = 2.6; G.comboPop = 1; meteorKill(e);
  G.run.kills++; G.run.bestCombo = Math.max(G.run.bestCombo, G.combo); if (e.isBoss) G.run.bosses++; if (e.name) G.run.champs++;
  corpseDied(e); // Corpse Blast: a fresh corpse (or a chain blast if a Corpse Blast just killed it)
  const pg = player.g;
  if (player.der.quake) { // STR 15: a kill knocks the foes around it back (no damage)
    addRing(e.x, e.z, 0.2, 2.4, 0.25, 0xffd27a);
    for (const o of enemies) { if (o.dead || o === e) continue; const dx = o.x - e.x, dz = o.z - e.z, dl = Math.hypot(dx, dz);
      if (dl < 2.4 + o.r) { const f = 7 * kbMul(o) / (dl || 1); o.kx += dx * f; o.kz += dz * f; } }
  }
  if (e.curse > 0) { // shadow: cursed foes EXPLODE (2.8 tiles) and hurt their friends; cursed friends it kills explode too
    const R = (pg.flags.shroud ? 4 : 2.8) * (player.hero.id === 'necro' ? 1.2 : 1), cd = e.curseDmg;
    addRing(e.x, e.z, 0.3, R, 0.4, 0xa35cff); addRing(e.x, e.z, 0.2, R * 0.6, 0.3, 0xe0c8ff);
    burst(e.x, 0.6, e.z, 0xa35cff, 26, 7, 0.5, 0.55); burst(e.x, 0.6, e.z, 0x2a0a40, 10, 3, 0.7, 0.7); splat(e.x, e.z, 0x1a0a28, R * 0.8, 0.9);
    fxLight.position.set(e.x, 1.2, e.z); fxLight.intensity = 30; addShake(0.15); sfx('boom');
    later(0.05, () => { for (const o of [...enemies]) if (!o.dead && o !== e && Math.hypot(o.x - e.x, o.z - e.z) < R + o.r) hurtEnemyRaw(o, cd, '#c48cff'); });
  }
  if (e.poison > 0 && !e.isBoss) elPatch(e.x, e.z, 1.1, 3, Math.max(2, (e.poisonDps || 6) * 0.3), 'venom', 0x5fff4a); // venom: a toxic puddle that poisons walkers
  if (e.lastEls && e.lastEls.includes('holy')) { // holy: every 10th holy kill heals half a heart (4 per floor at most)
    if (G.holyFloor !== G.floor) { G.holyFloor = G.floor; G.holyHeals = 0; }
    G.holyK = (G.holyK || 0) + 1;
    spark(e.x, 1, e.z, 0xffe9a0, { vy: 3, s: 0.6, life: 0.5, drag: 0 });
    if (G.holyK % 10 === 0 && G.holyHeals < 4 && player.hp < player.maxHp && !G.prologue) {
      G.holyHeals++; player.hp++; renderHearts(); sfx('heal');
      addText(player.x, 1.6, player.z, 'HOLY +HEAL', '#ffe9a0', 1.1); addRing(player.x, player.z, 0.2, 1.3, 0.4, 0xffe9a0); burst(player.x, 1, player.z, 0xffe9a0, 12, 3, 0.35, 0.5);
    }
  }
  if (pg.flags.cinders && e.burn > 0) { const bd = (e.burnDps || 10) * 4; later(0.05, () => explode({ x: e.x, z: e.z, aoe: 1.6, dmg: bd, els: ['fire'], color: 0xff7a1a })); }
  if (pg.flags.lich && G.run.kills % 15 === 0 && player.hp < player.maxHp) { player.hp++; addText(player.x, 1.5, player.z, '+', '#ff6a8a', 1); renderHearts(); }
  if (pg.flags.ouro) for (const sp of spells) sp.t -= 0.1;
  gainXp(e.isBoss ? 60 : e.name ? 15 : e.elite ? 3 : isBigFoe(e) ? 2 : 1); // elites 6 -> 3, champions 25 -> 15 (progression retune)
  const luck = pg.luck + player.der.loot;
  if (e.isBoss && G.prologue) { G.finisher = { x: e.x, z: e.z, t: 0.85 }; G.hitstop = 0.1; flash(0.5); addShake(0.8); $('bossbar').classList.add('hidden'); } // the story keeps the loot
  else if (e.isBoss) { dropGear(e.x, e.z, 2); dropGear(e.x, e.z, 2); bossReward(e); }
  else if (e.name) dropGear(e.x, e.z, 1);
  // gear: 2% from big monsters (elites, big slimes, golems), 0.05% from the rest; luck still helps
  else if (Math.random() < (e.elite || isBigFoe(e) ? 0.02 : 0.0005) * (1 + luck)) dropGear(e.x, e.z, 0);
  const d = e.d, big = e.isBoss ? 4 : e.type === 'big' ? 1.6 : 1;
  splat(e.x, e.z, d.splat, rr(1.0, 1.5) * big);
  for (let k = 0; k < 3 * big; k++) splat(e.x + rr(-0.8, 0.8) * big, e.z + rr(-0.8, 0.8) * big, d.splat, rr(0.3, 0.7));
  chunk(e.x, 0.5, e.z, d.chunk, Math.round(7 * big), 5 * Math.sqrt(big), 0.13);
  burst(e.x, 0.5, e.z, d.chunk, Math.round(14 * big), 5, 0.4, 0.5);
  spark(e.x, 0.6, e.z, 0xffffff, { s: 1.4 * big, life: 0.12, drag: 0 });
  addShake(e.isBoss ? 1 : 0.12 * big);
  if (e.isBoss) G.hitstop = Math.max(G.hitstop, 0.25); // only a boss kill freezes the frame now (ordinary kills stuttered: user 11-15)
  sfx(e.isBoss ? 'slam' : 'kill');
  if (Math.random() < (e.elite ? 1 : d.coin * 0.6)) for (let k = 0; k < (e.isBoss ? 25 : isBigFoe(e) ? 3 : 1) * (e.elite ? 4 : 1) * (G.daily && G.daily.mod.id === 'greed' ? 2 : 1); k++) dropPickup(e.x, e.z, 'coin');
  if (e.gold && !e.isBoss) { for (let k = 0; k < 2; k++) dropPickup(e.x, e.z, 'coin', true); coinSpill(e.x, 0.9, e.z, 6, 2.8, 4.4); burst(e.x, 0.9, e.z, 0xffe680, 10, 5, 0.35, 0.45); addText(e.x, 1.7, e.z, '+GOLD', '#ffd34f', 1.05); sfx('coin', 9); } // finished by Coin Spray: a jackpot pop
  if (player.der.chestLoot && !e.isBoss && Math.random() < 0.2) for (let k = 0; k < 2; k++) dropPickup(e.x, e.z, 'coin'); // LUK 5: coin rain
  if (e.type === 'bomber') enemyBlast(e.x, e.z, 1.9, false);
  // hearts only drop when you're hurt: 5% from big monsters (elites, big slimes, golems), 0.5% from the rest
  if (player.hp < player.maxHp && Math.random() < (e.elite || isBigFoe(e) ? 0.05 : 0.005)) dropPickup(e.x, e.z, 'heart');
  if (e.type === 'big') for (let k = 0; k < 2; k++) { const s = spawnEnemy('slime', e.x + (k ? 0.5 : -0.5), e.z); s.spawn = 1; s.hp *= 0.6; s.state = 'jump'; s.st = 0.4; s.jx = (k ? 1 : -1) * 3; s.jz = 0; }
  if (e.isBoss) { flash(0.6); $('bossbar').classList.add('hidden'); }
  if (e.name) {
    $('bossbar').classList.add('hidden'); $('bossname').textContent = 'KING GLOOP';
    const r = rooms.find((q) => q.active); if (r) r.champDrop = true;
    for (let k = 0; k < 12; k++) dropPickup(e.x, e.z, 'coin');
    dropPickup(e.x, e.z, 'heart'); toast(e.name.toUpperCase(), 'has fallen');
  }
  const gh = makeSprite(e.d.sheet || e.type, e.mesh.userData.bh);
  gh.material.transparent = true; gh.material.uniforms.uFlash.value = 1; gh.material.uniforms.uFlip.value = e.face < 0 ? 1 : 0;
  gh.position.copy(e.mesh.position); gh.quaternion.copy(camera.quaternion);
  texts.push({ ghost: gh, life: 0.16, max: 0.16, grow: true });
  killMesh(e.mesh); scene.remove(e.shadow); dropPart(e); freeFoeFx(e);
}
function enemyShoot(e, ang, speed = 5, color = 0xb05cff, size = 0.9, homing = 0, kind = 'orb') {
  const p = { x: e.x + Math.cos(ang) * 0.4, z: e.z + Math.sin(ang) * 0.4, vx: Math.cos(ang) * speed, vz: Math.sin(ang) * speed, r: 0.22, life: 6, color, glow: makeGlow(color, size * 0.8, 0.8), homing };
  p.mesh = makeProjMesh(kind, color); p.shadow = makeShadow(0.45); p.kind = kind; placeProj(p, 0.55, 0);
  eprojs.push(p);
  return p;
}

function updateEnemy(e, dt) {
  const d = e.d;
  e.spawn = Math.min(1, e.spawn + dt * 2.2);
  e.flash = Math.max(0, e.flash - dt * 7);
  e.squash = Math.max(0, (e.squash || 0) - dt * 2.5);
  if (e.poison > 0) { e.poison -= dt; e.poisonTick = (e.poisonTick || 0) - dt; if (e.poisonTick <= 0) { e.poisonTick = 0.5; hurtEnemyRaw(e, e.poisonDps * 0.5, '#7dff6a'); spark(e.x, 0.7, e.z, 0x7dff6a, { vy: 1.5, s: 0.35, life: 0.6 }); } if (e.poison <= 0) { e.pstacks = 0; e.poisonDps = 0; } }
  if (e.burn > 0) { e.burn -= dt; e.burnTick = (e.burnTick || 0) - dt; if (e.burnTick <= 0) { e.burnTick = 0.5; hurtEnemyRaw(e, e.burnDps * 0.5, '#ff9a4a'); spark(e.x, 0.8, e.z, 0xff7a1a, { vy: 2, s: 0.35, life: 0.4 }); } if (e.burn <= 0) e.burnDps = 0; }
  if (e.shock > 0) { e.shock -= dt; if (fxP(0.12)) spark(e.x + rr(-0.3, 0.3), 0.5 + Math.random() * 0.6, e.z, 0xfff36a, { s: 0.25, life: 0.1, drag: 0 }); }
  if (e.curse > 0) { e.curse -= dt; if (fxP(0.08)) spark(e.x, 1.1, e.z, 0xa35cff, { vy: 0.6, s: 0.3, life: 0.5 }); }
  if (e.dead) return;
  let sm = e.slow > 0 ? 1 - (e.slowAmt || 0.5) : 1;
  if (e.slow <= 0) e.slowAmt = 0;
  e.slow -= dt;
  if (e.freeze > 0 || e.stun > 0) { e.freeze -= dt; e.stun -= dt; sm = 0; }
  if (e.hs > 0) e.hs = 0; // no per-foe freeze frames either (user 11-15: no freeze on hits)
  if (e.ice && !(e.freeze > 0)) e.ice = false; // thawed without being shattered
  const edt = dt * sm;
  e.t += edt; e.st -= edt;
  const dx = player.x - e.x, dz = player.z - e.z, dist = Math.hypot(dx, dz) || 1, ux = dx / dist, uz = dz / dist;
  let mx = 0, mz = 0, sx = 1, sy = 1, tilt = 0;
  e.noContact = false;
  if (e.dummy) { e.noContact = true; e.y = 0; } else // ?spells training dummy: no AI, no attacks, never walks (spvUpdate springs it home)
  switch (e.type) {
    case 'slime': case 'big': case 'mimic': {
      if (e.sleep) { // the Mimic Lord's decoys: a plain chest until you come close, then a shake (the tell) and a bite
        e.y = 0; e.noContact = true;
        if (e.wake > 0) {
          e.wake -= dt; e.shake = 0.07; e.tint = 1 - e.wake / 0.65;
          if (e.wake <= 0) { e.sleep = false; e.noContact = false; e.tint = 0; e.state = 'wait'; e.st = 0; killMesh(e.mesh); e.mesh = makeSprite('mimic', SPRITE_H.mimic * 0.8); burst(e.x, 0.6, e.z, 0xffd34f, 10, 3, 0.35, 0.4); sfx('spit'); }
        } else if (dist < 1.8 || e.flash > 0.5) { e.wake = 0.65; sfx('lock'); addText(e.x, 1.3, e.z, '!', '#ffd34f', 1.3); }
        break;
      }
      // hoppers (audit #1/#2/#9): no contact damage. Each hop: a squash wind-up with a ring at the landing spot (it fills, then
      // locks), the hop, and a landing that hurts only inside that ring (splat, hit-stop). Slimes are green jelly now (not Pip pink)
      e.noContact = true;
      const big = e.type === 'big', mim = e.type === 'mimic', RR = big ? 1.1 : mim ? 0.75 : 0.6, WT = big ? 0.5 : mim ? 0.3 : 0.35;
      if (e.state === 'idle' || e.state === 'wait') {
        const k = 1 - clamp(e.st / 0.5, 0, 1); sx = 1 + 0.12 * k + Math.sin(e.t * 9) * 0.03; sy = 1 - 0.12 * k - Math.sin(e.t * 9) * 0.03; e.y = 0;
        if (e.st <= 0) {
          freeFoeFx(e); e.state = 'crouch'; e.st = WT; e.tg = teleGet('ring', mim ? 0xffb030 : 0x5aff9a);
          const lead = 0.25; let jx = dx + player.vx * lead, jz = dz + player.vz * lead; const jl = Math.hypot(jx, jz), mxs = (big ? 2.6 : mim ? 5 : 3.2) * 0.5; if (jl > mxs) { jx *= mxs / jl; jz *= mxs / jl; }
          e.tx = e.x + jx; e.tz = e.z + jz; if (solid(e.tx, e.tz, false)) { e.tx = e.x + jx * 0.5; e.tz = e.z + jz * 0.5; }
          e.away = mim && !e.mini && e.jumps % 3 === 2 && dist < 4.2; // the coin ring comes on the next landing: it hops AWAY first (spacing)
          if (e.away) { const sd = rand() < 0.5 ? 1 : -1; for (let q = 0; q < 3; q++) { const ax = -ux * (q ? 0.5 : 1) - uz * sd * (q ? 0.85 : 0), az = -uz * (q ? 0.5 : 1) + ux * sd * (q ? 0.85 : 0), l = q === 2 ? 1.2 : 2.3; e.tx = e.x + ax * l; e.tz = e.z + az * l; if (!solid(e.tx, e.tz, false)) break; } if (solid(e.tx, e.tz, false)) { e.tx = e.x; e.tz = e.z; } }
        }
      } else if (e.state === 'crouch') { // squash down, the landing ring fills (tracks you for the first half, then locks)
        const k = 1 - e.st / WT; sx = 1 + 0.32 * k; sy = 1 - 0.32 * k; e.y = 0; e.shake = 0.015 + 0.02 * k; e.tint = k * 0.35;
        if (k < 0.5 && !e.away) { let jx = dx + player.vx * 0.2, jz = dz + player.vz * 0.2; const jl = Math.hypot(jx, jz), mxs = (big ? 2.6 : mim ? 5 : 3.2) * 0.5; if (jl > mxs) { jx *= mxs / jl; jz *= mxs / jl; } if (!solid(e.x + jx, e.z + jz, false)) { e.tx = e.x + jx; e.tz = e.z + jz; } }
        teleSet(e.tg, e.tx, e.tz, 0, RR, 0, k);
        if (e.st <= 0) { teleFree(e); e.tint = 0; e.state = 'jump'; e.st = 0.5; e.jx = (e.tx - e.x) / 0.5; e.jz = (e.tz - e.z) / 0.5; sfx(mim ? 'skitter' : 'spit'); }
      } else if (e.state === 'lid') { // the mimic's coin ring tell: the lid flaps, a gold ring grows round it, then the coins fly
        const k = 1 - e.st / 0.4; sx = 1 + 0.06 * Math.sin(e.t * 50); sy = 1 + 0.18 * Math.abs(Math.sin(e.t * 26)); e.tint = 0.6 * k; e.shake = 0.03;
        teleSet(e.tg, e.x, e.z, 0, 0.9 + 0.25 * k, 0, k);
        if (fxP(0.5)) spark(e.x + rr(-0.3, 0.3), 0.8, e.z, 0xffe680, { vy: 2.5, s: 0.35, life: 0.3, drag: 1 });
        if (e.st <= 0) {
          teleFree(e); e.tint = 0; e.state = 'wait'; e.st = rr(0.5, 0.8); addShake(0.2); sfx('coin'); e.squash = 0.6;
          for (let k2 = 0; k2 < 10; k2++) { const a = k2 / 10 * Math.PI * 2, cx = e.x + Math.cos(a) * 0.6, cz = e.z + Math.sin(a) * 0.6; if (Math.hypot(player.x - cx, player.z - cz) < player.r + 0.45) continue; const p = enemyShoot(e, a, 4.2, 0xffd34f, 0.6, 0, 'coin'); p.x = cx; p.z = cz; } // starts outside Pip
        }
      } else {
        const p = 1 - e.st / 0.5; e.y = Math.sin(p * Math.PI) * (big ? 0.7 : 0.55);
        sx = p < 0.5 ? 0.78 : 0.9; sy = p < 0.5 ? 1.3 : 1.12; tilt = -Math.sign(e.jx || 1) * 0.15 * Math.sin(p * Math.PI); mx = e.jx; mz = e.jz;
        if (e.st <= 0) { // landing: the ring is the truth
          e.state = 'wait'; e.st = mim ? rr(0.3, 0.5) : rr(0.45, 0.9); e.y = 0; e.squash = big ? 0.8 : 0.6;
          const hit = inMark(e.mk); if (hit) { damagePlayer(1, e.x, e.z); e.flash = 0.8; } e.hs = hit ? 0.07 : 0.04;
          addRing(e.x, e.z, 0.2, RR * 1.5, 0.3, mim ? 0xffd34f : 0x7affb0); chunkDust(e.x, e.z, d.chunk);
          if (!mim) { splat(e.x + rr(-0.2, 0.2), e.z + rr(-0.2, 0.2), d.splat, RR * 1.6, 0.7); for (let q = 0; q < 6; q++) { const a = q / 6 * 6.28 + rr(-0.3, 0.3); spark(e.x, 0.25, e.z, d.chunk, { vx: Math.cos(a) * 3.2, vz: Math.sin(a) * 3.2, vy: rr(2, 3.5), grav: -14, s: 0.3, life: 0.45, drag: 1 }); } sfx('splat'); } // a wet splat + droplets
          if (big) { addShake(0.18); sfx('land'); addCrack(e.x, e.z, 1.2, 0); }
          if (mim) { sfx('clink'); if (!e.mini && ++e.jumps % 3 === 0) { e.state = 'lid'; e.st = 0.4; e.tg = teleGet('ring', 0xffd34f); sfx('lock'); } }
        }
      }
      break;
    }
    case 'eye': {
      e.y = 0.55 + Math.sin(e.t * 3) * 0.12;
      const flap = Math.sin(e.t * 16); sx = 1 + flap * 0.12; sy = 1 - flap * 0.06; tilt = Math.sin(e.t * 2.3) * 0.12;
      keepBand(e, dist, ux, uz); mx = e.bmx; mz = e.bmz; // circles at range, backs off when Pip comes at it
      if (e.state === 'idle' && e.st <= 0 && dist < 9) { e.state = 'charge'; e.st = 0.6; sfx('spit'); }
      if (e.state === 'charge') {
        mx *= 0.2; mz *= 0.2;
        e.chargeK = 1 - e.st / 0.6; sx = 1 + e.chargeK * 0.25; sy = 1 + e.chargeK * 0.25; tilt = 0;
        if (fxP(0.5)) spark(e.x + ux * 0.35, e.y + 0.45, e.z + uz * 0.35, 0xb05cff, { s: 0.3 + e.chargeK * 0.4, life: 0.15, drag: 0 });
        if (e.st <= 0) {
          const a = Math.atan2(dz, dx);
          const n = G.floor >= 4 ? 3 : 1;
          for (let k = 0; k < n; k++) enemyShoot(e, a + (k - (n - 1) / 2) * 0.28, 4.6 + G.floor * 0.15, 0xb05cff, 0.8, 0, 'tear');
          e.state = 'idle'; e.st = rr(1.8, 2.8); e.squash = 0.4; e.chargeK = 0;
        }
      }
      break;
    }
    case 'imp': { // (user 11-14: "too fast and not stopping"): stalk and pause. It drifts in, stops and hovers low (smoke curls off
      // it, the eyes glow), and from that stop comes the telegraphed lunge: a 0.4 s crouch with a raised claw while a lane fills (then
      // locks); the lunge rakes down it. A pause to recover after each lunge. No constant zig-zag
      e.noContact = true; // only the marked lunge hurts
      if (e.state === 'idle') {
        e.faceLock = 0;
        if ((e.bt = (e.bt ?? rr(0.2, 0.6)) - edt) <= 0) {
          e.go = !e.go;
          if (e.go) { e.bt = rr(0.6, 1.1); const a = Math.atan2(uz, ux) + rr(-0.45, 0.45) + (dist < 1.6 ? Math.PI * 0.5 * (rand() < 0.5 ? 1 : -1) : 0); e.jx = Math.cos(a); e.jz = Math.sin(a); }
          else e.bt = rr(0.5, 1);
        }
        if (e.go) { // the drift: a smooth glide with a slow bob
          mx = e.jx * e.speed; mz = e.jz * e.speed; tilt = Math.sin(e.t * 7) * 0.1 + e.jx * 0.12; e.y = 0.08 + Math.sin(e.t * 7) * 0.05;
        } else { // the stop: hovers low, smoke curls, eyes glow; it watches Pip
          e.faceLock = dx > 0 ? 1 : -1; tilt = Math.sin(e.t * 3) * 0.05; e.y = 0.03 + Math.sin(e.t * 4) * 0.025; sx = 1 + 0.04 * Math.sin(e.t * 4); sy = 0.95;
          if (fxP(0.12)) spark(e.x + rr(-0.2, 0.2), 0.35, e.z + rr(-0.15, 0.15), 0x3a1a44, { vy: rr(0.6, 1.2), vx: rr(-0.4, 0.4), s: 0.45, life: 0.7, drag: 1 }); // smoke curls
          if (fxP(0.3)) spark(e.x + e.faceLock * 0.08, 0.5, e.z, 0xff3a2a, { s: 0.22, life: 0.06, drag: 0 }); // eyes glow
          if (dist < 2.8 && e.st <= 0 && e.bt < 0.6) { freeFoeFx(e); e.state = 'wind'; e.st = 0.4; e.lx = ux; e.lz = uz; e.tg = teleGet('lane', 0xff5a3a); }
        }
      } else if (e.state === 'wind') {
        const k = 1 - e.st / 0.4; if (k < 0.6) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
        sx = 1 + 0.2 * k; sy = 1 - 0.22 * k; tilt = -e.faceLock * 0.3 * k; e.y = 0; e.shake = 0.02 + 0.04 * k; e.tint = k;
        if (fxP(0.6)) spark(e.x + e.faceLock * 0.08, 0.55, e.z, 0xff3a2a, { s: 0.35 + 0.3 * k, life: 0.06, drag: 0 }); // the eyes burn red
        teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.r + 2.4, 0.6, k);
        if (e.st <= 0) { teleFree(e); e.tint = 0; e.state = 'lunge'; e.st = 0.22; e.hitDone = false; sfx('whoosh'); clawSmear(e, Math.atan2(e.lz, e.lx), 0xc070ff); }
      } else if (e.state === 'lunge') {
        mx = e.lx * 11; mz = e.lz * 11; sx = 1.35; sy = 0.75; tilt = e.faceLock * 0.45;
        if (fxP(0.8)) spark(e.x, 0.4, e.z, 0x9a4aaa, { s: 0.4, life: 0.3 });
        if (!e.hitDone && e.st < 0.12) { // mid-lunge: the claws rake; the lane is the truth
          e.hitDone = true; const hit = inMark(e.mk); if (hit) { damagePlayer(1, e.x, e.z); e.flash = 0.8; slashImpact(player.x, player.z, 0xc070ff, false); } e.hs = hit ? 0.06 : 0.03;
        }
        if (e.st <= 0) { e.state = 'rest'; e.st = rr(0.6, 0.9); }
      } else if (e.state === 'rest') { // recovery: hunched, panting, then back to stalking
        sx = 1 + 0.06 * Math.sin(e.t * 14); sy = 0.92 - 0.04 * Math.sin(e.t * 14); e.y = 0; tilt = e.faceLock * 0.1;
        if (e.st <= 0) { e.state = 'idle'; e.st = rr(0.9, 1.4); e.go = true; e.bt = rr(0.5, 0.9); const a = Math.atan2(uz, ux) + rr(-0.6, 0.6); e.jx = Math.cos(a); e.jz = Math.sin(a); e.faceLock = 0; }
      } else e.state = 'idle';
      break;
    }
    case 'skeleton': case 'cursed': case 'reaper': case 'boneknight': case 'golem': case 'runegolem': case 'crystalgolem': case 'magmagolem':
    case 'archer': case 'spider': case 'salamander': case 'shieldk': case 'cultist': case 'beetle':
      e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.tilt = 0;
      (e.type === 'reaper' ? updateReaper : SKELS.has(e.type) ? updateSkelFam : GOLEMS.has(e.type) ? updateGolemFam : FOE_UPD[e.type])(e, edt, dx, dz, dist, ux, uz);
      if (!(e.state === 'charge' || e.state === 'roll' || e.state === 'leap')) { // standoff: no step toward Pip inside body r + Pip r + gap
        const S = e.r + player.r + STAND_GAP, tow = e.mx * ux + e.mz * uz;
        if (tow > 0 && dist < S + 0.6) { const allow = Math.max(0, dist - S) * 6; if (tow > allow) { e.mx -= ux * (tow - allow); e.mz -= uz * (tow - allow); } }
      }
      sx = e.sx; sy = e.sy; mx = e.mx; mz = e.mz; tilt = e.tilt; break;
    case 'bomber': {
      if (e.state === 'idle') {
        const wob = Math.sin(e.t * 8 + e.anim) * 0.5;
        mx = (ux - uz * wob) * e.speed; mz = (uz + ux * wob) * e.speed;
        tilt = Math.sin(e.t * 16) * 0.2; e.y = Math.abs(Math.sin(e.t * 16)) * 0.1;
        if (dist < 1.7) { e.state = 'fuse'; e.st = 0.75; e.ring = addMarker(e.x, e.z, 1.9, 0xff6a20); sfx('spit'); }
      } else {
        const k = 1 - e.st / 0.75;
        sx = sy = 1 + k * 0.45 + Math.sin(e.t * 50) * 0.06; e.chargeK = k; e.y = 0;
        mx = ux * 0.6; mz = uz * 0.6;
        if (e.ring) { e.ring.position.set(e.x, 0.05, e.z); e.ring.material.opacity = 0.3 + k * 0.6; }
        if (fxP(0.6)) spark(e.x, 0.75, e.z, 0xffd34f, { vy: 2, s: 0.25, life: 0.3, spread: 1 });
        if (e.st <= 0) { enemyBlast(e.x, e.z, 1.9, true); e.hp = 0; killEnemy(e); }
      }
      break;
    }
    case 'ghost': {
      // (user 11-14: "bugged, goes near you for nothing"): it ONLY comes close by a teleport, and every teleport ends in its scream.
      // Between attacks it floats at a distance (spacing band, slow drift, never toward Pip). Cycle: drift -> fade -> blink in at
      // scream range (2.5-2.9 tiles, not on top of Pip) -> WAIL at once (stretches tall, the cone fills) -> SCREAM down the cone (the
      // cone is the hit) -> fade out -> reappear far off -> drift. No body-contact damage
      e.y = 0.35 + Math.sin(e.t * 2.5) * 0.12; tilt = Math.sin(e.t * 1.7) * 0.15; e.noContact = true;
      if (e.state === 'wail') {
        const k = 1 - e.st / 0.5; if (k < 0.6) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1; e.alpha = 0.92; e.hidden = false;
        sx = 1 - 0.18 * k; sy = 1 + 0.38 * k; tilt = 0; e.shake = 0.02 * k; e.tint = k * 0.5;
        if (fxP(0.4)) spark(e.x + e.lx * 0.3, 0.75, e.z + e.lz * 0.3, 0xdff8ff, { vx: -e.lx * 1.5, vz: -e.lz * 1.5, s: 0.3, life: 0.2, drag: 0 }); // breath drawn in
        teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), GHOST_CONE, 0, k);
        if (e.st <= 0) { // SCREAM
          teleFree(e); e.tint = 0; e.state = 'scream'; e.st = 0.3; sfx('scream');
          const hit = inMark(e.mk); if (hit) { damagePlayer(1, e.x, e.z); e.hs = 0.06; }
          for (let q = 0; q < 3; q++) later(q * 0.06, () => { if (!e.dead) addRing(e.x + e.lx * (0.7 + q * 0.75), e.z + e.lz * (0.7 + q * 0.75), 0.2, 0.8 + q * 0.45, 0.25, 0xdff8ff); }); // ripples down the cone
          for (let q = 0; q < 10; q++) { const a = Math.atan2(e.lz, e.lx) + rr(-0.8, 0.8), s = rr(5, 8); spark(e.x, 0.6, e.z, q % 3 ? 0xbff3ff : 0xffffff, { vx: Math.cos(a) * s, vz: Math.sin(a) * s, vy: rr(-0.5, 0.5), s: 0.35, life: 0.3, drag: 3 }); }
        }
        break;
      }
      if (e.state === 'scream') { sx = 1.15 + 0.05 * Math.sin(e.t * 60); sy = 1.1; e.alpha = 0.92; if (e.st <= 0) { e.state = 'fade'; e.st = 0.35; e.next = 'far'; e.faceLock = 0; } break; }
      if (e.state === 'idle') { // floats at a distance, drifting slowly; never walks up to Pip
        keepBand(e, dist, ux, uz, e.d.band, e.speed * 0.45); mx = e.bmx; mz = e.bmz; e.alpha = 0.85; e.hidden = false;
        if (e.st <= 0) { e.state = 'fade'; e.st = 0.4; e.next = 'atk'; }
      } else if (e.state === 'fade') {
        e.alpha = 0.85 * Math.max(0, e.st) / 0.4; e.hidden = e.alpha < 0.3;
        if (e.st <= 0) { e.state = 'gone'; e.st = e.next === 'atk' ? 0.55 : 0.4; e.hidden = true; }
      } else if (e.state === 'gone') {
        e.alpha = 0; e.hidden = true;
        if (e.st <= 0) {
          const room = rooms.find((q) => q.active) || G.curRoom, atk = e.next === 'atk';
          for (let tries = 0; tries < 16; tries++) {
            const a = rand() * Math.PI * 2, d = atk ? rr(2.5, 2.9) : rr(4.6, 6), nx = player.x + Math.cos(a) * d, nz = player.z + Math.sin(a) * d;
            if (!solid(nx, nz, true) && (!room || roomAt(nx, nz) === room)) { e.x = nx; e.z = nz; break; }
          }
          e.state = 'appear'; e.st = atk ? 0.3 : 0.45; burst(e.x, 0.6, e.z, 0xbff3ff, 12, 2.5, 0.35, 0.45); addRing(e.x, e.z, 0.2, 1.1, 0.35, 0xffffff); // blink-in: a white ring + wisps
        }
      } else if (e.state === 'appear') {
        e.alpha = 0.85 * (1 - Math.max(0, e.st) / 0.45); e.hidden = e.alpha < 0.3;
        if (e.st <= 0) {
          e.hidden = false; e.alpha = 0.85;
          if (e.next === 'atk') { freeFoeFx(e); e.state = 'wail'; e.st = 0.5; e.lx = ux; e.lz = uz; e.tg = teleGet('sector', 0xbff3ff); } // every blink-in ends in the scream
          else { e.state = 'idle'; e.st = rr(1.4, 2.2); }
        }
      } else { e.state = 'idle'; e.st = 1; }
      break;
    }
    case 'shroom': {
      sx = 1 + Math.sin(e.t * 3) * 0.04; sy = 1 - Math.sin(e.t * 3) * 0.04;
      e.face = dx > 0 ? 1 : -1;
      if (e.state === 'idle') { keepBand(e, dist, ux, uz); mx = e.bmx; mz = e.bmz; const wk = Math.min(1, Math.hypot(mx, mz)); e.y = Math.abs(Math.sin(e.t * 10)) * 0.07 * wk; tilt = Math.sin(e.t * 10) * 0.08 * wk; } // little hops back
      if (e.state === 'idle' && e.st <= 0 && dist < 10) { e.state = 'charge'; e.st = 0.55; e.y = 0; }
      if (e.state === 'charge') {
        const k = 1 - e.st / 0.55; e.chargeK = k; sx = 1 + k * 0.3; sy = 1 - k * 0.2;
        if (e.st <= 0) {
          const a = Math.atan2(dz, dx), n = G.floor >= 5 ? 7 : 5;
          for (let k2 = 0; k2 < n; k2++) { const p = enemyShoot(e, a + (k2 - (n - 1) / 2) * 0.24, 4.2, k2 % 2 ? 0xa070ff : 0x8add4a, 0.8, 0, 'spore'); p.slowTo = 0.6; } // spore puffs that drift and slow
          e.state = 'idle'; e.st = rr(2.2, 3); e.squash = 0.7; e.chargeK = 0; sfx('spit');
          burst(e.x, 0.6, e.z, 0xc070ff, 8, 2, 0.3, 0.4);
        }
      }
      break;
    }
    case 'boss': case 'eyeboss': case 'golemboss': case 'tyrant': case 'sporeboss': case 'wraithboss': case 'mimiclord': case 'frostboss': case 'sentinel':
      ({ boss: updateBoss, eyeboss: updateEyeBoss, golemboss: G.prologue ? updateProKing : updateStoneKing, tyrant: updateTyrant, sporeboss: updateSpore, wraithboss: updateWraith,
        mimiclord: updateMimicLord, frostboss: updateFrost, sentinel: updateSentinel })[e.type](e, edt, dx, dz, dist);
      if (e.tg) e.tg.str = 1.35; // boss telegraphs read a little stronger than a regular foe's
      sx = e.sx; sy = e.sy; mx = e.mx; mz = e.mz; tilt = e.tilt || 0; break;
  }
  // separation
  for (const o of enemies) {
    if (o === e || o.dead) continue;
    const ox = e.x - o.x, oz = e.z - o.z, min = e.r + o.r;
    if (ox > min || ox < -min || oz > min || oz < -min) continue; /* n² pairs: cheap box reject before the sqrt */
    const od = Math.sqrt(ox * ox + oz * oz);
    if (od < min && od > 0.001) { const push = (min - od) * 4; mx += ox / od * push; mz += oz / od * push; }
  }
  const sp = e.spawn < 1 ? 0 : 1;
  e.kx *= Math.exp(-8 * dt); e.kz *= Math.exp(-8 * dt);
  e.wallHit = false;
  moveCircle(e, (mx * sp + e.kx) * edt + e.kx * (dt - edt), (mz * sp + e.kz) * edt + e.kz * (dt - edt), e.r, !!d.fly); // hops don't clear pillars: slimes go around them
  if (!d.fly) unstick(e);
  // body block: a foe on the ground never walks into Pip's body (a charge stops at the collider instead of passing through)
  // (bosses are too heavy to shove: Pip is the one moved out of them, e.g. after King Gloop lands on him)
  const heavy = e.isBoss;
  if ((!e.isBoss || heavy) && !d.fly && !e.hidden && e.y < 0.35 && e.spawn >= 1 && player.alive) {
    const bx = e.x - player.x, bz = e.z - player.z, bd = Math.hypot(bx, bz), mn = e.r + player.r;
    if (bd < mn) {
      const k = bd > 1e-3 ? (mn - bd) / bd : 0, ox = bd > 1e-3 ? bx * k : mn, oz = bd > 1e-3 ? bz * k : 0;
      if (heavy) moveCircle(player, -ox, -oz, player.r, false); else moveCircle(e, ox, oz, e.r, false);
    }
  }
  if (e.faceLock) e.face = e.faceLock; else if (Math.abs(mx) > 0.1) e.face = mx > 0 ? 1 : -1; // faceLock: an attack keeps facing its target
  // contact damage: only foes built to ram (slimes, imps, bombers, ghosts, bosses...). The telegraphed melee families hurt only
  // through their marked blows; a golem's charge and a beetle's roll still hit on contact (their lane is the marker)
  if (!e.noContact && e.spawn >= 1 && dist < e.r + player.r + 0.05 && touchHurts(e)) {
    damagePlayer(e.isBoss || (isGolem(e) && e.state === 'charge') ? 2 : 1, e.x, e.z);
    if (isGolem(e) && e.state === 'charge') { e.state = 'stun'; e.st = 0.9; e.slamT = 0; e.squash = 0.5; e.wGlow = 0; e.pcd = 1; addShake(0.25); sfx('thud'); chunkDust(e.x + e.lx * e.r, e.z + e.lz * e.r, GOLEM_ATK[e.type].dust); } // rams Pip, then stops
    else if (e.type === 'golemboss' && e.state === 'charge') e.rammed = true; // ends this charge (updateStoneKing)
    else if (e.type === 'beetle' && e.state === 'roll') { e.st = 0; e.squash = 0.5; sfx('clink'); } // stops at Pip (then lies dizzy)
  }
  // render
  const m = e.mesh, u = m.material.uniforms;
  const pop = e.spawn < 1 ? 1 - Math.pow(1 - e.spawn, 3) * 1.0 + Math.sin(e.spawn * Math.PI) * 0.25 : 1;
  const sq = e.squash || 0;
  // sucked toward a Void Maw (user 11-15): thinner + taller (stretched into the pull), smaller the closer it gets, leaning at the hole
  const vk = e.voidK || 0; let vtilt = 0;
  { const tgt = e.voidTgt || 0; e.voidTgt = 0; e.voidK = vk + (tgt - vk) * Math.min(1, dt * (tgt > vk ? 2.2 : 3)); } // eases in / out (user: not an instant snap)
  if (vk > 0.001) vtilt = clamp((e.voidX - e.x), -1, 1) * 0.6 * vk;
  setSpriteScale(m, sx * pop * (1 + sq * 0.35) * (1 - 0.45 * vk), sy * pop * (1 - sq * 0.3) * (1 + 0.35 * vk - 0.35 * vk * vk));
  const jit = e.shake ? (Math.random() - 0.5) * e.shake * 2 : 0; e.shake = 0;
  m.position.set(e.x + jit, e.y + (e.liftT !== undefined ? liftY(e, dt) : 0) - (e.spawn < 1 && e.type !== 'boss' ? (1 - e.spawn) * 0.8 : 0), e.z);
  u.uBias.value = e.spawn < 1 || e.sunk ? 0 : 1.1; // rising out of (or sinking into) the floor: let the floor hide the part below it
  billboard(m, tilt * (e.face < 0 ? -1 : 1) * -1 - vtilt);
  if (e.rollSpin) { const th = tilt * (e.face < 0 ? -1 : 1) * -1, hc = m.scale.y * 0.5; _pw.set(Math.sin(th) * hc, hc - Math.cos(th) * hc, 0).applyQuaternion(camera.quaternion); m.position.add(_pw); } // a rolling golem turns about its middle, not its feet
  u.uFlip.value = e.face < 0 ? 1 : 0;
  if (e.alpha !== undefined) { m.material.transparent = true; u.uAlpha.value = e.alpha; e.shadow.visible = e.alpha > 0.2; }
  const tell = d.tellCol && e.tint > 0 ? e.tint : 0; // a per-enemy tell colour (ENEMY.tellCol) glows instead of reddening
  u.uFlash.value = Math.max(e.flash, (e.chargeK || 0) * 0.6 * (Math.sin(e.t * 40) > 0 ? 1 : 0.3), tell * 0.55);
  u.uFlashCol.value.set(e.flash > 0.01 ? 0xffffff : tell ? d.tellCol : 0xc070ff);
  if (e.freeze > 0) { u.uTint.value.set(e.ice || e.gustIce ? 0x8fd8ff : 0x9fe8ff); if (e.ice && fxP(0.25)) spark(e.x + rr(-0.3, 0.3), 0.3 + Math.random() * 0.8, e.z, 0xe8fbff, { s: 0.3, life: 0.25, drag: 0 }); } // ice: ready to shatter
  else if (e.stun > 0.05) { // stunned (earth): greyed out, dazed stars circle the head
    u.uTint.value.set(0xa8a49c);
    if (fxP(0.5)) { const sa = G.time * 9 + (e.x * 3 % 6.28), th = m.userData.bh + 0.1, hy = e.y + Math.cos(PITCH) * th; spark(e.x + Math.cos(sa) * 0.32, hy, e.z - Math.sin(PITCH) * th + Math.sin(sa) * 0.2, 0xfff2a0, { s: 0.28, life: 0.12, drag: 0 }); }
  } else if (tell) u.uTint.value.setRGB(1 - tell * 0.25, 1 - tell * 0.08, 1);
  else if (e.tint) u.uTint.value.setRGB(1, 1 - e.tint * 0.6, 1 - e.tint * 0.6);
  else if (e.slow > 0) { const c = Math.min(2, e.chill || 0); u.uTint.value.setRGB(0.62 - c * 0.12, 0.84 - c * 0.06, 1); if (fxP(0.06)) spark(e.x, 0.9, e.z, 0xbff4ff, { vy: -0.5, s: 0.22, life: 0.4, drag: 0 }); } // chilled: bluer with each stack
  else if (e.poison > 0) u.uTint.value.set(0xc8ffb8);
  else if (e.burn > 0) u.uTint.value.set(0xffc8a0);
  else if (e.curse > 0) u.uTint.value.set(0xd8b8ff);
  else u.uTint.value.set(e.elite ? 0xffd870 : 0xffffff);
  if (G.dark && fxP(0.25)) spark(e.x + e.face * 0.08, e.y + m.userData.bh * 0.72, e.z, 0xff2030, { s: 0.16, life: 0.15, drag: 0 });
  if (e.elite && fxP(0.15)) spark(e.x + rr(-0.3, 0.3), 0.3 + Math.random() * 0.6, e.z + rr(-0.3, 0.3), e.affColor || 0xffd34f, { vy: 1.2, s: 0.25, life: 0.5, drag: 0 });
  if (e.wpn) placePart(e, sx * pop * (1 + sq * 0.35), sy * pop * (1 - sq * 0.3));
  if (e.name || e.isBoss) $('bossfill').style.transform = `scaleX(${Math.max(0, e.hp / e.maxHp)})`;
  e.shadow.position.set(e.x, 0.04, e.z);
  if (e.type === 'sporeboss') e.shadow.visible = !e.hidden;
  const ss = (e.name ? 1.3 : 1) * d.r * 2.3 * (1 - Math.min(0.5, Math.max(0, e.y) * 0.25)) * pop;
  e.shadow.scale.set(ss, 1, ss * 0.8);
}
const markerGeo = flatRingGeo;
function addMarker(x, z, r, color) {
  const m = new THREE.Mesh(markerGeo, new THREE.MeshBasicMaterial({ map: markTex, color, transparent: true, opacity: 0.32, depthWrite: false, blending: THREE.AdditiveBlending, ...DECAL }));
  m.position.set(x, 0.05, z); m.scale.setScalar(r); scene.add(m); return m;
}
function killMarker(e) { if (e.ring) { scene.remove(e.ring); e.ring.material.dispose(); e.ring = null; } }
// bomber explosion: always hurts other enemies (chain reactions), hurts the player only if the fuse ran out
function enemyBlast(x, z, r, hitsPlayer) {
  addRing(x, z, 0.3, r, 0.3, 0xff8a2a);
  burst(x, 0.5, z, 0xff8a2a, 26, 7, 0.55, 0.45); burst(x, 0.5, z, 0xffe08a, 10, 4, 0.45, 0.3);
  splat(x, z, 0x1a1210, r * 1.2);
  fxLight.position.set(x, 1.2, z); fxLight.intensity = 40;
  addShake(0.35); sfx('boom');
  for (const o of [...enemies]) if (!o.dead && o.type !== 'bomber' && Math.hypot(o.x - x, o.z - z) < r + o.r) hurtEnemy(o, 25, o.x - x, o.z - z, 6, 0xff8a2a);
  for (const o of enemies) if (!o.dead && o.type === 'bomber' && o.state === 'idle' && Math.hypot(o.x - x, o.z - z) < r) { o.state = 'fuse'; o.st = 0.15; }
  for (const pot of [...pots]) if (Math.hypot(pot.x - x, pot.z - z) < r) breakPot(pot);
  if (hitsPlayer && Math.hypot(player.x - x, player.z - z) < r + player.r) damagePlayer(1, x, z);
}
function hurtEnemyRaw(e, dmg, color) {
  if (e.dead) return;
  e.hp -= dmg; e.flash = Math.max(e.flash, 0.4);
  dmgText(e, 1.1, dmg, color, 0.8);
  if (e.hp <= 0) killEnemy(e);
}
function chunkDust(x, z, color) { for (let k = 0; k < 5; k++) spark(x + rr(-0.3, 0.3), 0.08, z + rr(-0.3, 0.3), color, { vx: rr(-1.5, 1.5), vz: rr(-1.5, 1.5), vy: 0.6, s: 0.25, life: 0.35 }); }

// ---------- monster attacks: swinging weapon parts, smears, telegraphs, impacts (all pooled) ----------
// Every attack reads: wind-up (the weapon pulls back and glows, a ground telegraph fills up and stops tracking for the last
// part of it, so it can be dodged), a fast swing with a crescent smear, a few frames of the foe's own hit-stop + a white
// flash when it lands, impact FX (sparks, dust, ring, cracks for heavy blows), then a short recovery.
const ease3 = (k) => 1 - Math.pow(1 - clamp(k, 0, 1), 3);
const partGeos = {};
function makePart(body, bh) {
  const P = PARTS[body];
  if (!partGeos[body]) partGeos[body] = new THREE.PlaneGeometry(1, 1).translate(0.5 - P.pv[0], 0.5 - P.pv[1], 0); // origin = the pivot
  const m = makeSprite(body + '_w', bh * P.hr);
  m.geometry = partGeos[body]; m.material.side = THREE.DoubleSide; // mirrored with a negative x scale when facing left
  return m;
}
const _pq = new THREE.Quaternion(), _pz = new THREE.Vector3(0, 0, 1), _pv = new THREE.Vector3(), _pw = new THREE.Vector3();
// the part sits on the body's wrist / shoulder (follows its lean, squash and flip); e.wa = swing angle (CCW, facing right),
// e.wx = thrust along the weapon, e.wGlow = wind-up glow in e.wCol
function placePart(e, ssx, ssy) {
  const m = e.mesh, w = e.wpn, P = PARTS[e.body], f = e.face < 0 ? -1 : 1, ud = m.userData, wu = w.userData;
  if (e.thrown) { // the reaper's thrown sickle: spins about its own middle at its spot on the loop
    const sc = 1.9; w.quaternion.copy(camera.quaternion).multiply(_pq.setFromAxisAngle(_pz, e.skSpin));
    _pv.set((0.5 - P.pv[0]) * wu.bw * sc, (0.5 - P.pv[1]) * wu.bh * sc, 0).applyQuaternion(w.quaternion);
    w.position.set(e.skx, 0.62, e.skz).sub(_pv); w.scale.set(wu.bw * sc, wu.bh * sc, 1);
    const u = w.material.uniforms; u.uFlash.value = 0.25 + 0.15 * Math.sin(G.time * 30); u.uFlashCol.value.set(SK_COL); u.uTint.value.set(0xffffff); u.uAlpha.value = 1; u.uBias.value = 0.4;
    w.visible = true; return;
  }
  _pv.set((P.at[0] - 0.5) * ud.bw * ssx * f + (e.wfx || 0) * f, P.at[1] * ud.bh * ssy + (e.wy || 0), 0).applyQuaternion(m.quaternion); // wy / wfx: the hand raised / pushed forward
  w.position.copy(m.position).add(_pv);
  w.quaternion.copy(m.quaternion);
  if (e.wa) w.quaternion.multiply(_pq.setFromAxisAngle(_pz, e.wa * f));
  if (e.wx) { if (e.wxDir !== undefined) _pw.set(Math.cos(e.wxDir) * e.wx, Math.sin(e.wxDir) * e.wx, 0).applyQuaternion(camera.quaternion); else _pw.set(e.wx * f, 0, 0).applyQuaternion(m.quaternion); w.position.add(_pw); } // wxDir: slide along the weapon's own screen angle (a spear thrust)
  const ws = e.wsc || 1; w.scale.set(wu.bw * ssx * f * ws, wu.bh * ssy * ws, 1); // wsc: the weapon grows a little while it attacks (reads on a phone)
  const u = w.material.uniforms, bu = m.material.uniforms, g = e.wGlow || 0;
  if (g > bu.uFlash.value) { u.uFlash.value = g; u.uFlashCol.value.set(e.wCol || 0xff3050); } else { u.uFlash.value = bu.uFlash.value; u.uFlashCol.value.copy(bu.uFlashCol.value); }
  u.uTint.value.copy(bu.uTint.value); u.uAlpha.value = bu.uAlpha.value; u.uBias.value = bu.uBias.value + (P.behind && !e.wFront ? -0.08 : 0.08); // wFront: a spear thrust toward the camera is drawn in front of the body
  w.material.transparent = m.material.transparent; w.visible = m.visible && !e.noWpn; // noWpn: the shield knight's spear is out (thrown)
  if (e.smear) smearFollow(e, w.position);
}
// swing smear: a crescent from where the swing started to where the blade is now, bright at the head, gone in 0.14 s
const smearGeo = new THREE.PlaneGeometry(2, 2), smearPool = [], smears = [];
const smearMat = () => new THREE.ShaderMaterial({
  uniforms: { uA0: { value: 0 }, uA1: { value: 0 }, uR0: { value: 0.42 }, uCol: { value: new THREE.Color() }, uAlpha: { value: 1 } },
  vertexShader: 'varying vec2 vP; void main(){ vP = position.xy; vec4 mv = modelViewMatrix * vec4(position, 1.0); mv.z += 1.3; gl_Position = projectionMatrix * mv; }',
  fragmentShader: `uniform float uA0, uA1, uR0, uAlpha; uniform vec3 uCol; varying vec2 vP;
    void main(){ float r = length(vP); if (r > 1.0 || r < uR0) discard;
      float span = uA1 - uA0; float d = mod((atan(vP.y, vP.x) - uA0) * sign(span) + 12.5664, 6.2832); float t = d / max(0.001, abs(span));
      if (t > 1.0) discard;
      float band = smoothstep(uR0, uR0 + 0.3, r) * (1.0 - smoothstep(0.88, 1.0, r));
      float al = band * t * t * uAlpha;
      vec3 c = mix(uCol, vec3(1.0), smoothstep(0.5, 1.0, t) * smoothstep(0.55, 0.92, r));
      gl_FragColor = vec4(c * al, al); }`,
  blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, side: THREE.DoubleSide,
});
function addSmear(e, col, from) {
  endSmear(e);
  let s = smearPool.pop();
  if (!s) { s = { m: new THREE.Mesh(smearGeo, smearMat()) }; s.m.frustumCulled = false; s.m.renderOrder = 4; s.u = s.m.material.uniforms; }
  s.e = e; s.life = -1; s.a0 = from; s.u.uCol.value.set(col); s.u.uAlpha.value = 1; s.u.uA0.value = s.u.uA1.value = 0;
  scene.add(s.m); smears.push(s); e.smear = s;
}
function smearFollow(e, pos) {
  const s = e.smear, P = PARTS[e.body], f = e.face < 0 ? -1 : 1, th = P.tip[0] * Math.PI / 180, R = P.tip[1] * e.wpn.userData.bh * 1.15 * (e.wsc || 1);
  s.m.position.copy(pos); s.m.quaternion.copy(e.mesh.quaternion); s.m.scale.set(R * f, R, 1);
  s.u.uA0.value = th + s.a0; s.u.uA1.value = th + e.wa;
}
function endSmear(e) { if (e.smear) { e.smear.life = 0.14; e.smear = null; } }
// a free-standing claw / bite smear (no weapon part): a crescent raked across the foe toward world direction a, gone in 0.16 s
function clawSmear(e, a, col) {
  let s = smearPool.pop();
  if (!s) { s = { m: new THREE.Mesh(smearGeo, smearMat()) }; s.m.frustumCulled = false; s.m.renderOrder = 4; s.u = s.m.material.uniforms; }
  _sv1.set(e.x, 0.5, e.z).project(camera); _sv2.set(e.x + Math.cos(a), 0.5, e.z + Math.sin(a)).project(camera);
  const th = Math.atan2(_sv2.y - _sv1.y, (_sv2.x - _sv1.x) * camera.aspect), R = 0.55 + e.r;
  s.e = e; s.life = 0.16; s.u.uCol.value.set(col); s.u.uAlpha.value = 1; s.u.uA0.value = th + 1.1; s.u.uA1.value = th - 1.1;
  s.m.position.set(e.x + Math.cos(a) * 0.3, 0.5, e.z + Math.sin(a) * 0.3); s.m.quaternion.copy(camera.quaternion); s.m.scale.set(R, R, 1);
  scene.add(s.m); smears.push(s);
}
// ground telegraphs: an outline plus a fill that grows with the wind-up (sector = a swing in front, lane = a charge or thrust
// line, ring = where a blow / leap lands)
// (user 11-14 "make them more subtle"): a thin outline, a faint fill that only brightens in the last ~30% before the blow, a
// light dark under-layer (just enough to separate it from warm floors), no chevrons. Bosses (t.str) read a bit stronger
const teleTex = {
  sector: canvasTex(128, 128, (g) => {
    const grd = g.createRadialGradient(64, 64, 0, 64, 64, 62);
    grd.addColorStop(0, 'rgba(255,255,255,0.03)'); grd.addColorStop(0.8, 'rgba(255,255,255,0.16)'); grd.addColorStop(0.95, 'rgba(255,255,255,0.85)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd; g.beginPath(); g.moveTo(64, 64); g.arc(64, 64, 62, -0.9, 0.9); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.55)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(64, 64); g.lineTo(64 + Math.cos(-0.9) * 61, 64 + Math.sin(-0.9) * 61); g.moveTo(64, 64); g.lineTo(64 + Math.cos(0.9) * 61, 64 + Math.sin(0.9) * 61); g.stroke(); // thin side edges
  }),
  lane: canvasTex(128, 32, (g) => {
    const grd = g.createLinearGradient(0, 0, 0, 32); grd.addColorStop(0, 'rgba(255,255,255,0.85)'); grd.addColorStop(0.07, 'rgba(255,255,255,0.14)'); grd.addColorStop(0.93, 'rgba(255,255,255,0.14)'); grd.addColorStop(1, 'rgba(255,255,255,0.85)');
    g.fillStyle = grd; g.fillRect(0, 0, 124, 32);
  }),
  ring: ringTexture([[0, 0.06], [0.7, 0.12], [0.88, 0.35], [0.95, 0.85], [0.985, 0.3], [1, 0]]),
};
const teleGeo = { sector: flatRingGeo, ring: flatRingGeo, lane: new THREE.PlaneGeometry(1, 1).translate(0.5, 0, 0).rotateX(-Math.PI / 2) };
const telePool = { sector: [], ring: [], lane: [] };
function teleGet(kind, color) {
  let t = telePool[kind].pop();
  if (!t) {
    const mk = () => { const m = new THREE.Mesh(teleGeo[kind], new THREE.MeshBasicMaterial({ map: teleTex[kind], transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL })); m.renderOrder = 1; return m; };
    t = { kind, a: mk(), b: mk() };
    // dark under-layer (normal blend): the additive colour alone vanished on warm floors (forge orange, lava light); kept faint
    t.u = new THREE.Mesh(teleGeo[kind], new THREE.MeshBasicMaterial({ map: teleTex[kind], color: 0x000000, transparent: true, opacity: 0.2, depthWrite: false, ...DECAL })); t.u.renderOrder = 0;
  }
  t.str = 1; t.a.material.color.set(color); t.b.material.color.set(color); t.a.scale.setScalar(0.01); t.b.scale.setScalar(0.01); t.u.scale.setScalar(0.01);
  scene.add(t.a, t.b, t.u); return t;
}
function teleSet(t, x, z, ang, len, wid, k) {
  if (!t) return;
  t.a.position.set(x, 0.05, z); t.a.rotation.y = -ang; t.b.position.set(x, 0.055, z); t.b.rotation.y = -ang; t.u.position.set(x, 0.045, z); t.u.rotation.y = -ang;
  if (t.kind === 'lane') { t.a.scale.set(len, 1, wid); t.b.scale.set(Math.max(0.01, len * k), 1, wid * 0.85); t.u.scale.set(len + 0.06, 1, wid * 1.06); }
  else { t.a.scale.setScalar(len); t.b.scale.setScalar(Math.max(0.01, len * k)); t.u.scale.setScalar(len * 1.02); }
  // only near Pip (user 11-15: markers everywhere looked dirty): full within ~3.5 tiles of the marked area, gone by ~6
  let dd = Math.hypot(player.x - x, player.z - z) - (t.kind === 'lane' ? 0 : len);
  if (t.kind === 'lane') dd = Math.min(dd, Math.hypot(player.x - (x + Math.cos(ang) * len), player.z - (z + Math.sin(ang) * len)), Math.hypot(player.x - (x + Math.cos(ang) * len * 0.5), player.z - (z + Math.sin(ang) * len * 0.5)));
  const vis = clamp(1 - (dd - 0.2) / 0.5, 0, 1); // tightened (user: slime landing rings still showing): only when it can actually reach you
  const s = (t.str || 1) * vis, late = clamp((k - 0.7) / 0.3, 0, 1); // the fill brightens only in the last 30%
  const e0 = t.kind === 'sector' && s < 1.2 ? 1 - k : 0; // a regular foe's swing wedge starts a little stronger (it vanished on the forge floor)
  t.u.material.opacity = (0.1 + 0.12 * k + 0.14 * e0) * s;
  t.a.material.opacity = (0.2 + 0.12 * k + 0.18 * e0) * s; t.b.material.opacity = (0.1 + 0.08 * k + 0.42 * late) * s * (k > 0.8 ? 0.8 + 0.2 * Math.sin(G.time * 40) : 1);
  t.x = x; t.z = z; t.ang = ang; t.len = len; t.wid = wid; // the area the blow covers (inMark): the marker is the truth
}
// teleFree keeps the last marker's area on e.mk, so the blow that follows hits exactly what the marker showed
function teleFree(e) { const t = e.tg; if (!t) return; if (t.len) e.mk = { kind: t.kind, x: t.x, z: t.z, ang: t.ang, len: t.len, wid: t.wid }; scene.remove(t.a, t.b, t.u); telePool[t.kind].push(t); e.tg = null; }
// how far a charge / roll can travel from (x, z) along (fx, fz) before a wall or the room's edge (its lane marker = this)
function laneLen(x, z, fx, fz, max, r) {
  const room = roomAt(x, z); let l = 0;
  while (l < max) { const n = l + 0.25, px = x + fx * (n + r), pz = z + fz * (n + r); if (solid(px, pz, false) || (room && roomAt(px, pz) !== room)) break; l = n; }
  return Math.max(0.5, l);
}
// is Pip inside a marker area? pad = how much of Pip's body may stick out (half his radius by default). sector = the
// +-0.9 rad wedge of the sector texture, lane = a strip len x wid from (x, z), ring = a disc of radius len
function inMark(m, pad = player.r * 0.5) {
  if (!m || !player.alive) return false;
  const px = player.x - m.x, pz = player.z - m.z, d = Math.hypot(px, pz);
  if (m.kind === 'ring') return d < m.len + pad;
  const fx = Math.cos(m.ang), fz = Math.sin(m.ang);
  if (m.kind === 'lane') { const along = px * fx + pz * fz, perp = Math.abs(pz * fx - px * fz); return along > -pad && along < m.len + pad && perp < m.wid / 2 + pad; }
  if (d > m.len * 0.97 + pad) return false;
  if (d < 0.05) return true;
  return Math.acos(clamp((px * fx + pz * fz) / d, -1, 1)) < 0.9 + Math.asin(Math.min(1, pad / d));
}
// ground cracks under heavy blows (dark), with a hot glowing copy for rune / crystal / magma golems
const crackTex = canvasTex(128, 128, (g) => {
  g.lineCap = 'round'; g.lineJoin = 'round';
  for (let k = 0; k < 9; k++) {
    let x = 64, y = 64, a = k / 9 * 6.283 + hash(k, 5) * 0.5;
    for (let s2 = 0; s2 < 5; s2++) {
      const L = 7 + hash(k, s2 + 9) * 7, nx = x + Math.cos(a) * L, ny = y + Math.sin(a) * L;
      g.strokeStyle = 'rgba(255,255,255,0.95)'; g.lineWidth = Math.max(1.2, 4.5 - s2 * 0.8); g.beginPath(); g.moveTo(x, y); g.lineTo(nx, ny); g.stroke();
      x = nx; y = ny; a += (hash(k, s2) - 0.5) * 0.9;
    }
  }
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 22); grd.addColorStop(0, 'rgba(255,255,255,0.8)'); grd.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
});
const crackPool = [], cracks = [];
function addCrack(x, z, r, hot) {
  let c = cracks.length >= 8 ? cracks.shift() : crackPool.pop();
  if (!c) {
    c = { d: new THREE.Mesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: crackTex, color: 0x000000, transparent: true, depthWrite: false, ...DECAL })),
      h: new THREE.Mesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: crackTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL })) };
    c.d.renderOrder = -1; c.h.renderOrder = 0;
  }
  const rot = Math.random() * 6.28;
  c.d.position.set(x, onPlate(x, z) ? 0.058 : 0.02, z); c.d.rotation.y = rot; c.d.scale.setScalar(r); c.d.material.opacity = 0.75;
  c.h.position.set(x, 0.025, z); c.h.rotation.y = rot; c.h.scale.setScalar(r * 0.92); c.h.visible = !!hot; if (hot) c.h.material.color.set(hot);
  scene.add(c.d, c.h); c.life = 2.6; cracks.push(c);
}
// afterimages behind a charging golem (a small pool of body sprites per sheet)
const afterPool = {}, afters = [];
function afterImage(e, col) {
  if (afters.length >= (MOBILE ? 8 : 16)) return; // a crowd of charging golems: the trail thins out instead of costing frames
  const sh = e.mesh.userData.sheet; let pool = afterPool[sh]; if (!pool) afterPool[sh] = pool = [];
  let g = pool.pop();
  if (!g) { g = makeSprite(sh, e.mesh.userData.bh); g.material.transparent = true; g.material.depthWrite = false; scene.remove(g); }
  g.position.copy(e.mesh.position); g.quaternion.copy(e.mesh.quaternion); g.scale.copy(e.mesh.scale);
  const u = g.material.uniforms; u.uFlip.value = e.mesh.material.uniforms.uFlip.value; u.uFlash.value = 0.9; u.uFlashCol.value.set(col); u.uAlpha.value = 0.45; u.uBias.value = 0.9;
  scene.add(g); afters.push({ g, sh, life: 0.24 });
}
// foe ground hazards: magma golem lava, salamander fire (hurt Pip, never foes)
const foeHaz = [], FOE_HAZ_MAX = MOBILE ? 10 : 16;
function addFoeHaz(x, z, r, life, kind, delay = 0) { // delay: an ember that only flares up (and hurts) after it (the telegraph)
  if (cellAt(x, z) !== FLOOR) return;
  for (const h of foeHaz) if (h.kind === kind && Math.abs(h.x - x) < r * 0.6 && Math.abs(h.z - z) < r * 0.6) { h.life = Math.max(h.life, life); return; } // refresh one already there
  const h = foeHaz.length >= FOE_HAZ_MAX ? foeHaz.shift() : {};
  h.x = x; h.z = z; h.r = r; h.life = h.max = life + delay; h.delay = delay; h.kind = kind; h.cd = 0.25; h.rot = Math.random() * 6.28;
  foeHaz.push(h);
}
// the magma golem's roll leaves ONE connected lava streak (not a row of round pools) that cools from yellow-white to dark red
const lavaStreaks = Array.from({ length: 6 }, () => ({ on: false })), _sc = new THREE.Color();
function addStreak(x, z) { const s = lavaStreaks.find((q) => !q.on) || lavaStreaks[0]; Object.assign(s, { on: true, x0: x, z0: z, x1: x, z1: z, life: 2.6, max: 2.6, cd: 0, grow: true }); return s; }
// expanding rune shockwaves (the ring's front hurts once; outrun it or stand outside its reach)
// ---------- round-2 monster FX (all pooled; the ground layers are drawn in updateFoeFx between gfxBegin and gfxEnd) ----------
// gfxPut with separate length / width (stretched decals: path bands, lava streaks)
function gfxPut2(m, x, y, z, sx, sz, rot, color, a) {
  const n = m.userData.n; if (n >= m.userData.max || a <= 0.01) return;
  m.setMatrixAt(n, gfxM.compose(gfxV.set(x, y, z), gfxQ.setFromAxisAngle(gfxUp, rot), gfxS.set(sx, 1, sz)));
  gfxC.set(color); m.geometry.attributes.aCol.setXYZW(n, gfxC.r, gfxC.g, gfxC.b, a); m.userData.n = n + 1;
}
// path band: a curved marked strip (a thrown sickle's loop, a saw gear's bounce path). Dark edge built in (reads on any floor),
// tinted core, bright rims; its half-width is the real hit radius
const bandTex = canvasTex(16, 32, (g) => {
  g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(0, 1, 16, 30); // subtler (user 11-14): faint dark edge, thin rims, a light core
  g.fillStyle = 'rgba(255,255,255,0.2)'; g.fillRect(0, 4, 16, 24);
  g.fillStyle = 'rgba(255,255,255,0.9)'; g.fillRect(0, 3, 16, 1.5); g.fillRect(0, 27.5, 16, 1.5);
});
const bandBatch = groundBatch(bandTex, false, MOBILE ? 200 : 300); bandBatch.renderOrder = 1;
// soft dark blob (scorch, lava crust, contact shadows under rooted foes)
const darkBatch = groundBatch(blobTex, false, 72); darkBatch.renderOrder = -1;
// murky spore gas: soft lumpy fog, a darker lumpy (not spiky) edge, bubbles. Tinted per cloud
const gasTex = canvasTex(128, 128, (g) => {
  g.translate(64, 64);
  g.fillStyle = 'rgba(70,70,70,0.55)'; blobPath(g, 58, 0.09); g.fill();
  for (let k = 0; k < 9; k++) {
    const a = hash(k, 81) * 6.2832, d = k ? 12 + hash(k, 82) * 26 : 0, r = k ? 20 + hash(k, 83) * 14 : 40, x = Math.cos(a) * d, y = Math.sin(a) * d;
    const grd = g.createRadialGradient(x, y, 0, x, y, r); grd.addColorStop(0, 'rgba(255,255,255,0.55)'); grd.addColorStop(0.7, 'rgba(210,210,210,0.3)'); grd.addColorStop(1, 'rgba(160,160,160,0)');
    g.fillStyle = grd; g.beginPath(); g.arc(x, y, r, 0, 6.2832); g.fill();
  }
  g.lineWidth = 2.2;
  for (let k = 0; k < 11; k++) { const a = hash(k, 91) * 6.2832, d = hash(k, 92) * 42, r = 3 + hash(k, 93) * 6; g.strokeStyle = 'rgba(255,255,255,0.75)'; g.beginPath(); g.arc(Math.cos(a) * d, Math.sin(a) * d, r, 0, 6.2832); g.stroke(); }
});
gasTex.magFilter = THREE.LinearFilter;
const gasBatch = groundBatch(gasTex, false, 24);
// dirt: clods and roots (Mother Spore's base, her burrow mound)
const dirtTex = canvasTex(128, 128, (g) => {
  g.translate(64, 64); g.lineCap = 'round';
  for (let k = 0; k < 12; k++) { // roots crawling out
    let a = k / 12 * 6.2832 + hash(k, 101) * 0.4, r = 20, x = Math.cos(a) * r, y = Math.sin(a) * r;
    g.beginPath(); g.moveTo(x, y);
    for (let s2 = 0; s2 < 4; s2++) { a += (hash(k, s2 + 102) - 0.5) * 0.8; r += 9; x = Math.cos(a) * r; y = Math.sin(a) * r; g.lineTo(x, y); }
    g.strokeStyle = 'rgba(30,22,16,0.9)'; g.lineWidth = 6; g.stroke(); g.strokeStyle = 'rgba(150,120,95,0.9)'; g.lineWidth = 2.5; g.stroke();
  }
  const grd = g.createRadialGradient(0, 0, 8, 0, 0, 46); grd.addColorStop(0, 'rgba(40,30,22,0.95)'); grd.addColorStop(0.65, 'rgba(110,86,64,0.9)'); grd.addColorStop(1, 'rgba(90,70,50,0)');
  g.fillStyle = grd; blobPath(g, 44, 0.12); g.fill();
  for (let k = 0; k < 26; k++) { const a = hash(k, 111) * 6.2832, d = 14 + hash(k, 112) * 34, r = 2 + hash(k, 113) * 4.5; g.fillStyle = k % 3 ? 'rgba(170,140,110,0.95)' : 'rgba(60,45,34,0.95)'; g.beginPath(); g.arc(Math.cos(a) * d, Math.sin(a) * d, r, 0, 6.2832); g.fill(); }
});
dirtTex.magFilter = THREE.LinearFilter;
const dirtBatch = groundBatch(dirtTex, false, 24); dirtBatch.renderOrder = -1;
// lava streak: one connected glowing ribbon (soft ends, white-hot core, red edges), tinted as it cools
const streakTex = canvasTex(128, 32, (g) => {
  for (let y = 0; y < 32; y++) {
    const v = 1 - Math.abs(y - 15.5) / 16, a = Math.pow(v, 0.7), col = `rgba(255,${Math.round(90 + 150 * v * v)},${Math.round(20 + 120 * v * v * v)},${a})`;
    const grd = g.createLinearGradient(0, 0, 128, 0); grd.addColorStop(0, 'rgba(255,90,20,0)'); grd.addColorStop(0.08, col); grd.addColorStop(0.92, col); grd.addColorStop(1, 'rgba(255,90,20,0)');
    g.fillStyle = grd; g.fillRect(0, y, 128, 1);
  }
  g.globalCompositeOperation = 'destination-out'; // crust cracks across the flow
  for (let k = 0; k < 9; k++) { const x = 8 + k * 13 + hash(k, 121) * 6; g.strokeStyle = 'rgba(0,0,0,0.55)'; g.lineWidth = 2; g.beginPath(); g.moveTo(x, 3); g.lineTo(x + 4, 14); g.lineTo(x - 2, 29); g.stroke(); }
});
streakTex.magFilter = THREE.LinearFilter;
const streakBatch = groundBatch(streakTex, true, 12); streakBatch.renderOrder = 0;
GFX_BATCHES.push(bandBatch, darkBatch, gasBatch, dirtBatch, streakBatch);
function bandSeg(x0, z0, x1, z1, w, col, a) { const dx = x1 - x0, dz = z1 - z0, l = Math.hypot(dx, dz); if (l > 1e-3) gfxPut2(bandBatch, (x0 + x1) / 2, 0.05, (z0 + z1) / 2, l / 2 + 0.015, w, -Math.atan2(dz, dx), col, a); }
// a foe's path marker: e.pth = flat [x, z, ...] (NaN breaks a line), e.pthN points, e.pthW half-width (= the hit radius),
// e.pthK fill 0..1 (the wind-up), e.pthCol colour, e.pthA overall alpha. Drawn every frame while e.pthN > 1
function pthClear(e) { e.pthN = 0; e.pthK = 0; e.pthA = 1; }
function pthAdd(e, x, z) { if (!e.pth) e.pth = new Float32Array(400); if (e.pthN < 200) { e.pth[e.pthN * 2] = x; e.pth[e.pthN * 2 + 1] = z; e.pthN++; } }
function drawPath(e) {
  const P = e.pth, n = e.pthN, k = e.pthK, fl = k > 0.75 && k < 1 ? 0.75 + 0.25 * Math.sin(G.time * 40) : 1;
  for (let i = 1; i < n; i++) {
    const x0 = P[i * 2 - 2], z0 = P[i * 2 - 1], x1 = P[i * 2], z1 = P[i * 2 + 1];
    if (x0 !== x0 || x1 !== x1) continue; // a break
    if (e.pthDash && i % 2 === 0) continue; // dashed
    bandSeg(x0, z0, x1, z1, e.pthW, e.pthCol, (i / n <= k ? 0.45 + 0.4 * clamp((k - 0.7) / 0.3, 0, 1) : 0.28) * fl * e.pthA);
  }
}
// gold coins that spill off the Mimic Lord: bounce, roll, settle, fade. One instanced draw, NOT pickups
const coinGeo = (() => {
  const g = new THREE.CylinderGeometry(0.13, 0.13, 0.03, 14), nrm = g.attributes.normal, c = new Float32Array(nrm.count * 3);
  for (let i = 0; i < nrm.count; i++) { const cap = Math.abs(nrm.getY(i)) > 0.5; c[i * 3] = cap ? 1 : 0.7; c[i * 3 + 1] = cap ? 0.84 : 0.47; c[i * 3 + 2] = cap ? 0.32 : 0.1; }
  g.setAttribute('color', new THREE.BufferAttribute(c, 3)); return g;
})();
const coinMat = new THREE.MeshBasicMaterial({ vertexColors: true });
const COIN_N = MOBILE ? 28 : 48, coinFx = Array.from({ length: COIN_N }, () => ({ on: false })), coinFxMesh = new THREE.InstancedMesh(coinGeo, coinMat, COIN_N);
coinFxMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); coinFxMesh.frustumCulled = false; coinFxMesh.count = 0; scene.add(coinFxMesh);
let coinHead = 0;
const _ce = new THREE.Euler();
function coinSpill(x, y, z, n, spd = 2.2, up = 3.2) {
  for (let k = 0; k < n; k++) {
    const c = coinFx[coinHead]; coinHead = (coinHead + 1) % COIN_N;
    const a = Math.random() * 6.2832, s = spd * (0.5 + Math.random() * 0.7);
    c.on = true; c.x = x; c.y = y; c.z = z; c.vx = Math.cos(a) * s; c.vz = Math.sin(a) * s; c.vy = up * (0.6 + Math.random() * 0.6);
    c.rx = Math.random() * 6.28; c.rz = Math.random() * 6.28; c.sp = 8 + Math.random() * 8; c.life = c.max = 1.3 + Math.random() * 0.7; c.flat = false;
  }
}
function updateCoinFx(dt) {
  let n = 0;
  for (const c of coinFx) {
    if (!c.on) continue;
    c.life -= dt; if (c.life <= 0) { c.on = false; continue; }
    c.vy -= 16 * dt; c.x += c.vx * dt; c.y += c.vy * dt; c.z += c.vz * dt;
    if (solid(c.x, c.z, false)) { c.x -= c.vx * dt; c.z -= c.vz * dt; c.vx *= -0.4; c.vz *= -0.4; }
    if (c.y < 0.035) { // bounce, then roll and settle flat
      c.y = 0.035;
      if (c.vy < -1.2) { c.vy = -c.vy * 0.42; c.vx *= 0.7; c.vz *= 0.7; if (fxP(0.4)) spark(c.x, 0.08, c.z, 0xfff2a0, { s: 0.3, life: 0.08, drag: 0 }); }
      else { c.vy = 0; c.vx *= Math.exp(-3 * dt); c.vz *= Math.exp(-3 * dt); c.flat = true; }
    }
    if (c.flat) { c.rx = lerp(c.rx, Math.round(c.rx / Math.PI) * Math.PI, damp(8, dt)); c.rz = lerp(c.rz, Math.round(c.rz / Math.PI) * Math.PI, damp(8, dt)); } else c.rx += c.sp * dt;
    const s = Math.min(1, c.life / 0.35);
    _ce.set(c.rx, 0, c.rz); gfxQ.setFromEuler(_ce);
    coinFxMesh.setMatrixAt(n++, gfxM.compose(gfxV.set(c.x, c.y, c.z), gfxQ, gfxS.set(s, s, s)));
    if (!c.flat && fxP(0.04)) spark(c.x, c.y, c.z, 0xffffff, { s: 0.22, life: 0.07, drag: 0 }); // a glint
  }
  coinFxMesh.count = n; coinFxMesh.visible = n > 0; if (n) coinFxMesh.instanceMatrix.needsUpdate = true;
}
// the Mimic Lord's tongue: a bendy chain of tapered segments (instanced cylinders + joint balls) plus a fat tip, so a wave can
// run along it; world-space instances, built once and reused
const TG_N = 24;
let tongueM = null;
function tongueMesh() {
  if (!tongueM) {
    const mat = new THREE.MeshLambertMaterial({ color: 0xd83848, emissive: 0x700c18 });
    const segs = new THREE.InstancedMesh(new THREE.CylinderGeometry(1, 1, 1, 8, 1, true), mat, TG_N);
    const joints = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), mat, TG_N);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8), mat);
    for (const o of [segs, joints, tip]) { o.material.depthTest = false; o.renderOrder = 5; o.frustumCulled = false; } // drawn over the chest: it visibly leaves the mouth
    tongueM = new THREE.Group(); tongueM.add(segs, joints, tip); tongueM.userData = { segs, joints, tip, pts: new Float32Array((TG_N + 1) * 3) };
  }
  return tongueM;
}
// the Sentinel's saw gear: a flat toothed brass gear with a dark hub (extruded once; spun on Y in flight)
const gearGeo = (() => {
  const s = new THREE.Shape(), T = 12, R0 = 0.33, R1 = 0.45;
  for (let i = 0; i < T * 4; i++) { const a = i / (T * 4) * 6.2832, r = (i % 4 === 1 || i % 4 === 2) ? R1 : R0; if (i) s.lineTo(Math.cos(a) * r, Math.sin(a) * r); else s.moveTo(Math.cos(a) * r, Math.sin(a) * r); }
  const h = new THREE.Path(); h.absarc(0, 0, 0.1, 0, 6.2832, true); s.holes.push(h);
  return new THREE.ExtrudeGeometry(s, { depth: 0.07, bevelEnabled: false, curveSegments: 4 }).translate(0, 0, -0.035).rotateX(-Math.PI / 2);
})();
const gearHubGeo = new THREE.CylinderGeometry(0.17, 0.17, 0.1, 12);
const gearMat = new THREE.MeshPhongMaterial({ color: 0xd8a040, emissive: 0x5a3810, specular: 0xfff0c0, shininess: 70 }), gearHubMat = new THREE.MeshPhongMaterial({ color: 0x3a2a1c, emissive: 0x140c06, specular: 0x887766, shininess: 40 });
const shocks = [];
function addShock(x, z, R, dur, col, dmg) { addRing(x, z, 0.3, R, dur, col, true); addRing(x, z, 0.3, R * 0.94, dur * 1.08, 0xffffff, true); shocks.push({ x, z, R, dur, t: 0, dmg, hit: false, col }); } // top: drawn over the wall it hit (was clipped)
// ---- rocks (user 11-14): golem lobs, ground-smash rockfall, Stone King roll debris. One pooled instanced draw (+ a glow shell for
// rune / crystal / magma). A rock flies from (x0, y0, z0) to its landing spot (x1, z1) on an arc of height h over T s (ceiling rocks
// wait W s, then drop straight down); its ring on the floor (= the hit, radius R) fills while a shadow grows under it, then it
// shatters. kind: 0 stone, 1 rune, 2 crystal, 3 magma. Only a lobbed rock does its variant trick (lava splash, crystal shards)
// (user 11-14 'rocks small and dark'): drawn ROCK_VS x bigger (hit rings unchanged), light warm-grey stone, a bright top, a dark
// facet edge + a black back-face outline so they pop on dark and orange floors; a shadow under each that grows as it drops
const ROCK_VS = 1.65, ROCK_N = MOBILE ? 18 : 30, ROCK_COL = [0xd6c8b2, 0x8a90d0, 0xd8b8f0, 0x8a4a2c], ROCK_HOT = [0, 0x7fe8ff, 0xd070ff, 0xff6a10], ROCK_DUST = [0xa89a8a, 0x8a90c0, 0xd8a868, 0x5a3a30];
const rockGeo = (() => {
  const g = new THREE.DodecahedronGeometry(0.5, 0), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i), j = 0.8 + 0.32 * hash(Math.round(x * 40) + Math.round(z * 40) * 3, Math.round(y * 40)); p.setXYZ(i, x * j, y * j * 0.82, z * j); } // lumpy, a bit flat
  g.computeVertexNormals(); return g;
})();
const rockMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
rockMat.onBeforeCompile = (sh) => { // bright top facets, darker facets turned away from the camera (reads as a rim)
  sh.fragmentShader = sh.fragmentShader.replace('#include <opaque_fragment>', `
  { float ndv = clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0);
    float top = smoothstep(0.35, 0.85, dot(normal, normalize((viewMatrix * vec4(0.0, 1.0, 0.0, 0.0)).xyz)));
    outgoingLight = outgoingLight * (0.85 + 0.35 * top) + diffuseColor.rgb * (0.12 + 0.4 * top);
    outgoingLight *= mix(0.45, 1.0, smoothstep(0.05, 0.5, ndv)); }
  #include <opaque_fragment>`);
};
const rockMesh = new THREE.InstancedMesh(rockGeo, rockMat, ROCK_N);
const rockEdge = new THREE.InstancedMesh(rockGeo, new THREE.MeshBasicMaterial({ color: 0x120c08, side: THREE.BackSide }), ROCK_N); // outline shell
const rockHot = new THREE.InstancedMesh(rockGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.BackSide }), ROCK_N); // a glow halo round the outline (back faces: the rock itself stays readable)
for (const m of [rockMesh, rockEdge, rockHot]) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.setColorAt(0, _sc.set(0xffffff)); m.instanceColor.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; scene.add(m); }
const rocks = Array.from({ length: ROCK_N }, () => ({ on: false })), _re = new THREE.Euler();
function rockSpawn(kind, x1, z1, R, W, T, o = {}) {
  const r = rocks.find((q) => !q.on); if (!r) return null;
  r.on = true; r.kind = kind; r.x1 = x1; r.z1 = z1; r.R = R; r.W = W; r.T = T; r.t = 0; r.k0 = 0; r.held = !!o.held; r.lob = !!o.lob;
  r.x = r.x0 = o.x0 ?? x1; r.y = r.y0 = o.y0 ?? 7.5; r.z = r.z0 = o.z0 ?? z1; r.h = o.h || 0; r.s = o.s || 0.75; r.dmg = o.dmg ?? 1; r.foes = o.foes || 0; r.own = o.own || null;
  r.rx = Math.random() * 6.28; r.ry = Math.random() * 6.28; r.sp = 5 + Math.random() * 5;
  r.tg = teleGet('ring', o.col ?? 0xff3050); if (o.boss) r.tg.str = 1.35; teleSet(r.tg, x1, z1, 0, R, 0, 0);
  return r;
}
function rockFree(r) { r.on = false; if (r.tg) { teleRelease(r.tg); r.tg = null; } }
function rockLand(r) {
  const x = r.x1, z = r.z1, hot = ROCK_HOT[r.kind];
  rockFree(r);
  chunk(x, 0.45, z, ROCK_COL[r.kind], MOBILE ? 5 : 8, 4.5, 0.14); burst(x, 0.3, z, ROCK_DUST[r.kind], MOBILE ? 7 : 11, 4, 0.42, 0.45);
  spark(x, 0.4, z, 0xffffff, { s: 1.3, life: 0.07, drag: 0 });
  for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283; spark(x, 0.08, z, 0xc8b8a0, { vx: Math.cos(a) * 4, vz: Math.sin(a) * 4, vy: 0.4, s: 0.32, life: 0.3, drag: 5 }); } // dust ring
  addRing(x, z, 0.2, r.R * 1.2, 0.28, 0xd8d0c0); addCrack(x, z, r.R * 0.75, hot && r.lob ? hot : 0); addShake(r.lob ? 0.16 : 0.1); sfx('rockfall');
  if (r.dmg && inMark({ kind: 'ring', x, z, len: r.R * 0.96 })) damagePlayer(r.dmg, x, z); // the ring is the truth
  if (r.foes) for (const o of enemies) if (!o.dead && !o.isBoss && Math.hypot(o.x - x, o.z - z) < r.R + o.r * 0.5) hurtEnemyRaw(o, r.foes, '#c0c8d0');
  for (const pot of [...pots]) if (Math.hypot(pot.x - x, pot.z - z) < r.R) breakPot(pot);
  if (!r.lob) return;
  if (r.kind === 3) addFoeHaz(x, z, 0.8, 2.2, 'lava'); // molten rock: a short lava splash
  else if (r.kind === 2) { // crystal: it splits into shards that fly out from the ring's edge
    const a0 = Math.random() * 6.28; for (let k = 0; k < 5; k++) { const a = a0 + k / 5 * 6.283, p = enemyShoot({ x, z }, a, 4.6, 0xd070ff, 0.7, 0, 'bolt'); p.x = x + Math.cos(a) * (r.R + 0.1); p.z = z + Math.sin(a) * (r.R + 0.1); }
    burst(x, 0.6, z, 0xe8a8ff, 10, 4, 0.35, 0.4);
  } else if (r.kind === 1) { addRing(x, z, 0.2, r.R * 1.5, 0.45, 0x7fe8ff, true); burst(x, 0.5, z, 0x7fe8ff, 10, 3, 0.35, 0.4); } // the rune flares
}
function updateRocks(dt) {
  let n = 0, nh = 0;
  for (const r of rocks) {
    if (!r.on) continue;
    if (r.held && (!r.own || r.own.dead)) { rockFree(r); continue; } // its golem died holding it
    let vis = true;
    if (!r.held) {
      r.t += dt; const fl = r.t - r.W;
      if (fl < 0) vis = false; // a ceiling rock not falling yet
      else { const u = Math.min(1, fl / r.T); r.x = lerp(r.x0, r.x1, u); r.z = lerp(r.z0, r.z1, u); r.y = r.lob ? lerp(r.y0, 0.3, u) + r.h * 4 * u * (1 - u) : lerp(r.y0, 0.3, u * u); }
      const k = r.k0 + (1 - r.k0) * clamp(r.t / (r.W + r.T), 0, 1);
      if (r.tg) teleSet(r.tg, r.x1, r.z1, 0, r.R, 0, k);
      gfxPut(darkBatch, r.x1, 0.03, r.z1, r.R * (0.25 + 0.6 * k), 0, 0x000000, 0.22 + 0.38 * k); // the marked spot darkens as it comes down
      if (fl >= r.T) { rockLand(r); continue; }
      if (vis) { // a soft shadow right under the rock: grows and darkens as it drops
        const lo = 1 - clamp((r.y - 0.3) / 7, 0, 1); gfxPut(darkBatch, r.x, 0.035, r.z, r.s * ROCK_VS * (0.35 + 0.45 * lo), 0, 0x000000, 0.25 + 0.45 * lo);
        const dc = ROCK_DUST[r.kind], ds = r.s * ROCK_VS * 0.5;
        if (r.lob && ROCK_HOT[r.kind] && fxP(0.5)) spark(r.x, r.y, r.z, ROCK_HOT[r.kind], { s: 0.3, life: 0.3, drag: 1 });
        if (fxP(0.6)) spark(r.x + rr(-ds, ds), r.y + (r.lob ? 0 : 0.35), r.z + rr(-ds, ds) * 0.5, dc, { vy: r.lob ? 0.4 : 2, s: 0.38, life: 0.35, drag: 1 }); // dust trailing off it
        if (fxP(0.3)) spark(r.x + rr(-ds, ds), r.y, r.z, 0xe8dcc8, { vy: 0.6, s: 0.22, life: 0.25, drag: 2 }); // grit
      }
    } else if (r.tg) teleSet(r.tg, r.x1, r.z1, 0, r.R, 0, r.k0);
    if (!vis) continue;
    r.rx += r.sp * dt * (r.held ? 0.15 : 1); _re.set(r.rx, r.ry, r.rx * 0.6); gfxQ.setFromEuler(_re);
    const vs = r.s * ROCK_VS, ry = r.y + (r.held ? (vs - r.s) * 0.4 : 0); // a held rock sits a bit higher so the bigger one clears the fist
    rockMesh.setMatrixAt(n, gfxM.compose(gfxV.set(r.x, ry, r.z), gfxQ, gfxS.set(vs, vs, vs))); rockMesh.setColorAt(n, _sc.set(ROCK_COL[r.kind]));
    rockEdge.setMatrixAt(n, gfxM.compose(gfxV, gfxQ, gfxS.set(vs * 1.1, vs * 1.1, vs * 1.1))); n++;
    if (ROCK_HOT[r.kind]) { const g = vs * (1.22 + 0.05 * Math.sin(G.time * 20 + r.ry)); rockHot.setMatrixAt(nh, gfxM.compose(gfxV, gfxQ, gfxS.set(g, g, g))); rockHot.setColorAt(nh, _sc.set(ROCK_HOT[r.kind])); nh++; }
  }
  rockMesh.count = rockEdge.count = n; rockMesh.visible = rockEdge.visible = n > 0; if (n) { rockMesh.instanceMatrix.needsUpdate = true; rockMesh.instanceColor.needsUpdate = true; rockEdge.instanceMatrix.needsUpdate = true; }
  rockHot.count = nh; rockHot.visible = nh > 0; if (nh) { rockHot.instanceMatrix.needsUpdate = true; rockHot.instanceColor.needsUpdate = true; }
}
// marked ceiling rocks around Pip (the first where he is heading), spaced apart, inside the room, staggered warnings
const _spots = new Float32Array(48);
function rockfall(n, spread, kind, warn, stagger, o = {}) {
  const room = rooms.find((q) => q.active) || G.curRoom; let m = 0;
  for (let tries = 0; m < n && tries < n * 10; tries++) {
    let x = player.x + (m ? rr(-spread, spread) : player.vx * 0.25), z = player.z + (m ? rr(-spread, spread) : player.vz * 0.25);
    if (room) { x = clamp(x, room.x0 + 1.5, room.x0 + room.w + 0.5); z = clamp(z, room.z0 + 1.5, room.z0 + room.h + 0.5); }
    if (solid(x, z, false) || (o.avoid && Math.hypot(x - o.avoid.x, z - o.avoid.z) < o.avoid.r + 1)) continue;
    let ok = true; for (let i = 0; i < m && ok; i++) if (Math.hypot(x - _spots[i * 2], z - _spots[i * 2 + 1]) < 1.5) ok = false;
    if (!ok) continue;
    _spots[m * 2] = x; _spots[m * 2 + 1] = z;
    rockSpawn(kind, x, z, o.R || 0.8, warn + m * stagger, 0.32, { s: o.s || 0.8, foes: o.foes || 0, col: o.col, boss: o.boss });
    m++;
  }
  if (m) sfx('rockfall');
}
// where an armed foe's hand / fist is (the part's tip), for a rock held up in it
function partTip(e, out) {
  const P = PARTS[e.body], f = e.face < 0 ? -1 : 1, a = P.tip[0] * Math.PI / 180 + (e.wa || 0), R = P.tip[1] * e.wpn.userData.bh * (e.wsc || 1);
  return out.set(Math.cos(a) * R * f, Math.sin(a) * R, 0).applyQuaternion(e.mesh.quaternion).add(e.wpn.position);
}
// ground smash (golems + the Stone King, user 11-14): the fist goes up high and the body rears back with dust shaken loose while
// a ring round it fills (= the hit), then it slams the floor (shockwave, cracks, shake) and rocks come down from the ceiling on
// their own marked spots. S = { R, col, dust, hot, n, spread, kind, warn, wave2, boss, foes, after }
function smashStep(e, dt, S) {
  const bh = e.mesh.userData.bh;
  if (e.state === 'gwind') {
    const k = 1 - e.st / e.windT; e.faceLock = e.faceLock || 1;
    e.wa = lerp(e.wa, 2.9, damp(7, dt)); e.wy = bh * 0.16 * ease3(k); e.wsc = 1 + 0.18 * ease3(k); e.wGlow = k * 0.8;
    e.sy = 1 + 0.12 * k; e.sx = 1 - 0.06 * k; e.tilt = -e.faceLock * 0.12 * k; e.tint = k * 0.6; e.shake = 0.02 + 0.05 * k;
    if (fxP(0.6 * k)) { const a = Math.random() * 6.28, d = e.r * (0.8 + Math.random() * 0.7); spark(e.x + Math.cos(a) * d, 0.08, e.z + Math.sin(a) * d, S.dust, { vy: rr(1.2, 2.8), s: 0.42, life: 0.5, drag: 1 }); } // dust shaken loose
    if (k > 0.5 && fxP(0.2)) spark(e.x + rr(-0.5, 0.5), bh * 0.95, e.z, 0xffffff, { s: 0.6, life: 0.06, drag: 0 }); // the raised fist glints
    teleSet(e.tg, e.x, e.z, 0, S.R, 0, k);
    if (e.st <= 0) { teleFree(e); e.state = 'gslam'; e.st = 0.12; e.tint = 0; e.wGlow = 0; addSmear(e, S.col, e.wa); sfx('swing'); }
  } else if (e.state === 'gslam') {
    const p = 1 - e.st / 0.12; e.wa = lerp(2.9, -0.4, p * p); e.wy = bh * 0.16 * (1 - p * p); e.sx = 1.12; e.sy = 0.88; e.tilt = e.faceLock * 0.2;
    if (e.st <= 0) {
      endSmear(e); e.squash = 0.9; e.hs = 0.09; e.flash = Math.max(e.flash, 0.8); addShake(S.boss ? 0.8 : 0.5); sfx('slam'); sfx('thud'); G.hitstop = Math.max(G.hitstop, S.boss ? 0.06 : 0.04);
      if (inMark(e.mk)) damagePlayer(1, e.x, e.z); // the ring is the truth
      addRing(e.x, e.z, 0.4, S.R * 1.18, 0.45, 0xc0c8d0, true); addRing(e.x, e.z, 0.3, S.R, 0.32, S.col, true); addCrack(e.x, e.z, S.R * 0.85, S.hot || 0);
      chunk(e.x, 0.4, e.z, e.d.chunk, MOBILE ? 8 : 12, 6, 0.16); burst(e.x, 0.3, e.z, S.dust, MOBILE ? 10 : 16, 6, 0.5, 0.55);
      for (let q = 0; q < 14; q++) { const a = q / 14 * 6.283; spark(e.x + Math.cos(a) * e.r, 0.1, e.z + Math.sin(a) * e.r, 0xc8b8a0, { vx: Math.cos(a) * 7, vz: Math.sin(a) * 7, vy: 0.6, s: 0.45, life: 0.4, drag: 5 }); }
      spark(e.x, 0.5, e.z, 0xffffff, { s: 2, life: 0.08, drag: 0 });
      for (const pot of [...pots]) if (Math.hypot(pot.x - e.x, pot.z - e.z) < S.R) breakPot(pot);
      rockfall(S.n, S.spread, S.kind, S.warn, 0.16, { R: S.rockR || 0.8, foes: S.foes, boss: S.boss, avoid: e });
      if (S.wave2) later(0.95, () => { if (!e.dead) { addShake(0.3); rockfall(S.wave2, S.spread, S.kind, S.warn * 0.9, 0.12, { R: S.rockR || 0.8, foes: S.foes, boss: S.boss }); } }); // enraged: a second wave
      e.state = 'grec'; e.st = 0.8;
    }
  } else if (e.state === 'grec') { // the fist comes back up out of the cracks
    e.wa = lerp(e.wa, 0, damp(4, dt)); e.wy = lerp(e.wy || 0, 0, damp(6, dt)); e.wsc = lerp(e.wsc || 1, 1, damp(5, dt)); e.tilt = e.faceLock * 0.1 * (e.st / 0.8);
    if (e.st <= 0) { e.state = 'idle'; e.st = S.after; e.faceLock = 0; }
  }
}
// a slain armed foe's weapon / arm flies off and fades
const flyParts = [];
function dropPart(e) {
  const w = e.wpn; if (!w) return; e.wpn = null;
  if (flyParts.length >= 8 || e.noWpn) { killMesh(w); return; } // noWpn: his spear was out
  w.material.transparent = true;
  flyParts.push({ m: w, vx: (Math.random() - 0.5) * 3 + (e.face < 0 ? -1.5 : 1.5), vy: 4.2, vz: (Math.random() - 0.5) * 1.5, spin: (Math.random() < 0.5 ? -1 : 1) * 13, life: 0.6 });
}
function freeFoeFx(e) { teleFree(e); if (e.tg2) { teleRelease(e.tg2); e.tg2 = null; } endSmear(e); if (e.laser) { releaseLaser(e.laser); e.laser = null; } if (e.streak) { e.streak.grow = false; e.streak = null; } e.pthN = 0; if (e.type === 'mimiclord' && tongueM) tongueM.visible = false; }
function resetFoeFx() {
  for (const s of smears) { scene.remove(s.m); smearPool.push(s); } smears.length = 0;
  for (const c of cracks) { scene.remove(c.d, c.h); crackPool.push(c); } cracks.length = 0;
  for (const a of afters) { scene.remove(a.g); afterPool[a.sh].push(a.g); } afters.length = 0;
  for (const f of flyParts) killMesh(f.m); flyParts.length = 0;
  foeHaz.length = 0; shocks.length = 0;
  for (const s of lavaStreaks) s.on = false; for (const c of coinFx) c.on = false; coinFxMesh.count = 0;
  if (tongueM) scene.remove(tongueM);
  for (const r of rocks) if (r.on) rockFree(r); rockMesh.count = rockEdge.count = rockHot.count = 0;
  for (const sp of spears) if (sp.on) spearFree(sp);
  for (const f of fballs) if (f.on) fballFree(f);
}
function updateFoeFx(dt) {
  for (let i = smears.length - 1; i >= 0; i--) {
    const s = smears[i];
    if (s.life < 0) { if (s.e.dead || s.e.smear !== s) s.life = 0.1; else continue; }
    s.life -= dt; s.u.uAlpha.value = Math.max(0, s.life / 0.14);
    if (s.life <= 0) { scene.remove(s.m); smearPool.push(s); smears.splice(i, 1); }
  }
  for (let i = cracks.length - 1; i >= 0; i--) {
    const c = cracks[i]; c.life -= dt;
    c.d.material.opacity = 0.75 * clamp(c.life / 0.8, 0, 1); c.h.material.opacity = clamp((c.life - 1.2) / 1.4, 0, 1);
    if (c.life <= 0) { scene.remove(c.d, c.h); crackPool.push(c); cracks.splice(i, 1); }
  }
  for (let i = afters.length - 1; i >= 0; i--) {
    const a = afters[i]; a.life -= dt; a.g.material.uniforms.uAlpha.value = 0.45 * Math.max(0, a.life / 0.24);
    if (a.life <= 0) { scene.remove(a.g); afterPool[a.sh].push(a.g); afters.splice(i, 1); }
  }
  for (let i = flyParts.length - 1; i >= 0; i--) {
    const f = flyParts[i], m = f.m; f.life -= dt; f.vy -= 22 * dt;
    m.position.x += f.vx * dt; m.position.y = Math.max(0.05, m.position.y + f.vy * dt); m.position.z += f.vz * dt;
    m.rotateZ(f.spin * dt); m.material.uniforms.uAlpha.value = clamp(f.life / 0.3, 0, 1);
    if (f.life <= 0) { killMesh(m); flyParts.splice(i, 1); }
  }
  for (let i = shocks.length - 1; i >= 0; i--) {
    const s = shocks[i]; s.t += dt;
    const k = s.t / s.dur, rad = lerp(0.3, s.R, 1 - Math.pow(1 - Math.min(1, k), 3)) * 0.86;
    if (fxP(0.8)) { const a = Math.random() * 6.28; spark(s.x + Math.cos(a) * rad, 0.15, s.z + Math.sin(a) * rad, s.col, { vy: 1.5, s: 0.35, life: 0.3, drag: 1 }); }
    if (!s.hit && player.alive && Math.abs(Math.hypot(player.x - s.x, player.z - s.z) - rad) < 0.32 + player.r * 0.5) { s.hit = true; damagePlayer(s.dmg, s.x, s.z); }
    if (k >= 1) shocks.splice(i, 1);
  }
  for (let i = foeHaz.length - 1; i >= 0; i--) {
    const h = foeHaz[i]; h.life -= dt; h.cd -= dt;
    const age = h.max - h.life - (h.delay || 0), lava = h.kind === 'lava';
    if (age < 0) { // the ember tell: a dim glowing spot and a few rising sparks, harmless, then it flares up
      const k = 1 + age / h.delay;
      gfxPut(darkBatch, h.x, 0.025, h.z, h.r * 0.9 * k, h.rot, 0x000000, 0.35 * k);
      gfxPut(emberBatch, h.x, 0.04, h.z, h.r * (0.35 + 0.35 * k), h.rot + 1, 0xff6a1a, 0.35 + 0.35 * k * (0.7 + 0.3 * Math.sin(G.time * 30)));
      if (fxP(0.12)) spark(h.x + rr(-0.3, 0.3) * h.r, 0.08, h.z + rr(-0.3, 0.3) * h.r, 0xffb040, { vy: rr(0.8, 1.6), s: 0.14, life: 0.4, drag: 0.5 });
      continue;
    }
    const fin = Math.min(1, age / 0.15), fade = fin * clamp(h.life / 0.45, 0, 1);
    gfxPut(darkBatch, h.x, 0.025, h.z, h.r * (lava ? 1.4 : 1.3), h.rot, 0x000000, (lava ? 0.8 : 0.6) * fade); // a soft scorch / cooled crust, no spiky rim (it read as black sawblades)
    gfxPut(emberBatch, h.x, 0.04, h.z, h.r * (lava ? 1.05 : 0.95), h.rot + 1, lava ? 0xff5a10 : 0xff8a2a, (lava ? 0.95 : 0.85) * fade * (0.85 + 0.15 * Math.sin(G.time * 9 + h.x * 3)));
    const fh = h.r * (lava ? 0.9 : 1.45) * (0.75 + 0.25 * Math.sin(G.time * 13 + h.z * 5)) * fade;
    gfxFlame(flameBatch, h.x + Math.sin(G.time * 3 + h.rot) * h.r * 0.25, 0.02, h.z, fh * 0.55, fh, Math.sin(G.time * 5 + h.x) * 0.1 * fh, 0xffffff, 0.6 * fade);
    if (!lava) { // fire: a cluster of licking tongues, not one
      for (let q = 0; q < 2; q++) { const a = h.rot + q * 3.1, fq = fh * (0.6 + 0.25 * Math.sin(G.time * 17 + q * 2 + h.x)); gfxFlame(flameBatch, h.x + Math.cos(a) * h.r * 0.45, 0.02, h.z + Math.sin(a) * h.r * 0.35, fq * 0.5, fq, Math.sin(G.time * 6 + q + h.z) * 0.12 * fq, 0xffffff, 0.55 * fade); }
    }
    if (fxP(lava ? 0.15 : 0.12)) spark(h.x + rr(-0.5, 0.5) * h.r, 0.1, h.z + rr(-0.5, 0.5) * h.r, Math.random() < 0.5 ? 0xffd25a : 0xff6a1a, { vy: rr(1.4, 2.4), s: 0.18, life: 0.6, drag: 0.5 });
    if (h.cd <= 0 && fin >= 1 && player.alive && Math.hypot(player.x - h.x, player.z - h.z) < h.r * 0.85 + player.r * 0.4) { h.cd = 1; damagePlayer(1, h.x, h.z); }
    if (h.life <= 0) foeHaz.splice(i, 1);
  }
  for (const s of lavaStreaks) { // lava streaks: crust under-layer + one stretched glowing ribbon; hot (it hurts) until it has cooled
    if (!s.on) continue;
    if (!s.grow) s.life -= dt; s.cd -= dt;
    if (s.life <= 0) { s.on = false; continue; }
    const dx = s.x1 - s.x0, dz = s.z1 - s.z0, l = Math.hypot(dx, dz), mx = (s.x0 + s.x1) / 2, mz = (s.z0 + s.z1) / 2, rot = -Math.atan2(dz, dx), k = s.life / s.max, fade = clamp(s.life / 0.5, 0, 1);
    if (l < 0.05) continue;
    gfxPut2(darkBatch, mx, 0.026, mz, l / 2 + 0.45, 0.62, rot, 0x000000, 0.7 * fade);
    _sc.setRGB(1, 0.3 + 0.7 * k * k, 0.15 + 0.85 * k * k * k);
    gfxPut2(streakBatch, mx, 0.045, mz, l / 2 + 0.35, 0.42, rot, _sc.getHex(), (0.55 + 0.45 * k) * fade * (0.9 + 0.1 * Math.sin(G.time * 11 + s.x0)));
    if (fxP(0.25 * k)) { const u = Math.random(); spark(s.x0 + dx * u + rr(-0.2, 0.2), 0.1, s.z0 + dz * u + rr(-0.2, 0.2), Math.random() < 0.5 ? 0xffd25a : 0xff5a10, { vy: rr(1, 2.2), s: 0.18, life: 0.5, drag: 0.5 }); }
    if (k > 0.25 && s.cd <= 0 && player.alive) { // Pip on the hot ribbon
      const px = player.x - s.x0, pz = player.z - s.z0, u = clamp((px * dx + pz * dz) / (l * l), 0, 1), d = Math.hypot(px - dx * u, pz - dz * u);
      if (d < 0.38 + player.r * 0.4) { s.cd = 1; damagePlayer(1, s.x0 + dx * u, s.z0 + dz * u); }
    }
  }
  for (const e of enemies) {
    if (e.dead) continue;
    if (e.pthN > 1) drawPath(e); // marked paths (sickle loops, gear lanes)
    if (e.thrown) gfxPut(darkBatch, e.skx, 0.03, e.skz, 0.32, 0, 0x000000, 0.5); // the flying sickle's shadow
    if (e.type === 'sporeboss') { // rooted: dirt and roots at her base; the moving mound while she tunnels
      if (e.root > 0.05) { gfxPut(darkBatch, e.x, 0.024, e.z, e.r * 1.5, 0, 0x000000, 0.7 * e.root); gfxPut(dirtBatch, e.x, 0.03, e.z, e.r * 1.75 * (0.6 + 0.4 * e.root), 0.7, 0xffffff, e.root); }
      if (e.state === 'tunnel' || e.state === 'mark') { const b = e.state === 'mark' ? 1 + 0.3 * (1 - e.st / e.markT) : 1; gfxPut(darkBatch, e.x, 0.03, e.z, 1.3 * b, 0, 0x000000, 0.6); gfxPut(dirtBatch, e.x, 0.035, e.z, 1.25 * b * (1 + 0.06 * Math.sin(G.time * 30)), G.time * 2, 0xffffff, 1); }
    }
    if (e.type === 'mimiclord' || e.type === 'mimic') gfxPut(darkBatch, e.x, 0.024, e.z, e.r * 1.35, 0, 0x000000, 0.65 * clamp(1 - e.y * 1.4, 0.2, 1)); // planted: a contact shadow
  }
  updateCoinFx(dt); updateRocks(dt); updateSpears(dt); updateFballs(dt);
}
// a melee blow's active frame: Pip is hit if he is within reach and inside the arc in front (cosA = arc half-width)
function foeStrike(e, ax, az, reach, cosA, dmg) {
  if (!player.alive) return false;
  const dx = player.x - e.x, dz = player.z - e.z, d = Math.hypot(dx, dz) || 1;
  if (d > e.r + reach + player.r || (dx * ax + dz * az) / d < cosA) return false;
  damagePlayer(dmg, e.x, e.z); return true;
}
function lineStrike(e, fx, fz, len, half, dmg) { // a thrust: Pip inside the lane in front
  const px = player.x - e.x, pz = player.z - e.z, along = px * fx + pz * fz, perp = Math.abs(pz * fx - px * fz);
  if (!player.alive || along < 0 || along > len + player.r || perp > half + player.r) return false;
  damagePlayer(dmg, e.x, e.z); return true;
}
function slashImpact(x, z, col, heavy) {
  spark(x, 0.6, z, 0xffffff, { s: heavy ? 1.3 : 0.9, life: 0.08, drag: 0 });
  for (let k = 0; k < (heavy ? 9 : 6); k++) spark(x, 0.55, z, Math.random() < 0.4 ? 0xffffff : col, { vx: rr(-5, 5), vy: rr(1, 4), vz: rr(-5, 5), s: 0.22, life: 0.25, drag: 5 });
  chunkDust(x, z, 0xa89a8a);
}
function blockFx(e, x, z, word) { // a shield or shell turns the hit: clink + sparks, and a tiny word at most every 0.7 s
  spark(x, 0.65, z, 0xffffff, { s: 1.1, life: 0.07, drag: 0 });
  for (let k = 0; k < 6; k++) spark(x, 0.65, z, k % 2 ? 0xfff2a0 : 0xffffff, { vx: rr(-4, 4), vy: rr(1.5, 4), vz: rr(-4, 4), s: 0.18, life: 0.22, drag: 4, grav: -6 });
  sfx('clink');
  if (G.time > (e.blockT || 0)) { e.blockT = G.time + 0.7; addText(e.x, 1.3, e.z, word, '#dfe4ff', 0.6); }
}
// shield / shell checks from hurtEnemy: returns the share of the hit that lands (0 = turned aside)
function foeGuard(e, kx, kz) {
  if (e.type === 'cursed' && e.guard && e.state === 'idle') { // its old shield takes one hit, then it lunges back at once
    e.guard = false; e.guardT = 4; blockFx(e, e.x - e.face * 0.3, e.z, 'BLOCK');
    const dx = player.x - e.x, dz = player.z - e.z, d = Math.hypot(dx, dz) || 1; skelWind(e, dx / d, dz / d, 0.32); return 0;
  }
  if (e.type === 'shieldk' && !e.open) { // the tower shield turns hits from the front: flank it, or hit it after its thrust
    const kl = Math.hypot(kx, kz), fx = Math.cos(e.fa || 0), fz = Math.sin(e.fa || 0);
    if (kl > 0.01 && (kx * fx + kz * fz) / kl < -0.25) { blockFx(e, e.x + fx * 0.5, e.z + fz * 0.5, 'BLOCK'); return 0.15; }
  }
  if (e.type === 'beetle' && (e.state === 'curl' || e.state === 'roll')) { blockFx(e, e.x, e.z, 'SHELL'); return 0; }
  return 1;
}
// ---- skeleton family: fast sword melee. Each swing: [from angle, to angle, seconds, step speed, damage]
const SKEL_ATK = {
  skeleton: { wind: 0.5, reach: 0.7, col: 0xfff0d8, tell: 0xff3050, sw: [[1.15, -2.0, 0.2, 9, 1]] }, // wound up beside the head, not across the skull
  cursed: { wind: 0.45, reach: 0.75, col: 0xffc070, tell: 0xff3050, sw: [[1.2, -2.1, 0.2, 9.5, 1]] },
  reaper: { wind: 0.42, reach: 0.8, col: 0xb8ff7a, tell: 0x9aff5a, sw: [[1.15, -1.9, 0.16, 11, 1], [-1.9, 1.3, 0.17, 7, 1]] }, // sickle: down, then back up
  boneknight: { wind: 0.55, reach: 0.8, col: 0xffa040, tell: 0xff6a20, sw: [[1.15, -1.8, 0.15, 6, 1], [-1.8, 1.4, 0.15, 6, 1], [1.3, -2.2, 0.2, 8, 2]] }, // 3-hit combo, the last one heavy
};
function skelWind(e, ux, uz, w) {
  freeFoeFx(e); e.state = 'wind'; e.st = e.wind = w; e.lx = ux; e.lz = uz; e.tg = teleGet('sector', SKEL_ATK[e.type].tell);
}
function skelSwing(e, A) { const S = A.sw[e.si]; e.state = 'swing'; e.st = S[2]; e.wyS = Math.abs(S[0] - S[1]) > 2.5 && S[0] > 0 ? e.mesh.userData.bh * 0.3 : (e.wy || 0); e.hitDone = false; addSmear(e, A.col, e.wa); sfx('swing'); }
function skelHit(e, A, S) {
  const reach = A.reach + 0.25, ix = e.x + e.lx * (e.r + reach * 0.7), iz = e.z + e.lz * (e.r + reach * 0.7), heavy = S[4] > 1;
  // the marker is the truth: every blow (a combo's later ones too) hits only inside the sector the wind-up showed
  const hit = inMark(e.mk); if (hit) damagePlayer(S[4], e.x, e.z);
  e.hs = hit ? 0.07 : 0.035; e.flash = Math.max(e.flash, hit ? 0.9 : 0.45); // the blade bites: freeze + white flash
  slashImpact(ix, iz, A.col, heavy);
  if (heavy) { addRing(ix, iz, 0.2, 1.4, 0.3, A.tell); addCrack(ix, iz, 0.9, 0xff8a3a); addShake(0.22); sfx('thud'); }
}
function updateSkelFam(e, dt, dx, dz, dist, ux, uz) {
  const A = SKEL_ATK[e.type], crawl = e.type === 'reaper';
  e.wCol = A.tell;
  if (e.state === 'idle') {
    e.faceLock = 0; e.mx = ux * e.speed; e.mz = uz * e.speed;
    if (crawl) { e.tilt = Math.sin(e.t * 12) * 0.08; e.y = 0; e.sy = 0.95 + Math.abs(Math.sin(e.t * 12)) * 0.05; e.sx = 1.03; }
    else { e.tilt = Math.sin(e.t * 9) * 0.14; e.y = Math.abs(Math.sin(e.t * 9)) * 0.06; }
    e.wa = lerp(e.wa, 0.15 * Math.sin(e.t * 9), damp(10, dt)); e.wGlow = 0; e.wy = 0; e.wfx = 0; e.wsc = 1;
    if (e.type === 'cursed') {
      if (!e.guard && (e.guardT -= dt) <= 0) { e.guard = true; spark(e.x - e.face * 0.3, 0.6, e.z, 0xfff2a0, { s: 0.7, life: 0.15, drag: 0 }); }
      if (e.guard && fxP(0.03)) spark(e.x - e.face * 0.32, 0.4 + Math.random() * 0.4, e.z, 0xfff2a0, { s: 0.3, life: 0.2, drag: 0 }); // the raised shield glints
    }
    if (dist < (crawl ? 2.7 : e.type === 'boneknight' ? 2.1 : 1.9) && e.st <= 0) skelWind(e, ux, uz, A.wind);
  } else if (e.state === 'wind') {
    const k = 1 - e.st / e.wind;
    if (k < 0.6) { e.lx = ux; e.lz = uz; } // aims until 60% in, then commits: the rest is a fair dodge window
    e.faceLock = e.lx > 0 ? 1 : -1;
    e.wa = lerp(e.wa, A.sw[0][0], ease3(k * 1.4)); e.wGlow = k * 0.75;
    e.wy = e.mesh.userData.bh * 0.3 * ease3(k * 1.3); e.wsc = 1 + 0.25 * ease3(k * 1.5); // the sword hand goes up high: an overhead chop
    e.tint = k; e.tilt = -e.faceLock * 0.3 * k; e.sy = 1 + 0.1 * k; e.sx = 1 - 0.05 * k; e.y = 0;
    if (crawl) e.sy *= 0.94;
    if (k > 0.7) e.shake = 0.03;
    const S = A.sw[0]; teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.r + A.reach + S[3] * S[2] * 0.6 * A.sw.length ** 0.5, 0, k);
    if (e.st <= 0) { teleFree(e); e.tint = 0; e.wGlow = 0; e.si = 0; skelSwing(e, A); }
  } else if (e.state === 'swing') {
    const S = A.sw[e.si], p = 1 - e.st / S[2], mv = S[3] * (1 - p * 0.6);
    e.mx = e.lx * mv; e.mz = e.lz * mv; e.faceLock = e.lx > 0 ? 1 : -1;
    e.wa = lerp(S[0], S[1], ease3(Math.min(1, p / 0.7))); e.wy = lerp(e.wyS, 0, ease3(Math.min(1, p / 0.6))); e.wfx = 0.12 * Math.sin(Math.min(1, p / 0.7) * Math.PI);
    e.sx = 1.15; e.sy = crawl ? 0.85 : 0.9; e.tilt = e.faceLock * (S[1] < S[0] ? 0.45 : -0.25); e.y = 0;
    if (!e.hitDone && p >= 0.35) { e.hitDone = true; skelHit(e, A, S); }
    if (e.st <= 0) {
      endSmear(e);
      if (++e.si < A.sw.length) { e.state = 'gap'; e.gapFrom = e.wa; e.st = e.gapDur = Math.abs(A.sw[e.si][0] - e.wa) > 1 ? 0.2 : 0.05; }
      else { e.state = 'recover'; e.st = 0.4; }
    }
  } else if (e.state === 'gap') { // combo: the weapon is drawn back for the next swing
    const k = 1 - e.st / e.gapDur; e.wa = lerp(e.gapFrom, A.sw[e.si][0], ease3(k)); e.wGlow = k * 0.6; if (A.sw[e.si][0] > 2) e.wy = e.mesh.userData.bh * 0.3 * ease3(k); e.mx = e.lx * 1.5; e.mz = e.lz * 1.5;
    if (k > 0.5) { e.lx = lerp(e.lx, ux, 0.2); e.lz = lerp(e.lz, uz, 0.2); const l = Math.hypot(e.lx, e.lz) || 1; e.lx /= l; e.lz /= l; } // a combo re-aims a little
    if (e.st <= 0) { e.wGlow = 0; skelSwing(e, A); }
  } else if (e.state === 'recover') {
    const k = 1 - e.st / 0.4; e.wa = lerp(e.wa, 0, damp(9, dt)); e.wy = lerp(e.wy || 0, 0, damp(9, dt)); e.wsc = lerp(e.wsc || 1, 1, damp(6, dt)); e.wfx = 0; e.sx = 1 + 0.08 * (1 - k); e.sy = 1 - 0.08 * (1 - k); e.tilt = (e.faceLock || 1) * 0.15 * (1 - k);
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.1, 1.7) + (e.type === 'boneknight' ? 0.5 : 0); e.faceLock = 0; }
  }
}
// ---- grave reaper (user 11-14): THROWS its sickle. It spins out along a marked loop, curves round and comes back to the
// reaper; it hits once on the way out and once on the way back. The whole loop is marked (green band = the sickle's hit
// radius) during the wind-up and stays marked while it flies. The reaper stands empty-handed until it catches it.
const SK_R = 0.42, SK_COL = 0x9aff5a;
function reaperLoop(e, a, L, side) { // samples the loop: straight out along a (through where you stand), a turn past you, home on a wide arc to one side
  pthClear(e); e.pthW = SK_R; e.pthCol = SK_COL;
  const fx = Math.cos(a), fz = Math.sin(a), W = Math.min(1.5, L * 0.32) * side;
  for (let i = 0; i <= 28; i++) { const u = i / 28, f = L * Math.sin(Math.PI * u), s = u > 0.5 ? W * Math.sin(2 * Math.PI * (u - 0.5)) : 0; pthAdd(e, e.x + fx * f - fz * s, e.z + fz * f + fx * s); }
}
function reaperPathOk(e) { for (let i = 0; i < e.pthN; i++) if (solid(e.pth[i * 2], e.pth[i * 2 + 1], true)) return false; return true; }
function sickleAt(e, u) { // position on the locked loop (u 0..1), linear between the samples
  const f = clamp(u, 0, 1) * (e.pthN - 1), i = Math.min(e.pthN - 2, Math.floor(f)), t = f - i, P = e.pth;
  e.skx = lerp(P[i * 2], P[i * 2 + 2], t); e.skz = lerp(P[i * 2 + 1], P[i * 2 + 3], t);
}
function updateReaper(e, dt, dx, dz, dist, ux, uz) {
  e.wCol = SK_COL;
  if (e.state === 'idle') { // crawls in to throwing range, backs off if you come close
    e.faceLock = 0; e.thrown = false;
    const want = dist > 4.6 ? 1 : dist < 2.3 ? -0.8 : 0.25 * Math.sin(e.t * 0.8 + e.anim);
    e.mx = (ux * want - uz * 0.35 * Math.sin(e.t * 0.5 + e.anim)) * e.speed; e.mz = (uz * want + ux * 0.35 * Math.sin(e.t * 0.5 + e.anim)) * e.speed;
    e.tilt = Math.sin(e.t * 12) * 0.08; e.y = 0; e.sy = 0.95 + Math.abs(Math.sin(e.t * 12)) * 0.05; e.sx = 1.03;
    e.wa = lerp(e.wa, 0.15 * Math.sin(e.t * 9), damp(10, dt)); e.wGlow = 0; e.wy = 0; e.wfx = 0; e.wsc = 1;
    if (e.st <= 0 && dist < 7.5 && dist > 1.3) { freeFoeFx(e); e.state = 'wind'; e.st = e.wind = 0.62; e.side = -(e.side || 1); e.la = Math.atan2(uz, ux); sfx('bowdraw'); }
  } else if (e.state === 'wind') { // the sickle goes up behind its skull and glows; the loop is marked, then locks
    const k = 1 - e.st / e.wind;
    if (k < 0.6) { // aims, then commits
      e.la = Math.atan2(uz, ux); let L = clamp(dist + 1.4, 3, 6.5);
      for (let tr = 0; tr < 6; tr++) { reaperLoop(e, e.la, L, e.side); if (reaperPathOk(e)) break; if (tr % 2 === 0) e.side = -e.side; else L *= 0.8; }
      e.skL = L;
    }
    e.pthK = k; e.pthA = 1;
    e.faceLock = Math.cos(e.la) > 0 ? 1 : -1;
    e.wa = lerp(e.wa, 2.5, ease3(k * 1.4)); e.wy = e.mesh.userData.bh * 0.32 * ease3(k * 1.3); e.wsc = 1 + 0.25 * ease3(k * 1.5); e.wGlow = k * 0.8;
    e.tint = k * 0.6; e.tilt = -e.faceLock * 0.3 * k; e.sy = 1 + 0.08 * k; e.y = 0; if (k > 0.7) e.shake = 0.03;
    if (e.st <= 0) { // let go: the sickle spins out along the marked loop
      e.state = 'throw'; e.st = e.thT = 0.55 + e.skL * 0.15; e.thrown = true; e.skSpin = 0; e.skHit1 = e.skHit2 = false; e.tint = 0; e.wGlow = 0;
      sickleAt(e, 0); sfx('swing'); sfx('whoosh'); e.squash = 0.4;
      spark(e.skx, 0.7, e.skz, 0xffffff, { s: 0.9, life: 0.07, drag: 0 });
    }
  } else if (e.state === 'throw') { // empty-handed: crouched, one claw out, watching it fly
    const u = 1 - e.st / e.thT;
    e.pthK = 1; e.pthA = 0.75;
    e.wa = 0; e.wy = 0; e.wsc = 1; e.sy = 0.92; e.sx = 1.05; e.tilt = e.faceLock * 0.18; e.y = 0;
    sickleAt(e, u); e.skSpin -= dt * 24 * (e.faceLock || 1);
    if (fxP(0.9)) spark(e.skx + rr(-0.15, 0.15), 0.6, e.skz + rr(-0.15, 0.15), Math.random() < 0.6 ? SK_COL : 0xffffff, { s: 0.35, life: 0.22, drag: 0 }); // the spinning trail
    if (fxP(0.7)) spark(e.skx, 0.62, e.skz, SK_COL, { s: 1.1, life: 0.05, drag: 0 }); // its glow
    if ((u > 0.48 && u < 0.52) && fxP(0.3)) sfx('whoosh');
    const half = u < 0.5 ? 1 : 2;
    if (!(half === 1 ? e.skHit1 : e.skHit2) && player.alive && Math.hypot(player.x - e.skx, player.z - e.skz) < SK_R + player.r * 0.5) { // out once, back once
      if (half === 1) e.skHit1 = true; else e.skHit2 = true;
      damagePlayer(1, e.skx, e.skz); e.hs = 0.07; slashImpact(player.x, player.z, SK_COL, false); spark(e.skx, 0.6, e.skz, 0xffffff, { s: 1.2, life: 0.08, drag: 0 });
    }
    if (e.st <= 0) { // caught
      e.thrown = false; e.state = 'recover'; e.st = 0.45; e.squash = 0.5; e.wa = 1.2; e.wGlow = 0.6; pthClear(e);
      spark(e.x, 0.8, e.z, 0xffffff, { s: 0.8, life: 0.07, drag: 0 }); for (let q = 0; q < 6; q++) spark(e.x, 0.7, e.z, SK_COL, { vx: rr(-3, 3), vy: rr(1, 3), vz: rr(-3, 3), s: 0.2, life: 0.25, drag: 4 }); sfx('clink');
    }
  } else if (e.state === 'recover') {
    e.wa = lerp(e.wa, 0, damp(8, dt)); e.wGlow = lerp(e.wGlow, 0, damp(6, dt)); e.wsc = 1; e.tilt = (e.faceLock || 1) * 0.1;
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.6, 2.3); e.faceLock = 0; }
  } else { e.state = 'idle'; e.thrown = false; }
}
// ---- golem family: slow heavy charger. Up close: a fist raised high and slammed down. At range: fist cocked, charge with
// afterimages, a wall hit = ground-pound shockwave + cracks + a long stun. Variants add a rune ring / crystal shards / lava.
const GOLEM_ATK = { golem: { col: 0xff3050, dust: 0x8a96a0, rk: 0 }, runegolem: { col: 0x7fe8ff, dust: 0x6a70a8, rk: 1 }, crystalgolem: { col: 0xd070ff, dust: 0xd8a868, rk: 2 }, magmagolem: { col: 0xff7a20, dust: 0x5a3a30, rk: 3 } }; // rk: its lobbed rock's kind
const GOLEM_HOT = { runegolem: 0x7fe8ff, crystalgolem: 0xd070ff, magmagolem: 0xff6a10 };
function golemSlam(e, x, z, R, dmg, wall) {
  const A = GOLEM_ATK[e.type];
  e.hs = wall ? 0.09 : 0.07; e.flash = Math.max(e.flash, 0.8);
  addRing(x, z, 0.2, R, 0.35, A.col); addRing(x, z, 0.1, R * 0.55, 0.22, 0xffffff);
  addCrack(x, z, R * 0.8, GOLEM_HOT[e.type] || 0);
  chunk(x, 0.4, z, e.d.chunk, wall ? 10 : 6, 5, 0.14); burst(x, 0.3, z, A.dust, 12, 5, 0.45, 0.5);
  for (let k = 0; k < 10; k++) { const a = k / 10 * 6.283; spark(x, 0.08, z, 0xc8b8a0, { vx: Math.cos(a) * 5.5, vz: Math.sin(a) * 5.5, vy: 0.5, s: 0.38, life: 0.35, drag: 5 }); }
  spark(x, 0.4, z, 0xffffff, { s: 1.6, life: 0.08, drag: 0 });
  addShake(wall ? 0.42 : 0.3); sfx('thud'); if (wall) { sfx('slam'); G.hitstop = Math.max(G.hitstop, 0.035); }
  for (const pot of [...pots]) if (Math.hypot(pot.x - x, pot.z - z) < R) breakPot(pot);
  if (dmg && inMark({ kind: 'ring', x, z, len: R * 0.96 })) damagePlayer(dmg, x, z); // the ring marker's edge
  if (e.type === 'runegolem') addShock(x, z, wall ? 3.4 : 2.8, 0.8, 0x7fe8ff, 1);
  else if (e.type === 'crystalgolem') { // crystal shards spray back off the wall (a fan away from the impact)
    const n = wall ? 7 : 5, a0 = wall ? Math.atan2(-e.lz, -e.lx) : Math.atan2(e.lz, e.lx);
    for (let k = 0; k < n; k++) { const a = a0 + (k - (n - 1) / 2) * (wall ? 0.34 : 0.45), p = enemyShoot(e, a, 5, 0xd070ff, 0.7, 0, 'bolt'), o = wall ? 0.3 : R * 0.9; p.x = x + Math.cos(a) * o; p.z = z + Math.sin(a) * o; } // a punch's shards start at its ring's edge, not on Pip
    burst(x, 0.6, z, 0xe8a8ff, 12, 4, 0.35, 0.4);
  } else if (e.type === 'magmagolem') addFoeHaz(x, z, wall ? 1.0 : 0.85, 3, 'lava');
}
// the ground-smash settings per golem (built once: no per-frame objects)
const GOLEM_SMASH = Object.fromEntries(Object.entries(GOLEM_ATK).map(([t, A]) => [t, { R: 2.5, col: A.col, dust: A.dust, hot: GOLEM_HOT[t] || 0, n: MOBILE ? 3 : 4, spread: 3.6, kind: A.rk, warn: 0.85, after: 1.5 }]));
function golemAtk(e, A, ux, uz, st) { // start an attack: pwind fist slam, gwind ground smash, lgrab rock lob, wind roll
  freeFoeFx(e); e.state = st; e.lx = ux; e.lz = uz;
  if (st === 'pwind') { e.st = 0.6; e.tg = teleGet('ring', A.col); }
  else if (st === 'gwind') { e.st = e.windT = 0.9; e.faceLock = ux > 0 ? 1 : -1; e.tg = teleGet('ring', A.col); sfx('roll'); addShake(0.12); }
  else if (st === 'lgrab') { e.st = 0.42; e.faceLock = ux > 0 ? 1 : -1; }
  else { e.st = 0.85; e.tg = teleGet('lane', A.col); }
}
function updateGolemFam(e, dt, dx, dz, dist, ux, uz) {
  const A = GOLEM_ATK[e.type]; e.wCol = A.col; e.pcd = (e.pcd || 0) - dt;
  const reachX = () => e.x + e.lx * (e.r + 0.75), reachZ = () => e.z + e.lz * (e.r + 0.75);
  if (e.state === 'idle') {
    e.faceLock = 0; e.mx = ux * e.speed; e.mz = uz * e.speed;
    e.tilt = Math.sin(e.t * 5) * 0.1; e.y = Math.abs(Math.sin(e.t * 5)) * 0.05;
    e.wa = lerp(e.wa, 0.12 * Math.sin(e.t * 5 + 1), damp(8, dt)); e.wGlow = 0; e.wy = 0; e.wsc = lerp(e.wsc || 1, 1, damp(5, dt));
    // close: the fist slam, every 3rd time the GROUND SMASH; mid range: roll / rock lob / ground smash in turn (user 11-14)
    if (dist < 2 && e.pcd <= 0) golemAtk(e, A, ux, uz, (e.atk = (e.atk || 0) + 1) % 3 === 0 ? 'gwind' : 'pwind');
    else if (e.st <= 0 && dist < 8.5 && dist > 2.4) { const q = (e.ratk = (e.ratk || 0) + 1) % 3; golemAtk(e, A, ux, uz, q === 2 && dist < 4.5 ? 'gwind' : q === 1 && dist > 3 || dist >= 7 ? 'lgrab' : 'wind'); }
  } else if (e.state === 'gwind' || e.state === 'gslam' || e.state === 'grec') {
    smashStep(e, dt, GOLEM_SMASH[e.type]);
  } else if (e.state === 'lgrab') { // ROCK LOB: it reaches down and rips a boulder out of the floor (debris flies)
    const k = 1 - e.st / 0.42; e.faceLock = e.lx > 0 ? 1 : -1;
    e.wa = lerp(e.wa, -1.25, damp(10, dt)); e.wy = -e.mesh.userData.bh * 0.06 * ease3(k); e.tilt = e.faceLock * 0.22 * k; e.sy = 1 - 0.1 * k; e.sx = 1 + 0.06 * k;
    if (k > 0.45 && fxP(0.6)) { const gx = e.x + e.faceLock * 0.7, gz = e.z + 0.2; spark(gx, 0.1, gz, A.dust, { vx: rr(-2, 2), vy: rr(2, 4), vz: rr(-1, 1), grav: -12, s: 0.35, life: 0.45, drag: 1 }); }
    if (e.st <= 0) {
      const gx = e.x + e.faceLock * 0.7, gz = e.z + 0.2; chunk(gx, 0.3, gz, A.dust, 5, 3, 0.12); addCrack(gx, gz, 0.7, 0); sfx('thud'); e.squash = 0.4; addShake(0.1);
      const tx = player.x, tz = player.z; e.rock = rockSpawn(A.rk, tx, tz, 1.05, 0, 1, { held: true, lob: true, own: e, col: A.col, s: 0.8 });
      e.state = 'lwind'; e.st = e.windT = 0.55;
    }
  } else if (e.state === 'lwind') { // the boulder goes up over its head; the landing ring tracks Pip, then locks
    const k = 1 - e.st / e.windT, r = e.rock;
    e.wa = lerp(e.wa, 2.6, damp(8, dt)); e.wy = e.mesh.userData.bh * 0.14 * ease3(k); e.wsc = 1 + 0.1 * k; e.wGlow = k * 0.6; e.tint = k * 0.5;
    e.tilt = -e.faceLock * 0.18 * k; e.sy = 1 + 0.08 * k; e.sx = 1 - 0.04 * k; if (k > 0.7) e.shake = 0.03;
    if (r && r.on) {
      if (k < 0.6) { let tx = player.x + player.vx * 0.3, tz = player.z + player.vz * 0.3; const l = Math.hypot(tx - e.x, tz - e.z); if (l > 8.5) { tx = e.x + (tx - e.x) * 8.5 / l; tz = e.z + (tz - e.z) * 8.5 / l; } if (!solid(tx, tz, false)) { r.x1 = tx; r.z1 = tz; } }
      partTip(e, _pv); r.x = _pv.x; r.y = _pv.y + 0.25; r.z = _pv.z; r.k0 = 0.35 * k;
    }
    if (e.st <= 0) { // the throw: a high arc to the ring
      e.state = 'lthrow'; e.st = 0.12; e.wGlow = 0; e.tint = 0; addSmear(e, A.col, e.wa); sfx('swing');
      if (r && r.on) { r.held = false; r.x0 = r.x; r.y0 = r.y; r.z0 = r.z; r.t = 0; r.W = 0; r.T = 0.7 + Math.hypot(r.x1 - r.x, r.z1 - r.z) * 0.04; r.h = 2.6; r.k0 = 0.35; }
      e.rock = null;
    }
  } else if (e.state === 'lthrow') {
    const p = 1 - e.st / 0.12; e.wa = lerp(2.6, -0.6, p * p); e.wy = e.mesh.userData.bh * 0.14 * (1 - p); e.tilt = e.faceLock * 0.25; e.sx = 1.08; e.sy = 0.94;
    if (e.st <= 0) { endSmear(e); e.state = 'precover'; e.st = 0.55; e.squash = 0.35; }
  } else if (e.state === 'pwind') { // the fist goes up high; a ring shows where it comes down
    const k = 1 - e.st / 0.6; if (k < 0.5) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
    e.wa = lerp(e.wa, 2.7, damp(9, dt)); e.wy = e.mesh.userData.bh * 0.12 * ease3(k); e.wsc = 1 + 0.12 * ease3(k); e.wGlow = k * 0.8; e.tint = k * 0.6; e.tilt = -e.faceLock * 0.22 * k; e.sy = 1 + 0.07 * k; e.sx = 1 - 0.04 * k;
    if (k > 0.7) e.shake = 0.04;
    teleSet(e.tg, reachX(), reachZ(), 0, 1.3, 0, k);
    if (e.st <= 0) { teleFree(e); e.state = 'pslam'; e.st = 0.11; e.wGlow = 0; e.tint = 0; addSmear(e, A.col, e.wa); sfx('swing'); }
  } else if (e.state === 'pslam') {
    const p = 1 - e.st / 0.11; e.wa = lerp(2.7, -0.35, p * p); e.wy = e.mesh.userData.bh * 0.12 * (1 - p * p); e.tilt = e.faceLock * 0.3; e.sx = 1.1; e.sy = 0.92;
    if (e.st <= 0) { endSmear(e); e.squash = 0.6; golemSlam(e, reachX(), reachZ(), 1.3, 1, false); e.state = 'precover'; e.st = 0.5; e.pcd = rr(1.8, 2.4); }
  } else if (e.state === 'precover') {
    e.wa = lerp(e.wa, 0, damp(4, dt)); e.wy = 0; e.wsc = lerp(e.wsc || 1, 1, damp(5, dt)); e.tilt = e.faceLock * 0.1;
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(0.6, 1); e.faceLock = 0; }
  } else if (e.state === 'wind') { // roll wind-up: it tucks into a boulder (squash, rumble, arm hugged in), the lane fills
    const k = 1 - e.st / 0.85; if (k < 0.55) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
    e.tint = k * 0.8; e.wGlow = k * 0.5; e.shake = 0.03 + k * 0.05; e.tilt = e.faceLock * 0.25 * k; e.sy = 1 - k * 0.22; e.sx = 1 + k * 0.12;
    e.wa = lerp(e.wa, -0.7, damp(6, dt)); e.wsc = 1;
    if (fxP(0.35 * k)) spark(e.x - e.lx * 0.4, 0.06, e.z - e.lz * 0.4, A.dust, { vx: -e.lx * 2.5 + rr(-1, 1), vz: -e.lz * 2.5 + rr(-1, 1), vy: 0.8, s: 0.32, life: 0.4 });
    e.laneL = laneLen(e.x, e.z, e.lx, e.lz, 11.7, e.r); teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.laneL + e.r, e.r * 2.2, k); // the lane = the whole run
    if (e.st <= 0) { teleFree(e); e.state = 'charge'; e.st = e.laneL / 9; e.tint = 0; e.wGlow = 0.35; e.wallHit = false; e.ai = 0; e.spin = 0; e.ct = 0; e.rollSpin = true; sfx('roll'); if (e.type === 'magmagolem') e.streak = addStreak(e.x, e.z); }
  } else if (e.state === 'charge') { // the roll: a spinning boulder straight down the marked lane, ONE line, then it crashes and stops
    e.mx = e.lx * 9; e.mz = e.lz * 9; e.sx = 0.92; e.sy = 0.8;
    e.spin += dt * 9 / Math.max(0.4, e.mesh.userData.bh * 0.4); e.tilt = e.spin; // rolls (about its middle: see rollSpin in updateEnemy)
    e.wa = lerp(e.wa, -0.7, damp(12, dt)); // the arm stays tucked in
    if (Math.random() < 0.8) chunkDust(e.x, e.z, A.dust);
    if ((e.ct -= dt) <= 0) { e.ct = 0.22; addCrack(e.x - e.lx * 0.3, e.z - e.lz * 0.3, 0.55, GOLEM_HOT[e.type] || 0); }
    if ((e.ai -= dt) <= 0) { e.ai = MOBILE ? 0.12 : 0.08; afterImage(e, A.col); }
    if (e.streak) { e.streak.x1 = e.x - e.lx * 0.3; e.streak.z1 = e.z - e.lz * 0.3; } // the lava ribbon grows behind it
    if (e.wallHit || e.st <= 0) { // the end of the lane: it crashes (wall or not), shockwave, then lies stunned and uncurls
      e.state = 'stun'; e.st = 1.6; e.squash = 0.9; e.slamT = 0; e.wGlow = 0; if (e.streak) { e.streak.grow = false; e.streak = null; }
      golemSlam(e, e.x + e.lx * (e.r + 0.3), e.z + e.lz * (e.r + 0.3), 2.0, 0, true);
    }
  } else if (e.state === 'stun') {
    if (e.rollSpin) { const to = Math.round(e.spin / 6.2832) * 6.2832; e.spin = lerp(e.spin, to, damp(9, dt)); e.tilt = e.spin; if (Math.abs(e.spin - to) < 0.03) { e.rollSpin = false; e.spin = 0; } } // uncurls
    if (e.slamT > 0) { e.slamT -= dt; e.wa = lerp(1.45, -0.4, 1 - Math.max(0, e.slamT) / 0.12); }
    else e.wa = lerp(e.wa, -0.15 + Math.sin(e.t * 6) * 0.12, damp(6, dt)); // the arm hangs limp
    e.wsc = lerp(e.wsc || 1, 1, damp(5, dt));
    if (!e.rollSpin) e.tilt = Math.sin(e.t * 12) * 0.12; e.tint = 0; e.faceLock = 0;
    if (fxP(0.3)) spark(e.x + Math.cos(e.t * 6) * 0.4, 1.5, e.z + Math.sin(e.t * 6) * 0.4, 0xffe14f, { s: 0.25, life: 0.3, drag: 0 });
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.5, 2.5); }
  }
}
// ---- spacing (user 11-14: "most monsters keep going close to you even if they shouldn't ... the archer works great, it keeps
// away"): the archer's keep-away step as one helper. B = [preferred distance, strafe] (ENEMY[type].band): steps toward / away
// from Pip in proportion to how far off its distance it is, circles while it is there, and slides along a wall instead of
// backing into it (a cornered caster gets out sideways). Result in e.bmx / e.bmz (no allocation)
function keepBand(e, dist, ux, uz, B = e.d.band, spd = e.speed) {
  const want = B[0], str = B[1] ?? 0.9, tang = Math.sin(e.t * 0.6 + e.anim) > 0 ? 1 : -1;
  let rad = (dist - want) * 0.9, side = tang, tg = str;
  if (rad < 0 && solid(e.x - ux * (e.r + 0.7), e.z - uz * (e.r + 0.7), !!e.d.fly)) { if (!e.wallSide) e.wallSide = tang; side = e.wallSide; rad *= 0.25; tg = Math.max(str, 1.6); } // its back to a wall
  else e.wallSide = 0;
  let mx = ux * rad - uz * side * tg, mz = uz * rad + ux * side * tg;
  const cap = spd * (dist < want - 1.5 ? 1.15 : 1), ml = Math.hypot(mx, mz); if (ml > cap) { mx *= cap / ml; mz *= cap / ml; }
  e.bmx = mx; e.bmz = mz; return ml;
}
// ---- skeleton archer: keeps its distance, a visible aim line that locks, then one fast arrow
function updateArcher(e, dt, dx, dz, dist, ux, uz) {
  e.faceLock = dx > 0 ? 1 : -1;
  if (e.state === 'idle') {
    keepBand(e, dist, ux, uz); e.mx = e.bmx; e.mz = e.bmz;
    const ml = Math.hypot(e.mx, e.mz);
    const wk = Math.min(1, ml); e.tilt = Math.sin(e.t * 9) * 0.1 * wk; e.y = Math.abs(Math.sin(e.t * 9)) * 0.05 * wk;
    if (e.st <= 0 && dist < 10) { freeFoeFx(e); e.state = 'draw'; e.st = 0.85; e.laser = getLaser(0xff2040); e.ax = ux; e.az = uz; sfx('bowdraw'); }
  } else if (e.state === 'draw') {
    const k = 1 - e.st / 0.85; if (k < 0.7) { e.ax = ux; e.az = uz; } // tracks, then locks for the last 0.25 s
    e.tilt = -e.faceLock * 0.14 * k; e.sx = 1 - 0.05 * k; e.sy = 1 + 0.04 * k; e.tint = k * 0.5; if (k > 0.75) e.shake = 0.02;
    const a = Math.atan2(e.az, e.ax); let len = 0.5; while (len < 12 && !solid(e.x + e.ax * len, e.z + e.az * len, true)) len += 0.5;
    if (e.laser) { // a thin dim aim line while it tracks; brighter and flickering once locked
      const L = e.laser, lock = k > 0.7; placeLaser(L, e.x + e.ax * 0.35, 0.55, e.z + e.az * 0.35, a, len - 0.35, lock ? 0.6 : 0.1, 0, 0xff2040);
      L.core.scale.z = lock ? 0.05 : 0.025; L.core.scale.y = 0.03; L.glow.scale.z = lock ? 0.16 : 0.08;
      L.core.material.opacity = lock ? 0.6 + 0.4 * Math.sin(G.time * 50) : 0.18 + 0.3 * k; L.glow.material.opacity = lock ? 0.3 : 0.08;
    }
    if (e.st <= 0) {
      if (e.laser) { releaseLaser(e.laser); e.laser = null; }
      enemyShoot(e, a, 12 + G.floor * 0.2, 0xffe6b0, 0.6, 0, 'arrow');
      e.state = 'loose'; e.st = 0.3; e.squash = 0.4; e.tint = 0; e.kx -= e.ax * 2; e.kz -= e.az * 2; sfx('twang');
      spark(e.x + e.ax * 0.4, 0.6, e.z + e.az * 0.4, 0xffffff, { s: 0.8, life: 0.07, drag: 0 });
    }
  } else if (e.state === 'loose') { e.tilt = e.faceLock * 0.1; if (e.st <= 0) { e.state = 'idle'; e.st = rr(2, 2.8); } }
}
// ---- crystal spider (packs): skitters in bursts, crouches, pounces onto a marked spot, pauses
function updateSpider(e, dt, dx, dz, dist, ux, uz) {
  if (e.state === 'idle') {
    e.y = 0; e.faceLock = 0;
    if ((e.bt = (e.bt || 0) - dt) <= 0) { e.bt = rr(0.3, 0.55); e.go = !e.go; const a = Math.atan2(uz, ux) + rr(-0.9, 0.9); e.jx = Math.cos(a); e.jz = Math.sin(a); if (e.go && fxP(0.5)) sfx('skitter'); }
    if (e.go) { e.mx = e.jx * e.speed * 1.4; e.mz = e.jz * e.speed * 1.4; e.sy = 1 + Math.sin(e.t * 30) * 0.06; e.tilt = Math.sin(e.t * 30) * 0.08; }
    if (e.st <= 0 && dist < 4.2 && dist > 0.5) { const L = clamp(dist - e.r - player.r, 0.1, 3.4); /* lands touching Pip, not on him */ e.tx = e.x + ux * L; e.tz = e.z + uz * L; e.state = 'crouch'; e.st = 0.42; e.tg = teleGet('ring', 0x8fe8ff); e.faceLock = ux > 0 ? 1 : -1; }
  } else if (e.state === 'crouch') {
    const k = 1 - e.st / 0.42; e.sx = 1 + 0.25 * k; e.sy = 1 - 0.3 * k; e.shake = 0.02; e.tint = k * 0.5;
    teleSet(e.tg, e.tx, e.tz, 0, 0.7, 0, k);
    if (e.st <= 0) { e.state = 'leap'; e.st = 0.36; e.jx = (e.tx - e.x) / 0.36; e.jz = (e.tz - e.z) / 0.36; e.tint = 0; sfx('skitter'); }
  } else if (e.state === 'leap') {
    const p = 1 - e.st / 0.36; e.y = Math.sin(p * Math.PI) * 0.9; e.mx = e.jx; e.mz = e.jz; e.sx = 0.85; e.sy = 1.2; e.tilt = -e.faceLock * 0.5 * (p - 0.5); e.noContact = true;
    if (e.st <= 0) {
      teleFree(e); e.y = 0; e.squash = 0.6; e.state = 'pause'; e.st = rr(0.6, 0.9); e.hs = 0.04;
      addRing(e.x, e.z, 0.1, 0.8, 0.2, 0x8fe8ff); chunkDust(e.x, e.z, 0x8fe8ff);
      if (inMark(e.mk)) { damagePlayer(1, e.x, e.z); e.flash = 0.8; } // the landing ring is the truth
    }
  } else if (e.state === 'pause') { e.sx = 1 + Math.sin(e.t * 20) * 0.03; if (e.st <= 0) { e.state = 'idle'; e.st = rr(0.9, 1.6); e.faceLock = 0; } }
}
// ---- fire salamander (user 11-14: "looks drugged, never stops"): a lizard rhythm. Quick skitter bursts (0.3-0.6 s dash, body
// wiggle, one heading per burst, a burning trail) then FULL STOPS (0.5-1.2 s frozen: a head / tail flick, a lick of flame, it
// looks at Pip). The fiery bite only comes out of a stop
function updateSalamander(e, dt, dx, dz, dist, ux, uz) {
  e.y = 0;
  if (e.state === 'idle') {
    e.faceLock = 0;
    if ((e.bt = (e.bt ?? rr(0.2, 0.5)) - dt) <= 0) {
      e.go = !e.go;
      if (e.go) { e.bt = rr(0.3, 0.6); const a = Math.atan2(uz, ux) + (dist < 2.2 ? (rand() < 0.5 ? 1 : -1) * rr(1.1, 1.8) : rr(-0.6, 0.6)); e.jx = Math.cos(a); e.jz = Math.sin(a); if (fxP(0.6)) sfx('skitter'); }
      else { e.bt = rr(0.5, 1.2); e.stopT = 0; e.squash = 0.25; }
    }
    if (e.go) { // the burst: fast, low, wiggling; fire only now
      e.mx = e.jx * e.speed * 1.3; e.mz = e.jz * e.speed * 1.3; e.tilt = Math.sin(e.t * 34) * 0.1; e.sx = 1.06 + Math.sin(e.t * 34) * 0.06; e.sy = 0.94;
      if ((e.ft = (e.ft || 0) - dt) <= 0) { e.ft = 0.24; if (Math.hypot(player.x - e.x, player.z - e.z) > 1.3) addFoeHaz(e.x, e.z, 0.42, 1.7, 'fire', 0.4); } // never under Pip; an ember first, then it flares
    } else { // the stop: frozen, a flick now and then, watching Pip
      e.stopT = (e.stopT || 0) + dt; e.faceLock = dx > 0 ? 1 : -1;
      const fl = (e.stopT * 1.7 + e.anim) % 1; e.tilt = fl < 0.12 ? Math.sin(fl / 0.12 * Math.PI) * 0.14 : 0; // head / tail flick
      if (fl > 0.55 && fl < 0.62 && fxP(0.5)) spark(e.x + e.faceLock * 0.32, 0.25, e.z, 0xffb040, { vx: e.faceLock * 1.6, vy: 0.4, s: 0.28, life: 0.15, drag: 2 }); // a lick of flame
      if (e.st <= 0 && dist < 2.0 && e.stopT > 0.25) { freeFoeFx(e); e.state = 'wind'; e.st = 0.34; e.lx = ux; e.lz = uz; e.faceLock = ux > 0 ? 1 : -1; e.tg = teleGet('sector', 0xff7a20); }
    }
  } else if (e.state === 'wind') {
    const k = 1 - e.st / 0.34; e.sx = 1 - 0.15 * k; e.sy = 1 + 0.15 * k; e.tilt = -e.faceLock * 0.35 * k; e.tint = k; e.shake = 0.03;
    if (fxP(0.5)) spark(e.x + e.lx * 0.35, 0.3, e.z + e.lz * 0.35, 0xffb040, { vy: 1.2, s: 0.25, life: 0.25 });
    teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.r + 1.5, 0, k);
    if (e.st <= 0) { teleFree(e); e.tint = 0; e.state = 'lunge'; e.st = 0.16; e.hitDone = false; sfx('fire'); clawSmear(e, Math.atan2(e.lz, e.lx), 0xff8a2a); } // the jaw snap
  } else if (e.state === 'lunge') {
    e.mx = e.lx * 10; e.mz = e.lz * 10; e.sx = 1.3; e.sy = 0.8; e.tilt = e.faceLock * 0.3;
    if (fxP(0.8)) spark(e.x + e.lx * 0.4, 0.3, e.z + e.lz * 0.4, 0xff8a1a, { vx: e.lx * 4, vz: e.lz * 4, vy: 1, s: 0.35, life: 0.25 });
    if (!e.hitDone && e.st < 0.08) {
      e.hitDone = true; const hit = inMark(e.mk); if (hit) damagePlayer(1, e.x, e.z); // the wind-up's sector is the truth
      e.hs = hit ? 0.06 : 0.03; if (hit) e.flash = 0.8;
      burst(e.x + e.lx * 0.55, 0.35, e.z + e.lz * 0.55, 0xff7a1a, 10, 4, 0.35, 0.35); spark(e.x + e.lx * 0.55, 0.4, e.z + e.lz * 0.55, 0xffe08a, { s: 0.9, life: 0.08, drag: 0 });
    }
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.3, 1.9); e.faceLock = 0; e.go = false; e.bt = rr(0.5, 0.8); e.stopT = 0; } // a stop after the bite
  } else e.state = 'idle';
}
// ---- shield knight: turns slowly to face you behind a tower shield (frontal hits are turned aside), spear thrust, then open.
// The spear points and thrusts along its facing as seen on screen (it used to poke screen-right whatever the lane): pulled
// back with a glint on the tip, then driven down the lane with a white streak along it
const _sv1 = new THREE.Vector3(), _sv2 = new THREE.Vector3();
function spearAim(e, fx, fz) { // the spear part's angle for a world direction (fx, fz), as the camera sees it
  _sv1.set(e.x, 0.55, e.z).project(camera); _sv2.set(e.x + fx, 0.55, e.z + fz).project(camera);
  const sx = (_sv2.x - _sv1.x) * camera.aspect, sy = _sv2.y - _sv1.y, th = Math.atan2(sy, sx);
  if (Math.abs(sx) > 0.02) e.faceLock = sx > 0 ? 1 : -1;
  const t0 = PARTS.shieldk.tip[0] * Math.PI / 180;
  e.wa = e.faceLock > 0 ? th - t0 : Math.PI - t0 - th; e.wxDir = th; e.wFront = fz > 0.35;
}
// (user 11-14) a real pike reach: the poke lane is ~2.5 tiles (marker = hit) and he holds that distance instead of walking in.
// At mid range he THROWS the spear: shield planted, spear drawn back over the shoulder while the lane to the wall fills, then it
// flies straight down the lane (spinning a little, a streak behind it) and sticks in the wall or the floor where it stops. He walks
// over to pull it out; until then no poke (a window to flank him). The frontal block stays
const PIKE = 2.0, SPEAR_SPD = 17, SPEAR_MAX = 9;
const spearShaftGeo = new THREE.CylinderGeometry(0.035, 0.04, 1.5, 6).rotateZ(-Math.PI / 2), spearTipGeo = new THREE.ConeGeometry(0.075, 0.3, 6).rotateZ(-Math.PI / 2).translate(0.88, 0, 0);
const spearShaftMat = new THREE.MeshLambertMaterial({ color: 0x6a4a32 }), spearTipMat = new THREE.MeshLambertMaterial({ color: 0xe8ecf8, emissive: 0x30303a });
const spears = Array.from({ length: 4 }, () => ({ on: false }));
function spearFree(sp) { sp.on = false; if (sp.g) scene.remove(sp.g); if (sp.own && sp.own.spear === sp) sp.own.spear = null; }
function spearThrow(e, fx, fz, L) {
  const sp = spears.find((q) => !q.on); if (!sp) return null;
  if (!sp.g) { sp.g = new THREE.Group(); sp.g.add(new THREE.Mesh(spearShaftGeo, spearShaftMat), new THREE.Mesh(spearTipGeo, spearTipMat)); sp.g.rotation.order = 'YXZ'; }
  sp.on = true; sp.own = e; sp.fx = fx; sp.fz = fz; sp.ang = Math.atan2(fz, fx); sp.x0 = e.x + fx * e.r; sp.z0 = e.z + fz * e.r; sp.L = Math.max(0.3, L - e.r); sp.d = 0; sp.stuck = false; sp.hit = false; sp.wob = 0; sp.mk = e.mk; sp.wall = L < SPEAR_MAX - 0.3; sp.roll = 0;
  sp.x = sp.x0; sp.z = sp.z0; scene.add(sp.g); return sp;
}
function updateSpears(dt) {
  for (const sp of spears) {
    if (!sp.on) continue;
    if (!sp.own || sp.own.dead) { spearFree(sp); continue; }
    const g = sp.g;
    if (!sp.stuck) {
      const d0 = sp.d; sp.d = Math.min(sp.L, sp.d + SPEAR_SPD * dt); sp.x = sp.x0 + sp.fx * sp.d; sp.z = sp.z0 + sp.fz * sp.d; sp.roll += dt * 14;
      if (!sp.hit && player.alive) { // the spear's tip passes Pip: the locked lane is the truth
        const along = (player.x - sp.x0) * sp.fx + (player.z - sp.z0) * sp.fz;
        if (along < sp.d + 0.75 && along > d0 - 0.5 && inMark(sp.mk)) { sp.hit = true; damagePlayer(1, sp.x, sp.z); slashImpact(player.x, player.z, 0xff5070, false); G.hitstop = Math.max(G.hitstop, 0.04); }
      }
      if (fxP(0.9)) spark(sp.x - sp.fx * 0.6, 0.62, sp.z - sp.fz * 0.6, Math.random() < 0.5 ? 0xffffff : 0xff5070, { s: 0.3, life: 0.16, drag: 0 }); // the streak behind it
      if (sp.d >= sp.L) { // it sticks: in the wall (level) or the floor (nose down)
        sp.stuck = true; sp.wob = 0.35; sp.tLeft = 7;
        const tx = sp.x + sp.fx * 0.75, tz = sp.z + sp.fz * 0.75;
        chunkDust(tx, tz, 0xa89a8a); spark(tx, 0.6, tz, 0xffffff, { s: 0.9, life: 0.07, drag: 0 }); for (let q = 0; q < 5; q++) spark(tx, 0.55, tz, 0xfff2a0, { vx: rr(-3, 3) - sp.fx * 2, vy: rr(1, 3), vz: rr(-3, 3) - sp.fz * 2, s: 0.2, life: 0.25, drag: 4 });
        sfx(sp.wall ? 'clink' : 'thud'); addShake(0.08); if (!sp.wall) addCrack(tx, tz, 0.5, 0);
      }
    } else {
      sp.wob = Math.max(0, sp.wob - dt);
      if ((sp.tLeft -= dt) <= 0) { burst(sp.x, 0.5, sp.z, 0xd8c0ff, 8, 2, 0.3, 0.4); sp.own.hasSpear = true; spearFree(sp); continue; } // never stuck out of reach for good
    }
    const pitch = sp.stuck && !sp.wall ? 0.6 : 0, wob = sp.wob > 0 ? Math.sin(sp.wob * 60) * sp.wob * 0.5 : 0;
    g.position.set(sp.x, sp.stuck && !sp.wall ? 0.36 : 0.6, sp.z); g.rotation.set(sp.stuck ? 0 : sp.roll, -sp.ang + wob, -pitch);
    gfxPut(darkBatch, sp.x, 0.03, sp.z, 0.35, 0, 0x000000, 0.35);
  }
}
function updateShieldK(e, dt, dx, dz, dist, ux, uz) {
  if (e.fa === undefined) e.fa = Math.atan2(uz, ux);
  if (e.hasSpear === undefined) e.hasSpear = true;
  const sp = e.spear, fetch = e.state === 'idle' && !e.hasSpear && sp && sp.stuck; // walking over to his spear: he faces where he goes
  const ta = fetch ? Math.atan2(sp.z - e.z, sp.x - e.x) : Math.atan2(uz, ux);
  let da = ta - e.fa; while (da > Math.PI) da -= 6.2832; while (da < -Math.PI) da += 6.2832;
  const turn = e.state === 'idle' ? 1.7 : e.state === 'twind' && e.st < 0.28 ? 0 : 0.35; e.fa += clamp(da, -turn * dt, turn * dt); // the throw locks its aim for the last 40%
  const fx = Math.cos(e.fa), fz = Math.sin(e.fa); e.faceLock = fx > 0 ? 1 : -1; e.y = 0; e.wCol = 0xff3050; e.noWpn = !e.hasSpear;
  if (e.state === 'idle') {
    e.open = false; e.tcd = (e.tcd || 0) - dt;
    if (fetch) { // to the spear, pull it out
      const sd = Math.hypot(sp.x - e.x, sp.z - e.z), spd = e.speed * 1.15 * clamp(1 - Math.abs(da), 0.3, 1);
      if (sd > e.r + 0.3) { e.mx = fx * spd; e.mz = fz * spd; e.tilt = Math.sin(e.t * 7) * 0.06; e.y = Math.abs(Math.sin(e.t * 7)) * 0.05; }
      else { e.hasSpear = true; spearFree(sp); e.noWpn = false; sfx('clink'); e.squash = 0.4; spark(e.x + fx * 0.5, 0.7, e.z + fz * 0.5, 0xffffff, { s: 0.8, life: 0.07, drag: 0 }); chunkDust(sp.x, sp.z, 0xa89a8a); e.st = Math.max(e.st, 0.5); e.tcd = rr(4, 6); }
    } else if (e.hasSpear) { // holds his pike's reach: walks in when far, steps back (shield still up) when Pip crowds him
      const want = e.r + PIKE * 0.8, sp2 = e.speed * clamp(1 - Math.abs(da), 0.2, 1);
      if (dist > want + 0.5) { e.mx = fx * sp2; e.mz = fz * sp2; } else if (dist < want - 0.45) { e.mx = -ux * e.speed * 0.6; e.mz = -uz * e.speed * 0.6; }
      if (e.mx || e.mz) { e.tilt = Math.sin(e.t * 6) * 0.05; e.y = Math.abs(Math.sin(e.t * 6)) * 0.04; }
    }
    e.wx = lerp(e.wx || 0, 0, damp(8, dt)); e.wa = lerp(e.wa || 0, 0, damp(6, dt)); e.wy = lerp(e.wy || 0, 0, damp(8, dt)); if (Math.abs(e.wx) < 0.02) { e.wxDir = undefined; e.wFront = false; }
    if (e.hasSpear && e.st <= 0 && Math.abs(da) < 0.6) {
      if (dist < e.r + PIKE + 0.25) { freeFoeFx(e); e.state = 'wind'; e.st = 0.6; e.tg = teleGet('lane', 0xff3050); }
      else if (dist > 3.4 && dist < 8.5 && e.tcd <= 0) { freeFoeFx(e); e.state = 'twind'; e.st = 0.75; e.tg = teleGet('lane', 0xff3050); sfx('bowdraw'); }
    }
  } else if (e.state === 'wind') { // the spear swings round to the lane and is drawn back; the tip glints before the thrust
    const k = 1 - e.st / 0.6; spearAim(e, fx, fz); e.wx = lerp(0, -0.32, ease3(k)); e.wGlow = k * 0.8; e.tint = k * 0.5; e.tilt = -e.faceLock * 0.1 * k; if (k > 0.7) e.shake = 0.03;
    if (k > 0.7 && fxP(0.5)) spark(e.x + fx * (e.r + 0.55), 0.6, e.z + fz * (e.r + 0.55), 0xffffff, { s: 0.55, life: 0.06, drag: 0 });
    teleSet(e.tg, e.x, e.z, e.fa, e.r + PIKE, 0.75, k);
    if (e.st <= 0) { teleFree(e); e.state = 'thrust'; e.st = 0.1; e.hitDone = false; e.wGlow = 0; e.tint = 0; sfx('swing'); e.laser = getLaser(0xffffff); }
  } else if (e.state === 'thrust') { // a long pike thrust: the spear slides far out along the lane
    const p = 1 - e.st / 0.1; spearAim(e, fx, fz); e.wx = lerp(-0.32, 1.25, ease3(p)); e.mx = fx * 4; e.mz = fz * 4; e.tilt = e.faceLock * 0.12; e.sx = 1.06;
    if (e.laser) { placeLaser(e.laser, e.x + fx * e.r, 0.55, e.z + fz * e.r, e.fa, PIKE * ease3(p), 1, 0, 0xffffff); e.laser.core.scale.z = 0.12; e.laser.glow.scale.z = 0.5; } // the streak down the lane
    if (!e.hitDone && p > 0.5) {
      e.hitDone = true; const hit = inMark(e.mk); if (hit) damagePlayer(1, e.x, e.z); const tx = e.x + fx * (e.r + PIKE * 0.8), tz = e.z + fz * (e.r + PIKE * 0.8);
      e.hs = hit ? 0.07 : 0.035; e.flash = Math.max(e.flash, hit ? 0.8 : 0.3);
      slashImpact(tx, tz, 0xd090ff, false); for (let k = 0; k < 5; k++) spark(tx, 0.55, tz, 0xd090ff, { vx: fx * rr(2, 5) + rr(-1.5, 1.5), vz: fz * rr(2, 5) + rr(-1.5, 1.5), vy: rr(0.5, 2), s: 0.2, life: 0.22, drag: 4 });
    }
    if (e.st <= 0) { e.state = 'hold'; e.st = 0.18; }
  } else if (e.state === 'hold') {
    spearAim(e, fx, fz); const k = e.st / 0.18;
    if (e.laser) { placeLaser(e.laser, e.x + fx * e.r, 0.55, e.z + fz * e.r, e.fa, PIKE, k, 0, 0xffffff); e.laser.core.material.opacity = k; e.laser.glow.material.opacity = 0.4 * k; e.laser.core.scale.z = 0.12 * k; }
    if (e.st <= 0) { if (e.laser) { releaseLaser(e.laser); e.laser = null; } e.state = 'recover'; e.st = 0.75; e.open = true; }
  } else if (e.state === 'twind') { // shield planted, the spear drawn back over his shoulder; the lane to the wall fills, then locks
    const k = 1 - e.st / 0.75; spearAim(e, fx, fz); e.wx = lerp(0, -0.55, ease3(k)); e.wy = e.mesh.userData.bh * 0.14 * ease3(k); e.wGlow = k * 0.85; e.tint = k * 0.5;
    e.sy = 1 - 0.05 * k; e.sx = 1 + 0.04 * k; e.tilt = -e.faceLock * 0.16 * k; if (k > 0.6) e.shake = 0.03;
    if (k < 0.65 || !e.laneL) e.laneL = laneLen(e.x, e.z, fx, fz, SPEAR_MAX, 0.12);
    if (k > 0.6 && fxP(0.5)) spark(e.x - fx * 0.3, e.mesh.userData.bh * 0.75, e.z - fz * 0.3, 0xffffff, { s: 0.55, life: 0.06, drag: 0 });
    teleSet(e.tg, e.x, e.z, e.fa, e.laneL, 0.6, k);
    if (e.st <= 0) { teleFree(e); e.spear = spearThrow(e, fx, fz, e.laneL); if (e.spear) e.hasSpear = false; e.noWpn = !e.hasSpear; e.state = 'tthrow'; e.st = 0.35; e.wGlow = 0; e.tint = 0; e.wy = 0; e.squash = 0.4; sfx('swing'); sfx('whoosh'); }
  } else if (e.state === 'tthrow') { e.tilt = e.faceLock * 0.14 * (e.st / 0.35); e.sx = 1.04; if (e.st <= 0) { e.state = 'idle'; e.st = 0.4; } }
  else if (e.state === 'recover') { // shield lowered: the opening
    e.open = true; e.wx = lerp(e.wx, 0, damp(4, dt)); e.tilt = -e.faceLock * 0.06; e.sy = 0.97;
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.4, 2); e.open = false; }
  } else e.state = 'idle';
}
// ---- cultist caster: holds its distance (spacing band); heals a hurt friend or opens a portal for 2 minions, and between
// chants throws a FIREBALL (user 11-14, replaces the homing red skull): staff raised, flame gathering in its hand, a thin aim
// line that tracks then locks with a blast ring where it will burst (0.55 s), then a big crimson-and-gold fireball (hostile:
// never Pip's orange Fireball) flies straight down that line. It bursts on Pip (1) or at the line's end (the ring = the
// blast), leaving a brief burning patch. Interrupted by a hard hit (20% HP)
const FB_SPD = 7.5, FB_COL = 0xd8201a, FB_CORE = 0xffd34f, FB_SMOKE = 0x2a0c0a;
const fbCoreGeo = new THREE.SphereGeometry(0.17, 10, 8), fbShellGeo = new THREE.SphereGeometry(0.32, 12, 8);
const fballs = Array.from({ length: 4 }, () => ({ on: false }));
function fballGet() {
  const f = fballs.find((q) => !q.on); if (!f) return null;
  if (!f.core) {
    f.core = new THREE.Mesh(fbCoreGeo, new THREE.MeshBasicMaterial({ color: 0xfff0b0 }));
    f.shell = new THREE.Mesh(fbShellGeo, new THREE.MeshBasicMaterial({ color: FB_COL, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }));
    f.shell2 = new THREE.Mesh(fbShellGeo, new THREE.MeshBasicMaterial({ color: FB_CORE, transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false }));
  }
  f.on = true; f.held = true; f.t = 0; f.g = 0.3; scene.add(f.core, f.shell, f.shell2); return f;
}
function fballFree(f) { f.on = false; if (f.core) scene.remove(f.core, f.shell, f.shell2); if (f.own && f.own.fb === f) f.own.fb = null; f.own = null; }
function fballBurst(f, x, z, hitPip) {
  const R = 1.0;
  fballFree(f);
  if (hitPip) damagePlayer(1, x, z); else if (inMark({ kind: 'ring', x, z, len: R })) damagePlayer(1, x, z); // direct hit, or the marked blast ring at the line's end
  addRing(x, z, 0.2, R * 1.25, 0.3, FB_CORE); addRing(x, z, 0.15, R, 0.24, FB_COL);
  burst(x, 0.55, z, FB_COL, MOBILE ? 12 : 18, 5, 0.45, 0.4); burst(x, 0.55, z, FB_CORE, MOBILE ? 6 : 9, 3.5, 0.4, 0.3);
  for (let q = 0; q < 6; q++) spark(x + rr(-0.4, 0.4), 0.5, z + rr(-0.4, 0.4), FB_SMOKE, { vy: rr(1.2, 2.4), s: 0.7, life: 0.6, drag: 1 }); // black smoke
  spark(x, 0.6, z, 0xffffff, { s: 1.5, life: 0.08, drag: 0 }); splat(x, z, 0x1a0808, 1.1, 0.8);
  if (fxLight.intensity < 20) { fxLight.position.set(x, 1.2, z); fxLight.intensity = 25; }
  addShake(0.18); sfx('boom'); addFoeHaz(x, z, 0.55, 1.3, 'fire', 0.3); // a brief burning patch (an ember first)
}
function updateFballs(dt) {
  for (const f of fballs) {
    if (!f.on) continue;
    f.t += dt;
    const fl = 1 + 0.15 * Math.sin(f.t * 47) + 0.08 * Math.sin(f.t * 83);
    if (f.held) { // gathering in the cultist's hand
      const e = f.own; if (!e || e.dead || e.state !== 'fwind') { fballFree(f); continue; }
      f.x = e.x + e.face * 0.32; f.z = e.z; f.y = 1.25 + (e.y || 0);
    } else {
      const d0 = f.d; f.d = Math.min(f.L, f.d + FB_SPD * dt); f.x = f.x0 + f.fx * f.d; f.z = f.z0 + f.fz * f.d; f.y = lerp(f.y, 0.6, damp(6, dt));
      if (player.alive && Math.hypot(player.x - f.x, player.z - f.z) < 0.32 + player.r * 0.6) { fballBurst(f, f.x, f.z, true); continue; }
      if (f.d >= f.L) { fballBurst(f, f.x, f.z, false); continue; }
      if (fxP(0.9)) spark(f.x - f.fx * 0.2, f.y, f.z - f.fz * 0.2, Math.random() < 0.6 ? FB_COL : FB_CORE, { vx: -f.fx * 1.5 + rr(-0.6, 0.6), vy: rr(0.3, 1.2), vz: -f.fz * 1.5 + rr(-0.6, 0.6), s: 0.35, life: 0.35, drag: 2 }); // ember trail
      if (fxP(0.35)) spark(f.x - f.fx * 0.35, f.y + 0.1, f.z - f.fz * 0.35, FB_SMOKE, { vy: 0.8, s: 0.55, life: 0.5, drag: 1 });
      gfxPut(darkBatch, f.x, 0.03, f.z, 0.4, 0, 0x000000, 0.4);
      if (MOBILE ? fxP(0.5) : true) { if (fxLight.intensity < 8) { fxLight.position.set(f.x, 1, f.z); fxLight.intensity = 6 * fl; } } // a flickering light under it
    }
    const g = f.g * fl;
    f.core.position.set(f.x, f.y, f.z); f.core.scale.setScalar(f.g * 1.05);
    f.shell.position.copy(f.core.position); f.shell.scale.setScalar(g); f.shell.material.opacity = 0.65 + 0.2 * Math.sin(f.t * 31);
    f.shell2.position.copy(f.core.position); f.shell2.scale.setScalar(g * 1.45); f.shell2.material.opacity = 0.25 + 0.12 * Math.sin(f.t * 23);
  }
}
function cultistCast(e) { // heal a hurt friend, or a portal; false when neither is worth it (then it throws a fireball instead)
  let best = null, bv = 0.75;
  for (const o of enemies) { if (o === e || o.dead || o.isBoss || o.type === 'cultist' || o.spawn < 1) continue; const f = o.hp / o.maxHp; if (f < bv && Math.hypot(o.x - e.x, o.z - e.z) < 7.5) { bv = f; best = o; } }
  if (best) {
    best.hp = Math.min(best.maxHp, best.hp + best.maxHp * 0.35);
    bolts.push({ pts: [new THREE.Vector3(e.x, 1.0, e.z), new THREE.Vector3(best.x, 0.7, best.z)], life: 0.35, color: '#7dff9a', glow: 'rgba(125,255,154,.5)', w: 8 });
    addText(best.x, 1.3, best.z, '+HEAL', '#7dff9a', 0.7); burst(best.x, 0.7, best.z, 0x7dff9a, 14, 3, 0.35, 0.5); addRing(best.x, best.z, 0.2, 1.1, 0.35, 0x7dff9a); sfx('heal');
    return true;
  }
  if ((e.sum || 0) < 4) {
    const a0 = rand() * 6.28, type = G.floor >= 6 ? 'skeleton' : 'imp';
    for (let q = 0; q < 2; q++) { const a = a0 + q * Math.PI, x = e.x + Math.cos(a) * 1.4, z = e.z + Math.sin(a) * 1.4; if (cellAt(x, z) !== FLOOR) continue; portals.push(makePortal(x, z, type, 0.7, q * 0.15)); e.sum = (e.sum || 0) + 1; }
    sfx('portal'); burst(e.x, 1, e.z, 0xff3050, 16, 3, 0.4, 0.5);
    return true;
  }
  return false;
}
function cultistHurt(e, dmg) {
  e.castDmg = (e.castDmg || 0) + dmg;
  if (e.castDmg > e.maxHp * 0.2) { teleFree(e); if (e.laser) { releaseLaser(e.laser); e.laser = null; } e.state = 'idle'; e.st = 2.2; e.tint = 0; addText(e.x, 1.4, e.z, 'INTERRUPTED', '#ffd34f', 0.6); burst(e.x, 0.9, e.z, 0xffd34f, 12, 3, 0.35, 0.4); sfx('clink'); }
}
function cultistFire(e, ux, uz) { freeFoeFx(e); e.state = 'fwind'; e.st = 0.55; e.castDmg = 0; e.ax = ux; e.az = uz; e.laser = getLaser(FB_COL); e.tg = teleGet('ring', FB_CORE); e.fb = fballGet(); if (e.fb) e.fb.own = e; sfx('fire'); }
function updateCultist(e, dt, dx, dz, dist, ux, uz) {
  e.faceLock = dx > 0 ? 1 : -1;
  if (e.state === 'idle') {
    keepBand(e, dist, ux, uz); e.mx = e.bmx; e.mz = e.bmz;
    e.y = 0.05 + Math.sin(e.t * 3) * 0.04; e.tilt = Math.sin(e.t * 2) * 0.06;
    if (e.st <= 0 && dist < 13) {
      if ((e.cn = (e.cn || 0) + 1) % 2 === 0) { freeFoeFx(e); e.state = 'cast'; e.st = 1.0; e.castDmg = 0; e.tg = teleGet('ring', 0xffd34f); sfx('chant'); }
      else cultistFire(e, ux, uz);
    }
  } else if (e.state === 'cast') {
    const k = 1 - e.st / 1.0; e.tint = k; e.sy = 1 + 0.08 * k; e.y = 0.05 + k * 0.15; e.tilt = Math.sin(e.t * 20) * 0.03 * k;
    teleSet(e.tg, e.x, e.z, G.time * 2, 1.0 + 0.2 * k, 0, k);
    if (fxP(0.6)) { const a = Math.random() * 6.28; spark(e.x + Math.cos(a) * 0.9, 0.1, e.z + Math.sin(a) * 0.9, Math.random() < 0.5 ? 0xffd34f : 0xff3050, { vy: 2.2, s: 0.3, life: 0.5, drag: 1 }); }
    if (fxP(0.35)) spark(e.x, e.y + 1.25, e.z, 0xff3050, { s: 0.55, life: 0.1, drag: 0 }); // priority-target glint over its head
    if (e.st <= 0) { teleFree(e); e.tint = 0; if (cultistCast(e)) { e.state = 'idle'; e.st = rr(1.8, 2.6); } else cultistFire(e, ux, uz); }
  } else if (e.state === 'fwind') { // staff up, the flame gathers in its hand, the aim line tracks then locks
    const k = 1 - e.st / 0.55; if (k < 0.6) { e.ax = ux; e.az = uz; }
    e.tint = k * 0.7; e.sy = 1 + 0.1 * k; e.sx = 1 - 0.04 * k; e.tilt = -e.faceLock * 0.12 * k; e.y = 0.05 + k * 0.08; if (k > 0.7) e.shake = 0.02;
    const a = Math.atan2(e.az, e.ax); let len = 0.6; while (len < 11 && !solid(e.x + e.ax * len, e.z + e.az * len, true)) len += 0.25;
    e.fbL = Math.max(0.8, len - 0.3);
    if (e.fb) { e.fb.g = 0.15 + 0.85 * ease3(k); if (fxP(0.7)) { const sa = Math.random() * 6.28; spark(e.fb.x + Math.cos(sa) * 0.6, e.fb.y + Math.sin(sa) * 0.5, e.fb.z, Math.random() < 0.5 ? FB_COL : FB_CORE, { vx: -Math.cos(sa) * 2.4, vy: -Math.sin(sa) * 2, s: 0.3, life: 0.22, drag: 0 }); } } // flame drawn into the hand
    if (e.laser) {
      const L = e.laser, lock = k > 0.6; placeLaser(L, e.x + e.ax * 0.35, 0.55, e.z + e.az * 0.35, a, e.fbL - 0.35, lock ? 0.5 : 0.1, 0, FB_COL);
      L.core.scale.z = lock ? 0.045 : 0.025; L.core.scale.y = 0.03; L.glow.scale.z = lock ? 0.14 : 0.07;
      L.core.material.opacity = lock ? 0.5 + 0.35 * Math.sin(G.time * 50) : 0.15 + 0.25 * k; L.glow.material.opacity = lock ? 0.25 : 0.07;
    }
    teleSet(e.tg, e.x + e.ax * e.fbL, e.z + e.az * e.fbL, 0, 1.0, 0, k); // where it bursts if nothing is in the way
    if (e.st <= 0) { // throw
      teleFree(e); if (e.laser) { releaseLaser(e.laser); e.laser = null; }
      const f = e.fb; e.fb = null;
      if (f) { f.held = false; f.own = null; f.g = 1; f.x0 = e.x + e.ax * 0.4; f.z0 = e.z + e.az * 0.4; f.fx = e.ax; f.fz = e.az; f.d = 0; f.L = e.fbL - 0.4; }
      e.state = 'fthrow'; e.st = 0.3; e.tint = 0; e.squash = 0.4; e.kx -= e.ax * 1.5; e.kz -= e.az * 1.5; sfx('whoosh'); sfx('fire');
      spark(e.x + e.ax * 0.5, 1.0, e.z + e.az * 0.5, 0xffffff, { s: 0.9, life: 0.07, drag: 0 });
    }
  } else if (e.state === 'fthrow') { e.tilt = e.faceLock * 0.12 * (e.st / 0.3); if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.8, 2.6); } }
  else e.state = 'idle';
}
// ---- rust beetle: curls up (immune), rolls and ricochets off walls, then lies dizzy (takes x1.5)
function updateBeetle(e, dt, dx, dz, dist, ux, uz) {
  if (e.state === 'idle') {
    e.faceLock = 0; e.mx = ux * e.speed; e.mz = uz * e.speed; e.tilt = Math.sin(e.t * 8) * 0.08; e.y = Math.abs(Math.sin(e.t * 8)) * 0.04;
    if (e.st <= 0 && dist < 8) { freeFoeFx(e); e.state = 'curl'; e.st = 0.6; e.lx = ux; e.lz = uz; e.tg = teleGet('lane', 0xff8a2a); }
  } else if (e.state === 'curl') {
    const k = 1 - e.st / (e.rico ? 0.35 : 0.6); if (k < 0.6 && !e.rico) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1; // rico: a bounce, new lane shown
    e.sx = 1 + 0.12 * k; e.sy = 1 - 0.25 * k; e.tint = k * 0.7; e.shake = 0.03; e.tilt = -e.faceLock * k * 1.1; // tucks in, rocking back
    e.laneL = laneLen(e.x, e.z, e.lx, e.lz, 7, e.r); teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.laneL + e.r, e.r * 2, k); // the lane = the whole roll
    if (e.st <= 0) { teleFree(e); e.tint = 0; e.state = 'roll'; e.st = e.laneL / 8.5 + 0.05; if (!e.rico) e.bn = 0; e.rico = false; e.spin = e.spin || 0; e.wallHit = false; sfx('roll'); }
  } else if (e.state === 'roll') {
    e.mx = e.lx * 8.5; e.mz = e.lz * 8.5; e.spin += dt * 16; e.tilt = -e.faceLock * e.spin; e.sx = 0.9; e.sy = 0.85; e.y = Math.abs(Math.sin(e.spin)) * 0.05;
    if (fxP(0.6)) spark(e.x, 0.06, e.z, 0x9a7a5a, { vx: -e.lx * 2, vz: -e.lz * 2, vy: 0.6, s: 0.3, life: 0.35 });
    if (e.wallHit) { // ricochet: flip whichever way is blocked
      const r = e.r + 0.15; let f = false;
      if (solid(e.x + Math.sign(e.lx) * r, e.z, false)) { e.lx = -e.lx; f = true; }
      if (solid(e.x, e.z + Math.sign(e.lz) * r, false)) { e.lz = -e.lz; f = true; }
      if (!f) { e.lx = -e.lx; e.lz = -e.lz; }
      e.faceLock = e.lx > 0 ? 1 : -1; e.bn++; addShake(0.12); sfx('clink'); e.squash = 0.5; e.hs = 0.04;
      for (let k = 0; k < 6; k++) spark(e.x, 0.4, e.z, 0xffd27a, { vx: rr(-4, 4), vy: rr(1, 3), vz: rr(-4, 4), s: 0.2, life: 0.25, drag: 4 });
      chunkDust(e.x, e.z, 0x9a7a5a);
      if (e.bn >= 3) e.st = 0;
      else { e.state = 'curl'; e.st = 0.35; e.rico = true; e.tg = teleGet('lane', 0xff8a2a); } // each ricochet shows its own lane first
    }
    if (e.st <= 0) { e.state = 'dizzy'; e.st = 1.4; e.faceLock = 0; e.tilt = 0; e.squash = 0.6; sfx('thud'); }
  } else if (e.state === 'dizzy') {
    e.tilt = Math.sin(e.t * 10) * 0.15; e.sy = 0.95;
    if (fxP(0.3)) spark(e.x + Math.cos(e.t * 6) * 0.35, 0.95, e.z + Math.sin(e.t * 6) * 0.35, 0xffe14f, { s: 0.25, life: 0.3, drag: 0 });
    if (e.st <= 0) { e.state = 'idle'; e.st = rr(1.4, 2.2); }
  }
}
const FOE_UPD = { archer: updateArcher, spider: updateSpider, salamander: updateSalamander, shieldk: updateShieldK, cultist: updateCultist, beetle: updateBeetle };

const beamGeo = new THREE.BoxGeometry(1, 0.2, 1).translate(0.5, 0, 0);
// ---------- player lasers (Ray shapes, Hollow Gaze, Holy Beam): a thin bright core, a faint glow, a pulsing impact ring ----------
// pooled: each laser keeps its 3 meshes and materials; get/release only add/remove them from the scene (no per-frame allocation)
const laserGeo = new THREE.BoxGeometry(1, 1, 1).translate(0.5, 0, 0), laserPool = [], LASER_WHITE = new THREE.Color(0xffffff);
function getLaser(color) {
  let L = laserPool.pop();
  if (!L) {
    const mat = (o, map) => new THREE.MeshBasicMaterial({ map: map || null, transparent: true, opacity: o, blending: THREE.AdditiveBlending, depthWrite: false });
    L = { core: new THREE.Mesh(laserGeo, mat(1)), glow: new THREE.Mesh(laserGeo, mat(0.25)), ring: new THREE.Mesh(flatRingGeo, mat(1, softRingTex)) };
    L.core.renderOrder = 6; L.glow.renderOrder = 5; L.ring.renderOrder = 2; L.core.material.depthTest = L.glow.material.depthTest = false; // drawn over the foes (user 11-15: Holy Beam was under them); every player laser stops at walls
  }
  L.core.material.color.set(color).lerp(LASER_WHITE, 0.65); L.glow.material.color.set(color); L.ring.material.color.set(color);
  L.core.visible = L.glow.visible = L.ring.visible = true;
  scene.add(L.core, L.glow, L.ring);
  return L;
}
function releaseLaser(L) { if (!L) return; scene.remove(L.core, L.glow, L.ring); if (laserPool.length < 16) laserPool.push(L); }
function hideLaser(L) { L.core.visible = L.glow.visible = L.ring.visible = false; }
// from (x, y, z) along angle a for len tiles. bright 0..1+ scales the glow; hitR = impact ring radius (0 = none); col = spark colour
function placeLaser(L, x, y, z, a, len, bright, hitR, col) {
  L.core.visible = L.glow.visible = true;
  const ry = -a, fl = Math.sin(G.time * 55) * 0.012;
  L.core.position.set(x, y, z); L.core.rotation.y = ry; L.core.scale.set(len, 0.05, 0.09 + fl);
  L.glow.position.set(x, y, z); L.glow.rotation.y = ry; L.glow.scale.set(len, 0.08, 0.3 + fl * 3);
  L.core.material.opacity = Math.min(1, 0.75 + 0.25 * bright); L.glow.material.opacity = Math.min(0.6, 0.14 + 0.2 * bright);
  const hx = x + Math.cos(a) * len, hz = z + Math.sin(a) * len;
  L.ring.visible = hitR > 0;
  if (hitR > 0) {
    L.ring.position.set(hx, 0.12, hz); L.ring.scale.setScalar(hitR * (0.85 + 0.15 * Math.sin(G.time * 24)));
    L.ring.material.opacity = Math.min(1, 0.6 + 0.4 * bright);
    if (fxP(0.55)) spark(hx, y, hz, Math.random() < 0.5 ? 0xffffff : col, { vx: rr(-2.5, 2.5), vz: rr(-2.5, 2.5), vy: rr(1, 3), s: 0.22 + 0.1 * bright, life: 0.22, drag: 4 });
    if (fxP(0.5)) spark(hx, y, hz, 0xffffff, { s: 0.35 + 0.35 * Math.min(1.5, bright), life: 0.06, drag: 0 }); // hot spot at the impact
  }
}
// o: len, warn, dur, color, w (beam half-width that hurts), y: the Sentinel's cross and the Hollow Eye's sweeps use it
// foe beams (pooled): a glow slab + a white-hot core + a flare at the source and sparks where it ends. The warning is a lane
// on the floor (dark under-layer + colour, as wide as the beam that follows), not a 1-px line
const foeBeamPool = [];
function foeBeamGet(color) {
  let B = foeBeamPool.pop();
  if (!B) {
    B = { mesh: new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false })), core: new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false })) };
    B.mesh.renderOrder = 3; B.core.renderOrder = 4;
  }
  B.mesh.material.color.set(color); B.mesh.rotation.set(0, 0, 0); B.core.rotation.set(0, 0, 0); B.mesh.material.depthTest = B.core.material.depthTest = true; scene.add(B.mesh, B.core); B.core.visible = false; return B;
}
function teleRelease(t) { if (!t) return; scene.remove(t.a, t.b, t.u); telePool[t.kind].push(t); }
function addBeam(e, a, spin, o = {}) {
  const color = o.color || 0xff2040, len = o.len || 14;
  let mesh = null, laser = null, B = null;
  if (o.ally) laser = getLaser(color); // Pip's own beam: the thin pooled laser (enemy beams keep their wide dodge tell)
  else { B = foeBeamGet(color); mesh = B.mesh; mesh.scale.set(len, 1, 0.08); }
  const b = { e, a, spin, t: 0, warn: o.warn ?? 0.9, dur: o.dur || 3.1, mesh, laser, B, bright: 0.3, hitR: 0.35, color, len, cur: len, w: o.w || 0.45, y: o.y || 0.7, ww: o.ww || 0.06, clip: !!o.clip, ally: !!o.ally, src: o.src || null }; // src: [x, y] share of the sprite the beam leaves from (the Hollow Eye's pupil)
  if (B && b.src) B.mesh.material.depthTest = B.core.material.depthTest = false; // leaves the pupil in front of the eye, whichever way it points
  if (B) { b.tg = teleGet('lane', color); if (e.isBoss) b.tg.str = 1.35; b.flare = makeGlow(color, 0.1, 0); b.flare2 = makeGlow(0xffffff, 0.1, 0); }
  beams.push(b);
  sfx(o.sfx || 'laser');
  return b;
}
function beamEnd(b) { // back to the pools
  if (b.laser) { releaseLaser(b.laser); b.laser = null; return; }
  if (b.B) { scene.remove(b.B.mesh, b.B.core); if (foeBeamPool.length < 12) foeBeamPool.push(b.B); b.B = null; }
  teleRelease(b.tg); b.tg = null; killGlow(b.flare); killGlow(b.flare2);
}
const _bSrc = new THREE.Vector3(), _bFwd = new THREE.Vector3();
function updateBeams(dt) {
  for (let i = beams.length - 1; i >= 0; i--) {
    const b = beams[i]; b.t += dt;
    if (b.t > b.warn) b.a += b.spin * dt;
    const x = b.e.x, z = b.e.z, live = b.t > b.warn;
    let len = b.len;
    if (b.clip) { // stops at the first wall, the same test enemy shots die on (low obstacles don't block)
      const cx = Math.cos(b.a), cz = Math.sin(b.a);
      for (let d = 0.6; d < b.len; d += 0.2) { const wx = x + cx * d, wz = z + cz * d; if (solid(wx, wz, true)) { len = d; break; } }
      if (live && !b.laser && len < b.len && fxP(0.5)) spark(x + cx * len, b.y, z + cz * len, b.color, { vy: rr(1, 3), s: 0.45, life: 0.3, drag: 1, spread: 1.5 });
    }
    b.cur = len;
    if (b.laser) { // ally laser: stops at its target (b.stop, set by Holy Beam) or the wall; ring + sparks at that point
      const L = Math.min(len, b.stop || len);
      placeLaser(b.laser, x, b.y, z, b.a, L, b.bright, b.hitR, b.color);
      if (b.t >= b.dur || b.e.dead) { releaseLaser(b.laser); b.laser = null; beams.splice(i, 1); }
      continue;
    }
    const cx = Math.cos(b.a), cz = Math.sin(b.a), wk = Math.min(1, b.t / Math.max(0.01, b.warn));
    let sx = x, sy = b.y, sz = z, ry = -b.a, rz = 0, sl = len; // the visible beam: from the source to the lane's far end
    if (b.src) { // from the pupil (follows the bob, the facing and the lean) sloping down to the far end of its floor lane
      const m = b.e.mesh; _bSrc.set(b.src[0] * (b.e.face < 0 ? -1 : 1) * m.scale.x, b.src[1] * m.scale.y, 0).applyQuaternion(m.quaternion).add(m.position);
      sx = _bSrc.x; sy = _bSrc.y; sz = _bSrc.z; const hx = x + cx * len - sx, hz = z + cz * len - sz, hd = Math.hypot(hx, hz) || 0.01, dy = sy - b.y;
      ry = -Math.atan2(hz, hx); rz = -Math.atan2(dy, hd); sl = Math.hypot(hd, dy);
    }
    b.mesh.scale.x = sl;
    b.mesh.position.set(sx, sy, sz); b.mesh.rotation.order = 'YXZ'; b.mesh.rotation.set(0, ry, rz);
    b.mesh.scale.z = live ? b.w * 0.93 + Math.sin(b.t * 60) * 0.06 : b.ww;
    b.mesh.material.opacity = live ? 0.8 : 0.25 + Math.sin(b.t * 30) * 0.15;
    if (b.tg) { // the floor warning lane: fills over the warn time, flickers at the end; gone once the beam is live
      if (!live) teleSet(b.tg, x, z, b.a, len, b.w * 2, wk); else { teleRelease(b.tg); b.tg = null; }
    }
    if (b.B) {
      const C = b.B.core; C.visible = live; if (live) { C.position.set(sx, sy, sz); C.rotation.order = 'YXZ'; C.rotation.set(0, ry, rz); C.scale.set(sl, 0.6, b.w * 0.3 * (0.85 + 0.15 * Math.sin(b.t * 70))); }
      const fs = live ? 1.6 + 0.3 * Math.sin(b.t * 40) : 0.5 + 0.9 * wk; // the source flare charges up, then blazes
      if (b.src) b.flare.position.set(sx, sy, sz).addScaledVector(_bFwd.set(0, 0, 1).applyQuaternion(camera.quaternion), 0.4); else b.flare.position.set(x + cx * 0.5, b.y, z + cz * 0.5); // on the pupil, just in front of the eye b.flare.scale.set(fs * 1.4, fs * 1.4, 1); b.flare.material.opacity = live ? 0.9 : 0.4 + 0.4 * wk;
      b.flare2.position.copy(b.flare.position); b.flare2.scale.set(fs * 0.6, fs * 0.6, 1); b.flare2.material.opacity = live ? 0.9 : 0.5 * wk;
    }
    if (live) {
      for (let k = fxN(3); k > 0; k--) { const d = Math.random() * Math.max(0, len - 1); spark(x + cx * d, b.y, z + cz * d, b.color, { vy: rr(0.5, 2), s: 0.35, life: 0.25, drag: 0 }); }
      if (fxP(0.6)) spark(x + cx * len, b.y, z + cz * len, Math.random() < 0.5 ? 0xffffff : b.color, { vx: rr(-3, 3), vy: rr(1, 3), vz: rr(-3, 3), s: 0.35, life: 0.25, drag: 3 }); // end sparks
      const rx = player.x - x, rz = player.z - z, along = rx * cx + rz * cz, perp = Math.abs(-rx * cz + rz * cx);
      if (!b.ally && along > 0 && along < len && perp < b.w) damagePlayer(1, player.x - cz, player.z + cx); // b.ally: Pip's own beam (Holy Beam deals its damage itself)
      if (!b.ally && Math.random() < 0.3) { const sd = rr(1, Math.max(1, len * 0.7)); splat(x + cx * sd, z + cz * sd, 0x1a0606, 0.4); }
    }
    if (b.t >= b.dur || b.e.dead) { beamEnd(b); beams.splice(i, 1); }
  }
}
// The Hollow Eye: circles the room near its walls (never through you), sweeps lasers (a floor lane warns first), bursts of
// tear-drops after a pupil glow + ring tell, calls its children. No body-contact damage: only its attacks hurt
const EYE_PUPIL = [0.22, 0.49]; // the slit pupil on the hollow sheet (x from the centre, y up from the bottom; the art faces right)
function updateEyeBoss(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, enraged = e.hp < e.maxHp * 0.5;
  e.noContact = true;
  e.orbit = (e.orbit || 0) + dt * (enraged ? 0.55 : 0.38);
  const ox = Math.max(2, Math.min(4.5, r.w / 2 - 1.6)), oz = Math.max(1.8, Math.min(4.5, r.h / 2 - 1.6));
  const tx = r.cx + Math.cos(e.orbit) * ox, tz = r.cz + Math.sin(e.orbit) * oz;
  e.mx = (tx - e.x) * 1.5; e.mz = (tz - e.z) * 1.5;
  if (dist < 4.4) { const w = clamp((4.4 - dist) / 2, 0, 1); keepBand(e, dist, dx / dist, dz / dist, e.d.band, e.speed * 1.3); e.mx = lerp(e.mx, e.bmx, w); e.mz = lerp(e.mz, e.bmz, w); } // Pip closes in: it backs off (the orbit gives way)
  e.y = 0.6 + Math.sin(e.t * 2) * 0.2; e.tilt = Math.sin(e.t * 1.3) * 0.1;
  const flap = Math.sin(e.t * 9); e.sx = 1 + flap * 0.08; e.sy = 1 - flap * 0.04;
  e.face = dx > 0 ? 1 : -1;
  if (e.state === 'idle' && e.st <= 0) {
    e.jumps++;
    const pickA = e.jumps % 3;
    if (pickA === 1) { e.state = 'laser'; e.st = 3.2; const a = Math.atan2(dz, dx) - 0.9; addBeam(e, a, 0.75, { src: EYE_PUPIL }); if (enraged) addBeam(e, a + Math.PI, 0.75, { src: EYE_PUPIL }); }
    else if (pickA === 2) { freeFoeFx(e); e.state = 'bwind'; e.st = 0.45; e.tg = teleGet('ring', 0xff5a3a); sfx('lock'); } // the pupil glows, a ring marks the burst
    else { e.state = 'summon'; e.st = 1; for (let k = 0; k < (enraged ? 4 : 3); k++) portals.push(makePortal(r.cx + rr(-4, 4), r.cz + rr(-4, 4), 'eye', 0.7, k * 0.15)); sfx('portal'); }
  }
  if (e.state === 'laser') { e.mx *= 0.2; e.mz *= 0.2; e.chargeK = 0.5; }
  if (e.state === 'bwind') {
    const k = 1 - e.st / 0.45; e.mx *= 0.2; e.mz *= 0.2; e.chargeK = k; e.sx = e.sy = 1 + 0.15 * k; teleSet(e.tg, e.x, e.z, 0, 1.9, 0, k);
    if (fxP(0.7)) spark(e.x + rr(-0.2, 0.2), e.y + 1.2, e.z, 0xffffff, { s: 0.6 + k, life: 0.06, drag: 0 }); // the pupil
    if (e.st <= 0) { teleFree(e); e.state = 'burst'; e.st = 1.4; e.shots = 0; e.cool = 0; e.chargeK = 0; }
    return;
  }
  if (e.state === 'burst') {
    e.cool -= dt; e.mx *= 0.4; e.mz *= 0.4;
    if (e.cool <= 0 && e.shots < 3) { e.cool = 0.45; e.shots++; const n = enraged ? 18 : 14; for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2 + e.shots * 0.2, p = enemyShoot(e, a, 4, 0xb05cff, 1, 0, 'tear'); p.x = e.x + Math.cos(a) * 1.9; p.z = e.z + Math.sin(a) * 1.9; } e.squash = 0.5; sfx('spit'); addRing(e.x, e.z, 0.4, 2.1, 0.25, 0xb05cff); } // leaves from the ring's edge
  }
  if (e.state !== 'idle' && e.st <= 0) { e.state = 'idle'; e.st = enraged ? 1.2 : 1.8; e.chargeK = 0; }
}
// The Stone King (user 11-14: "not rolling"): a giant boulder ROLL down a marked lane (tucks into a ball with a rumble, spins down
// the lane, crashes into the wall: shockwave, debris falling on marked spots, stunned, uncurls); enraged he ricochets off that wall
// down a second lane (both marked from the start). Close up: a fist slam (ring in front). Every 3rd move the GROUND SMASH: both
// fists up, a big ring round him, then rocks rain from the ceiling on marked spots (enraged: a second wave)
const KING_COL = 0xff8a3a, KING_TELL = 0xff3050;
const KING_SMASH = [false, true].map((en) => ({ R: 3.3, col: KING_COL, dust: 0x8a96a0, hot: 0xff6a10, n: en ? (MOBILE ? 7 : 9) : (MOBILE ? 6 : 8), spread: 5, kind: 0, warn: en ? 0.8 : 0.95, wave2: en ? (MOBILE ? 5 : 7) : 0, boss: true, foes: 30, rockR: 0.85, after: en ? 1 : 1.5 })); // [normal, enraged]
function kingCrash(e, x, z) { // the roll ends: shockwave + cracks + falling debris (marked), no damage of its own
  e.squash = 0.9; e.hs = 0.09; addShake(0.6); sfx('slam'); sfx('thud'); G.hitstop = Math.max(G.hitstop, 0.05);
  addRing(x, z, 0.4, 3.2, 0.45, 0xc0c8d0, true); addRing(x, z, 0.3, 2.2, 0.32, KING_COL, true); addCrack(x, z, 1.8, 0xff6a10);
  chunk(x, 1, z, 0x8a96a0, MOBILE ? 8 : 12, 6, 0.18); burst(x, 0.4, z, 0x8a96a0, MOBILE ? 10 : 16, 6, 0.5, 0.55); spark(x, 0.6, z, 0xffffff, { s: 2, life: 0.08, drag: 0 });
  rockfall(e.hp < e.maxHp * 0.5 ? 4 : 3, 2.6, 0, 0.7, 0.15, { R: 0.8, boss: true, foes: 30 }); // the ceiling shakes loose
}
function updateStoneKing(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, enraged = e.hp < e.maxHp * 0.5;
  const ux = dx / (dist || 1), uz = dz / (dist || 1), S = e.r + player.r + STAND_GAP, bh = e.mesh.userData.bh;
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; if (!e.rollSpin) e.tilt = 0; e.wCol = KING_COL;
  if (e.state === 'idle') { // keeps ~4 tiles off to roll down a lane; Pip close gets the fist. Never walks into Pip
    const sp = e.speed * 0.8 * clamp(dist - 4, -1, 1) * (dist < S + 0.2 ? 0 : 1); e.mx = ux * sp; e.mz = uz * sp; e.faceLock = 0;
    e.tilt = Math.sin(e.t * 4) * 0.08; e.y = Math.abs(Math.sin(e.t * 4)) * 0.05;
    e.wa = lerp(e.wa, 0.12 * Math.sin(e.t * 4 + 1), damp(6, dt)); e.wGlow = 0; e.wy = lerp(e.wy || 0, 0, damp(8, dt)); e.wsc = lerp(e.wsc || 1, 1, damp(5, dt));
    if (e.st <= 0) {
      e.jumps++; freeFoeFx(e); e.lx = ux; e.lz = uz; e.faceLock = ux > 0 ? 1 : -1;
      if (e.jumps % 3 === 0) { e.state = 'gwind'; e.st = e.windT = enraged ? 0.9 : 1.1; e.tg = teleGet('ring', KING_TELL); sfx('roll'); addShake(0.25); e.callGuard = (e.smN = (e.smN || 0) + 1) % 2 === 0; } // the ground smash
      else if (dist < 3.2) { e.state = 'pwind'; e.st = enraged ? 0.55 : 0.7; e.tg = teleGet('ring', KING_TELL); } // close up: the fist
      else { e.state = 'wind'; e.st = e.windT = enraged ? 0.75 : 0.9; e.rico = enraged; e.tg = teleGet('lane', KING_TELL); if (enraged) e.tg2 = teleGet('lane', KING_TELL); sfx('roll'); }
    }
  } else if (e.state === 'gwind' || e.state === 'gslam' || e.state === 'grec') {
    smashStep(e, dt, KING_SMASH[enraged ? 1 : 0]);
    if (e.state === 'grec' && e.callGuard) { e.callGuard = false; for (let q = 0; q < 2; q++) portals.push(makePortal(r.cx + rr(-3, 3), r.cz + rr(-3, 3), 'skeleton', 0.7, q * 0.2)); } // his guard answers (every other smash)
  } else if (e.state === 'wind') { // the tuck: he curls into a boulder (squash, rumble, fist hugged in), the lane fills; aims until 60%
    const k = 1 - e.st / e.windT; if (k < 0.6) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
    e.tint = k * 0.8; e.wGlow = k * 0.5; e.shake = 0.04 + k * 0.08; e.tilt = e.faceLock * 0.3 * k; e.sy = 1 - k * 0.24; e.sx = 1 + k * 0.12;
    e.wa = lerp(e.wa, -0.7, damp(6, dt)); e.wsc = 1; e.wy = 0;
    if (fxP(0.5 * k)) spark(e.x - e.lx * 0.9 + rr(-0.5, 0.5), 0.06, e.z - e.lz * 0.9, 0x8a96a0, { vx: -e.lx * 3 + rr(-1, 1), vz: -e.lz * 3 + rr(-1, 1), vy: 0.9, s: 0.5, life: 0.45 });
    if (k < 0.6 || !e.laneL) {
      e.laneL = laneLen(e.x, e.z, e.lx, e.lz, 14, e.r);
      if (e.rico) { // the ricochet lane: off the wall he hits (reflected), or straight back at Pip if that wall sends him nowhere
        const ex = e.x + e.lx * e.laneL, ez = e.z + e.lz * e.laneL, rp = e.r + 0.3; let rx = e.lx, rz = e.lz;
        if (solid(ex + Math.sign(e.lx) * rp, ez, false)) rx = -rx; if (solid(ex, ez + Math.sign(e.lz) * rp, false)) rz = -rz; if (rx === e.lx && rz === e.lz) { rx = -rx; rz = -rz; }
        let L2 = laneLen(ex, ez, rx, rz, 12, e.r); if (L2 < 2.5) { const px = player.x - ex, pz = player.z - ez, pl = Math.hypot(px, pz) || 1; rx = px / pl; rz = pz / pl; L2 = laneLen(ex, ez, rx, rz, 12, e.r); }
        e.r2x = ex; e.r2z = ez; e.l2x = rx; e.l2z = rz; e.lane2L = L2;
      }
    }
    teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.laneL + e.r, e.r * 2, k); // the lane = the whole roll
    if (e.tg2) teleSet(e.tg2, e.r2x, e.r2z, Math.atan2(e.l2z, e.l2x), e.lane2L + e.r, e.r * 2, k * 0.8);
    if (e.st <= 0) { teleFree(e); kingRoll(e); }
  } else if (e.state === 'charge') { // the roll: the only time touching him hurts (2); a spinning boulder straight down the lane
    e.mx = e.lx * 10; e.mz = e.lz * 10; e.sx = 0.94; e.sy = 0.82;
    e.spin += dt * 10 / Math.max(0.5, bh * 0.4); e.tilt = e.spin; // rolls about its middle (rollSpin)
    e.wa = lerp(e.wa, -0.7, damp(12, dt));
    if (Math.random() < 0.8) chunkDust(e.x, e.z, 0x8a96a0);
    if ((e.ct -= dt) <= 0) { e.ct = 0.18; addCrack(e.x - e.lx * 0.5, e.z - e.lz * 0.5, 0.8, 0); }
    if ((e.ai -= dt) <= 0) { e.ai = MOBILE ? 0.1 : 0.07; afterImage(e, KING_COL); }
    if (fxP(0.3)) addShake(0.06);
    if (e.wallHit || e.st <= 0 || e.rammed) {
      kingCrash(e, e.x + e.lx * (e.r + 0.3), e.z + e.lz * (e.r + 0.3)); e.rammed = false; e.wGlow = 0;
      if (e.tg2) { // enraged: the ricochet down the second marked lane
        e.lx = e.l2x; e.lz = e.l2z; e.state = 'rwind'; e.st = 0.3; e.faceLock = e.lx > 0 ? 1 : -1;
      } else { e.state = 'stun'; e.st = 1.6; e.slamT = 0; }
    }
  } else if (e.state === 'rwind') { // a heartbeat at the wall, then off down lane two
    const t2 = e.tg2; if (t2) teleSet(t2, e.x, e.z, Math.atan2(e.lz, e.lx), laneLen(e.x, e.z, e.lx, e.lz, 12, e.r) + e.r, e.r * 2, 1);
    e.spin += dt * 4; e.tilt = e.spin; e.shake = 0.06;
    if (e.st <= 0) { if (e.tg2) { teleRelease(e.tg2); e.tg2 = null; } e.laneL = laneLen(e.x, e.z, e.lx, e.lz, 12, e.r); kingRoll(e); }
  } else if (e.state === 'stun') { // dazed, uncurls
    if (e.rollSpin) { const to = Math.round(e.spin / 6.2832) * 6.2832; e.spin = lerp(e.spin, to, damp(7, dt)); e.tilt = e.spin; if (Math.abs(e.spin - to) < 0.03) { e.rollSpin = false; e.spin = 0; } }
    else e.tilt = Math.sin(e.t * 12) * 0.1;
    e.wa = lerp(e.wa, -0.15 + Math.sin(e.t * 6) * 0.12, damp(6, dt)); // the arm hangs limp
    e.wsc = lerp(e.wsc || 1, 1, damp(5, dt)); e.faceLock = 0; e.sy = lerp(0.9, 1, 1 - e.st / 1.6);
    if (fxP(0.3)) spark(e.x + Math.cos(e.t * 6) * 0.8, 3.1, e.z + Math.sin(e.t * 6) * 0.8, 0xffe14f, { s: 0.3, life: 0.3, drag: 0 });
    if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 1 : 1.6; }
  } else if (e.state === 'pwind') { // the fist goes up high and glows; a ring in front shows where it lands
    const pw = enraged ? 0.55 : 0.7, k = 1 - e.st / pw; if (k < 0.55) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
    e.sy = 1 + k * 0.08; e.sx = 1 - k * 0.05; e.tilt = -e.faceLock * 0.2 * k; e.tint = k * 0.6; if (k > 0.6) e.shake = 0.05;
    e.wa = lerp(e.wa, 2.7, damp(7, dt)); e.wy = bh * 0.1 * ease3(k); e.wsc = 1 + 0.15 * ease3(k); e.wGlow = k * 0.6;
    teleSet(e.tg, e.x + e.lx * (e.r + 0.9), e.z + e.lz * (e.r + 0.9), 0, 1.8, 0, k);
    if (e.st <= 0) { teleFree(e); e.state = 'pslam'; e.st = 0.12; e.tint = 0; e.wGlow = 0; addSmear(e, KING_COL, e.wa); sfx('swing'); }
  } else if (e.state === 'pslam') {
    const p = 1 - e.st / 0.12; e.wa = lerp(2.7, 0.6, p * p); e.wy = bh * 0.1 * (1 - p * p); e.tilt = e.faceLock * 0.3; e.sx = 1.1; e.sy = 0.9;
    if (e.st <= 0) {
      endSmear(e); e.squash = 0.8; e.hs = 0.08; e.flash = Math.max(e.flash, 0.8); addShake(0.5); sfx('slam'); G.hitstop = Math.max(G.hitstop, 0.05);
      const fx0 = e.mk ? e.mk.x : e.x, fz0 = e.mk ? e.mk.z : e.z;
      if (inMark(e.mk)) damagePlayer(1, fx0, fz0); // the ring is the truth
      addRing(fx0, fz0, 0.3, 2.2, 0.35, 0xc0c8d0); addRing(fx0, fz0, 0.2, 1.8, 0.25, KING_COL); addCrack(fx0, fz0, 1.6, 0xff6a10);
      chunk(fx0, 0.5, fz0, 0x8a96a0, 8, 5, 0.16); burst(fx0, 0.3, fz0, 0x8a96a0, 12, 5, 0.45, 0.5); spark(fx0, 0.5, fz0, 0xffffff, { s: 1.8, life: 0.08, drag: 0 });
      e.state = 'precover'; e.st = 0.5;
    }
  } else if (e.state === 'precover') { // the fist comes back up out of the cracks
    e.wa = lerp(e.wa, 0, damp(4, dt)); e.wy = 0; e.wsc = lerp(e.wsc || 1, 1, damp(5, dt)); e.tilt = e.faceLock * 0.1 * (e.st / 0.5);
    if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 0.8 : 1.1; e.faceLock = 0; }
  } else { e.state = 'idle'; e.st = 1; }
}
function kingRoll(e) {
  e.state = 'charge'; e.st = e.laneL / 10 + 0.05; e.tint = 0; e.wGlow = 0.35; e.ai = 0; e.ct = 0; e.rammed = false; e.wallHit = false;
  if (!e.rollSpin) { e.rollSpin = true; e.spin = 0; } sfx('roll'); sfx('whoosh'); addShake(0.2);
}
// ---- The prologue Stone King: no charges. He keeps his distance and spits slow fans of stone, and calls Rockfall
// (red circles at and around Pip, rocks drop after a warning). Every 20% of HP lost calls a small group of his guard;
// under half he rages: wider, faster fans, more rocks, shorter warnings. Few things on screen at once (phone FPS).
function updateProKing(e, dt, dx, dz, dist) {
  const P = G.prologue, f = e.hp / e.maxHp, ux = dx / (dist || 1), uz = dz / (dist || 1);
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.tilt = 0;
  if (!P.enraged && f < 0.5) {
    P.enraged = true; e.squash = 0.9; addShake(0.7); flash(0.3); sfx('slam'); addRing(e.x, e.z, 0.5, 5, 0.5, 0xff6a4f);
    banner('<span style="color:#ff6a4f">THE STONE KING RAGES</span>', 'FASTER · MORE ROCKS'); bannerT = 1.6;
  }
  const en = P.enraged, g = P.summons || 0;
  if (g < PRO_GUARD.length && f <= 0.8 - g * 0.2) { // hurt him and he calls his guard, never past the cap
    const live = enemies.filter((o) => !o.dead && !o.isBoss).length + portals.length, n = Math.min(MOBILE ? 4 : 6, PRO_CAP - live);
    P.summons = g + 1; e.squash = 0.8; addShake(0.35);
    if (n > 0) proRing(n, PRO_GUARD[g], g >= 2 ? 1 : 0);
  }
  if (e.state === 'idle') { // drift to ~4.5 from Pip and face him
    const want = clamp(dist - 4.5, -1, 1); e.mx = ux * e.speed * 0.7 * want; e.mz = uz * e.speed * 0.7 * want;
    e.tilt = Math.sin(e.t * 4) * 0.06; e.y = Math.abs(Math.sin(e.t * 4)) * 0.04;
    e.wa = lerp(e.wa || 0, 0.1 * Math.sin(e.t * 4 + 1), damp(5, dt)); e.wy = lerp(e.wy || 0, 0, damp(8, dt)); e.wGlow = 0; e.wsc = lerp(e.wsc || 1, 1, damp(5, dt));
    if (e.st <= 0) { e.atk = (e.atk || 0) + 1; if (e.atk % (en ? 2 : 3) === 0) { e.state = 'call'; e.st = 0.5; } else { e.state = 'spit'; e.st = e.wind = en ? 0.45 : 0.65; } }
  } else if (e.state === 'spit') { // the tell: he rears back and glows, then a fan of stone at Pip
    e.tint = 1 - e.st / e.wind; e.shake = 0.06; e.sy = 1 + e.tint * 0.12; e.sx = 1 - e.tint * 0.06; e.tilt = -e.face * 0.2 * e.tint;
    e.wCol = 0xd8a868; e.wa = lerp(e.wa || 0, 2.2, damp(8, dt)); e.wGlow = e.tint * 0.8; e.wsc = 1 + 0.12 * e.tint; // the fist winds up
    if (e.st <= 0) {
      addSmear(e, 0xd8a868, e.wa); e.wa = -0.2; e.wGlow = 0; later(0.12, () => endSmear(e)); // ...and throws the stones
      const n = en ? 5 : 3, a0 = Math.atan2(dz, dx), sp = en ? 5.2 : 4.2;
      for (let k = 0; k < n; k++) enemyShoot(e, a0 + (k - (n - 1) / 2) * 0.3, sp, 0xd8a868, 1.1);
      e.tint = 0; e.squash = 0.7; addShake(0.2); sfx('orb'); e.state = 'idle'; e.st = en ? 0.8 : 1.3;
    }
  } else if (e.state === 'call') { // Rockfall: he slams the floor and the ceiling answers
    const k = 1 - e.st / 0.5; e.sy = 1 - k * 0.2; e.sx = 1 + k * 0.15; e.shake = 0.05;
    e.wCol = 0xff8a3a; e.wa = lerp(e.wa || 0, 2.7, damp(10, dt)); e.wy = e.mesh.userData.bh * 0.1 * k; e.wGlow = k * 0.8; // fist up high...
    if (e.st <= 0) { e.wa = 0.6; e.wy = 0; e.wGlow = 0; e.hs = 0.06; addCrack(e.x + e.face * 1.2, e.z, 1.8, 0xff6a10); proRockfall(en ? (MOBILE ? 4 : 5) : 3, en ? 0.75 : 1.0); e.squash = 0.9; addShake(0.5); sfx('slam'); addRing(e.x, e.z, 0.5, 3, 0.4, 0xc0c8d0); e.state = 'idle'; e.st = en ? 1 : 1.4; }
  } else { e.state = 'idle'; e.st = 1; }
}
function proRockfall(n, warn) {
  const P = G.prologue, r = P.room; P.rockfalls = (P.rockfalls || 0) + 1;
  for (let q = 0; q < n; q++) { // the first circle lands where Pip is heading, the rest around him
    const x = clamp(player.x + (q ? rr(-2.6, 2.6) : player.vx * 0.2), r.x0 + 1.5, r.x0 + r.w + 0.5), z = clamp(player.z + (q ? rr(-2.6, 2.6) : player.vz * 0.2), r.z0 + 1.5, r.z0 + r.h + 0.5);
    later(q * 0.08, () => {
      if (!G.prologue) return;
      const mk = addMarker(x, z, 0.95, 0xff3050); mk.material.depthTest = false; mk.renderOrder = 8; P.marks.push({ mk, t: 0, warn }); // drawn over the spell glow
      later(warn, () => {
        scene.remove(mk); mk.material.dispose(); if (!G.prologue) return;
        P.marks = P.marks.filter((m) => m.mk !== mk);
        chunk(x, 2.5, z, 0x8a96a0, 6, 3, 0.18); burst(x, 0.3, z, 0xc0c8d0, 8, 3, 0.4, 0.4); splat(x, z, 0x2a2a30, 0.9); addShake(0.14); sfx('rockfall');
        if (Math.hypot(player.x - x, player.z - z) < 0.9) damagePlayer(1, x, z);
        for (const o of enemies) if (!o.dead && !o.isBoss && Math.hypot(o.x - x, o.z - z) < 0.9) hurtEnemyRaw(o, 30, '#c0c8d0');
      });
    });
  }
}

// ---- The Bone Tyrant: greatsword sweeps, bone eruptions, raises the dead
function updateTyrant(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, enraged = e.hp < e.maxHp * 0.5;
  const ux = dx / (dist || 1), uz = dz / (dist || 1), S = e.r + player.r + STAND_GAP, bh = e.mesh.userData.bh;
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.tilt = 0; e.wCol = 0xff3050;
  if (e.state === 'idle') { // keeps ~4.5 from Pip (bone lines from range); the greatsword is for when Pip comes close
    const sp = e.speed * 0.8 * clamp(dist - 4.5, -1, 1) * (dist < S + 0.2 ? 0 : 1); e.mx = ux * sp; e.mz = uz * sp; e.faceLock = 0;
    e.tilt = Math.sin(e.t * 5) * 0.08 * Math.min(1, Math.abs(sp)); e.y = Math.abs(Math.sin(e.t * 5)) * 0.06 * Math.min(1, Math.abs(sp));
    e.wa = lerp(e.wa, 0.12 * Math.sin(e.t * 5), damp(8, dt)); e.wGlow = 0; e.wy = lerp(e.wy || 0, 0, damp(8, dt)); e.wsc = lerp(e.wsc || 1, 1, damp(5, dt));
    if (e.st <= 0) {
      freeFoeFx(e); e.lx = ux; e.lz = uz; e.faceLock = ux > 0 ? 1 : -1;
      const k = dist < 3.2 ? 1 : ++e.jumps % 3 === 0 ? 0 : 2; // close: the sweep; at range: bone lines, every 3rd time raise the dead
      if (k === 1 && (e.cmb = !e.cmb)) { e.ci = 0; tyComboWind(e, ux, uz, enraged); } // close up: the 3-slash combo and the sweep in turn
      else if (k === 1) { e.state = 'sweepWind'; e.st = e.windT = enraged ? 0.55 : 0.75; e.tg = teleGet('sector', 0xff3050); }
      else if (k === 2) { e.state = 'bones'; e.st = 1.2; e.plunged = false; }
      else { e.state = 'raise'; e.st = 1; for (let q = 0; q < (enraged ? 4 : 3); q++) portals.push(makePortal(r.cx + rr(-4, 4), r.cz + rr(-4, 4), 'skeleton', 0.7, q * 0.15)); sfx('portal'); }
    }
  } else if (e.state === 'sweepWind') { // the greatsword goes back over his shoulder; a ring in front fills. Aims until 60%
    const k = 1 - e.st / e.windT; if (k < 0.6) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
    e.tint = k * 0.7; e.shake = 0.06; e.tilt = -e.faceLock * 0.35 * k; e.sx = 1 + 0.08 * k;
    e.wa = lerp(e.wa, 1.9, damp(9, dt)); e.wy = bh * 0.08 * ease3(k); e.wsc = 1 + 0.18 * ease3(k); e.wGlow = k * 0.55; // a big blade: a lighter glow still reads
    teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx), e.r + 2.6, 0, k); // a wide arc in front: what the sweep covers
    if (e.st <= 0) { teleFree(e); e.tint = 0; e.wGlow = 0; e.state = 'sweep'; e.st = 0.14; e.hitDone = false; e.wa0 = e.wa; addSmear(e, 0xffe0e0, e.wa); sfx('swing'); }
  } else if (e.state === 'sweep') { // one huge downward sweep; the blow lands mid-swing
    const p = 1 - e.st / 0.14; e.wa = lerp(e.wa0, -1.9, ease3(Math.min(1, p / 0.8))); e.wy = lerp(bh * 0.08, 0, ease3(p)); e.wfx = 0.2 * Math.sin(Math.min(1, p) * Math.PI);
    e.tilt = e.faceLock * 0.45; e.sx = 1.12; e.sy = 0.92;
    if (!e.hitDone && p >= 0.5) {
      e.hitDone = true; const cx = e.x + e.lx * 2, cz = e.z + e.lz * 2, hit = inMark(e.mk); // the arc is the truth
      if (hit) damagePlayer(1, e.x, e.z);
      e.hs = hit ? 0.09 : 0.05; e.flash = Math.max(e.flash, hit ? 0.9 : 0.5);
      addShake(0.6); sfx('slam'); G.hitstop = Math.max(G.hitstop, 0.05);
      addRing(cx, cz, 0.4, 2.4, 0.35, 0xffe0e0); addCrack(cx, cz, 1.6, 0xff3050); slashImpact(cx, cz, 0xffe0e0, true);
      for (let q = 0; q < 14; q++) { const a = Math.atan2(e.lz, e.lx) + rr(-1.1, 1.1), d = rr(0.6, 2.8); spark(e.x + Math.cos(a) * d, 0.8, e.z + Math.sin(a) * d, 0xfff0f0, { vx: Math.cos(a) * 4, vz: Math.sin(a) * 4, s: 0.5, life: 0.3 }); }
      for (const pot of [...pots]) if (Math.hypot(pot.x - cx, pot.z - cz) < 2.2) breakPot(pot);
    }
    if (e.st <= 0) { endSmear(e); e.state = 'recover'; e.st = 0.6; e.squash = 0.6; e.wfx = 0; }
  } else if (e.state === 'cwind') { // COMBO (user 11-14): each slash gets its own marked arc; it re-aims for 60% of its wind-up, then commits
    const C = TY_COMBO[e.ci], k = 1 - e.st / e.windT; if (k < 0.6) { e.lx = ux; e.lz = uz; } e.faceLock = e.lx > 0 ? 1 : -1;
    e.wa = lerp(e.wa, C[1], damp(14, dt)); e.wy = C[1] > 2 ? bh * 0.1 * ease3(k) : 0; e.wsc = 1 + 0.15 * ease3(k); e.wGlow = k * 0.6; e.tint = k * 0.5;
    e.tilt = -e.faceLock * (C[1] > 0 ? 0.25 : -0.15) * k; e.sx = 1 + 0.05 * k; if (k > 0.7) e.shake = 0.04;
    teleSet(e.tg, e.x, e.z, Math.atan2(e.lz, e.lx) + C[3] * e.faceLock, e.r + C[4], 0, k); // alternating sides: each arc leans toward its swing
    if (e.st <= 0) { teleFree(e); e.state = 'cslash'; e.st = 0.12; e.hitDone = false; e.tint = 0; e.wGlow = 0; e.wa0 = e.wa; addSmear(e, C[5] > 1 ? 0xffe0e0 : 0xfff0e8, e.wa); sfx('swing'); }
  } else if (e.state === 'cslash') {
    const C = TY_COMBO[e.ci], p = 1 - e.st / 0.12; e.wa = lerp(e.wa0, C[2], ease3(Math.min(1, p / 0.8))); e.wy = lerp(e.wy || 0, 0, ease3(p)); e.wfx = 0.18 * Math.sin(Math.min(1, p) * Math.PI);
    e.mx = e.lx * 3.5; e.mz = e.lz * 3.5; e.tilt = e.faceLock * (C[2] < C[1] ? 0.4 : -0.25); e.sx = 1.1; e.sy = 0.93;
    if (!e.hitDone && p >= 0.5) {
      e.hitDone = true; const heavy = C[5] > 1, a = Math.atan2(e.lz, e.lx) + C[3] * e.faceLock, cx = e.x + Math.cos(a) * (e.r + C[4] * 0.6), cz = e.z + Math.sin(a) * (e.r + C[4] * 0.6), hit = inMark(e.mk); // the arc is the truth
      if (hit) damagePlayer(C[5], e.x, e.z);
      e.hs = hit ? 0.08 : 0.04; e.flash = Math.max(e.flash, hit ? 0.9 : 0.45); slashImpact(cx, cz, 0xffe0e0, heavy);
      if (heavy) { addShake(0.55); sfx('slam'); G.hitstop = Math.max(G.hitstop, 0.05); addRing(cx, cz, 0.4, 2.2, 0.35, 0xffe0e0); addCrack(cx, cz, 1.5, 0xff3050); for (const pot of [...pots]) if (Math.hypot(pot.x - cx, pot.z - cz) < 2) breakPot(pot); }
      else { addShake(0.18); sfx('thud'); }
    }
    if (e.st <= 0) { endSmear(e); e.wfx = 0; if (++e.ci < TY_COMBO.length) tyComboWind(e, ux, uz, enraged); else { e.state = 'recover'; e.st = 0.7; e.squash = 0.6; } }
  } else if (e.state === 'recover') { // the blade rests in the cracks, then comes back up: the opening
    e.wa = lerp(e.wa, 0, damp(3, dt)); e.wy = 0; e.wsc = lerp(e.wsc || 1, 1, damp(5, dt)); e.tilt = e.faceLock * 0.4 * (e.st / 0.6);
    if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 0.9 : 1.4; e.faceLock = 0; }
  } else if (e.state === 'bones') { // the sword goes up, then stabs into the floor: bone lines erupt from it
    const t = 1.2 - e.st; e.faceLock = e.lx > 0 ? 1 : -1;
    if (t < 0.22) { const k = t / 0.22; e.wa = lerp(e.wa, 2.4, damp(12, dt)); e.wy = bh * 0.1 * ease3(k); e.wGlow = k * 0.8; e.wCol = 0xffe0c0; e.tint = k * 0.5; e.sy = 1 + 0.06 * k; }
    else {
      if (!e.plunged) { e.plunged = true; e.wa0 = e.wa; addSmear(e, 0xffe0c0, e.wa); boneLines(e, enraged ? 5 : 3); addShake(0.3); sfx('thud'); e.hs = 0.06; chunkDust(e.x + e.faceLock * 1.2, e.z, 0xe8e0cc); }
      const p = Math.min(1, (t - 0.22) / 0.1); e.wa = lerp(e.wa0, -2.1, ease3(p)); // blade stabbed down into the floor e.wy = bh * 0.1 * (1 - p); e.wGlow = 0; e.tint = 0; e.tilt = e.faceLock * 0.3 * p; e.sy = 0.94;
      if (p >= 1) endSmear(e);
    }
    if (e.st <= 0) { endSmear(e); e.state = 'idle'; e.st = enraged ? 0.9 : 1.4; e.faceLock = 0; }
  } else if (e.state === 'raise') { // greatsword held high, glowing: the dead answer
    const k = 1 - e.st; e.wa = lerp(e.wa, 1.2, damp(6, dt)); e.wy = bh * 0.12 * ease3(Math.min(1, k * 2)); e.wGlow = 0.4 + 0.3 * Math.sin(e.t * 12); e.wCol = 0xb070ff; e.sy = 1 + 0.05 * Math.sin(e.t * 6);
    if (fxP(0.4)) spark(e.x + e.face * 0.9, bh * 0.75, e.z, 0xb070ff, { vy: 1.5, s: 0.4, life: 0.4, drag: 0 });
    if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 0.9 : 1.4; e.wGlow = 0; }
  } else if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 0.9 : 1.4; }
}
// the Bone Tyrant's 3-slash combo: [wind-up s, blade from, blade to, arc lean (rad), reach, damage]. Down-right, back-hand up,
// then an overhead heavy (cracks, shake). The wind-up of the next slash is the dodge window
const TY_COMBO = [[0.5, 1.9, -1.9, 0.3, 2.3, 1], [0.34, -1.9, 1.7, -0.3, 2.3, 1], [0.48, 2.7, -2.1, 0, 2.8, 2]];
function tyComboWind(e, ux, uz, enraged) { e.state = 'cwind'; e.st = e.windT = TY_COMBO[e.ci][0] * (enraged ? 0.82 : 1); e.lx = ux; e.lz = uz; if (e.tg) teleFree(e); e.tg = teleGet('sector', 0xff3050); }
function boneLines(e, n) {
  const base = Math.atan2(player.z - e.z, player.x - e.x);
  sfx('lock');
  for (let l = 0; l < n; l++) {
    const a = base + (l - (n - 1) / 2) * 0.45;
    for (let k = 1; k <= 10; k++) { // ~8.5 tiles: cast from range
      const x = e.x + Math.cos(a) * k * 0.85, z = e.z + Math.sin(a) * k * 0.85;
      later(k * 0.02, () => { // the whole lane is marked almost at once, then the bones erupt along it from the Tyrant outward
        if (cellAt(x, z) !== FLOOR) return;
        const mk = addMarker(x, z, 0.5, 0xffe0c0);
        later(0.55 + k * 0.05, () => {
          scene.remove(mk); mk.material.dispose();
          addBones(x, z, 1.15);
          if (inMark({ kind: 'ring', x, z, len: 0.48 })) damagePlayer(1, x, z); // the spike's marker (0.5) is the truth
        });
      });
    }
  }
}
// ---- Mother Spore: spore spirals, poison clouds around you, her brood
// ---- Mother Spore (user 11-14: "looks like floating, make it dig then up"): rooted in the floor (dirt + roots at her base, no
// drifting), and a BURROW: she sinks into the ground in a spray of dirt, a mound cracks along under the floor toward you, a ring
// marks where she comes up, then she erupts there (dirt + spores; the ring is the hit) and carries on from her new spot
const SPORE_DIRT = 0x6a4a30;
function updateSpore(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, enraged = e.hp < e.maxHp * 0.5, bh = e.mesh.userData.bh;
  e.mx = 0; e.mz = 0; e.tilt = Math.sin(e.t * 1.1) * 0.025; e.y = 0; e.sunk = false;
  const breathe = Math.sin(e.t * 2.4); e.sx = 1 + breathe * 0.04; e.sy = 1 - breathe * 0.04; e.face = dx > 0 ? 1 : -1;
  e.root = lerp(e.root ?? 1, e.state === 'sink' || e.state === 'tunnel' || e.state === 'mark' ? 0 : 1, damp(6, dt));
  e.rcd = (e.rcd || 0) - dt;
  if (e.state === 'idle' && dist < 3.4 && e.rcd <= 0) { e.state = 'sink'; e.st = 0.7; e.away = true; e.rcd = 4.5; sfx('roll'); addShake(0.1); } // spacing (user 11-14): Pip on top of her: she digs away to range
  else if (e.state === 'idle' && e.st <= 0) {
    e.jumps++;
    const k = e.jumps % 4;
    if (k === 1) { e.state = 'inhale'; e.st = 0.5; sfx('hiss'); } // the spiral's tell: she swells and glows green
    else if (k === 3) { e.state = 'sink'; e.st = 0.9; sfx('roll'); addShake(0.15); }
    else if (k === 2) {
      e.state = 'gas'; e.st = 1.2; sfx('hiss');
      for (let q = 0; q < (enraged ? 6 : 4); q++) {
        const x = player.x + rr(-3, 3), z = player.z + rr(-3, 3);
        if (cellAt(x, z) !== FLOOR) continue;
        const mk = addMarker(x, z, 1.3, 0xc8d040);
        later(0.9, () => { scene.remove(mk); mk.material.dispose(); clouds.push({ x, z, r: 1.3, life: 3.5, cd: 0 }); });
      }
    } else { e.state = 'brood'; e.st = 1; for (let q = 0; q < (enraged ? 4 : 3); q++) portals.push(makePortal(r.cx + rr(-4, 4), r.cz + rr(-3, 4), q % 2 ? 'slime' : 'shroom', 0.7, q * 0.15)); sfx('portal'); }
  }
  if (e.state === 'inhale') {
    const k = 1 - e.st / 0.5; e.tint = k; e.sx = 1 - 0.08 * k; e.sy = 1 + 0.12 * k; e.shake = 0.02 + 0.03 * k;
    if (fxP(0.6)) { const a = Math.random() * 6.28; spark(e.x + Math.cos(a) * 1.6, rr(0.3, 1.6), e.z + Math.sin(a) * 1.2, 0x9add4a, { vx: -Math.cos(a) * 3, vz: -Math.sin(a) * 2.2, vy: 0.3, s: 0.35, life: 0.45, drag: 0 }); } // spores drawn in
    if (e.st <= 0) { e.tint = 0; e.state = 'spiral'; e.st = enraged ? 3 : 2.4; e.spin = rand() * 6; e.cool = 0; e.squash = 0.4; }
    return;
  }
  if (e.state === 'spiral') {
    e.cool -= dt; e.sx = 1 + Math.sin(e.t * 18) * 0.06;
    if (e.cool <= 0) { e.cool = enraged ? 0.08 : 0.11; e.spin += 0.33; for (let q = 0; q < 2; q++) { const p = enemyShoot(e, e.spin + q * Math.PI, 3.6, q ? 0xb070ff : 0x8add4a, 0.9, 0, 'spore'); p.x += Math.cos(e.spin + q * Math.PI) * 0.6; p.z += Math.sin(e.spin + q * Math.PI) * 0.6; } }
  } else if (e.state === 'sink') { // she digs in: shakes, sinks into the floor in a spray of dirt
    const k = 1 - e.st / 0.9; e.sunk = true; e.y = -bh * ease3(k) * 1.02; e.shake = 0.08; e.noContact = true; e.sx = 1 + 0.12 * k; e.sy = 1 - 0.08 * k;
    if (fxP(0.8)) { const a = Math.random() * 6.28; spark(e.x + Math.cos(a) * 1.1, 0.1, e.z + Math.sin(a) * 0.9, SPORE_DIRT, { vx: Math.cos(a) * 3, vz: Math.sin(a) * 3, vy: rr(2, 4), grav: -14, s: 0.35, life: 0.5, drag: 1 }); }
    if (fxP(0.25)) chunk(e.x + rr(-0.8, 0.8), 0.2, e.z + rr(-0.6, 0.6), SPORE_DIRT, 2, 4, 0.12);
    if (e.st <= 0) { e.state = 'tunnel'; e.st = 2.4; e.hidden = true; e.ct = 0; if (e.away) sporeAwaySpot(e, r); burst(e.x, 0.3, e.z, SPORE_DIRT, 14, 4, 0.4, 0.5); addCrack(e.x, e.z, 1.4, 0); addShake(0.25); sfx('thud'); }
  } else if (e.state === 'tunnel') { // a mound cracks along under the floor toward you (she is under it)
    e.sunk = true; e.y = -bh * 1.02; e.hidden = true; e.noContact = true;
    const tx = e.away ? e.ax : clamp(player.x, r.x0 + 1.6, r.x0 + r.w - 0.6), tz = e.away ? e.az : clamp(player.z, r.z0 + 1.6, r.z0 + r.h - 0.6), mdx = tx - e.x, mdz = tz - e.z, md = Math.hypot(mdx, mdz);
    if (md > 0.05) { const sp = Math.min(5.2, md * 4); e.mx = mdx / md * sp; e.mz = mdz / md * sp; }
    if ((e.ct -= dt) <= 0) { e.ct = 0.18; addCrack(e.x, e.z, 0.75, 0); chunk(e.x, 0.15, e.z, SPORE_DIRT, 2, 3, 0.11); if (fxP(0.5)) addShake(0.05); }
    if (fxP(0.7)) spark(e.x + rr(-0.4, 0.4), 0.1, e.z + rr(-0.4, 0.4), SPORE_DIRT, { vy: rr(1.5, 3), grav: -12, s: 0.3, life: 0.4, drag: 1 });
    if (e.away && (md < 0.4 || e.st <= 0)) { // surfaces quietly at range: no ring, no hit
      e.away = false; e.hidden = false; e.state = 'erupt'; e.st = 0.4; e.squash = 0.6; e.mx = e.mz = 0; sfx('thud'); addShake(0.15);
      burst(e.x, 0.4, e.z, SPORE_DIRT, 14, 4, 0.45, 0.5); chunk(e.x, 0.4, e.z, SPORE_DIRT, 8, 5, 0.14); addCrack(e.x, e.z, 1.4, 0);
    } else if (!e.away && (md < 0.7 || e.st <= 0)) { e.state = 'mark'; e.st = e.markT = 0.85; e.tg = teleGet('ring', 0xd8ff5a); e.mx = e.mz = 0; sfx('lock'); } // the spot locks
  } else if (e.state === 'mark') { // the ground bulges; the ring is where (and how far) she comes up
    e.sunk = true; e.y = -bh * 1.02; e.hidden = true; e.noContact = true;
    const k = 1 - e.st / e.markT; teleSet(e.tg, e.x, e.z, 0, 1.8, 0, k);
    if (fxP(0.6 + k * 0.4)) spark(e.x + rr(-1, 1), 0.1, e.z + rr(-1, 1), Math.random() < 0.6 ? SPORE_DIRT : 0x9add4a, { vy: rr(1.5, 3.5) * (0.5 + k), grav: -12, s: 0.32, life: 0.45, drag: 1 });
    if (k > 0.6) addShake(0.02);
    if (e.st <= 0) { // erupt
      teleFree(e); e.hidden = false; e.state = 'erupt'; e.st = 0.4; e.squash = 0.9;
      const hit = inMark(e.mk); if (hit) { damagePlayer(1, e.x, e.z); G.hitstop = Math.max(G.hitstop, 0.06); }
      e.flash = 1; addShake(0.5); sfx('slam'); sfx('thud');
      addRing(e.x, e.z, 0.3, 2.2, 0.4, 0xd8ff5a); addRing(e.x, e.z, 0.2, 1.4, 0.3, 0xffffff); addCrack(e.x, e.z, 2, 0x9add4a);
      chunk(e.x, 0.4, e.z, SPORE_DIRT, 14, 7, 0.16); burst(e.x, 0.4, e.z, SPORE_DIRT, 20, 6, 0.5, 0.6);
      for (let q = 0; q < 16; q++) { const a = q / 16 * 6.28; spark(e.x + Math.cos(a) * 0.6, rr(0.4, 1.4), e.z + Math.sin(a) * 0.5, q % 2 ? 0x9add4a : 0xb070ff, { vx: Math.cos(a) * 4, vz: Math.sin(a) * 4, vy: rr(1, 3), s: 0.6, life: 0.7, drag: 2 }); } // a spore cloud bursts out
      splat(e.x, e.z, 0x2a1a10, 2.4, 0.8);
    }
  } else if (e.state === 'erupt') { // she shoots up out of the hole, overshoots, settles
    const k = 1 - e.st / 0.4; e.y = -bh * Math.max(0, 1 - k * 2.2) * 1.02; e.sunk = k < 0.5; e.sy = 1 + 0.25 * Math.sin(Math.min(1, k * 1.5) * Math.PI); e.sx = 1 - 0.1 * Math.sin(Math.min(1, k * 1.5) * Math.PI);
    if (e.st <= 0) { e.y = 0; e.state = 'idle'; e.st = enraged ? 0.9 : 1.3; }
    return;
  }
  if (e.state !== 'idle' && e.st <= 0) { e.state = 'idle'; e.st = enraged ? 1 : 1.6; e.hidden = false; e.tint = 0; }
}
function sporeAwaySpot(e, r) { // the far side: ~6 tiles from Pip, inside the room, the farthest of a few tries
  const a0 = Math.atan2(e.z - player.z, e.x - player.x); let bd = -1;
  for (let q = 0; q < 7; q++) {
    const a = a0 + (q % 2 ? 1 : -1) * Math.ceil(q / 2) * 0.6, x = clamp(player.x + Math.cos(a) * 6, r.x0 + 1.6, r.x0 + r.w - 0.6), z = clamp(player.z + Math.sin(a) * 6, r.z0 + 1.6, r.z0 + r.h - 0.6);
    if (solid(x, z, false)) continue; const d = Math.hypot(x - player.x, z - player.z); if (d > bd) { bd = d; e.ax = x; e.az = z; }
  }
  if (bd < 0) { e.ax = e.x; e.az = e.z; }
}
function updateClouds(dt) {
  for (let i = clouds.length - 1; i >= 0; i--) {
    const c = clouds[i]; c.life -= dt; c.cd -= dt;
    if (c.max === undefined) { c.max = c.life; c.rot = Math.random() * 6.28; }
    const fin = Math.min(1, (c.max - c.life) / 0.3), fade = fin * clamp(c.life / 0.5, 0, 1);
    // murky gas (audit: it used the spiky sawblade decal, same as the salamander fire): a soft lumpy fog pool, low rolling puffs, bubbles
    gfxPut(darkBatch, c.x, 0.025, c.z, c.r * 1.25, 0, 0x000000, 0.5 * fade);
    gfxPut(gasBatch, c.x, 0.035, c.z, c.r * 1.12 * (0.85 + 0.15 * fin), c.rot + G.time * 0.15, 0x8a9a2a, 0.9 * fade);
    gfxPut(gasBatch, c.x, 0.04, c.z, c.r * 0.8, -c.rot - G.time * 0.22, 0x6a4a7a, 0.55 * fade);
    for (let q = 0; q < 3; q++) { const a = c.rot + q * 2.1 + G.time * 0.4, d = c.r * 0.45, ph = Math.sin(G.time * 1.7 + q * 2 + c.x); gfxFlame(puffBatch, c.x + Math.cos(a) * d, 0.02, c.z + Math.sin(a) * d * 0.8, c.r * (0.9 + 0.15 * ph), c.r * (0.75 + 0.2 * ph), Math.sin(G.time + q) * 0.1, q === 1 ? 0x7a5a8a : 0x9aaa3a, 0.55 * fade); }
    for (let n = gfxEmit(c, 'eA', 12 * fade, dt); n > 0; n--) { const a = Math.random() * 6.28, d = Math.random() * c.r; spark(c.x + Math.cos(a) * d, rr(0.1, 0.8), c.z + Math.sin(a) * d, Math.random() < 0.5 ? 0x6a7a24 : 0x4a2266, { vy: 0.4, s: rr(0.5, 0.9), life: 0.8, drag: 1 }); }
    if (fxP(0.1 * fade)) { const a = Math.random() * 6.28, d = Math.random() * c.r * 0.8; spark(c.x + Math.cos(a) * d, 0.08, c.z + Math.sin(a) * d, 0x6a7a2a, { vy: 0.5, s: -0.24, life: 0.5, drag: 1 }); } // a bubble that pops
    if (c.cd <= 0 && player.alive && Math.hypot(player.x - c.x, player.z - c.z) < c.r) { c.cd = 1.2; damagePlayer(1, c.x, c.z); }
    if (c.life <= 0) clouds.splice(i, 1);
  }
}
// ---- The Wraith Queen: blinks around you, homing souls, her court of ghosts; snuffs the torches when hurt
function updateWraith(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, enraged = e.hp < e.maxHp * 0.5;
  if (enraged && !e.snuffed) { e.snuffed = true; G.dark = r; for (const f of r.flames) { f.visible = false; f.userData.core.visible = false; } banner('THE LIGHTS DIE', ''); sfx('moan'); }
  e.y = 0.5 + Math.sin(e.t * 2) * 0.15; e.tilt = Math.sin(e.t * 1.4) * 0.12; e.face = dx > 0 ? 1 : -1;
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1;
  if (e.state === 'idle') {
    e.alpha = 0.92; e.hidden = false;
    keepBand(e, dist, dx / (dist || 1), dz / (dist || 1)); e.mx = e.bmx; e.mz = e.bmz; // circles at ~5 and backs off
    if (e.st <= 0) {
      e.jumps++;
      const k = e.jumps % 3;
      if (k === 1) { e.state = 'fade'; e.st = 0.4; }
      else if (k === 2) { e.state = 'souls'; e.st = 1.4; e.cool = 0; e.shots = 0; }
      else { e.state = 'court'; e.st = 1; for (let q = 0; q < (enraged ? 4 : 3); q++) portals.push(makePortal(r.cx + rr(-4, 4), r.cz + rr(-4, 4), 'ghost', 0.7, q * 0.15)); sfx('portal'); }
    }
  } else if (e.state === 'fade') {
    e.alpha = 0.92 * e.st / 0.4; e.hidden = e.alpha < 0.3; e.noContact = true;
    if (e.st <= 0) {
      for (let tries = 0; tries < 12; tries++) { const a = rand() * 6.28, nx = player.x + Math.cos(a) * 3.2, nz = player.z + Math.sin(a) * 3.2; if (!solid(nx, nz, true) && roomAt(nx, nz) === r) { e.x = nx; e.z = nz; break; } }
      e.state = 'appear'; e.st = 0.45; burst(e.x, 1, e.z, 0xbff3ff, 16, 3, 0.4, 0.5);
    }
  } else if (e.state === 'appear') {
    e.alpha = 0.92 * (1 - e.st / 0.45); e.hidden = e.alpha < 0.3;
    if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 1 : 1.5; const n = enraged ? 18 : 12; for (let q = 0; q < n; q++) { const a = q / n * Math.PI * 2, p = enemyShoot(e, a, 3.4, 0xbff3ff, 0.9, 0, 'soul'); p.x = e.x + Math.cos(a) * 1.0; p.z = e.z + Math.sin(a) * 1.0; } addShake(0.3); sfx('spit'); }
  } else if (e.state === 'souls') {
    e.cool -= dt; e.chargeK = 0.4;
    if (e.cool <= 0 && e.shots < (enraged ? 7 : 5)) { e.cool = 0.22; e.shots++; enemyShoot(e, Math.atan2(dz, dx) + rr(-1.2, 1.2), 3.2, 0x9fe8ff, 1, 1.8, 'soul'); sfx('spit'); }
    if (e.st <= 0) { e.state = 'idle'; e.st = enraged ? 1 : 1.6; e.chargeK = 0; }
  } else if (e.st <= 0) { e.state = 'idle'; e.st = 1.4; }
}
function updateBoss(e, dt, dx, dz, dist) {
  const enraged = e.hp < e.maxHp * 0.5;
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.tilt = 0;
  if (e.state === 'wait') {
    const k = 1 - clamp(e.st / 0.7, 0, 1);
    e.sx = 1 + 0.25 * k + Math.sin(e.t * 6) * 0.03; e.sy = 1 - 0.25 * k - Math.sin(e.t * 6) * 0.03; e.y = 0;
    if (e.st <= 0) {
      e.jumps++;
      if (e.jumps % 4 === 0) { e.state = 'spray'; e.st = 2.2; e.shots = 0; e.spin = rand() * 6; }
      else {
        e.state = 'jump'; e.st = enraged ? 0.75 : 0.95; e.jd = e.st;
        e.tx = clamp(player.x + player.vx * 0.4, G.curRoom.x0 + 2.2, G.curRoom.x0 + G.curRoom.w - 0.2);
        e.tz = clamp(player.z + player.vz * 0.4, G.curRoom.z0 + 2.2, G.curRoom.z0 + G.curRoom.h - 0.2);
        e.sx0 = e.x; e.sz0 = e.z;
        e.marker = new THREE.Mesh(portalGeo, new THREE.MeshBasicMaterial({ map: markTex, color: 0xff4a2a, transparent: true, opacity: 0.6, depthWrite: false, blending: THREE.AdditiveBlending, ...DECAL }));
        e.marker.position.set(e.tx, 0.05, e.tz); e.marker.scale.setScalar(2.7); scene.add(e.marker); // the ring's bright edge = the 2.6 hit
      }
    }
  } else if (e.state === 'jump') {
    const p = 1 - e.st / e.jd;
    e.y = Math.sin(p * Math.PI) * 3.2;
    e.x = lerp(e.sx0, e.tx, p); e.z = lerp(e.sz0, e.tz, p);
    e.sx = p < 0.5 ? 0.8 : 0.92; e.sy = p < 0.5 ? 1.3 : 1.1; e.noContact = true;
    if (e.marker) e.marker.material.opacity = 0.3 + p * 0.6;
    if (e.st <= 0) {
      e.y = 0; e.state = 'wait'; e.st = enraged ? 0.5 : 0.75; e.squash = 0.8;
      if (e.marker) { scene.remove(e.marker); e.marker.material.dispose(); e.marker = null; }
      addShake(0.7); sfx('slam'); G.hitstop = Math.max(G.hitstop, 0.06);
      addRing(e.x, e.z, 0.5, 4, 0.45, 0x6a7aff);
      splat(e.x, e.z, 0x1a1a8a, 3.2);
      chunk(e.x, 0.3, e.z, 0x6a7aff, 14, 7, 0.16);
      if (inMark({ kind: 'ring', x: e.x, z: e.z, len: 2.6 })) damagePlayer(2, e.x, e.z); // the landing marker (radius 2.7) is the truth
      const n = enraged ? 16 : 12;
      for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2 + (e.jumps % 2) * 0.2; enemyShoot(e, a, 4.2, 0x5a6aff, 1.0, 0, 'slime'); }
      if (e.jumps % 3 === 0) for (let k = 0; k < (enraged ? 3 : 2); k++) { portals.push(makePortal(e.x + rr(-3, 3), e.z + rr(-3, 3), 'slime', 0.7, k * 0.1)); }
    }
  } else if (e.state === 'spray') {
    e.sx = 1 + Math.sin(e.t * 20) * 0.06; e.sy = 1 - Math.sin(e.t * 20) * 0.06; e.tilt = Math.sin(e.t * 7) * 0.08;
    e.cool = (e.cool || 0) - dt;
    if (e.cool <= 0) { e.cool = enraged ? 0.09 : 0.13; e.spin += 0.37; for (let k = 0; k < 3; k++) enemyShoot(e, e.spin + k * Math.PI * 2 / 3, 3.8, 0x7a5aff, 0.9, 0, 'slime'); sfx('spit'); }
    if (e.st <= 0) { e.state = 'wait'; e.st = 0.6; }
  }
  $('bossfill').style.transform = `scaleX(${Math.max(0, e.hp / e.maxHp)})`;
}

// ---- The Mimic Lord (user 11-14: "looks like floating, add gold trail, coin falling"): planted on the floor and moves in heavy
// hops (crouch, hop, thud + dust + lid clatter), spilling gold coins that bounce and roll off him; a real tongue that shoots down
// its marked lane while the chest lunges; fans of spinning gold coins; decoy chests that bite
const ML_TONGUE = 0xff5a2a; // its tell: hot red-orange (never Pip pink)
const ML_MOUTH = [0.03, 0.54]; // the middle of the open lid, inside the mouth (share of the sprite: x from the centre, y up from the feet)
const _mlM = new THREE.Vector3(), _mlD = new THREE.Vector3(), _mlP = new THREE.Vector3(), _mlU = new THREE.Vector3(), _mlA = new THREE.Vector3();
const _mlY = new THREE.Vector3(0, 1, 0), _mlX = new THREE.Vector3(1, 0, 0), _mlQ = new THREE.Quaternion(), _mlS = new THREE.Vector3(), _mlMx = new THREE.Matrix4();
// the tongue from the middle of his mouth (follows the lunge, the facing and the lean) to its lane, sloping down to the floor.
// amp/wph: a sideways wave sin(2.6 turns along it - wph) that grows toward the tip (wph rising = runs out, falling = runs in);
// curl: the tip lifts and hooks back toward the mouth; tipS: tip size (the snap pop). len <= 0.05 hides it.
function mlTongue(e, len, amp = 0, wph = 0, curl = 0, tipS = 1) {
  const T = tongueMesh(), ud = T.userData, m = e.mesh, fx = Math.cos(e.la), fz = Math.sin(e.la);
  if (T.parent !== scene) scene.add(T);
  T.visible = len > 0.05; if (!T.visible) return;
  _mlM.set(ML_MOUTH[0] * (e.face < 0 ? -1 : 1) * m.scale.x, ML_MOUTH[1] * m.scale.y, 0).applyQuaternion(m.quaternion).add(m.position); // the mouth in the world
  const reach = e.r * 0.45 + len, k = clamp(len / 2, 0, 1); // the tip lands where the lane says (a short lick droops off the lip)
  const tx = e.x + fx * reach, tz = e.z + fz * reach, ty = lerp(_mlM.y - 0.25, 0.22, k);
  _mlD.set(tx - _mlM.x, ty - _mlM.y, tz - _mlM.z); const L = _mlD.length() || 0.01; _mlD.multiplyScalar(1 / L);
  _mlP.set(-_mlD.z, 0, _mlD.x); if (_mlP.lengthSq() < 1e-6) _mlP.set(1, 0, 0); _mlP.normalize(); _mlU.crossVectors(_mlP, _mlD); // sideways + "up" across it
  const P = ud.pts, th = clamp(len / 0.7, 0.5, 1);
  for (let i = 0; i <= TG_N; i++) {
    const s = i / TG_N, w = amp * Math.sin(s * Math.PI * 0.5) * Math.sin(s * 16.3 - wph), a = L * s - curl * 0.45 * s * s * s, u = curl * s * s;
    P[i * 3] = _mlM.x + _mlD.x * a + _mlP.x * w + _mlU.x * u; P[i * 3 + 1] = _mlM.y + _mlD.y * a + _mlU.y * u; P[i * 3 + 2] = _mlM.z + _mlD.z * a + _mlP.z * w + _mlU.z * u;
  }
  for (let i = 0; i < TG_N; i++) { // segment i from point i to i+1, a ball on its root joint
    const s = i / TG_N, r = (0.21 - 0.08 * s) * th;
    _mlA.set(P[i * 3 + 3] - P[i * 3], P[i * 3 + 4] - P[i * 3 + 1], P[i * 3 + 5] - P[i * 3 + 2]); const sl = _mlA.length() || 0.001;
    _mlQ.setFromUnitVectors(_mlY, _mlA.multiplyScalar(1 / sl));
    ud.segs.setMatrixAt(i, _mlMx.compose(_mlS.set(P[i * 3] + P[i * 3 + 3], P[i * 3 + 1] + P[i * 3 + 4], P[i * 3 + 2] + P[i * 3 + 5]).multiplyScalar(0.5), _mlQ, _mlA.set(r, sl, r)));
    ud.joints.setMatrixAt(i, _mlMx.compose(_mlS.set(P[i * 3], P[i * 3 + 1], P[i * 3 + 2]), _mlQ.identity(), _mlA.set(r, r, r)));
  }
  ud.segs.instanceMatrix.needsUpdate = true; ud.joints.instanceMatrix.needsUpdate = true;
  const j = TG_N * 3; _mlA.set(P[j] - P[j - 3], P[j + 1] - P[j - 2], P[j + 2] - P[j - 1]).normalize();
  ud.tip.position.set(P[j], P[j + 1], P[j + 2]); ud.tip.quaternion.setFromUnitVectors(_mlX, _mlA); ud.tip.scale.set(1.25 * tipS * th, 0.6 * tipS * th, tipS * th);
}
function mlLand(e, big) { // the thud: dust, lid clatter, coins spill out
  e.squash = big ? 0.8 : 0.55; sfx(big ? 'thud' : 'land'); if (big) sfx('clink'); addShake(big ? 0.18 : 0.07);
  addRing(e.x, e.z, 0.4, e.r * 1.9, 0.3, 0xc8a070); for (let k = 0; k < 8; k++) { const a = k / 8 * 6.28; spark(e.x + Math.cos(a) * e.r, 0.1, e.z + Math.sin(a) * e.r * 0.8, 0xa89070, { vx: Math.cos(a) * 3, vz: Math.sin(a) * 3, vy: 0.6, s: 0.45, life: 0.4, drag: 4 }); }
  coinSpill(e.x, 0.9, e.z, big ? 6 : 3, 2.6, 3.4);
}
function updateMimicLord(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, en = e.hp < e.maxHp * 0.5, ux = dx / (dist || 1), uz = dz / (dist || 1);
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.tilt = 0; e.face = dx > 0 ? 1 : -1;
  if (e.state === 'idle') { // heavy hops toward you: crouch, hop, land (no hovering)
    e.hopT = (e.hopT || 0) + dt; const H = 0.62, ph = e.hopT % H / H; // 0..0.3 crouch on the floor, 0.3..1 in the air
    const far = dist > 2.4, coinsNext = (e.jumps + 1) % 3 === 2; // a coin fan next: he hops back out to range first (spacing)
    if (coinsNext) keepBand(e, dist, ux, uz, e.d.band, e.speed * 1.5);
    if (ph < 0.3) { const k = ph / 0.3; e.y = 0; e.sx = 1 + 0.1 * k; e.sy = 1 - 0.12 * k; }
    else { const k = (ph - 0.3) / 0.7; e.y = Math.sin(k * Math.PI) * 0.45; e.sx = 0.94; e.sy = 1.08; if (coinsNext) { e.mx = e.bmx; e.mz = e.bmz; } else if (far) { e.mx = ux * e.speed * 1.5; e.mz = uz * e.speed * 1.5; } e.tilt = Math.sin(k * Math.PI * 2) * 0.06; if (fxP(0.08)) coinSpill(e.x, 0.6 + e.y, e.z, 1, 1.2, 1.5); }
    if (e.lastPh !== undefined && ph < e.lastPh) mlLand(e, false); // landed
    e.lastPh = ph;
    if (e.lick > 0) { e.lick -= dt; const q = 1 - Math.max(0, e.lick) / 0.4; mlTongue(e, 0.4 * Math.sin(Math.PI * q), 0.08, G.time * 18, 0.5 - 0.2 * q); } // a quick lick of the lip, then gone
    else if (ph < 0.3 && e.st > 0.5 && Math.random() < dt * 0.3) e.lick = 0.4;
    if (e.st <= 0 && ph < 0.05) {
      e.lick = 0;
      e.y = 0; e.jumps++; const k = e.jumps % 3;
      if (k === 1) { freeFoeFx(e); e.state = 'lwind'; e.st = e.wind = 0.75; e.la = Math.atan2(uz, ux); e.tg = teleGet('lane', ML_TONGUE); sfx('lock'); }
      else if (k === 2) { e.state = 'coins'; e.st = e.wind = en ? 0.6 : 0.75; e.shots = 0; }
      else { e.state = 'decoys'; e.st = 0.9; mimicDecoys(e, r, en ? 3 : 2); mlLand(e, true); }
    }
  } else if (e.state === 'lwind') { // lid gapes, the tongue licks at the lip, the lane fills and locks
    const k = 1 - e.st / e.wind; if (k < 0.6) e.la = Math.atan2(uz, ux);
    e.y = 0; e.tint = k; e.sy = 1 + 0.1 * k; e.sx = 1 - 0.04 * k; e.shake = 0.03 + 0.03 * k; e.tilt = -Math.cos(e.la) * 0.08 * k;
    const fx = Math.cos(e.la), fz = Math.sin(e.la), x0 = e.x + fx * e.r * 0.45, z0 = e.z + fz * e.r * 0.45;
    e.lashL = Math.min(7, laneLen(x0, z0, fx, fz, 7, 0.2)); teleSet(e.tg, x0, z0, e.la, e.lashL, 1.0, k);
    { // the tongue slithers out of the mouth (a wave running out along it, the tip curling and tasting), then draws back a hair before the lash
      const out = ease3(Math.min(1, k * 1.7)), pull = clamp((k - 0.82) / 0.18, 0, 1);
      mlTongue(e, (0.12 + 0.75 * out + 0.07 * Math.sin(G.time * 9)) * (1 - 0.35 * pull), 0.13 + 0.05 * out, G.time * 13, 0.42 - 0.2 * out + 0.12 * Math.sin(G.time * 7) + 0.25 * pull);
    }
    if (e.st <= 0) { teleFree(e); e.state = 'lash'; e.st = 0.12; e.tint = 0; e.hitDone = false; sfx('whoosh'); }
  } else if (e.state === 'lash') { // SHLURP: the tongue shoots out the lane, the chest lunges after it
    const p = 1 - e.st / 0.12; mlTongue(e, lerp(0.5, e.lashL, ease3(p)), 0.45 * Math.sin(Math.PI * p), 4 + p * 16, 0.15 * (1 - p)); // a whip wave cracks out and straightens on the lane
    e.mx = Math.cos(e.la) * 3.3; e.mz = Math.sin(e.la) * 3.3; e.sx = 1.12; e.sy = 0.92; e.tilt = Math.cos(e.la) > 0 ? 0.12 : -0.12;
    if (e.st <= 0) {
      mlTongue(e, e.lashL); const tx = e.x + Math.cos(e.la) * (e.r * 0.45 + e.lashL), tz = e.z + Math.sin(e.la) * (e.r * 0.45 + e.lashL);
      const hit = inMark(e.mk); if (hit) { damagePlayer(1, e.x, e.z); e.flash = 0.8; } e.hs = hit ? 0.08 : 0.04; // the lane is the truth
      splat(tx, tz, 0xc0304a, 0.9, 0.85); spark(tx, 0.3, tz, 0xffffff, { s: 1, life: 0.08, drag: 0 }); for (let q = 0; q < 6; q++) spark(tx, 0.3, tz, 0xff7a9a, { vx: rr(-3, 3), vy: rr(1, 3), vz: rr(-3, 3), s: 0.25, life: 0.3, drag: 3, grav: -8 });
      e.state = 'lhold'; e.st = 0.14; addShake(0.12);
    }
  } else if (e.state === 'lhold') { const q = e.st / 0.14; mlTongue(e, e.lashL * (1 + 0.03 * Math.sin(G.time * 50)), 0.14 * q, G.time * 60, 0, 1 + 0.6 * q); if (e.st <= 0) { e.state = 'lback'; e.st = 0.28; } } // the tip snaps (pops, shivers)
  else if (e.state === 'lback') { // reels it back in fast, a wave running back up it, the tip flicking up as it slurps into the mouth
    const p = 1 - e.st / 0.28; mlTongue(e, e.lashL * (1 - ease3(p * 1.15)), 0.3 * Math.sin(Math.PI * p), -p * 26, 0.35 * p);
    if (e.st <= 0) { mlTongue(e, 0); e.state = 'idle'; e.st = en ? 0.9 : 1.4; e.squash = 0.5; sfx('clink'); }
  } else if (e.state === 'coins') { // the lid gapes (the tell), then two fans of spinning gold coins
    e.y = 0; e.tint = Math.min(1, 1 - e.st / e.wind + 0.2); e.sy = 1 + 0.12 * e.tint; e.shake = 0.04;
    if (fxP(0.3)) spark(e.x + rr(-0.5, 0.5), 1.4, e.z, 0xffe680, { vy: 2, s: 0.4, life: 0.3, drag: 1 });
    if (e.st <= 0) {
      const n = en ? 9 : 7, a0 = Math.atan2(dz, dx);
      for (let v = 0; v < 2; v++) later(v * 0.35, () => { if (e.dead) return; for (let k = 0; k < n; k++) { const a = a0 + (k - (n - 1) / 2) * 0.24 + v * 0.12, p = enemyShoot(e, a, 3.3, 0xffd34f, 0.6, 0, 'coin'); p.x = e.x + Math.cos(a) * e.r; p.z = e.z + Math.sin(a) * e.r; } sfx('coin'); e.squash = 0.6; coinSpill(e.x, 1.1, e.z, 3, 2, 3); });
      e.tint = 0; e.state = 'idle'; e.st = en ? 1.2 : 1.7; addShake(0.2);
    }
  } else if (e.st <= 0) { e.state = 'idle'; e.st = en ? 1 : 1.5; }
  if (!(e.state === 'lwind' || e.state === 'lash' || e.state === 'lhold' || e.state === 'lback' || (e.state === 'idle' && e.lick > 0)) && tongueM && tongueM.visible) tongueM.visible = false;
}
// decoy chests, away from you; at most 4 sleeping or awake at once
function mimicDecoys(e, r, n) {
  const live = enemies.filter((o) => !o.dead && o.mini).length; n = Math.min(n, 4 - live);
  sfx('lock'); e.squash = 0.8; addShake(0.3);
  for (let q = 0, tries = 0; q < n && tries < 30; tries++) {
    const x = r.x0 + 1.5 + rand() * (r.w - 1), z = r.z0 + 1.5 + rand() * (r.h - 1);
    if (solid(x, z, false) || Math.hypot(x - player.x, z - player.z) < 3) continue;
    const m = spawnEnemy('mimic', x, z); m.mini = true; m.sleep = true; m.hp *= 0.3; m.maxHp = m.hp; m.spawn = 0.4;
    killMesh(m.mesh); m.mesh = makeSprite('items', 0.75, 4); // a plain treasure chest
    burst(x, 0.4, z, 0xffd34f, 8, 3, 0.3, 0.4); q++;
  }
}

// ---- The Frost Matriarch: keeps her distance; frost rings with a gap to slip through, icicles in lines, ice that makes you slide
// Her ice (user: "art of projectile is shit"): faceted crystals, not white bars. One shared unlit shader: pale cyan lit facets,
// deep indigo shade, a violet rim and crisp white facet edges (barycentric lines). The indigo/violet keeps it hostile next to
// Pip's own pale frost spells. Opaque + depth-written (no sorting); spikes grow / shrink by scale. Pooled instanced meshes.
function bipyramidGeo(sides, botY, midY, topY, midR = 1) { // a bipyramid: every facet a triangle, so every edge is a real facet edge
  const P = [], B = [], ring = [];
  for (let i = 0; i < sides; i++) { const a = i / sides * Math.PI * 2, r = midR * (i % 2 ? 0.82 : 1); ring.push([Math.cos(a) * r, midY, Math.sin(a) * r]); }
  const tri = (a, b, c) => { P.push(...a, ...b, ...c); B.push(1, 0, 0, 0, 1, 0, 0, 0, 1); };
  for (let i = 0; i < sides; i++) { const a = ring[i], b = ring[(i + 1) % sides]; tri(b, a, [0, topY, 0]); tri(a, b, [0, botY, 0]); }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('aBary', new THREE.Float32BufferAttribute(B, 3));
  return g;
}
const iceCrystalMat = new THREE.ShaderMaterial({
  uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uDeep: { value: new THREE.Color(0x2b3496) }, uRim: { value: new THREE.Color(0x8a4cf0) }, uCore: { value: new THREE.Color(0xb4f2ff) }, uEdge: { value: new THREE.Color(0xf4fdff) } }]),
  vertexShader: `attribute vec3 aBary; attribute float aK; varying vec3 vB; varying vec3 vV; varying float vK; varying float vY;
    #include <fog_pars_vertex>
    void main(){ vB = aBary; vK = aK; vY = position.y; vec4 mvPosition = modelViewMatrix * instanceMatrix * vec4(position, 1.0); vV = mvPosition.xyz; gl_Position = projectionMatrix * mvPosition;
      #include <fog_vertex>
    }`,
  fragmentShader: `uniform vec3 uDeep; uniform vec3 uRim; uniform vec3 uCore; uniform vec3 uEdge; varying vec3 vB; varying vec3 vV; varying float vK; varying float vY;
    #include <fog_pars_fragment>
    void main(){
      vec3 n = normalize(cross(dFdx(vV), dFdy(vV)));
      float l = clamp(dot(n, normalize(vec3(-0.35, 0.8, 0.5))), 0.0, 1.0), f = 1.0 - abs(n.z);
      float e = min(min(vB.x, vB.y), vB.z), w = fwidth(e) * 1.4 + 0.02, edge = 1.0 - smoothstep(0.0, w, e);
      vec3 c = mix(uDeep, uCore, smoothstep(-0.1, 0.75, l));
      c = mix(c, uRim, f * f * 0.75);
      c = mix(c, uCore * 1.15, smoothstep(0.12, 0.34, e) * l * 0.35); // a paler heart in each facet
      c += uEdge * edge * (0.45 + 0.55 * l) + vec3(pow(l, 10.0) * 0.5);
      gl_FragColor = vec4(c * vK, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      #include <fog_fragment>
    }`,
  fog: true,
});
function crystalBatch(geo, max) {
  const m = new THREE.InstancedMesh(geo, iceCrystalMat, max);
  m.geometry.setAttribute('aK', new THREE.InstancedBufferAttribute(new Float32Array(max), 1).setUsage(THREE.DynamicDrawUsage));
  m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.count = 0; m.frustumCulled = false; scene.add(m); return m;
}
const fringMesh = crystalBatch(bipyramidGeo(5, -0.25, 0.18, 1, 1), MOBILE ? 300 : 440); // her Frost Diver crystals: base under the floor, long point up
const iclMesh = crystalBatch(bipyramidGeo(6, 0, 0.84, 1.06, 1), 48); // icicles: long point down (tip at y = 0)
const icls = Array.from({ length: 48 }, () => ({ on: false, x: 0, z: 0, t: 0, warn: 1, stuck: 0, sp: 0 }));
const frR = (a, b) => a + Math.random() * (b - a), FR_GLIT = [0xeaffff, 0xa8ecff, 0x9c7aff]; // VFX only: never the seeded rand
const frM = new THREE.Matrix4(), frQ = new THREE.Quaternion(), frS = new THREE.Vector3(), frV = new THREE.Vector3(), frD = new THREE.Vector3(), frUp = new THREE.Vector3(0, 1, 0);
function frostPut(m, n, x, y, z, w, h, dx, dy, dz, k) {
  m.setMatrixAt(n, frM.compose(frV.set(x, y, z), frQ.setFromUnitVectors(frUp, frD.set(dx, dy, dz).normalize()), frS.set(w, h, w)));
  m.geometry.attributes.aK.array[n] = k;
}
function frostShatter(x, z, big) { // ice breaking on the floor: chunks, glitter, a cold mist puff and a frost mark
  chunk(x, 0.35, z, 0xdff6ff, big ? 5 : 3, 3.2, 0.1); chunk(x, 0.35, z, 0x4a52b8, big ? 2 : 1, 2.6, 0.08);
  burst(x, 0.3, z, 0xeaffff, big ? 8 : 5, 3.4, 0.2, 0.35); burst(x, 0.2, z, 0x5d6fc0, 3, 1.2, 0.85, 0.55);
  splat(x, z, 0x86c4ec, big ? 0.55 : 0.4, 0.75);
}
function spawnIcicle(x, z, warn) { const o = icls.find((q) => !q.on); if (!o) return null; Object.assign(o, { on: true, x, z, t: 0, warn, stuck: 0, sp: Math.random() * 6.28 }); return o; }
function updateIcicles(dt) {
  let n = 0;
  for (const o of icls) {
    if (!o.on) continue;
    let y, s, k = 1;
    if (o.stuck > 0) { o.stuck -= dt; if (o.stuck <= 0) { o.on = false; continue; } s = o.stuck / 0.35; y = -0.35 * (1 - s); } // the broken stump sinks away
    else {
      o.t += dt; const fall = Math.min(0.26, o.warn * 0.4), u = (o.t - (o.warn - fall)) / fall;
      s = Math.min(1, o.t / 0.22); y = u > 0 ? Math.max(0, 3.4 * (1 - u * u)) : 3.4 + Math.sin(o.t * 9 + o.sp) * 0.05; // forms high up, then drops
      k = 0.75 + 0.25 * s;
      if (u <= 0 && fxP(0.12)) spark(o.x + frR(-0.12, 0.12), y + 0.5, o.z, 0xeaffff, { vy: -0.4, s: 0.16, life: 0.3, drag: 0 });
      if (u > 0 && fxP(0.3)) spark(o.x + frR(-0.15, 0.15), y + frR(0.5, 1.2), o.z + frR(-0.15, 0.15), 0xbfe6ff, { vy: 1, s: 0.16, life: 0.2, drag: 0 }); // a short frosty streak as it falls
    }
    frostPut(iclMesh, n++, o.x, y, o.z, 0.21 * s, 1.3 * Math.max(0.05, s), Math.sin(o.sp) * 0.06, 1, Math.cos(o.sp) * 0.06, k);
  }
  iclMesh.count = n; iclMesh.instanceMatrix.needsUpdate = true; iclMesh.geometry.attributes.aK.needsUpdate = true;
}
// Her FROST DIVER burst (user: rings looked bad -> "frost diver, all directions, 16 directions"): a hostile take on Pip's Frost
// Diver. 16 lines all around her (one aimed at Pip), each marked first by a thin violet streak on its exact path (0.6 s), then
// crystals stab up along it from her outward (FD_SPD tiles/s, to the wall or FD_REACH). Standing on a line when its crystals
// pass = 1 hit; the safe spots are the wedges between lines, wider farther out. Enraged: a second burst turned 11.25 deg.
// Hostile look: the shared indigo/violet crystal shader (Pip's are pale Lambert). Own pools, nothing made per cast or frame.
const FD_LINES = 48, FD_CR = MOBILE ? 300 : 440, FD_SPD = 8, FD_STEP = MOBILE ? 0.62 : 0.48, FD_REACH = 9.5, FD_D0 = 0.9;
const fdStreakTex = canvasTex(128, 32, (g, w, h) => { // a thin violet path: soft band, bright centre line, faded ends
  const gr = g.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.35, 'rgba(255,255,255,.35)'); gr.addColorStop(0.5, 'rgba(255,255,255,1)'); gr.addColorStop(0.65, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.globalCompositeOperation = 'destination-in';
  const ge = g.createLinearGradient(0, 0, w, 0); ge.addColorStop(0, 'rgba(0,0,0,0)'); ge.addColorStop(0.06, 'rgba(0,0,0,1)'); ge.addColorStop(0.92, 'rgba(0,0,0,1)'); ge.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = ge; g.fillRect(0, 0, w, h);
}, false);
fdStreakTex.magFilter = THREE.LinearFilter;
const fdStreakMesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: fdStreakTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, ...DECAL }), FD_LINES);
fdStreakMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); fdStreakMesh.setColorAt(0, tmpC.set(0)); fdStreakMesh.count = 0; fdStreakMesh.frustumCulled = false; fdStreakMesh.renderOrder = 1; scene.add(fdStreakMesh);
const fdLines = Array.from({ length: FD_LINES }, () => ({ on: false, x0: 0, z0: 0, ca: 1, sa: 0, L: 1, t: 0, warn: 0.6, d: 0, k: 0, end: false }));
const fdCr = Array.from({ length: FD_CR }, () => ({ t: 9, x: 0, z: 0, h: 1, w: 0.1, dx: 0, dz: 0 }));
let fdHead = 0;
function fdReset() { for (const l of fdLines) l.on = false; for (const c of fdCr) c.t = 9; fdStreakMesh.count = 0; }
function frostDiverBurst(e, rot, warn) {
  for (let i = 0; i < 16; i++) {
    const ln = fdLines.find((q) => !q.on); if (!ln) break;
    const a = rot + i * Math.PI / 8, ca = Math.cos(a), sa = Math.sin(a);
    let L = FD_REACH; for (let d = FD_D0; d < FD_REACH; d += 0.25) if (solid(e.x + ca * d, e.z + sa * d, true)) { L = d - 0.15; break; }
    if (L <= FD_D0 + 0.2) continue;
    Object.assign(ln, { on: true, x0: e.x, z0: e.z, ca, sa, L, t: 0, warn, d: FD_D0, k: 0, end: false });
  }
  sfx('frost');
}
function updateFrostDivers(dt) {
  let ns = 0, n = 0;
  for (const ln of fdLines) {
    if (!ln.on) continue;
    ln.t += dt;
    const live = ln.t >= ln.warn, head = live ? FD_D0 + (ln.t - ln.warn) * FD_SPD : FD_D0;
    while (live && ln.d <= Math.min(head, ln.L)) { // crystals erupt as the head passes; the hit is checked right there
      const side = ln.k % 2 ? 1 : -1, off = side * 0.1, x = ln.x0 + ln.ca * ln.d - ln.sa * off, z = ln.z0 + ln.sa * ln.d + ln.ca * off;
      const c = fdCr[fdHead]; fdHead = (fdHead + 1) % FD_CR;
      c.t = 0; c.x = x; c.z = z; c.h = 0.75 + Math.random() * 0.4; c.w = 0.13 + Math.random() * 0.04; c.dx = ln.ca * 0.45 - ln.sa * side * 0.25; c.dz = ln.sa * 0.45 + ln.ca * side * 0.25;
      if (ln.k % 3 === 0 && Math.random() < (MOBILE ? 0.3 : 0.5)) spark(x, 0.25, z, ln.k % 2 ? 0xdff6ff : 0x9c7aff, { vx: ln.ca * 1.2, vz: ln.sa * 1.2, vy: 0.5, s: 0.7, life: 0.5, drag: 2.5 });
      if (player.alive && Math.hypot(player.x - x, player.z - z) < 0.5) damagePlayer(1, ln.x0, ln.z0);
      ln.d += FD_STEP; ln.k++;
    }
    if (live && !ln.end && head > ln.L) { ln.end = true; const ex = ln.x0 + ln.ca * ln.L, ez = ln.z0 + ln.sa * ln.L; burst(ex, 0.4, ez, 0xdff6ff, MOBILE ? 3 : 5, 2.5, 0.22, 0.3); chunk(ex, 0.4, ez, 0x8c7cff, 1, 2, 0.07); }
    const gone = live ? ln.t - ln.warn - (ln.L - FD_D0) / FD_SPD : -1; // time since the head reached the end
    if (gone > 0.6) { ln.on = false; continue; }
    // the path streak: fades in and pulses as the tell, then fades out behind the crystals
    const f = !live ? Math.min(1, ln.t / 0.15) * (0.75 + 0.25 * Math.sin(ln.t * 30)) : gone > 0 ? 0.35 * (1 - gone / 0.6) : 0.35; // dimmer once live: the crystals carry it
    const len = ln.L - FD_D0, mid = FD_D0 + len / 2;
    frV.set(ln.x0 + ln.ca * mid, 0.04, ln.z0 + ln.sa * mid); frQ.setFromAxisAngle(frUp, -Math.atan2(ln.sa, ln.ca)); frS.set(len / 2 + 0.1, 1, 0.22);
    fdStreakMesh.setMatrixAt(ns, frM.compose(frV, frQ, frS)); fdStreakMesh.setColorAt(ns++, tmpC.set(0xa070ff).multiplyScalar(f));
  }
  for (const c of fdCr) { // crystals: stab up, hold, then shrink and sink away (Pip's Frost Diver timing)
    if (c.t > 0.5) continue;
    c.t += dt; if (c.t > 0.5 || n >= FD_CR) continue;
    const up = c.t < 0.07 ? 1 - (1 - c.t / 0.07) ** 3 : 1, q = c.t < 0.25 ? 0 : (c.t - 0.25) / 0.25;
    frostPut(fringMesh, n++, c.x, -c.h * 0.45 * q * q, c.z, c.w * (1 - 0.5 * q), Math.max(0.001, c.h * up * (1 - 0.6 * q)), c.dx, 1, c.dz, 0.9);
  }
  fringMesh.count = n; fringMesh.instanceMatrix.needsUpdate = true; fringMesh.geometry.attributes.aK.needsUpdate = true;
  fdStreakMesh.count = ns; fdStreakMesh.instanceMatrix.needsUpdate = true; if (fdStreakMesh.instanceColor) fdStreakMesh.instanceColor.needsUpdate = true;
}
function updateFrostRings(dt) {
  updateIcicles(dt); updateFrostDivers(dt);
  for (let i = ices.length - 1; i >= 0; i--) { // ice patches: grow in (they don't hurt), last a while, then melt
    const p = ices[i]; p.t += dt;
    p.mk.scale.setScalar(p.r * Math.min(1, p.t / 0.6)); p.mk.material.opacity = 0.9 * Math.min(1, (p.life - p.t) / 0.8, p.t / 0.25);
    if (p.t >= p.life) { scene.remove(p.mk); p.mk.material.dispose(); ices.splice(i, 1); }
  }
}
const onIce = (x, z) => ices.some((p) => p.t > 0.6 && Math.hypot(x - p.x, z - p.z) < p.r);
function icicleLine(e, a, warn) { // a line of markers across your path; the icicles drop along it in order
  const cx = player.x, cz = player.z, px = -Math.sin(a), pz = Math.cos(a);
  for (let k = -5; k <= 5; k++) {
    const x = cx + px * k * 0.85, z = cz + pz * k * 0.85;
    if (cellAt(x, z) !== FLOOR) continue;
    later(Math.abs(k) * 0.04, () => {
      if (e.dead) return;
      const mk = addMarker(x, z, 0.5, 0x8c8cff), ic = spawnIcicle(x, z, warn); // the icicle forms overhead, drops on the beat
      later(warn, () => {
        scene.remove(mk); mk.material.dispose();
        if (ic && ic.on && ic.x === x && ic.z === z) ic.stuck = 0.35;
        frostShatter(x, z, true);
        if (Math.hypot(player.x - x, player.z - z) < 0.55) damagePlayer(1, x, z);
      });
    });
  }
  sfx('frost');
}
function updateFrost(e, dt, dx, dz, dist) {
  const r = rooms.find((q) => q.active) || G.curRoom, en = e.hp < e.maxHp * 0.5, ux = dx / (dist || 1), uz = dz / (dist || 1);
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.face = dx > 0 ? 1 : -1;
  e.y = 0.15 + Math.sin(e.t * 1.8) * 0.08; e.tilt = Math.sin(e.t * 1.2) * 0.05; // she glides
  if (e.state === 'idle') {
    keepBand(e, dist, ux, uz); e.mx = e.bmx; e.mz = e.bmz; // keeps ~5.5 away, circling; backs off when Pip closes in
    if (e.st <= 0) {
      e.jumps++; const k = e.jumps % 3;
      if (k === 1) { e.state = 'rings'; e.st = 1.2; const g = Math.atan2(dz, dx); rr(-1.6, 1.6); frostDiverBurst(e, g, 0.6); if (en) later(0.8, () => { rr(0.5, 1.5); if (!e.dead) frostDiverBurst(e, g + Math.PI / 16, 0.5); }); } // 16 Frost Diver lines, one at Pip (rr kept: same seeded stream)
      else if (k === 2) { e.state = 'icicles'; e.st = 1.3; const a = Math.atan2(dz, dx); icicleLine(e, a, 0.8); if (en) later(0.5, () => { if (!e.dead) icicleLine(e, a + Math.PI / 2, 0.7); }); }
      else { e.state = 'ice'; e.st = 0.9; iceFloor(r, en ? 4 : 3); }
    }
  } else if (e.state === 'rings' || e.state === 'icicles' || e.state === 'ice') { // staff raised: a pale glow while she casts
    e.tint = 0.4 + Math.sin(e.t * 20) * 0.2; e.sy = 1.04;
    if (e.st <= 0) { e.tint = 0; e.state = 'idle'; e.st = en ? 1.1 : 1.6; }
  } else if (e.st <= 0) { e.state = 'idle'; e.st = 1.4; }
}
const iceFloorTex = canvasTex(256, 256, (g) => { // the Matriarch's ice sheet: a thin frosted sheen the floor shows through, fine white cracks, a soft violet rim
  const pts = []; for (let i = 0; i < 26; i++) { const a = i / 26 * 6.2832, r = 104 + (i % 2 ? -10 : 4) + hash(i, 5) * 14; pts.push([128 + Math.cos(a) * r, 128 + Math.sin(a) * r]); }
  const path = () => { g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath(); };
  const grd = g.createRadialGradient(110, 104, 8, 128, 128, 122);
  grd.addColorStop(0, 'rgba(225,248,255,0.2)'); grd.addColorStop(0.7, 'rgba(160,210,250,0.13)'); grd.addColorStop(1, 'rgba(120,130,235,0.3)');
  path(); g.fillStyle = grd; g.fill();
  g.save(); path(); g.clip(); // frost sheen: a few soft diagonal streaks
  g.strokeStyle = 'rgba(235,250,255,0.13)'; g.lineWidth = 14; for (let k = 0; k < 3; k++) { g.beginPath(); g.moveTo(40 + k * 50, 230); g.lineTo(120 + k * 60, 20); g.stroke(); }
  g.restore();
  g.lineJoin = 'miter'; g.lineWidth = 3; g.strokeStyle = 'rgba(90,50,190,0.55)'; path(); g.stroke();
  g.lineWidth = 1.2; g.strokeStyle = 'rgba(210,240,255,0.6)'; path(); g.stroke();
  g.strokeStyle = 'rgba(255,255,255,0.55)'; g.lineWidth = 1;
  for (let k = 0; k < 9; k++) { let x = 128 + (hash(k, 3) - 0.5) * 30, y = 128 + (hash(k, 4) - 0.5) * 30, a = k / 9 * 6.2832 + hash(k, 9); g.beginPath(); g.moveTo(x, y);
    for (let s = 0; s < 6; s++) { a += (hash(k, s) - 0.5) * 0.9; x += Math.cos(a) * 15; y += Math.sin(a) * 15; g.lineTo(x, y);
      if (s === 2) { g.moveTo(x, y); const b = a + 0.9; g.lineTo(x + Math.cos(b) * 12, y + Math.sin(b) * 12); g.moveTo(x, y); } } g.stroke(); }
});
iceFloorTex.magFilter = THREE.LinearFilter;
function iceFloor(r, n) {
  for (const p of ices.splice(0)) { scene.remove(p.mk); p.mk.material.dispose(); } // only one set at a time
  for (let q = 0, tries = 0; q < n && tries < 20; tries++) {
    const x = clamp(player.x + rr(-3.5, 3.5), r.x0 + 1.5, r.x0 + r.w + 0.5), z = clamp(player.z + rr(-3.5, 3.5), r.z0 + 1.5, r.z0 + r.h + 0.5);
    if (cellAt(x, z) !== FLOOR) continue;
    const mk = new THREE.Mesh(markerGeo, new THREE.MeshBasicMaterial({ map: iceFloorTex, transparent: true, opacity: 0, depthWrite: false, ...DECAL })); // a sheet of cracked ice, not a bubble
    mk.position.set(x, 0.05, z); mk.rotation.y = Math.random() * 6.28; mk.scale.setScalar(0.1); scene.add(mk);
    ices.push({ x, z, r: rr(1.3, 1.8), t: 0, life: 7, mk }); q++;
  }
  sfx('frost');
}

// ---- The Clockwork Sentinel: a slow walker; a rotating four-way laser cross, ricocheting saw gears, and an overheat
// where its core is exposed and takes double damage (the "hit it now" moment)
function updateSentinel(e, dt, dx, dz, dist) {
  const en = e.hp < e.maxHp * 0.5, ux = dx / (dist || 1), uz = dz / (dist || 1);
  e.mx = 0; e.mz = 0; e.sx = 1; e.sy = 1; e.tilt = 0; e.face = dx > 0 ? 1 : -1;
  if (e.state === 'idle') {
    e.tilt = Math.sin(e.t * 3) * 0.05; e.y = Math.abs(Math.sin(e.t * 3)) * 0.03;
    keepBand(e, dist, ux, uz); e.mx = e.bmx; e.mz = e.bmz; // lasers and saws are ranged: it holds ~5 off and backs away
    if (e.st <= 0) {
      e.jumps++; const k = e.jumps % 4;
      if (k === 1 || k === 3) { e.state = 'cross'; e.st = 4.4; const a0 = Math.atan2(dz, dx) + Math.PI / 4, sp = (en ? 0.8 : 0.55) * (e.jumps % 8 < 4 ? 1 : -1); for (let q = 0; q < 4; q++) addBeam(e, a0 + q * Math.PI / 2, sp, { len: 12, warn: 1.0, dur: 3.4, color: 0xff8a2a, w: 0.42, y: 1.2, ww: 0.16, clip: true }); }
      else if (k === 2) { // the saws: a 0.7 s wind-up while each gear's path is shown as a dashed lane (to its 3rd wall bounce)
        e.state = 'gears'; e.st = e.wind = 0.7; e.gn = en ? 5 : 3; e.ga = Math.atan2(dz, dx); pthClear(e); e.pthW = 0.45; e.pthCol = 0xffa040; e.pthDash = true;
        for (let q = 0; q < e.gn; q++) { const a = e.ga + (q - (e.gn - 1) / 2) * 0.45; let x = e.x + Math.cos(a) * (e.r + 0.5), z = e.z + Math.sin(a) * (e.r + 0.5), vx = Math.cos(a), vz = Math.sin(a), b = 0, L = 0;
          if (q) { pthAdd(e, NaN, NaN); }
          pthAdd(e, x, z);
          while (L < 13 && b <= 3) { const ox = x, oz = z; x += vx * 0.35; z += vz * 0.35; L += 0.35; if (solid(x, z, true)) { if (solid(x, oz, true)) vx = -vx; if (solid(ox, z, true)) vz = -vz; x = ox; z = oz; b++; } pthAdd(e, x, z); } }
      }
      else { e.state = 'overheat'; e.st = 3.2; banner('<span style="color:#ff8a2a">CORE EXPOSED</span>', 'HIT IT NOW · DOUBLE DAMAGE'); bannerT = 1.4; sfx('hiss'); addShake(0.4); }
    }
  } else if (e.state === 'cross') { e.tint = 0.3 + Math.sin(e.t * 16) * 0.2; e.shake = 0.02; if (e.st <= 0) { e.tint = 0; e.state = 'idle'; e.st = en ? 0.9 : 1.3; } }
  else if (e.state === 'gears') { // the tell: it winds up, gears whirring, the dashed lanes fill, then the saws fly
    e.tint = 1 - e.st / e.wind; e.shake = 0.05; e.sx = 1 + 0.08 * e.tint; e.pthK = e.tint;
    if (fxP(0.5)) spark(e.x + rr(-0.8, 0.8), rr(1, 2.2), e.z, 0xfff2a0, { vx: rr(-2, 2), vy: rr(1, 3), s: 0.25, life: 0.3, drag: 2 });
    if (e.st <= 0) {
      for (let q = 0; q < e.gn; q++) { const a = e.ga + (q - (e.gn - 1) / 2) * 0.45, p = enemyShoot(e, a, 4.6, 0xd8a040, 0.9, 0, 'gear'); p.x = e.x + Math.cos(a) * (e.r + 0.5); p.z = e.z + Math.sin(a) * (e.r + 0.5); p.bounce = 3; p.life = 5; p.r = 0.45; } // hitbox = the drawn gear; leaves from the hull, not point-blank
      e.tint = 0; e.squash = 0.6; addShake(0.25); sfx('orb'); sfx('clink'); e.state = 'idle'; e.st = en ? 1.1 : 1.5; pthClear(e); e.pthDash = false;
    }
  } else if (e.state === 'overheat') { // vents open, the core glows: stands still and takes double damage
    e.tint = 0.6 + Math.sin(e.t * 22) * 0.4; e.sy = 0.94; e.tilt = Math.sin(e.t * 30) * 0.02;
    if (fxP(0.5)) spark(e.x + rr(-0.6, 0.6), rr(1.5, 2.6), e.z, Math.random() < 0.5 ? 0xffffff : 0xff8a2a, { vy: rr(2, 4), s: 0.5, life: 0.6, drag: 1 });
    if (e.st <= 0) { e.tint = 0; e.state = 'idle'; e.st = 1; }
  } else if (e.st <= 0) { e.state = 'idle'; e.st = 1.3; }
}

// ---------- spells ----------
// ---------- spells: generated from element x shape (see arcana.js); boss spells and legendaries are special ----------
function castSpells(dt) {
  if (player.drop > 0 || (G.prologue && G.prologue.phase !== 'fight' && G.prologue.phase !== 'boss')) return;
  const cdMul = player.cdMul * player.g.cd * player.der.cd;
  for (const s of spells) {
    const def = spellDef(s.id);
    if (!def) continue;
    if (def.kills) { updateMeteor(s, def); continue; } // Meteor: no cooldown, kills charge it
    if (def.sh.beh === 'holybeam' && updateHolyBeam(s, def, dt, cdMul)) continue; // the beam is on: its cooldown starts when it ends
    s.t -= dt;
    if (s.t > 0) continue;
    const rank = projRank(s), target = rank > 0 ? spreadTarget(def.range + (player.rangeBonus || 0), rank) : nearestEnemy(player.x, player.z, def.range + (player.rangeBonus || 0));
    if (!target) { s.t = 0; continue; }
    castSpell(s, def, target);
    player.casts++;
    const g = player.g;
    if ((g.flags.echo && Math.random() < 0.2) || (g.flags.stormcaller && player.casts % 8 === 0) || (player.der.echo && s === echoSpell(spells) && (s.echoN = (s.echoN || 0) + 1) % 4 === 0)) { // INT 15: the strongest spell's every 4th cast twice
      later(0.15, () => { const t2 = player.alive && nearestEnemy(player.x, player.z, def.range + 2); if (t2) castSpell(s, def, t2); });
    }
    let cd = def.cd * cdMul;
    if (s.lv >= 5 && def.sh.beh === 'proj') cd *= 0.85;
    if (def.unique) { cd = uniqCd(def, s.lv) * cdMul * (def.sh.beh === 'momentum' && s.lv >= 5 ? 0.8 : 1); s.cdT = cd; } // the HUD sweep reads s.cdT
    s.t = cd; s.pop = 1;
  }
}
// Projectiles from different spells must not stack on one line (user): with 4-6 spells all aimed at the nearest foe from the
// staff, the straight shots read as one blob. Each projectile spell gets its own lane: its rank among the projectile spells
// picks a fixed launch angle and a sideways launch offset (FAN_A / FAN_O), and the shots curve back in onto the target
// (p.fan in updateProjectiles), so a volley reads as a fan of colours that converges. Subtle target spread on top: rank k
// prefers the k-th nearest foe if it is not much further than the nearest one. Casts still fire on the same frame.
const FAN_A = [0, 0.34, -0.34, 0.58, -0.58, 0.78, -0.78, 0.92];
const isProjSpell = (s) => { const d = spellDef(s.id); return !!(d && d.sh && d.sh.beh === 'proj' && !d.unique && !d.bossSpell && !d.legendary); };
function projRank(s) { if (!isProjSpell(s)) return -1; let r = 0; for (const q of spells) { if (q === s) return r; if (isProjSpell(q)) r++; } return r; }
const spreadC = [];
function spreadTarget(range, rank) { // the rank-th nearest foe within 2.5 of the nearest one's distance; else the nearest
  spreadC.length = 0;
  for (const e of enemies) { if (e.spawn < 0.3 || e.dead || e.hidden) continue; const d = Math.hypot(e.x - player.x, e.z - player.z); if (d < range) { e._sd = d; spreadC.push(e); } }
  if (!spreadC.length) return null;
  spreadC.sort((a, b) => a._sd - b._sd);
  const lim = spreadC[0]._sd + 2.5; let n = 1; while (n < spreadC.length && spreadC[n]._sd <= lim) n++;
  const t = spreadC[rank % n]; spreadC.length = 0; return t;
}
const tipV = new THREE.Vector3();
function staffTip() {
  const m = player.mesh, sh = sheets[player.hero.sprite], tip = (sh && sh.tip) || [0.82, 0.78];
  tipV.set((tip[0] - 0.5) * (player.face < 0 ? -1 : 1), tip[1], 0).multiply(m.scale).applyQuaternion(m.quaternion).add(m.position);
  return tipV;
}
const lvMul = (lv) => 1 + 0.3 * (lv - 1);
// Spell levels follow the depth (progression retune, see gainXp): Lv 2 from the start, Lv 3 from floor 5, Lv 4 from floor 10,
// Lv 5 from floor 20 (a daily, 3 floors, allows Lv 3). Every source of spell levels obeys it: level-up / floor / chest cards,
// the Lucky Chest, the shop, the Blood Pact. Spells above it (an old save) just stop there.
const spellCap = () => (G.daily ? 3 : G.floor < 5 ? 2 : G.floor < 10 ? 3 : G.floor < 20 ? 4 : 5);
const canLevel = (s) => s.lv < spellCap() && !spellDef(s.id).legendary;
const hexOf = (c) => new THREE.Color(c).getHex();
// heroes throw their own projectiles: javelins, axes, arrows, skulls
function heroVis(v) {
  const hv = player.hero.vis;
  if (!hv) return v;
  if (v === 'bolt' || v === 'lance' || v === 'glaive') return hv;
  if (v === 'venom') return hv + 'S';
  return v;
}
function castSpell(s, def, target) {
  // turn to the target so the weapon is on that side, then cast from its tip
  player.face = target.x >= player.x ? 1 : -1;
  player.mesh.material.uniforms.uFlip.value = player.face < 0 ? 1 : 0;
  const t0 = staffTip(), px = t0.x, pz = t0.z, py = t0.y;
  const a = Math.atan2(target.z - pz, target.x - px);
  const col = hexOf(def.color);
  player.aimX = Math.cos(a); player.aimZ = Math.sin(a);
  player.castT = 0.25;
  spark(px, py, pz, 0xffffff, { s: 0.9, life: 0.1, drag: 0 });
  for (let k = 0; k < 3; k++) spark(px, py, pz, col, { vx: player.aimX * 3, vz: player.aimZ * 3, vy: 1, s: 0.25, life: 0.25, spread: 2 });
  kick(-player.aimX * 0.06, -player.aimZ * 0.06);
  if (def.legendary) return castLegendary(s, def, target);
  if (def.unique) return castUnique(s, def, target, a);
  if (def.bossSpell) return castBossSpell(s, def, target, px, pz, py, a, col);
  const sh = def.sh, g = player.g, lv = s.lv, els = def.els;
  const dmg = def.dmg * lvMul(lv);
  const area = player.area * g.area * player.der.area, dur = player.dur * g.dur, extra = player.extraProj + g.proj + player.der.proj;
  const arc = false; // Arcane shots no longer curve onto foes (user, 11-12: seeking + pierce was too strong); homing comes from the Seek rune
  switch (sh.beh) {
    case 'proj': {
      // Frozen Orb: one orb (two at Lv 5, +1 from gear at most): its shards are the spray. Spit Volley: shots one after another.
      const n = sh.shards ? 1 + (lv >= 5) + Math.min(1, extra) : sh.count + (lv >= 3) + (lv >= 5) + extra;
      const rn = s.runes || {};
      // this spell's lane in the fan (see FAN_A): an angle off the aim line and a sideways launch offset; less when point-blank.
      // Spread spells (Venom Fan...) are a fan already and keep their own aim.
      const rk = Math.max(0, projRank(s)), dT = Math.hypot(target.x - px, target.z - pz), fk = Math.min(1, Math.max(0, (dT - 1.2) / 2.5));
      const fa = sh.spread || sh.lanes ? 0 : FAN_A[rk % FAN_A.length] * fk, fo = Math.sign(fa) * (0.12 + 0.1 * Math.ceil(rk / 2)) * fk;
      const shoot = (x0, z0, y, aa0, tg, spdK = 1) => { const aa = aa0 + fa, x = x0 - Math.sin(aa0) * fo, z = z0 + Math.cos(aa0) * fo; addProj({ kind: s.id === 'shadow.scythe' ? 'scythe' : s.id === 'earth.boulder' ? 'boulder' : s.id === 'venom.toxglaive' ? 'vglaive' : LOOK_KIND[sh.look] || heroVis(sh.vis), x, z, y, a: aa, speed: sh.speed * spdK * (player.projSpeed || 1) * player.der.projSpd, dmg, r: sh.r, color: col, size: sh.size,
        homing: Math.max(sh.homing || 0, rn.seek ? 7 : 0, arc ? 4.5 : 0), seek: !!rn.seek || arc, target: sh.homing || rn.seek || arc ? tg : null, pierce: (sh.pierce || 0) + (player.pierceBonus || 0) + (rn.pierce || 0), bounce: rn.bounce || 0, life: sh.life * (rn.bounce ? 1.6 : 1) * (rn.seek ? 1.3 : 1),
        aoe: sh.aoe ? sh.aoe * area : 0, tx: tg.x, tz: tg.z, els, boomerang: !!sh.boomerang,
        kb: sh.kb || 0, split: sh.split || 0, endBurst: sh.endBurst ? sh.endBurst * area : 0, shards: sh.shards ? (lv >= 3 ? 0.14 : 0.2) : 0, shT: 0.12, trail: sh.trail || false, look: sh.look || '', reap: sh.reap || 0, burn: !!sh.burnPool, roll: !!sh.roll, scale: sh.meshScale || 0,
        fan: fa ? Math.max(1.6, 2.6 * Math.abs(fa) * sh.speed * (player.projSpeed || 1) * player.der.projSpd / Math.max(2, Math.hypot(tg.x - x, tg.z - z))) : 0, fx: tg.x, fz: tg.z }); };
      for (let k = 0; k < n; k++) {
        if (sh.volley) { // Spit Volley (user 11-15: "make it lob", "different targets"): poison globs lobbed in high arcs, each at a
          // different foe (the k-th nearest; wraps when there are fewer), splatting a small poison splash where they land
          if (k === 0) { spitTg.length = 0; for (const e of enemies) if (!e.dead && !e.hidden && e.spawn >= 0.3 && Math.hypot(e.x - px, e.z - pz) < def.range + 2) spitTg.push(e); spitTg.sort((p1, p2) => Math.hypot(p1.x - px, p1.z - pz) - Math.hypot(p2.x - px, p2.z - pz)); }
          const tg = spitTg.length ? spitTg[k % spitTg.length] : target, tx = tg.x, tz = tg.z;
          later(k * 0.1, () => { if (!player.alive) return; const t1 = staffTip(); lobSpit(t1.x, t1.y, t1.z, tg.dead ? tx : tg.x, tg.dead ? tz : tg.z, dmg, els, col); });
          continue;
          if (k === 0) shoot(px, pz, py, a, target);
          else later(k * 0.09, () => { if (!player.alive) return; const t1 = staffTip(), tg = target.dead ? nearestEnemy(player.x, player.z, def.range + 2) || target : target; shoot(t1.x, t1.z, t1.y, Math.atan2(tg.z - t1.z, tg.x - t1.x) + rr(-0.05, 0.05), tg); });
          continue;
        }
        if (sh.lanes && n > 1) { // Arcane Missiles (user, 11-12): one direction, side by side in parallel lanes
          // each dart: its lane plus a random sideways jitter, and its own speed (user: random offsets, different speeds)
          // fired as a quick burst (user: a burst, not 3 at once): dart k leaves k x 0.07 s later from the staff, re-aimed
          const off = (k - (n - 1) / 2) * sh.lanes + rr(-0.5, 0.5) * sh.lanes, spd = rr(0.82, 1.18);
          const fire = (x0, z0, y0, aa) => shoot(x0 - Math.sin(aa) * off, z0 + Math.cos(aa) * off, y0, aa, target, spd);
          if (k === 0) fire(px, pz, py, a);
          else later(k * 0.07, () => { if (!player.alive) return; const t1 = staffTip(), tg = target.dead ? nearestEnemy(player.x, player.z, def.range + 2) || target : target; fire(t1.x, t1.z, t1.y, Math.atan2(tg.z - t1.z, tg.x - t1.x)); });
          continue;
        }
        const aa = n === 1 ? a : sh.spread ? a + (k / (n - 1) - 0.5) * sh.spread * (1 + 0.08 * extra) : a + (k - (n - 1) / 2) * (sh.shards ? 0.5 : 0.2);
        shoot(px, pz, py, aa, target);
      }
      sfx(sh.aoe || sh.roll ? 'fire' : sh.vis === 'venom' ? 'venom' : 'bolt');
      break;
    }
    case 'radial': {
      if (sh.corpse) { castCorpseBlast(lv, dmg, sh.aoe * (lv >= 3 ? 1.25 : 1) * area, els, col, target, def.range + (player.rangeBonus || 0), sh.count + (lv >= 3) + Math.min(2, extra), px, pz, py, a); break; }
      const n = sh.count + (lv >= 3 ? 4 : 0) + (lv >= 5 ? 6 : 0) + extra * 3;
      const rn = s.runes || {};
      for (let k = 0; k < n; k++) addProj({ kind: heroVis(sh.vis), x: player.x, z: player.z, y: 0.7, a: a + k / n * Math.PI * 2, speed: sh.speed, dmg, r: sh.r, color: col, size: sh.size, life: sh.life * (rn.bounce ? 1.6 : 1), els,
        pierce: (player.pierceBonus || 0) + (rn.pierce || 0), bounce: rn.bounce || 0, homing: rn.seek ? 6 : arc ? 3.5 : 0, seek: !!rn.seek || arc, target: rn.seek || arc ? nearestEnemy(player.x, player.z, 8) : null });
      sfx('venom');
      break;
    }
    case 'nova': {
      const rad = sh.radius * (lv >= 3 ? 1.25 : 1) * area;
      for (let k = 0; k < (lv >= 5 ? 2 : 1); k++) later(k * 0.35, () => castNova(dmg, rad, col, els, sh, k));
      break;
    }
    case 'phoenix': { // Phoenix (fire.ring): a bird of flame dives out through the foes, U-turns and swoops back (updatePhoenixes)
      const lv5 = lv >= 5, sc = (lv5 ? 1.3 : 1) * Math.sqrt(area), v = lv5 ? 13 : 10.5, side = Math.random() < 0.5 ? 1 : -1;
      const L = Math.max(4, Math.min(8.5, Math.hypot(target.x - px, target.z - pz) + 2.4)); // overshoot the foe, turn behind it
      addPhoenix(px, pz, a, L, v, side, sc, dmg, els, lv5);
      if (lv >= 3) later(0.1, () => { if (player.alive) addPhoenix(player.x, player.z, a - 0.3 * side, L * 0.92, v, -side, sc, dmg, els, lv5); }); // mirrored, a little off the line
      sfx('fire');
      break;
    }
    case 'chain': {
      // the chain JUMPS foe to foe (user 11-15: "I want to see the chain jumping, not instant all"): one hop every 0.08 s,
      // each with its own bolt segment that lingers so the path reads, a spark and a crackle. Same damage as before.
      const jumps = sh.jumps + (lv >= 3 ? 2 : 0) + (lv >= 5 ? 3 : 0) + extra, reach = 3.8 * Math.sqrt(area);
      const hit = new Set(); // no sky bolt per hit (user 11-15: chain lightning should not have the lightning from the sky)
      const hop = (k, from, cur) => {
        if (!cur || cur.dead || !player.alive) return;
        hit.add(cur); const to = new THREE.Vector3(cur.x, 0.6 + (cur.y || 0), cur.z);
        momQuiet = true; hurtEnemy(cur, dmg * Math.pow(0.9, k), cur.x - from.x, cur.z - from.z, 1.5, col, els); momQuiet = false; // no storm side-arcs: they looked like re-hitting chained foes (user 11-15)
        const hx = (def.color || '#9fd8ff').replace('#', ''), glow = hx.length === 6 ? `rgba(${parseInt(hx.slice(0, 2), 16)},${parseInt(hx.slice(2, 4), 16)},${parseInt(hx.slice(4, 6), 16)},.45)` : undefined;
        bolts.push({ pts: [from, to], life: 0.15, max: 0.15, grow: 0.05, color: def.color, glow, w: 11 }); // one zigzag arc at a time (user: 'not a triangle', 'the zigzag, not straight')
        burst(cur.x, 0.6, cur.z, col, 10, 4.5, 0.3, 0.35); addRing(cur.x, cur.z, 0.2, 1.1, 0.25, col);
        if (sh.look === 'plasma') { burst(cur.x, 0.6, cur.z, 0xff5a10, fxN(8), 5, 0.3, 0.45); spark(cur.x, 0.7, cur.z, 0xffffff, { s: 1.3, life: 0.08, drag: 0 }); } // Plasma Chain: each hop flares white-hot and throws embers
        if (k === 0) addShake(0.1);
        sfx('zap');
        if (k >= jumps) return;
        const nx = nearestEnemy(cur.x, cur.z, reach, hit);
        if (nx) later(0.12, () => hop(k + 1, to, nx.dead ? nearestEnemy(to.x, to.z, reach, hit) : nx));
      };
      hop(0, new THREE.Vector3(px, py, pz), target);
      break;
    }
    case 'orbit': {
      if (sh.guard) for (const o of orbs) if (o.sid === s.id) o.life = 0; // Guardian Orbs refresh, never stack (they were near-permanent shot immunity)
      const n = sh.count + (lv >= 3) + (lv >= 5 ? 2 : 0) + extra;
      for (let k = 0; k < n; k++) orbs.push({ a: k / n * Math.PI * 2, rad: sh.radius * Math.sqrt(area), life: sh.dur * dur, dmg, color: col, els, sid: s.id,
        breathe: !!sh.breathe, pull: !!sh.pull, guard: !!sh.guard, // Rune Halo sweeps in and out, Void Halo drags foes in, Guardian Orbs eat enemy shots
        // Void Orbs: black orbs with an arcane rim; Twilight Orbs: light and dark orbs taking turns
        glow: makeGlow(sh.look === 'twilight' ? (k % 2 ? 0x8a4cff : 0xffe08a) : col, 0.8, sh.look === 'void' || sh.look === 'twilight' && k % 2 ? 0.3 : 0.7), mesh: makeProjMesh(sh.vis === 'glaive' ? 'glaive' : sh.look === 'void' ? 'void' : sh.look === 'twilight' ? (k % 2 ? 'void' : 'holyorb') : 'orb', sh.look === 'twilight' && k % 2 ? 0x8a4cff : col), shadow: makeShadow(0.5), hits: new Map() });
      sfx('orb');
      break;
    }
    case 'rain': {
      if (sh.swords) { // Angel Swords: holy swords hang over 4 foes (6 at Lv 3, 8 at Lv 5) and drop on them (castAngelSwords)
        castAngelSwords(def, target, sh.count + (lv >= 3 ? 2 : 0) + (lv >= 5 ? 2 : 0) + Math.min(2, extra), dmg, sh.aoe * area * (lv >= 5 ? 1.35 : 1), lv >= 5 ? 1.75 : 1.5, col, els);
        break;
      }
      if (sh.smite) { // Smite: one big sunbeam (smiteStrike, no lightning) on the toughest foe in reach (Lv 5: a second one on the next toughest)
        const tough = (not) => { let b = null; for (const e of enemies) if (!e.dead && !e.hidden && e.spawn >= 0.5 && e !== not && Math.hypot(e.x - player.x, e.z - player.z) < def.range + 2 && (!b || e.hp > b.hp)) b = e; return b; };
        const aoe = sh.aoe * area * (lv >= 3 ? 1.25 : 1), t1 = tough(null) || target;
        const hit = (t, m) => { if (!player.alive) return; holyHammer(t.x, t.z, dmg * m, aoe * 0.7, col, els); }; // less AoE (user 11-15) // a spinning holy hammer slams down (user 11-15)
        hit(t1, 1);
        if (lv >= 5) later(0.3, () => { const t2 = tough(t1); if (t2) hit(t2, 0.7); });
        break;
      }
      if (sh.thunder && sh.look === 'judg') { // Judgment Bolts (storm+holy): Thunderfall's strikes, in holy gold (storm + holy effects)
        const n = sh.count + (lv >= 3 ? 2 : 0) + (lv >= 5 ? 3 : 0) + extra * 2;
        for (let k = 0; k < n; k++) later(k * 0.11, () => {
          if (!player.alive) return;
          const foes = enemies.filter((e) => !e.dead && !e.hidden && e.spawn >= 0.5 && Math.hypot(e.x - player.x, e.z - player.z) < def.range + 2);
          const e = foes.length ? pick(foes) : null; if (!e) return;
          skyStrike(e.x, e.z, dmg, 0.9 * area, '#fff6c8', 'rgba(255,200,60,.55)', 0xffd860, JUDG_O);
        });
        break;
      }
      if (sh.thunder) { // Thunderfall: bolts straight from the sky onto foes, no falling rock and no warning
        const n = sh.count + (lv >= 3 ? 2 : 0) + (lv >= 5 ? 3 : 0) + extra * 2;
        for (let k = 0; k < n; k++) later(k * 0.11, () => {
          if (!player.alive) return;
          const foes = enemies.filter((e) => !e.dead && !e.hidden && e.spawn >= 0.5 && Math.hypot(e.x - player.x, e.z - player.z) < def.range + 2);
          const e = foes.length ? pick(foes) : null; if (!e) return;
          skyStrike(e.x, e.z, dmg, 0.9 * area, '#cfe4ff', 'rgba(110,160,255,.5)', 0x8fc4ff, THUNDER_O);
        });
        break;
      }
      if (sh.pebbles) { // Pebble Storm (user 11-15: "spawn from the staff, in a cone"): a 0.75 s stream of ~30 tumbling pebbles sprayed from
        // the staff tip in a cone toward the foe (+-30 deg, ~4.5 tiles); each pebble hits the first foe it meets for a small bit
        const n = sh.count + (lv >= 3 ? 3 : 0) + (lv >= 5 ? 4 : 0) + extra * 2, L = 4.5 * Math.sqrt(area) * (lv >= 5 ? 1.15 : 1), half = 0.52, N = MOBILE ? 24 : 30;
        const a0 = Math.atan2(target.z - pz, target.x - px);
        // bursts (user 11-15: "a burst, not a stream - 5 per burst, different starting positions"): 3 bursts 0.18 s apart, each 5 pebbles
        // at once, fanned across the cone and leaving from 5 different points around the staff
        for (let b = 0; b < 3; b++) later(b * 0.18, () => {
          if (!player.alive) return; const t1 = staffTip(); sfx('thud'); addShake(0.05); chunkDust(t1.x, t1.z, 0x8a6a4a); for (let q = fxN(6); q > 0; q--) spark(t1.x, t1.y, t1.z, 0x9a7a5a, { vx: Math.cos(a0) * rr(3, 6), vz: Math.sin(a0) * rr(3, 6), vy: rr(0.5, 2), s: 0.25, life: 0.3, drag: 3, spread: 2 }); // muzzle grit
          for (let q = 0; q < 5; q++) { // LOBBED (user 11-15: "it should be lobbing, falling to the ground"): each pebble arcs up and drops on its own spot in the cone
            const aa = a0 + ((q - 2) / 2 + (Math.random() - 0.5) * 0.35) * half, d = 1.4 + Math.random() * (L - 1.4), side = (q - 2) * 0.16;
            const x = t1.x - Math.sin(a0) * side, z = t1.z + Math.cos(a0) * side;
            lobRock(x, t1.y, z, player.x + Math.cos(aa) * d, player.z + Math.sin(aa) * d, 0.42 + d * 0.04, dmg * n * 0.1, col, els);
          }
        });
        chunkDust(px, pz, 0x8a6a4a); addShake(0.08); sfx('rockfall'); break;
      }
      { const hail = sh.look === 'hail', cnt = sh.count + (lv >= 3 ? 2 : 0) + (lv >= 5 ? 3 : 0) + extra * 2; // Blizzard (user 11-15: 'too much'): half the hailstones, each 1.8x, no sky bolt per stone
        strikes(hail ? Math.ceil(cnt / 2) : cnt, target, sh.aoe * area, hail ? dmg * 1.8 : dmg, col, els, hail ? 0.18 : 0.12, false, false, sh.look || ''); }
      sfx(sh.pebbles ? 'slam' : 'fire');
      break;
    }
    case 'zone': {
      const r = sh.radius * (lv >= 3 ? 1.25 : 1) * area, life = sh.dur * (lv >= 5 ? 2 : 1) * dur;
      if (sh.wall) { // Flame Wall: a straight line of fire in front of Pip, across the way to the foe (user: in front, not at my feet)
        const dx = target.x - player.x, dz = target.z - player.z, ax = Math.abs(dx) >= Math.abs(dz); // snapped: a horizontal or vertical wall
        const ux = ax ? Math.sign(dx) || 1 : 0, uz = ax ? 0 : Math.sign(dz) || 1, k0 = 3.2;
        const cx = player.x + ux * k0, cz = player.z + uz * k0, segs = (lv >= 3 ? 7 : 5) + Math.round((area - 1) * 3);
        for (let q = 0; q < segs; q++) {
          const o = (q - (segs - 1) / 2) * 0.7, x = cx - uz * o, z = cz + ux * o;
          if (cellAt(x, z) !== FLOOR) continue;
          fires.push({ x, z, r: 0.55, life: life * (0.9 + q % 2 * 0.1), dmg, tick: 0.1, els, color: col, wallFx: true, glow: makeGlowAt(x, 0.2, z, col, 1.5, 0.45) });
        }
        addRing(cx, cz, 0.2, 1.4, 0.35, col); sfx('fire');
        break;
      }
      fires.push({ x: target.x, z: target.z, r, life, dmg, tick: 0, els, color: col, drift: sh.drift ? 1.4 : 0, zone: true, look: sh.look || '', glow: makeGlowAt(target.x, 0.2, target.z, col, r * 2.2, 0.4) }); // zone: draws its hit-area ring
      addRing(target.x, target.z, 0.2, r, 0.4, col); sfx(sh.drift ? 'venom' : 'frost');
      break;
    }
    case 'mine': {
      if (sh.pillars) { castPillars(lv, sh, def.range, dmg, els, col, area, extra); break; } // Stone Pillars (earth.quake): at the foes, not a trap
      for (let k = 0; k < (lv >= 5 ? 2 : 1); k++) {
        const x = player.x + (k ? rr(-0.8, 0.8) : 0), z = player.z + (k ? rr(-0.8, 0.8) : 0);
        mines.push({ x, z, arm: 0.45, life: 9 * dur, dmg, aoe: sh.aoe * (lv >= 3 ? 1.25 : 1) * area, els, color: col, glow: makeGlowAt(x, 0.15, z, col, 1.1, 0.6), t: 0, rune: makeRune(x, z, col, sh.aoe * (lv >= 3 ? 1.25 : 1) * area) });
      }
      sfx('lock');
      break;
    }
    case 'diver': castDiver(s, dmg, target, dur); break; // Frost Diver (frost.trap)
    case 'beam': {
      rays.push({ target, t: sh.dur * (lv >= 3 ? 1.5 : 1) * dur, tick: 0, n: 0, dmg, els, color: col, split: lv >= 5, range: def.range + 1, lasers: [], spark: !!sh.spark, look: sh.look || '' });
      sfx('laser');
      break;
    }
    case 'summon': {
      const n = 1 + (lv >= 3) + (lv >= 5) + Math.floor(extra / 2);
      for (let k = 0; k < n; k++) wisps.push({ a: k * 2.1 + Math.random(), life: sh.dur * dur, cd: 0.3 + k * 0.2, rate: lv >= 5 ? 0.5 : 0.75, dmg, els, color: col,
        glow: makeGlow(col, 0.9, 0.8), mesh: makeProjMesh('orb', col), shadow: makeShadow(0.4), x: player.x, z: player.z });
      sfx('orb');
      break;
    }
  }
}
// strikes falling from the sky onto random foes (Rain shapes, Meteor Storm, Rockfall)
// a falling rock: dark tumbling core with glowing cracks, a fiery shell, a smoke and flame trail
const meteorRock = new THREE.IcosahedronGeometry(1, 1);
{ const pos = meteorRock.attributes.position; for (let i = 0; i < pos.count; i++) { const k = 0.8 + hash(i, 1, 3) * 0.4; pos.setXYZ(i, pos.getX(i) * k, pos.getY(i) * k, pos.getZ(i) * k); } meteorRock.computeVertexNormals(); }
const meteorMats = new Map();
function makeMeteor(x, z, col, rocky, aoe, look = '') {
  const g = new THREE.Group(), size = 0.22 + aoe * 0.12;
  if (look === 'hail') { // Blizzard: a jagged hailstone of ice, point first, wrapped in frost glow (no dark rock, no smoke)
    const core = new THREE.Mesh(PG.shard, pMat(0xf0fcff, false)); core.scale.set(size * 5, size * 13, size * 5); g.add(core);
    const sh2 = new THREE.Mesh(PG.shard, pMat(0x8fe6ff, true, 0.5)); sh2.scale.set(size * 9, size * 19, size * 9); g.add(sh2);
    g.quaternion.setFromUnitVectors(gfxUp, new THREE.Vector3(4, 9 - 0.3, -3).normalize()); // long axis along the fall
    const glow = makeGlow(0x8fe6ff, size * 6, 0.7); scene.add(g);
    return { g, core, glow, x, z, sx: x + 4, sy: 9, sz: z - 3, t: 0, dur: 0.65, col: 0xbfefff, rocky: false, hail: true };
  }
  const mk = col + '|' + rocky;
  if (!meteorMats.has(mk)) meteorMats.set(mk, new THREE.MeshLambertMaterial({ color: rocky ? 0x8a8070 : 0x3a2a24, emissive: new THREE.Color(col).multiplyScalar(rocky ? 0.15 : 0.55), flatShading: true }));
  const core = new THREE.Mesh(meteorRock, meteorMats.get(mk));
  core.scale.setScalar(size); g.add(core);
  if (!rocky) { const shell = new THREE.Mesh(PG.ball, pMat(col, true, 0.45)); shell.scale.setScalar(size * 9); g.add(shell); }
  const glow = makeGlow(col, size * 6, rocky ? 0.3 : 0.8);
  scene.add(g);
  return { g, core, glow, x, z, sx: x + 4, sy: 9, sz: z - 3, t: 0, dur: 0.65, col, rocky };
}
function updateMeteors(dt) {
  for (let i = meteors.length - 1; i >= 0; i--) {
    const m = meteors[i]; m.t += dt;
    const k = Math.min(1, m.t / m.dur), e = k * k; // accelerates as it falls
    const px = lerp(m.sx, m.x, e), py = lerp(m.sy, 0.3, e), pz = lerp(m.sz, m.z, e);
    m.g.position.set(px, py, pz); m.glow.position.set(px, py, pz);
    if (!m.hail) { m.core.rotation.x += dt * 9; m.core.rotation.z += dt * 6; }
    spark(px, py, pz, m.col, { s: 0.6, life: 0.25, drag: 0, spread: 0.6 });
    if (m.hail) { if (fxP(0.35)) spark(px + rr(-0.3, 0.3), py, pz + rr(-0.3, 0.3), 0xfff36a, { s: 0.3, life: 0.08, drag: 0 }); } // storm crackle on the falling ice
    else if (fxP(0.6)) spark(px, py, pz, m.rocky ? 0x6a6458 : 0x2a2220, { s: 0.7, life: 0.6, drag: 1, vy: 0.5, spread: 0.4 });
    if (k >= 1) { scene.remove(m.g); killGlow(m.glow); meteors.splice(i, 1); }
  }
}
const THUNDER_O = { small: true, els: ['storm'], light: 45, lightCol: 0xa8c8ff, flash: 0.05, shake: 0.1, boom: false, burstCol: 0xcfe4ff, splat: 0x080a14, w: 10, glow2: 'rgba(170,200,255,.35)', fork: true }; // white-blue forked lightning, straight down
const JUDG_O = { ...THUNDER_O, els: ['storm', 'holy'], lightCol: 0xffe08a, burstCol: 0xfff0b0, glow2: 'rgba(255,230,140,.4)' }; // Judgment Bolts: Thunderfall in gold, storm + holy
function strikes(n, target, aoe, dmg, col, els, gap, rocky = false, lite = false, look = '') {
  const foes = enemies.filter((e) => !e.dead && !e.hidden);
  for (let k = 0; k < n; k++) {
    const e = foes.length ? pick(foes) : target;
    const x = e.x + rr(-0.9, 0.9), z = e.z + rr(-0.9, 0.9);
    later(k * gap, () => {
      if (cellAt(x, z) !== FLOOR) return;
      const mk = addMarker(x, z, aoe * 0.85, col);
      meteors.push(makeMeteor(x, z, col, rocky, aoe, look));
      later(0.65, () => {
        scene.remove(mk); mk.material.dispose(); explode({ x, z, aoe, dmg, els, color: col, lite });
        if (look === 'hail') { addRing(x, z, 0.2, aoe, 0.35, 0xdff6ff); chunk(x, 0.3, z, 0xdff6ff, 3, 5, 0.1); } // the hailstone shatters, lightning cracks down on it
        else chunk(x, 0.2, z, rocky ? 0x8a96a0 : 0x3a2a24, lite ? 2 : 5, 5, 0.13);
      });
    });
  }
}
function castNova(dmg, rad, col, els, sh = null, wave = 0) {
  if (!player.alive) return;
  addRing(player.x, player.z, 0.3, rad, 0.35, col);
  addRing(player.x, player.z, 0.2, rad * 0.75, 0.45, 0xffffff);
  for (let k = 0; k < 28; k++) { const a = k / 28 * Math.PI * 2; spark(player.x + Math.cos(a) * 0.5, 0.3, player.z + Math.sin(a) * 0.5, col, { vx: Math.cos(a) * rad * 3, vz: Math.sin(a) * rad * 3, vy: 1, s: 0.4, life: 0.35, drag: 5 }); }
  let hits = 0;
  for (const e of [...enemies]) if (!e.dead && Math.hypot(e.x - player.x, e.z - player.z) < rad + e.r) {
    hurtEnemy(e, dmg, e.x - player.x, e.z - player.z, 5, col, els); hits++;
    if (!sh) continue;
  }
  for (const pot of [...pots]) if (Math.hypot(pot.x - player.x, pot.z - player.z) < rad) breakPot(pot);
  addShake(Math.min(0.25, 0.03 + hits * 0.03)); sfx('frost');
}
// ---------- unique spells (arcana.js UNIQUE_SPELLS): hand-made, each with its own rule ----------
// No channelling: Holy Beam, Momentum, Vesper's Judgment, Earth Spike and Storm Gust auto-cast on their cooldown (castUnique;
// Holy Beam then stays on for a while, updateHolyBeam). Meteor has no cooldown: kills fill it (meteorKill), and when full it
// falls by itself on the biggest crowd (updateMeteor). Levels: +30% damage at Lv 2/4, a perk at Lv 3/5, -5% cooldown each.
const uniqCd = (def, lv) => def.cd * (1 - 0.05 * (lv - 1));
const FROST_ELS = ['frost'];
const HOLY_SPK = { vy: 1.2, s: 0.4, life: 0.3, drag: 0, spread: 1 };
const momHit = new Set();
// Meteor's charge: kills needed to fill it at Lv 1..5 (Lv 5 perk: 30% faster). Elites / named foes count 3, bosses 6.
const METEOR_KILLS = [22, 20, 18, 16, 14]; // kills to fill it per level (was 14-9: a meteor every few seconds by floor 4)
function meteorKill(e) {
  if (G.prologue) return;
  const w = e.isBoss ? 6 : e.elite || e.name ? 3 : 1;
  for (const s of spells) if (s.id === 'u.meteor') s.ch = Math.min(1, (s.ch || 0) + w / METEOR_KILLS[clamp(s.lv, 1, 5) - 1]);
}
// ---------- Dragon Strafe (user 11-15, replacing the unique Meteor): a painted fire dragon (sprites/dragon.webp) swoops across the
// screen in 1.4 s through the target point, low over it, breathing fire down along its path: burning ground, flame streams from
// its jaws, every foe within W of the line burnt once. back: the Lv 5 second pass comes from the other side.
const dragons = [];
// ---------- Storm Eye (user 11-15): a dark thundercloud (5 soft puffs, one cached canvas texture) gathers over Pip and follows
// him for 6 s, striking a foe within 5.5 tiles with a zigzag bolt from the cloud every 0.33 s (Lv 3: 0.25 s, Lv 5: 2 bolts a time)
let cloudTex = null; const storms = [];
function stormEye(dmg, lv, range) {
  if (!cloudTex) { const c = document.createElement('canvas'); c.width = c.height = 128; const g = c.getContext('2d'), rg = g.createRadialGradient(64, 64, 4, 64, 64, 62); rg.addColorStop(0, 'rgba(34,36,50,.97)'); rg.addColorStop(0.55, 'rgba(22,24,36,.85)'); rg.addColorStop(1, 'rgba(14,14,24,0)'); g.fillStyle = rg; g.fillRect(0, 0, 128, 128); cloudTex = new THREE.CanvasTexture(c); }
  for (const st of storms) st.t = st.T; // one cloud at a time: a recast replaces it
  // a small lightning orb over the head (user 11-15: "the cloud is too big - just a lightning sphere with static electricity")
  const grp = new THREE.Group(), puffs = [];
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 12), new THREE.MeshBasicMaterial({ color: 0xe8f4ff, transparent: true, opacity: 0 })); grp.add(core); puffs.push(core);
  const halo = new THREE.Mesh(new THREE.SphereGeometry(0.34, 16, 12), new THREE.MeshBasicMaterial({ color: 0x5aa8ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })); grp.add(halo); puffs.push(halo);
  scene.add(grp); storms.push({ grp, puffs, t: 0, T: 6, st: 0.4, every: lv >= 5 ? 0.12 : lv >= 3 ? 0.15 : 0.2, tg: null, dmg, range: Math.min(5.5, range), arcT: 0, glow: makeGlowAt(player.x, 2.3, player.z, 0x6aa8ff, 1.3, 0.6) });
  sfx('wave');
}
function updateStormEye(dt) {
  for (let i = storms.length - 1; i >= 0; i--) {
    const S = storms[i]; S.t += dt; const fin = S.t >= S.T, f = Math.min(1, S.t / 0.5) * Math.min(1, (S.T - S.t) / 0.5);
    S.grp.position.set(player.x, 2.4 + Math.sin(S.t * 1.5) * 0.08, player.z); // right over the hero's head
    const fl = 1 + Math.sin(S.t * 30) * 0.08 + (Math.random() < 0.1 ? 0.25 : 0); S.puffs[0].material.opacity = Math.max(0, f); S.puffs[1].material.opacity = 0.55 * Math.max(0, f); S.grp.scale.setScalar(Math.max(0.01, f) * fl);
    if ((S.arcT -= dt) <= 0 && f > 0.3) { // static: short crackling arcs jumping off the orb
      S.arcT = 0.05 + Math.random() * 0.06; const c = S.grp.position, a1 = Math.random() * 6.283, a2 = a1 + rr(0.8, 2), r1 = 0.22, r2 = 0.45 + Math.random() * 0.25, y2 = rr(-0.25, 0.3);
      bolts.push({ pts: [new THREE.Vector3(c.x + Math.cos(a1) * r1, c.y, c.z + Math.sin(a1) * r1), new THREE.Vector3(c.x + Math.cos(a2) * r2, c.y + y2, c.z + Math.sin(a2) * r2)], life: 0.07, max: 0.07, color: '#cfe8ff', glow: 'rgba(90,160,255,.5)', w: 4 });
    }
    S.glow.position.set(player.x, 2.3, player.z); S.glow.material.opacity = 0.4 * Math.max(0, f) * (Math.random() < 0.06 ? 3 : 1); // inner flicker
    if (fin) { scene.remove(S.grp); for (const m of S.puffs) { m.material.dispose(); m.geometry.dispose(); } killGlow(S.glow); storms.splice(i, 1); continue; }
    if (S.t > 0.5 && (S.st -= dt) <= 0) {
      S.st = S.every;
      { // ONE target, zapped fast (user 11-15), kept until it dies or leaves range, then the nearest
        if (!S.tg || S.tg.dead || S.tg.hidden || Math.hypot(S.tg.x - player.x, S.tg.z - player.z) > S.range) S.tg = nearestEnemy(player.x, player.z, S.range);
        if (!S.tg) continue;
        const e = S.tg, from = S.grp.position; // the live orb position: the bolt stays attached while Pip moves (user 11-15)
        bolts.push({ pts: [from, new THREE.Vector3(e.x, 0.5, e.z)], life: 0.2, max: 0.2, grow: 0.04, fork: true, color: '#cfe4ff', glow: 'rgba(110,160,255,.55)', w: 10 });
        momQuiet = true; hurtEnemy(e, S.dmg, 0, 0, 1, 0x8fc4ff, ['storm']); momQuiet = false;
        burst(e.x, 0.6, e.z, 0xcfe4ff, fxN(6), 3, 0.3, 0.25); addRing(e.x, e.z, 0.2, 0.9, 0.2, 0x8fc4ff); sfx('zap');
      }
    }
  }
}
function resetStormEye() { for (const S of storms) { scene.remove(S.grp); for (const m of S.puffs) m.material.dispose(); killGlow(S.glow); } storms.length = 0; }
function dragonStrafe(cx, cz, dmg, W, els, back = false) {
  const dir = (Math.random() < 0.5) !== back ? 1 : -1, L = 13, T = 1.4, zo = rr(-0.4, 0.4);
  const m = sheets.dragon ? makeSprite('dragon', 2.6) : null; if (m) { m.geometry = scytheGeo || (scytheGeo = new THREE.PlaneGeometry(1, 1)); m.material.side = THREE.DoubleSide; }
  dragons.push({ m, sh: makeShadow(2.2), x0: cx - dir * L, x1: cx + dir * L, z: cz + zo, cx, cz, dir, T, t: 0, W, dmg, els, hit: new Set(), ft: 0, glow: makeGlowAt(cx, 2, cz, 0xff4fc0, 2.2, 0.5) }); // pink dragon, pink-violet fire (user: tell it apart from the orange Phoenix)
  sfx('whoosh'); later(0.35, () => sfx('fire'));
}
function updateDragons(dt) {
  for (let i = dragons.length - 1; i >= 0; i--) {
    const d = dragons[i]; d.t += dt; const k = d.t / d.T, x = lerp(d.x0, d.x1, k), near = Math.max(0, 1 - Math.abs(x - d.cx) / 6.5), y = 3.3 - 1.4 * near;
    if (d.m) { d.m.position.set(x, y + Math.sin(d.t * 9) * 0.12, d.z); d.m.quaternion.copy(camera.quaternion); d.m.rotateZ(-d.dir * 0.12 * near); setSpriteScale(d.m, d.dir, 1); }
    d.sh.position.set(x, 0.04, d.z); d.sh.scale.set(2.2, 1, 1.4); d.glow.position.set(x + d.dir * 1.0, y - 0.3, d.z);
    if (near > 0.25 && (d.ft -= dt) <= 0) { // breathing: fire pours from the jaws onto the floor under it
      d.ft = 0.05; const gx = x + d.dir * 0.9, gz = d.z;
      elPatch(gx, gz, 0.9 * d.W / 1.25, 2.4, Math.max(2, d.dmg * 0.12), 'fire', 0xff3fa8);
      for (let q = fxN(4); q > 0; q--) spark(x + d.dir * 1.3, y - 0.2, d.z, q & 1 ? 0xffb0e8 : 0xd040ff, { vx: d.dir * rr(1, 3), vy: -rr(5, 8), vz: rr(-1, 1), s: 0.7, life: 0.35, drag: 1 });
      burst(gx, 0.3, gz, 0xff4fc0, fxN(4), 3, 0.35, 0.3);
      for (const e of enemies) if (!e.dead && !e.hidden && !d.hit.has(e) && Math.abs(e.x - gx) < 1.0 + e.r && Math.abs(e.z - gz) < d.W + e.r) { d.hit.add(e); hurtEnemy(e, d.dmg, 0, e.z - gz, 3, 0xff4fc0, d.els); }
      if (Math.random() < 0.25) addShake(0.06);
    }
    if (k >= 1) { if (d.m) killMesh(d.m); scene.remove(d.sh); killGlow(d.glow); dragons.splice(i, 1); }
  }
}
function resetDragons() { for (const d of dragons) { if (d.m) killMesh(d.m); scene.remove(d.sh); killGlow(d.glow); } dragons.length = 0; }
function updateMeteor(s, def) {
  s.ch = s.ch || 0; s.cdT = 1; s.t = 1 - s.ch; // the HUD slot's sweep shows the charge
  if (s.ch < 1) return;
  const lv = s.lv, area = player.area * player.g.area * player.der.area, rad = 2.6 * (lv >= 3 ? 1.25 : 1) * area;
  const aim = densestFoe(null, player.x, player.z, def.range + (player.rangeBonus || 0), rad);
  if (!aim) return; // full: waits for a foe in reach
  const x = aim.x, z = aim.z, dmg = def.dmg * lvMul(lv), col = 0xff6a1a;
  const mk = addMarker(x, z, rad * 0.95, 0xff3020); // the red target circle: ~0.65 s of warning while the rock falls
  meteors.push(makeMeteor(x, z, col, false, rad)); sfx('fire'); later(0.41, () => sfx('meteor')); // its boom peaks ~0.24 s in: lands with the rock
  later(0.65, () => { scene.remove(mk); mk.material.dispose(); explode({ x, z, aoe: rad, dmg, els: ['fire'], color: col }); addShake(0.5); flash(0.15); chunk(x, 0.2, z, 0x3a2a24, 8, 6, 0.14); });
  s.ch = 0; s.t = 1; s.pop = 1; player.casts++;
}
// Holy Beam: cast on its cooldown, the laser locks on for HOLY_DUR s and grows brighter and stronger; the cooldown runs after it
const holyRunes = [], holyDir = new THREE.Vector3(); // Holy Beam's floor runes: fade out by themselves once their beam ends (updateHolyRunes)
function updateHolyRunes(dt) { for (let i = holyRunes.length - 1; i >= 0; i--) { const m = holyRunes[i], u = m.userData; if (!u.fade) continue; u.fade -= dt; m.material.opacity *= Math.exp(-dt * 8); if (u.fade <= 0) { scene.remove(m); if (m.material.map !== judgRuneTex) m.material.map.dispose(); m.material.dispose(); holyRunes.splice(i, 1); } } }
const HOLY_DUR = 4, holyFx = new WeakMap(); // spell -> { beam, tg, bt, tick } (not saved)
function startHolyBeam(s, def, tg) { // Holy Beam (user 11-15: "move Smite's effect to Holy Beam"): a column of holy light from the sky
  // on the target, following it while it channels, brighter and wider as it goes; it burns every foe inside the column
  holyFx.set(s, { tg, bt: 0, tick: 0, pt: 0, rt: 0, x: tg.x, z: tg.z, snd: holyHum(HOLY_DUR) });
  addRing(tg.x, tg.z, 0.2, 1.4, 0.3, 0xfff6c8);
}
function updateHolyBeam(s, def, dt, cdMul) {
  const f = holyFx.get(s); if (!f) return false;
  const lv = s.lv, area = player.area * player.g.area * player.der.area, range = def.range + (player.rangeBonus || 0);
  if (f.tg && (f.tg.dead || Math.hypot(f.tg.x - player.x, f.tg.z - player.z) > range + 1.5)) f.tg = nearestEnemy(f.x, f.z, range) || nearestEnemy(player.x, player.z, range);
  if (!f.tg || f.bt > HOLY_DUR) { if (f.snd) f.snd.stop(); if (f.rune) f.rune.userData.fade = 0.3; holyFx.delete(s); s.t = s.cdT = uniqCd(def, lv) * cdMul; s.pop = 1; return true; } // done: the cooldown starts
  if (f.bt < 0.9 && f.bt + dt >= 0.9) addShake(0.08);
  f.bt += dt; s.t = 0; s.cdT = HOLY_DUR; // the HUD slot stays full while it fires
  const k = Math.min(1, f.bt / (lv >= 5 ? 2 : 3)), R = (0.7 + 0.6 * k) * (lv >= 3 ? 1.25 : 1) * Math.sqrt(area);
  f.x += (f.tg.x - f.x) * Math.min(1, dt * 6); f.z += (f.tg.z - f.z) * Math.min(1, dt * 6); // glides after its foe
  player.aimX = f.x - player.x; player.aimZ = f.z - player.z; player.castT = 0.1;
  // ONE steady column (user 11-15: 'it's a beam, it should never flicker'): kept alive every frame, following the foe; it fades by itself when the channel ends
  if (!f.col || bolts.indexOf(f.col) < 0) { f.col = { kind: 'pillar', steady: true, pts: [new THREE.Vector3(f.x, 16, f.z), new THREE.Vector3(f.x, 0, f.z)], r: R, life: 0.3, max: 0.3, color: '255,205,90', core: '255,252,235' }; bolts.push(f.col); }
  // Vesper's rune circle in white under the column (user 11-15), following it, turning, brightening with the beam
  if (!f.rune) { const rt = judgRuneTex.clone(); rt.center.set(0.5, 0.5); rt.needsUpdate = true; f.rune = new THREE.Mesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: rt, color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL })); f.rune.renderOrder = 4; f.rune.userData.fade = 0; scene.add(f.rune); holyRunes.push(f.rune); }
  // a CIRCLE on screen (user 11-15): stretched along z by 1/(floor foreshortening) so the tilted camera doesn't squash it; it turns via its texture
  { const sc = R * (0.9 + 0.2 * Math.min(1, f.bt / 0.9)), fs = Math.max(0.3, Math.abs(camera.getWorldDirection(holyDir).y)); f.rune.position.set(f.x, 0.09, f.z); f.rune.scale.set(sc, 1, sc); /* flat on the floor, in the floor's perspective (user 11-15) */ f.rune.material.map.rotation += dt * 0.8; } f.rune.material.opacity = 0.25 + 0.7 * Math.min(1, f.bt / 0.9);
  { const bi = bolts.indexOf(f.col); if (bi < bolts.length - 1) { bolts.splice(bi, 1); bolts.push(f.col); } } // always among the drawn (newest) bolts
  f.col.life = f.col.max = 0.3; f.col.int = Math.min(1, f.bt / 0.9) ** 1.5; f.col.r = R * (0.08 + 0.22 * Math.min(1, f.bt / 0.9)); /* narrower than the rune: its rounded end lands on the rune's CENTRE, not its rim (user 11-15) */ f.col.pts[0].set(f.x, 16, f.z); f.col.pts[1].set(f.x, 0, f.z);
  // it HITS the floor (user 11-15): quick impact ripples from the centre + light splashing out along the floor
  if ((f.rt -= dt) <= 0) { f.rt = 0.16; addRing(f.x, f.z, 0.1, R * 0.75, 0.28, 0xfff6c8); }
  for (let q = fxN(3); q > 0; q--) { const a = Math.random() * 6.283, v = 2.5 + Math.random() * 3; spark(f.x, 0.12, f.z, q & 1 ? 0xffffff : 0xffd870, { vx: Math.cos(a) * v, vz: Math.sin(a) * v, vy: 0.6 + Math.random() * 1.2, s: 0.3, life: 0.3, drag: 3, grav: 4 }); }
  if (fxP(0.5 + 0.4 * k)) { const a = Math.random() * 6.283, d = Math.random() * R; spark(f.x + Math.cos(a) * d, 0.2, f.z + Math.sin(a) * d, Math.random() < 0.5 ? 0xffffff : 0xffd870, { vy: 2 + Math.random() * 3, s: 0.3, life: 0.5, drag: 1 }); }
  // no fxLight here: its range showed as a hard glowing circle on the floor (user 11-15). A burn trail instead: as the column
  // slides after its foe it scorches the floor every ~0.35 tiles, with a few golden embers
  if (f.lx == null || Math.hypot(f.x - f.lx, f.z - f.lz) > 0.35) { f.lx = f.x; f.lz = f.z; if (f.bt > 0.2) { splat(f.x, f.z, 0x050200, R * 0.6, 1); splat(f.x + rr(-0.15, 0.15), f.z + rr(-0.15, 0.15), 0x120600, R * 0.85, 0.8); /* charred black scorch (user 11-15: darker) */ spark(f.x, 0.15, f.z, 0xffc860, { vy: 1.5, s: 0.35, life: 0.6, drag: 1, spread: 1 }); } }
  if (fxP(0.3 + 0.5 * k)) spark(player.x, 0.3, player.z, 0xfff0b0, HOLY_SPK);
  if ((f.tick -= dt) <= 0) {
    f.tick = 0.2;
    const dmg = def.dmg * lvMul(lv) * (1 + 2 * k);
    for (const e of enemies) if (!e.dead && e.spawn >= 0.3 && Math.hypot(e.x - f.x, e.z - f.z) < R + e.r) dotHit(e, dmg, 0xffe9a0, def.els, true);
  }
  return true;
}
function castUnique(s, def, target) {
  const lv = s.lv, dmg = def.dmg * lvMul(lv), area = player.area * player.g.area * player.der.area, range = def.range + (player.rangeBonus || 0), beh = def.sh.beh;
  if (beh === 'judgment') { // Vesper's pillar of light on the biggest crowd in range
    const aoe = 2.2 * (lv >= 3 ? 1.25 : 1) * area, e = densestFoe(target, player.x, player.z, range);
    judgmentStrike(e.x, e.z, dmg, aoe);
    if (lv >= 5) later(0.4, () => { const e2 = player.alive && densestFoe(null, player.x, player.z, range); if (e2) judgmentStrike(e2.x, e2.z, dmg * 0.6, aoe); });
  } else if (beh === 'spike') castSpike(s, dmg, target);
  else if (beh === 'gust') castGust(s, dmg, target, range, area);
  else if (beh === 'holybeam') { if (!holyFx.has(s)) startHolyBeam(s, def, target); }
  else if (beh === 'stormeye') stormEye(dmg, lv, range);
  else if (beh === 'dragon') { const e = densestFoe(target, player.x, player.z, range, 2.4); dragonStrafe(e.x, e.z, dmg, (lv >= 3 ? 1.6 : 1.25) * Math.sqrt(area), def.els); if (lv >= 5) later(1.6, () => { if (!player.alive) return; const e2 = densestFoe(null, player.x, player.z, range, 2.4); if (e2) dragonStrafe(e2.x, e2.z, dmg * 0.8, (lv >= 3 ? 1.6 : 1.25) * Math.sqrt(area), def.els, true); }); }
  else if (beh === 'momentum') { // a straight blue lightning lance that keeps BOUNCING foe to foe for 2.5 s (user 11-15: "keep bouncing
    // until x seconds"): a hop every 0.12 s to the nearest other foe within 7 tiles, preferring foes it hasn't hit in the last 0.6 s;
    // each hop hits for half (it can come back to the same foes). Lv 3: 3 s, Lv 5: 3.5 s.
    const T = 1.5 + (lv >= 3 ? 0.3 : 0) + (lv >= 5 ? 0.3 : 0), aoe = 0.7 * Math.sqrt(area), last = new Map(), tp = staffTip(), tok = s.momTok = (s.momTok || 0) + 1; // shorter than its cooldown, and a new cast ends the old chain (user 11-15: 'make sure it stops')
    const hop = (t, sx, sy, sz, cur) => {
      if (t > T || !player.alive || s.momTok !== tok) return;
      let best = null, bs = Infinity;
      for (const e of enemies) { if (e.dead || e.hidden || e.spawn < 0.3 || e === cur) continue; const d = Math.hypot(e.x - (cur ? cur.x : player.x), e.z - (cur ? cur.z : player.z)); if (d > (cur ? 7 : range)) continue; const sc = d + (G.time - (last.get(e) ?? -9) < 0.6 ? 6 : 0); if (sc < bs) { bs = sc; best = e; } }
      if (!best && cur && !cur.dead) best = cur; // alone: it keeps striking the same foe (user: can hit the same monster)
      if (!best) return;
      last.set(best, G.time); momentumStrike(best.x, best.z, dmg * 0.5, aoe, null, sx, sy, sz);
      const bx = best.x, bz = best.z; later(0.12, () => hop(t + 0.12, bx, 0.6, bz, best.dead ? null : best));
    };
    hop(0, tp.x, tp.y, tp.z, null);
  }
}
// bosses can't be stunned or frozen by the unique spells: they say so once per fight
function immNote(e, stun) {
  const k = stun ? 'immStun' : 'immFreeze'; if (e[k]) return; e[k] = 1;
  addText(e.x, 3.2, e.z, 'IMMUNE', '#a0a0b8', 1.1); burst(e.x, 1.5, e.z, 0x9a9aa8, 8, 3, 0.35, 0.4);
}
// Earth Spike: lines of stone spikes from Pip toward the nearest foe (0.4s for 6 tiles), stopped by walls; hit foes are STUNNED
function castSpike(s, dmg, target) {
  const lv = s.lv, L = 6 + (lv >= 5 ? 2 : 0), x0 = player.x, z0 = player.z, a0 = Math.atan2(target.z - z0, target.x - x0);
  const hit = new Set(), lines = lv >= 5 ? 3 : lv >= 3 ? 2 : 1;
  for (let l = 0; l < lines; l++) {
    const a = a0 + (l === 1 ? 0.45 : l === 2 ? -0.45 : 0), cx = Math.cos(a), cz = Math.sin(a);
    let len = L; for (let d = 0.5; d < L; d += 0.25) if (solid(x0 + cx * d, z0 + cz * d, true)) { len = d - 0.2; break; }
    // Frost Diver's system in stone (user 11-15: "Earth Spike still looks bad - Frost Diver looks real good"; "maybe some crack on the
    // floor"): a dark jagged crack rips along the floor with the line's head, grey-black stone spikes burst up out of it in a
    // zig-zag swept forward, dust and grit fly, the spikes crumble back down. Hits / reach / stun unchanged.
    addEStreak(x0 + cx * 0.5, z0 + cz * 0.5, cx, cz, len - 0.5);
    for (let d = 0.6, k = 0; d <= len; d += MOBILE ? 0.34 : 0.28, k++) {
      const side = k % 2 ? 1 : -1, off = side * (0.12 + Math.random() * 0.1), x = x0 + cx * d - cz * off, z = z0 + cz * d + cx * off, delay = (d - 0.6) / 24; // faster (user 11-15)
      addEShard(x, z, 1.0 + Math.random() * 0.6 + (k % 3 === 0 ? 0.35 : 0), 0.9 + Math.random() * 0.3, a + side * 1.0, 0.3 + Math.random() * 0.25, delay);
      addEShard(x0 + cx * d + cz * off * 0.6, z0 + cz * d - cx * off * 0.6, 0.45 + Math.random() * 0.25, 0.7, a - side * 1.2, 0.4, delay + 0.02);
      later(delay, () => {
        if (k % 2 === 0) { chunkDust(x, z, 0x8a8478); chunk(x, 0.35, z, k % 4 ? 0x5a5a62 : 0x2a2a30, MOBILE ? 1 : 2, 4, 0.1); }
        if (k % 3 === 0) { sfx('thud'); addShake(0.05); }
        for (const e of enemies) if (!e.dead && e.spawn >= 0.3 && !hit.has(e) && Math.hypot(e.x - x, e.z - z) < 0.55 + e.r) { hit.add(e); spikeHit(e, dmg, x0, z0); }
      });
    }
  }
  addShake(0.28); sfx('spike'); sfx('rockfall'); sfx('slam'); // a heavier crack-and-rumble (user 11-15: 'more impactful sound')
}
function spikeHit(e, dmg, sx, sz) {
  const st0 = e.stun || 0;
  hurtEnemy(e, dmg, e.x - sx, e.z - sz, 1.5, 0xc8925a, ['earth']);
  burst(e.x, 0.6, e.z, 0xd8b888, 10, 4, 0.35, 0.35); addRing(e.x, e.z, 0.2, 1.1, 0.25, 0xc8a878); // impaled
  if (e.dead) return;
  if (e.isBoss) { e.stun = st0; immNote(e, true); return; } // no stun on bosses (not even earth's random one from this hit)
  e.stun = Math.max(e.stun || 0, 1.2 * Math.min(1, ccMul(e) * 1.4)); // 1.2s; tough foes (golems, named) a bit less
}
// the spikes: one instanced draw of the trap cones in earth colour, a ring buffer of 64 (2 cones each)
// black-grey stone spikes (user 11-15: "not flat, some black grey"): a 5-sided rock cone, near-black at the ground fading to a
// light grey tip (vertex colours), faceted shading
const espkGeo = (() => { const g = new THREE.ConeGeometry(0.085, 0.42, 5).translate(0, 0.21, 0), p = g.attributes.position, c = [], lo = new THREE.Color(0x1c1c22), hi = new THREE.Color(0xb4b4be), t = new THREE.Color();
  for (let i = 0; i < p.count; i++) { t.copy(lo).lerp(hi, Math.pow(p.getY(i) / 0.42, 1.4)); c.push(t.r, t.g, t.b); }
  g.setAttribute('color', new THREE.Float32BufferAttribute(c, 3)); return g; })();
const ESPK = 96, espkMesh = new THREE.InstancedMesh(espkGeo, new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x08080c, flatShading: true }), ESPK * 2);
espkMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); espkMesh.frustumCulled = false;
bMat.makeScale(0, 0, 0); for (let i = 0; i < ESPK * 2; i++) espkMesh.setMatrixAt(i, bMat);
scene.add(espkMesh);
const espk = Array.from({ length: ESPK }, () => ({ t: 9, x: 0, z: 0, s: 1 }));
let espkHead = 0, espkLive = 0;
function addEspk(x, z, s) { const p = espk[espkHead]; espkHead = (espkHead + 1) % ESPK; p.t = 0; p.x = x; p.z = z; p.s = s; espkLive = 0.8; }
function updateEspk(dt) {
  if (espkLive <= 0) return;
  espkLive -= dt;
  for (let i = 0; i < ESPK; i++) {
    const p = espk[i]; if (p.t > 0.7) continue;
    p.t += dt;
    const k = p.t < 0.07 ? p.t / 0.07 : p.t < 0.45 ? 1 : Math.max(0, 1 - (p.t - 0.45) / 0.25), sy = k * p.s * 2.2;
    // a retracted spike used to stay as a 0.0001-tall cone: a flat earth-coloured disc at y=0, flickering against the floor tiles.
    // Now it's gone (zero scale) when down, and the base starts 8 cm under the floor so no face ever lies on it.
    if (k <= 0.02) { bMat.makeScale(0, 0, 0); espkMesh.setMatrixAt(i * 2, bMat); espkMesh.setMatrixAt(i * 2 + 1, bMat); if (p.t > 0.7) p.t = 9; continue; }
    espkMesh.setMatrixAt(i * 2, bMat.makeScale(p.s * 2.4, sy + 0.19, p.s * 2.4).setPosition(p.x, -0.08, p.z));
    espkMesh.setMatrixAt(i * 2 + 1, bMat.makeScale(p.s * 1.5, sy * 0.6 + 0.19, p.s * 1.5).setPosition(p.x + 0.17, -0.08, p.z + 0.1));
  }
  espkMesh.instanceMatrix.needsUpdate = true;
}
// Bone Eruption (the Bone Tyrant's bone lines; Pip's boss.bones is now Bone Boomerang, below), shadow element. It must never read as Earth Spike's brown rock
// cones (user): at each spot along a line a small RIBCAGE bursts from a violet-black crack: two pairs of bleach-white curved
// ribs arch up from opposite sides and bend in over the middle, dark joints at their roots, a violet shadow glow, white bone
// shards flying; it holds, then crumbles into white bone dust. Timing and hits are unchanged (castBossSpell 'bones').
// Cheap: one instanced draw for the ribs, one for the joints, a ring buffer of BONE_N spots, nothing made per spot or frame.
const BONE_N = 64, BONE_PER = 4;
const ribCurve = new THREE.CubicBezierCurve3(new THREE.Vector3(0, 0, 0), new THREE.Vector3(-0.06, 0.5, 0), new THREE.Vector3(0.12, 0.98, 0), new THREE.Vector3(0.36, 0.92, 0));
const boneGeo = new THREE.TubeGeometry(ribCurve, 9, 0.065, 5, false);
const boneMesh = new THREE.InstancedMesh(boneGeo, new THREE.MeshLambertMaterial({ color: 0xf2f0f6, emissive: 0x9a94a2, side: THREE.DoubleSide }), BONE_N * BONE_PER);
const jointMesh = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.085, 0), new THREE.MeshLambertMaterial({ color: 0x2a0f3a, emissive: 0x1a0626 }), BONE_N * BONE_PER);
for (const m of [boneMesh, jointMesh]) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; bMat.makeScale(0, 0, 0); for (let i = 0; i < BONE_N * BONE_PER; i++) m.setMatrixAt(i, bMat); scene.add(m); }
// rib j of a spot: pair 0/1 a little apart along the spine, left ribs arch to +x, right ribs are their mirror image
const RIB = [[-0.3, -0.13, 1], [0.3, -0.13, -1], [-0.27, 0.13, 1], [0.27, 0.13, -1]];
const bones = Array.from({ length: BONE_N }, () => ({ t: 9, x: 0, z: 0, dust: 1, off: true, q: new THREE.Quaternion(), cy: 1, sy: 0, sp: Array.from({ length: BONE_PER }, () => ({ ox: 0, oz: 0, h: 1 })) }));
const boneAxis = new THREE.Vector3(0, 1, 0), boneP = new THREE.Vector3(), boneS = new THREE.Vector3(), boneQ = new THREE.Quaternion();
const BONE_DUST = { vy: 1.1, s: 0.34, life: 0.5, drag: 3 };
let boneHead = 0, boneLive = 0;
function addBones(x, z, s = 1) {
  const p = bones[boneHead]; boneHead = (boneHead + 1) % BONE_N;
  p.t = 0; p.x = x; p.z = z; p.dust = 0; p.off = false; boneLive = 0.9;
  const yaw = Math.random() * 6.283; p.cy = Math.cos(yaw); p.sy = Math.sin(yaw); p.q.setFromAxisAngle(boneAxis, yaw);
  for (let i = 0; i < BONE_PER; i++) {
    const sp = p.sp[i], [lx, lz] = RIB[i];
    sp.ox = lx * p.cy + lz * p.sy; sp.oz = -lx * p.sy + lz * p.cy; // the rib's root, turned with the cage (a y-rotation)
    sp.h = s * (i < 2 ? 0.95 + Math.random() * 0.15 : 0.78 + Math.random() * 0.12);
  }
  splat(x, z, 0x2a0a40, 0.7); // the violet-black crack it bursts from
  spark(x, 0.06, z, 0x8a3cff, { s: 1.5, life: 0.55, drag: 0 }); // the shadow glow under it
  for (let k = 0; k < 2; k++) { const a = Math.random() * 6.283; spark(x + Math.cos(a) * 0.25, 0.1, z + Math.sin(a) * 0.25, 0x6a2aa8, { vx: Math.cos(a) * 1.2, vz: Math.sin(a) * 1.2, vy: 0.5, s: 0.4, life: 0.45, drag: 3 }); }
  chunk(x, 0.3, z, 0xf4efe2, 2, 2.2, 0.07); // a couple of bone shards fly
}
function updateBones(dt) {
  if (boneLive <= 0) return;
  boneLive -= dt;
  for (let i = 0; i < BONE_N; i++) {
    const p = bones[i]; if (p.off) continue;
    p.t += dt;
    const t = p.t;
    if (t > 0.66) { p.off = true; bMat.makeScale(0, 0, 0); for (let j = 0; j < BONE_PER; j++) { boneMesh.setMatrixAt(i * BONE_PER + j, bMat); jointMesh.setMatrixAt(i * BONE_PER + j, bMat); } continue; }
    // burst up fast (with a small overshoot), hold, then crumble: sink and shrink into white bone dust
    const up = t < 0.08 ? 1 - (1 - t / 0.08) ** 3 : 1, ov = t < 0.08 ? 1 : t < 0.14 ? 1 + 0.1 * Math.sin((t - 0.08) / 0.06 * Math.PI) : 1;
    const c = t < 0.42 ? 0 : (t - 0.42) / 0.24;
    if (c > 0 && !p.dust) { p.dust = 1; chunk(p.x, 0.4, p.z, 0xf4efe2, 3, 2.4, 0.07);
      for (let k = 0; k < 3; k++) { const a = Math.random() * 6.283; spark(p.x + Math.cos(a) * 0.2, 0.25, p.z + Math.sin(a) * 0.2, 0xf6f2e8, { ...BONE_DUST, vx: Math.cos(a) * 1.4, vz: Math.sin(a) * 1.4 }); } }
    for (let j = 0; j < BONE_PER; j++) {
      const sp = p.sp[j], h = sp.h * up * ov * (1 - 0.5 * c), w = 1 - 0.35 * c, sink = -sp.h * 0.8 * c * c;
      boneP.set(p.x + sp.ox, sink, p.z + sp.oz); boneS.set(RIB[j][2] * w * (0.85 + 0.15 * up), h || 0.0001, w);
      boneMesh.setMatrixAt(i * BONE_PER + j, bMat.compose(boneP, p.q, boneS));
      boneP.y = 0.03 + sink; const js = (0.6 + 0.4 * up) * w; boneS.set(js, js * 0.8, js);
      jointMesh.setMatrixAt(i * BONE_PER + j, bMat.compose(boneP, boneQ, boneS));
    }
  }
  boneMesh.instanceMatrix.needsUpdate = true; jointMesh.instanceMatrix.needsUpdate = true;
}
// ---------- Corpse Blast (shadow.hex, replaced Hex Sigil: no rune at Pip's feet, it happens out among the monsters) ----------
// Every death leaves a corpse spot (a ring buffer of the last CB_KEEP, fresh for CB_AGE s). A cast picks the corpses with the most
// living foes around them and blows them up one after another: a black-violet fireball core, rising dark flames, bone chips,
// a shock ring and a crater. A foe a blast kills blows up too (chain reaction), capped per cast in generations and blasts.
// No corpses near foes: a dark bolt flies at the foe and blasts where it lands. Pooled: one instanced draw for the cores
// (the debris mesh's Lambert program, so no new shader), corpse spots preallocated; sparks, chunks, rings and splats are pooled.
const CB_KEEP = 12, CB_AGE = 8, CB_N = 16;
const cbSpots = Array.from({ length: CB_KEEP }, () => ({ x: 0, z: 0, t: -99, sc: 0 }));
let cbHead = 0, cbCur = null, cbLive = 0;
const cbPick = [];
const cbMesh = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshLambertMaterial({ emissive: 0x2a0846 }), CB_N);
cbMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); cbMesh.frustumCulled = false;
const cbCores = Array.from({ length: CB_N }, () => ({ t: 9, x: 0, z: 0, r: 1 }));
for (let i = 0; i < CB_N; i++) { cbMesh.setMatrixAt(i, dm.makeScale(0, 0, 0)); cbMesh.setColorAt(i, tmpC.set(0x1a0628)); }
scene.add(cbMesh);
let cbCoreHead = 0;
function corpseDied(e) {
  const c = cbCur;
  if (c && c.n < c.max && c.gen < c.maxGen) { // killed by a Corpse Blast: its own corpse goes off next (chain reaction)
    c.n++; const x = e.x, z = e.z, gen = c.gen + 1;
    later(0.11, () => corpseBoom(x, z, c, gen, 1));
    return;
  }
  const s = cbSpots[cbHead]; cbHead = (cbHead + 1) % CB_KEEP;
  s.x = e.x; s.z = e.z; s.t = G.time;
}
function castCorpseBlast(lv, dmg, R, els, col, target, range, n, px, pz, py, a) {
  const cast = { dmg, R, els, col, lv, n: 0, gen: 0, max: (lv >= 5 ? 14 : 10) + CB_KEEP, maxGen: lv >= 5 ? 5 : 3 }; // + every corpse that goes off at once
  if (SPELLV) for (const e of enemies) if (!e.dead && Math.random() < 0.6) { const s = cbSpots[cbHead]; cbHead = (cbHead + 1) % CB_KEEP; s.x = e.x + rr(-1.2, 1.2); s.z = e.z + rr(-1.2, 1.2); s.t = G.time; } // the viewer's dummies rarely die: give it corpses to show
  // EVERY fresh corpse in the room goes off at once (user 11-15: "blast all corpses at once"), foes near it or not; the blasts'
  // kills still chain (corpseDied)
  let k = 0;
  for (const s of cbSpots) {
    if (s.t < 0 || G.time - s.t > CB_AGE || Math.hypot(s.x - player.x, s.z - player.z) > 14) continue;
    const x = s.x, z = s.z; s.t = -99; cast.n++; k++;
    corpseBoom(x, z, cast, 0, 1);
  }
  if (k) { addShake(Math.min(0.5, 0.15 + k * 0.05)); return; }
  // no corpse near a foe: no projectile (user 11-15) - the blast goes off right on the foe, as hard as the old bolt's
  cast.n = 1;
  corpseBoom(target.x, target.z, cast, 0, 1.4);
}
// fresh corpses you can blow up (user 11-15: "we need to figure out how to show the corpse"): while Pip owns Corpse Blast,
// every corpse spot shows a little skull-and-bones pile on the floor with a faint violet glow, fading out as it expires.
const cbMarkTex = (() => { try {
  const c = document.createElement('canvas'); c.width = c.height = 128; const g = c.getContext('2d'); g.translate(64, 64);
  const rg = g.createRadialGradient(0, 0, 4, 0, 0, 62); rg.addColorStop(0, 'rgba(150,70,255,.55)'); rg.addColorStop(1, 'rgba(90,20,180,0)'); g.fillStyle = rg; g.fillRect(-64, -64, 128, 128);
  g.lineCap = 'round'; g.strokeStyle = '#2a1a22'; g.lineWidth = 13; g.beginPath(); g.moveTo(-30, 26); g.lineTo(30, -8); g.moveTo(-30, -8); g.lineTo(30, 26); g.stroke(); // crossed bones
  g.strokeStyle = '#efe6d2'; g.lineWidth = 8; g.stroke();
  for (const [x, y] of [[-30, 26], [30, -8], [-30, -8], [30, 26]]) { g.fillStyle = '#2a1a22'; g.beginPath(); g.arc(x, y, 8, 0, 6.2832); g.fill(); g.fillStyle = '#efe6d2'; g.beginPath(); g.arc(x, y, 5.5, 0, 6.2832); g.fill(); }
  g.fillStyle = '#2a1a22'; g.beginPath(); g.ellipse(0, -12, 24, 22, 0, 0, 6.2832); g.fill(); g.fillRect(-13, 0, 26, 16); // skull
  g.fillStyle = '#f4ecdc'; g.beginPath(); g.ellipse(0, -12, 20, 18, 0, 0, 6.2832); g.fill(); g.fillRect(-10, 0, 20, 13);
  g.fillStyle = '#1a0a1e'; g.beginPath(); g.ellipse(-8, -12, 6, 7, 0, 0, 6.2832); g.ellipse(8, -12, 6, 7, 0, 0, 6.2832); g.fill(); g.fillRect(-2, -3, 4, 5);
  return new THREE.CanvasTexture(c);
} catch (e) { return null; } })();
const cbMarks = cbSpots.map(() => { if (!cbMarkTex) return null; const m = new THREE.Mesh(new THREE.PlaneGeometry(0.95, 0.95), new THREE.MeshBasicMaterial({ map: cbMarkTex, transparent: true, depthWrite: false, opacity: 0 })); m.rotation.x = -Math.PI / 2 + 0.35; m.visible = false; scene.add(m); return m; });
function updateCorpseMarks() {
  const on = !!player && spells.some((s) => { const d = spellDef(s.id); return d && d.sh && d.sh.corpse; });
  for (let i = 0; i < CB_KEEP; i++) {
    const m = cbMarks[i]; if (!m) continue; const s = cbSpots[i], age = G.time - s.t;
    if (!on || s.t < 0 || age > CB_AGE || age < 0) { m.visible = false; continue; }
    m.visible = true; m.position.set(s.x, 0.12, s.z); m.material.opacity = Math.min(1, age * 4, (CB_AGE - age) / 1.5) * (0.85 + 0.15 * Math.sin(G.time * 4 + i));
  }
}
// a translucent violet shockwave dome that bursts out to the blast radius and fades (pooled), and real little bones (the Bone
// Boomerang's bone shape) flung out tumbling, bouncing and settling (pooled)
const CBD_N = 6, cbDomes = [], cbDomeGeo = new THREE.SphereGeometry(1, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2);
function cbDome(x, z, R) {
  let d = cbDomes.find((q) => q.t > 0.4); if (!d && cbDomes.length < CBD_N) { d = { m: new THREE.Mesh(cbDomeGeo, new THREE.MeshBasicMaterial({ color: 0x8a3cff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })), t: 9 }; cbDomes.push(d); }
  if (!d) return; d.t = 0; d.R = R; d.m.position.set(x, 0.02, z); if (!d.m.parent) scene.add(d.m);
  addRing(x, z, R * 0.9, R * 1.05, 0.5, 0x5a1aa0); splat(x, z, 0x0a0410, R * 1.0, 0.95); // dark crater, violet rim
}
const CBB_N = 40, cbBoneP = []; let cbBoneHead = 0, cbBoneMat = null;
function cbBones(x, z, n) {
  for (let k = 0; k < n; k++) {
    let p = cbBoneP[cbBoneHead]; if (!p) p = cbBoneP[cbBoneHead] = { m: new THREE.Mesh(boomGeo, cbBoneMat || (cbBoneMat = new THREE.MeshLambertMaterial({ color: 0xd8ccb4, emissive: 0x2a2018 }))), t: 9 };
    cbBoneHead = (cbBoneHead + 1) % CBB_N;
    const a = Math.random() * 6.283, v = 3 + Math.random() * 4;
    Object.assign(p, { t: 0, x, y: 0.6, z, vx: Math.cos(a) * v, vy: 4 + Math.random() * 3, vz: Math.sin(a) * v, rx: rr(-14, 14), ry: rr(-14, 14), s: 0.13 + Math.random() * 0.08 });
    p.m.scale.setScalar(p.s); if (!p.m.parent) scene.add(p.m);
  }
}
function updateCbFx(dt) {
  for (const d of cbDomes) {
    if (d.t > 0.4) continue; d.t += dt; if (d.t > 0.4) { scene.remove(d.m); continue; }
    const k = d.t / 0.4, e = 1 - (1 - k) ** 3; d.m.scale.set(d.R * (0.25 + 0.95 * e), d.R * (0.2 + 0.7 * e), d.R * (0.25 + 0.95 * e)); d.m.material.opacity = 0.55 * (1 - k) ** 1.5;
  }
  for (const p of cbBoneP) {
    if (!p || p.t > 1.8) continue; p.t += dt; if (p.t > 1.8) { scene.remove(p.m); continue; }
    p.vy -= 22 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    if (p.y < 0.06) { p.y = 0.06; p.vy = Math.abs(p.vy) > 2 ? -p.vy * 0.35 : 0; p.vx *= 0.55; p.vz *= 0.55; p.rx *= 0.5; p.ry *= 0.5; }
    p.m.rotation.x += p.rx * dt; p.m.rotation.y += p.ry * dt;
    const sink = p.t > 1.4 ? (p.t - 1.4) / 0.4 : 0; p.m.position.set(p.x, p.y - sink * 0.1, p.z); p.m.scale.setScalar(p.s * (1 - sink));
  }
}
// ---------- Corpse Blast's shadow hands: a dark pool spreads from the corpse, 6-7 painted shadow hands (sprites/shadow_hand.webp)
// burst up out of it in a ring + one big one in the middle, clutch (sway / squeeze) for a moment, then sink back down. Pooled.
const HANDS_N = 28, hands = [];
function shadowHands(x, z, R) {
  splat(x, z, 0x0a0410, R * 1.1, 0.95); addRing(x, z, 0.3, R * 1.05, 0.45, 0x5a1aa0);
  const n = MOBILE ? 5 : 6, put = (hx, hz, h, lean, delay) => {
    let p = hands.find((q) => q.t > q.T); if (!p && hands.length < HANDS_N) { const m = makeSprite('shadow_hand', 1); m.material.side = THREE.DoubleSide; m.visible = false; p = { m, t: 9, T: 0 }; hands.push(p); }
    if (!p) return; Object.assign(p, { x: hx, z: hz, h, lean, t: -delay, T: 0.8, flip: Math.random() < 0.5 ? -1 : 1 });
  };
  put(x, z, 1.5, 0, 0);
  for (let k = 0; k < n; k++) { const a = k / n * 6.2832 + Math.random() * 0.4, d = R * (0.45 + Math.random() * 0.3); put(x + Math.cos(a) * d, z + Math.sin(a) * d, 0.9 + Math.random() * 0.4, Math.cos(a) * 0.35, 0.03 + Math.random() * 0.1); }
  for (let k = fxN(10); k > 0; k--) { const a = Math.random() * 6.283, d = Math.random() * R; spark(x + Math.cos(a) * d, 0.15, z + Math.sin(a) * d, k & 1 ? 0x2a0a4a : 0x6a2aaa, { vy: 1 + Math.random() * 1.5, s: 0.6, life: 0.7, drag: 1 }); }
}
function updateHands(dt) {
  for (const p of hands) {
    if (p.t > p.T) { if (p.m.visible) p.m.visible = false; continue; }
    p.t += dt; if (p.t < 0) continue; if (p.t > p.T) { p.m.visible = false; continue; }
    const t = p.t, rise = t < 0.12 ? 1 - (1 - t / 0.12) ** 3 : 1, sink = t > 0.55 ? (t - 0.55) / 0.25 : 0;
    p.m.visible = true; p.m.position.set(p.x, -0.15 - sink * p.h * 0.9, p.z);
    billboard(p.m, p.lean + Math.sin(t * 18 + p.x) * 0.12 * (1 - sink)); // clutching sway
    setSpriteScale(p.m, p.flip * (1 + Math.sin(t * 25) * 0.06) * p.h, rise * p.h * (1 - 0.15 * Math.sin(t * 25)));
    p.m.material.uniforms.uAlpha.value = 1 - sink * 0.7;
  }
}
// ---------- Corpse Blast's ghost burst: 6 (phones 4) ghost-face spirits (the 'soul' shot mesh) burst out of the corpse in a ring,
// rising and curling as they fly out to the blast radius, then fade; a dark splat + a pale ring under them. Visual only (pooled meshes).
const ghostFx = [];
function ghostBurst(x, z, R) {
  splat(x, z, 0x0a0410, R * 0.8, 0.85); addRing(x, z, 0.2, R * 1.1, 0.4, 0xb8a8ff); sfx('moan');
  const n = MOBILE ? 4 : 6, a0 = Math.random() * 6.283;
  for (let k = 0; k < n; k++) { const m = makeProjMesh('soul', 0x6a3ad0); m.scale.setScalar(1.15); ghostFx.push({ m, x, z, a: a0 + k / n * 6.283, R: R * 1.6, t: 0, T: 1.4 + Math.random() * 0.3, /* slower, farther (user: too fast to see) */ curl: (k % 2 ? 1 : -1) * 0.9 }); }
}
function updateGhostFx(dt) {
  for (let i = ghostFx.length - 1; i >= 0; i--) {
    const g = ghostFx[i]; g.t += dt; const k = g.t / g.T, e = 1 - (1 - Math.min(1, k)) ** 2, a = g.a + g.curl * e;
    g.m.position.set(g.x + Math.cos(a) * g.R * e, 0.5 + 1.1 * e + Math.sin(g.t * 14) * 0.05, g.z + Math.sin(a) * g.R * e);
    g.m.rotation.y = -(a + g.curl * 0.6); g.m.scale.setScalar(1.15 * (1 - Math.max(0, k - 0.6) / 0.4));
    if (fxP(0.3)) spark(g.m.position.x, g.m.position.y, g.m.position.z, 0x7a5ad0, { s: 0.3, life: 0.25, drag: 1 });
    if (k >= 1) { const m = g.m; if (m.parent === scene && m.userData.pk) { let pool = projPool.get(m.userData.pk); if (!pool) projPool.set(m.userData.pk, pool = []); if (pool.length < 48) pool.push(m); } scene.remove(m); ghostFx.splice(i, 1); }
  }
}
const cbSkulls = [];
function cbSkull(x, z) { // the rising ghost skull (the 'skull' shot mesh, pooled by makeProjMesh), drifting up and fading
  const m = makeProjMesh('skull', 0x6a1ab0); m.scale.setScalar(1.4); m.position.set(x, 0.8, z); cbSkulls.push({ m, t: 0, x, z, g: makeGlowAt(x, 1, z, 0x5a1aa0, 0.9, 0.45) });
}
function updateCbSkulls(dt) {
  for (let i = cbSkulls.length - 1; i >= 0; i--) {
    const s = cbSkulls[i]; s.t += dt; const k = s.t / 0.8;
    s.m.position.set(s.x + Math.sin(s.t * 9) * 0.08, 0.8 + k * 1.8, s.z); s.m.rotation.y = Math.PI / 2 + Math.sin(s.t * 6) * 0.3; s.m.scale.setScalar(1.4 * (1 + k * 0.3) * (1 - Math.max(0, k - 0.7) / 0.3));
    s.g.position.copy(s.m.position); s.g.scale.setScalar(0.9 * (1 - k));
    if (fxP(0.4)) spark(s.m.position.x, s.m.position.y, s.m.position.z, 0xb070ff, { vy: 0.5, s: 0.4, life: 0.3, drag: 1 });
    if (k >= 1) { scene.remove(s.m); killGlow(s.g); cbSkulls.splice(i, 1); }
  }
}
function corpseBoom(x, z, c, gen, mul) {
  if (!player.alive) return;
  const R = c.R, col = c.col;
  // look: a black-violet fireball core puffs up and collapses, dark flames lick upward, bone chips and black gore fly
  // (user 11-15: "instead of the circle in the middle, something better"): no ball - the corpse erupts in a column of dark violet
  // flame, bones fly out and a ghostly skull rises out of the blast and fades
  for (let k = fxN(14); k > 0; k--) { const a = Math.random() * 6.283, d = Math.random() * R * 0.35; spark(x + Math.cos(a) * d, 0.2, z + Math.sin(a) * d, k & 1 ? 0x4a0a8a : 0x7a2ad8, { vy: 3 + Math.random() * 3, vx: Math.cos(a) * 0.6, vz: Math.sin(a) * 0.6, s: 0.9 + Math.random() * 0.5, life: 0.45 + Math.random() * 0.25, drag: 1.2 }); }
  ghostBurst(x, z, R); // (user 11-15: no hands - 'ghost burst') wailing spirits burst out of the corpse in every direction
  addRing(x, z, 0.3, R * 1.15, 0.32, 0x6a1ab0); addRing(x, z, 0.15, R * 0.6, 0.22, 0x3a0a66); // dark violet, no white (user 11-15: white overdraw)
  burst(x, 0.5, z, 0x7a2ad8, 14, 6.5, 0.55, 0.45); burst(x, 0.7, z, 0x12061c, 10, 3, 0.7, 0.6); // + black smoke
  for (let k = 0; k < 7; k++) { const aa = Math.random() * 6.283, rr0 = Math.random() * R * 0.5; spark(x + Math.cos(aa) * rr0, 0.25, z + Math.sin(aa) * rr0, k & 1 ? 0x5a14a8 : 0x7a2ad8, { vy: 3 + Math.random() * 2, s: 0.75, life: 0.55, drag: 1.5, grav: 2 }); }
  chunk(x, 0.4, z, 0xa89c88, 2, 6, 0.08); chunk(x, 0.35, z, 0x1a0a22, 3, 5, 0.12);
  splat(x, z, 0x12061c, R * 1.1, 0.95);
  addShake(0.1); sfx('boom');
  // damage: the blast's own kills are corpses that go off next (corpseDied, while cbCur is set)
  const prev = cbCur; cbCur = c; c.gen = gen;
  const d0 = c.dmg * mul * Math.pow(0.7, gen), lv5 = c.lv >= 5; // chain blasts fade: x0.7 per link (was a flat x0.85)
  const hits = c.hits || (c.hits = new Map()); // per cast: a foe takes one blast in full, every further blast of the same cast only 25% (user 11-17: 'corpse blast is too good' - a room of corpses going off at once killed everything)
  for (const e of [...enemies]) {
    if (e.dead || e.hidden) continue;
    const d = Math.hypot(e.x - x, e.z - z);
    if (d >= R + e.r) continue;
    const nh = hits.get(e) || 0; hits.set(e, nh + 1);
    hurtEnemy(e, d0 * (1 - 0.3 * d / (R + e.r)) * (nh ? 0.25 : 1), e.x - x, e.z - z, 5, col, c.els);
    if (lv5 && !e.dead && e.curse > 0) { e.curse = Math.max(e.curse, 6); e.curseDmg = Math.max(e.curseDmg || 0, d0 * 2.2 * player.der.status); } // Lv 5: a longer, harder curse
  }
  for (const pot of [...pots]) if (Math.hypot(pot.x - x, pot.z - z) < R) breakPot(pot);
  cbCur = prev;
}
function updateCorpseFx(dt) {
  if (cbLive <= 0) return;
  cbLive -= dt;
  for (let i = 0; i < CB_N; i++) {
    const o = cbCores[i]; if (o.t > 0.34) continue;
    o.t += dt;
    const t = o.t, s = o.t > 0.34 ? 0 : (t < 0.09 ? 1 - (1 - t / 0.09) ** 3 : 1 - ((t - 0.09) / 0.25) ** 2) * o.r * 0.4;
    cbMesh.setMatrixAt(i, s > 0.001 ? dm.compose(dv.set(o.x, 0.35 + t * 1.2, o.z), dq.identity(), ds.set(s, s * 0.85, s)) : dm.makeScale(0, 0, 0));
  }
  cbMesh.instanceMatrix.needsUpdate = true;
}
// ---------- Bone Boomerang (Pip's boss.bones, replaced Bone Eruption) ----------
// One giant ivory bone spins out toward the foe, swings round Pip in a wide loop and comes home to him (not a straight
// out-and-back like the glaives). Lv 3 adds a second bone looping the other way, Lv 5 makes them bigger and faster. It pierces
// everything: each foe can be hit once going out and once coming back. Faint violet trail, bone chips on hits.
// Pooled: BOOM_N slots in one instanced draw, nothing made per cast. (The Bone Tyrant keeps his own bone lines: addBones above.)
const BOOM_N = 6;
const boomGeo = (() => { // a curved rib with double knobs at both ends, lying flat, merged into one geometry
  const curve = new THREE.QuadraticBezierCurve3(new THREE.Vector3(-0.78, 0, -0.1), new THREE.Vector3(0, 0, 0.32), new THREE.Vector3(0.78, 0, -0.1));
  const parts = [new THREE.TubeGeometry(curve, 12, 0.12, 6, false)];
  for (const [x, z] of [[-0.88, -0.02], [-0.77, -0.23], [0.88, -0.02], [0.77, -0.23]]) parts.push(new THREE.IcosahedronGeometry(0.17, 1).translate(x, 0, z));
  const pos = [], nor = [];
  for (const g of parts) { const n = g.index ? g.toNonIndexed() : g; pos.push(...n.attributes.position.array); nor.push(...n.attributes.normal.array); g.dispose(); n.dispose(); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  return g.translate(0, 0, 0.02);
})();
const boomMesh = new THREE.InstancedMesh(boomGeo, new THREE.MeshLambertMaterial({ color: 0xf3ead6, emissive: 0x6a6052 }), BOOM_N);
// pulled toward the camera like the ice blocks, so the bone flies over the foes' sprites instead of through them
boomMesh.material.onBeforeCompile = (s) => { s.vertexShader = s.vertexShader.replace('#include <project_vertex>', '#include <project_vertex>\n  mvPosition.z += 1.3; gl_Position = projectionMatrix * mvPosition;'); };
boomMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); boomMesh.frustumCulled = false; boomMesh.count = 0; scene.add(boomMesh);
const booms = Array.from({ length: BOOM_N }, () => ({ on: false, t: 0, dur: 1, a: 0, dir: 1, R: 4, s: 1, dmg: 0, els: null, col: 0, spin: 0, x: 0, z: 0, out: new Set(), back: new Set() }));
const boomP = new THREE.Vector3(), boomS = new THREE.Vector3(), boomQ = new THREE.Quaternion(), boomE = new THREE.Euler();
const BOOM_TRAIL = { s: 0.55, life: 0.32, drag: 2 };
function addBoomerang(a, dir, R, dur, s, dmg, els, col) {
  const b = booms.find((q) => !q.on); if (!b) return;
  Object.assign(b, { on: true, t: 0, dur, a, dir, R, s, dmg, els, col, spin: Math.random() * 6.283, x: player.x, z: player.z, hunt: false, home: false, tour: null, ti: 0, hist: null, hd: null, homeT: 0 });
  b.out.clear(); b.back.clear(); return b;
}
function boomPos(b, u) { // polar around Pip: out along a, round the loop, home along a again
  const th = b.a + b.dir * 6.2832 * u * u * (3 - 2 * u), r = b.R * Math.pow(Math.max(0, Math.sin(Math.PI * u)), 0.55);
  boomP.set(player.x + Math.cos(th) * r, 0, player.z + Math.sin(th) * r);
}
function boomHit(b, x, z, vx, vz) {
  const set = (b.hunt ? !b.home : b.t < b.dur * 0.5) ? b.out : b.back, hr = 1.8 * b.s; // the bone draws small (user: too big, twice); the hit reach stays about what it was
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i]; if (!e || e.dead || set.has(e)) continue;
    const dx = e.x - x, dz = e.z - z, rr2 = hr + e.r; if (dx * dx + dz * dz > rr2 * rr2) continue;
    set.add(e); hurtEnemy(e, b.dmg, vx, vz, 2, b.col, b.els);
    // the CRACK (user 11-15 "lacking some effect", "underwhelming"): a white flash, a bone-white shock ring, splinters and
    // crack sparks thrown the way the bone travels, a puff of bone dust, a beat of hit-stop and a thud
    chunk(e.x, 0.7, e.z, 0xf4efe2, MOBILE ? 4 : 6, 4.5, 0.09); // bone splinters
    spark(e.x, 0.8, e.z, 0xffffff, { s: 2.2, life: 0.09, drag: 0 }); spark(e.x, 0.75, e.z, 0x9a5cff, { s: 1.4, life: 0.25, drag: 0 });
    addRing(e.x, e.z, 0.2, 1.3, 0.2, 0xfff6e8); addRing(e.x, e.z, 0.2, 0.8, 0.3, 0xa070ff);
    const l = Math.hypot(vx, vz) || 1, fx = vx / l, fz = vz / l;
    for (let q = fxN(8); q > 0; q--) { const v = 4 + Math.random() * 5, s = (Math.random() - 0.5) * 5; spark(e.x, 0.8, e.z, Math.random() < 0.6 ? 0xffffff : 0xfff0d0, { vx: fx * v - fz * s, vz: fz * v + fx * s, vy: 1 + Math.random() * 2, s: 0.22, life: 0.22, drag: 4 }); }
    for (let q = fxN(5); q > 0; q--) spark(e.x + (Math.random() - 0.5) * 0.6, 0.55, e.z + (Math.random() - 0.5) * 0.6, 0xbfb6a6, { vy: 0.6 + Math.random() * 0.8, s: 0.6 + Math.random() * 0.4, life: 0.55, drag: 2.5, spread: 2 }); // bone dust
    // (no global hit-stop on bone pierces: it stuttered)
    if (G.time - boomThud > 0.07) { boomThud = G.time; sfx('thud'); addShake(0.07); }
  }
}
let boomThud = -9;
// afterimages: the bone at BOOM_GH earlier points of its loop, fading violet: a spin blur (no history kept, boomPos is a pure
// function of u). Plus a swept whoosh: a ribbon of soft glow sparks along the path and ivory streaks off both knobs.
const BOOM_GH = 5, BOOM_DRAW = 1.25; // the bone draws 25% bigger than before (the hit reach is unchanged: 1.8 x b.s)
const boomGhost = new THREE.InstancedMesh(boomGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }), BOOM_N * BOOM_GH);
boomGhost.material.onBeforeCompile = boomMesh.material.onBeforeCompile;
for (let i = 0; i < BOOM_N * BOOM_GH; i++) boomGhost.setColorAt(i, tmpC.set(0xb890ff).multiplyScalar([0.8, 0.6, 0.42, 0.28, 0.16][i % BOOM_GH]));
boomGhost.instanceMatrix.setUsage(THREE.DynamicDrawUsage); boomGhost.frustumCulled = false; boomGhost.count = 0; scene.add(boomGhost);
function updateBoomerangs(dt) {
  let n = 0;
  for (const b of booms) {
    if (!b.on) continue;
    b.t += dt;
    if (b.t >= b.dur || !player.alive) {
      if (player.alive) { // the catch: Pip snaps it out of the air
        addRing(player.x, player.z, 0.2, 1.7, 0.25, 0xfff6e8); addRing(player.x, player.z, 0.2, 1.1, 0.32, 0xa070ff);
        spark(player.x, 0.95, player.z, 0xffffff, { s: 2, life: 0.1, drag: 0 });
        burst(player.x, 0.9, player.z, 0xc9a8ff, fxN(12), 4, 0.35, 0.3); chunk(player.x, 0.9, player.z, 0xf4efe2, MOBILE ? 2 : 4, 3, 0.07);
        addShake(0.1); sfx('clink'); sfx('thud');
      }
      b.on = false; b.out.clear(); b.back.clear(); continue;
    }
    if (b.hunt) { // hunting bone: flies foe to foe through the whole tour, then home to Pip (user 11-15: "make it hit all")
      let tg = null;
      while (!b.home && b.ti < b.tour.length && (b.tour[b.ti].dead || b.tour[b.ti].hidden)) b.ti++;
      if (!b.home && b.ti < b.tour.length && b.t < 2) tg = b.tour[b.ti]; else b.home = true; // heads home after 2 s at most (user 11-15)
      const tx = b.home ? player.x : tg.x, tz = b.home ? player.z : tg.z, ddx = tx - b.x, ddz = tz - b.z, dd = Math.hypot(ddx, ddz) || 1;
      // it CURVES (user 11-15): a heading that turns toward the target at a limited rate, so it swings round in arcs like a boomerang
      if (b.hd == null) b.hd = b.a + b.dir * 1.1; // thrown out to the side first
      let da = Math.atan2(ddz, ddx) - b.hd; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
      if (b.home) b.homeT = (b.homeT || 0) + dt;
      // close in, or homeward for 0.35 s: straight at it - it can never orbit its foe or Pip (user 11-15: "make sure they go home")
      b.hd += dd < 1.2 || (b.home && b.homeT > 0.35) ? da : clamp(da, -1, 1) * Math.min(1, dt * (b.home ? 14 : dd < 2.5 ? 12 : 6));
      const v = Math.min(dd + 0.2, (13 + (b.home ? b.t * 4 : 0)) * dt);
      if (b.home && dd < 0.6 || b.t > 7) b.t = b.dur = 1e-9; // caught (the catch fx run next frame)
      if (!b.home && (dd < 0.45 || b.out.has(tg))) b.ti++; // hit it (or reached it): on to the next
      boomP.set(b.x + Math.cos(b.hd) * v, 0, b.z + Math.sin(b.hd) * v);
      (b.hist || (b.hist = [])).unshift(b.x, b.z); if (b.hist.length > 2 * BOOM_GH + 2) b.hist.length = 2 * BOOM_GH + 2;
    } else { const u = b.t / b.dur; boomPos(b, u); }
    const u = b.hunt ? 0 : b.t / b.dur;
    const x = boomP.x, z = boomP.z, dx = x - b.x, dz = z - b.z, d = Math.hypot(dx, dz), steps = Math.min(6, Math.ceil(d / 0.35));
    for (let k = 1; k <= steps; k++) boomHit(b, b.x + dx * k / steps, b.z + dz * k / steps, dx, dz); // no gaps at low fps
    b.x = x; b.z = z;
    const S = b.s * BOOM_DRAW;
    for (let k = fxN(2); k > 0; k--) { const f = Math.random(); spark(x - dx * f, 0.95, z - dz * f, 0x8a4cff, { ...BOOM_TRAIL, s: 1.5 * S }); } // the whoosh ribbon
    b.spin += dt * 22 * b.dir;
    const tc = Math.cos(b.spin) * 0.85 * S, ts = Math.sin(b.spin) * 0.85 * S; // both knobs throw off ivory streaks: the spin shows as a spiral
    if (fxP(0.95)) { spark(x + tc, 0.95, z - ts, 0xfff8ec, { s: 0.75 * S, life: 0.22, drag: 0 }); spark(x - tc, 0.95, z + ts, 0xfff8ec, { s: 0.75 * S, life: 0.22, drag: 0 }); }
    boomE.set(0.3, b.spin, 0); boomQ.setFromEuler(boomE); boomS.setScalar(S); boomP.set(x, 0.95 + Math.sin(b.t * 9) * 0.05, z);
    boomMesh.setMatrixAt(n, bMat.compose(boomP, boomQ, boomS));
    for (let k = 1; k <= BOOM_GH; k++) {
      if (b.hunt) { const h = b.hist, j = Math.min(h.length - 2, k * 2 - 2); boomP.set(h[j] ?? x, 0.95, h[j + 1] ?? z); } else { boomPos(b, Math.max(0, u - k * 0.009)); boomP.y = 0.95; }
      boomE.set(0.3, b.spin - b.dir * k * 0.3, 0); boomQ.setFromEuler(boomE); boomS.setScalar(S * (1 + k * 0.04));
      boomGhost.setMatrixAt(n * BOOM_GH + k - 1, bMat.compose(boomP, boomQ, boomS));
    }
    n++;
  }
  if (n || boomMesh.count) { boomMesh.count = n; boomMesh.instanceMatrix.needsUpdate = true; boomGhost.count = n * BOOM_GH; boomGhost.instanceMatrix.needsUpdate = true; }
}
// ---------- Gloop Slam (Pip's boss.gloop, King Gloop's leap-slam) ----------
// user 11-15: "not clear ... just explode then have lots of fire", then "still shit". It went through explode(), whose look is a
// fireball: yellow sparks, dark smoke, a black scorch mark and the orange fx light. Now a HUGE glossy green goo blob drops onto the
// target (a ring marks the spot, its shadow grows), splats with a big squash and a jiggle, a slime shockwave rolls out, a thick
// crown of goo splashes up, goo globs are lobbed out on high arcs (like the golem rock lob) and splat where they land, the
// damaging ring of globs hops out along the floor, and a glossy venom puddle (looks only, no damage) is left with green stains.
// Same hit as before: 2.2 x area with explode's falloff and knock-back, plus the ring of globs (10 + 2/Lv, 35% damage each,
// same speed, life and path: they only hop now). The blob lands GLOOP_FALL after the cast.
// Pooled: GLOOP_N blobs and GOB_N lobbed globs (one instanced draw + outline) made once.
const GLOOP_N = 3, GLOOP_FALL = 0.34, GLOOP_SQ = 0.6;
const gloopGeo = (() => { // a lumpy blob, a little flat underneath
  const g = new THREE.SphereGeometry(0.5, 22, 16), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i), k = 1 + 0.07 * Math.sin(x * 11 + 1) * Math.sin(z * 9) + 0.05 * Math.sin(y * 13); p.setXYZ(i, x * k, y < -0.3 ? -0.3 + (y + 0.3) * 0.4 : y * k, z * k); }
  g.computeVertexNormals(); return g;
})();
const gloopMat = new THREE.MeshLambertMaterial({ color: 0x6af050, emissive: 0x0f520a }), gloopGloss = new THREE.MeshBasicMaterial({ color: 0xf2ffe8 });
const gloopHlGeo = new THREE.SphereGeometry(0.16, 10, 8);
const gloopShell = new THREE.MeshBasicMaterial({ color: 0x7dff6a, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false });
const gloopEdge = new THREE.MeshBasicMaterial({ color: 0x0a2a06, side: THREE.BackSide }); // a dark outline so it pops on any floor
const gloops = Array.from({ length: GLOOP_N }, () => {
  const g = new THREE.Group(); g.add(new THREE.Mesh(gloopGeo, gloopMat));
  const ed = new THREE.Mesh(gloopGeo, gloopEdge); ed.scale.setScalar(1.07); g.add(ed);
  const sh = new THREE.Mesh(gloopGeo, gloopShell); sh.scale.setScalar(1.2); g.add(sh);
  const hl = new THREE.Mesh(gloopHlGeo, gloopGloss); hl.position.set(-0.16, 0.25, 0.24); hl.scale.set(1.2, 0.7, 0.9); g.add(hl); // the gloss highlight
  g.visible = false; scene.add(g);
  return { on: false, g, t: 0, x: 0, z: 0, R: 2, s0: 1, dmg: 0, els: null, col: 0, n: 0, hit: false, sh: null, gl: null };
});
// lobbed goo globs (looks only): fly from the splat on an arc of height h over T s, land with a small splash and a stain
const GOB_N = MOBILE ? 14 : 24;
const gobMesh = new THREE.InstancedMesh(gloopGeo, gloopMat, GOB_N), gobEdge = new THREE.InstancedMesh(gloopGeo, gloopEdge, GOB_N);
for (const m of [gobMesh, gobEdge]) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; scene.add(m); }
const gobs = Array.from({ length: GOB_N }, () => ({ on: false, t: 0, T: 0.6, x0: 0, z0: 0, x1: 0, z1: 0, h: 2, s: 0.4 }));
const gobM = new THREE.Matrix4(), gobV = new THREE.Vector3(), gobS = new THREE.Vector3(), gobQ = new THREE.Quaternion();
function gobLob(x0, z0, x1, z1, h, T, s) { const o = gobs.find((q) => !q.on); if (o) Object.assign(o, { on: true, t: 0, T, x0, z0, x1, z1, h, s }); }
function updateGobs(dt) {
  let n = 0;
  for (const o of gobs) {
    if (!o.on) continue;
    o.t += dt; const u = Math.min(1, o.t / o.T), x = lerp(o.x0, o.x1, u), z = lerp(o.z0, o.z1, u), y = 0.2 + o.h * 4 * u * (1 - u);
    if (u >= 1) { // lands: a little splat
      o.on = false; splat(x, z, 0x2a8a1e, o.s * 1.6, 0.85); addRing(x, z, 0.1, o.s * 1.8, 0.22, 0x7dff6a);
      for (let k = fxN(5); k > 0; k--) { const a = Math.random() * 6.2832; spark(x, 0.15, z, 0x9dff7a, { vx: Math.cos(a) * 2.2, vz: Math.sin(a) * 2.2, vy: 2 + Math.random() * 2, s: 0.18, life: 0.35, drag: 1, grav: -12 }); }
      continue;
    }
    const st = 1 + 0.35 * Math.abs(1 - 2 * u); // stretched while it is fast
    gobMesh.setMatrixAt(n, gobM.compose(gobV.set(x, y, z), gobQ, gobS.set(o.s / st, o.s * st, o.s / st)));
    gobEdge.setMatrixAt(n, gobM.compose(gobV, gobQ, gobS.multiplyScalar(1.12))); n++;
    if (fxP(0.4)) spark(x, y, z, 0x7dff6a, { s: 0.3, life: 0.2, drag: 0 }); // drips off it
  }
  if (n || gobMesh.count) { gobMesh.count = gobEdge.count = n; gobMesh.instanceMatrix.needsUpdate = gobEdge.instanceMatrix.needsUpdate = true; }
}
// the damaging ring globs (projectiles, kind 'slime', p.goo): they hop along their path instead of gliding (hits unchanged)
function gooHop(p) {
  const u = 1 - p.life / p.maxLife, ph = u * 2.2, hop = Math.abs(Math.sin(ph * Math.PI)), y = 0.3 + 1.1 * hop * (1 - u * 0.4);
  p.mesh.position.y = y; p.glow.position.y = y;
  const f = Math.floor(ph); if (f !== p.hopN) { p.hopN = f; if (f > 0) { if (fxP(0.3)) splat(p.x, p.z, 0x2a8a1e, 0.45, 0.75); spark(p.x, 0.15, p.z, 0xb8ff90, { s: 0.9, life: 0.15, drag: 0 }); } } // touch-down
}
function gooPop(p) { splat(p.x, p.z, 0x2a8a1e, 0.55, 0.8); for (let k = fxN(4); k > 0; k--) { const a = Math.random() * 6.2832; spark(p.x, 0.25, p.z, 0x9dff7a, { vx: Math.cos(a) * 2.5, vz: Math.sin(a) * 2.5, vy: 2.5, s: 0.2, life: 0.35, drag: 1, grav: -12 }); } }
function addGloop(x, z, R, dmg, els, col, n) {
  const b = gloops.find((q) => !q.on); if (!b) return;
  Object.assign(b, { on: true, t: 0, x, z, R, s0: 1.15 * R, dmg, els, col, n, hit: false });
  b.sh = makeShadow(0.3); b.sh.position.set(x, 0.04, z); b.gl = makeGlowAt(x, 0.3, z, 0x7dff6a, 1, 0.25);
  addRing(x, z, R, R * 0.9, GLOOP_FALL, 0x7dff6a); // where it will land
  b.g.visible = true; b.g.position.set(x, 9, z); b.g.scale.setScalar(0.01);
}
function gloopSplat(b) { // IMPACT: the same hit explode() made, in goo
  const { x, z, R, col } = b; let hits = 0;
  for (const e of [...enemies]) {
    const d = Math.hypot(e.x - x, e.z - z);
    if (d < R + e.r) { hurtEnemy(e, b.dmg * (1 - 0.35 * d / (R + e.r)), e.x - x, e.z - z, 6, col, b.els); hits++; }
  }
  for (const pot of [...pots]) if (Math.hypot(pot.x - x, pot.z - z) < R) breakPot(pot);
  for (let k = 0; k < b.n; k++) addProj({ kind: 'slime', x, z, y: 0.6, a: k / b.n * Math.PI * 2, speed: 7, dmg: b.dmg * 0.35, r: 0.25, color: col, size: 0.8, life: 0.7, els: b.els, scale: 1.5, goo: true, hopN: 0 });
  addRing(x, z, 0.3, R * 1.1, 0.35, 0x7dff6a, true); addRing(x, z, 0.2, R * 0.7, 0.4, 0xe0ffd0, true); later(0.1, () => addRing(x, z, 0.5, R * 1.35, 0.5, 0x2fbf2a)); // the slime shockwave
  spark(x, 0.6, z, 0xeaffd8, { s: R * 1.6, life: 0.12, drag: 0 });
  for (let k = fxN(40); k > 0; k--) { // thick goo thrown out and up, falling back
    const a = Math.random() * 6.2832, v = 2.5 + Math.random() * 6, c = Math.random();
    spark(x + Math.cos(a) * 0.6, 0.35, z + Math.sin(a) * 0.6, c < 0.45 ? 0x7dff6a : c < 0.8 ? 0x3cdc3a : 0xd8ffc0, { vx: Math.cos(a) * v, vz: Math.sin(a) * v, vy: 3 + Math.random() * 5, s: 0.28 + Math.random() * 0.35, life: 0.55 + Math.random() * 0.35, drag: 1.2, grav: -15 });
  }
  for (let k = 0; k < 18; k++) { const a = k / 18 * 6.2832; spark(x + Math.cos(a) * R * 0.5, 0.2, z + Math.sin(a) * R * 0.5, k % 2 ? 0xb8ff90 : 0x5ee84a, { vx: Math.cos(a) * 1.5, vz: Math.sin(a) * 1.5, vy: 6.5, s: 0.45, life: 0.5, drag: 1, grav: -16 }); } // the splash crown
  const nl = MOBILE ? 6 : 9; // goo globs lobbed out on high arcs (like the golem rock lob), splatting where they land
  for (let k = 0; k < nl; k++) { const a = (k + Math.random() * 0.6) / nl * 6.2832, d = R * (0.9 + Math.random() * 0.7); gobLob(x, z, x + Math.cos(a) * d, z + Math.sin(a) * d, 1.6 + Math.random() * 1.6, 0.45 + Math.random() * 0.3, 0.32 + Math.random() * 0.2); }
  splat(x, z, 0x2a8a1e, R * 1.2, 0.9); for (let k = 0; k < 5; k++) { const a = Math.random() * 6.2832, d = R * (0.5 + Math.random() * 0.5); splat(x + Math.cos(a) * d, z + Math.sin(a) * d, 0x2a8a1e, 0.35 + Math.random() * 0.35, 0.8); }
  fires.push({ x, z, r: R * 0.6, life: 2.6, dmg: 0, tick: 1e9, kind: 'venom', age: 0, rot: Math.random() * 6.28, spin: 0.5, g0: 0.35, glow: makeGlowAt(x, 0.2, z, 0x5fff4a, R * 1.4, 0.35) }); // the puddle (no damage: tick never comes)
  fxLight.position.set(x, 1.4, z); fxLight.color.set(0x7dff6a); fxLight.intensity = 55; later(0.35, () => fxLight.color.set(0xffa040));
  addText(x, 1.8, z, 'SPLAT!', '#9dff7a', 1.4);
  addShake(0.5); sfx('slam'); sfx('splat'); sfx('land');
  if (b.sh) { scene.remove(b.sh); b.sh = null; }
}
function updateGloops(dt) {
  updateGobs(dt);
  for (const b of gloops) {
    if (!b.on) continue;
    b.t += dt;
    const s0 = b.s0, g = b.g;
    if (b.t < GLOOP_FALL) { // dropping: stretched tall, its shadow growing under it, goo streaming off the top
      const u = b.t / GLOOP_FALL;
      g.position.set(b.x, 0.4 * s0 + 9 * (1 - u * u), b.z); g.scale.set(s0 * 0.78, s0 * 1.4, s0 * 0.78);
      b.sh.scale.set(s0 * (0.3 + 1.1 * u), 1, s0 * (0.3 + 1.1 * u) * 0.8);
      b.gl.scale.setScalar(b.R * (0.6 + 0.8 * u));
      for (let k = fxN(2); k > 0; k--) spark(b.x + (Math.random() - 0.5) * s0 * 0.5, g.position.y + s0 * 0.6, b.z, 0x9dff7a, { vy: 4, s: 0.5, life: 0.2, drag: 0 });
      continue;
    }
    if (!b.hit) { b.hit = true; gloopSplat(b); }
    const v = Math.min(1, (b.t - GLOOP_FALL) / GLOOP_SQ), j = Math.sin(v * Math.PI * 3) * (1 - v); // squash, jiggle, melt into the puddle
    const sy = s0 * Math.max(0.03, lerp(0.45, 0.03, v * v) * (1 + 0.5 * j)), sx = s0 * lerp(1.45, 1.7, v) * (1 - 0.14 * j);
    g.scale.set(sx, sy, sx); g.position.set(b.x, sy * 0.3, b.z);
    b.gl.scale.setScalar(b.R * 1.4 * (1 - v));
    if (v >= 1) { b.on = false; g.visible = false; killGlow(b.gl); b.gl = null; }
  }
}
function resetGloops() { for (const b of gloops) { b.on = false; b.g.visible = false; if (b.sh) scene.remove(b.sh); if (b.gl) killGlow(b.gl); b.sh = b.gl = null; } for (const o of gobs) o.on = false; gobMesh.count = gobEdge.count = 0; }
// ---------- Phoenix (Pip's fire.ring, replaced Fire Ring) ----------
// A bird made of flame launches from Pip at the foe, dives straight through the crowd, banks round in a tight U-turn behind
// it and swoops back through once more, homing on Pip, where it bursts into embers. It pierces: each foe is hit once going
// out and once coming back, and fire sets it burning. Wings flap (they roll about the body), a trail of embers streams from
// the body and the wing tips. Lv 3: a second bird mirrored a little off the line. Lv 5: bigger, faster, burns hotter.
// Pooled: PHX_N birds in three instanced draws (body, wings, tail) sharing one additive vertex-coloured material; a cast only
// takes a free slot and a glow placeholder. Local frame of the meshes: +X = forward, +Z = the right wing's span, Y = up.
const PHX_N = 6;
function phxGeo(parts) { // merge geometries into one non-indexed geometry with a 'color' per vertex (colour fn of x, y, z)
  const pos = [], col = [];
  for (const [g, cf] of parts) {
    const n = g.index ? g.toNonIndexed() : g, p = n.attributes.position.array;
    for (let i = 0; i < p.length; i += 3) { pos.push(p[i], p[i + 1], p[i + 2]); col.push(...cf(p[i], p[i + 1], p[i + 2])); }
    if (n !== g) n.dispose(); g.dispose();
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  return g;
}
const phxMix = (a, b, t) => { t = Math.max(0, Math.min(1, t)); return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; };
const PHX_WHITE = [1, 0.9, 0.55], PHX_GOLD = [1, 0.62, 0.12], PHX_ORANGE = [0.95, 0.32, 0.03], PHX_RED = [0.75, 0.08, 0.01]; // additive: kept off white so it reads orange on light floors
const phxFlat = (pts) => { const s = new THREE.Shape(); s.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) s.lineTo(pts[i][0], pts[i][1]); return new THREE.ShapeGeometry(s).rotateX(Math.PI / 2); }; // 2D (x, span) -> XZ
const phxBodyGeo = phxGeo([
  [new THREE.IcosahedronGeometry(1, 1).scale(0.34, 0.13, 0.15), (x) => phxMix(PHX_ORANGE, PHX_WHITE, (x + 0.34) / 0.68)],
  [new THREE.IcosahedronGeometry(0.12, 1).translate(0.36, 0.05, 0), () => PHX_WHITE], // head
  [new THREE.ConeGeometry(0.05, 0.16, 4).rotateZ(-Math.PI / 2).translate(0.53, 0.04, 0), () => PHX_GOLD], // beak
  ...[-0.05, 0.05].map((z) => [new THREE.ConeGeometry(0.035, 0.26, 4).rotateZ(0.93).translate(0.22, 0.2, z), () => PHX_ORANGE]), // crest flames
]);
const phxWingGeo = phxGeo([[phxFlat([[0.17, 0], [0.24, 0.25], [0.2, 0.55], [0.04, 0.86], [-0.26, 1.12], [-0.34, 0.96], [-0.2, 0.9], [-0.4, 0.77], [-0.24, 0.68],
  [-0.42, 0.54], [-0.24, 0.47], [-0.38, 0.32], [-0.18, 0.24], [-0.24, 0.06], [-0.13, 0]]),
  (x, y, z) => phxMix(phxMix([1, 0.85, 0.35], PHX_ORANGE, z / 0.5), PHX_RED, (z - 0.5) / 0.6)]]);
const phxTailGeo = phxGeo([-0.38, 0, 0.38].map((ya) => [phxFlat([[0.04, 0], [-0.3, 0.09], [-0.9, 0.02], [-1.05, 0.12], [-0.98, -0.02], [-0.3, -0.09]]).rotateY(ya).translate(-0.24, 0, 0),
  (x) => phxMix(PHX_GOLD, PHX_RED, (-x - 0.3) / 0.9)]));
const phxMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
phxMat.onBeforeCompile = boomMesh.material.onBeforeCompile; // pulled toward the camera like the bone: flies over the foes' sprites
// wings and tail blend normally (additive alone washed out to pale yellow on light floors); the body core, glow and embers add light
const phxFeatherMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.92, depthWrite: false, side: THREE.DoubleSide });
phxFeatherMat.onBeforeCompile = boomMesh.material.onBeforeCompile;
const phxBody = new THREE.InstancedMesh(phxBodyGeo, phxMat, PHX_N), phxWing = new THREE.InstancedMesh(phxWingGeo, phxFeatherMat, PHX_N * 2), phxTail = new THREE.InstancedMesh(phxTailGeo, phxFeatherMat, PHX_N);
for (const m of [phxTail, phxWing, phxBody]) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; m.renderOrder = m === phxBody ? 4 : 3; scene.add(m); }
const phxs = Array.from({ length: PHX_N }, () => ({ on: false, t: 0, x: 0, z: 0, a: 0, v: 10, phase: 0, run: 0, L: 5, side: 1, rot: 0, s: 1, dmg: 0, els: null, hot: false, flap: 0, bank: 0, emit: 0, glow: null, out: new Set(), back: new Set() }));
const phxE = new THREE.Euler(), PHX_R = 0.75; // U-turn radius (times the bird's scale)
function addPhoenix(x, z, a, L, v, side, s, dmg, els, hot) {
  const b = phxs.find((q) => !q.on); if (!b) return;
  Object.assign(b, { on: true, t: 0, x, z, a, v, phase: 0, run: 0, L, side, rot: 0, s, dmg, els, hot, flap: Math.random() * 6.283, bank: 0, emit: 0 });
  b.out.clear(); b.back.clear();
  b.glow = makeGlow(0xff5a10, 2.2 * s, 0.5);
  burst(x, 0.9, z, 0xffb040, 8, 3, 0.35, 0.3);
}
function phxEnd(b, puff) {
  b.on = false; killGlow(b.glow); b.glow = null; b.out.clear(); b.back.clear();
  if (!puff) return;
  spark(b.x, 1.05, b.z, 0xfff0c0, { s: 1.4 * b.s, life: 0.18, drag: 0 });
  burst(b.x, 1.05, b.z, 0xffb040, 12, 4, 0.4, 0.5); burst(b.x, 1.05, b.z, 0xff4a10, 8, 3, 0.35, 0.6);
}
function phxHit(b, x, z, vx, vz) {
  const set = b.phase < 2 ? b.out : b.back, hr = 0.9 * b.s;
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i]; if (!e || e.dead || set.has(e)) continue;
    const dx = e.x - x, dz = e.z - z, rr2 = hr + e.r; if (dx * dx + dz * dz > rr2 * rr2) continue;
    set.add(e); hurtEnemy(e, b.dmg, vx, vz, 2, 0xff8a20, b.els); // fire: hurtEnemy -> applyStatus sets it burning
    if (b.hot && !e.dead && e.burn > 0) { e.burn = Math.max(e.burn, 5); e.burnDps = Math.max(e.burnDps || 0, b.dmg * 0.45 * player.der.status); } // Lv 5: hotter, longer
    burst(e.x, 0.8, e.z, 0xffa030, 5, 4, 0.3, 0.35);
  }
}
function updatePhoenixes(dt) {
  let nb = 0, nw = 0;
  for (const b of phxs) {
    if (!b.on) continue;
    b.t += dt;
    if (!player.alive || b.t > 3.5) { phxEnd(b, player.alive); continue; }
    let v = b.v, bank = 0;
    if (b.phase === 0) { b.run += v * dt; if (b.run >= b.L) b.phase = 1; } // straight out through the crowd
    else if (b.phase === 1) { // bank round behind it
      v *= 0.8; const w = v / (PHX_R * Math.sqrt(b.s)) * dt; b.a += w * b.side; b.rot += w; bank = b.side;
      if (b.rot >= Math.PI * 0.9) b.phase = 2;
    } else { // swoop home to Pip, with a turn limit so it curves in rather than snapping
      const dx = player.x - b.x, dz = player.z - b.z;
      if (dx * dx + dz * dz < 0.55) { phxEnd(b, true); continue; }
      let d = Math.atan2(dz, dx) - b.a; d = Math.atan2(Math.sin(d), Math.cos(d));
      const mx = 7 * dt; b.a += Math.max(-mx, Math.min(mx, d)); bank = Math.max(-1, Math.min(1, d * 2));
    }
    b.bank += (bank - b.bank) * Math.min(1, dt * 10);
    const ca = Math.cos(b.a), sa = Math.sin(b.a), sx = ca * v * dt, sz = sa * v * dt, steps = Math.min(6, Math.ceil(Math.hypot(sx, sz) / 0.35));
    for (let k = 1; k <= steps; k++) phxHit(b, b.x + sx * k / steps, b.z + sz * k / steps, ca, sa); // no gaps at low fps
    b.x += sx; b.z += sz;
    // look: wings flap (glide wide through the turn), body bobs against the beat, grows in at launch
    b.flap += dt * (b.phase === 1 ? 6 : 15);
    const phi = b.phase === 1 ? 0.12 + 0.1 * Math.sin(b.flap) : 0.2 + 0.62 * Math.sin(b.flap), s = b.s * Math.min(1, 0.35 + b.t * 6);
    const y = Math.min(1.15, 0.85 + b.t * 3) - 0.07 * Math.sin(b.flap), roll = -b.bank * 0.5;
    boomP.set(b.x, y, b.z); boomS.setScalar(s);
    phxBody.setMatrixAt(nb, bMat.compose(boomP, boomQ.setFromEuler(phxE.set(roll, -b.a, 0, 'YXZ')), boomS));
    phxTail.setMatrixAt(nb++, bMat.compose(boomP, boomQ.setFromEuler(phxE.set(roll, -b.a + 0.15 * Math.sin(b.flap * 0.5), 0, 'YXZ')), boomS));
    phxWing.setMatrixAt(nw++, bMat.compose(boomP, boomQ.setFromEuler(phxE.set(roll - phi, -b.a, 0, 'YXZ')), boomS));
    phxWing.setMatrixAt(nw++, bMat.compose(boomP, boomQ.setFromEuler(phxE.set(roll + phi + Math.PI, -b.a, 0, 'YXZ')), boomS));
    b.glow.position.set(b.x, y, b.z);
    // fiery trail: embers from behind the body and from both wing tips, drifting up
    const ne = gfxEmit(b, 'emit', 75, dt), span = 1.05 * s * Math.cos(phi), ty = y + 1.05 * s * Math.sin(phi);
    for (let k = 0; k < ne; k++) {
      const q = k % 3;
      if (q === 0) spark(b.x - ca * 0.35 * s, y, b.z - sa * 0.35 * s, Math.random() < 0.5 ? 0xffd060 : 0xff8a20, { vy: 0.6, s: 0.55 * s, life: 0.38, drag: 2, spread: 0.6 });
      else { const w = q === 1 ? 1 : -1; spark(b.x - sa * span * w - ca * 0.2 * s, ty, b.z + ca * span * w - sa * 0.2 * s, Math.random() < 0.5 ? 0xff5a10 : 0xffa030, { vy: 1.2, s: 0.32 * s, life: 0.42, drag: 2, spread: 1 }); }
    }
  }
  for (const [m, n] of [[phxBody, nb], [phxTail, nb], [phxWing, nw]]) if (n || m.count) { m.count = n; m.instanceMatrix.needsUpdate = true; }
}
// ---------- Angel Swords (holy.radiance, replaced Radiance: the user dislikes blasts around Pip) ----------
// Golden-white swords materialize high over up to N foes (distinct foes first, extras double up on the toughest), hang a
// moment with a shimmer and a faint mark on the floor, then drop like guillotines, slam in with a flash and hit a small
// area, stay stuck in the floor and fade. Pooled: ANGEL_N slots, three instanced draws (sword, glow, floor mark), one
// material each made at load; per-instance fade is an attribute, so nothing is created or recompiled per cast.
const ANGEL_N = 24, ANGEL_H = 3.8, ANGEL_DROP = 0.17, ANGEL_STUCK = 0.4, ANGEL_FADE = 0.25;
const angelGeo = (() => { // tip at the origin pointing down, hilt up: diamond blade, crossguard with knobs, grip, pommel
  const parts = [
    [new THREE.CylinderGeometry(0.15, 0.0, 1.55, 4).scale(1, 1, 0.3).translate(0, 0.775, 0), 0xfffbea],
    [new THREE.BoxGeometry(0.7, 0.1, 0.12).translate(0, 1.6, 0), 0xffd24a],
    [new THREE.IcosahedronGeometry(0.07, 0).translate(-0.37, 1.6, 0), 0xffe08a],
    [new THREE.IcosahedronGeometry(0.07, 0).translate(0.37, 1.6, 0), 0xffe08a],
    [new THREE.CylinderGeometry(0.045, 0.05, 0.36, 6).translate(0, 1.83, 0), 0x9a6a2e],
    [new THREE.IcosahedronGeometry(0.085, 0).translate(0, 2.06, 0), 0xffc640],
  ];
  const pos = [], nor = [], colr = [], c = new THREE.Color();
  for (const [g, hex] of parts) {
    const n = g.index ? g.toNonIndexed() : g; c.set(hex);
    pos.push(...n.attributes.position.array); nor.push(...n.attributes.normal.array);
    for (let i = 0; i < n.attributes.position.count; i++) colr.push(c.r, c.g, c.b);
    g.dispose(); if (n !== g) n.dispose();
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(colr, 3));
  g.setAttribute('aFade', new THREE.InstancedBufferAttribute(new Float32Array(ANGEL_N).fill(1), 1).setUsage(THREE.DynamicDrawUsage));
  return g;
})();
const angelMesh = new THREE.InstancedMesh(angelGeo, new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0xa88a40, transparent: true }), ANGEL_N);
// pulled toward the camera so a sword in front of a foe draws over its sprite; the part below the floor is cut away
// (so a stuck sword reads as buried), and aFade fades each sword on its own
angelMesh.material.onBeforeCompile = (s) => {
  s.vertexShader = 'attribute float aFade;\nvarying float vFade;\nvarying float vWY;\n' + s.vertexShader.replace('#include <project_vertex>',
    '#include <project_vertex>\n  vFade = aFade; vWY = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).y;\n  mvPosition.z += 0.9; gl_Position = projectionMatrix * mvPosition;');
  s.fragmentShader = 'varying float vFade;\nvarying float vWY;\n' + s.fragmentShader.replace('#include <dithering_fragment>', '#include <dithering_fragment>\n  if (vWY < 0.0) discard;\n  gl_FragColor.a *= vFade;');
};
angelMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); angelMesh.frustumCulled = false; angelMesh.count = 0; scene.add(angelMesh);
const angelGlow = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: glowTex, color: 0xffe9a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }), ANGEL_N);
angelGlow.material.onBeforeCompile = (s) => { s.vertexShader = s.vertexShader.replace('#include <project_vertex>', '#include <project_vertex>\n  mvPosition.z += 1.0; gl_Position = projectionMatrix * mvPosition;'); };
const angelMark = new THREE.InstancedMesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: markTex, color: 0xffe9a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }), ANGEL_N);
for (const m of [angelGlow, angelMark]) { // instanceColor set up front so the shader is built with it once; dimming it fades the additive glow
  for (let i = 0; i < ANGEL_N; i++) m.setColorAt(i, new THREE.Color(0));
  m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.instanceColor.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; scene.add(m);
}
angelGlow.renderOrder = 3; angelMark.renderOrder = -1;
const angels = Array.from({ length: ANGEL_N }, () => ({ on: false, t: 0, hang: 0.3, e: null, x: 0, z: 0, ox: 0, oz: 0, dmg: 0, aoe: 1, s: 1, els: null, col: 0, sway: 0, hitT: -1, cast: 0 }));
const angelFoes = [], angelP = new THREE.Vector3(), angelS = new THREE.Vector3(), angelQ = new THREE.Quaternion(), angelE = new THREE.Euler(), angelC = new THREE.Color();
const ANGEL_SPK = { vy: 2.4, s: 0.45, life: 0.35, drag: 2, spread: 1.6 };
let angelCast = 0;
function castAngelSwords(def, target, n, dmg, aoe, s, col, els) {
  angelFoes.length = 0;
  for (const e of enemies) if (!e.dead && !e.hidden && e.spawn >= 0.5 && Math.hypot(e.x - player.x, e.z - player.z) < def.range + 2) angelFoes.push(e);
  if (!angelFoes.length) angelFoes.push(target);
  angelFoes.sort((a, b) => b.hp - a.hp); // distinct foes, toughest first; extra swords double up from the toughest down
  const L = angelFoes.length; angelCast++;
  for (let k = 0; k < n; k++) {
    const w = angels.find((q) => !q.on); if (!w) break;
    const dup = k >= L, e = angelFoes[dup ? (k - L) % L : k], a = Math.random() * 6.283, r = dup ? 0.45 + 0.1 * Math.floor((k - L) / L) : 0;
    Object.assign(w, { on: true, t: 0, hang: 0.3 + k * 0.05, e, x: e.x, z: e.z, ox: Math.cos(a) * r, oz: Math.sin(a) * r * 0.6, dmg, aoe, s, els, col, sway: Math.random() * 6.283, hitT: -1, cast: angelCast });
  }
  angelFoes.length = 0;
  sfx('orb');
}
function angelImpact(w) {
  const x = w.x, z = w.z, big = w.s > 1.6;
  addRing(x, z, 0.2, w.aoe + 0.5, 0.3, 0xffffff); addRing(x, z, 0.3, w.aoe, 0.45, 0xffe9a0);
  burst(x, 0.3, z, 0xfff3c0, Math.round((big ? 16 : 11) * (MOBILE ? 0.6 : 1)), 5, 0.45, 0.4);
  for (let k = 0; k < (MOBILE ? 3 : 5); k++) spark(x, 0.2, z, k % 2 ? 0xffffff : 0xffd870, ANGEL_SPK);
  chunk(x, 0.15, z, 0x6a5a40, big ? 4 : 3, 3.5, 0.07);
  fxLight.color.set(0xfff0b0); fxLight.position.set(x, 1.8, z); fxLight.intensity = big ? 55 : 40;
  if (G.time - (G.skyFlashT ?? -9) > 0.8) { G.skyFlashT = G.time; flash(0.05); }
  addShake(big ? 0.09 : 0.06); sfx('slam');
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i]; if (!e || e.dead) continue;
    const dx = e.x - x, dz = e.z - z, rr2 = w.aoe + e.r; if (dx * dx + dz * dz > rr2 * rr2) continue;
    hurtEnemy(e, w.dmg, dx, dz, 2.5, w.col, w.els);
  }
  for (const pot of [...pots]) if (Math.hypot(pot.x - x, pot.z - z) < w.aoe) breakPot(pot);
}
function updateAngelSwords(dt) {
  let n = 0, nm = 0;
  const fade = angelGeo.attributes.aFade.array;
  for (const w of angels) {
    if (!w.on) continue;
    w.t += dt;
    const tDrop = w.hang, tHit = w.hang + ANGEL_DROP, tEnd = tHit + ANGEL_STUCK + ANGEL_FADE;
    if (w.t >= tEnd || !player.alive) { w.on = false; w.e = null; continue; }
    if (w.t < tDrop && w.e && !w.e.dead) { w.x = w.e.x + w.ox; w.z = w.e.z + w.oz; } // follows its foe while it hangs, then commits
    let y, sc = w.s, alpha = 1, glow, rz = 0;
    if (w.t < tDrop) { // materialize and hang with a shimmer
      const u = Math.min(1, w.t / 0.12);
      sc *= 0.3 + 0.7 * (1 - (1 - u) ** 3); alpha = u;
      y = ANGEL_H + Math.sin(w.t * 9 + w.sway) * 0.07; rz = Math.sin(w.t * 13 + w.sway) * 0.05;
      glow = u * (0.4 + 0.2 * Math.sin(w.t * 30 + w.sway));
      if (fxP((MOBILE ? 0.15 : 0.3))) spark(w.x + rr(-0.25, 0.25), y + rr(0.3, 1.8) * sc, w.z, 0xfff3c0, { s: 0.3, life: 0.25, drag: 0, vy: -0.5 });
    } else if (w.t < tHit) { // guillotine drop: accelerates all the way down
      const u = (w.t - tDrop) / ANGEL_DROP;
      y = ANGEL_H * (1 - u * u); glow = 0.8;
      if (fxP(0.6)) spark(w.x, y + 1.2 * sc, w.z, 0xffe9a0, { s: 0.5, life: 0.18, drag: 0 });
    } else { // stuck in the floor, a short quiver, then fades
      if (w.hitT < 0) { w.hitT = w.t; angelImpact(w); }
      const st = w.t - tHit, f = st < ANGEL_STUCK ? 1 : 1 - (st - ANGEL_STUCK) / ANGEL_FADE;
      y = -0.4 * w.s - (1 - f) * 0.25; alpha = f;
      rz = Math.sin(st * 60) * 0.06 * Math.max(0, 1 - st / 0.25);
      glow = (st < 0.1 ? 1.6 - st * 6 : 1) * f * 0.8;
    }
    angelE.set(0, 0, rz); angelQ.setFromEuler(angelE); angelP.set(w.x, y, w.z); angelS.setScalar(sc);
    angelMesh.setMatrixAt(n, bMat.compose(angelP, angelQ, angelS)); fade[n] = alpha;
    angelP.y = Math.max(0.15, y + 1.0 * sc); angelS.set(0.8 * sc, 2.5 * sc, 1); angelQ.identity();
    angelGlow.setMatrixAt(n, bMat.compose(angelP, angelQ, angelS)); angelGlow.setColorAt(n, angelC.setRGB(glow, glow * 0.95, glow * 0.8));
    n++;
    if (w.t < tHit) { // the faint mark on the floor under the sword until it lands
      const u = Math.min(1, w.t / 0.2), m = (w.t < tDrop ? 0.45 : 0.75) * u;
      angelP.set(w.x, 0.06, w.z); angelS.setScalar(w.aoe * (0.6 + 0.4 * u)); angelQ.identity();
      angelMark.setMatrixAt(nm, bMat.compose(angelP, angelQ, angelS)); angelMark.setColorAt(nm++, angelC.setRGB(m, m * 0.9, m * 0.6));
    }
  }
  if (n || angelMesh.count) {
    angelMesh.count = angelGlow.count = n; angelMesh.instanceMatrix.needsUpdate = true; angelGeo.attributes.aFade.needsUpdate = true;
    angelGlow.instanceMatrix.needsUpdate = true; angelGlow.instanceColor.needsUpdate = true;
  }
  if (nm || angelMark.count) { angelMark.count = nm; angelMark.instanceMatrix.needsUpdate = true; angelMark.instanceColor.needsUpdate = true; }
}
// ---------- Stone Pillars (earth.quake, replaced Quake's blast around Pip) ----------
// Strikes the foes where they stand (never a ring around Pip, never a line from him like Earth Spike): under each of 3 picked
// foes (Lv 3: 4, Lv 5: 5, taller and wider) the floor cracks and flashes for 0.25s, then a thick rough hexagonal pillar bursts
// up with rubble and dust, hits everything in a small radius and launches the foe on top of it (STUNNED; bosses only flinch).
// It stands ~0.6s, then crumbles into falling chunks and sinks back. Pooled: PIL_N slots in four instanced draws (pillars, the
// broken slabs round their base, dark cracks, the additive crack glow); nothing is made per cast.
const PIL_N = 12, PIL_SLAB = 5, PIL_WARN = 0.25, PIL_RISE = 0.09, PIL_STAND = 0.6, PIL_SINK = 0.35, PIL_END = PIL_WARN + PIL_RISE + PIL_STAND + PIL_SINK;
const pilGeo = (() => { // a hexagonal column, wider at the foot, every vertex pushed in/out a little (seam vertices get the same push)
  const g = new THREE.CylinderGeometry(0.42, 0.55, 1, 6, 4), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i), hx = Math.round(x * 40), hz = Math.round(z * 40), hy = Math.round(y * 8);
    const k = 0.82 + hash(hx, hz + hy * 13, 5) * 0.32;
    p.setXYZ(i, x * k, y + (y > 0.49 ? (hash(hx, hz, 9) - 0.5) * 0.3 : 0), z * k);
  }
  return g.translate(0, 0.5, 0);
})();
const pilSlabGeo = new THREE.ConeGeometry(0.2, 0.55, 4).translate(0, 0.2, 0); // a broken floor slab jutting out at the base
const pilMat = new THREE.MeshLambertMaterial({ color: 0x9a7a5a, emissive: 0x1a120a, flatShading: true }); // the pebbles' rock colour (user 11-15)
const pilEdgeMat = new THREE.MeshBasicMaterial({ color: 0x140c06, side: THREE.BackSide }); // + their dark outline shell
const pilCrackTex = canvasTex(64, 64, (g) => { // jagged cracks branching out from the middle
  g.strokeStyle = '#fff'; g.lineCap = 'round';
  for (let i = 0; i < 9; i++) {
    let a = i / 9 * Math.PI * 2 + hash(i, 2, 3) * 0.5, x = 32, y = 32, r = 0;
    g.lineWidth = 3; g.beginPath(); g.moveTo(x, y);
    while (r < 28) { r += 4 + hash(i, r, 4) * 4; a += (hash(i, r, 6) - 0.5) * 0.9; x = 32 + Math.cos(a) * r; y = 32 + Math.sin(a) * r; g.lineTo(x, y); g.lineWidth = Math.max(1, 3 - r / 10); }
    g.stroke();
  }
});
pilCrackTex.magFilter = THREE.LinearFilter;
const pilFlat = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
const pilMesh = new THREE.InstancedMesh(pilGeo, pilMat, PIL_N);
const pilSlabMesh = new THREE.InstancedMesh(pilSlabGeo, pilMat, PIL_N * PIL_SLAB);
const pilCrackMesh = new THREE.InstancedMesh(pilFlat, new THREE.MeshBasicMaterial({ map: pilCrackTex, color: 0x140c06, transparent: true, opacity: 0.85, depthWrite: false, ...DECAL }), PIL_N);
const pilGlowMesh = new THREE.InstancedMesh(pilFlat, new THREE.MeshBasicMaterial({ map: pilCrackTex, color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }), PIL_N);
const pilEdge = new THREE.InstancedMesh(pilGeo, pilEdgeMat, PIL_N), pilSlabEdge = new THREE.InstancedMesh(pilSlabGeo, pilEdgeMat, PIL_N * PIL_SLAB);
const PIL_MESHES = [pilMesh, pilSlabMesh, pilCrackMesh, pilGlowMesh, pilEdge, pilSlabEdge];
pilGlowMesh.renderOrder = 1;
for (const m of PIL_MESHES) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; scene.add(m); }
for (let i = 0; i < PIL_N; i++) pilGlowMesh.setColorAt(i, tmpC.set(0)); // the glow's colour buffer exist from the start: no recompile later
const pils = Array.from({ length: PIL_N }, () => ({ on: false, t: 0, x: 0, z: 0, H: 1, w: 1, aoe: 1, dmg: 0, els: null, col: 0, rot: 0, hit: false, ck: 0, foe: null }));
let pilLive = false;
const pilP = new THREE.Vector3(), pilS = new THREE.Vector3(), pilQ = new THREE.Quaternion(), pilE = new THREE.Euler();
const pilC = [], pilPick = [];
function pickPillarFoes(n, range) { // the toughest and most crowded foes in reach, one each, not on top of each other
  pilC.length = pilPick.length = 0; let hpMax = 1;
  for (const e of enemies) if (!e.dead && !e.hidden && e.spawn >= 0.5 && Math.hypot(e.x - player.x, e.z - player.z) < range) { pilC.push(e); hpMax = Math.max(hpMax, e.hp); }
  for (const e of pilC) { let c = 0; for (const o of pilC) if (o !== e && Math.abs(o.x - e.x) < 1.6 && Math.abs(o.z - e.z) < 1.6) c++; e._pw = Math.min(3, c) + 2 * e.hp / hpMax; }
  pilC.sort((a, b) => b._pw - a._pw);
  for (const gap of [1.4, 0.8]) for (const e of pilC) { // spread out first; with few foes, closer ones fill the rest
    if (pilPick.length >= n) break;
    if (!pilPick.includes(e) && !pilPick.some((o) => Math.hypot(o.x - e.x, o.z - e.z) < gap)) pilPick.push(e);
  }
  pilC.length = 0; return pilPick;
}
function castPillars(lv, sh, range, dmg, els, col, area, extra) {
  const big = lv >= 5, n = sh.count + (lv >= 3) + (lv >= 5) + Math.min(2, extra);
  const foes = pickPillarFoes(n, range + 1.5 + (player.rangeBonus || 0));
  for (let k = 0; k < foes.length; k++) {
    const p = pils.find((q) => !q.on); if (!p) break;
    const e = foes[k];
    if (sh.look === 'thunder') { const x = e.x, z = e.z; later(k * 0.06, () => { skyBolt(x, z, '#fff7a8', 0.22, 9); bolts[bolts.length - 1].glow = 'rgba(232,200,110,.5)'; }); } // Thunder Pillars: lightning cracks down where each pillar bursts up
    Object.assign(p, { on: true, t: -k * 0.06, x: e.x, z: e.z, H: big ? 2.3 : 1.8, w: big ? 1.35 : 1.15, aoe: sh.aoe * area * (big ? 1.3 : 1), dmg, els, col, rot: rand() * 6.283, hit: false, ck: 0, foe: e });
    pilLive = true;
  }
  sfx('lock');
}
function pillarHit(p) { // the pillar is up: damage around it, the foe on it goes up with it
  p.hit = true;
  addShake(0.16); sfx('slam');
  chunk(p.x, 0.3, p.z, 0x8a7258, 7, 4, 0.14); chunkDust(p.x, p.z, 0xc8925a); burst(p.x, 0.2, p.z, 0xc8a07a, 8, 3, 0.45, 0.45);
  addRing(p.x, p.z, 0.3, p.aoe * 1.3, 0.3, 0xc8925a);
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i]; if (!e || e.dead || e.spawn < 0.3) continue;
    const dx = e.x - p.x, dz = e.z - p.z, d = Math.hypot(dx, dz); if (d > p.aoe + e.r) continue;
    const top = e === p.foe || d < 0.45, st0 = e.stun || 0;
    hurtEnemy(e, p.dmg, top ? 0 : dx, top ? 0 : dz, top ? 0 : 1.2, p.col, p.els);
    if (e.dead) continue;
    if (e.isBoss) { e.stun = st0; e.squash = 0.6; e.shake = 0.1; continue; } // bosses: damage and a flinch, no launch, no stun
    const dur = top ? PIL_RISE + PIL_STAND + 0.22 : 0.42;
    e.stun = Math.max(e.stun || 0, dur, 1.2 * Math.min(1, ccMul(e) * 1.4)); e.stunImm = G.time + 1.8;
    if (e.liftT === undefined || (top && e.liftH < 1)) { e.liftT = 0; e.liftDur = dur; e.liftH = top ? p.H + 0.05 : 0.55; } // launched onto the pillar top, or popped off its edge (a foe in the air stays up)
    if (top) { e.kx = e.kz = 0; }
  }
  for (const pot of [...pots]) if (Math.hypot(pot.x - p.x, pot.z - p.z) < p.aoe) breakPot(pot);
}
function liftY(e, dt) { // a launched foe: shoots up, rides the pillar top, drops when it crumbles
  const t = (e.liftT += dt), D = e.liftDur, H = e.liftH, up = Math.min(0.12, D * 0.35), fall = Math.min(0.24, D * 0.5);
  if (t >= D) { e.liftT = undefined; e.squash = Math.max(e.squash || 0, 0.5); return 0; }
  if (t < up) { const k = 1 - t / up; return H * (1 - k * k); }
  if (t > D - fall) { const u = (t - D + fall) / fall; return H * (1 - u * u); }
  return H + Math.sin((t - up) * 14) * 0.03;
}
function updatePillars(dt) {
  if (!pilLive) return;
  let n = 0, ns = 0, nc = 0, live = false;
  for (const p of pils) {
    if (!p.on) continue;
    p.t += dt; live = true;
    const t = p.t; if (t < 0) continue;
    if (t >= PIL_END + 0.25) { p.on = false; p.foe = null; continue; }
    // the crack: grows in during the warning, flashes, then glows down and fades out after the pillar sinks
    const cs = p.aoe * 2.3 * Math.min(1, 0.5 + t / PIL_WARN * 0.5) * (t > PIL_END ? Math.max(0, 1 - (t - PIL_END) / 0.25) : 1);
    pilP.set(p.x, 0.02, p.z); pilE.set(0, p.rot, 0); pilQ.setFromEuler(pilE); pilS.set(cs, 1, cs);
    bMat.compose(pilP, pilQ, pilS); pilCrackMesh.setMatrixAt(nc, bMat); pilGlowMesh.setMatrixAt(nc, bMat);
    const gl = t < PIL_WARN ? 0.55 + 0.45 * Math.sin(t * 55) : Math.max(0, 1 - (t - PIL_WARN) / 0.5) * 0.9;
    pilGlowMesh.setColorAt(nc++, tmpC.setHex(0xff8a2a).multiplyScalar(gl));
    if (t < PIL_WARN) { if (Math.random() < 0.3) chunkDust(p.x + rr(-0.4, 0.4), p.z + rr(-0.4, 0.4), 0xc8925a); continue; }
    if (!p.hit) pillarHit(p);
    // the pillar: bursts up out of the floor (a small overshoot), stands, then shakes, crumbles and sinks
    const tr = t - PIL_WARN, kr = Math.min(1, tr / PIL_RISE), us = Math.max(0, Math.min(1, (tr - PIL_RISE - PIL_STAND) / PIL_SINK));
    if (us > 0 && p.ck === 0) { p.ck = 1; chunk(p.x, p.H * 0.8, p.z, 0x8a7258, 6, 2.5, 0.17); chunkDust(p.x, p.z, 0xc8925a); }
    if (us > 0.5 && p.ck === 1) { p.ck = 2; chunk(p.x, p.H * 0.4, p.z, 0x7a6450, 4, 2, 0.14); }
    if (us >= 1) continue;
    const rise = kr < 1 ? 1 - Math.pow(1 - kr, 3) * (1 - kr * 0.6) + Math.sin(kr * Math.PI) * 0.08 : 1;
    const y = -p.H * (1 - rise) - p.H * 1.05 * us * us - 0.1, jx = us > 0 ? rr(-0.04, 0.04) : 0;
    pilP.set(p.x + jx, y, p.z); pilE.set(us * 0.12, p.rot, us * 0.08); pilQ.setFromEuler(pilE); pilS.set(p.w * (1 - us * 0.25), p.H + 0.1, p.w * (1 - us * 0.25));
    pilMesh.setMatrixAt(n, bMat.compose(pilP, pilQ, pilS)); pilS.multiplyScalar(1.1); pilEdge.setMatrixAt(n++, bMat.compose(pilP, pilQ, pilS));
    for (let j = 0; j < PIL_SLAB; j++) { // broken slabs pushed up round the foot, leaning out
      const a = p.rot + j / PIL_SLAB * 6.283 + hash(j, p.rot, 2) * 0.6, r = 0.58 * p.w, s = (0.75 + hash(j, p.rot, 7) * 0.6) * p.w * Math.min(1, kr * 1.5) * (1 - us);
      pilP.set(p.x + Math.cos(a) * r, -0.06 - us * 0.3, p.z + Math.sin(a) * r);
      pilE.set(Math.sin(a) * 0.55, a, -Math.cos(a) * 0.55); pilQ.setFromEuler(pilE); pilS.set(s, s, s);
      pilSlabMesh.setMatrixAt(ns, bMat.compose(pilP, pilQ, pilS)); pilS.multiplyScalar(1.12); pilSlabEdge.setMatrixAt(ns++, bMat.compose(pilP, pilQ, pilS));
    }
  }
  pilLive = live;
  pilMesh.count = pilEdge.count = n; pilSlabMesh.count = pilSlabEdge.count = ns; pilCrackMesh.count = pilGlowMesh.count = nc;
  for (const m of PIL_MESHES) m.instanceMatrix.needsUpdate = true;
  if (nc) pilGlowMesh.instanceColor.needsUpdate = true;
}
// ---------- Frost Diver (frost.trap) and ice blocks on frozen foes ----------
// Frost Diver travels out to the foes (user: no runes at Pip's feet): a line of thin ice crystals races along the floor from
// just in front of Pip to a foe (17 tiles/s: 6 tiles in ~0.35s, stopped by walls), zig-zagging side to side over a pale frozen
// streak that fades. Each crystal stabs up leaning forward, holds a moment, then shrinks away into frost mist. Every foe the
// line crosses is hit and FROZEN in a block of ice until it thaws or shatters; bosses are only slowed. Unlike Earth Spike's
// fat brown cones in a straight row these are thin, pale, many and swept forward. Everything is instanced and preallocated:
// STREAK_N streak decals, SHARD_N crystals, ICEBLK_N ice blocks; nothing is made per cast or per frame.
const STREAK_N = 14, SHARD_N = 260, ICEBLK_N = 40, DIVER_SPD = 17;
const iceStreakTex = canvasTex(256, 64, (g, w, h) => { // a frozen band: soft edges, bright crackle lines and frost specks
  const gr = g.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.3, 'rgba(255,255,255,.45)'); gr.addColorStop(0.5, 'rgba(255,255,255,.75)');
  gr.addColorStop(0.7, 'rgba(255,255,255,.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.globalCompositeOperation = 'destination-in'; // round off both ends
  const ge = g.createLinearGradient(0, 0, w, 0);
  ge.addColorStop(0, 'rgba(0,0,0,0)'); ge.addColorStop(0.08, 'rgba(0,0,0,1)'); ge.addColorStop(0.9, 'rgba(0,0,0,1)'); ge.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = ge; g.fillRect(0, 0, w, h);
  g.globalCompositeOperation = 'source-over'; g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 1.5;
  for (let k = 0; k < 9; k++) { // short jagged cracks
    let x = 14 + hash(k, 4) * (w - 40), y = h * (0.3 + hash(k, 5) * 0.4); g.beginPath(); g.moveTo(x, y);
    for (let q = 0; q < 4; q++) { x += 5 + hash(k, q + 6) * 9; y += (hash(k, q + 11) - 0.5) * 14; g.lineTo(x, y); }
    g.stroke();
  }
  for (let i = 0; i < 160; i++) { g.fillStyle = `rgba(255,255,255,${0.3 + hash(i, 7) * 0.6})`; g.fillRect(8 + hash(i, 8) * (w - 16), h * (0.22 + hash(i, 9) * 0.56), 2, 2); }
}, false);
const iceInst = (geo, mat, n) => { const m = new THREE.InstancedMesh(geo, mat, n); m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; m.count = 0; scene.add(m); return m; };
const iceStreakMesh = iceInst(new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: iceStreakTex, color: 0xffffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, ...DECAL }), STREAK_N);
iceStreakMesh.setColorAt(0, tmpC.set(0)); iceStreakMesh.renderOrder = 1; // the colour buffer exists from the start: no shader change later
const iceCrystalGeo = new THREE.OctahedronGeometry(1, 0).scale(0.12, 0.5, 0.12).translate(0, 0.42, 0); // a long prism standing on its lower tip
const iceCrMesh = iceInst(iceCrystalGeo, new THREE.MeshLambertMaterial({ color: 0xd4f2ff, emissive: 0x3a7aaa, transparent: true, opacity: 0.92, flatShading: true }), SHARD_N);
const iceBlkMesh = iceInst(new THREE.DodecahedronGeometry(1, 0).translate(0, 0.85, 0), new THREE.MeshLambertMaterial({ color: 0xe0f6ff, emissive: 0x5a9ccc, transparent: true, opacity: 0.58, depthWrite: false, flatShading: true }), ICEBLK_N);
// sprites are pulled 1.1 toward the camera in their shader (uBias); the block gets a bit more so it draws over its foe
iceBlkMesh.material.onBeforeCompile = (s) => { s.vertexShader = s.vertexShader.replace('#include <project_vertex>', '#include <project_vertex>\n  mvPosition.z += 1.3; gl_Position = projectionMatrix * mvPosition;'); };
const streaks = Array.from({ length: STREAK_N }, () => ({ t: 9, x: 0, z: 0, ca: 1, sa: 0, L: 1 }));
const shards = Array.from({ length: SHARD_N }, () => ({ t: 9, x: 0, z: 0, h: 1, w: 1, q: new THREE.Quaternion(), dust: 1 }));
const iceP = new THREE.Vector3(), iceS = new THREE.Vector3(), iceQ = new THREE.Quaternion(), iceAx = new THREE.Vector3(), UP = new THREE.Vector3(0, 1, 0);
const ICE_MIST = { vy: 0.5, s: 1.0, life: 0.7, drag: 2.5, spread: 0.4 };
let shardHead = 0, streakHead = 0, iceLive = 0, iceDrawn = 0;
const leanOut = (q, a, lean) => q.setFromAxisAngle(iceAx.set(Math.sin(a), 0, -Math.cos(a)), lean); // the tip leans toward angle a
function addShard(x, z, h, w, a, lean, delay) {
  const p = shards[shardHead]; shardHead = (shardHead + 1) % SHARD_N;
  p.t = -delay; p.x = x; p.z = z; p.h = h; p.w = w; p.dust = 0; leanOut(p.q, a, lean);
}
// one cast: a line per target (Lv 3: the 2 nearest foes, Lv 5: 3), each foe hit once per cast
const diverC = [];
function castDiver(s, dmg, target, dur) {
  const D = spellDef(s.id), rock = D.look === 'glacier'; // Glacier Rift (frost+earth): the same lines, hitting with frost + earth, stone breaking up with the ice
  const lv = s.lv, lines = lv >= 5 ? 3 : lv >= 3 ? 2 : 1, frz = (lv >= 5 ? 2.8 : 2) * dur, x0 = player.x, z0 = player.z, hit = new Set();
  diverC.length = 0;
  if (lines > 1) { // the next nearest foes in range
    const R = spellDef(s.id).range + (player.rangeBonus || 0);
    for (const e of enemies) { if (e === target || e.dead || e.hidden || e.spawn < 0.3) continue; e._sd = Math.hypot(e.x - x0, e.z - z0); if (e._sd < R) diverC.push(e); }
    diverC.sort((a, b) => a._sd - b._sd);
  }
  for (let l = 0; l < lines; l++) {
    const e = l ? diverC[l - 1] : target, a = Math.atan2(target.z - z0, target.x - x0);
    if (e) diverLine(x0, z0, Math.atan2(e.z - z0, e.x - x0), Math.hypot(e.x - x0, e.z - z0), dmg, frz, hit, D.els, rock);
    else diverLine(x0, z0, a + (l === 1 ? 0.45 : -0.45), 5, dmg, frz, hit, D.els, rock); // no foe for this line: fan off the first one
  }
  diverC.length = 0;
  addShake(0.1); sfx('frost');
}
function diverLine(x0, z0, a, dist, dmg, frz, hit, els = FROST_ELS, rock = false) {
  const ca = Math.cos(a), sa = Math.sin(a), d0 = 0.55;
  let L = clamp(dist + 1, 2.5, 7.5); // runs just past its foe, not across the room
  for (let d = d0; d < L; d += 0.25) if (solid(x0 + ca * d, z0 + sa * d, true)) { L = d - 0.15; break; }
  if (L <= d0) return;
  const st = streaks[streakHead]; streakHead = (streakHead + 1) % STREAK_N;
  st.t = 0; st.x = x0 + ca * d0; st.z = z0 + sa * d0; st.ca = ca; st.sa = sa; st.L = L - d0;
  iceLive = 2;
  const step = MOBILE ? 0.36 : 0.3;
  for (let d = d0, k = 0; d <= L; d += step, k++) {
    const side = k % 2 ? 1 : -1, off = side * (0.13 + Math.random() * 0.1), cx = x0 + ca * d, cz = z0 + sa * d, delay = (d - d0) / DIVER_SPD;
    // the zig-zag: a tall thin crystal on one side swept forward and out, a small one on the other side
    addShard(cx - sa * off, cz + ca * off, 0.9 + Math.random() * 0.55, 0.62 + Math.random() * 0.2, a + side * 1.1, 0.3 + Math.random() * 0.25, delay);
    addShard(cx + sa * off * 0.6, cz - ca * off * 0.6, 0.4 + Math.random() * 0.25, 0.5, a - side * 1.3, 0.45, delay + 0.02);
    const last = d + step > L;
    later(delay, () => {
      if (k % (MOBILE ? 3 : 2) === 0) spark(cx, 0.2, cz, k % 4 ? 0xe8f8ff : 0xbfe8ff, { ...ICE_MIST, vx: -sa * side * 1.4 + ca * 1.5, vz: ca * side * 1.4 + sa * 1.5 });
      if (last) burst(cx, 0.5, cz, 0xe8fbff, MOBILE ? 6 : 10, 3.5, 0.3, 0.35);
      if (rock && k % 2 === 0) { chunk(cx, 0.25, cz, k % 4 ? 0x8a7258 : 0x6a5a48, MOBILE ? 1 : 2, 3.5, 0.11); if (k % 4 === 0) chunkDust(cx, cz, 0xc8a07a); } // Glacier Rift: stone breaks up with the ice
      for (const e of enemies) if (!e.dead && e.spawn >= 0.3 && !hit.has(e) && Math.hypot(e.x - cx, e.z - cz) < 0.5 + e.r) { hit.add(e); diverHit(e, dmg, x0, z0, frz, els); }
    });
  }
}
function diverHit(e, dmg, sx, sz, frz, els = FROST_ELS) {
  const pre = e.ice && e.freeze > 0; // already in ice: this hit shatters it (hurtEnemy), it isn't frozen again
  hurtEnemy(e, dmg, e.x - sx, e.z - sz, 0.6, 0x9fe8ff, els);
  if (e.dead || pre) return;
  if (e.isBoss) { e.slow = Math.max(e.slow || 0, 2.5); e.slowAmt = Math.max(e.slowAmt || 0, 0.45); return; } // bosses: slowed, never frozen
  ccFreeze(e, frz); // tough foes (golems, named, elites) a bit less
  if (e.freeze > 0) { if (!e.ice) addText(e.x, 1.6, e.z, 'FROZEN', '#9fe8ff', 0.9); e.ice = true; e.chill = 0; }
  burst(e.x, 0.7, e.z, 0xbff4ff, MOBILE ? 6 : 10, 3, 0.35, 0.4);
}
function updateIceFx(dt) {
  let ns = 0, nc = 0, nb = 0;
  if (iceLive > 0) {
    iceLive -= dt;
    for (const st of streaks) { // the frozen streak grows with the line's head, holds, then fades
      if (st.t > 1.6) continue;
      st.t += dt; if (st.t > 1.6) continue;
      const ext = Math.min(st.L, st.t * DIVER_SPD), f = st.t < 0.9 ? 1 : 1 - (st.t - 0.9) / 0.7;
      if (ext < 0.05) continue;
      iceP.set(st.x + st.ca * ext * 0.5, 0.03, st.z + st.sa * ext * 0.5); iceS.set(ext * 0.5 + 0.15, 1, 0.42);
      iceStreakMesh.setMatrixAt(ns, bMat.compose(iceP, iceQ.setFromAxisAngle(UP, -Math.atan2(st.sa, st.ca)), iceS));
      iceStreakMesh.setColorAt(ns++, tmpC.set(0x8fd2f4).multiplyScalar(0.75 * f * f));
    }
    for (const p of shards) { // crystals: stab up, hold, then shrink and sink away into frost
      if (p.t > 0.5) continue;
      p.t += dt; if (p.t < 0 || p.t > 0.5) continue;
      const t = p.t, up = t < 0.06 ? 1 - (1 - t / 0.06) ** 3 : 1, c = t < 0.22 ? 0 : (t - 0.22) / 0.28;
      if (c > 0 && !p.dust) { p.dust = 1; if (p.h > 0.8) chunk(p.x, 0.5, p.z, 0xdff6ff, MOBILE ? 1 : 2, 3, 0.06); }
      iceP.set(p.x, -p.h * 0.45 * c * c, p.z); iceS.set(p.w * (1 - 0.6 * c), p.h * up * (1 - 0.6 * c) || 0.0001, p.w * (1 - 0.6 * c));
      iceCrMesh.setMatrixAt(nc++, bMat.compose(iceP, p.q, iceS));
    }
  }
  for (const e of enemies) { // frozen foes sit in a block of ice (Frost Diver, frost's freeze, Storm Gust); bosses never freeze
    if (e.dead || !(e.freeze > 0) || !(e.ice || e.gustIce) || e.isBoss || nb >= ICEBLK_N) { e.iceT = 0; continue; }
    e.iceT = (e.iceT || 0) + dt; if (e.iceRot === undefined) e.iceRot = Math.random() * 6.283;
    const ud = e.mesh.userData, k = Math.min(1, e.iceT / 0.12) * Math.min(1, e.freeze / 0.2 + 0.3), w = ud.bw * 0.56 * k;
    iceP.set(e.x, (e.y || 0) - 0.05, e.z); iceS.set(w, ud.bh * 0.64 * k, w * 0.85);
    iceBlkMesh.setMatrixAt(nb++, bMat.compose(iceP, iceQ.setFromAxisAngle(UP, e.iceRot), iceS));
  }
  iceStreakMesh.count = ns; iceCrMesh.count = nc; iceBlkMesh.count = nb;
  const any = ns + nc + nb;
  if (any || iceDrawn) {
    iceStreakMesh.instanceMatrix.needsUpdate = iceCrMesh.instanceMatrix.needsUpdate = iceBlkMesh.instanceMatrix.needsUpdate = true;
    if (iceStreakMesh.instanceColor) iceStreakMesh.instanceColor.needsUpdate = true;
  }
  iceDrawn = any;
}
// ---------- Earth Spike's stone line (the Frost Diver pipeline in stone): crack decals + instanced stone spikes, preallocated
const ESTREAK_N = 6, ESHARD_N = 160;
const earthCrackTex = canvasTex(256, 64, (g, w, h) => { // a dark torn crack: a jagged black split with branches and a dusty rim
  const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(40,30,22,0)'); gr.addColorStop(0.5, 'rgba(40,30,22,.35)'); gr.addColorStop(1, 'rgba(40,30,22,0)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  const main = (lw, col) => { g.strokeStyle = col; g.lineWidth = lw; g.beginPath(); let y = h / 2; g.moveTo(4, y); for (let x = 4; x < w - 4; x += 9) { y = h / 2 + (hash(x, 3) - 0.5) * 18; g.lineTo(x, y); } g.stroke(); };
  main(9, 'rgba(10,8,8,.55)'); main(4, 'rgba(0,0,0,.95)');
  g.strokeStyle = 'rgba(0,0,0,.8)'; g.lineWidth = 2;
  for (let k = 0; k < 10; k++) { let x = 12 + hash(k, 21) * (w - 30), y = h / 2; g.beginPath(); g.moveTo(x, y); const dy = hash(k, 22) < 0.5 ? -1 : 1; for (let q = 0; q < 3; q++) { x += 4 + hash(k, q + 23) * 8; y += dy * (3 + hash(k, q + 27) * 6); g.lineTo(x, y); } g.stroke(); }
  g.globalCompositeOperation = 'destination-in'; const ge = g.createLinearGradient(0, 0, w, 0); ge.addColorStop(0, 'rgba(0,0,0,0)'); ge.addColorStop(0.06, 'rgba(0,0,0,1)'); ge.addColorStop(0.92, 'rgba(0,0,0,1)'); ge.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = ge; g.fillRect(0, 0, w, h);
}, false);
const eStreakMesh = iceInst(new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: earthCrackTex, transparent: true, depthWrite: false, ...DECAL }), ESTREAK_N); eStreakMesh.renderOrder = 1;
const eShardGeo = (() => { const g = new THREE.OctahedronGeometry(1, 0).scale(0.17, 0.5, 0.17).translate(0, 0.42, 0), p = g.attributes.position, c = [], lo = new THREE.Color(0x18181c), hi = new THREE.Color(0xa8a8b2), t = new THREE.Color();
  for (let i = 0; i < p.count; i++) { t.copy(lo).lerp(hi, clamp(p.getY(i) / 0.92, 0, 1) ** 1.3); c.push(t.r, t.g, t.b); } g.setAttribute('color', new THREE.Float32BufferAttribute(c, 3)); return g; })();
const eCrMesh = iceInst(eShardGeo, new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x060608, flatShading: true }), ESHARD_N);
const eCrEdge = iceInst(eShardGeo, new THREE.MeshBasicMaterial({ color: 0x120c08, side: THREE.BackSide }), ESHARD_N); // the pebbles' dark outline shell (user 11-15)
const estreaks = Array.from({ length: ESTREAK_N }, () => ({ t: 9, x: 0, z: 0, ca: 1, sa: 0, L: 1 }));
const eshards = Array.from({ length: ESHARD_N }, () => ({ t: 9, x: 0, z: 0, h: 1, w: 1, q: new THREE.Quaternion(), dust: 1 }));
let eHead = 0, esHead = 0, eLive = 0, eDrawn = 0;
function addEStreak(x, z, ca, sa, L) { const st = estreaks[esHead]; esHead = (esHead + 1) % ESTREAK_N; st.t = 0; st.x = x; st.z = z; st.ca = ca; st.sa = sa; st.L = Math.max(0.5, L); eLive = 2.6; }
function addEShard(x, z, h, w, a, lean, delay) { const p = eshards[eHead]; eHead = (eHead + 1) % ESHARD_N; p.t = -delay; p.x = x; p.z = z; p.h = h; p.w = w; p.dust = 0; leanOut(p.q, a, lean); eLive = 2.6; }
function updateEarthFx(dt) {
  let ns = 0, nc = 0;
  if (eLive > 0) {
    eLive -= dt;
    for (const st of estreaks) { // the crack tears open with the line's head, stays, then closes up (narrows) and goes
      if (st.t > 2.4) continue; st.t += dt; if (st.t > 2.4) continue;
      const ext = Math.min(st.L, st.t * 24), f = st.t < 1.6 ? 1 : 1 - (st.t - 1.6) / 0.8; if (ext < 0.05) continue;
      iceP.set(st.x + st.ca * ext * 0.5, 0.035, st.z + st.sa * ext * 0.5); iceS.set(ext * 0.5 + 0.1, 1, 0.5 * f);
      eStreakMesh.setMatrixAt(ns++, bMat.compose(iceP, iceQ.setFromAxisAngle(UP, -Math.atan2(st.sa, st.ca)), iceS));
    }
    for (const p of eshards) { // stone spikes: burst up, hold, then crumble and sink
      if (p.t > 0.75) continue; p.t += dt; if (p.t < 0 || p.t > 0.75) continue;
      const t = p.t, up = t < 0.07 ? 1 - (1 - t / 0.07) ** 3 : 1, c = t < 0.4 ? 0 : (t - 0.4) / 0.35;
      if (c > 0 && !p.dust) { p.dust = 1; if (p.h > 0.9) chunk(p.x, 0.4, p.z, 0x4a4a52, MOBILE ? 1 : 2, 2.5, 0.08); }
      iceP.set(p.x, -p.h * 0.5 * c * c, p.z); iceS.set(p.w * (1 - 0.4 * c), p.h * up * (1 - 0.5 * c) || 0.0001, p.w * (1 - 0.4 * c));
      eCrMesh.setMatrixAt(nc, bMat.compose(iceP, p.q, iceS)); iceS.multiplyScalar(1.13); iceP.y -= 0.02; eCrEdge.setMatrixAt(nc++, bMat.compose(iceP, p.q, iceS));
    }
  }
  eStreakMesh.count = ns; eCrMesh.count = eCrEdge.count = nc;
  if (ns + nc || eDrawn) eStreakMesh.instanceMatrix.needsUpdate = eCrMesh.instanceMatrix.needsUpdate = eCrEdge.instanceMatrix.needsUpdate = true;
  eDrawn = ns + nc;
}
// Storm Gust: a freezing cloud over the biggest crowd; ticks frost damage, freezes foes that stay 1s, shatters them at the end
const GUST_SNOW = { vx: 2.6, vy: -5, vz: 0.8, s: 0.22, life: 0.55, drag: 0 };
function castGust(s, dmg, target, range, area) {
  const lv = s.lv, R = 2.5 * (lv >= 3 ? 1.2 : 1) * area, dur = 3 + (lv >= 3 ? 0.5 : 0);
  const e = densestFoe(target, player.x, player.z, range, R);
  addGust(e.x, e.z, R, dur, dmg);
  if (lv >= 5) { // a second, smaller storm on the nearest foe outside the first
    let o = null, od = range;
    for (const q of enemies) { if (q.dead || q.spawn < 0.3 || Math.hypot(q.x - e.x, q.z - e.z) < R + 0.8) continue; const d = Math.hypot(q.x - player.x, q.z - player.z); if (d < od) { od = d; o = q; } }
    if (o) addGust(o.x, o.z, R * 0.65, dur, dmg * 0.7);
  }
  sfx('whoosh');
}
function addGust(x, z, R, dur, dmg) {
  const g = { x, z, R, dur, dmg, t: 0, tick: 0.2, glows: [], shadow: makeShadow(R * 2.4),
    ring: new THREE.Mesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: softRingTex, color: 0xbfe8ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL })) };
  for (let k = 0; k < 6; k++) g.glows.push(makeGlow(k % 2 ? 0x3a5aa0 : 0xa8d8ff, R, 0));
  g.ring.position.set(x, 0.1, z); g.ring.scale.setScalar(R); scene.add(g.ring);
  g.shadow.position.set(x, 0.04, z);
  gusts.push(g);
}
function updateGusts(dt) {
  for (let i = gusts.length - 1; i >= 0; i--) {
    const g = gusts[i]; g.t += dt;
    const form = Math.min(1, g.t / 0.3), k = form * clamp((g.dur - g.t) / 0.3, 0, 1);
    for (let j = 0; j < g.glows.length; j++) { // the cloud: puffs swirling overhead
      const gl = g.glows[j], a = G.time * 1.6 + j * 1.2566, rd = j ? g.R * 0.55 : 0, sz = g.R * (j ? 1.1 : 1.5) * form;
      gl.position.set(g.x + Math.cos(a) * rd, 3 + (j % 2) * 0.4, g.z + Math.sin(a) * rd * 0.7); gl.scale.set(sz, sz, 1); gl.material.opacity = (j % 2 ? 0.55 : 0.3) * k;
    }
    g.shadow.scale.set(g.R * 2.4 * k, 1, g.R * 1.9 * k);
    g.ring.material.opacity = 0.75 * k;
    if (g.t < g.dur) for (let q = 0, n = MOBILE ? 2 : 4; q < n; q++) { // wind-driven snow, slanting across the circle
      const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * g.R;
      spark(g.x + Math.cos(a) * d - 1.3, 2.6, g.z + Math.sin(a) * d - 0.4, q % 2 ? 0xffffff : 0xbfe8ff, GUST_SNOW);
    }
    if (g.t < g.dur && (g.tick -= dt) <= 0) {
      g.tick = 0.35;
      for (const e of enemies) {
        if (e.dead || e.spawn < 0.3 || Math.hypot(e.x - g.x, e.z - g.z) > g.R + e.r) continue;
        const fr0 = e.freeze;
        dotHit(e, g.dmg, 0x9fe8ff, FROST_ELS, true); // frost: slows stack up
        if (e.dead) continue;
        if (e.isBoss) { e.freeze = fr0; immNote(e, false); continue; }
        e.gust = (e.gust || 0) + 0.35;
        if (e.gust >= 1) { ccFreeze(e, g.dur - g.t + 0.8); if (e.freeze > 0) e.gustIce = 1; } // FROZEN after ~1s inside
      }
    }
    if (g.t >= g.dur) { // the storm ends: frozen foes shatter
      let n = 0;
      for (const e of enemies) {
        if (e.dead || Math.hypot(e.x - g.x, e.z - g.z) > g.R + 1.5) continue;
        e.gust = 0; if (!e.gustIce) continue; e.gustIce = 0; n++;
        hurtEnemy(e, g.dmg * 5, e.x - g.x, e.z - g.z, 3, 0xbfe8ff, FROST_ELS);
        burst(e.x, 0.7, e.z, 0xdff6ff, 10, 5, 0.35, 0.45); chunk(e.x, 0.5, e.z, 0xbfe8ff, 4, 4, 0.08);
      }
      addRing(g.x, g.z, 0.3, g.R, 0.4, 0xbfe8ff); if (n) addShake(Math.min(0.3, 0.08 + n * 0.03)); sfx('frost');
      for (const gl of g.glows) killGlow(gl);
      scene.remove(g.shadow); scene.remove(g.ring); g.ring.material.dispose(); gusts.splice(i, 1);
    }
  }
}
function updateUniqueFx(dt) {
  updateEspk(dt); updateBones(dt); updateBoomerangs(dt); updatePhoenixes(dt); updateAngelSwords(dt); updatePillars(dt); updateIceFx(dt); updateEarthFx(dt); updateGusts(dt);
  updateCorpseFx(dt); updateCorpseMarks(); updateGloops(dt); updateStones(dt); updateSaws(dt); updateHammers(dt); updateSpits(dt); updateLobRocks(dt); updateCbSkulls(dt); updateCbFx(dt); updateHands(dt); updateGhostFx(dt); updateDragons(dt); updateStormEye(dt); updatePebbles(dt); updateHolyRunes(dt);
}
// ---------- sigil runes (user 11-15: "Titan Sigil is the shittest"): rune traps had nothing on the floor, only a glow. Now a
// glowing rune circle painted on the floor in the spell's colour (rings, 8 glyph ticks, a star), opening, turning, pulsing
// fast while it arms, then flashing into a shockwave. One white canvas texture tinted per mine.
let sigilTex = null;
function makeRune(x, z, col, aoe) {
  if (!sigilTex) {
    try {
      const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d'); g.translate(128, 128);
      g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.shadowColor = '#fff'; g.shadowBlur = 8;
      g.lineWidth = 7; g.beginPath(); g.arc(0, 0, 112, 0, 6.2832); g.stroke();
      g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 96, 0, 6.2832); g.stroke(); g.beginPath(); g.arc(0, 0, 44, 0, 6.2832); g.stroke();
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; g.save(); g.rotate(a); g.fillRect(-3, -110, 6, 16); g.beginPath(); g.arc(0, -78, 6, 0, 6.2832); g.fill(); g.restore(); }
      g.lineWidth = 4; g.beginPath(); for (let k = 0; k <= 5; k++) { const a = k * 4 * Math.PI / 5 - Math.PI / 2; g[k ? 'lineTo' : 'moveTo'](Math.cos(a) * 92, Math.sin(a) * 92); } g.stroke();
      sigilTex = new THREE.CanvasTexture(c);
    } catch (e) { return null; }
  }
  const m = new THREE.Mesh(holePlane, new THREE.MeshBasicMaterial({ map: sigilTex, color: col, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0 }));
  m.rotation.x = -Math.PI / 2; m.position.set(x, 0.09, z); m.renderOrder = 4; m.userData.R = Math.max(1.2, aoe * 2); m.scale.setScalar(0.01); scene.add(m); return m;
}
function killRune(r) { if (r) { scene.remove(r); r.material.dispose(); } }
// ---------- Gear Storm saws: out (0.35 s, stops at walls) -> grind 2 s -> back to Pip; hit each foe every 0.3 s on the way
const saws = [];
// the blade (user 11-15: "make it cog spikes"): a flat steel cog with 12 sharp spikes, a brass hub, a dark outline; spinY spins it
let sawGeo = null, sawEdgeGeo = null, sawHubGeo = null, sawMat = null, sawEdgeMat = null, sawHubMat = null;
function makeSawMesh() {
  if (sheets.razor_saw) { // the painted razor saw (user 11-15: "blades - just ask for a sprite"): lying almost flat, spun via spinY
    const g = new THREE.Group(), w = new THREE.Group(); g.add(w); g.userData.spinY = w;
    const m = makeSprite('razor_saw', 1.5); scene.remove(m); m.geometry = scytheGeo || (scytheGeo = new THREE.PlaneGeometry(1, 1)); m.material.side = THREE.DoubleSide;
    m.rotation.x = -Math.PI / 2 + 0.5; w.add(m); scene.add(g); return g;
  }
  if (!sawGeo) {
    // mostly blades (user: "more blades, less gear"): a small hub and 8 long hooked blades - each a curved sickle sweeping out
    const sh = new THREE.Shape(), N = 5, R = 1.0, r = 0.18; // fewer, sharper (user: 'less blades but sharp')
    for (let k = 0; k < N; k++) {
      const a = k / N * Math.PI * 2, st = Math.PI * 2 / N;
      const p0 = [Math.cos(a) * r, Math.sin(a) * r], tip = [Math.cos(a + st * 0.42) * R, Math.sin(a + st * 0.42) * R], back = [Math.cos(a + st * 0.48) * r * 1.05, Math.sin(a + st * 0.48) * r * 1.05];
      const c1 = [Math.cos(a - st * 0.05) * R * 0.75, Math.sin(a - st * 0.05) * R * 0.75], c2 = [Math.cos(a + st * 0.4) * R * 0.5, Math.sin(a + st * 0.4) * R * 0.5]; // thin, needle tips
      if (k === 0) sh.moveTo(...p0); else sh.lineTo(...p0);
      sh.quadraticCurveTo(...c1, ...tip); sh.quadraticCurveTo(...c2, ...back); // convex cutting edge out, concave back edge in
    }
    const hole = new THREE.Path(); hole.absarc(0, 0, 0.07, 0, Math.PI * 2, true); sh.holes.push(hole);
    sawGeo = new THREE.ExtrudeGeometry(sh, { depth: 0.07, bevelEnabled: true, bevelThickness: 0.015, bevelSize: 0.015, bevelSegments: 1 }).rotateX(-Math.PI / 2);
    sawEdgeGeo = sawGeo.clone(); sawHubGeo = new THREE.CylinderGeometry(0.15, 0.15, 0.13, 16);
    sawMat = new THREE.MeshLambertMaterial({ color: 0xc8ccd4, emissive: 0x2a2c34, flatShading: true });
    sawEdgeMat = new THREE.MeshBasicMaterial({ color: 0x120c08, side: THREE.BackSide }); sawHubMat = new THREE.MeshLambertMaterial({ color: 0xd8a040, emissive: 0x3a2400 });
  }
  const g = new THREE.Group(), w = new THREE.Group(); g.add(w); g.userData.spinY = w;
  const b = new THREE.Mesh(sawGeo, sawMat); w.add(b);
  const o = new THREE.Mesh(sawEdgeGeo, sawEdgeMat); o.scale.setScalar(1.07); o.position.y = -0.005; w.add(o);
  const h = new THREE.Mesh(sawHubGeo, sawHubMat); h.position.y = 0.04; w.add(h);
  g.scale.setScalar(1.25); scene.add(g); return g;
}
function addSaw(x, z, a, L, dmg, els) {
  let d = L; for (let q = 0.5; q < L; q += 0.25) if (solid(x + Math.cos(a) * q, z + Math.sin(a) * q, true)) { d = q - 0.3; break; }
  const mesh = makeSawMesh();
  saws.push({ x, z, sx: x, sz: z, tx: x + Math.cos(a) * d, tz: z + Math.sin(a) * d, t: 0, ph: 0, dmg, els, mesh, shadow: makeShadow(0.8), glow: makeGlow(0xd8a040, 0.6, 0.3), hits: new Map() });
}
function updateSaws(dt) {
  for (let i = saws.length - 1; i >= 0; i--) {
    const w = saws[i]; w.t += dt;
    if (w.ph === 0) { const k = Math.min(1, w.t / 0.35), e = ease3(k); w.x = lerp(w.sx, w.tx, e); w.z = lerp(w.sz, w.tz, e); if (k >= 1) { w.ph = 1; w.t = 0; addRing(w.x, w.z, 0.3, 1.3, 0.25, 0xffd080); sfx('clink'); } }
    else if (w.ph === 1) { if (w.t >= 2) { w.ph = 2; w.t = 0; } if (fxP(0.5)) spark(w.x + rr(-0.4, 0.4), 0.15, w.z + rr(-0.4, 0.4), 0xffe08a, { vx: rr(-4, 4), vz: rr(-4, 4), vy: rr(1, 3), s: 0.2, life: 0.3, drag: 1, grav: 6 }); }
    else { const dx = player.x - w.x, dz = player.z - w.z, d = Math.hypot(dx, dz) || 1, v = 9 + w.t * 14; w.x += dx / d * Math.min(d, v * dt); w.z += dz / d * Math.min(d, v * dt); if (d < 0.5 || w.t > 2) { scene.remove(w.mesh); w.mesh.traverse((o) => { if (o.material && o.material.isShaderMaterial) o.material.dispose(); }); scene.remove(w.shadow); killGlow(w.glow); saws.splice(i, 1); continue; } }
    w.mesh.position.set(w.x, 0.55 + (w.ph === 1 ? Math.sin(G.time * 14 + i) * 0.04 : 0), w.z); w.shadow.position.set(w.x, 0.04, w.z); w.glow.position.set(w.x, 0.55, w.z);
    const sp = w.mesh.userData.spinY; if (sp) sp.rotation.y += dt * (w.ph === 1 ? 40 : 28);
    for (const e of enemies) {
      if (e.dead || e.hidden || e.spawn < 0.5 || Math.hypot(e.x - w.x, e.z - w.z) > e.r + 0.6 || (w.hits.get(e) || 0) > G.time) continue;
      w.hits.set(e, G.time + 0.3); hurtEnemy(e, w.dmg, e.x - w.x, e.z - w.z, 1.5, 0xd8a040, w.els);
      for (let q = fxN(6); q > 0; q--) spark(w.x, 0.6, w.z, q & 1 ? 0xffe08a : 0xffffff, { vx: rr(-5, 5), vz: rr(-5, 5), vy: rr(1, 3), s: 0.22, life: 0.3, drag: 1, grav: 6 });
    }
    for (const pot of [...pots]) if (Math.hypot(pot.x - w.x, pot.z - w.z) < 0.6) breakPot(pot);
  }
}
function resetSaws() { for (const w of saws) { scene.remove(w.mesh); w.mesh.traverse((o) => { if (o.material && o.material.isShaderMaterial) o.material.dispose(); }); scene.remove(w.shadow); killGlow(w.glow); } saws.length = 0; }
// ---------- Pebble Storm's lobbed pebbles: an arc (1.2-1.8 high) onto a spot; on landing a thud, dust, bits, and a hit within 0.65
const lobRocks = [];
function lobRock(x, y, z, tx, tz, T, dmg, col, els) { const m = makeProjMesh('pebble', col); scene.add(m); lobRocks.push({ m, sh: makeShadow(0.3), x, y, z, tx, tz, T, h: 1.2 + Math.random() * 0.6, t: 0, dmg, col, els }); }
function updateLobRocks(dt) {
  for (let i = lobRocks.length - 1; i >= 0; i--) {
    const g = lobRocks[i]; g.t += dt; const k = Math.min(1, g.t / g.T), x = lerp(g.x, g.tx, k), z = lerp(g.z, g.tz, k), y = lerp(g.y, 0.15, k) + g.h * Math.sin(Math.PI * k);
    g.m.position.set(x, y, z); g.m.rotation.y = -Math.atan2(g.tz - g.z, g.tx - g.x); const sp = g.m.userData.spinZ; if (sp) sp.rotation.z -= dt * 14; g.sh.position.set(x, 0.04, z);
    if (k < 1) continue;
    scene.remove(g.m); scene.remove(g.sh); lobRocks.splice(i, 1);
    chunkDust(x, z, 0x9a8064); pebbles(x, 0.3, z, MOBILE ? 1 : 2); splat(x, z, 0x2a1e12, 0.35, 0.5); if (Math.random() < 0.4) sfx('thud');
    for (const e of [...enemies]) if (!e.dead && !e.hidden && Math.hypot(e.x - x, e.z - z) < 0.65 + e.r) hurtEnemy(e, g.dmg, e.x - x, e.z - z, 0.6, g.col, g.els);
  }
}
function resetLobRocks() { for (const g of lobRocks) { scene.remove(g.m); scene.remove(g.sh); } lobRocks.length = 0; }
// ---------- Spit Volley globs: a venom glob lobbed in an arc (0.42 s, 1.9 high), splats on landing: small aoe + venom
const spits = [], spitTg = [];
function lobSpit(x, y, z, tx, tz, dmg, els, col) { const m = makeProjMesh('venom', col); m.scale.setScalar(1.3); spits.push({ m, sh: makeShadow(0.35), x, y, z, tx, tz, t: 0, dmg, els, col }); sfx('spit'); }
function updateSpits(dt) {
  for (let i = spits.length - 1; i >= 0; i--) {
    const g = spits[i]; g.t += dt; const k = Math.min(1, g.t / 0.42), x = lerp(g.x, g.tx, k), z = lerp(g.z, g.tz, k), y = lerp(g.y, 0.2, k) + 1.9 * Math.sin(Math.PI * k);
    g.m.position.set(x, y, z); g.m.rotation.y = -Math.atan2(g.tz - g.z, g.tx - g.x); g.m.rotation.z = (0.5 - k) * 1.6; g.sh.position.set(x, 0.04, z);
    if (fxP(0.6)) spark(x, y, z, 0x7dff6a, { s: 0.35, life: 0.25, drag: 0 });
    if (k < 1) continue;
    scene.remove(g.m); scene.remove(g.sh); spits.splice(i, 1);
    burst(x, 0.3, z, 0x7dff6a, 12, 3.5, 0.3, 0.35); addRing(x, z, 0.15, 1.0, 0.25, 0x7dff6a); splat(x, z, 0x2a5a18, 0.6, 0.8); sfx('hiss');
    for (const e of [...enemies]) if (!e.dead && !e.hidden && Math.hypot(e.x - x, e.z - z) < 0.75 + e.r) hurtEnemy(e, g.dmg, e.x - x, e.z - z, 1, g.col, g.els);
  }
}
function resetSpits() { for (const g of spits) { scene.remove(g.m); scene.remove(g.sh); } spits.length = 0; }
// ---------- pebbles: small faceted rocks (the Boulder's stone) that tumble, bounce on the floor, settle and sink away. Pooled.
const PEB_N = 60, pebs = []; let pebHead = 0;
function pebbles(x, y, z, n) {
  for (let k = 0; k < n; k++) {
    let p = pebs[pebHead]; if (!p) { const m = new THREE.Mesh(rockGeo, boulderMat || (boulderMat = new THREE.MeshLambertMaterial({ color: 0x9a7a5a, emissive: 0x1a120a, flatShading: true }))); p = pebs[pebHead] = { m, t: 9 }; }
    pebHead = (pebHead + 1) % PEB_N;
    const a = Math.random() * 6.283, v = 1.5 + Math.random() * 3;
    Object.assign(p, { t: 0, x: x + rr(-0.2, 0.2), y, z: z + rr(-0.2, 0.2), vx: Math.cos(a) * v, vy: rr(0, 2), vz: Math.sin(a) * v, s: 0.12 + Math.random() * 0.16, rx: rr(-9, 9), rz: rr(-9, 9) });
    p.m.scale.setScalar(p.s); p.m.position.set(p.x, p.y, p.z); if (!p.m.parent) scene.add(p.m);
  }
}
function updatePebbles(dt) {
  for (const p of pebs) {
    if (!p || p.t > 1.6) continue; p.t += dt;
    if (p.t > 1.6) { scene.remove(p.m); continue; }
    p.vy -= 22 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    if (p.y < p.s * 0.4) { p.y = p.s * 0.4; p.vy = Math.abs(p.vy) > 2 ? -p.vy * 0.35 : 0; p.vx *= 0.6; p.vz *= 0.6; p.rx *= 0.6; p.rz *= 0.6; }
    p.m.rotation.x += p.rx * dt; p.m.rotation.z += p.rz * dt;
    const sink = p.t > 1.2 ? (p.t - 1.2) / 0.4 : 0; p.m.position.set(p.x, p.y - sink * p.s, p.z); p.m.scale.setScalar(p.s * (1 - sink * 0.6));
  }
}
// ---------- Rockfall stones: fall from y 7 in ~0.45 s (shadow grows under them), then hit everything within aoe
const stones = [];
function dropStone(x, z, dmg, aoe, els) {
  const g = new THREE.Group(), sc = 0.55 + Math.random() * 0.35;
  const r = new THREE.Mesh(rockGeo, boulderMat || (boulderMat = new THREE.MeshLambertMaterial({ color: 0x9a7a5a, emissive: 0x1a120a, flatShading: true }))); r.scale.setScalar(sc);
  const o = new THREE.Mesh(rockGeo, boulderEdge || (boulderEdge = new THREE.MeshBasicMaterial({ color: 0x140c06, side: THREE.BackSide }))); o.scale.setScalar(sc * 1.08);
  g.add(r, o); g.position.set(x, 7, z); g.rotation.set(Math.random() * 6, Math.random() * 6, 0); scene.add(g);
  const sh = makeShadow(0.6); sh.position.set(x, 0.03, z); sh.scale.setScalar(0.2);
  stones.push({ g, sh, x, z, y: 7, vy: 0, dmg, aoe, els, sc });
}
function updateStones(dt) {
  for (let i = stones.length - 1; i >= 0; i--) {
    const s = stones[i]; s.vy -= 34 * dt; s.y += s.vy * dt; s.g.position.y = s.y; s.g.rotation.x += dt * 3;
    s.sh.scale.setScalar(0.25 + 0.9 * (1 - s.y / 7));
    if (s.y > s.sc * 0.4) continue;
    scene.remove(s.g); scene.remove(s.sh); stones.splice(i, 1);
    chunk(s.x, 0.4, s.z, 0x9a7a5a, 5, 5, 0.18); chunk(s.x, 0.3, s.z, 0x6a5038, 3, 4, 0.24); chunkDust(s.x, s.z, 0xb09878); chunkDust(s.x, s.z, 0x8a6a4a);
    addRing(s.x, s.z, 0.2, s.aoe * 1.2, 0.3, 0xc8a878); splat(s.x, s.z, 0x2a1e12, s.aoe * 0.8, 0.7); addShake(0.06); sfx('thud');
    for (const e of [...enemies]) if (!e.dead && !e.hidden && Math.hypot(e.x - s.x, e.z - s.z) < s.aoe + e.r) hurtEnemy(e, s.dmg, e.x - s.x, e.z - s.z, 3, 0xb0a090, s.els);
    for (const pot of [...pots]) if (Math.hypot(pot.x - s.x, pot.z - s.z) < s.aoe) breakPot(pot);
  }
}
function resetStones() { for (const s of stones) { scene.remove(s.g); scene.remove(s.sh); } stones.length = 0; }
// ---------- Void Maw: a real black hole (user 11-15: "void maw is shit", "have some black sprite blackhole") ----------
// a swirling accretion disc on the floor (painted once into a small canvas: black middle, violet ring, spiral arms), a second
// faster swirl on top turning the other way, a black core floating over it with a violet rim glow. It opens with a pop, grows
// while it drags foes in (sparks streak inward), implodes for the last 0.18 s, then detonates: flash, double shockwave, burst.
let holeTex = null, holeSwirlTex = null, holeCoreGeo = null;
function holeTextures() {
  if (holeTex) return;
  const mk = (arms, inner) => {
    const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d'); g.translate(128, 128);
    const rg = g.createRadialGradient(0, 0, 0, 0, 0, 128);
    if (inner) { rg.addColorStop(0, 'rgba(0,0,0,1)'); rg.addColorStop(0.24, 'rgba(4,0,10,1)'); rg.addColorStop(0.32, 'rgba(110,40,190,.9)'); rg.addColorStop(0.42, 'rgba(55,12,110,.8)'); rg.addColorStop(0.7, 'rgba(20,3,45,.45)'); rg.addColorStop(1, 'rgba(10,0,30,0)'); }
    else { rg.addColorStop(0, 'rgba(0,0,0,0)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); }
    g.fillStyle = rg; g.fillRect(-128, -128, 256, 256);
    g.globalCompositeOperation = 'source-over'; // not 'lighter': stacked dots went white (user: base image darker)
    for (let a = 0; a < arms; a++) for (let i = 0; i < 90; i++) { // spiral arms of soft dots, fading toward the rim
      const t = i / 90, r = 30 + t * 95, ang = a / arms * Math.PI * 2 + t * 4.2, sz = 2 + (1 - t) * 6;
      g.fillStyle = `rgba(${70 + 60 * (1 - t) | 0},${10 + 25 * (1 - t) | 0},${150 + 60 * (1 - t) | 0},${0.45 * (1 - t) + 0.08})`;
      g.beginPath(); g.arc(Math.cos(ang) * r, Math.sin(ang) * r, sz, 0, 6.2832); g.fill();
    }
    if (inner) { g.globalCompositeOperation = 'source-over'; const cg = g.createRadialGradient(0, 0, 0, 0, 0, 34); cg.addColorStop(0, '#000'); cg.addColorStop(0.85, '#000'); cg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = cg; g.beginPath(); g.arc(0, 0, 34, 0, 6.2832); g.fill(); }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  };
  try { holeTex = mk(3, true); holeSwirlTex = mk(5, false); } catch (e) { holeTex = holeSwirlTex = null; }
  holeCoreGeo = new THREE.CircleGeometry(0.5, 40).rotateX(-Math.PI / 2); // a flat black event horizon on the floor (user 11-15: not a sphere)
}
const holePlane = new THREE.PlaneGeometry(1, 1);
function makeHole(x, z) {
  holeTextures();
  const h = { x, z, t: 0, dur: 2.2, glow: makeGlowAt(x, 0.2, z, 0x6a1aff, 3.5, 0.45), meshes: [] };
  const flat = (tex, y, op) => { if (!tex) return null; const m = new THREE.Mesh(holePlane, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, opacity: op })); m.rotation.x = -Math.PI / 2; m.position.set(x, y, z); m.renderOrder = 2; scene.add(m); h.meshes.push(m); return m; };
  h.disc = flat(holeTex, 0.09, 1); h.swirl = flat(holeSwirlTex, 0.11, 0.9);
  h.core = new THREE.Mesh(holeCoreGeo, new THREE.MeshBasicMaterial({ color: 0x000000, depthWrite: false, ...DECAL })); h.core.renderOrder = 5; h.core.position.set(x, 0.13, z); scene.add(h.core); h.meshes.push(h.core);
  addRing(x, z, 0.2, 2.2, 0.3, 0x9a4aff); burst(x, 0.7, z, 0x220833, 16, 5, 0.4, 0.4); // the tear opens
  return h;
}
function killHole(h) { killGlow(h.glow); for (const m of h.meshes || []) { scene.remove(m); if (m.material) m.material.dispose(); } h.meshes = []; }
function castLegendary(s, def, target) {
  if (s.id === 'meteor') { strikes(9, target, 2.3, 75 + G.floor * 10, 0xff6a1a, ['fire'], 0.17); sfx('fire'); for (let k = 0; k < 9; k++) later(0.65 + k * 0.17, () => { addShake(0.25); sfx('meteor'); }); } // a legendary storm of real meteors (user 11-15: the plain Meteor looked stronger): 9 bigger rocks, more damage
  if (s.id === 'hole') { holes.push(makeHole(target.x, target.z)); sfx('portal'); }
  if (s.id === 'still') {
    G.still = 2.5;
    for (const e of enemies) e.freeze = Math.max(e.freeze, 2.5 * (e.isBoss ? 0.5 : 1)); // stopped time beats resistance, bosses half
    stillTint(true); later(2.5, () => stillTint(false));
    flash(0.5); addShake(0.3); sfx('frost');
  }
}
// boss spells: each boss's own attack, now yours
function castBossSpell(s, def, target, px, pz, py, a, col) {
  const dmg = def.dmg * lvMul(s.lv), els = def.els, area = player.area * player.g.area * player.der.area;
  switch (def.sh.beh) {
    case 'gloop': addGloop(target.x, target.z, 1.5 * area, dmg, els, col, 10 + s.lv * 2); /* smaller first impact (user 11-15: too big; was 2.2) */ sfx('whoosh'); break; // a goo blob drops, splats (updateGloops)
    case 'bones': { // Bone Boomerang: a giant bone loops round Pip and comes home (updateBoomerangs)
      const lv5 = s.lv >= 5, k = Math.sqrt(area), sc = (lv5 ? 0.55 : 0.42) * k, dur = lv5 ? 1.15 : 1.45;
      const aa = Math.atan2(target.z - player.z, target.x - player.x), R = Math.max(3.2, Math.min(5.5, Math.hypot(target.x - player.x, target.z - player.z) + 0.6)) * k;
      // the tour: every foe within 9 tiles (up to 20), nearest-next from Pip; Lv 3's second bone takes it in reverse
      const tour = [], seen = new Set(); let cx = player.x, cz = player.z;
      for (const e of enemies) if (e.dead || e.hidden || e.spawn < 0.3 || Math.hypot(e.x - player.x, e.z - player.z) > 12) seen.add(e); // only foes within 12 tiles of Pip
      for (let q = 0; q < 24; q++) { const e = nearestEnemy(cx, cz, 30, seen); if (!e) break; tour.push(e); seen.add(e); cx = e.x; cz = e.z; } // all of them, nearest-next (user: 'not hitting all')
      const b1 = addBoomerang(aa, 1, R, 99, sc, dmg, els, col); if (b1) { b1.hunt = true; b1.tour = tour; }
      if (s.lv >= 3) { const b2 = addBoomerang(aa, -1, R, 99, sc, dmg, els, col); if (b2) { b2.hunt = true; b2.tour = tour.slice().reverse(); } }
      addRing(player.x, player.z, 0.3, 1.5, 0.25, 0xc9a8ff); // the throw: a whoosh ring and ivory dust off Pip's hand
      for (let q = fxN(8); q > 0; q--) spark(player.x, 0.9, player.z, 0xf4ecdc, { vx: Math.cos(aa) * 6, vz: Math.sin(aa) * 6, vy: 0.8, s: 0.3, life: 0.28, drag: 4, spread: 4 });
      sfx('whoosh');
      break;
    }
    case 'gaze': { // like the Hollow Eye (user 11-15): a little Hollow Eye is summoned over the foes and turns a cross of 4 beams
      // from its pupil ("place the orb somewhere and have the beams stay there, not on the staff"; damage 0.8 a beam: was underwhelming)
      // its spot: open floor between Pip and the foes, never on a monster (user 11-15) - the first of a few candidates with no foe
      // within 1.1 tiles and no wall, else the halfway point
      const ta = Math.atan2(target.z - pz, target.x - px), td = Math.hypot(target.x - px, target.z - pz);
      let ox = px + Math.cos(ta) * td * 0.5, oz = pz + Math.sin(ta) * td * 0.5;
      for (const [da, dd] of [[0, 0.5], [0.5, 0.55], [-0.5, 0.55], [0.9, 0.6], [-0.9, 0.6], [0, 0.3]]) {
        const cx = px + Math.cos(ta + da) * Math.max(1.4, td * dd), cz = pz + Math.sin(ta + da) * Math.max(1.4, td * dd);
        if (!solid(cx, cz, true) && !enemies.some((e) => !e.dead && Math.hypot(e.x - cx, e.z - cz) < 1.1 + e.r)) { ox = cx; oz = cz; break; }
      }
      const eye = new THREE.Mesh(gazeOrbGeo || (gazeOrbGeo = new THREE.SphereGeometry(0.28, 16, 12)), new THREE.MeshBasicMaterial({ color: new THREE.Color(col).lerp(new THREE.Color(0xffffff), 0.55) })); scene.add(eye); // a glowing orb (user: not the boss sprite)
      rays.push({ sweep: true, lock: [], spokes: 4, ox, oz, eye, eyeGlow: makeGlowAt(ox, 1.2, oz, col, 2.2, 0.7), a0: a - 0.8, arc: 2.4, t: 2, dur: 2, tick: 0, n: 0, dmg: dmg * 0.8, els, color: col, range: 7, lasers: [] });
      addRing(ox, oz, 0.2, 1.8, 0.3, col); burst(ox, 1.2, oz, col, 14, 4, 0.35, 0.4); sfx('zap'); break;
    } // was the 1.5 s laser hum on every cast
    case 'spores': {
      const n = 16 + s.lv * 2;
      for (let k = 0; k < n; k++) later(k * 0.08, () => { if (!player.alive) return; for (let q = 0; q < 2; q++) addProj({ kind: 'venom', x: player.x, z: player.z, y: 0.7, a: k * 0.4 + q * Math.PI, speed: 8, dmg, r: 0.22, color: col, size: 0.7, life: 0.9, els }); });
      sfx('spit');
      break;
    }
    case 'rocks': { // Rockfall (user 11-15: "should not be like a meteor"): real stones drop straight down from the ceiling onto
      // the foes - a growing shadow, a faceted boulder, then dust, debris, a crater and a thud. No fire, no glow. Same hits/aoe.
      const n = 8 + s.lv * 2, foes = enemies.filter((e) => !e.dead && !e.hidden);
      for (let k = 0; k < n; k++) { const e = foes.length ? pick(foes) : target, x = e.x + rr(-0.9, 0.9), z = e.z + rr(-0.9, 0.9); later(k * 0.08, () => { if (player.alive && cellAt(x, z) === FLOOR) dropStone(x, z, dmg, 1.3 * area, els); }); }
      addShake(0.2); sfx('slam'); break;
    }
    case 'souls': {
      for (let k = 0; k < 4 + s.lv; k++) addProj({ kind: 'soul', x: px, z: pz, y: py, a: a + rr(-1.4, 1.4), speed: 7, dmg, r: 0.28, color: col, size: 0.9, homing: 4, target, life: 2.4, els }); // ghost-face teardrops with a streaming tail (user 11-15 picked these)
      sfx('orb'); // was the 2.8 s ghost moan: on every cast it played as a looping wail
      break;
    }
    case 'coins': { // a fan of gold; whatever it finishes coughs up extra coins
      const n = 4 + s.lv, bag = { n: s.lv >= 4 ? 4 : 3 }; // up to 3 (Lv 4+: 4) real coin pickups per cast, 1 gold each
      for (let k = 0; k < n; k++) addProj({ kind: 'coin', x: px, z: pz, y: py, a: a + (k - (n - 1) / 2) * 0.22, speed: 9, dmg, r: 0.24, color: 0xffd34f, size: 0.7, life: 1.1, els, gold: true, bag, scale: 1.7 }); // real spinning coins
      spark(px, py, pz, 0xfff6c8, { s: 1.3, life: 0.12, drag: 0 }); // the toss: a gold flash and a spray of glints off the staff
      for (let k = fxN(8); k > 0; k--) spark(px, py, pz, Math.random() < 0.5 ? 0xffffff : 0xffd34f, { vx: Math.cos(a) * 5, vz: Math.sin(a) * 5, vy: 1.5, s: 0.25, life: 0.3, drag: 3, spread: 4 });
      sfx('coin'); sfx('coin', 7);
      break;
    }
    case 'fring': { // Frost Ring = the Frost Matriarch's burst (user 11-15: "make it like the boss, frost diver 8 directions"):
      // 8 Frost Diver lines race out all around Pip (turned a little each cast), each foe hit once: damage + freeze
      const R = (2.6 + s.lv * 0.3) * area, hit = new Set(), a0 = (G.time * 0.7) % (Math.PI / 4);
      for (let k = 0; k < 8; k++) diverLine(px, pz, a0 + k * Math.PI / 4, R - 1, dmg, 1.4, hit);
      addRing(px, pz, 0.2, 1.6, 0.3, 0x9fe8ff); addShake(0.12); sfx('frost');
      break;
    }
    case 'gears': { // Gear Storm (user 11-15: "big razor blades, multiple, 4 directions, stay at the destination a couple of
      // seconds, then come back"): big brass saw blades fly out in a cross (8 at Lv 5), grind in place 2 s, then return to Pip
      const n = s.lv >= 5 ? 8 : 4, a0 = Math.atan2(target.z - pz, target.x - px), L = (3.6 + 0.2 * s.lv) * Math.sqrt(area);
      for (let k = 0; k < n; k++) addSaw(px, pz, a0 + k * Math.PI * 2 / n, L, dmg, els);
      sfx('whoosh'); break;
    }
  }
}
// ---------- status effects ----------
// how strongly a status lands: the monster's resistance to that element (0 = immune) times its toughness against control
const TENACITY = { big: 0.7, golem: 0.4, runegolem: 0.4, crystalgolem: 0.4, magmagolem: 0.4, skeleton: 0.85, cursed: 0.85, reaper: 0.85, boneknight: 0.6, shieldk: 0.6, beetle: 0.7, mimic: 0.6 };
function statusMul(e, el) { return Math.min(1.5, resistOf(e.type, [el], e.affinity)); }
function ccMul(e) { return (TENACITY[e.type] || 1) * (e.isBoss ? 0.35 : e.name ? 0.5 : e.elite ? 0.7 : 1); }
function ccFreeze(e, dur) { const k = statusMul(e, 'frost') * ccMul(e); if (k > 0.05) e.freeze = Math.max(e.freeze, dur * k); }
function applyStatus(e, els, dmg) {
  const pw = player.der.status;
  for (const el of els) {
    const f = statusMul(e, el);
    if (f <= 0) continue; // immune: no status at all
    switch (el) {
      case 'fire': e.burn = 3 * Math.min(1, f); e.burnDps = Math.max(e.burnDps || 0, dmg * 0.3 * pw * f); break;
      case 'frost': { // resistant foes slow less and need more chills to freeze
        const c = ccMul(e);
        e.slow = Math.max(e.slow, 2 * Math.min(1, f)); e.slowAmt = Math.max(e.slowAmt || 0, Math.min(0.6, 0.5 * f * (0.5 + 0.5 * c)));
        if (e.isBoss || (e.ice && e.freeze > 0)) break; // bosses only slow; a frozen foe waits for the shattering hit
        e.chill = (e.chill || 0) + f * c;
        if (e.chill >= 3) { // 3 chills: FROZEN for 1.6s; the next hit of any kind shatters it (elementOnHit)
          e.chill = 0; ccFreeze(e, 1.6);
          if (e.freeze > 0) { e.ice = true; addText(e.x, 1.6, e.z, 'FROZEN', '#9fe8ff', 0.9); burst(e.x, 0.7, e.z, 0xbff4ff, 10, 3, 0.35, 0.4); }
        }
        break;
      }
      case 'storm': e.shock = 2.5 * Math.min(1, f); e.shockAmt = 0.25 * f; break;
      case 'venom': e.poison = 4; e.pstacks = Math.min(Math.max(1, Math.round(8 * Math.min(1, f))), (e.pstacks || 0) + 1); e.poisonDps = Math.max(e.poisonDps || 0, dmg * 0.1 * e.pstacks * pw * f); break;
      case 'shadow': e.curse = 4 * Math.min(1, f); e.curseDmg = Math.max(e.curseDmg || 0, dmg * 1.5 * pw * f); break;
      // earth: its stun is in elementOnHit (direct hits only, never bosses)
    }
  }
}
// damage from beams and fields: no knockback, numbers only now and then
function dotHit(e, dmg, color, els, show) {
  if (e.dead) return;
  const g = player.g;
  let d = dmg * player.dmgMul * g.dmg * player.der.dmg * strMul(e) * resistOf(e.type, els, e.affinity);
  if (els.includes('holy') && UNDEAD.has(e.type)) d *= 2;
  if (e.shock > 0) d *= 1 + (e.shockAmt || 0.25);
  if (DMGLOG) DMGLOG[color] = (DMGLOG[color] || 0) + Math.min(d, Math.max(0, e.hp));
  G.run.dmg += Math.min(d, Math.max(0, e.hp)); e.hp -= d; e.flash = Math.max(e.flash, 0.3); e.lastEls = els;
  applyStatus(e, els, d);
  if (show) dmgText(e, 1.1, d, cssOf(color), 0.8);
  if (e.hp <= 0) killEnemy(e);
}
// ---------- leveling (Ragnarok-style stat points) ----------
function gainXp(n) {
  const p = player; if (G.prologue || ZOO) return; // no level-up cards in the prologue (or the zoo)
  p.xp += n * (G.xpMul || 1); // floors with calm rooms pay more per kill (genFloor)
  while (p.xp >= xpNeed(p.lv)) {
    p.xp -= xpNeed(p.lv); p.lv++; G.lvPicks = (G.lvPicks || 0) + 1; G.lvPickT = 0.7; // a power pick follows the banner (spells and stat boosts)
    banner('LEVEL UP', `LEVEL ${p.lv}`); bannerT = 1.2; sfx('levelup');
    burst(p.x, 1, p.z, 0xffe14f, 24, 4, 0.4, 0.7);
  }
}
// No stat points to spend in a run any more (user decision): stats grow from STAT BOOST level-up cards (statCard).
// Points that are still around (an old save, a Lucky Chest roll) go into the hero's main stat, at the usual point cost.
const MAIN_STAT = { mage: 'int', archer: 'dex', warrior: 'str', hunter: 'str' };
function flushRunPts() {
  const p = player; if (!p || !(p.statPts > 0)) return false;
  const k = MAIN_STAT[p.hero.cls] || 'int';
  while (p.statPts > 0) { const c = ptCost(p, k); p.alloc[k]++; p.statPts -= c; } // a last partial point still counts
  p.statPts = 0; return true;
}
// a STAT BOOST card: +n to one stat, with what it does read off derive ("+3 INT · +30% damage") and the milestone it unlocks
const STAT_COL = { str: '#ff9a5a', int: '#c78cff', dex: '#7fd8ff', agi: '#8affc0', luk: '#ffd34f', vit: '#ff6a8a' };
const STAT_ICON = { str: 'relic_lode', int: 'up_pow', dex: 'up_haste', agi: 'up_swift', luk: 'up_fate', vit: 'up_vit' };
function statCard(k, n = 2) { // +2 a card (was +3: INT +3 = +30% damage every level was too much by floor 4)
  const p = player, ms = MILESTONES[k].find(([v]) => p.st[k] < v && p.st[k] + n >= v);
  const gains = statGains(k, n), info = `${gains.slice(0, 2).join(' · ') || 'closer to the next milestone'}${ms ? ` · UNLOCKS ${ms[0]}: ${ms[1]}` : ''}`;
  return { w: 1, stat: k, tag: ms ? 'STAT BOOST ✦ MILESTONE' : 'STAT BOOST', name: `${STAT_NAMES[k]} +${n}`, info, color: STAT_COL[k], icon: iconPath(STAT_ICON[k]) || ['items', 3],
    pick: () => {
      const t0 = p.der.T[k]; p.alloc[k] += n; recalcStats();
      if (p.der.T[k] > t0) { const m = MILESTONES[k][p.der.T[k] - 1]; toast(`${STAT_NAMES[k]} ${m[0]} UNLOCKED`, m[1]); later(0.1, () => sfx('levelup')); burst(p.x, 1, p.z, 0xffe14f, 30, 5, 0.45, 0.7); }
    } };
}
// 1 stat card per level-up, a second one about 1 time in 3; the hero's main stat and VIT come up most
function statCards() {
  const main = MAIN_STAT[player.hero.cls] || 'int', w = (k) => (k === main ? 3 : k === 'vit' ? 2 : 1);
  const ks = weightedSample(STATS.slice(), w, 2);
  return (rand() < 0.4 ? ks.slice(0, 1) : []).map((k) => statCard(k)); // a stat card on ~40% of level-ups, never two (user 11-15: too many stats)
}
// first level-up of a run = a POWER PICK (user 11-15: "the early game is underwhelming"): 3 showy spells the user chose, never a
// stat card or a legendary - Phoenix, Chain Lightning and one of Frozen Orb / Frost Diver (one per element). Offered even when
// the element is still locked (a taste of Storm before the Hollow Eye unlocks it for the normal card pool).
const WOW_SPELLS = ['fire.ring', 'storm.chain', 'frost.frozenorb', 'frost.trap'];
function wowOptions() {
  const owned = new Set(spells.map((s) => s.id)), pool = WOW_SPELLS.filter((id) => spellDef(id) && !owned.has(id));
  if (pool.length < 2) return null;
  return variedSample(pool, () => 1, 3).map((id) => { const d = spellDef(id), isNew = !meta.codex.includes(id);
    return { shape: d.shape, newEl: d.els[0], sim: (L) => L.concat({ id, lv: 1 }), tag: `★ POWER PICK${isNew ? ' ✦ NEW' : ''}`, name: d.name, info: `${d.info} · ${d.cd}s`, color: d.color, icon: spellIcon(d),
      pick: () => { player.wowDone = true; spells.push({ id, lv: 1, t: 0.2 }); discover(id); flash(0.35); sfx('clear'); } }; });
}
// reaching level 3 in a normal run = a RARE PICK (user 11-15: "lvl 3 should give 1 tier 2"): 3 RARE signature spells from your
// unlocked elements (not owned, one per element), no stat card. Skipped if the pool has none.
function rareOptions() {
  const owned = new Set(spells.map((s) => s.id)), pool = SIG_IDS.filter((id) => !CUT_IDS.has(id) && SIGNATURE[id].tier === 1 && elOk(SIGNATURE[id].el) && !owned.has(id));
  if (!pool.length) return null;
  return variedSample(pool, () => 1, 3).map((id) => { const d = spellDef(id), isNew = !meta.codex.includes(id);
    return { shape: d.shape, newEl: d.els[0], sim: (L) => L.concat({ id, lv: 1 }), tag: `◆ RARE PICK${isNew ? ' ✦ NEW' : ''}`, name: d.name, info: `${d.info} · ${d.cd}s`, color: d.color, icon: spellIcon(d),
      pick: () => { player.rareDone = true; spells.push({ id, lv: 1, t: 0.2 }); discover(id); flash(0.3); sfx('clear'); } }; });
}
function levelUpOptions() {
  if (!player.wowDone && player.lv <= 3 && !G.prologue) { const w = wowOptions(); if (w) return w; }
  return levelOffer(); // rareOptions (the old 3-Rare pick at Lv 3) is replaced by levelOffer's Rare card every 3rd level
}
// a stat's permanent part (hero base + Sanctum buys + victories + legacy) and its run part (level-up points this run)
const permOf = (p, k) => (p.hero.base[k] || 0) + ((p.metaAlloc || {})[k] || 0);
const runOf = (p, k) => (p.alloc[k] || 0) - ((p.metaAlloc || {})[k] || 0);
const ptCost = (p, k) => statPtCost((p.hero.base[k] || 0) + (p.alloc[k] || 0)); // gear doesn't make points pricier
// everything that feeds the player's numbers: hero base stats + points spent + gear
function recalcStats() {
  const p = player, t = gearTotals(p.gear), st = {};
  for (const k of STATS) st[k] = (p.hero.base[k] || 0) + (p.alloc[k] || 0) + (t.st[k] || 0);
  const der = derive(p.hero.cls, st, p.hero.base), bonusHp = t.hp + der.hearts * 2, delta = bonusHp - (p.bonusHp || 0);
  p.maxHp = Math.max(2, p.maxHp + delta); if (delta > 0) p.hp += delta; p.hp = Math.min(p.hp, p.maxHp);
  p.bonusHp = bonusHp; p.st = st; p.der = der; p.g = t;
  if (!p.statPts) $('pauseBtn').classList.remove('pts');
  renderHearts();
}
// ---------- gear ----------
function dropGear(x, z, minR, given = null, armed = !given) {
  if (ZOO) return null;
  const item = given || rollGear(rand, G.floor, player.g.luck + player.der.loot, minR);
  const col = hexOf(RARITY[item.rarity].color);
  // a thick additive light pillar plus a big glow so drops read from across the room
  const beam = new THREE.Mesh(new THREE.BoxGeometry(0.26, 5, 0.26), new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
  scene.add(beam);
  const a = Math.random() * Math.PI * 2, v = given ? 1.2 : rr(1, 2.5);
  pickups.push({ kind: 'gear', item, x, z, y: 0.4, vx: Math.cos(a) * v, vz: Math.sin(a) * v, vy: given ? 4 : rr(5, 7), mesh: makeSprite('gear', 0.6, SLOTS.indexOf(item.slot)), shadow: makeShadow(0.4), t: 0, spin: 0, beam, glow: makeGlow(col, 3.6, 1), armed });
}
// standing on gear for a taken slot: what you wear now vs what you'd swap to, while the 3-second ring fills
function showSwapCompare(cur, next) {
  let el = $('swapCmp'); if (!el) { el = document.createElement('div'); el.id = 'swapCmp'; $('app').appendChild(el); }
  const row = (tag, it) => `<div class="cmp"><small>${tag}</small><b style="color:${RARITY[it.rarity].color}">${it.name}</b><span>${RARITY[it.rarity].name} ${SLOT_NAMES[it.slot]}</span><p>${gearLines(it).join('<br>')}</p></div>`;
  const diff = gearScore(next) - gearScore(cur), verdict = diff > 0 ? '<em class="up">▲ BETTER</em>' : diff < 0 ? '<em class="down">▼ WEAKER</em>' : '<em>= SIMILAR</em>';
  el.innerHTML = `<div class="cmphead">SWAP? STAND STILL 3s ${verdict}</div><div class="cmpgrid">${row('WEARING', cur)}<i>➜</i>${row('ON THE FLOOR', next)}</div>`;
  el.className = 'show';
}
function hideSwapCompare() { const el = $('swapCmp'); if (el) el.className = ''; G.cmpFor = null; }
// gear never goes to a bag: an empty slot equips it, otherwise it lands on the floor next to you for the 3-second swap
function equipOrStash(item, force = false) {
  const p = player, cur = p.gear[item.slot], R = RARITY[item.rarity];
  if (cur && !force) { dropGear(p.x, p.z, 0, item, true); toast(`<span style="color:${R.color}">${item.name}</span>`, `ON THE FLOOR · STAND ON IT 3s TO SWAP`); return; }
  if (cur) dropGear(p.x, p.z, 0, cur); // swapped out: waits on the floor until you step off it
  p.bag = p.bag.filter((it) => it !== item);
  p.gear[item.slot] = item; recalcStats(); sfx('card');
  toast(`<span style="color:${R.color}">${item.name}</span>`, `EQUIPPED · ${gearLines(item).join(' · ')}`);
}
function gearCard(minR) {
  const item = rollGear(rand, G.floor, player.g.luck + player.der.loot, minR), R = RARITY[item.rarity];
  return { gear: true, tag: `${R.name.toUpperCase()} ${SLOT_NAMES[item.slot].toUpperCase()}`, name: item.name, info: gearLines(item).join(', '), color: R.color, icon: gearIcon(item), legend: item.rarity === 3, pick: () => equipOrStash(item) };
}
function discover(id) {
  if (meta.codex.includes(id)) return;
  meta.codex.push(id); saveMeta();
  if (G.state === 'play' || G.state === 'cards') later(0.3, () => toast('NEW SPELL DISCOVERED', `${spellDef(id).name} · codex ${meta.codex.length}/${TOTAL_SPELLS}`));
}
function bossReward(e) {
  if (ZOO) return;
  const id = Object.keys(BOSS_SPELLS).find((k) => BOSS_SPELLS[k].boss === e.type);
  if (!id) return;
  G.bossSpell = id;
  const el = BOSS_SPELLS[id].unlocks;
  if (el && !meta.elements.includes(el)) { meta.elements.push(el); saveMeta(); later(2, () => toast('ELEMENT UNLOCKED', `${ELEMENTS[el].name} spells can now appear`)); }
}
// ---------- icons: element emblem(s) + a shape glyph badge ----------
const iconCache = new Map();
function elementIconSrc(el) { return el === 'venom' ? ['spells', 5] : ['elements', ELEMENTS[el].icon]; }
let ICONS = new Set();
const iconPath = (name) => (ICONS.has(name) ? `icons/${name}.webp` : null);
const gearIcon = (it) => iconPath(`gear_${it.slot}_${it.rarity}`) || iconURL('gear', SLOTS.indexOf(it.slot));
const elemIcon = (el) => iconPath('el_' + el) || iconURL(...elementIconSrc(el));
function spellIcon(def) {
  const painted = iconPath(def.sig ? def.els[0] + '.' + def.shape : def.id.replace('+', '_')); // signature spells reuse their base shape's painted icon
  if (painted) return painted;
  if (iconCache.has(def.id)) return iconCache.get(def.id);
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'); let miss = false;
  if (!g) return def.els && ELEMENTS[def.els[0]] ? iconURL(...elementIconSrc(def.els[0])) : iconURL('spells', 0);
  g.imageSmoothingEnabled = true;
  const drawIcon = (src, clip) => {
    const s = sheets[src[0]]; if (!s || pending.has(src[0])) miss = true; if (!s) return;
    g.save(); if (clip) clip();
    const k = 56 / Math.max(s.w, s.h);
    g.drawImage(s.canvas, src[1] * s.w, 0, s.w, s.h, 32 - s.w * k / 2, 32 - s.h * k / 2, s.w * k, s.h * k);
    g.restore();
  };
  if (def.bossSpell) drawIcon([({ boss: 'boss', tyrant: 'tyrant', eyeboss: 'hollow', sporeboss: 'sporemother', golemboss: 'stoneking', wraithboss: 'wraith', mimiclord: 'mimiclord', frostboss: 'frostmatriarch', sentinel: 'sentinel' })[def.boss], 0]);
  else if (def.legendary) drawIcon(['spells', { meteor: 1, hole: 4, still: 2 }[def.id]]);
  else if (def.fused) {
    drawIcon(elementIconSrc(def.els[0]), () => { g.beginPath(); g.moveTo(0, 0); g.lineTo(64, 0); g.lineTo(0, 64); g.clip(); });
    drawIcon(elementIconSrc(def.els[1]), () => { g.beginPath(); g.moveTo(64, 0); g.lineTo(64, 64); g.lineTo(0, 64); g.clip(); });
  } else drawIcon(elementIconSrc(def.els[0]));
  if (def.shape && SHAPES[def.shape]) {
    g.fillStyle = 'rgba(10,8,20,.85)'; g.beginPath(); g.arc(50, 50, 13, 0, 7); g.fill();
    g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineWidth = 2.2; g.lineCap = 'round';
    drawGlyph(g, def.shape, 50, 50);
  }
  if (def.unique) { // unique spells: a white diamond badge
    g.fillStyle = 'rgba(10,8,20,.85)'; g.beginPath(); g.arc(50, 50, 13, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.moveTo(50, 41); g.lineTo(58, 50); g.lineTo(50, 59); g.lineTo(42, 50); g.closePath(); g.fill();
    g.fillStyle = def.color; g.beginPath(); g.moveTo(50, 45); g.lineTo(54, 50); g.lineTo(50, 55); g.lineTo(46, 50); g.closePath(); g.fill();
  }
  const url = c.toDataURL(); c.width = c.height = 0;
  if (url.length < 32) return def.els && ELEMENTS[def.els[0]] ? iconURL(...elementIconSrc(def.els[0])) : iconURL('spells', 0); // no canvas memory: the plain element icon
  if (!miss) iconCache.set(def.id, url); // art still loading: draw it again next time
  return url;
}
function drawGlyph(g, shape, x, y) {
  const L = (a, b, c, d) => { g.beginPath(); g.moveTo(x + a, y + b); g.lineTo(x + c, y + d); g.stroke(); };
  const C = (cx, cy, r, fill) => { g.beginPath(); g.arc(x + cx, y + cy, r, 0, 7); fill ? g.fill() : g.stroke(); };
  switch (shape) {
    case 'bolt': L(-6, 4, 6, -4); L(6, -4, 1, -4); L(6, -4, 5, 1); break;
    case 'lance': L(-8, 6, 8, -6); L(8, -6, 3, -6); L(8, -6, 7, -1); L(-8, 2, -4, 6); break;
    case 'orb': C(0, 0, 5, true); break;
    case 'nova': C(0, 0, 7); C(0, 0, 2, true); break;
    case 'chain': g.beginPath(); g.moveTo(x - 7, y - 5); g.lineTo(x - 1, y - 1); g.lineTo(x - 4, y + 1); g.lineTo(x + 7, y + 6); g.stroke(); break;
    case 'halo': C(0, -6, 2, true); C(5, 4, 2, true); C(-5, 4, 2, true); C(0, 0, 6); break;
    case 'fan': L(-6, 6, -7, -4); L(-6, 6, 0, -7); L(-6, 6, 7, -3); break;
    case 'rain': L(-5, -6, -7, 0); L(0, -4, -2, 2); L(5, -6, 3, 0); C(0, 6, 2, true); break;
    case 'burst': for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; L(Math.cos(a) * 3, Math.sin(a) * 3, Math.cos(a) * 7, Math.sin(a) * 7); } break;
    case 'field': g.globalAlpha = 0.5; C(0, 2, 7, true); g.globalAlpha = 1; C(0, 2, 7); break;
    case 'glaive': g.beginPath(); g.arc(x, y, 6, 0.3, 5.2); g.stroke(); L(4, -4, 7, -7); break;
    case 'sigil': g.beginPath(); g.moveTo(x, y - 7); g.lineTo(x + 7, y); g.lineTo(x, y + 7); g.lineTo(x - 7, y); g.closePath(); g.stroke(); C(0, 0, 1.5, true); break;
    case 'ray': g.lineWidth = 4; L(-7, 5, 7, -5); g.lineWidth = 2.2; break;
    case 'wisp': C(0, -2, 4, true); L(-3, 2, -5, 7); L(0, 2, 0, 7); L(3, 2, 5, 7); break;
  }
}
const coinGeoV = coinGeo.clone().rotateX(Math.PI / 2); // a coin on its edge (face toward z): spinning on y flips it
const PG = {
  puff: (() => { const g = new THREE.IcosahedronGeometry(0.15, 1), p = g.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i), k = 1 + 0.22 * Math.sin(x * 40) * Math.sin(y * 37 + 1) * Math.sin(z * 33 + 2); p.setXYZ(i, x * k, y * k, z * k); } return g; })(), // a lumpy spore puff
  face: (() => { const parts = [[0.15, 0, 0.06, 0.04, 0.07, 0.05], [0.15, 0, -0.06, 0.04, 0.07, 0.05], [0.17, -0.09, 0, 0.04, 0.05, 0.07]].map(([x, y, z, a, b, c]) => new THREE.BoxGeometry(a, b, c).translate(x, y, z)); return phxGeo(parts.map((g) => [g, () => [0, 0, 0]])); })(), // a soul's eyes + mouth in one mesh
  shard: new THREE.OctahedronGeometry(0.15, 0),
  ball: new THREE.IcosahedronGeometry(0.16, 1),
};
const projMats = new Map();
function pMat(color, add, opacity = 1) {
  const key = color + '|' + add + '|' + opacity;
  if (!projMats.has(key)) projMats.set(key, new THREE.MeshBasicMaterial(add ? { color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false } : { color }));
  return projMats.get(key);
}
// solid core + glowing shell(s); x axis points along the flight direction
const projPool = new Map(); // 'kind|color' -> spent projectile meshes: a new Group + 2-3 Meshes per shot was steady garbage in big fights
let gazeOrbGeo = null, scytheGeo = null, boulderMat = null, boulderEdge = null;
let magmaMat = null;
const LOOK_KIND = { steam: 'steam', napalm: 'fire', magma: 'magma', crystal: 'crystal' }; // fusion look -> projectile mesh (makeProjMesh)
// fusion looks (arcana.js FUSIONS): the second element shows in the projectile's trail and in its burst. fxP/fxN-gated
function lookTrail(p) {
  const L = p.look;
  if (L === 'steam') { if (fxP(0.55)) spark(p.x, p.y, p.z, 0xeef4f6, { vy: 0.9, s: rr(0.5, 0.8), life: 0.6, drag: 1, spread: 0.4 }); if (fxP(0.3)) spark(p.x, p.y, p.z, 0xff8a2a, { s: 0.25, life: 0.25, drag: 0 }); }
  else if (L === 'napalm') { if (fxP(0.8)) spark(p.x + rr(-0.15, 0.15), p.y - 0.1, p.z + rr(-0.15, 0.15), Math.random() < 0.6 ? 0x7dff6a : 0x3cc02a, { vy: -1.8, s: 0.32, life: 0.4, drag: 0 }); } // venom drips off the fireball
  else if (L === 'magma') { if (fxP(0.6)) spark(p.x + rr(-0.3, 0.3), 0.3, p.z + rr(-0.3, 0.3), Math.random() < 0.5 ? 0xffd25a : 0xff6a1a, { vy: rr(1.5, 2.5), s: 0.18, life: 0.5, drag: 0.5 }); }
  else if (L === 'crystal') { if (fxP(0.5)) spark(p.x, p.y, p.z, Math.random() < 0.5 ? 0xffffff : 0xff5fd8, { s: 0.2, life: 0.3, drag: 0, spread: 0.5 }); }
}
function lookBoom(p) {
  const L = p.look, x = p.x, z = p.z, R = p.aoe || 1.5;
  if (L === 'steam') { // a scalding cloud: white steam puffs billow out over the burst, a pale ring
    addRing(x, z, 0.2, R * 1.1, 0.45, 0xdff6ff);
    for (let k = fxN(10); k > 0; k--) { const a = Math.random() * 6.28, d = Math.random() * R * 0.7; spark(x + Math.cos(a) * d, 0.3, z + Math.sin(a) * d, 0xf0f4f4, { vx: Math.cos(a) * 1.5, vz: Math.sin(a) * 1.5, vy: rr(0.8, 1.8), s: rr(1.1, 1.7), life: rr(0.7, 1.1), drag: 1.5 }); }
  } else if (L === 'napalm') { burst(x, 0.4, z, 0x7dff6a, fxN(10), 4, 0.35, 0.4); addRing(x, z, 0.2, R * 0.9, 0.35, 0x7dff6a); }
  else if (L === 'magma') { burst(x, 0.4, z, 0xff8a2a, fxN(12), 5, 0.3, 0.45); chunk(x, 0.3, z, 0x3a2018, 5, 4, 0.12); }
  else if (L === 'crystal') burst(x, 0.6, z, 0xff9ae8, fxN(8), 3.5, 0.3, 0.3);
}
function rayLook(r, segs, y) {
  for (const sg of segs) {
    if (sg[4] === 'spark' && r.look !== 'ether') continue;
    const dx = sg[2] - sg[0], dz = sg[3] - sg[1];
    if (r.look === 'ether' && fxP(sg[4] === 'spark' ? 0.2 : 0.4)) { // Ether Ray (user: "Ether Ray doesn't make sense"): a violet arcane
      // beam with storm crackle: short jagged yellow-white arcs flicker along it and jump off it
      const t0 = Math.random() * 0.8, t1 = Math.min(1, t0 + 0.1 + Math.random() * 0.15), tm = (t0 + t1) / 2, j = 0.28;
      bolts.push({ pts: [new THREE.Vector3(sg[0] + dx * t0, y, sg[1] + dz * t0), new THREE.Vector3(sg[0] + dx * tm + rr(-j, j), y + rr(-j, j), sg[1] + dz * tm + rr(-j, j)),
        new THREE.Vector3(sg[0] + dx * t1 + rr(-j, j) * 0.5, y + rr(-j, j) * 0.5, sg[1] + dz * t1 + rr(-j, j) * 0.5)], life: 0.09, color: '#fff7a8', glow: 'rgba(176,112,255,.55)', w: 4 });
      if (fxP(0.4)) { const t = Math.random(); spark(sg[0] + dx * t, y, sg[1] + dz * t, Math.random() < 0.5 ? 0xfff36a : 0xc890ff, { vx: rr(-2, 2), vz: rr(-2, 2), vy: rr(0.5, 2), s: 0.16, life: 0.2, drag: 3 }); }
    } else if (r.look === 'sun' && fxP(0.6)) { // Sunfire Beam: embers rain off the sunbeam
      const t = Math.random(); spark(sg[0] + dx * t, y, sg[1] + dz * t, Math.random() < 0.5 ? 0xffd25a : 0xff7a1a, { vx: rr(-0.5, 0.5), vz: rr(-0.5, 0.5), vy: rr(-1.6, -0.4), s: 0.2, life: 0.45, drag: 0.5 });
    }
  }
}
function makeProjMesh(kind, color) {
  const pk = kind + '|' + color, pool = projPool.get(pk);
  if (pool && pool.length) { const g = pool.pop(); g.scale.setScalar(kind.endsWith('S') ? 0.7 : 1); g.rotation.set(0, 0, 0); scene.add(g); return g; }
  const g = new THREE.Group(); g.userData.pk = pk;
  const light = new THREE.Color(color).lerp(new THREE.Color(0xffffff), 0.65).getHex();
  const add = (geo, mat, sx, sy, sz) => { const m = new THREE.Mesh(geo, mat); m.scale.set(sx, sy, sz); g.add(m); return m; };
  if (kind === 'bolt') { g.userData.spin = add(PG.shard, pMat(light, false), 2.4, 0.75, 0.75); add(PG.shard, pMat(color, true, 0.55), 3.2, 1.5, 1.5); }
  else if (kind === 'fire') { add(PG.ball, pMat(0xfff2b0, false), 1, 1, 1); g.userData.pulse = add(PG.ball, pMat(0xff7a1a, true, 0.8), 1.9, 1.9, 1.9); add(PG.ball, pMat(0xff2a00, true, 0.3), 2.8, 2.6, 2.6); }
  else if (kind === 'venom') { add(PG.ball, pMat(light, false), 1.5, 0.55, 0.55); add(PG.ball, pMat(color, true, 0.6), 2.3, 1, 1); }
  else if (kind === 'lance') { g.userData.spin = add(PG.shard, pMat(light, false), 4.2, 0.6, 0.6); add(PG.shard, pMat(color, true, 0.5), 5, 1.3, 1.3); }
  else if (kind === 'glaive') { g.userData.spinY = add(PG.shard, pMat(light, false), 1.7, 0.35, 1.7); add(PG.ball, pMat(color, true, 0.5), 2.2, 0.6, 2.2); }
  else if (kind === 'pebble') { // Pebble Storm's little rocks: the boulder's look, small, tumbling
    const w = new THREE.Group(); g.add(w); g.userData.spinZ = w;
    w.add(new THREE.Mesh(rockGeo, boulderMat || (boulderMat = new THREE.MeshLambertMaterial({ color: 0x9a7a5a, emissive: 0x1a120a, flatShading: true }))));
    w.children[0].scale.setScalar(0.3 + Math.random() * 0.14); w.children[0].rotation.set(Math.random() * 6, Math.random() * 6, 0); // bigger, varied (user: pebbles read badly)
    const o = new THREE.Mesh(rockGeo, boulderEdge || (boulderEdge = new THREE.MeshBasicMaterial({ color: 0x140c06, side: THREE.BackSide }))); o.scale.setScalar(w.children[0].scale.x * 1.1); w.add(o);
  }
  else if (kind === 'spook') { // Soul Volley (user 11-15: "make them appear like ghosts"): the ghost foe's art, small and see-through,
    // turned to the camera every frame (ud.bill), tinted toward the spell's colour, with a soft glow behind
    const m = makeSprite('ghost', 0.62); scene.remove(m); m.geometry = scytheGeo || (scytheGeo = new THREE.PlaneGeometry(1, 1));
    m.material.side = THREE.DoubleSide; const u = m.material.uniforms; u.uAlpha.value = 0.82; u.uTint.value.set(color).lerp(new THREE.Color(0xffffff), 0.6); u.uBias.value = 1.3;
    g.add(m); g.userData.bill = m;
    add(PG.ball, pMat(color, true, 0.3), 1.4, 1.4, 1.4);
  }
  else if (kind === 'boulder') { // Boulder (user 11-15: "should be a boulder, it's white glowing stuff"): a brown faceted rock
    // with a dark outline shell, rolling end over end (spinZ) - the golems' rock shape, no glow
    const w = new THREE.Group(); w.position.y = -0.22; g.add(w); g.userData.spinZ = w; // rolls along the floor
    const r = new THREE.Mesh(rockGeo, boulderMat || (boulderMat = new THREE.MeshLambertMaterial({ color: 0x9a7a5a, emissive: 0x1a120a, flatShading: true }))); r.scale.setScalar(0.5); w.add(r);
    const o = new THREE.Mesh(rockGeo, boulderEdge || (boulderEdge = new THREE.MeshBasicMaterial({ color: 0x140c06, side: THREE.BackSide }))); o.scale.setScalar(0.58); w.add(o); /* thick outline like the pebbles (user 11-15) */
  }
  // fusion projectiles (arcana.js FUSIONS look -> LOOK_KIND): each one built from both parents' looks
  else if (kind === 'steam') { // Steam Burst: a churning ball of white steam around a red-hot core
    add(PG.ball, pMat(0xffa040, true, 0.95), 0.95, 0.95, 0.95);
    const w = new THREE.Mesh(PG.puff, pMat(0xe8f0f2, true, 0.55)); w.scale.setScalar(1.6); g.add(w); g.userData.wob = w;
    g.userData.pulse = add(PG.ball, pMat(0xdff6ff, true, 0.3), 2.4, 2.4, 2.4);
  }
  else if (kind === 'magma') { // Magma Boulder: the Boulder's rock, black-red crust glowing through the cracks, in a heat haze
    const w = new THREE.Group(); w.position.y = -0.22; g.add(w); g.userData.spinZ = w;
    const r = new THREE.Mesh(rockGeo, magmaMat || (magmaMat = new THREE.MeshLambertMaterial({ color: 0x3a1a10, emissive: 0xd8400a, flatShading: true }))); r.scale.setScalar(0.5); w.add(r);
    const o = new THREE.Mesh(rockGeo, boulderEdge || (boulderEdge = new THREE.MeshBasicMaterial({ color: 0x140c06, side: THREE.BackSide }))); o.scale.setScalar(0.54); w.add(o);
    add(PG.ball, pMat(0xff6a1a, true, 0.14), 2.6, 1.8, 2.6).position.y = -0.22;
  }
  else if (kind === 'crystal') { // Crystal Lance: a long ice crystal (Ice Spear) with an arcane pink sheen (Prism Lance)
    g.userData.spin = add(PG.shard, pMat(0xf0ffff, false), 4.4, 0.7, 0.7); add(PG.shard, pMat(0x8fe6ff, true, 0.6), 5.2, 1.3, 1.3); add(PG.shard, pMat(0xff5fd8, true, 0.3), 6, 2, 2);
  }
  else if (kind === 'void') { // Void Orbs / Twilight dark orbs: a black core in a coloured rim
    add(PG.ball, pMat(0x05020a, false), 1.6, 1.6, 1.6); g.userData.pulse = add(PG.ball, pMat(color, true, 0.3), 1.9, 1.9, 1.9); add(PG.ball, pMat(0x5a18b0, true, 0.22), 2.7, 2.7, 2.7);
  }
  else if (kind === 'holyorb') { // Twilight light orbs: a white-gold core in a gold glow
    add(PG.ball, pMat(0xfffbe8, false), 1.1, 1.1, 1.1); g.userData.pulse = add(PG.ball, pMat(0xffd860, true, 0.7), 1.9, 1.9, 1.9); add(PG.ball, pMat(0xfff0b0, true, 0.3), 2.8, 2.8, 2.8);
  }
  else if (kind === 'vglaive' && sheets.venom_glaive) { // Venom Glaive (user 11-15: "add the glaive sprite itself"): a painted
    // three-bladed venom chakram (tools/paint_glaive.py), lying flat and spinning, over a soft toxic glow
    const w = new THREE.Group(); g.add(w); g.userData.spinY = w; g.userData.fast = true;
    const m = makeSprite('venom_glaive', 1.15); scene.remove(m); m.geometry = scytheGeo || (scytheGeo = new THREE.PlaneGeometry(1, 1));
    m.material.side = THREE.DoubleSide; m.material.uniforms.uBias.value = 1.2; m.rotation.x = -Math.PI / 2 + 0.5; w.add(m);
    add(PG.ball, pMat(color, true, 0.25), 2.2, 0.25, 2.2);
  }
  else if (kind === 'scythe' && sheets.skel_2_w) { // Reaper Scythe (user 11-15: "should show the scythe, right now it's just white"): the Grave
    // Reaper's painted sickle, lying almost flat and spinning like a thrown boomerang, over a soft violet glow
    const w = new THREE.Group(); g.add(w); g.userData.spinY = w; g.userData.fast = true;
    const m = makeSprite('skel_2_w', 0.95); scene.remove(m); m.geometry = scytheGeo || (scytheGeo = new THREE.PlaneGeometry(1, 1));
    m.material.side = THREE.DoubleSide; m.material.uniforms.uBias.value = 1.25; m.rotation.x = -Math.PI / 2 + 0.55; w.add(m);
    add(PG.ball, pMat(color, true, 0.2), 1.5, 0.25, 1.5);
  }
  else if (/^(javelin|axe|arrow|skull)S?$/.test(kind)) {
    const hk = kind.replace(/S$/, ''), sp = new THREE.Group(); g.add(sp);
    const part = (geo, c, sx, sy, sz, x, y = 0) => { const m = new THREE.Mesh(geo, pMat(c, false)); m.scale.set(sx, sy, sz); m.position.set(x, y, 0); sp.add(m); return m; };
    if (hk === 'javelin') { part(boxGeo, 0x8a5a2a, 0.9, 0.05, 0.05, -0.15, -0.025); part(PG.shard, 0xe8e8f0, 1.6, 0.45, 0.45, 0.36); }
    if (hk === 'axe') { part(boxGeo, 0x7a4a22, 0.5, 0.05, 0.05, -0.1, -0.025); part(boxGeo, 0xc8d0dc, 0.14, 0.26, 0.05, 0.16, -0.13); g.userData.spinZ = sp; }
    if (hk === 'arrow') { part(boxGeo, 0xd8b880, 0.7, 0.03, 0.03, -0.1, -0.015); part(PG.shard, 0xd0d4dc, 0.9, 0.35, 0.35, 0.26); part(boxGeo, 0xffffff, 0.12, 0.1, 0.02, -0.42, -0.05); }
    if (hk === 'skull') { part(PG.ball, 0xf2ece0, 1.1, 1, 1, 0); part(boxGeo, 0x101010, 0.05, 0.05, 0.06, 0.15, 0.02).position.z = 0.06; part(boxGeo, 0x101010, 0.05, 0.05, 0.06, 0.15, 0.02).position.z = -0.06; }
    add(PG.ball, pMat(color, true, 0.45), hk === 'skull' ? 2 : 2.6, 1, 1);
    if (kind.endsWith('S')) g.scale.setScalar(0.7);
  }
  // foe shot kinds (not every shot is the same glowing orb): spore puff, spinning gold coin, soul teardrop, slime glob, saw gear
  else if (kind === 'spore') { // a puffy cluster that wobbles
    const w = new THREE.Mesh(PG.puff, pMat(light, false)); g.add(w); g.userData.wob = w;
    add(PG.ball, pMat(color, true, 0.4), 1.9, 1.6, 1.9);
  } else if (kind === 'coin') { // a gold disc standing on edge, spinning (flips) with a glint
    const c = new THREE.Mesh(coinGeoV, coinMat); c.scale.setScalar(1.25); g.add(c); g.userData.spinY = c;
    add(PG.ball, pMat(0xffd34f, true, 0.3), 1.5, 1.5, 1.5);
  } else if (kind === 'soul') { // a pale teardrop with a ghost face, its tail streaming back (x = the flight direction)
    add(PG.ball, pMat(light, false), 1.1, 1, 1);
    add(PG.face, pMat(0x10202a, false), 1, 1, 1);
    g.userData.pulse = add(PG.ball, pMat(color, true, 0.5), 2.6, 1.2, 1.2); g.userData.pulse.position.x = -0.14;
  } else if (kind === 'tear') { // the eyes' bolts: a glossy tear-drop with a dripping tail
    add(PG.ball, pMat(light, false), 0.95, 0.85, 0.85); add(PG.ball, pMat(color, true, 0.55), 2.5, 1.1, 1.1).position.x = -0.14;
  } else if (kind === 'slime') { // a squashing jelly blob with a gloss dot
    const w = new THREE.Mesh(PG.ball, pMat(color, false)); w.scale.setScalar(1.35); g.add(w); g.userData.squish = w;
    add(PG.ball, pMat(color, true, 0.35), 2, 1.6, 2);
  } else if (kind === 'gear') { // the Sentinel's saw: a flat toothed brass gear, spun fast
    const w = new THREE.Group(); g.add(w); g.userData.spinY = w; g.userData.fast = true;
    w.add(new THREE.Mesh(gearGeo, gearMat)); w.add(new THREE.Mesh(gearHubGeo, gearHubMat));
  }
  else { add(PG.ball, pMat(light, false), 0.8, 0.8, 0.8); g.userData.pulse = add(PG.ball, pMat(color, true, 0.7), 1.7, 1.7, 1.7); } // enemy orb
  scene.add(g);
  return g;
}
function placeProj(p, y, dt) {
  p.t3 = (p.t3 || 0) + dt;
  const bob = Math.sin(p.t3 * 14) * 0.04;
  p.mesh.position.set(p.x, y + bob, p.z);
  p.mesh.rotation.y = -Math.atan2(p.vz, p.vx);
  if (p.mesh.userData.spin) p.mesh.userData.spin.rotation.x += dt * 18;
  const ud = p.mesh.userData;
  if (ud.spinY) ud.spinY.rotation.y += dt * (ud.fast ? 30 : ud.wob ? 8 : 12);
  if (ud.wob) { const w = Math.sin(p.t3 * 11); ud.wob.scale.set(1 + w * 0.14, 1 - w * 0.1, 1 - w * 0.12); ud.wob.rotation.x += dt * 3; }
  if (ud.squish) { const w = Math.sin(p.t3 * 16); ud.squish.scale.set(1 + w * 0.2, 1 - w * 0.22, 1 - w * 0.1); }
  if (p.mesh.userData.spinZ) p.mesh.userData.spinZ.rotation.z -= dt * 22;
  if (ud.bill) { p.mesh.updateMatrixWorld(); ud.bill.quaternion.copy(p.mesh.quaternion).invert().multiply(camera.quaternion); ud.bill.position.y = Math.sin(p.t3 * 9) * 0.06; ud.bill.scale.x = ud.bill.userData.bw * (p.vx < 0 ? -1 : 1); }
  if (p.mesh.userData.pulse) p.mesh.userData.pulse.scale.setScalar(1.8 + Math.sin(p.t3 * 30) * 0.15);
  p.glow.position.set(p.x, y + bob, p.z);
  p.shadow.position.set(p.x, 0.04, p.z);
}
function killProj(p) {
  if (p.mesh.parent === scene && p.mesh.userData.pk) { let pool = projPool.get(p.mesh.userData.pk); if (!pool) projPool.set(p.mesh.userData.pk, pool = []); if (pool.length < 48) pool.push(p.mesh); }
  scene.remove(p.mesh); scene.remove(p.shadow); killGlow(p.glow);
}
function addProj(o) {
  o.vx = Math.cos(o.a) * o.speed; o.vz = Math.sin(o.a) * o.speed;
  if (o.y === undefined) { o.x += Math.cos(o.a) * 0.35; o.z += Math.sin(o.a) * 0.35; o.y = 0.7; }
  o.glow = o.kind === 'boulder' || o.kind === 'pebble' ? makeGlow(0x6a4a2a, 0.3, 0.1) : o.kind === 'magma' ? makeGlow(0xff5a10, 0.7, 0.3) : makeGlow(o.color, o.size * 0.8, 0.7); o.glow.position.set(o.x, 0.7, o.z); // a rock doesn't glow
  o.mesh = makeProjMesh(o.kind, o.color); o.shadow = makeShadow(o.kind === 'fire' ? 0.7 : 0.45);
  o.mesh.scale.setScalar(o.scale || (o.kind === 'fire' ? 1.1 : 1));
  o.hit = new Set(); o.maxLife = o.life;
  placeProj(o, o.y, 0);
  projs.push(o);
}
function explode(p) {
  const r = p.aoe, col = p.color || 0xffa040;
  if (p.lite) { // small hits (Pebble Storm rocks, spear/orb end bursts): a ring and a few sparks, no smoke, light or boom
    addRing(p.x, p.z, 0.2, r, 0.25, col); burst(p.x, 0.4, p.z, col, 8, 4, 0.35, 0.3);
    for (const e of [...enemies]) { const d = Math.hypot(e.x - p.x, e.z - p.z); if (d < r + e.r) hurtEnemy(e, p.dmg * (1 - 0.35 * d / (r + e.r)), e.x - p.x, e.z - p.z, p.kb || 4, col, p.els); }
    for (const pot of [...pots]) if (Math.hypot(pot.x - p.x, pot.z - p.z) < r) breakPot(pot);
    if (p.burn) fires.push({ x: p.x, z: p.z, r: r * 0.8, life: 3, dmg: p.dmg * 0.25, tick: 0, glow: makeGlowAt(p.x, 0.2, p.z, 0xff5a10, r * 2.2, 0.45) });
    return;
  }
  addRing(p.x, p.z, 0.3, r, 0.3, col);
  burst(p.x, 0.5, p.z, col, 30, 7, 0.6, 0.5);
  burst(p.x, 0.5, p.z, 0xffe08a, 12, 4, 0.5, 0.3);
  for (let k = 0; k < 8; k++) spark(p.x + rr(-0.5, 0.5), 0.4, p.z + rr(-0.5, 0.5), 0x3a2a2a, { vy: 1.5 + Math.random(), s: 0.8, life: 0.9, drag: 1 });
  chunk(p.x, 0.3, p.z, 0x3a2a24, 5, 5, 0.1);
  splat(p.x, p.z, 0x1a1210, r * 1.3, 1);
  fxLight.position.set(p.x, 1.2, p.z); fxLight.intensity = 40;
  let hits = 0;
  for (const e of [...enemies]) {
    const d = Math.hypot(e.x - p.x, e.z - p.z);
    if (d < r + e.r) { hurtEnemy(e, p.dmg * (1 - 0.35 * d / (r + e.r)), e.x - p.x, e.z - p.z, 6, col, p.els); hits++; }
  }
  for (const pot of [...pots]) if (Math.hypot(pot.x - p.x, pot.z - p.z) < r) breakPot(pot);
  if (p.plague) fires.push({ x: p.x, z: p.z, r: r, life: 3.5, dmg: 0, tick: 0, poison: true, glow: makeGlowAt(p.x, 0.25, p.z, 0x5fff4a, r * 2.4, 0.35) });
  if (p.burn) fires.push({ x: p.x, z: p.z, r: r * 0.8, life: 3, dmg: p.dmg * 0.25, tick: 0, glow: makeGlowAt(p.x, 0.2, p.z, 0xff5a10, r * 2.2, 0.45) });
  addShake(Math.min(0.3, 0.04 + hits * 0.035)); sfx('boom'); // shake follows the impact
}
const ringGeo = flatRingGeo;
const ringPool = []; // spent ring meshes keep their material: a new material per ring cost a program lookup (getParameters) each
function addRing(x, z, r0, r1, dur, color, top = false) { // top: no depth test (not cut by a wall block)
  const mesh = ringPool.pop() || new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ map: softRingTex, color, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL }));
  mesh.material.color.set(color); mesh.material.opacity = 1; mesh.scale.setScalar(r0); mesh.material.depthTest = !top; mesh.renderOrder = top ? 8 : 0;
  mesh.position.set(x, 0.12, z); scene.add(mesh);
  rings.push({ mesh, t: 0, dur, r0, r1 });
}

// ---------- player ----------
function damagePlayer(n, fx, fz) {
  if (!player.alive || player.iframe > 0 || G.state !== 'play' || BENCH || (G.prologue && G.prologue.phase !== 'boss')) return;
  if (ZOO) { zooHit(fx, fz); return; } // the zoo: the hit reads, Pip takes no damage
  if (Math.random() < player.g.dodge + player.der.dodge + (player.cloakDodge || 0)) { addText(player.x, 1.4, player.z, 'DODGE', '#9fe7ff', 1); player.iframe = 0.35; sfx('whoosh');
    if (player.der.dash) { player.iframe = 0.8; player.dashT = 0.8; burst(player.x, 0.5, player.z, 0x9fe7ff, 10, 4, 0.3, 0.35); } // AGI 5: dodge dash
    if (player.der.counter) explode({ x: player.x, z: player.z, aoe: 2.2, dmg: 18 + 4 * G.floor, color: 0x9fe7ff }); // AGI 10: counter-hit
    return; }
  if (player.g.flags.mirror && player.mirrorRoom !== G.curRoom) { player.mirrorRoom = G.curRoom; addText(player.x, 1.4, player.z, 'BLOCKED', '#ffffff', 1.1); player.iframe = 0.6; flash(0.2); sfx('lock'); return; }
  n = Math.ceil(n * (1 + Math.floor((G.floor - 1) / 4) * 0.5)); // hits hurt more every 4 floors
  if (player.der.resist > 0) { // VIT: resist takes a % off; hits are whole half-hearts, so the fraction carries to the next hit
    const raw = n * (1 - player.der.resist) + (player.resAcc || 0), m = Math.floor(raw + 1e-9);
    player.resAcc = Math.max(0, raw - m);
    if (m < n) addText(player.x, 1.8, player.z, m <= 0 ? 'RESISTED' : 'RESIST', '#ffd27a', 0.9);
    n = m;
  }
  if (n <= 0) { player.iframe = 0.5; sfx('lock'); return; }
  player.hp -= n; player.iframe = 1.1;
  const dx = player.x - fx, dz = player.z - fz, dl = Math.hypot(dx, dz) || 1, push = 9;
  player.vx += dx / dl * push; player.vz += dz / dl * push;
  addShake(0.55); G.hitstop = 0.09; sfx('hurt');
  $('hurt').style.transition = 'none'; $('hurt').style.opacity = 1;
  requestAnimationFrame(() => { $('hurt').style.transition = 'opacity .6s'; $('hurt').style.opacity = 0; });
  burst(player.x, 0.6, player.z, 0xff2a4a, 16, 5, 0.4, 0.5);
  splat(player.x, player.z, 0x9b0f22, 0.6);
  player.squash = 0.6;
  if (player.ember) { const fake = { x: player.x, z: player.z, aoe: 2.4, dmg: 30 }; explode(fake); }
  renderHearts();
  if (player.hp <= 0) {
    if (G.prologue) { proRevive(); return; } // the prologue never ends in death
    if (player.revive > 0) {
      player.revive--; player.hp = 4; player.iframe = 2.5; renderHearts();
      explode({ x: player.x, z: player.z, aoe: 3.5, dmg: 80 }); flash(0.6); toast('PHOENIX FEATHER', 'You rise again');
      return;
    }
    playerDie();
  }
}
// ads exist only in the store apps: every browser (test link, CrazyGames, itch) gets the reward free, so no "watch an ad" wording there
const adsOn = () => Monet.mode !== 'web';
function offerRevive() {
  G.run.adRevive = true; G.state = 'cards';
  const row = $('cardRow'); $('cardsTitle').textContent = 'SECOND CHANCE';
  row.innerHTML = `<p class="beast" style="text-align:center">${adsOn() ? 'Watch an ad to get' : 'Get'} back up with full health.</p>`;
  const yes = document.createElement('button'); yes.className = 'rwbtn big'; yes.innerHTML = adsOn() ? '▶ WATCH AD · REVIVE' : '✦ REVIVE';
  const no = document.createElement('button'); no.className = 'rwbtn ghost'; no.textContent = 'no thanks';
  yes.addEventListener('pointerdown', async (ev) => {
    ev.stopPropagation();
    if (!(await Monet.rewarded('revive'))) return;
    $('cards').classList.add('hidden'); G.state = 'play';
    player.hp = player.maxHp; player.iframe = 3; renderHearts(); flash(0.6); sfx('revive');
    explode({ x: player.x, z: player.z, aoe: 3.5, dmg: 80 }); toast('REVIVED', 'back in the fight');
  });
  no.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); $('cards').classList.add('hidden'); G.state = 'play'; playerDie(); });
  row.append(yes, no); $('cards').classList.remove('hidden');
}
// ---------- victory: floor 50 boss down ----------
function winRewards() {
  const out = [];
  const lockedEls = ELEMENT_ORDER.filter((e) => !meta.elements.includes(e));
  const leg = Object.keys(LEGENDARY).filter((k) => k !== meta.winLegend);
  out.push({ id: 'item', name: 'Legendary Heirloom', info: 'A legendary item goes straight into your vault.', color: '#ffa040', icon: ['gear', 2],
    pick: () => { const it = rollGear(rand, WIN_FLOOR, 1, 3); if (!meta.vault[it.slot]) meta.vault[it.slot] = it; else meta.stash.push(it); return it.name; } });
  out.push({ id: 'stats', name: 'Ascended Blood', info: '+2 to every stat on every future run (stacks with each win).', color: '#c07aff', icon: ['items', 3],
    pick: () => { meta.winStats = (meta.winStats || 0) + 1; return `+${2 * meta.winStats} all stats`; } });
  if (leg.length) { const id = pick(leg); out.push({ id: 'legend', name: `Born with ${spellDef(id).name}`, info: `Start every run with ${spellDef(id).name}. ${LEGENDARY[id].info}.`, color: '#ffb340', icon: spellIcon(spellDef(id)),
    pick: () => { meta.winLegend = id; return spellDef(id).name; } }); }
  if (lockedEls.length) { const el = pick(lockedEls); out.push({ id: 'element', name: `${ELEMENTS[el].name} Unbound`, info: `Unlock ${ELEMENTS[el].name} spells for every run.`, color: ELEMENTS[el].color, icon: elemIcon(el),
    pick: () => { meta.elements.push(el); return ELEMENTS[el].name; } }); }
  out.push({ id: 'revive', name: 'Undying', info: 'One extra revive on every future run.', color: '#ff6a8a', icon: ['spells', 1], pick: () => { meta.winRevive = (meta.winRevive || 0) + 1; return 'extra revive'; } });
  out.push({ id: 'shards', name: 'Soul Hoard', info: '+2,000 soul shards.', color: '#b98cff', icon: ['items', 3], pick: () => { meta.shards += 2000; return '+2,000 shards'; } });
  return shuffle(out).slice(0, 3);
}
function showVictory() {
  if (G.state !== 'play') return;
  G.state = 'won'; G.victory = true; flash(0.8); sfx('clear'); addShake(0.6); clearRun(); // the run is over: no continue into a second win
  meta.wins = (meta.wins || 0) + 1; saveMeta();
  const opts = winRewards();
  $('cardsTitle').textContent = `VICTORY · FLOOR ${WIN_FLOOR}`;
  const row = $('cardRow'); row.innerHTML = '<p class="beast" style="text-align:center">You conquered the depths. Choose a reward to keep forever.</p>';
  opts.forEach((o) => {
    const c = document.createElement('div'); c.className = 'card legend'; c.style.setProperty('--c', o.color);
    c.innerHTML = `<div class="ci" style="--img:url(${typeof o.icon === 'string' ? o.icon : iconURL(o.icon[0], o.icon[1])})"></div><div><div class="tag">PERMANENT REWARD</div><h3>${o.name}</h3><p>${o.info}</p></div>`;
    c.addEventListener('pointerdown', (ev) => {
      ev.stopPropagation(); const got = o.pick(); saveMeta(); sfx('heal');
      $('cards').classList.add('hidden'); toast('REWARD KEPT', got);
      G.state = 'play'; player.revive = 0; player.iframe = 0; player.hp = 0; playerDie();
    });
    row.appendChild(c);
  });
  $('cards').classList.remove('hidden');
  if (AUTO) later(1, () => row.querySelector('.card').dispatchEvent(new PointerEvent('pointerdown')));
}
const againLabel = () => (G.daily && G.dailyRet ? 'BACK TO YOUR RUN' : 'PLAY AGAIN'); // a daily entered from a run goes back to it
function playerDie() {
  (G.deaths = G.deaths || []).push(G.floor);
  if (!G.daily) { G.deadRun = lastRun; clearRun(); } // the run ends here (death, victory or quit); an ad revive puts the checkpoint back. A daily never touches the run save
  const vict = !!G.victory, won = vict || !!G.dailyWon; G.victory = false;
  player.alive = false; G.state = 'dead'; G.deadT = 0; G.kept = false; tutHide(); killFairy();
  if (!won) {
    chunk(player.x, 0.6, player.z, 0xf7b6e0, 16, 6, 0.14);
    burst(player.x, 0.6, player.z, 0xff4fd8, 40, 6, 0.6, 0.9);
    player.mesh.visible = false; player.shadow.visible = false; player.staffGlow.visible = false;
    addShake(1); flash(0.5);
  }
  $('overTitle').textContent = G.dailyWon ? 'DAILY CLEARED' : won ? 'VICTORY' : 'YOU FELL';
  const R = G.run, gain = { depth: (G.floor - 1) * 6, slain: Math.floor(R.kills / 8), bosses: R.bosses * 30, champions: R.champs * 12 };
  if (vict) { for (const k of Object.keys(gain)) gain[k] *= 3; gain.victory = 250; }
  const total = Math.max(1, Object.values(gain).reduce((a, b) => a + b, 0));
  const st = meta.stats, newBest = G.floor > st.bestFloor;
  delete meta.fresh; meta.shards += total; st.shardsTotal += total; st.runs++; st.bestFloor = Math.max(st.bestFloor, G.floor);
  st.kills += R.kills; st.bosses += R.bosses; st.champs += R.champs; st.coins += R.coins; st.time += R.time; st.dmg += R.dmg; st.bestCombo = Math.max(st.bestCombo, R.bestCombo);
  const lgBefore = meta.legacy || 0, lgGain = R.kills + (G.floor - 1) * 25 + R.bosses * 80;
  meta.legacyXp = (meta.legacyXp || 0) + lgGain;
  while (meta.legacyXp >= legacyNeed(meta.legacy || 0)) { meta.legacyXp -= legacyNeed(meta.legacy || 0); meta.legacy = (meta.legacy || 0) + 1; }
  saveMeta(); G.best = st.bestFloor;
  G.deathDelta = { total, lgGain, kills: R.kills, bosses: R.bosses, champs: R.champs, coins: R.coins, time: R.time, dmg: R.dmg };
  const ms = { mage: 'INT', archer: 'DEX', warrior: 'STR', hunter: 'STR' }[player.hero.cls];
  const lgUp = meta.legacy - lgBefore;
  const affordable = UPGRADES.filter((u) => mlv(u.id) < u.max && meta.shards >= u.cost[mlv(u.id)]).length;
  later(1.5, () => {
    $('btnSanctum2').textContent = affordable ? `SANCTUM · ${affordable} UPGRADE${affordable > 1 ? 'S' : ''} READY` : 'SANCTUM';
    $('btnSanctum2').classList.toggle('ready', affordable > 0);
  });
  later(1.4, () => {
    const canRevive = !won && !G.run.adRevive && !AUTO && !G.daily;
    { const ov = $('keepVeil'); if (ov) ov.remove(); keepHome = null; } // a stale pop-up from the last death
    { const rv = $('reviveVeil'); if (rv) rv.remove(); }
    $('overStats').innerHTML = `
      <div class="ovInfo"><div><small>FLOOR</small><b>${G.floor}</b></div><div><small>SLAIN</small><b>${R.kills}</b></div><div><small>TIME</small><b>${fmtTime(R.time)}</b></div><div class="sh"><small>SHARDS</small><b>+<i id="shardCount">0</i></b></div></div>
      <div id="overTease">${loginTease()}</div>
      ${vaultPicker()}
      <div class="legacy">${newBest ? `<div class="newbest">✦ NEW BEST · FLOOR ${G.floor} ✦</div>` : ''}<span><u>LEGACY ${meta.legacy}</u><em>+${lgGain} XP</em></span><div class="xpbar"><i style="width:${Math.round(meta.legacyXp / legacyNeed(meta.legacy) * 100)}%"></i></div>
      <small>${lgUp ? `<b>LEVEL UP!</b> every run now starts with +${meta.legacy} ${ms}${meta.legacy >= 3 ? ` and +${Math.floor(meta.legacy / 3)} VIT` : ''}` : `next level: +1 ${ms} on every run`}</small></div>
      ${dailyCardHtml(true)}
      <div id="overChest"></div>
      <div id="overUps">${overUpgrades()}</div>
`;
    showScreen('over'); renderVChest('overChest'); setTimeout(loginPop, 1100); $('btnAgain').classList.remove('locked');
    $('btnAgain').textContent = againLabel(); // the keep pick comes at the END: PLAY AGAIN / SANCTUM open it first (user) /* arrows point up at the keep box (player feedback: not intuitive) */ $('hud').classList.add('hidden');
    let shown = 0; const step = () => { shown = Math.min(total, shown + Math.ceil(total / 30)); const el = $('shardCount'); if (el) el.textContent = shown; sfx('coin', Math.min(14, Math.floor(shown / total * 14))); if (shown < total) setTimeout(step, 40); };
    setTimeout(step, 400);
    if (AUTO) { const b = document.querySelector('[data-keep]'); if (b) b.click(); later(1.5, () => startRun()); }
    if (!vaultChoices.length) $('btnAgain').classList.remove('locked');
    // flow (user): REVIVE? first (when offered) -> KEEP ONE ITEM -> the results. A revive skips the rest: the run isn't over
    if (canRevive) reviveAsk(); else if (vaultChoices.length) keepModal(true, true);
  });
}
// ---------- Vault: keep one item per death; every run starts wearing the vault ----------
let vaultChoices = [];
function vaultPicker() {
  const items = [...Object.values(player.gear), ...player.bag].filter((it) => it && !it.vault);
  vaultChoices = G.prologue ? [] : items.sort((a, b) => gearScore(b) - gearScore(a)).slice(0, 4); // never in the prologue (user)
  if (!vaultChoices.length) return ''; // nothing to keep: say nothing
  return `<div class="vault keep"><button class="keepX" aria-label="close">✕</button><span>✦ KEEP ONE ITEM FOREVER ✦</span><small>Pick one before your next run. Kept items go to your Vault.</small>${vaultChoices.map((it, k) => {
    const cur = meta.vault[it.slot], better = true;
    return `<div class="gearslot bagit" data-keep="${k}" style="--c:${RARITY[it.rarity].color}"><i class="ci" style="--img:url(${gearIcon(it)})"></i><div><b>${it.name}</b>${better ? '' : ' · replace ' + cur.name + '?'}<br>${gearLines(it).join(' · ')}</div><em class="keepChip">KEEP</em></div>`;
  }).join('')}</div>`;
}
// the keep box as a centred pop-up over a dimmed screen; ✕ puts it back in the list (the locked button reopens it)
let keepHome = null; // the keep box's place in the results list while it sits in the pop-up
function keepModal(on, step = false) {
  const v = document.querySelector('.vault.keep'); if (!v) return;
  let veil = $('keepVeil');
  if (on && !G.kept && G.state !== 'play') {
    if (veil) return;
    keepHome = document.createComment('keep'); v.before(keepHome);
    veil = document.createElement('div'); veil.id = 'keepVeil'; veil.classList.toggle('step', step); veil.appendChild(v); $('over').appendChild(veil); // inside the results screen: it hides with it
    veil.addEventListener('click', onKeepClick);
  } else if (veil) { if (keepHome) { keepHome.replaceWith(v); keepHome = null; } veil.remove(); }
}
$('overStats').addEventListener('click', onKeepClick);
function onKeepClick(e) {
  if (e.target.closest('.keepX')) { keepModal(false); return; }
  const b = e.target.closest('[data-keep]'); if (!b || G.kept) return;
  const it = vaultChoices[+b.dataset.keep]; if (!it) return;
  const keep = { ...it, vault: undefined };
  if (!meta.vault[it.slot]) meta.vault[it.slot] = keep; else meta.stash.push(keep); // empty slot: wear it; otherwise into storage
  saveMeta(); G.kept = true; sfx('clear'); b.closest('.vault').classList.add('done'); { const st = $('keepVeil'), then = G.afterKeep; G.afterKeep = null; if (st) { st.classList.add('out'); setTimeout(() => { keepModal(false); if (then) then(); }, 380); } else if (then) then(); } // fades out, then PLAY AGAIN / SANCTUM goes on
  $('btnAgain').classList.remove('locked'); $('btnAgain').textContent = againLabel();
  b.closest('.vault').innerHTML = `<span>KEPT</span><small style="color:${RARITY[it.rarity].color}">${it.name}</small><small> ${meta.vault[it.slot] === keep ? 'is equipped for your next run.' : 'went to your storage. Equip it in Sanctum → Character.'}</small>`;
}
function legacyNeed(l) { return 120 + l * 70; }
function fmtNum(n) { n = Math.round(n); return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'k' : String(n); }
function fmtTime(t) { t = Math.round(t); const h = Math.floor(t / 3600), m = Math.floor(t / 60) % 60, sec = t % 60; return h ? `${h}h ${m}m` : `${m}:${String(sec).padStart(2, '0')}`; }
// all speed bonuses stack, but with diminishing returns: +50% feels fast, and it can never pass +80%
function moveSpeed(p) {
  const raw = p.speed / 5.4 * p.g.speed * p.der.speed - 1;
  const bonus = raw > 0 ? 0.8 * (1 - Math.exp(-raw / 0.8)) : raw;
  return 5.4 * (1 + bonus) * (p.dashT > 0 ? 1.45 : 1); // AGI 5 dodge dash goes past the cap for a moment
}
function tutShow(text, hand) {
  if (G.state !== 'play') return; // a delayed hint must not pop up over the death screen
  let el = $('tut'); if (!el) { el = document.createElement('div'); el.id = 'tut'; $('app').appendChild(el); }
  el.innerHTML = `${hand ? '<div class="hand">👆</div>' : ''}<b>${text}</b>`; el.className = 'show';
}
function tutHide() { const el = $('tut'); if (el) el.className = ''; }
function tutUpdate(dt) {
  const t = G.tut; if (!t || G.state !== 'play') return;
  if (t.step === 0) { t.moved += Math.hypot(player.vx, player.vz) * dt; if (t.moved > 4) { t.step = 1; tutHide(); } }
  else if (G.prologue) return; // the prologue only teaches moving; the rest comes on the real floor 1
  else if (t.step === 1 && enemies.some((e) => !e.dead && e.spawn >= 1)) { t.step = 2; tutShow('YOUR SPELLS FIRE ON THEIR OWN · KEEP MOVING, DODGE'); }
  else if (t.step === 2 && G.run.kills >= 3) { t.step = 3; tutShow('NICE! EXPLORE · CLEAR ROOMS TO GO DEEPER'); later(2.5, tutHide); meta.tutDone = true; saveMeta(); G.tut = null; }
}

// ---------- first-visit prologue: Pip and Vesper clear the depths together, then Vesper takes everything ----------
// A story scene played over live gameplay: a horde, the Stone King, the Grand Staff, the betrayal (freeze + every rune,
// item and the staff ripped out), the floor gives way -> the real floor 1 at level 1. Plays once (meta.prologueDone), or
// always with ?prologue=1. Nothing is saved, no damage, no XP while it runs. SKIP jumps to floor 1.
const PRO_SPELLS = ['arcane.missiles', 'fire.ring', 'u.meteor', 'u.spike', 'frost.frozenorb', 'u.momentum']; // the user's pick (11-15): Arcane Missiles, Phoenix, Storm Eye, Earth Spike, Frozen Orb, Momentum
const PRO_LOOT = ['hat', 'robe', 'ring', 'amulet', 'boots']; // shown flying out of Pip (the staff is the Grand Staff, last)
const VESPER_GREEN = 0x7dff9a, GOLD = 0xffd34f;
const PRO_LINES = {
  i1: ['vesper', "Let's end this, Pip. Together."],
  p2: ['pip', 'We did it!'],
  v1: ['vesper', 'Look... the Grand Staff.'],
  p3: ['pip', "It's ours!"],
  v2: ['vesper_evil', 'Ours? No, Pip. Mine.'],
  p4: ['pip_shock', "V-Vesper...? I can't move!"],
  v3: ['vesper_evil', 'Your runes. Your gear. All of it... mine.'],
  v4: ['vesper_evil', 'Enjoy the fall, little spark.'],
};
// the prologue boss: tanky enough to show his spits, Rockfall, four guard calls and the rage (the prologue spells hit hard)
const PRO_KING_HP = 120000, PRO_CAP = MOBILE ? 8 : 12; // PRO_CAP: most guards alive at once
const PRO_GUARD = [['slime', 'eye'], ['skeleton', 'imp', 'eye'], ['skeleton', 'ghost', 'big'], ['ghost', 'skeleton', 'golem', 'imp']];

// ---- visual-novel dialogue: big portrait (Pip left, Vesper right), name plate, typewriter text; a tap advances (the bot auto-advances) ----
const VN = { q: [], line: null, t: 0, shown: -1, hold: 0 };
function vnInit() {
  if ($('vn')) return;
  const el = document.createElement('div'); el.id = 'vn';
  el.innerHTML = '<img class="vp l" alt=""><img class="vp r" alt=""><div class="vbox"><div class="vname"></div><div class="vtext"></div><i class="vnext">TAP ▼</i></div>';
  $('app').appendChild(el);
  el.querySelector('.vbox').addEventListener('pointerdown', (e) => { e.stopPropagation(); if (G.state === 'play') vnTap(); });
  addEventListener('pointerdown', (e) => { if (VN.line && G.state === 'play' && !e.target.closest('#proSkip, #vn .vbox, .screen, #pauseBtn')) vnTap(); }); // a tap anywhere reads on (not on the pause menu)
  addEventListener('keydown', (e) => { if (VN.line && G.state === 'play' && (e.code === 'Space' || e.code === 'Enter')) vnTap(); });
  if (tier1Done) for (const f of ['pip', 'pip_shock', 'vesper', 'vesper_evil']) new Image().src = `portraits/${f}.webp`; // no pop-in later (a first visit streams them in loadSheets)
}
function vnSay(...keys) { VN.q.push(...keys.map((k) => PRO_LINES[k])); if (!VN.line) vnNext(); }
const vnBusy = () => !!VN.line || VN.q.length > 0;
function vnNext() {
  const el = $('vn'); VN.line = VN.q.shift() || null;
  el.classList.toggle('on', !!VN.line); $('app').classList.toggle('vnOn', !!VN.line);
  if (!VN.line) { for (const p of el.querySelectorAll('.vp')) p.classList.remove('in', 'dim', 'talk'); return; }
  const [face, text] = VN.line, side = face.startsWith('pip') ? 'l' : 'r';
  const me = el.querySelector(`.vp.${side}`), other = el.querySelector(`.vp.${side === 'l' ? 'r' : 'l'}`);
  if (!me.src.endsWith(`/${face}.webp`)) me.src = `portraits/${face}.webp`;
  me.classList.add('in', 'talk'); me.classList.remove('dim'); other.classList.remove('talk'); if (other.classList.contains('in')) other.classList.add('dim');
  const box = el.querySelector('.vbox'); box.className = `vbox ${side} ${face.split('_')[0]}`;
  box.querySelector('.vname').textContent = face.startsWith('pip') ? 'PIP' : 'VESPER';
  VN.t = 0; VN.shown = -1; VN.hold = 1.0 + text.length * 0.014; sfx('tap');
}
function vnUpdate(rdt) { // real time: slow-mo must not slow the text
  if (!VN.line) return;
  const text = VN.line[1], n = Math.min(text.length, Math.floor((VN.t += rdt) * 60));
  if (n !== VN.shown) { VN.shown = n; $('vn').querySelector('.vtext').textContent = text.slice(0, n); $('vn').querySelector('.vbox').classList.toggle('done', n >= text.length); }
  if (AUTO && n >= text.length && VN.t >= text.length / 60 + VN.hold) vnNext(); // players tap to read on
}
function vnTap() { if (!VN.line) return; const L = VN.line[1].length; if (VN.shown < L) VN.t = L / 60; else vnNext(); }
function vnClose() { VN.q.length = 0; VN.line = null; const el = $('vn'); if (el) { el.classList.remove('on'); for (const p of el.querySelectorAll('.vp')) p.classList.remove('in', 'dim', 'talk'); } $('app').classList.remove('vnOn'); }

// ---- the scene ----
function startPrologue() {
  initAudio(); for (const sId of screens) $(sId).classList.add('hidden');
  G.runDungeon = meta.lastDungeon = 'crypt'; saveMeta(); G.daily = null; G.dailyWon = null;
  const P = G.prologue = { phase: 'intro', t: 0, flights: [], marks: [], cd: 1, face: 1 };
  newGame(); // an ordinary floor 1 underneath (its checkpoint is skipped while G.prologue is set)
  spells = PRO_SPELLS.filter((id) => spellDef(id)).map((id, k) => ({ id, lv: 5, t: 0.3 + k * 0.12 }));
  player.maxHp = player.hp = 6; buildSpellHud(); renderHearts(); // hits hurt; a fall brings Holy Protection (proRevive)
  bannerT = 0; $('banner').classList.remove('show');
  P.start = P.cam = rooms.find((r) => r.type === 'start'); // Pip lands here and learns to move
  P.room = rooms.find((r) => r.type === 'pro') || P.start; // the Stone King's chamber, one door north: the whole fight is here
  P.ally = makeSprite('necro'); P.ally.material.uniforms.uTint.value.setRGB(0.85, 0.8, 1);
  P.allyShadow = makeShadow(0.8); P.allyGlow = makeGlow(VESPER_GREEN, 0.5, 0.8); P.allyGlow.material.depthTest = false; P.allyGlow.renderOrder = 10;
  P.ax = player.x + 1.6; P.az = player.z + 0.4; P.vDrop = { t: -1 }; // she drops in after Pip
  $('pauseBtn').style.visibility = 'hidden';
  $('app').classList.add('proHud');
  let ph = $('proHud'); if (!ph) { ph = document.createElement('div'); ph.id = 'proHud'; $('hud').appendChild(ph); }
  proHud('PROLOGUE', '');
  vnInit();
  let sk = $('proSkip'); if (!sk) { sk = document.createElement('button'); sk.id = 'proSkip'; sk.textContent = 'SKIP ›'; $('app').appendChild(sk); sk.addEventListener('pointerdown', (e) => { e.stopPropagation(); endPrologue(); }); }
  sk.classList.remove('hidden');
  P.run = proScript(P); P.wait = null;
}
// Pip falls in the prologue: Vesper's holy light lifts him back up at full health, shielded for a moment; the fight goes on
// Vesper heals Pip (no death, no freeze): a green beam from her staff to Pip, green rings and sparks, back to full HP
function proRevive() {
  const P = G.prologue; P.revives = (P.revives || 0) + 1;
  player.hp = player.maxHp; player.iframe = 2.5; P.shield = 2.5; renderHearts(); sfx('heal'); P.cast = 1;
  const vx = P.ax ?? player.x - 1, vz = P.az ?? player.z + 1, pts = [];
  for (let k = 0; k <= 6; k++) { const u = k / 6; pts.push(new THREE.Vector3(vx + (player.x - vx) * u, 1.1 + Math.sin(u * Math.PI) * 0.8, vz + (player.z - vz) * u)); }
  bolts.push({ pts, life: 0.5, color: '#9dffb8', glow: 'rgba(125,255,154,.5)', w: 12 }, { pts: pts.map((q) => q.clone()), life: 0.35, color: '#ffffff', glow: 'rgba(200,255,220,.35)', w: 5 });
  addRing(player.x, player.z, 0.2, 2.4, 0.5, VESPER_GREEN); addRing(player.x, player.z, 0.3, 1.4, 0.6, 0xd8ffe0); burst(player.x, 1, player.z, 0x7dff9a, 28, 4, 0.6, 0.7);
  fxLight.color.set(0x9dffb8); fxLight.position.set(player.x, 2.2, player.z); fxLight.intensity = 60;
  addText(vx, 2.3, vz, 'HEAL + SHIELD!', '#9dffb8', 1.3); // over Vesper's head: she is the one casting it
}
function proHud(title, sub) { const el = $('proHud'); if (el) el.innerHTML = `<b>${title}</b>${sub ? `<small>${sub}</small>` : ''}`; }
// Vesper's skill: a green-white bolt from the sky onto (x, z). dmg 0 = just the crack (the betrayal)
function vesperStrike(x, z, dmg, aoe = 2.2) {
  skyStrike(x, z, dmg, aoe, '#9dffb8', 'rgba(125,255,154,.45)', VESPER_GREEN);
}
// a jagged bolt from the sky onto (x, z) (Vesper's look; Momentum and Vesper's Judgment reuse it in their colours).
// o: glow2 (white core's glow), light / lightCol (fxLight), flash (given = throttled so frequent casts don't strobe), shake,
// boom (false = zap only), burstCol, splat, w (bolt width), small (a light hit with no explode), els
// Cheap on phones: no lights or materials are made (fxLight is the one shared light; on phones it isn't even in the scene),
// bolts are plain points drawn on the 2D overlay, rings come from a pool. Strikes landing close together (Momentum's
// volley, Thunderfall, several sky spells at once) are capped: past SKY_CAP in 0.3 s a strike draws one bolt, one ring and
// fewer sparks, and doesn't re-flash the screen. Damage is never capped.
const SKY_YS = [10, 6, 3], SKY_CAP = MOBILE ? 3 : 5, SKY_K = MOBILE ? 0.6 : 1;
let skyWinT = -9, skyWinN = 0, skyArcs = false; // skyArcs: a Thunderfall hit is resolving, its storm arcs come from the sky
function skyStrike(x, z, dmg, aoe, col, glow, ringCol, o = {}) {
  const busy = skyBusy();
  const pts = [new THREE.Vector3(x + rr(-0.8, 0.8), 15, z - 1.5)];
  for (const y of SKY_YS) pts.push(new THREE.Vector3(x + rr(-0.5, 0.5), y, z + rr(-0.3, 0.3)));
  pts.push(new THREE.Vector3(x, 0.05, z));
  const w = o.w || 12;
  if (o.fork) bolts.push({ pts, life: 0.34, max: 0.34, grow: 0.05, fork: true, color: col, glow, w }); // Thunderfall: the bolt shoots down from the sky with crackling forks
  else bolts.push({ pts, life: 0.32, color: col, glow, w });
  if (!busy) bolts.push({ pts: pts.map((q) => q.clone().setX(q.x + rr(-0.25, 0.25))), life: 0.22, color: '#ffffff', glow: o.glow2 || 'rgba(200,255,220,.3)', w: w / 2, ...(o.fork ? { max: 0.22, grow: 0.05 } : null) });
  fxLight.color.set(o.lightCol ?? 0xb8ffd0); fxLight.position.set(x, 2.5, z); fxLight.intensity = o.light ?? 90;
  if (busy) { /* no more flashes */ } else if (o.flash == null) flash(0.12);
  else if (o.flash > 0 && G.time - (G.skyFlashT ?? -9) > 0.8) { G.skyFlashT = G.time; flash(o.flash); }
  addShake(busy ? 0.02 : o.shake ?? 0.22); sfx('zap'); if (o.boom !== false) sfx('boom');
  if (!busy) addRing(x, z, 0.2, aoe + 0.6, 0.35, 0xffffff);
  addRing(x, z, 0.3, aoe, 0.5, ringCol);
  burst(x, 0.3, z, o.burstCol ?? 0xbfffd0, Math.round((o.small ? 10 : 24) * SKY_K * (busy ? 0.5 : 1)), 6, 0.5, 0.45); splat(x, z, o.splat ?? 0x0a1a10, aoe * 0.9, 0.9);
  if (dmg <= 0) return;
  if (o.small) { skyArcs = !!o.fork; for (const e of enemies) if (!e.dead && Math.hypot(e.x - x, e.z - z) < aoe + e.r) hurtEnemy(e, dmg, e.x - x, e.z - z, 2, ringCol, o.els || ['storm']); skyArcs = false; }
  else explode({ x, z, aoe, dmg, els: o.els || ['storm'], color: ringCol });
}
// a thin bolt from the sky onto a foe (storm chain hits): just the line and a spark, no light or flash
function skyBolt(x, z, col, life, w) {
  bolts.push({ pts: [new THREE.Vector3(x + rr(-0.5, 0.5), 9, z - 1), new THREE.Vector3(x + rr(-0.4, 0.4), 5, z + rr(-0.2, 0.2)), new THREE.Vector3(x + rr(-0.3, 0.3), 2.2, z), new THREE.Vector3(x, 0.4, z)], life, color: col, w });
  spark(x, 0.3, z, 0xffffff, { s: 0.7, life: 0.12, drag: 0 });
}
// the sky-strike cap shared by skyStrike / judgmentStrike / momentumStrike: true = too many landed in the last 0.3 s (draw less)
function skyBusy() { if (G.time - skyWinT > 0.3) { skyWinT = G.time; skyWinN = 0; } return ++skyWinN > SKY_CAP; }
// Vesper's Judgment: not a bolt but a pillar of light. A soft green-white column (drawn on the overlay, kind 'pillar') flares
// wide and narrows away, a rune circle flares on the ground and turns while it fades, motes and feathers of light drift up.
// Same blast as before (explode, storm, same aoe).
const judgRuneTex = canvasTex(256, 256, (g) => {
  g.translate(128, 128); g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineCap = 'round';
  g.lineWidth = 5; g.beginPath(); g.arc(0, 0, 120, 0, 6.283); g.stroke();
  g.lineWidth = 2; g.beginPath(); g.arc(0, 0, 104, 0, 6.283); g.stroke();
  g.beginPath(); g.arc(0, 0, 68, 0, 6.283); g.stroke();
  for (let k = 0; k < 16; k++) { // rune marks between the two outer circles
    g.save(); g.rotate(k / 16 * 6.283); g.lineWidth = 3; g.beginPath();
    const v = k % 4; g.moveTo(-5, -108); g.lineTo(-5, -116);
    if (v === 0) { g.moveTo(-5, -112); g.lineTo(5, -108); g.moveTo(-5, -112); g.lineTo(5, -116); }
    else if (v === 1) { g.moveTo(5, -108); g.lineTo(5, -116); g.moveTo(-5, -116); g.lineTo(5, -108); }
    else if (v === 2) { g.moveTo(-5, -116); g.lineTo(5, -112); g.lineTo(-5, -108); }
    else { g.moveTo(-5, -108); g.lineTo(5, -112); g.moveTo(1, -116); g.lineTo(1, -108); }
    g.stroke(); g.restore();
  }
  g.lineWidth = 3; g.beginPath(); // a six-pointed star in the inner circle
  for (let t = 0; t < 2; t++) for (let k = 0; k <= 3; k++) { const a = (k / 3 + t / 6) * 6.283 - 1.5708; k ? g.lineTo(Math.cos(a) * 68, Math.sin(a) * 68) : g.moveTo(Math.cos(a) * 68, Math.sin(a) * 68); }
  g.stroke();
  const grd = g.createRadialGradient(0, 0, 0, 0, 0, 60); grd.addColorStop(0, 'rgba(255,255,255,.7)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd; g.fillRect(-60, -60, 120, 120);
});
const judgRunePool = [], judgRunes = [];
function addRune(x, z, r, color) {
  let m = judgRunes.length >= 4 ? judgRunes.shift() : judgRunePool.pop();
  if (!m) { m = new THREE.Mesh(flatRingGeo, new THREE.MeshBasicMaterial({ map: judgRuneTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, ...DECAL })); m.renderOrder = 1; }
  m.material.color.set(color); m.material.opacity = 0; m.position.set(x, 0.09, z); m.renderOrder = 4; m.rotation.y = Math.random() * 6.28; // above the floor decals (user: clipping)
  m.userData.r = r; m.userData.life = m.userData.max = 1.2; m.scale.setScalar(r * 0.5);
  scene.add(m); judgRunes.push(m);
}
function updateRunes(dt) {
  for (let i = judgRunes.length - 1; i >= 0; i--) {
    const m = judgRunes[i], u = m.userData; u.life -= dt;
    const a = 1 - u.life / u.max; // flares out fast, turns, fades over its last 0.7 s
    m.scale.setScalar(u.r * (0.5 + 0.5 * (1 - (1 - Math.min(1, a / 0.14)) ** 3) + a * 0.08)); m.rotation.y += dt * 0.9;
    m.material.opacity = Math.min(1, a / 0.06) * clamp(u.life / 0.7, 0, 1);
    if (u.life <= 0) { scene.remove(m); judgRunePool.push(m); judgRunes.splice(i, 1); }
  }
}
function judgmentStrike(x, z, dmg, aoe) {
  const busy = skyBusy();
  bolts.push({ kind: 'pillar', pts: [new THREE.Vector3(x, 16, z), new THREE.Vector3(x, 0, z)], r: aoe * 0.45, life: 0.75, max: 0.75, color: '125,255,160', core: '235,255,225' });
  addRune(x, z, aoe * 1.05, 0xb8ffc0);
  fxLight.color.set(0xc8ffd0); fxLight.position.set(x, 3, z); fxLight.intensity = 55;
  if (!busy && G.time - (G.skyFlashT ?? -9) > 0.8) { G.skyFlashT = G.time; flash(0.06); }
  addShake(busy ? 0.02 : 0.25); sfx('boom');
  addRing(x, z, 0.3, aoe, 0.6, VESPER_GREEN);
  if (!busy) addRing(x, z, aoe * 0.9, aoe * 1.15, 0.45, 0xfff2b0);
  const n = Math.round(18 * SKY_K * (busy ? 0.5 : 1)); // motes and feathers of light drift up out of the circle
  for (let k = 0; k < n; k++) {
    const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * aoe * 0.9, big = k % 3 === 0;
    spark(x + Math.cos(a) * d, 0.2 + Math.random() * 0.6, z + Math.sin(a) * d, big ? 0xffffff : k % 3 === 1 ? 0xfff0a0 : 0x9dffb8,
      { vy: 1.6 + Math.random() * 2.2, vx: Math.cos(a) * 0.3, vz: Math.sin(a) * 0.3, s: big ? 0.45 : 0.28, life: 0.9 + Math.random() * 0.6, drag: 1.4, spread: 0.6 });
  }
  splat(x, z, 0x10200f, aoe * 0.7, 0.6);
  if (dmg > 0) explode({ x, z, aoe, dmg, els: ['storm'], color: VESPER_GREEN });
}
// Smite (user 11-15: "not lightning, just straight holy light from sky"): a narrow, intense gold-white sunbeam straight down
// (overlay 'pillar', thin and fast, no rune circle), a bright light pool on the floor and golden motes. Same blast as before.
function smiteStrike(x, z, dmg, aoe, col, els, noPillar) {
  const busy = skyBusy();
  if (!noPillar) bolts.push({ kind: 'pillar', pts: [new THREE.Vector3(x, 16, z), new THREE.Vector3(x, 0, z)], r: aoe * 0.2, life: 0.45, max: 0.45, color: '255,205,90', core: '255,252,235' });
  fxLight.color.set(0xfff0b0); fxLight.position.set(x, 2.5, z); fxLight.intensity = 60;
  if (!busy && G.time - (G.skyFlashT ?? -9) > 0.8) { G.skyFlashT = G.time; flash(0.08); }
  addShake(busy ? 0.02 : 0.3); sfx('boom');
  addRing(x, z, 0.2, aoe * 0.8, 0.7, 0xfff6c8); // the light pool spreading on the floor
  if (!busy) addRing(x, z, 0.3, aoe + 0.6, 0.3, 0xffffff);
  const n = Math.round(14 * SKY_K * (busy ? 0.5 : 1));
  for (let k = 0; k < n; k++) { const a = Math.random() * 6.283, d = Math.random() * aoe * 0.5; spark(x + Math.cos(a) * d, 0.2, z + Math.sin(a) * d, k & 1 ? 0xffffff : 0xffd870, { vy: 2.5 + Math.random() * 3, s: 0.3, life: 0.6 + Math.random() * 0.5, drag: 1.6, spread: 0.4 }); }
  splat(x, z, 0x1a1608, aoe * 0.9, 0.9);
  if (dmg > 0) explode({ x, z, aoe, dmg, els: els || ['storm'], color: col });
}
// Smite = a holy hammer slam (user 11-15: "a hammer rotating, then it hits"): a big golden war hammer appears high over the foe,
// tumbles end over end as it drops (0.45 s, its shadow and a gold target ring growing), slams head-first: the sunbeam's light
// burst without the pillar, cracks, a heavy shake and a short stun on everything it hits (bosses immune). Same damage / aoe.
const hammers = [], hamR = new THREE.Vector3(), hamU = new THREE.Vector3(); let hamGeo = null, hamMat = null, hamGrip = null, hamEdge = null;
function holyHammer(x, z, dmg, aoe, col, els) {
  if (!hamGeo) { hamGeo = new THREE.BoxGeometry(0.62, 0.36, 0.36); hamGrip = new THREE.CylinderGeometry(0.05, 0.05, 0.95, 8); hamMat = new THREE.MeshLambertMaterial({ color: 0xf2c654, emissive: 0x5a3c08, flatShading: true }); hamEdge = new THREE.MeshBasicMaterial({ color: 0x2a1a04, side: THREE.BackSide }); }
  if (sheets.holy_hammer) { // the painted holy hammer (user 11-15: "get a sprite", "too big"): a camera-facing sprite ~1.1 tall,
    // tumbling in the screen plane, landing head-down
    const m = makeSprite('holy_hammer', 1.1); m.geometry = scytheGeo || (scytheGeo = new THREE.PlaneGeometry(1, 1)); m.material.side = THREE.DoubleSide; m.position.set(x, 4.5, z);
    const sh = makeShadow(0.6); sh.position.set(x, 0.03, z); addRing(x, z, aoe * 1.2, 0.3, 0.45, 0xfff6c8);
    hammers.push({ spr: m, sh, x, z, t: 0, dmg, aoe, col, els, glow: makeGlowAt(x, 4.5, z, 0xffe08a, 1.1, 0.55) }); sfx('whoosh'); return;
  }
  const g = new THREE.Group(), spin = new THREE.Group(); g.add(spin);
  const head = new THREE.Mesh(hamGeo, hamMat); head.position.y = 0.5; const ho = new THREE.Mesh(hamGeo, hamEdge); ho.position.y = 0.5; ho.scale.setScalar(1.1);
  const grip = new THREE.Mesh(hamGrip, new THREE.MeshLambertMaterial({ color: 0xfff2c8, emissive: 0x3a3020 })); grip.position.y = 0.02;
  spin.add(head, ho, grip); g.scale.setScalar(0.9 + aoe * 0.15); g.position.set(x, 4.5, z); scene.add(g);
  const sh = makeShadow(0.9); sh.position.set(x, 0.03, z); addRing(x, z, aoe * 1.4, 0.3, 0.45, 0xfff6c8);
  hammers.push({ g, spin, sh, x, z, t: 0, dmg, aoe, col, els, glow: makeGlowAt(x, 4.5, z, 0xffe08a, 1.6, 0.6) });
  sfx('whoosh');
}
function updateHammers(dt) {
  for (let i = hammers.length - 1; i >= 0; i--) {
    const h = hammers[i]; h.t += dt; const hov = 0.4, k = Math.max(0, Math.min(1, (h.t - hov) / 0.45)), y = 4.5 * (1 - k * k) + 0.05 + (h.t < hov ? Math.sin(h.t * 12) * 0.05 : 0); // shows first, hovering (user 11-15), then falls
    if (h.spr) { // the HEAD follows the drop path and lands on the target (user: 'the edge hits the target, not the middle'): centre = head point minus the turned head offset
      const th = k * Math.PI * 3, ho = 0.36; hamR.set(1, 0, 0).applyQuaternion(camera.quaternion); hamU.set(0, 1, 0).applyQuaternion(camera.quaternion);
      h.spr.position.set(h.x, y + 0.12, h.z).addScaledVector(hamR, ho * Math.sin(th)).addScaledVector(hamU, -ho * Math.cos(th)); h.spr.quaternion.copy(camera.quaternion); h.spr.rotateZ(th); const ap = Math.min(1, h.t / 0.15); setSpriteScale(h.spr, ap, ap); h.glow.scale.setScalar(1.1 * (0.5 + Math.min(1, h.t / hov) * 0.8)); } // 1.5 turns: lands head-down
    else { h.g.position.y = y; h.spin.rotation.z = -k * Math.PI * 3 - Math.PI; } // tumbles end over end, lands head-down
    h.glow.position.set(h.x, y + 0.6, h.z); h.sh.scale.setScalar(0.3 + 0.9 * k);
    if (k < 1) continue;
    if (h.spr) killMesh(h.spr); else { scene.remove(h.g); for (const c of h.spin.children) if (c.material !== hamMat && c.material !== hamEdge) c.material.dispose(); }
    scene.remove(h.sh); killGlow(h.glow); hammers.splice(i, 1);
    smiteStrike(h.x, h.z, h.dmg, h.aoe, h.col, h.els, true); addCrack(h.x, h.z, h.aoe * 0.9, false); addShake(0.35); sfx('slam');
    for (const e of enemies) if (!e.dead && !e.isBoss && Math.hypot(e.x - h.x, e.z - h.z) < h.aoe + e.r) e.stun = Math.max(e.stun || 0, 0.6);
  }
}
function resetHammers() { for (const h of hammers) { if (h.spr) killMesh(h.spr); else scene.remove(h.g); scene.remove(h.sh); killGlow(h.glow); } hammers.length = 0; }
// Momentum: not lightning but amber comets flung from behind the hero (kind 'comet' on the overlay: a tapered streak that slams
// in and pulls its tail down into the impact), then a heavy landing: dust shockwave, glowing cracks, grit. Same small hit as before.
const gazeSeen = new Set();
let momQuiet = false; // Momentum's hits don't add the storm element's yellow arcs: the lance itself bounces to everyone
function momentumStrike(x, z, dmg, aoe, els, sx, sy, sz) { // Momentum (user 11-15: "shit effects-wise", and it read like Thunderfall): Pip HURLS
  // a lightning lance - a thick straight electric spear from the staff to the foe (shoots out in 0.05 s, white-hot core, blue
  // glow, crackle forks), then a shock ring, spark spray and a blue flash where it lands. Same damage / aoe as before.
  const busy = skyBusy(), tp = sx != null ? { x: sx, y: sy, z: sz } : staffTip();
  bolts.push({ pts: [new THREE.Vector3(tp.x, tp.y, tp.z), new THREE.Vector3(x, 0.6, z)], life: 0.22, max: 0.22, grow: 0.05, lance: true, fork: true, color: '#5ab0ff', glow: 'rgba(30,110,255,.6)', w: 11 }); // crackling blue lightning (user: it read as a ray) // blue (user 11-15)
  bolts.push({ pts: [new THREE.Vector3(tp.x, tp.y, tp.z), new THREE.Vector3(x, 0.6, z)], life: 0.16, max: 0.16, grow: 0.05, lance: true, color: '#e8f4ff', glow: 'rgba(60,150,255,.4)', w: 5 });
  later(0.05, () => {
    fxLight.color.set(0x3a9cff); fxLight.position.set(x, 1.5, z); fxLight.intensity = 30;
    addShake(busy ? 0.03 : 0.12); sfx('zap');
    addRing(x, z, 0.2, aoe + 0.6, 0.3, 0x3a9cff); if (!busy) addRing(x, z, 0.1, aoe * 0.7, 0.2, 0x9fd0ff);
    const n = Math.round(14 * SKY_K * (busy ? 0.5 : 1));
    for (let k = 0; k < n; k++) { const a = Math.random() * 6.283, v = 3 + Math.random() * 4; spark(x, 0.6, z, k % 3 ? 0x3a9cff : 0x9fd0ff, { vx: Math.cos(a) * v, vz: Math.sin(a) * v, vy: 1 + Math.random() * 2.5, s: 0.3, life: 0.3 + Math.random() * 0.2, drag: 2, grav: 6 }); }
    splat(x, z, 0x0a1428, aoe * 0.6, 0.6);
    momQuiet = true; if (dmg > 0) for (const e of enemies) if (!e.dead && Math.hypot(e.x - x, e.z - z) < aoe + e.r) hurtEnemy(e, dmg, e.x - x, e.z - z, 2, 0x9fd0ff, els || ['storm']); momQuiet = false;
  });
}
// the densest spot among living foes (the boss counts extra)
function proCluster(fallback) { return densestFoe(fallback); }
// the foe with the most others within rad of it, among foes within range of (cx, cz) (the boss counts extra); no allocation
function densestFoe(fallback, cx = 0, cz = 0, range = Infinity, rad = 2.4) {
  let best = fallback, bn = 0;
  for (const e of enemies) {
    if (e.dead || e.spawn < 0.3 || (range < Infinity && (e.hidden || Math.hypot(e.x - cx, e.z - cz) > range))) continue;
    let n = e.isBoss ? 5 : 0;
    for (const q of enemies) if (!q.dead && q.spawn >= 0.3 && Math.hypot(q.x - e.x, q.z - e.z) < rad) n++;
    if (n > bn) { bn = n; best = e; }
  }
  return best;
}
// a mote (or an item sprite) that arcs from a to b (b may move: pass a function), then calls done
function proFlight(color, size, from, to, dur, arc, done, sprite) {
  const m = makeGlow(color, size, 1); m.material.depthTest = false; m.renderOrder = 11;
  G.prologue.flights.push({ m, sprite, color, from, to, dur, arc, t: 0, done });
}
function proRing(n, mix = ['slime', 'eye'], elites = 0) { // foes crawl out of cracks along the walls
  const r = G.prologue.room;
  for (let k = 0; k < n; k++) {
    const a = k / n * Math.PI * 2 + rr(-0.15, 0.15);
    const x = clamp(r.cx + Math.cos(a) * (r.w / 2 - 0.8), r.x0 + 1.6, r.x0 + r.w + 0.4), z = clamp(r.cz + Math.sin(a) * (r.h / 2 - 0.8), r.z0 + 1.6, r.z0 + r.h + 0.4);
    const type = mix[k % mix.length], elite = k < elites, pt = makePortal(x, z, type, type === 'big' || type === 'golem' ? 1.0 : 0.7, k * 0.04);
    if (elite) { pt.elite = true; pt.hpMul = 1.6; pt.mesh.children[0].material.color.set(0xffc84f); }
    portals.push(pt);
  }
  sfx('portal'); sfx('wave'); addShake(0.25);
}
// the landing room's way out: a gold glow in the doorway and a bobbing arrow pointing through it (on = false clears it)
function proDoorHint(P, on) {
  if (P.door) { killGlow(P.door.glow); scene.remove(P.door.arrow); P.door.arrow.geometry.dispose(); P.door.arrow.material.dispose(); P.door = null; }
  const d = on && P.start !== P.room && P.start.doors[0]; if (!d) return;
  const x = d.cells.reduce((a, c) => a + c[0] + 0.5, 0) / d.cells.length, z = d.cells.reduce((a, c) => a + c[1] + 0.5, 0) / d.cells.length;
  const glow = makeGlowAt(x, 0.8, z, GOLD, 3.4, 0.7);
  const arrow = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.1, 4).rotateX(-Math.PI / 2).scale(1, 0.35, 1), new THREE.MeshBasicMaterial({ color: GOLD, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false }));
  arrow.renderOrder = 9; scene.add(arrow);
  P.door = { x, z, glow, arrow, t: 0 };
}
const proWait = (s) => { let t = 0; return (dt) => (t += dt) >= s; };
const proUntil = (fn, max = 99) => { let t = 0; return (dt) => fn() || (t += dt) >= max; };
// the story beats; each yield is a condition the scene waits for. Talk beats hold Pip still; fight beats are all play.
function* proScript(P) {
  const r = P.room, cleared = () => !portals.length && enemies.every((e) => e.dead), talked = () => !vnBusy();
  const hold = () => { P.hold = { x: player.x, z: player.z }; }, free = () => { P.hold = null; };
  yield proUntil(() => player.dropDelay <= 0 && player.drop <= 0);
  hold(); yield proWait(0.6);
  P.vDrop.t = 0; yield proUntil(() => !P.vDrop); // Vesper drops in beside Pip
  // 1. at the chamber door
  yield proWait(0.5);
  vnSay('i1'); yield proUntil(talked);
  // 2. the way in: Pip walks to the chamber door himself (his first moves, nothing can hurt him yet); the gate bars it behind him
  free(); P.phase = 'walk'; $('pauseBtn').style.visibility = ''; // it can be paused from here
  proDoorHint(P, true);
  const doorTip = () => { P.doorTold = true; tutShow('WALK THROUGH THE DOOR ▲'); };
  if (G.tut && G.tut.step === 0) tutShow(matchMedia('(pointer: coarse)').matches ? 'DRAG ANYWHERE TO MOVE' : 'WASD / ARROWS OR DRAG TO MOVE', true);
  else doorTip();
  yield proUntil(() => { if (!P.doorTold && (!G.tut || G.tut.step > 0)) doorTip(); return P.start === r || player.z < r.z0 + r.h - 0.6; }, Infinity);
  tutHide(); proDoorHint(P, false); P.phase = 'boss'; P.cam = r; // a real fight from here
  lockRoom(r, true); addShake(0.4); flash(0.2); addRing(r.cx, r.cz, 0.3, 6, 0.5, 0xff4fd8); // the chamber seals: the real gate bars, no way out
  P.look = { x: r.cx, z: r.z0 + 3.2 }; later(1.4, () => { if (G.prologue === P && P.phase === 'boss') P.look = null; }); // the camera turns to the King
  // 3. the Stone King, straight away and alone: he spits and drops rocks, and hurting him calls his guard (updateProKing)
  G.boss = BOSSES.find((b) => b.type === 'golemboss'); proHud("THE STONE KING'S CHAMBER", 'FINAL BATTLE');
  portals.push(makePortal(r.cx, r.z0 + 3.2, 'golemboss', 1.6, 0.2)); sfx('lock'); addShake(0.5); flash(0.3);
  banner(G.boss.name, G.boss.sub); bannerT = 2.2;
  yield proUntil(() => (P.boss = enemies.find((e) => e.isBoss && !e.dead)));
  P.boss.hp = P.boss.maxHp = PRO_KING_HP; G.curse = 2; // his guard is tougher than floor-1 foes
  yield proUntil(() => P.boss.dead, 90);
  G.curse = 0;
  if (!P.boss.dead) killEnemy(P.boss); // never let the scene stall on a tanky boss
  for (const e of enemies) if (!e.dead) killEnemy(e);
  portals.length = 0;
  const bx = P.boss.x, bz = P.boss.z;
  // 4. victory, and the drop
  P.phase = 'loot'; proHud('PROLOGUE', '');
  yield proWait(0.6); hold();
  P.staff = { x: bx, z: bz, t: 0, mesh: makeSprite('gear', 1.1, SLOTS.indexOf('staff')), glow: makeGlow(GOLD, 4.2, 1),
    beam: new THREE.Mesh(new THREE.BoxGeometry(0.34, 6, 0.34), new THREE.MeshBasicMaterial({ color: GOLD, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false })) };
  P.staff.mesh.material.uniforms.uTint.value.setRGB(1.35, 1.15, 0.6); scene.add(P.staff.beam);
  burst(bx, 1, bz, GOLD, 40, 6, 0.6, 0.8); addRing(bx, bz, 0.3, 4, 0.5, GOLD); flash(0.35); sfx('clear'); addShake(0.3);
  banner('<span style="color:#ffc04f">GRAND STAFF</span>', 'LEGENDARY'); bannerT = 2.6;
  P.look = { x: bx, z: bz }; // the camera leans toward it
  vnSay('p2', 'v1'); yield proUntil(talked);
  P.look = null; free();
  // 5. Pip picks it up: walk to it (a hint shows), or it comes to Pip after 1.5 s
  tutShow('PICK UP THE GRAND STAFF');
  yield proUntil(() => Math.hypot(player.x - bx, player.z - bz) < 1.1, 1.5);
  tutHide(); hold();
  { const s = P.staff; killMesh(s.mesh); scene.remove(s.beam); s.beam.material.dispose(); killGlow(s.glow); P.staff = null;
    proFlight(GOLD, 1.6, { x: s.x, y: 1.2, z: s.z }, () => ({ x: player.x, y: 0.9, z: player.z }), Math.hypot(player.x - s.x, player.z - s.z) < 1.5 ? 0.25 : 0.8, 1.2, () => {
      P.held = makeGlow(GOLD, 1.3, 0.95); P.held.material.depthTest = false; P.held.renderOrder = 12;
      flash(0.4); sfx('heal'); sfx('clear'); addShake(0.25); G.slowmo = 0.4;
      burst(player.x, 1, player.z, GOLD, 50, 5, 0.6, 0.8); addRing(player.x, player.z, 0.2, 3, 0.5, GOLD); addRing(player.x, player.z, 0.2, 1.8, 0.7, 0xffffff);
      player.mesh.material.uniforms.uFlash.value = 0.8;
    }, makeSprite('gear', 1.1, SLOTS.indexOf('staff'))); }
  yield proUntil(() => P.held, 3);
  vnSay('p3'); yield proUntil(talked);
  // 6. Vesper turns
  P.phase = 'betray'; P.evil = true;
  P.ally.material.uniforms.uTint.value.setRGB(0.55, 1, 0.65); P.allyGlow.material.color.set(0x3dff7a); P.allyGlow.scale.setScalar(1.1); sfx('moan'); addShake(0.2);
  vnSay('v2'); yield proUntil(talked);
  P.cast = 1; P.allyGlow.scale.setScalar(2); vesperStrike(player.x, player.z, 0, 1.6);
  proFlight(VESPER_GREEN, 1.5, { x: P.ax, y: 0.85, z: P.az }, () => ({ x: player.x, y: 0.6, z: player.z }), 0.45, 0.3, () => {
    P.frozen = { x: player.x, z: player.z };
    player.mesh.material.uniforms.uTint.value.setRGB(0.6, 0.9, 1.5);
    P.ice = new THREE.Mesh(new THREE.BoxGeometry(0.95, 1.35, 0.8).translate(0, 0.67, 0), new THREE.MeshBasicMaterial({ color: 0x9fe7ff, transparent: true, opacity: 0.38, blending: THREE.AdditiveBlending, depthWrite: false }));
    P.ice.position.set(player.x, 0, player.z); scene.add(P.ice);
    flash(0.5); trauma = Math.max(trauma, 0.7); G.slowmo = 0.5; sfx('frost'); sfx('hit'); addRing(player.x, player.z, 0.2, 3.2, 0.4, VESPER_GREEN);
    burst(player.x, 0.8, player.z, VESPER_GREEN, 30, 5, 0.5, 0.5);
    burst(player.x, 0.7, player.z, 0x9fe7ff, 40, 5, 0.5, 0.6); addRing(player.x, player.z, 0.2, 2.6, 0.4, 0x9fe7ff);
  });
  sfx('laser');
  yield proUntil(() => P.frozen, 3);
  vnSay('p4', 'v3');
  yield proUntil(() => VN.q.length === 0 && VN.line && VN.line[0] === 'vesper_evil');
  // every rune, every item, and last the Grand Staff, torn out one by one
  const vesperHand = () => ({ x: P.ax, y: 0.85, z: P.az });
  const rip = (col, name, sprite, size = 0.9, dur = 0.7) => {
    addText(player.x, 1.5, player.z, name, '#' + new THREE.Color(col).getHexString(), 0.9);
    flash(0.1); addShake(0.18); sfx('hit'); burst(player.x, 0.8, player.z, col, 14, 4, 0.4, 0.4);
    proFlight(col, size, { x: player.x, y: 0.8, z: player.z }, vesperHand, dur, 1.6, (b) => { burst(b.x, 0.8, b.z, col, 16, 3, 0.4, 0.5); P.allyGlow.scale.multiplyScalar(1.07); sfx('orb'); }, sprite);
  };
  while (spells.length) {
    const s = spells.pop(), d = spellDef(s.id);
    if (d.sh && d.sh.beh === 'orbit') for (const o of orbs) if (o.sid === s.id) o.life = Math.min(o.life, 0.05); // its orbs go with it
    if (d.sh && d.sh.beh === 'summon') for (const w of wisps) w.life = Math.min(w.life, 0.05);
    buildSpellHud(); rip(hexOf(d.color), d.name);
    yield proWait(0.14);
  }
  for (const k of PRO_LOOT) { rip(hexOf(RARITY[2].color), SLOT_NAMES[k], makeSprite('gear', 0.6, SLOTS.indexOf(k))); yield proWait(0.17); }
  yield proWait(0.35);
  { // the Grand Staff, last and biggest
    killGlow(P.held); P.held = null; G.slowmo = 0.8;
    addText(player.x, 1.7, player.z, 'GRAND STAFF', '#ffc04f', 1.3); flash(0.4); trauma = Math.max(trauma, 0.6); sfx('boom');
    burst(player.x, 1, player.z, GOLD, 40, 6, 0.6, 0.7);
    proFlight(GOLD, 1.8, { x: player.x, y: 1, z: player.z }, vesperHand, 1.1, 2.2, () => {
      P.vStaff = makeSprite('gear', 1.0, SLOTS.indexOf('staff')); P.vStaff.material.uniforms.uTint.value.setRGB(1.35, 1.15, 0.6);
      P.allyGlow.material.color.set(GOLD); P.allyGlow.scale.setScalar(2.2); flash(0.3); sfx('clear'); addRing(P.ax, P.az, 0.2, 3, 0.5, GOLD);
    }, makeSprite('gear', 1.1, SLOTS.indexOf('staff')));
  }
  yield proUntil(() => P.vStaff, 3);
  yield proUntil(talked);
  vnSay('v4'); yield proUntil(talked);
  // Vesper vanishes with everything; the floor gives way
  burst(P.ax, 0.8, P.az, VESPER_GREEN, 40, 6, 0.6, 0.7); burst(P.ax, 0.8, P.az, 0xa35cff, 30, 4, 0.5, 0.6); burst(P.ax, 1, P.az, GOLD, 20, 4, 0.5, 0.6);
  addRing(P.ax, P.az, 0.3, 3, 0.5, VESPER_GREEN); flash(0.3); sfx('portal');
  proDropAlly(P);
  yield proWait(0.5);
  trauma = 1; flash(0.5); sfx('slam'); sfx('stairs');
  if (P.ice) { burst(player.x, 0.7, player.z, 0x9fe7ff, 30, 6, 0.4, 0.6); chunk(player.x, 0.6, player.z, 0xbff3ff, 12, 6, 0.14); scene.remove(P.ice); P.ice.material.dispose(); P.ice = null; }
  for (let k = 0; k < 14; k++) { const a = rr(0, 6.28), d = rr(0.5, 3.8), x = player.x + Math.cos(a) * d, z = player.z + Math.sin(a) * d; splat(x, z, 0x030303, rr(0.8, 1.8)); chunk(x, 0.1, z, 0x2a2430, 6, 6, 0.16); }
  addRing(player.x, player.z, 0.2, 4.5, 0.6, 0xffffff);
  yield proWait(0.7);
  $('fade').style.opacity = 1;
  yield proWait(0.6);
  endPrologue();
}
function proDropAlly(P) {
  if (P.ally) { killMesh(P.ally); scene.remove(P.allyShadow); killGlow(P.allyGlow); P.ally = P.allyGlow = null; }
  if (P.vStaff) { killMesh(P.vStaff); P.vStaff = null; }
}
function proUpdate(dt) {
  const P = G.prologue, r = P.room; P.t += dt;
  // the landing room until the walk, the walls alone on the way to the chamber, then the chamber; frozen means frozen
  const walk = P.phase === 'walk', cr = P.phase === 'intro' ? P.start : walk ? null : r;
  if (cr) { player.x = clamp(player.x, cr.x0 + 1.4, cr.x0 + cr.w + 0.6); player.z = clamp(player.z, cr.z0 + 1.4, cr.z0 + cr.h + 0.6); }
  if (walk) P.cam = player.z > P.start.z0 + 1 ? P.start : player.z < r.z0 + r.h + 1 ? r : null; // the camera follows Pip in the corridor
  if (P.door) { // the door hint: the arrow bobs toward the doorway, the glow breathes
    const D = P.door; D.t += dt; const b = (D.t * 1.6) % 1;
    D.arrow.position.set(D.x, 0.25, D.z + 2.2 - b * 1.2); D.arrow.material.opacity = 0.9 * Math.sin(b * Math.PI);
    D.glow.material.opacity = 0.55 + 0.25 * Math.sin(D.t * 4);
  }
  if (P.hold && !P.frozen) { player.x = P.hold.x; player.z = P.hold.z; player.vx = player.vz = 0; }
  if (P.frozen) {
    player.x = P.frozen.x; player.z = P.frozen.z; player.vx = player.vz = 0;
    if (fxP(0.5)) spark(player.x + rr(-0.5, 0.5), rr(0.1, 1.3), player.z + rr(-0.4, 0.4), 0xbff3ff, { vy: rr(0.3, 1), s: 0.3, life: 0.5, drag: 1 });
    if (P.ice) P.ice.material.opacity = 0.32 + Math.sin(P.t * 5) * 0.06;
  }
  for (let i = P.flights.length - 1; i >= 0; i--) {
    const f = P.flights[i]; f.t += dt;
    const k = Math.min(1, f.t / f.dur), b = typeof f.to === 'function' ? f.to() : f.to, e = k * k * (3 - 2 * k);
    const x = lerp(f.from.x, b.x, e), z = lerp(f.from.z, b.z, e), y = lerp(f.from.y, b.y, e) + Math.sin(k * Math.PI) * f.arc;
    f.m.position.set(x, y, z); if (fxP(0.8)) spark(x, y, z, f.color, { s: 0.35, life: 0.3, drag: 2 });
    if (f.sprite) { f.sprite.position.set(x, y - f.sprite.userData.bh * 0.5, z); billboard(f.sprite, f.t * 8); }
    if (k >= 1) { killGlow(f.m); if (f.sprite) killMesh(f.sprite); P.flights.splice(i, 1); if (f.done) f.done(b); }
  }
  if (P.staff) { // the dropped Grand Staff bobs in its rainbow beam
    const s = P.staff; s.t += dt;
    s.mesh.position.set(s.x, 0.25 + Math.sin(s.t * 3) * 0.08, s.z); billboard(s.mesh);
    s.beam.position.set(s.x, 3, s.z); s.beam.material.color.setHSL((s.t * 0.4) % 1, 0.9, 0.62); s.glow.position.set(s.x, 0.7, s.z);
    if (fxP(0.6)) spark(s.x + rr(-0.3, 0.3), rr(0.2, 2), s.z + rr(-0.3, 0.3), GOLD, { vy: 1.5, s: 0.3, life: 0.6, drag: 0 });
  }
  for (const m of P.marks) { m.t += dt; const k = Math.min(1, m.t / m.warn); m.mk.scale.setScalar(0.95 * (0.5 + 0.5 * k)); m.mk.material.opacity = 0.55 + 0.4 * Math.abs(Math.sin(m.t * (8 + k * 10))); } // Rockfall circles grow and blink faster until the rocks land
  if (P.shield > 0) { // Vesper's shield: a pulsing green light around Pip while nothing can hit him
    P.shield -= dt; if (!P.shieldGlow) { P.shieldGlow = makeGlow(0x7dff9a, 2.2, 0.75); P.shieldGlow.material.depthTest = false; P.shieldGlow.renderOrder = 9; }
    P.shieldGlow.visible = P.shield > 0; P.shieldGlow.position.set(player.x, 0.8, player.z); P.shieldGlow.scale.setScalar(2.1 + Math.sin(P.t * 14) * 0.25); if ((P.shRing = (P.shRing || 0) - dt) <= 0) { P.shRing = 0.45; addRing(player.x, player.z, 0.6, 1.5, 0.45, VESPER_GREEN); } // a green bubble pulsing on the floor
    if (fxP(0.5)) spark(player.x + rr(-0.5, 0.5), rr(0.2, 1.4), player.z + rr(-0.4, 0.4), 0xfff2b0, { vy: 1.2, s: 0.3, life: 0.4, drag: 0 });
  }
  if (P.held) { P.held.position.copy(staffTip()); P.held.scale.setScalar(1.2 + Math.sin(P.t * 8) * 0.12); if (fxP(0.4)) spark(P.held.position.x, P.held.position.y, P.held.position.z, GOLD, { vy: 1, s: 0.3, life: 0.4 }); }
  // Vesper: a strong teammate. She strafes around Pip and never stops casting: a fast stream of homing green bolts at the
  // nearest foes, and every few seconds a big green blast on the thickest crowd (or the boss)
  const ally = P.ally;
  if (ally && (P.phase === 'fight' || P.phase === 'boss')) {
    const a = P.t * 0.9, tx = player.x + Math.cos(a) * 1.7, tz = player.z + 0.3 + Math.sin(a) * 1.1;
    const k = damp(4, dt); P.ax += (tx - P.ax) * k; P.az += (tz - P.az) * k;
    P.ax = clamp(P.ax, r.x0 + 1.4, r.x0 + r.w + 0.6); P.az = clamp(P.az, r.z0 + 1.4, r.z0 + r.h + 0.6);
    P.skyT = (P.skyT ?? 1.5) - dt;
    if (P.skyT <= 0 && enemies.some((e) => !e.dead && e.spawn >= 0.3)) { // she raises her staff and calls the sky down
      P.skyT = 2.6; P.cast = 1; P.allyGlow.scale.setScalar(1.6); spark(P.ax, 1.6, P.az, 0xffffff, { s: 1.2, life: 0.15, drag: 0 });
      const hit = new Set();
      for (let k = 0; k < 3; k++) later(0.18 + k * 0.16, () => {
        if (!G.prologue) return;
        const live = enemies.filter((e) => !e.dead && !hit.has(e));
        const c = proCluster(live[0]) || live[0]; if (!c) return;
        hit.add(c); vesperStrike(c.x + rr(-0.3, 0.3), c.z + rr(-0.3, 0.3), c.isBoss ? 380 : 220, 2.3);
      });
    }
    if ((P.cd -= dt) <= 0) {
      const tg = nearestEnemy(P.ax, P.az, 9);
      if (tg) {
        P.face = tg.x >= P.ax ? 1 : -1; P.cast = Math.max(P.cast, 0.6); sfx('zap');
        P.cd = 0.16;
        proFlight(VESPER_GREEN, 0.55, { x: P.ax + 0.3 * P.face, y: 0.85, z: P.az }, () => ({ x: tg.x, y: 0.45, z: tg.z }), 0.22, 0.25, (b) => explode({ x: b.x, z: b.z, aoe: 0.9, dmg: tg.isBoss ? 70 : 45, els: ['shadow'], color: VESPER_GREEN }));
      } else P.cd = 0.15;
    }
  } else if (ally) { // the story beats: she walks up to stand face to face with Pip
    const side = P.ax >= player.x ? 1 : -1, tx = player.x + side * (walk ? 0.8 : 1.9), tz = player.z + (walk ? 1.2 : 0.2); // on the walk she follows a step behind (the corridor is narrow)
    if (!P.frozen || Math.hypot(tx - P.ax, tz - P.az) > 0.3) { const k = damp(walk ? 4 : 2.5, dt); P.ax += (tx - P.ax) * k; P.az += (tz - P.az) * k; }
    if (cr) { P.ax = clamp(P.ax, cr.x0 + 1.4, cr.x0 + cr.w + 0.6); P.az = clamp(P.az, cr.z0 + 1.4, cr.z0 + cr.h + 0.6); }
    P.face = player.x >= P.ax ? 1 : -1;
  }
  if (ally) { // cast flash: a green pulse and a little hop on every shot
    P.cast = Math.max(0, (P.cast || 0) - dt * 6);
    ally.material.uniforms.uFlash.value = P.cast * 0.55; ally.material.uniforms.uFlashCol.value.set(VESPER_GREEN);
    setSpriteScale(ally, 1 + P.cast * 0.08, 1 - P.cast * 0.06);
  }
  let vy = 0;
  if (ally && P.vDrop) { // hidden until her cue, then a fast fall and a hard landing like Pip's
    const D = P.vDrop;
    if (D.t < 0) { ally.visible = P.allyShadow.visible = P.allyGlow.visible = false; }
    else {
      D.t += dt; const k = Math.min(1, D.t / 0.3); vy = (1 - k) * (1 - k) * 12;
      ally.visible = P.allyShadow.visible = P.allyGlow.visible = true; P.allyShadow.scale.set(0.3 + k * 0.5, 1, (0.3 + k * 0.5) * 0.8);
      for (let q = fxN(3); q > 0; q--) spark(P.ax + rr(-0.15, 0.15), vy + rr(0, 1.5), P.az, VESPER_GREEN, { s: 0.5, life: 0.18, drag: 0 });
      if (k >= 1) {
        P.vDrop = null; P.cast = 1; trauma = Math.max(trauma, 0.7); G.hitstop = 0.06; flash(0.25); sfx('slam'); sfx('land');
        addRing(P.ax, P.az, 0.2, 3, 0.35, 0xffffff); addRing(P.ax, P.az, 0.2, 2.2, 0.5, VESPER_GREEN);
        splat(P.ax, P.az, 0x050505, 2.2); burst(P.ax, 0.5, P.az, VESPER_GREEN, 26, 5, 0.4, 0.5); chunk(P.ax, 0.2, P.az, 0x5a5660, 10, 5, 0.12);
      }
    }
  }
  if (ally) {
    ally.position.set(P.ax, vy + (P.evil ? 0 : Math.abs(Math.sin(P.t * 6)) * 0.04), P.az); billboard(ally);
    ally.material.uniforms.uFlip.value = P.face < 0 ? 1 : 0;
    P.allyShadow.position.set(P.ax, 0.02, P.az); P.allyGlow.position.set(P.ax + 0.3 * P.face, 0.95, P.az);
    if (P.evil && fxP(0.5)) spark(P.ax + rr(-0.4, 0.4), rr(0, 1.2), P.az + rr(-0.3, 0.3), VESPER_GREEN, { vy: 1.2, s: 0.3, life: 0.5, drag: 0 });
  }
  if (P.vStaff) { P.vStaff.position.set(P.ax + 0.45 * P.face, 0.1, P.az + 0.05); billboard(P.vStaff, -0.3 * P.face); }
  // run the story
  if (P.run && (!P.wait || P.wait(dt))) { const n = P.run.next(); P.wait = n.done ? null : n.value; if (n.done) P.run = null; }
}
// skip or the end of the betrayal: the real run starts at level 1 with only your starting rune
function endPrologue() {
  const P = G.prologue; if (!P) return;
  for (const f of P.flights) { killGlow(f.m); if (f.sprite) killMesh(f.sprite); }
  proDropAlly(P);
  if (P.staff) { killMesh(P.staff.mesh); scene.remove(P.staff.beam); P.staff.beam.material.dispose(); killGlow(P.staff.glow); }
  if (P.held) killGlow(P.held);
  if (P.shieldGlow) killGlow(P.shieldGlow);
  proDoorHint(P, false); if (P.doorTold) tutHide(); // skipped on the way to the door
  for (const m of P.marks) { scene.remove(m.mk); m.mk.material.dispose(); }
  if (P.ice) { scene.remove(P.ice); P.ice.material.dispose(); }
  vnClose(); $('proSkip').classList.add('hidden'); $('pauseBtn').style.visibility = ''; $('app').classList.remove('proHud');
  G.curse = 0; fxLight.color.set(0xffa040);
  const moved = G.tut && G.tut.step > 0;
  G.prologue = null; G.slowmo = 0; G.boss = BOSSES[0]; meta.prologueDone = true; delete meta.fresh; saveMeta();
  newGame();
  if (moved && G.tut) G.tut.step = 1; // they already know how to move
  bannerT = 0; $('banner').classList.remove('show');
  later(1.6, () => { if (G.state === 'play' && G.floor === 1) { banner('TAKE YOUR<br>RUNES BACK', 'THE TRAITOR HAS YOUR GRAND STAFF'); bannerT = 2.8; } });
}
function updatePlayer(dt) {
  tutUpdate(dt);
  const p = player;
  p.iframe -= dt; p.castT = (p.castT || 0) - dt; if (p.dashT > 0) p.dashT -= dt;
  p.squash *= Math.exp(-8 * dt);
  let ix = input.x, iz = input.z;
  if (AUTO) [ix, iz] = botInput();
  let dropY = 0;
  if (p.dropDelay > 0) { // waiting above the floor: only a growing shadow and a few falling sparks hint where you'll land
    // this floor's art isn't in yet: the drop doesn't start; a plain loading overlay covers the floor until it is
    // (after 20 s it goes anyway and the late art swaps in when it arrives)
    const wait = p.dropDelay >= 1.5 && !fallReady() && (G.fallT || 0) < 20;
    if (wait) { G.fallT = (G.fallT || 0) + dt; if (G.fallT > 0.15) loadGate(true); } else { if (G.fallT) { G.fallT = 0; loadGate(false); } p.dropDelay -= dt; }
    ix = iz = 0; dropY = 40;
    const k = 1 - Math.min(1, p.dropDelay / 1.5);
    p.shadow.scale.set(0.3 + k * 0.6, 1, (0.3 + k * 0.6) * 0.8);
    // per second, not per frame (a 120-144 Hz screen used to rain 2-3x as many)
    if (!wait && Math.random() < k * dt * 24) spark(p.x + rr(-0.4, 0.4), 4 + Math.random() * 3, p.z + rr(-0.4, 0.4), 0xff7fe0, { vy: -8, s: 0.25, life: 0.5, drag: 0 });
  } else if (p.drop > 0) {
    p.drop -= dt; ix = iz = 0;
    const k = Math.max(0, p.drop / 0.22); dropY = k * k * 6;
    for (p.streakN = (p.streakN || 0) + dt * 70; p.streakN >= 1; p.streakN--) spark(p.x + rr(-0.15, 0.15), dropY + rr(0, 1.5), p.z, 0xff7fe0, { s: 0.5, life: 0.18, drag: 0 }); // streak, ~70/s at any frame rate
    if (p.drop <= 0) {
      // IMPACT: hard fast shake, a beat of hit-stop, flash, shockwaves, a crater and flying floor
      p.shadow.scale.set(0.8, 1, 0.64);
      p.squash = 1; trauma = 1; G.hitstop = 0.08; flash(0.3); sfx('slam'); sfx('land');
      addRing(p.x, p.z, 0.2, 3.2, 0.35, 0xffffff); addRing(p.x, p.z, 0.2, 2.2, 0.5, 0xff7fe0);
      splat(p.x, p.z, 0x050505, 2.4); splat(p.x, p.z, 0x2a1030, 1.4);
      const fcol = G.pal ? G.pal.floor : 0x8a96a0;
      chunk(p.x, 0.2, p.z, fcol, 16, 7, 0.16); chunk(p.x, 0.2, p.z, 0x3a3a44, 8, 5, 0.1);
      for (let a = 0; a < 20; a++) { const an = a / 20 * Math.PI * 2; spark(p.x + Math.cos(an) * 0.3, 0.12, p.z + Math.sin(an) * 0.3, a % 3 ? 0xc8d0e0 : 0xff7fe0, { vx: Math.cos(an) * 9, vz: Math.sin(an) * 9, vy: rr(0.5, 2), s: 0.5, life: 0.45, drag: 5 }); }
      burst(p.x, 0.6, p.z, 0xffd0f4, 12, 6, 0.5, 0.5);
      fxLight.position.set(p.x, 1.5, p.z); fxLight.color.set(0xff7fe0); fxLight.intensity = 60; later(0.4, () => fxLight.color.set(0xffa040));
      for (const pot of [...pots]) if (Math.hypot(pot.x - p.x, pot.z - p.z) < 2.5) breakPot(pot);
    }
  }
  const il = Math.hypot(ix, iz); if (il > 1) { ix /= il; iz /= il; }
  p.wantMove = il > 0.1; // channel spells: a lifted finger / no keys = standing still
  {
    const spd0 = moveSpeed(p), tx = ix * spd0, tz = iz * spd0;
    const acc = ices.length && onIce(p.x, p.z) ? (il > 0.1 ? 7 : 2.5) : il > 0.1 ? 38 : 26; // the Frost Matriarch's ice: you slide
    p.vx += clamp(tx - p.vx, -acc * dt, acc * dt); p.vz += clamp(tz - p.vz, -acc * dt, acc * dt);
  }
  moveCircle(p, p.vx * dt, p.vz * dt, p.r, false);
  const spd = Math.hypot(p.vx, p.vz);
  if (Math.abs(p.vx) > 0.3) p.face = p.vx > 0 ? 1 : -1;
  if (p.castT > 0) p.face = p.aimX >= 0 ? 1 : -1;
  // walk animation: frame cycle, bounce and little dust puffs (the reference wizard bobs as it runs)
  let bob = 0, tilt = 0, hop = 0;
  if (spd > 0.6) {
    p.anim += dt * 6.5; // same hop rhythm at any speed; faster just means longer hops
    hop = Math.abs(Math.sin(p.anim * Math.PI));
    bob = hop * 0.13;
    tilt = Math.sin(p.anim * Math.PI) * 0.16 - p.face * 0.08;
    p.step -= dt;
    if (p.step <= 0) { p.step = 0.16; spark(p.x - p.vx * 0.04, 0.06, p.z - p.vz * 0.04, 0x9aa4b4, { vy: 0.6, vx: rr(-0.5, 0.5), vz: rr(-0.5, 0.5), s: 0.3, life: 0.35, drag: 4 }); }
  } else { p.anim = 0; bob = Math.sin(G.time * 2.4) * 0.07; tilt = Math.sin(G.time * 1.3) * 0.05; } // idle: hover and sway
  p.hover = (p.hover || 0) + ((spd > 0.6 ? 0 : 0.16) - (p.hover || 0)) * Math.min(1, dt * 4); bob += p.hover;
  const m = p.mesh, u = m.material.uniforms;
  const breathe = spd < 0.6 ? Math.sin(G.time * 3) * 0.02 : 0;
  const land = spd > 0.6 ? (1 - hop) * 0.12 : 0; // squash at the bottom of each hop
  setSpriteScale(m, (1 + p.squash * 0.3 - breathe + land) * (p.castT > 0 ? 1.08 : 1), 1 - p.squash * 0.3 + breathe - land + (p.castT > 0 ? -0.05 : 0));
  m.position.set(p.x, bob + dropY, p.z);
  billboard(m, tilt);
  u.uFlip.value = p.face < 0 ? 1 : 0;
  u.uFlash.value = p.iframe > 0 ? (Math.sin(G.time * 40) > 0 ? 0.7 : 0) : 0;
  u.uFlashCol.value.set(0xff3050);
  m.visible = p.alive;
  p.shadow.position.set(p.x, 0.04, p.z);
  pLight.position.set(p.x, 1.6, p.z + 0.4);
  pLight.intensity = 18 + (p.castT > 0 ? 7 : 0) + Math.sin(G.time * 9) * 0.6;
  if (MOBILE && fxLight.intensity > 0.5) pLight.intensity += fxLight.intensity * 0.35 * Math.max(0, 1 - Math.hypot(fxLight.position.x - p.x, fxLight.position.z - p.z) / 9); // phones: no fxLight
  // staff sparkle
  const tp = staffTip();
  // charge-up: the crystal swells in the colour of the next spell as its cooldown runs out, sparks get sucked in
  let next = null;
  for (const sp of spells) if (!next || sp.t < next.t) next = sp;
  const hasTarget = enemies.some((e) => !e.dead && !e.hidden && e.spawn >= 0.3);
  const charge = next && hasTarget ? 1 - clamp(next.t / 0.5, 0, 1) : 0;
  const col = next ? SPELLS[next.id].color : '#ff7fe0';
  p.staffGlow.position.copy(tp); p.staffGlow.visible = p.alive;
  p.staffGlow.material.color.set(col);
  p.staffGlow.material.opacity = 0.55 + charge * 0.45;
  p.staffGlow.scale.setScalar(0.32 + Math.sin(G.time * 6) * 0.04 + charge * charge * 0.95 + (charge > 0.85 ? Math.sin(G.time * 40) * 0.08 : 0) + (p.castT > 0 ? p.castT * 2.6 : 0));
  if (charge > 0.35 && Math.random() < charge) {
    const a = Math.random() * 6.28, r = 0.35 + Math.random() * 0.25, ox = Math.cos(a) * r, oy = (Math.random() - 0.3) * r, oz = Math.sin(a) * r * 0.5;
    spark(tp.x + ox, tp.y + oy, tp.z + oz, col, { vx: -ox * 5.5, vy: -oy * 5.5, vz: -oz * 5.5, s: 0.18 + charge * 0.12, life: 0.18, drag: 0 });
  } else if (fxP(0.12)) spark(tp.x, tp.y, tp.z, 0xff9be8, { vy: 0.5, s: 0.14, life: 0.4, spread: 0.25 });
}
let ghostT = 0;
function ghostTrail() {
  ghostT -= 1 / 60;
  if (ghostT > 0) return; ghostT = 0.04;
  const g = makeSprite('wizard'); const u = g.material.uniforms;
  u.uFlash.value = 0.8; u.uFlashCol.value.set(0xff6fe0); u.uFlip.value = player.face < 0 ? 1 : 0;
  g.material.transparent = true; u.uAlpha.value = 0.6;
  g.position.set(player.x, 0, player.z); g.quaternion.copy(camera.quaternion);
  texts.push({ ghost: g, life: 0.25 });
}
// something ended up inside a pillar (knockback, a spawn, a coin bounce): move it to the nearest open tile
function unstick(o) {
  if (cellAt(o.x, o.z) !== OBST) return;
  const ci = Math.floor(o.x), cj = Math.floor(o.z);
  let best = null, bd = 9;
  for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
    if (cellAt(ci + di + 0.5, cj + dj + 0.5) !== FLOOR) continue;
    const d = Math.hypot(ci + di + 0.5 - o.x, cj + dj + 0.5 - o.z);
    if (d < bd) { bd = d; best = [ci + di + 0.5, cj + dj + 0.5]; }
  }
  if (best) { o.x = best[0]; o.z = best[1]; }
}
function moveCircle(o, dx, dz, r, fly) {
  if (!(Math.abs(dx) < 1e3 && Math.abs(dz) < 1e3)) return; // a NaN / runaway step must never spin this loop (it froze the page once)
  const steps = Math.min(64, Math.ceil(Math.max(Math.abs(dx), Math.abs(dz)) / 0.25) || 1);
  dx /= steps; dz /= steps;
  for (let s = 0; s < steps; s++) {
    if (dx) { const nx = o.x + dx, ex = nx + Math.sign(dx) * r; if (!solid(ex, o.z - r * 0.8, fly) && !solid(ex, o.z + r * 0.8, fly)) o.x = nx; else o.wallHit = true; }
    if (dz) { const nz = o.z + dz, ez = nz + Math.sign(dz) * r; if (!solid(o.x - r * 0.8, ez, fly) && !solid(o.x + r * 0.8, ez, fly)) o.z = nz; else o.wallHit = true; }
  }
}

// ---------- pickups / props ----------
function dropPickup(x, z, kind, wait = false) { // wait: a coin that stays on the floor until the room is clear (Coin Spray)
  const mesh = makeSprite('items', kind === 'heart' ? 0.5 : 0.38, kind === 'heart' ? 2 : 0);
  const a = Math.random() * Math.PI * 2, v = rr(1, 3.5);
  pickups.push({ kind, x, z, y: 0.3, vx: Math.cos(a) * v, vz: Math.sin(a) * v, vy: rr(4, 7), mesh, shadow: makeShadow(0.35), t: 0, spin: Math.random() * 6, wait });
}
function updatePickups(dt) {
  G.hold = null; // the countdown ring is set again by whatever the player is standing on (a gear swap, a shop pedestal)
  if ((G.coinT -= dt) <= 0) G.coinChain = 0;
  for (let i = pickups.length - 1; i >= 0; i--) {
    const p = pickups[i];
    p.t += dt;
    const dx = player.x - p.x, dz = player.z - p.z, d = Math.hypot(dx, dz);
    const mag = player.magnet * player.g.magnet;
    const held = p.wait && enemies.some((e) => !e.dead && !e.hidden); // Coin Spray coins: on the floor (not even magnet-pulled) until the room is clear (user 11-15)
    const wanted = !held && p.kind !== 'gear' && !(p.kind === 'heart' && player.hp >= player.maxHp); // full-health hearts stay on the floor for later
    if (p.kind === 'coin' && p.t > 0.45 && !held) p.homing = true; // no manual pickup: every coin flies to Pip once it has burst out (Coin Spray's wait for the room to be clear, user 11-15)
    const homing = p.homing && p.kind === 'coin';
    const pulled = (homing || (wanted && p.t > 0.5 && d < mag)) && player.alive;
    if (pulled) {
      if (homing) { // steer straight at Pip, speeding up so a running Pip is still caught
        p.ht = (p.ht || 0) + dt;
        const v = Math.min(26, 6 + p.ht * 18);
        p.vx = dx / d * v; p.vz = dz / d * v;
      } else {
        const pull = 14 * (1 - d / mag) + 4;
        p.vx += dx / d * pull * dt * 4; p.vz += dz / d * pull * dt * 4;
      }
    }
    p.vy -= 22 * dt; p.y += p.vy * dt;
    if (p.y < 0.05) { p.y = 0.05; p.vy = Math.abs(p.vy) > 1.5 ? -p.vy * 0.45 : 0; p.vx *= 0.8; p.vz *= 0.8; }
    p.vx *= Math.exp(-2 * dt); p.vz *= Math.exp(-2 * dt);
    moveCircle(p, p.vx * dt, p.vz * dt, 0.1, pulled); // pulled pickups pass over pillars instead of snagging on them
    if (!pulled && p.y <= 0.05) unstick(p);
    p.mesh.position.set(p.x, p.y + Math.sin(p.t * 4) * 0.04, p.z);
    p.mesh.quaternion.copy(camera.quaternion);
    if (p.kind === 'coin') setSpriteScale(p.mesh, Math.abs(Math.cos(p.t * 5 + p.spin)) * 0.9 + 0.1, 1);
    if (p.beam) { p.beam.position.set(p.x, 2.5, p.z); p.glow.position.set(p.x, p.y + 0.3, p.z); p.beam.material.opacity = 0.75 + Math.sin(p.t * 4) * 0.25; p.beam.scale.x = p.beam.scale.z = 1 + Math.sin(p.t * 4) * 0.25; }
    p.shadow.position.set(p.x, 0.04, p.z);
    if (p.kind === 'gear') { if (d > 0.9) p.armed = true; if (d >= 0.5) { p.hold = 0; p.shown = false; if (G.cmpFor === p) hideSwapCompare(); } } // stepping off resets the swap
    if (d < 0.5 && p.t > 0.35 && player.alive && !held) {
      if (p.kind === 'coin') { const got = 1 + (Math.random() < (G.coinMul || 1) - 1 ? 1 : 0); G.coins += got; G.run.coins += got; sfx('coin', G.coinChain++); G.coinT = 0.7; spark(p.x, 0.4, p.z, 0xffd34f, { s: 0.5, life: 0.2, drag: 0 }); $('coins').textContent = G.coins; }
      else if (p.kind === 'gear') {
        if (p.t < 0.6) continue;
        const cur = player.gear[p.item.slot];
        if (cur) { // the slot is taken: stand on it for 3 seconds to swap; the old piece drops where you stand
          if (!p.armed) continue; // a piece you just swapped out waits until you step off it
          if (!p.shown) { p.shown = true; showSwapCompare(cur, p.item); G.cmpFor = p; }
          p.hold = (p.hold || 0) + dt; G.hold = { p: p.hold / 3, left: 3 - p.hold, col: RARITY[p.item.rarity].color };
          if (p.hold < 3) continue;
          hideSwapCompare(); player.gear[p.item.slot] = p.item; recalcStats(); sfx('card');
          toast(`<span style="color:${RARITY[p.item.rarity].color}">${p.item.name}</span>`, `EQUIPPED · ${gearLines(p.item).join(' · ')}`);
          dropGear(p.x, p.z, 0, cur);
        } else equipOrStash(p.item);
        scene.remove(p.beam); killGlow(p.glow);
      }
      else if (p.kind === 'heart') { if (player.hp >= player.maxHp) continue; player.hp = Math.min(player.maxHp, player.hp + 2); sfx('heal'); renderHearts(); burst(p.x, 0.5, p.z, 0xff4a6a, 10, 3, 0.4, 0.5); addText(player.x, 1.4, player.z, '+1', '#ff6a8a', 1.2); }
      killMesh(p.mesh); scene.remove(p.shadow); pickups.splice(i, 1);
    }
  }
}
function breakPot(pot) {
  const i = pots.indexOf(pot); if (i < 0) return;
  pots.splice(i, 1); scene.remove(pot.mesh);
  if (pot.barrel) {
    chunk(pot.x, 0.4, pot.z, 0xa8231c, 10, 7, 0.14);
    explode({ x: pot.x, z: pot.z, aoe: 2.5, dmg: 55 });
    burst(pot.x, 0.6, pot.z, 0xffe08a, 20, 9, 0.7, 0.5);
    addShake(0.4);
    if (player.alive && Math.hypot(player.x - pot.x, player.z - pot.z) < 2.2) damagePlayer(1, pot.x, pot.z);
    return;
  }
  chunk(pot.x, 0.3, pot.z, 0xa8643c, 8, 4, 0.12); sfx('pot');
  if (rand() < 0.45) dropPickup(pot.x, pot.z, 'coin');
  if (rand() < 0.02 && player.hp < player.maxHp) dropPickup(pot.x, pot.z, 'heart');
}
function updateProps(dt) {
  for (const p of props) {
    if (p.glow) p.glow.material.opacity = (p.glowBase = p.glowBase || p.glow.material.opacity) * (0.75 + Math.sin(G.time * 3) * 0.25);
    const d = Math.hypot(player.x - p.x, player.z - p.z);
    if (p.kind === 'chest' && !p.opened) {
      p.mesh.quaternion.copy(camera.quaternion);
      p.mesh.position.y = 0.08 + Math.abs(Math.sin(G.time * 2)) * 0.06;
      if (p.mimic && d < 2.2 && fxP(0.04)) { p.mesh.position.y += 0.12; spark(p.x, 0.5, p.z, 0x3a2418, { vy: 2, s: 0.3, life: 0.3 }); } // it twitches...
      if (d < 0.9 && p.mimic) {
        p.opened = true; killMesh(p.mesh); p.mesh = null; killGlow(p.glow); p.glow = null;
        const r = p.room; r.cleared = false; r.active = true; r.waves = 0; r.mimic = true; lockRoom(r, true);
        const m = spawnEnemy('mimic', p.x, p.z, true); m.spawn = 1; m.state = 'wait'; m.st = 0.5;
        banner('MIMIC!', 'THE CHEST BITES BACK'); addShake(0.6); flash(0.4); sfx('hurt');
        damagePlayer(1, p.x, p.z);
        continue;
      }
      if (d < 0.9) {
        p.opened = true; killMesh(p.mesh); p.mesh = null; G.saveDue = true; G.pendT = G.run.time;
        burst(p.x, 0.6, p.z, 0xffd34f, 40, 6, 0.5, 0.8); chunk(p.x, 0.4, p.z, 0x8a5a2a, 10, 5, 0.13); flash(0.3); addShake(0.3);
        for (let k = 0; k < (player.der.chestLoot ? 12 : 6); k++) dropPickup(p.x, p.z, 'coin'); // LUK 5: double chest coins
        if (player.der.chestLoot && rand() < 0.25) dropGear(p.x, p.z, 0);
        sfx('chest');
        if (p.small) { for (let k = 0; k < 2 + Math.floor(G.floor / 2); k++) dropPickup(p.x, p.z, 'coin'); if (rand() < 0.35) dropGear(p.x, p.z, 0); continue; } // calm-room cache: no card pick
        const cards = () => { if (!G.run.boon) { G.run.boon = true; openCards('TREASURE', boonOptions()); } else openCards(p.gold ? 'GOLDEN CHEST' : 'TREASURE', relicOptions(1).concat(upgradeOptions().slice(0, 1), [gearCard(p.gold ? 2 : 1)])); };
        later(0.25, cards); // straight to the cards: the big reveal is for the Daily Chest (user)
      }
    }
    if (p.kind === 'shop' && !p.sold) {
      p.mesh.quaternion.copy(camera.quaternion);
      p.mesh.position.y = 0.75 + Math.sin(G.time * 2 + p.x) * 0.06;
      const buyT = 1.5; // stand on the pedestal to buy, like the stairs
      if (d < 0.75 && G.coins >= p.offer.price) { p.hold = (p.hold || 0) + dt; G.hold = { p: p.hold / buyT, left: buyT - p.hold, col: '#7fffd4' }; }
      else p.hold = 0;
      if (d < 0.75) {
        if (G.coins >= p.offer.price && p.hold >= buyT) {
          p.hold = 0;
          G.coins -= p.offer.price; $('coins').textContent = G.coins;
          p.sold = true; killMesh(p.mesh); killGlow(p.glow); p.glow = null; G.saveDue = true; sfx('heal'); burst(p.x, 0.8, p.z, 0x7fffd4, 20, 4, 0.4, 0.6);
          if (p.offer.kind === 'heal') { player.hp = Math.min(player.maxHp, player.hp + 2); renderHearts(); toast('HEALED', '+1 heart'); }
          if (p.offer.kind === 'upgrade') { const up = spells.filter((s) => canLevel(s)); if (up.length) { const s = pick(up); s.lv++; buildSpellHud(); toast(spellDef(s.id).name.toUpperCase() + ' LV' + s.lv, levelText(spellDef(s.id), s.lv)); } }
          if (p.offer.kind === 'gear') equipOrStash(rollGear(rand, G.floor, player.g.luck + player.der.loot, 1));
          if (p.offer.kind === 'relic') { const r = relicOptions(1)[0]; r.pick(); }
        } else if (!p.warned || G.time - p.warned > 2) { p.warned = G.time; toast(`${p.offer.price} COINS`, p.offer.label); }
      }
    }
    if (p.kind === 'shrine') {
      p.mesh.quaternion.copy(camera.quaternion);
      if (!p.used && fxP(0.3)) spark(p.x + rr(-0.2, 0.2), 1.1, p.z, p.bless ? CALM_LIGHT : 0xff2a4a, { vy: 1.2, s: 0.25, life: 0.6, drag: 0 });
      if (p.used === false && d > 1.6) p.armed = true;
      if (!p.used && d < 0.9 && G.state === 'play' && p.armed !== false) {
        p.armed = false;
        p.used = true; G.saveDue = true; G.pendT = G.run.time;
        if (p.bless) later(0.2, () => { if (G.state !== 'play') { p.used = false; return; } openCards('SHRINE OF LIGHT', blessOptions(p)); }); // busy (a level-up pick): it waits
        else later(0.2, () => openCards('BLOOD SHRINE', shrineOptions(p)));
      }
    }
    if (p.kind === 'fountain') {
      if (p.water) { p.water.rotation.y += dt * 0.4; p.water.material.opacity = p.used ? 0.15 : 0.5 + Math.sin(G.time * 2.5) * 0.12; }
      if (p.mesh) { p.mesh.quaternion.copy(camera.quaternion); p.mesh.position.y = 1.0 + Math.sin(G.time * 2) * 0.08; }
      if (!p.used && fxP(0.2)) spark(p.x + rr(-0.5, 0.5), 0.4, p.z + rr(-0.5, 0.5), 0x8fe0ff, { vy: 1.4, s: 0.25, life: 0.6, drag: 0 });
      if (!p.used && d < 1.1 && G.state === 'play') {
        if (player.hp >= player.maxHp) { if (!p.warned || G.time - p.warned > 3) { p.warned = G.time; toast('HEALING SPRING · come back when hurt', ''); } }
        else {
          p.used = true; G.saveDue = true; G.pendT = G.run.time; killMesh(p.mesh); p.mesh = null; killGlow(p.glow); p.glow = null;
          player.hp = Math.min(player.maxHp, player.hp + 4); renderHearts(); toast('HEALING SPRING · +2 hearts', '');
          sfx('heal'); flash(0.15); addRing(p.x, p.z, 0.2, 2.4, 0.5, 0x8fe0ff); burst(p.x, 0.8, p.z, 0xff8aa0, 24, 4, 0.5, 0.7);
        }
      }
    }
    if (p.kind === 'crystal') {
      const on = p.room.cleared; // asleep while its room still has to be fought
      p.gem.rotation.y += dt * (on ? 1.6 : 0.4); p.gem.position.y = 1.05 + Math.sin(G.time * 2.2) * 0.08;
      p.glow.material.opacity = (on ? 0.6 : 0.15) * (0.8 + Math.sin(G.time * 3) * 0.2);
      p.ring.material.opacity = on ? 0.4 + Math.sin(G.time * 3) * 0.15 : 0.1; p.ring.rotation.y += dt * 0.5;
      if (on && fxP(0.25)) spark(p.x + rr(-0.25, 0.25), 0.4, p.z + rr(-0.25, 0.25), CRYSTAL, { vy: 1.6, s: 0.25, life: 0.7, drag: 0 });
      if (d > 1.6) p.armed = true;
      if (on && d < 0.9 && G.state === 'play' && p.armed !== false) touchCrystal(p);
    }
    if (p.kind === 'stairs') {
      p.ring.rotation.y += dt; p.ring.scale.setScalar(1.1 + Math.sin(G.time * 4) * 0.06);
      if (fxP(0.5)) spark(p.x + rr(-0.7, 0.7), 0.1, p.z + rr(-0.7, 0.7), 0xff4fd8, { vy: 2, s: 0.3, life: 0.7, drag: 0 });
      if (d < 0.85 && G.state === 'play') {
        p.hold = (p.hold || 0) + dt; G.hold = { p: p.hold / 3, left: 3 - p.hold, col: '#ff6ae0' };
        if (fxP(0.6)) spark(player.x + rr(-0.5, 0.5), 0.1, player.z + rr(-0.5, 0.5), 0xff4fd8, { vy: 2.5, s: 0.3, life: 0.6, drag: 0 });
        if (p.hold >= 3) { p.hold = 0; nextFloor(); }
      } else p.hold = 0;
    }
  }
}

// ---------- upgrade cards ----------
const isSlotSpell = (id) => { const d = spellDef(id); return d && !d.legendary && !d.bossSpell; };
const RUNES = {
  pierce: { name: 'Piercing', info: 'pierces 2 more foes', add: (r) => { r.pierce = (r.pierce || 0) + 2; } },
  bounce: { name: 'Bouncing', info: 'ricochets to the next foe (and off walls) twice', add: (r) => { r.bounce = (r.bounce || 0) + 2; } },
  seek: { name: 'Seeking', info: 'shots hunt down their target', add: (r) => { r.seek = true; } },
};
function weightedSample(list, wf, n) {
  const pool = list.slice(), out = [];
  while (out.length < n && pool.length) {
    let r = rand() * pool.reduce((a, x) => a + wf(x), 0);
    const i = pool.findIndex((x) => (r -= wf(x)) <= 0);
    out.push(pool.splice(i < 0 ? 0 : i, 1)[0]);
  }
  return out;
}
// like weightedSample over generated spell ids ('el.shape'), but never two of one shape or one element key
function variedSample(list, wf, n) {
  const pool = list.slice(), out = [], usedSh = new Set(), usedEl = new Set(), key = (id) => { const d = spellDef(id); return [d.els.join('+'), d.shape]; };
  while (out.length < n && pool.length) {
    const id = weightedSample(pool, wf, 1)[0], [ek, sh] = key(id);
    out.push(id); usedSh.add(sh); usedEl.add(ek);
    for (let i = pool.length - 1; i >= 0; i--) { const [e2, s2] = key(pool[i]); if (usedSh.has(s2) || usedEl.has(e2)) pool.splice(i, 1); }
  }
  return out;
}
// the signature spells you can be offered: unlocked element, not owned
// The Daily's strong-spell budget (user 11-17: "give 1 unique any + 1 t2, or 2 T2 capping, or 2 t2 + t3"), Daily only (no cap
// in normal runs): of the spells you hold, at most 2 RARE (T2), at most 1 EPIC / unique / boss / legendary (T3), and T2 + T3 at most
// G.dailyHi (2; 3 in ~10% of runs, rolled in startDaily). So 1 unique + 1 RARE or 2 RARE; a lucky run 2 RARE + 1 T3. Never 2 uniques.
// Every RARE+ offer (new, swap, boon, wildcard, chest, the Daily's awesome card) asks hiOk; hiFull: no RARE+ fits any more.
const hiCount = () => { let t2 = 0, t3 = 0; for (const s of spells) { const d = spellDef(s.id), t = d ? spellTier(d) : 0; if (t === 1) t2++; else if (t >= 2) t3++; } return [t2, t3]; };
const hiTierOk = (t) => { if (!G.daily || t <= 0) return true; const [t2, t3] = hiCount(); return t2 + t3 < (G.dailyHi || 2) && (t === 1 ? t2 < 2 : t3 < 1); };
const hiFull = () => !!G.daily && !hiTierOk(1) && !hiTierOk(2);
const hiOk = (id) => hiTierOk(spellTier(spellDef(id)));
// the element lock is off in the Daily (user 11-17: "remove all elements on daily"): every element's spells can be offered there;
// meta.elements and the save are untouched. Normal runs: unlocked elements only.
const elOk = (el) => !!G.daily || meta.elements.includes(el);
const sigPool = (owned, minTier = 0) => SIG_IDS.filter((id) => !CUT_IDS.has(id) && elOk(SIGNATURE[id].el) && !owned.has(id) && SIGNATURE[id].tier >= minTier);
// cards that clash in one offer: the same shape twice (new spell vs a spell you own too), or two NEW spells of one element
const clashes = (a, b) => (a.shape && a.shape === b.shape) || (a.newEl && a.newEl === b.newEl);
function upgradeOptions(raw = false) {
  const opts = [], specials = [];
  const owned = new Set(spells.map((s) => s.id));
  const ownedSh = new Set(spells.map((s) => { const d = spellDef(s.id); return d && SHAPES[d.shape] ? d.shape : null; }));
  for (const s of spells) {
    const d = spellDef(s.id), shape = SHAPES[d.shape] ? d.shape : s.id;
    if (canLevel(s)) opts.push({ w: 2, kind: 'up', shape, up: s, sim: (L) => L.map((x) => (x === s ? { ...x, lv: x.lv + 1 } : x)), tag: 'UPGRADE', name: `${d.name} Lv ${s.lv + 1}`, info: levelText(d, s.lv + 1), color: d.color, icon: spellIcon(d), pick: () => { s.lv++; } });
    // runes only fit spells that shoot projectiles
    if (d.sh && (d.sh.beh === 'proj' || d.sh.beh === 'radial')) {
      const rn = s.runes || {};
      for (const [k, R] of Object.entries(RUNES)) {
        if (k === 'seek' && (rn.seek || d.sh.homing)) continue;
        if ((k === 'pierce' && (rn.pierce || 0) >= 6) || (k === 'bounce' && (rn.bounce || 0) >= 6)) continue;
        opts.push({ w: 0.7, kind: 'rune', shape, tag: 'RUNE', name: `${R.name} ${d.name}`, info: `${d.name} ${R.info}`, color: '#9fe7ff', icon: spellIcon(d), pick: () => { s.runes = s.runes || {}; R.add(s.runes); toast(`${R.name.toUpperCase()} RUNE`, d.name); } });
      }
    }
  }
  if (spells.filter((s) => isSlotSpell(s.id)).length < 4) {
    // new spells from the elements you have unlocked; spells you have never seen are favoured
    const pool = sigPool(owned).filter(hiOk);
    // rarer (stronger) spells come up less often; the card shows its tier and odds. One on a base shape you already own is 2x rarer.
    const tw = (id) => SPELL_TIERS[spellTier(spellDef(id))].w * (ownedSh.has(spellDef(id).shape) ? 0.5 : 1), total = pool.reduce((a, id) => a + tw(id), 0);
    for (const id of variedSample(pool, tw, 4)) { // at most one per element (and per base shape)
      const d = spellDef(id), isNew = !meta.codex.includes(id), T = SPELL_TIERS[spellTier(d)];
      const pct = (tw(id) / total * 100), odds = pct >= 1 ? pct.toFixed(0) : pct.toFixed(1);
      opts.push({ w: (isNew ? 1.4 : 1) * tw(id) * 0.8 * 1.6, shape: d.shape, sim: (L) => L.concat({ id, lv: 1 }), newEl: d.els[0], tag: `${T.name} SPELL${isNew ? ' ✦ NEW' : ''} · ${odds}%`, name: d.name, info: `${d.info} · ${d.cd}s`, color: d.color, icon: spellIcon(d), pick: () => { spells.push({ id, lv: 1, t: 0.2 }); discover(id); } });
    }
    // one hand-made unique spell (arcana.js UNIQUE_SPELLS) per pick at most; it takes a slot. Until you have seen them all,
    // about 1 pick in 3 is guaranteed one (G.uqForce), after that it competes like any card.
    const uq = Object.keys(UNIQUE_SPELLS).filter((id) => !owned.has(id));
    if (uq.length && hiTierOk(2)) {
      const unseen = uq.filter((id) => !meta.codex.includes(id));
      const id = pick(unseen.length ? unseen : uq), d = spellDef(id), isNew = !meta.codex.includes(id);
      const card = { w: isNew ? 3 : 2.2, unique: true, shape: id, sim: (L) => L.concat({ id, lv: 1 }), newEl: d.els[0], tag: `◆ UNIQUE SPELL${isNew ? ' ✦ NEW' : ''}`, name: d.name, info: `${d.info} · ${d.kills ? 'no cooldown, charged by kills' : d.cd + 's cooldown'}`, color: d.color, icon: spellIcon(d), pick: () => { spells.push({ id, lv: 1, t: 0.2 }); discover(id); } };
      if (G.floor < 3) { /* no unique spells on floors 1-2: they made the early run too easy (user) */ }
      else if (!unseen.length) { card.w *= 0.6; opts.push(card); }
      else if (rand() < 0.22) { card.force = true; opts.push(card); }
    }
  }
  // boss spells you have already earned can come back in later runs (they don't take a slot)
  for (const id of Object.keys(BOSS_SPELLS)) {
    if (!meta.codex.includes(id) || owned.has(id) || !hiOk(id)) continue;
    const d = spellDef(id);
    opts.push({ w: 0.8, kind: 'boss', id, sim: (L) => L.concat({ id, lv: 1 }), tag: 'BOSS SPELL', name: d.name, info: `${d.info} · no slot needed`, color: d.color, icon: spellIcon(d), pick: () => { spells.push({ id, lv: 1, t: 0.5 }); } });
  }
  // fusion: two spells of different elements, both level 3+, become one stronger spell and free a slot
  for (let i = 0; i < spells.length; i++) for (let j = i + 1; j < spells.length; j++) {
    const a = spells[i], b = spells[j];
    if (a.lv < 3 || b.lv < 3) continue;
    const fid = fusionOf(a, b);
    if (!fid) continue;
    const fd = spellDef(fid), isNew = !meta.codex.includes(fid);
    specials.push({ legend: true, shape: fd.shape, sim: (L) => L.filter((x) => x !== a && x !== b).concat({ id: fid, lv: Math.max(a.lv, b.lv) }), tag: isNew ? 'FUSION ✦ NEW' : 'FUSION', name: fd.name, info: `${spellDef(a.id).name} + ${spellDef(b.id).name}: both effects, +20% damage, frees a slot`, color: fd.color, icon: spellIcon(fd),
      pick: () => {
        spells = spells.filter((x) => x !== a && x !== b);
        spells.push({ id: fid, lv: Math.max(a.lv, b.lv), t: 0.3, runes: { ...(a.runes || {}), ...(b.runes || {}) } });
        discover(fid); flash(0.5); addShake(0.4); sfx('clear'); toast('FUSION', fd.name.toUpperCase());
      } });
  }
  // Spell Salvage removed from offers (user 11-15: 'remove the salvage spell'); salvageCard() kept for reference
  for (const r of relicOptions(2)) opts.push({ ...r, w: 1.1, kind: 'relic' });
  opts.push({ ...gearCard(0), w: 1 });
  if (player.hp < player.maxHp) opts.push({ w: player.hp <= 2 ? 4 : 1.2, kind: 'potion', tag: 'POTION', name: 'Healing Draught', info: 'Restore 2 hearts', color: '#ff6a8a', icon: ['items', 2], pick: () => { player.hp = Math.min(player.maxHp, player.hp + 4); renderHearts(); sfx('heal'); } });
  const legend = Object.keys(LEGENDARY).filter((id) => !owned.has(id));
  const lchance = legendChance();
  if (lchance > 0 && legend.length && rand() < lchance) {
    const id = pick(legend), d = spellDef(id);
    specials.push({ legend: true, kind: 'legend', tag: `LEGENDARY · ${+(lchance * 100).toFixed(1)}%`, name: d.name, info: d.info, color: '#ffb340', icon: spellIcon(d), pick: () => { spells.push({ id, lv: 1, t: 1 }); discover(id); flash(0.6); addShake(0.5); sfx('clear'); toast('LEGENDARY', d.name.toUpperCase()); } });
  }
  if (raw) return opts.concat(specials); // levelOffer builds its own mix from these
  const out = specials.length ? [pick(specials)] : []; // a fusion or legendary, when available, is always offered
  const fi = opts.findIndex((o) => o.force); // the guaranteed unique spell (see above)
  if (fi >= 0 && !(out[0] && clashes(out[0], opts[fi]))) out.push(opts.splice(fi, 1)[0]);
  const drop = (c) => { for (let k = opts.length - 1; k >= 0; k--) if (clashes(c, opts[k])) opts.splice(k, 1); };
  for (const c of out) drop(c);
  while (out.length < 3 && opts.length) {
    const tot = opts.reduce((a, o) => a + o.w, 0); let roll = rand() * tot;
    const i = opts.findIndex((o) => (roll -= o.w) <= 0);
    const c = opts.splice(i < 0 ? 0 : i, 1)[0];
    out.push(c); drop(c); // variety: nothing else of its shape, nor another new spell of its element
  }
  return out;
}
// ---------- level-up offers (user 11-15: "the level up selection", "fill up spells first") ----------
// Tiers are the user's own T1/T2/T3 ratings (arcana.js USER_TIERS): COMMON = 8 signature spells; RARE = 14 signature spells
// + Earth Spike; EPIC = the unique spells Storm Eye, Holy Beam, Momentum, Vesper's Judgment, Storm Gust + the boss spells
// Rockfall, Gear Storm (boss spells only once you have earned them).
// Each new-spell card rolls its tier: COMMON 70% / RARE 20% / EPIC 10% (LV_TIER_ODDS, user 11-17 was 75/20/5; unique spells only from floor 3, as
// before; no EPIC left -> RARE). Every 3rd level (3, 6, 9...; in the DAILY every 3rd offer) one card is a guaranteed RARE.
// While a spell slot is free, a level-up offers NEW SPELLS only (3 cards; a potion takes one place on 1 heart).
// With the 4 slots full the offer is a mix of 3:
//   NEW SPELL  - a SWAP: a higher-tier spell replaces your weakest lower-tier spell and keeps its level (never weaker).
//                A guaranteed RARE swap every 3rd level, otherwise only on a RARE / EPIC roll (an EPIC boss spell needs no slot)
//   BUILD ON   - an upgrade of a spell you own (lower levels first; a rune when nothing can level)
//   WILDCARD   - stat boost / relic / COMMON boss spell / potion when hurt / gear / a 2nd upgrade / rune; a legendary roll always gets in
// Anti-repeat: a card offered in each of the last 2 level-ups is not offered a third time in a row (player.lvMem).
const LV_TIER_ODDS = [0.7, 0.2, 0.1];
const cardKey = (c) => c.name.replace(/ Lv \d+$/, '');
function rollTier() { const r = rand(); return r < LV_TIER_ODDS[0] ? 0 : r < LV_TIER_ODDS[0] + LV_TIER_ODDS[1] ? 1 : 2; }
const sigW = (id) => (meta.codex.includes(id) ? 1 : 1.6); // spells never seen are favoured
// every spell of tier t you could be offered: signature spells (unlocked elements), unique spells (floor 3+), boss spells you have earned
function tierPool(owned, t, uqOk = G.floor >= 3) {
  const uq = uqOk ? Object.keys(UNIQUE_SPELLS).filter((id) => !owned.has(id) && spellTier(spellDef(id)) === t) : [];
  const bs = Object.keys(BOSS_SPELLS).filter((id) => meta.codex.includes(id) && !owned.has(id) && spellTier(spellDef(id)) === t);
  return sigPool(owned).filter((id) => spellTier(spellDef(id)) === t).concat(uq, t === 2 ? bs : []); // COMMON / RARE boss spells stay wildcards
}
function spellCardInfo(d) { return d.bossSpell ? `${d.info} · no slot needed` : d.unique ? `${d.info} · ${d.kills ? 'no cooldown, charged by kills' : +(+d.cd).toFixed(1) + 's cooldown'}` : `${d.info} · ${+(+d.cd).toFixed(1)}s`; }
// a new spell of tier t (else the nearest tier with spells left), not clashing with `out`; a base shape you own is rarer
function newSpellCard(owned, ownedSh, tier, guaranteed, out, noUp = false) {
  const ok = (id) => { const d = spellDef(id); return !out.some((o) => o.name === d.name || clashes(o, { shape: d.shape, newEl: d.sig ? d.els[0] : null })); };
  let t = tier, pool = [];
  for (const tt of guaranteed ? [1, 2] : noUp ? [tier, tier - 1, tier - 2] : [tier, tier - 1, tier + 1, tier - 2]) { /* noUp: an empty COMMON roll must not become a RARE (user 11-15: daily cards all tier 2) */ if (tt < 0 || tt > 2) continue; pool = tierPool(owned, tt).filter((id) => hiOk(id) && ok(id)); if (pool.length) { t = tt; break; } }
  if (!pool.length) return null;
  const id = weightedSample(pool, (x) => sigW(x) * (ownedSh.has(spellDef(x).shape) ? 0.35 : 1), 1)[0], d = spellDef(id), isNew = !meta.codex.includes(id), T = SPELL_TIERS[t];
  const kind = d.bossSpell ? 'BOSS SPELL' : d.unique ? 'UNIQUE SPELL' : 'SPELL';
  return { kind: 'new', unique: !!d.unique, shape: d.sig ? d.shape : id, newEl: d.sig ? d.els[0] : null, tier: t, sim: (L) => L.concat({ id, lv: 1 }),
    tag: `${guaranteed ? '◆ ' : ''}${T.name} ${kind}${isNew ? ' ✦ NEW' : ''}${guaranteed ? ' · EVERY 3RD LV' : ` · ${Math.round(LV_TIER_ODDS[t] * 100)}%`}`,
    name: d.name, info: spellCardInfo(d), color: d.color, icon: spellIcon(d), pick: () => { spells.push({ id, lv: 1, t: d.bossSpell ? 0.5 : 0.2 }); discover(id); if (t) flash(t > 1 ? 0.4 : 0.25); } };
}
// slots full: a spell of `tier` takes the place of your weakest lower-tier spell, at that spell's level (an EPIC boss spell needs no slot)
function swapSpellCard(owned, tier, guaranteed) {
  const pool = tierPool(owned, tier).filter(hiOk); if (!pool.length) return null;
  const id = weightedSample(pool, sigW, 1)[0], d = spellDef(id);
  if (d.bossSpell) return newSpellCard(owned, new Set(), tier, guaranteed, []);
  const old = spells.filter((s) => isSlotSpell(s.id) && spellTier(spellDef(s.id)) < tier).sort((a, b) => spellTier(spellDef(a.id)) - spellTier(spellDef(b.id)) || a.lv - b.lv)[0];
  if (!old) return null;
  const od = spellDef(old.id), isNew = !meta.codex.includes(id), T = SPELL_TIERS[tier], lv = old.lv;
  return { kind: 'new', swap: true, unique: !!d.unique, shape: d.sig ? d.shape : id, newEl: d.sig ? d.els[0] : null, tier, sim: (L) => L.map((x) => (x === old ? { id, lv } : x)),
    tag: `${guaranteed ? '◆ ' : ''}${T.name} ${d.unique ? 'UNIQUE ' : ''}SPELL · SWAP${isNew ? ' ✦ NEW' : ''}`,
    name: d.name, info: `Replaces ${od.name} (keeps Lv ${lv}) · ${d.info}`, color: d.color, icon: spellIcon(d),
    pick: () => {
      if (od.sh && od.sh.beh === 'orbit') for (const o of orbs) if (o.sid === old.id) o.life = Math.min(o.life, 0.05);
      if (od.sh && od.sh.beh === 'summon') for (const w of wisps) w.life = Math.min(w.life, 0.05);
      const i = spells.indexOf(old); if (i >= 0) spells[i] = { id, lv, t: 0.3 }; else spells.push({ id, lv, t: 0.3 });
      discover(id); flash(0.3); burst(player.x, 0.9, player.z, hexOf(d.color), 22, 4.5, 0.45, 0.5); toast('SPELL SWAPPED', `${od.name.toUpperCase()} → ${d.name.toUpperCase()} · Lv ${lv}`);
    } };
}
// The Daily's awesome spells: the user's pick (11-17; rated in the ?spells viewer's ★ DAILY AWESOME toggle). In order: Momentum,
// Storm Eye, Smite, Angel Swords. The Daily's one guaranteed awesome card draws only from these (any tier, element locked or not,
// any floor), skipping ones you own and ones the Daily budget (hiOk) has no room for; none left -> any unique that fits, else no card.
const DAILY_AWESOME = ['u.momentum', 'u.meteor', 'holy.smite', 'holy.radiance', 'u.gust', 'u.judgment', 'u.holybeam']; // user's picks 11-17 (?spells viewer -> rbqa_tmp/daily_awesome.json)
function dailyAweCard(out, lv = 1) {
  const onPick = () => { G.dailyAwe = 'taken'; };
  const owned = new Set(spells.map((s) => s.id)), ids = DAILY_AWESOME.filter((id) => spellDef(id) && !CUT_IDS.has(id) && !owned.has(id));
  return (ids.length && showSpellCard({ ids, out, lv, label: 'DAILY', onPick })) || // only the ones that fit the Daily budget (hiOk)
    showSpellCard({ tiers: [2], out, lv, label: 'DAILY', mark: true, uqOk: true, awe: true, onPick }); // else any unique that fits, else none
}
// The first free chest (user 11-17: the HUD's Daily Chest, ready after 10 minutes of play): instead of gear it unlocks a random
// locked element, one time only (meta.elemChestDone; every element owned -> gear as usual). Either way it then gives one pick of
// the three awesome storm spells (owned ones skipped, none left -> no pick; slots full -> a SWAP of the weakest slot spell at the
// same level). The pick is meta.aweNext, saved: it opens on the next 'play' frame of a normal run (not the Daily, the prologue or a
// dead hero), so a chest opened in a run gets it right after NICE, one opened on the menu / death screen / Daily at the next run.
const ELEM_AWESOME = ['u.momentum', 'u.judgment', 'u.meteor']; // Momentum, Vesper's Judgment, Storm Eye
// ?elemchest (test link): the free chest is ready now and counts as the first one, without setting meta.elemChestDone
const elemChestTest = false; // the ?elemchest test switch is gone (user 11-17: it re-armed the first-chest unlock on every load)
function elemChestAwe() {
  const out = [];
  for (const id of ELEM_AWESOME) { if (!spellDef(id) || CUT_IDS.has(id)) continue; const c = showSpellCard({ ids: [id], out, lv: 2, label: '' }); if (c) out.push(c); }
  G.rerollFn = null; G.rerolled = false;
  if (out.length) openCards('FREE CHEST REWARD', out);
}
function aweNextTick() { // in update(), state 'play': the deferred awesome pick of the first free chest
  if (!meta.aweNext || G.prologue || G.daily || AUTO || BENCH || ZOO || !player || !player.alive || document.querySelector('.rw-overlay')) return;
  delete meta.aweNext; saveMeta();
  try { elemChestAwe(); } catch (err) { console.error(err); }
}
function elemChest(el, onPick) { // the first free chest's element reveal (el is already unlocked and saved)
  const E = ELEMENTS[el];
  chestReveal({ rar: 2, img: elemIcon(el), label: 'FREE CHEST', tag: 'NEW ELEMENT', name: E.name, sub: 'NEW ELEMENT UNLOCKED',
    lines: ['Its spells can now appear in your offers.', E.info], note: 'Permanent · every run', foot: `Next free chest in ${chestLeft()}`,
    buttons: [{ x: 'ok', text: 'NICE' }], onPick });
}
// A showcase spell card (user 11-17: "never get to see the awesome spells, like Momentum, Angel Swords and Smite"): treasure
// chest, boss kill and the Daily's one awesome spell. A spell of the first tier in `tiers` that has one left, not clashing with
// `out`. Slots full: a SWAP that replaces your weakest lower-tier slot spell and keeps its level (never a 5th slot spell, never
// a lower level); a boss spell needs no slot. The Daily's strong-spell budget (hiOk) always holds.
// awe: unique spells only. ids: draw from these spells instead (the Daily's awesome list: any tier, a swap replaces your
// weakest slot spell of any tier). null when nothing fits.
function showSpellCard({ tiers, ids = null, out = [], lv = 1, label, mark = false, uqOk = G.floor >= 3, noBoss = false, awe = false, onPick = null }) {
  const owned = new Set(spells.map((s) => s.id)), slotN = spells.filter((s) => isSlotSpell(s.id)).length;
  const ownedSh = new Set(spells.map((s) => { const d = spellDef(s.id); return d && SHAPES[d.shape] ? d.shape : null; }));
  const ok = (id) => { const d = spellDef(id); return hiOk(id) && !(noBoss && d.bossSpell) && !(awe && !d.unique) && !out.some((o) => o.name === d.name || clashes(o, { shape: d.sig ? d.shape : id, newEl: d.sig ? d.els[0] : null })); };
  const aweL = ids ? ids.filter((id) => !owned.has(id)) : null;
  for (const t0 of aweL ? [-1] : tiers) {
    if (!aweL && (t0 < 0 || t0 > 2)) continue;
    const old = slotN < 4 ? null : spells.filter((s) => isSlotSpell(s.id) && (aweL || spellTier(spellDef(s.id)) < t0)).sort((a, b) => (aweL ? DAILY_AWESOME.includes(a.id) - DAILY_AWESOME.includes(b.id) : 0) || spellTier(spellDef(a.id)) - spellTier(spellDef(b.id)) || a.lv - b.lv)[0];
    const pool = (aweL || tierPool(owned, t0, uqOk)).filter((id) => ok(id) && (slotN < 4 || !isSlotSpell(id) || old));
    if (!pool.length) continue;
    const id = weightedSample(pool, (x) => (aweL ? 1 : sigW(x) * (ownedSh.has(spellDef(x).shape) ? 0.35 : 1) * (mark && spellDef(x).unique ? 2 : 1)), 1)[0], d = spellDef(id), t = aweL ? spellTier(d) : t0, T = SPELL_TIERS[t], isNew = !meta.codex.includes(id);
    const swap = slotN >= 4 && isSlotSpell(id) ? old : null, od = swap && spellDef(swap.id), slv = Math.min(5, swap ? Math.max(swap.lv, lv) : lv);
    const kind = d.bossSpell ? 'BOSS SPELL' : d.unique ? 'UNIQUE SPELL' : 'SPELL';
    return { kind: 'new', swap: !!swap, unique: !!d.unique, shape: d.sig ? d.shape : id, newEl: d.sig ? d.els[0] : null, tier: t,
      sim: (L) => (swap ? L.map((x) => (x === swap ? { id, lv: slv } : x)) : L.concat({ id, lv: slv })),
      tag: aweL ? `★ AWESOME SPELL${swap ? ' · SWAP' : ''}${label ? ` · ${label}` : ''}${isNew ? ' ✦ NEW' : ''}` : `${mark ? '◆ ' : ''}${T.name} ${kind}${swap ? ' · SWAP' : ''} · ${label}${isNew ? ' ✦ NEW' : ''}`,
      tagColor: aweL ? T.color : null, tierCls: aweL ? t : null,
      name: d.name, info: swap ? `Replaces ${od.name} (${slv > swap.lv ? `Lv ${swap.lv} → ` : 'keeps '}Lv ${slv}) · ${d.info}` : `${spellCardInfo(d)}${slv > 1 ? ` · starts at Lv ${slv}` : ''}`, color: d.color, icon: spellIcon(d),
      pick: () => {
        if (swap) {
          if (od.sh && od.sh.beh === 'orbit') for (const o of orbs) if (o.sid === swap.id) o.life = Math.min(o.life, 0.05);
          if (od.sh && od.sh.beh === 'summon') for (const w of wisps) w.life = Math.min(w.life, 0.05);
          const i = spells.indexOf(swap); if (i >= 0) spells[i] = { id, lv: slv, t: 0.3 }; else spells.push({ id, lv: slv, t: 0.3 });
          burst(player.x, 0.9, player.z, hexOf(d.color), 22, 4.5, 0.45, 0.5); toast('SPELL SWAPPED', `${od.name.toUpperCase()} → ${d.name.toUpperCase()} · Lv ${slv}`);
        } else spells.push({ id, lv: slv, t: d.bossSpell ? 0.5 : 0.2 });
        discover(id); if (t) flash(t > 1 ? 0.4 : 0.25); if (onPick) onPick();
      } };
  }
  return null;
}
// never an empty offer: upgrades of spells you own (lowest level first), then a stat card, then gear
function fillCards(out, n = 3) {
  const taken = (c) => out.some((o) => o.name === c.name || clashes(o, c));
  for (const c of upgradeOptions(true).filter((o) => o.kind === 'up').sort((a, b) => a.up.lv - b.up.lv)) if (out.length < n && !taken(c)) out.push(c);
  if (out.length < n) out.push(statCard(MAIN_STAT[player.hero.cls] || 'int'));
  if (out.length < n) out.push(gearCard(1));
  return out;
}
// the boss kill: its boss spell + a showcase EPIC / UNIQUE new spell (a swap at the same level when the slots are full; not in
// the Daily past its RARE+ cap) + an upgrade
function bossOffer(bsId) {
  const bc = bossSpellCard(bsId), out = [bc];
  const sc = showSpellCard({ tiers: [2], out, label: 'BOSS REWARD', mark: true, noBoss: true });
  if (sc) out.push(sc);
  for (const c of upgradeOptions()) if (out.length < 3 && !out.some((o) => o.name === c.name || clashes(o, c))) out.push(c); // never the same boss spell twice (user bug)
  return fillCards(out);
}
function levelOffer() {
  const owned = new Set(spells.map((s) => s.id)), full = spells.filter((s) => isSlotSpell(s.id)).length >= 4;
  const ownedSh = new Set(spells.map((s) => { const d = spellDef(s.id); return d && SHAPES[d.shape] ? d.shape : null; }));
  const mem = player.lvMem || [], stale = (c) => mem.length >= 2 && mem.every((m) => m.includes(cardKey(c))); // offered in each of the last 2
  const fresh = (list) => { const f = list.filter((c) => !stale(c)); return f.length ? f : list; };
  const wpick = (list) => { if (!list.length) return null; let r = rand() * list.reduce((a, c) => a + c.w, 0); return list.find((c) => (r -= c.w) <= 0) || list[list.length - 1]; };
  const all = upgradeOptions(true), of = (k) => all.filter((c) => c.kind === k);
  const out = [], taken = (c) => out.some((o) => o.name === c.name || clashes(o, c));
  const hi = hiFull(), third = !hi && (G.daily ? (player.lvOffers || 0) % 3 === 1 : player.lv % 3 === 0), lg = of('legend')[0], ups = fresh(of('up')), runes = fresh(of('rune'));
  if (G.daily && G.dailyAwe === 'head') { // the Daily's one awesome spell (user 11-17): in the first head-start pick (within the strong-spell budget, hiOk)
    G.dailyAwe = 'chest'; // passed up -> the Daily's first treasure chest shows one again
    const aw = dailyAweCard(out);
    if (aw) out.push(aw);
  }
  if (!full) { // a free slot: new spells first
    if (lg) out.push(lg);
    for (let k = 0; out.length < 3 && k < 8; k++) { const c = newSpellCard(owned, ownedSh, third && k === 0 ? 1 : hi ? 0 : rollTier(), third && k === 0, out, hi || out.some((o) => o.tier > 0)); if (c && !stale(c)) out.push(c); } // at most one card steps up a tier when its own tier ran dry
    if (player.hp <= 2) { const pt = of('potion')[0]; if (pt) { if (out.length >= 3) out.pop(); out.push(pt); } }
    for (const c of ups.concat(runes)) if (out.length < 3 && !taken(c)) out.push(c); // the pool ran dry
  } else {
    // 1) NEW SPELL as a SWAP: a guaranteed RARE every 3rd level, else only on a RARE / EPIC roll
    const tier = third ? 1 : rollTier();
    const nw = !hi && (third || tier > 0) ? swapSpellCard(owned, Math.max(1, tier), third) || (tier === 2 ? swapSpellCard(owned, 1, false) : null) : null; // never an EPIC in place of a RARE (Epics stay rare)
    if (nw && !stale(nw)) out.push(nw);
    // 2) BUILD ON: an upgrade of a spell you own (lower levels first), else a rune
    const b = ups.filter((c) => !taken(c)), build = b.length ? wpick(b.map((c) => ({ ...c, w: (6 - c.up.lv) * (isSlotSpell(c.up.id) ? 1 : 0.6) }))) : wpick(runes.filter((c) => !taken(c)));
    if (build) out.push(build);
    // 3) WILDCARD (fills the rest)
    const main = MAIN_STAT[player.hero.cls] || 'int', statK = weightedSample(STATS.slice(), (k) => (k === main ? 3 : k === 'vit' ? 2 : 1), 1)[0];
    let wild = [{ ...statCard(statK), w: 1.1 }].concat(of('relic').map((c) => ({ ...c, w: 0.5 })), of('boss').filter((c) => spellTier(spellDef(c.id)) < (hi ? 1 : 2)).map((c) => ({ ...c, w: 0.9 })),
      of('potion').map((c) => ({ ...c, w: player.hp <= 2 ? 6 : 0.5 })), [{ ...gearCard(0), w: 0.4 }], ups.map((c) => ({ ...c, w: 0.8 })), runes.map((c) => ({ ...c, w: 0.3 })));
    if (lg) { if (out.length > 2) out.pop(); out.push(lg); }
    if (player.hp <= 2) { const pt = of('potion')[0]; if (pt && out.length < 3) out.push(pt); } // on 1 heart a potion is always offered
    wild = fresh(wild).filter((c) => !taken(c));
    while (out.length < 3 && wild.length) { const c = wpick(wild); out.push(c); wild = wild.filter((x) => x !== c && !taken(x)); }
  }
  player.lvMem = mem.concat([out.map(cardKey)]).slice(-2); player.lvOffers = (player.lvOffers || 0) + 1;
  return out;
}
// Spell Salvage (user 11-15, replaces the removed fusions): owning 3 signature spells of one tier (COMMON or RARE) puts a
// SALVAGE card in the offer. Picking it opens a second pick: 1 of up to 3 spells of the next tier (unlocked elements, the
// sacrificed spells' elements first, never owned or cut). The 3 lowest-level spells of that tier go, the new one starts at
// their average level (rounded up), runes are dropped: 3 out, 1 in frees 2 slots. Nothing changes until the second pick,
// so a save taken in between still has the 3 spells.
function salvageCard() {
  for (const tier of [0, 1]) {
    const own = spells.filter((s) => { const d = spellDef(s.id); return d && d.sig && !d.fused && SIGNATURE[s.id] && SIGNATURE[s.id].tier === tier; });
    if (own.length < 3) continue;
    const three = own.slice().sort((a, b) => a.lv - b.lv).slice(0, 3), els = new Set(three.map((s) => SIGNATURE[s.id].el));
    const owned = new Set(spells.map((s) => s.id)), pool = shuffle(sigPool(owned, tier + 1).filter((id) => SIGNATURE[id].tier === tier + 1 && hiOk(id)));
    const cands = pool.filter((id) => els.has(SIGNATURE[id].el)).concat(pool.filter((id) => !els.has(SIGNATURE[id].el))).slice(0, 3);
    if (!cands.length) continue;
    const lv = Math.min(5, Math.ceil(three.reduce((a, s) => a + s.lv, 0) / 3)), T0 = SPELL_TIERS[tier], T1 = SPELL_TIERS[tier + 1];
    const rest = (L) => L.filter((x) => !three.includes(x));
    const m = dpsMuls(player, false), best = cands.slice().sort((a, b) => spellListDps([{ id: b, lv }], m) - spellListDps([{ id: a, lv }], m))[0];
    const names = three.map((s) => `${spellDef(s.id).name} Lv ${s.lv}`).join(', ');
    return { salvage: true, sim: (L) => rest(L).concat({ id: best, lv }), tag: `SALVAGE · 3 ${T0.name} → 1 ${T1.name}`, name: 'Spell Salvage', info: `Sacrifice ${names}: choose 1 of ${cands.length} ${T1.name} spell${cands.length > 1 ? 's' : ''} at Lv ${lv}. Frees 2 slots`, color: T1.color, icon: spellIcon(spellDef(best)),
      pick: () => queueMicrotask(() => openCards('SALVAGE', cands.map((id) => salvagePick(id, lv, three, T1)))) }; // chooseCard sets 'play' first, then the second pick opens
  }
  return null;
}
function salvagePick(id, lv, three, T) {
  const d = spellDef(id), isNew = !meta.codex.includes(id);
  return { tag: `${T.name} SPELL · SALVAGED${isNew ? ' ✦ NEW' : ''}`, name: d.name, info: `${d.info} · ${d.cd}s · starts at Lv ${lv}`, color: d.color, icon: spellIcon(d), sim: (L) => L.filter((x) => !three.includes(x)).concat({ id, lv }),
    pick: () => {
      for (const s of three) { // the 3 sacrificed spells go (their orbiting orbs / familiars with them)
        const sd = spellDef(s.id), col = hexOf(sd.color), k = three.indexOf(s), a = k / 3 * Math.PI * 2 + 0.5, cx = Math.cos(a) * 1.3, cz = Math.sin(a) * 1.3;
        if (sd.sh && sd.sh.beh === 'orbit') for (const o of orbs) if (o.sid === s.id) o.life = Math.min(o.life, 0.05);
        if (sd.sh && sd.sh.beh === 'summon') for (const w of wisps) w.life = Math.min(w.life, 0.05);
        for (let q = 0; q < 6; q++) spark(player.x + cx, 0.9 + q * 0.04, player.z + cz, q ? col : 0xffffff, { vx: -cx * 3.6, vz: -cz * 3.6, vy: 0, s: q ? 0.5 : 0.8, life: 0.28 + q * 0.012, drag: 0 }); // 3 orbs fly into one
      }
      spells = spells.filter((x) => !three.includes(x));
      spells.push({ id, lv, t: 0.3 });
      buildSpellHud(); discover(id); flash(0.4); addShake(0.3); sfx('clear');
      later(0.28, () => { burst(player.x, 0.9, player.z, hexOf(d.color), 26, 5, 0.5, 0.5); addRing(player.x, player.z, 0.3, 2.2, 0.4, hexOf(d.color)); });
      toast('SALVAGE', `${d.name.toUpperCase()} · Lv ${lv}`);
    } };
}
// legendary spells (outside the first-run gift) only drop deep: floors 11-19 3%, 20-29 2%, 30-39 1%, 40+ 0.5%
const legendChance = () => (G.floor < 11 ? 0 : G.floor < 20 ? 0.03 : G.floor < 30 ? 0.02 : G.floor < 40 ? 0.01 : 0.005);
// the first treasure chest of every run = a spell showcase (user 11-17): 3 spell cards, one a guaranteed showcase (floor 3+
// EPIC / unique, floors 1-2 RARE), two with the normal level-up odds; new spells start at Lv 2. Slots full: every card is a
// SWAP (keeps the replaced spell's level). The Daily's cap holds; the Daily's awesome spell comes back here if it was passed
// up. Not enough spells: upgrades / a stat card / gear fill it (never an empty chest). The first run also offers a legendary.
function boonOptions() {
  const gift = !meta.giftDone && meta.stats.runs === 0; // the guaranteed legendary is a one-time gift on the very first run
  const lucky = !gift && rand() < legendChance(); // after that, only deep down and rarely
  const out = [];
  if (gift || lucky) {
    if (gift) { meta.giftDone = true; saveMeta(); }
    const lid = pick(Object.keys(LEGENDARY).filter((k) => !spells.some((s) => s.id === k)));
    if (lid) { const d = spellDef(lid); out.push({ legend: true, tag: gift ? 'LEGENDARY · BEGINNER GIFT' : `LEGENDARY · ${+(legendChance() * 100).toFixed(1)}%`, name: d.name, info: d.info, color: '#ffb340', icon: spellIcon(d), pick: () => { spells.push({ id: lid, lv: 1, t: 1 }); discover(lid); flash(0.6); addShake(0.5); sfx('clear'); } }); }
  }
  let sc = null;
  if (G.daily && G.dailyAwe === 'chest') { G.dailyAwe = 'done'; sc = dailyAweCard(out, 2); }
  if (!sc) sc = showSpellCard({ tiers: G.floor >= 3 ? [2, 1] : [1], out, lv: 2, label: 'TREASURE', mark: true });
  if (sc) out.push(sc);
  const hi = hiFull();
  for (let k = 0; out.length < 3 && k < 8; k++) { const t = hi ? 0 : rollTier(), c = showSpellCard({ tiers: [t, t - 1, t - 2], out, lv: 2, label: 'TREASURE' }); if (c) out.push(c); }
  return fillCards(out);
}
function bossSpellCard(id) {
  const d = spellDef(id), had = meta.codex.includes(id);
  discover(id);
  return { legend: true, tag: had ? 'BOSS SPELL' : 'BOSS SPELL ✦ UNLOCKED', name: d.name, info: `${d.info} · doesn't take a slot`, color: d.color, icon: spellIcon(d),
    pick: () => { const s = spells.find((x) => x.id === id); if (s) s.lv = Math.min(5, s.lv + 1); else spells.push({ id, lv: 1, t: 0.5 }); toast(d.name.toUpperCase(), 'is yours'); } };
}
function shrineOptions(p) {
  const done = () => { p.mesh.material.uniforms.uTint.value.set(0x555566); killGlow(p.glow); p.glow = null; burst(p.x, 1, p.z, 0xff2a4a, 30, 5, 0.5, 0.8); addShake(0.3); sfx('hurt'); };
  const opts = [];
  if (player.maxHp > 2) opts.push({ tag: 'BLOOD PACT', name: 'Sacrifice a heart', info: '-1 max heart. Two random spells gain +1 level.', color: '#ff3050', icon: ['items', 2],
    pick: () => { player.maxHp -= 2; player.hp = Math.min(player.hp, player.maxHp); shuffle(spells.filter((s) => s.lv < spellCap())).slice(0, 2).forEach((s) => s.lv++); buildSpellHud(); renderHearts(); done(); toast('BLOOD PACT', 'Your spells grow stronger'); } });
  if (player.hp > 2) opts.push({ tag: 'BLOOD PRICE', name: 'Bleed for gold', info: 'Lose 1 heart now. Gain 45 coins.', color: '#ffd34f', icon: ['items', 0],
    pick: () => { player.hp -= 2; G.coins += 45; $('coins').textContent = G.coins; renderHearts(); done(); for (let k = 0; k < 8; k++) dropPickup(p.x, p.z + 0.6, 'coin'); } });
  opts.push({ tag: 'BLOOD RELIC', name: 'Cursed relic', info: 'Gain a random relic. Enemies get 15% tougher this floor.', color: '#c070ff', icon: ['items', 5],
    pick: () => { G.curse = (G.curse || 0) + 0.15; relicOptions(1)[0].pick(); done(); } });
  opts.push({ tag: 'LEAVE', name: 'Walk away', info: 'The shrine stays dormant.', color: '#8aa0c8', icon: ['items', 1], pick: () => { p.used = false; } });
  return opts;
}
function relicOptions(n) {
  const pool = shuffle(RELICS.filter((r) => !(r.id === 'feather' && player.revive > 0) && !(r.id === 'ember' && player.ember)));
  return pool.slice(0, n).map((r) => ({ tag: 'RELIC', name: r.name, info: r.info, color: '#ffd36b', icon: iconPath('relic_' + r.id) || r.icon, pick: () => { r.apply(); player.relics.push(r.id); renderHearts(); toast(r.name.toUpperCase(), r.info); } }));
}
// which card is better (user 11-15: "no way to guide what is better"): every card that changes your damage shows its gain from
// the same single-target model the game balances with (spellListDps); the best card gets a gold ★ BEST. A fusion or a
// legendary is always best; a potion is best when you're on 1 heart or less. Relics / gear / runes show no number.
const SHOW_BEST = false;
function rateCards(opts) {
  if (!player || ZOO) return;
  const m = dpsMuls(player, false), cur = spellListDps(spells, m);
  for (const o of opts) {
    o.gain = null; o.best = false;
    try {
      if (o.sim) o.gain = cur > 0 ? spellListDps(o.sim(spells), m) / cur - 1 : 1;
      // an upgrade is worth at least its stated per-hit damage (+30% a level) on that spell's share: the measured table is
      // single-target and noisy between some levels (Prism Lance Lv1 -> 2 measured +2%)
      if (o.up && cur > 0) o.gain = Math.max(o.gain || 0, spellListDps([o.up], m) / cur * (lvMul(o.up.lv + 1) / lvMul(o.up.lv) - 1));
      else if (o.stat) { const st2 = { ...player.st, [o.stat]: (player.st[o.stat] || 0) + 2 }, m2 = dpsMuls({ ...player, der: derive(player.hero.cls, st2, player.hero.base) }, false); o.gain = cur > 0 ? spellListDps(spells, m2) / cur - 1 : 0; }
    } catch (e) { o.gain = null; }
    if (o.gain != null && !(o.gain > 0.005)) o.gain = null; // VIT / AGI etc.: their own text says what they do
  }
  const must = opts.find((o) => o.legend) || (player.hp <= 2 && opts.find((o) => o.tag === 'POTION'));
  const top = must || opts.filter((o) => o.gain != null && !o.stat).sort((a, b) => b.gain - a.gain)[0]; // a STAT BOOST is never ★BEST (user 11-15)
  if (top && SHOW_BEST) top.best = true; // ★BEST badge OFF (user 11-15: 'remove the best tag, it's not right'); the ▲ damage line stays
}
let cardCss = false;
function openCards(title, opts) {
  if (!opts.length || G.state !== 'play') return;
  if (!cardCss) { cardCss = true; const st = document.createElement('style'); st.textContent = '.card .gain{font:800 12px/1.2 system-ui,sans-serif;color:#7dff9a;margin:2px 0 3px;text-shadow:0 1px 2px #000}html:not(.land) .card .gain{text-align:left;justify-content:flex-start}.card.best{outline:3px solid #ffd34f;box-shadow:0 0 22px #ffd34f88,0 0 0 1px #000}.card .bestTag{position:absolute;top:-11px;left:50%;transform:translateX(-50%);background:linear-gradient(#ffe68a,#e3a52a);color:#3a2300;font:900 11px/1 system-ui,sans-serif;letter-spacing:.08em;padding:4px 9px;border-radius:9px;border:1.5px solid #3a2300;white-space:nowrap;z-index:2}'; document.head.appendChild(st); }
  rateCards(opts);
  G.state = 'cards'; G.cardsOpen = performance.now(); G.cardsTitle = title;
  $('cardsTitle').textContent = title;
  const row = $('cardRow'); row.innerHTML = '';
  opts.forEach((o, k) => {
    const c = document.createElement('div'); c.className = 'card' + (o.legend ? ' legend' : '') + (o.unique ? ' unique' : '') + (o.tierCls === 2 || /EPIC/.test(o.tag || '') ? ' t3' : o.tierCls === 1 || /RARE/.test(o.tag || '') ? ' t2' : ''); /* tier backgrounds (user 11-15) */ c.style.setProperty('--c', o.color); c.style.animationDelay = k * 0.07 + 's';
    if (o.best) { c.classList.add('best'); c.style.position = 'relative'; }
    const gain = o.gain != null ? `<div class="gain">▲ +${o.gain >= 0.995 ? Math.round(o.gain * 100) : Math.max(1, Math.round(o.gain * 100))}% damage</div>` : '';
    c.innerHTML = `${o.best ? '<div class="bestTag">★ BEST</div>' : ''}<div class="ci" style="--img:url(${typeof o.icon === 'string' ? o.icon : iconURL(o.icon[0], o.icon[1])})"></div><div><div class="tag"${o.tagColor ? ` style="color:${o.tagColor}"` : ''}>${o.tag}</div><h3>${o.name}</h3>${gain}<p>${o.info}</p></div>`;
    c.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); if (performance.now() - G.cardsOpen < 350) return; chooseCard(o); });
    row.appendChild(c);
  });
  const canReroll = G.rerollFn && !G.rerolled;
  if (canReroll) {
    const rb = document.createElement('button'); rb.className = 'rwbtn reroll'; rb.innerHTML = adsOn() ? '▶ WATCH AD · REROLL' : '↻ REROLL';
    rb.addEventListener('pointerdown', async (ev) => { ev.stopPropagation(); if (!(await Monet.rewarded('reroll'))) return; G.rerolled = true; const fn = G.rerollFn; G.state = 'play'; openCards(title, fn()); });
    row.appendChild(rb);
  }
  $('cards').classList.remove('hidden');
  sfx('card');
  if (AUTO) later(0.7, () => chooseCard(window.__botPick ? window.__botPick(opts) : pick(opts))); // test scripts can steer the bot's picks
}
function chooseCard(o) {
  if (G.state !== 'cards') return;
  const nS = spells.length, ids = spells.map((x) => x.id).join(); o.pick(); sfx('card'); G.rerollFn = null; G.rerolled = false; G.saveDue = true;
  if (spells.length !== nS || spells.map((x) => x.id).join() !== ids) buildSpellHud(); // a new / swapped spell shows in the HUD right away
  if (meta.prologueDone && !(meta.stats.runs || 0)) toast('RUNE RECOVERED', o.name || ''); // first run after the prologue
  $('cards').classList.add('hidden');
  G.state = 'play';
}

// ---------- HUD ----------
let heartImg = '', coinImg = '';
function renderHearts() {
  const el = $('hearts'); el.innerHTML = '';
  for (let i = 0; i < player.maxHp / 2; i++) {
    const v = clamp(player.hp - i * 2, 0, 2);
    const h = document.createElement('div'); h.className = 'heart';
    h.style.setProperty('--img', `url(${heartImg})`);
    h.innerHTML = `<i style="width:${v * 50}%"></i>`;
    el.appendChild(h);
  }
}
let spellEls = [];
function buildSpellHud() {
  const el = $('spells'); el.innerHTML = ''; spellEls = [];
  for (const s of spells) {
    const def = spellDef(s.id);
    const d = document.createElement('div'); d.className = 'spell';
    d.style.setProperty('--c', def.color); d.style.setProperty('--img', `url(${spellIcon(def)})`);
    d.innerHTML = `<div class="in"></div><div class="lv">${s.lv}</div>`;
    el.appendChild(d); spellEls.push(d);
  }
}
function updateHud() {
  spells.forEach((s, i) => {
    const el = spellEls[i]; if (!el) return;
    const cd = s.cdT || spellDef(s.id).cd * player.cdMul * player.g.cd * player.der.cd; // s.cdT: unique spells' own cooldown
    const p = clamp(1 - s.t / cd, 0, 1), q = Math.floor(p * 40) / 40; // 1/40 steps: the conic sweep only repaints when it visibly moves
    if (el._p !== q) { el._p = q; el.style.setProperty('--p', q.toFixed(3)); el.classList.toggle('ready', p >= 1); }
    if (s.pop) { s.pop = 0; if (el.animate) el.animate([{ offset: 0.5, transform: 'scale(1.18)' }], 250); else { el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); } } /* WAAPI: no forced layout per cast */
  });
}
const mm = $('minimap').getContext('2d');
function drawMinimap() {
  mm.clearRect(0, 0, 96, 96);
  const cur = G.curRoom || roomAt(player.x, player.z);
  const ox = 48 - (player.x / SX) * 13, oz = 48 - (player.z / SZ) * 13;
  for (const r of rooms) {
    if (!r.seen) continue;
    for (const o of r.links) {
      if (!o.seen) continue;
      mm.fillStyle = 'rgba(160,180,210,.5)';
      mm.fillRect(ox + (r.gx + 0.5) * 13 - 1, oz + (r.gy + 0.5) * 13 - 1, (o.gx - r.gx) * 13 + 2, (o.gy - r.gy) * 13 + 2);
    }
  }
  for (const r of rooms) {
    if (!r.seen) continue;
    const x = ox + r.gx * 13 + 2, y = oz + r.gy * 13 + 2;
    mm.fillStyle = r === cur ? '#ffffff' : r.visited ? '#5c6d8c' : '#2a3348';
    mm.fillRect(x, y, 9, 9);
    const ic = { treasure: '#ffd34f', shop: '#7fffd4', exit: '#ff4fd8', boss: '#ff3050', shrine: '#c0304a', challenge: '#ffa040', calm: '#ffe2a8' }[r.type] || { swarm: '#ff6a7a', dark: '#6a5aa8', traps: '#c8c8d8' }[r.variant];
    if (ic) { mm.fillStyle = ic; mm.fillRect(x + 3, y + 3, 3, 3); }
  }
}
let toastT = 0;
function toast(a, b) { $('toast').innerHTML = `${a}<small>${b}</small>`; $('toast').classList.add('show'); toastT = 2.2; }
let bannerT = 0;
function banner(a, b) { $('banner').innerHTML = `${a}${b ? `<small>${b}</small>` : ''}`; $('banner').classList.add('show'); bannerT = 1.8; }
// stopped time: grey the world. A CSS filter on the canvas re-filters the whole screen every frame (heavy on phones), so phones
// get a grey layer that blends as "saturation" over the canvas instead
let stillEl = null;
function stillTint(on) {
  if (!MOBILE) { renderer.domElement.style.filter = on ? 'grayscale(0.9) contrast(1.15) brightness(1.1)' : ''; return; }
  if (!stillEl) { stillEl = document.createElement('div'); stillEl.style.cssText = 'position:absolute;inset:0;pointer-events:none;background:#8a8a90;mix-blend-mode:saturation;opacity:.9;display:none'; renderer.domElement.after(stillEl); }
  stillEl.style.display = on ? 'block' : 'none'; // off = not in the page at all, so no blend layer the rest of the time
}
function flash(a) { const f = $('flash'); f.style.transition = 'none'; f.style.opacity = a; requestAnimationFrame(() => { f.style.transition = 'opacity .35s'; f.style.opacity = 0; }); }
// a big fight made 400+ live numbers (drawOverlay was ~17% of a 6x-throttled phone frame): cap them (oldest number goes)
// and merge repeat hits on one foe into its fresh number, which pops again and counts up
const MAX_TEXTS = MOBILE ? 32 : 70;
function addText(x, y, z, text, color, scale = 1) {
  if (texts.length >= MAX_TEXTS) { const i = texts.findIndex((q) => !q.ghost); if (i >= 0) { texts[i].life = 0; texts.splice(i, 1); } }
  const t = { x, y, z, text: String(text), color, scale, life: 0.75, vy: 1.8, vx: rr(-0.4, 0.4) }; texts.push(t); return t;
}
// every hit shows its own number (the feel of dealing damage), popping in with a small punch; bigger hits are a bit bigger.
// The cap above keeps a big fight cheap (oldest number goes first).
const dmgScale = (base, n) => base * (0.85 + Math.min(0.35, Math.log10(1 + n) * 0.1)); // 10 -> x0.95, 100 -> x1.05, 1000 -> x1.15
function dmgText(e, y, n, color, scale = 1, suf = '') {
  const o = e.dTxt; // hits on the same foe within 0.25 s of its number appearing add into it (one number per burst)
  if (o && o.life > 0.5 && texts.includes(o)) { o.n += n; o.text = Math.round(o.n) + suf; o.color = color; o.scale = dmgScale(Math.max(o.base, scale), o.n); o.base = Math.max(o.base, scale); o.punch = 1; return; }
  const t = addText(e.x + rr(-0.25, 0.25), y, e.z, Math.round(n) + suf, color, dmgScale(scale, n)); t.punch = 1; t.n = n; t.base = scale; e.dTxt = t;
}
const hexCss = new Map(); // DoT tick colour -> '#rrggbb' without a new THREE.Color per tick
const cssOf = (c) => { let s = hexCss.get(c); if (!s) hexCss.set(c, s = '#' + new THREE.Color(c).getHexString()); return s; };

// ---------- camera (smooth follow + lead, trauma shake, kick, zoom punch) ----------
const camTarget = new THREE.Vector3();
let trauma = 0;
const kickV = new THREE.Vector2();
function addShake(a) { if (G.prologue) a *= 0.35; trauma = Math.min(1, trauma + a * (1 - trauma * 0.75)); } // overlapping shakes add up with diminishing returns; the prologue shakes much less (user 11-15: "can't see what's going on")
function kick(x, z) { kickV.x += x; kickV.y += z; }
function updateCamera(dt) {
  if (player) {
    const lead = 0.28;
    let tx = player.x + player.vx * lead, tz = player.z + player.vz * lead - 0.8;
    // locked room: the whole room fits on screen, so hold the camera on it (a little drift toward the player)
    // instead of panning out over the empty dark beyond the walls
    // the prologue arena frames like a locked room: following Pip to its south wall left half a portrait screen of black void
    const lockR = rooms.find((q) => q.active) || (G.prologue ? G.prologue.cam : null); // landing room, then the chamber (free in the corridor)
    G.camLock = (G.camLock || 0) + ((lockR ? 1 : 0) - (G.camLock || 0)) * damp(3, dt);
    if (lockR || G.camLock > 0.01) {
      const r = lockR || G.lastLockRoom;
      if (lockR) G.lastLockRoom = lockR;
      if (r) {
        const fx = r.cx + (player.x - r.cx) * 0.18, fz = r.cz - 0.8 + (player.z - r.cz) * 0.22;
        tx = lerp(tx, fx, G.camLock); tz = lerp(tz, fz, G.camLock);
      }
    }
    if (G.finisher) { tx = lerp(tx, G.finisher.x, 0.6); tz = lerp(tz, G.finisher.z - 0.4, 0.6); }
    if (SPELLV && spv.cam) { tx = lerp(spv.cam[0], player.x, 0.2); tz = lerp(spv.cam[1], player.z - 0.8, 0.2) + (app.clientWidth > app.clientHeight ? 1.2 : 0.6); } // ?spells: frame Pip and the dummies above the panel
    // prologue dialogue covers the bottom of the screen: keep Pip and Vesper in the open part above it
    if (G.prologue && G.prologue.look) { tx = lerp(tx, G.prologue.look.x, 0.55); tz = lerp(tz, G.prologue.look.z, 0.55); }
    const vnWant = G.prologue && VN.line ? (app.clientHeight > app.clientWidth ? 3.4 : 1.4) : 0;
    G.vnCam = (G.vnCam || 0) + (vnWant - (G.vnCam || 0)) * damp(2.5, dt); tz += G.vnCam;
    const k = damp(6, dt);
    camTarget.x += (tx - camTarget.x) * k; camTarget.z += (tz - camTarget.z) * k;
  }
  const tq = G.prologue ? Math.min(trauma, 0.45) : trauma; // the prologue caps it too (its scripted beats set trauma directly)
  const s = tq * tq, t = G.time * 1 + performance.now() / 1000;
  const n1 = Math.sin(t * 37.1) * 0.6 + Math.sin(t * 59.3) * 0.4, n2 = Math.sin(t * 41.7 + 1.3) * 0.6 + Math.sin(t * 67.1) * 0.4, n3 = Math.sin(t * 29.3 + 2.1);
  const zoom = G.state === 'dead' ? 0.75 : G.finisher ? 0.72 : G.prologue && G.prologue.phase === 'betray' ? 0.78 : G.slowmo > 0 ? 0.93 : 1;
  camZoom += (zoom - camZoom) * damp(G.finisher ? 9 : 4, dt);
  const d = camDist * camZoom;
  const cx = camTarget.x + kickV.x + n1 * s * 0.5, cz = camTarget.z + kickV.y + n2 * s * 0.5;
  camera.position.set(cx, Math.sin(PITCH) * d, cz + Math.cos(PITCH) * d);
  camera.lookAt(cx, 0, cz);
  camera.rotateZ(n3 * s * 0.035);
  trauma = Math.max(0, trauma - dt * 1.6);
  kickV.multiplyScalar(Math.exp(-14 * dt));
  sun.position.set(camTarget.x - 7, 16, camTarget.z + 5);
  sun.target.position.set(camTarget.x, 0, camTarget.z);
}
let camZoom = 1;

// ---------- auto-play bot (for teaser recording and testing) ----------
function botInput() {
  const [x, z] = botWish();
  const l = Math.hypot(x, z);
  if (l < 0.01) return [0, 0];
  const a0 = Math.atan2(z, x);
  for (const da of [0, 0.5, -0.5, 1, -1, 1.5, -1.5, 2.2, -2.2]) {
    const a = a0 + da, cx = player.x + Math.cos(a) * 0.75, cz = player.z + Math.sin(a) * 0.75;
    if (!solid(cx, cz, false) && !solid(player.x + Math.cos(a) * 0.4, player.z + Math.sin(a) * 0.4, false)) return [Math.cos(a) * Math.min(1, l), Math.sin(a) * Math.min(1, l)];
  }
  return [x, z];
}
function botWish() {
  const p = player;
  let ax = 0, az = 0;
  const r = G.curRoom;
  const threats = enemies.filter((e) => !e.dead);
  for (const h of hazards) {
    const dx = p.x - h.x, dz = p.z - h.z, d = Math.hypot(dx, dz) || 1;
    if (d < 1.8 && (h.kind === 'lava' || h.state === 'warn' || h.state === 'up' || h.state === 'puff')) { ax += dx / d * 2.5 / d; az += dz / d * 2.5 / d; }
  }
  for (const c of clouds) { const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz) || 1; if (d < c.r + 1) { ax += dx / d * 3; az += dz / d * 3; } }
  for (const b of beams) { if (b.ally) continue; const cx = Math.cos(b.a + 0.4), cz = Math.sin(b.a + 0.4); ax -= cz * 3; az += cx * 3; }
  if (r && r.active || threats.length) {
    for (const e of threats) {
      const dx = p.x - e.x, dz = p.z - e.z, d = Math.hypot(dx, dz) || 1;
      const w = 1 / Math.max(0.3, d * d) * (e.isBoss ? 6 : 1);
      ax += dx / d * w * 3; az += dz / d * w * 3;
      ax += -dz / d * w * 1.2; az += dx / d * w * 1.2;
    }
    for (const b of eprojs) { const dx = p.x - b.x, dz = p.z - b.z, d = Math.hypot(dx, dz); if (d < 2) { ax += dx / d * 2 / d; az += dz / d * 2 / d; } }
    if (r) { ax += (r.cx - p.x) * 0.12; az += (r.cz - p.z) * 0.12; }
    const coin = pickups.find((c) => Math.hypot(c.x - p.x, c.z - p.z) < 3);
    if (coin) { ax += (coin.x - p.x) * 0.2; az += (coin.z - p.z) * 0.2; }
    return [ax, az];
  }
  const near = pickups.find((c) => roomAt(c.x, c.z) === r && c.kind === 'coin' && c.t < 8);
  if (near) return toward(near.x, near.z);
  const chest = props.find((q) => q.kind === 'chest' && !q.opened && roomAt(q.x, q.z) === r);
  if (chest) return toward(chest.x, chest.z);
  const stairs = props.find((q) => q.kind === 'stairs');
  // route to the next unvisited room (or the stairs) through room centres
  const here = r || roomFromGrid(p.x, p.z);
  if (!here) return [0, 0];
  let goal = stairs && rooms.every((q) => q.visited || q.type === 'shop') ? roomAt(stairs.x, stairs.z) : null;
  if (stairs && here === goal) return toward(stairs.x, stairs.z);
  const prev = new Map([[here, null]]); const q = [here]; let found = null;
  while (q.length) { const c = q.shift(); if (goal ? c === goal : !c.visited) { found = c; break; } for (const o of c.links) if (!prev.has(o)) { prev.set(o, c); q.push(o); } }
  if (!found && stairs) { goal = roomAt(stairs.x, stairs.z); return toward(goal.cx, goal.cz); }
  if (!found) return [0, 0];
  let step = found; while (prev.get(step) && prev.get(step) !== here) step = prev.get(step);
  const horizontal = step.gx !== here.gx;
  if (horizontal && Math.abs(p.z - here.cz) > 0.4) return toward(p.x, here.cz);
  if (!horizontal && Math.abs(p.x - here.cx) > 0.4) return toward(here.cx, p.z);
  return toward(step.cx, step.cz);
}
function roomFromGrid(x, z) { const gx = Math.floor(x / SX), gy = Math.floor(z / SZ); return roomGrid[gy * GW + gx] || null; }
function toward(x, z) { const dx = x - player.x, dz = z - player.z, d = Math.hypot(dx, dz); return d < 0.1 ? [0, 0] : [dx / d, dz / d]; }

// ---------- main update ----------
function update(dt) {
  G.time += dt;
  if (G.state === 'play') {
    updatePlayer(dt); G.run.time += dt;
    if (meta.aweNext) aweNextTick(); // the first free chest's awesome spell pick
    if (G.prologue) proUpdate(dt);
    if (G.lvPicks > 0 && (G.lvPickT -= dt) <= 0) { G.lvPicks--; G.lvPickT = 0.5; G.rerollFn = levelUpOptions; G.rerolled = false; openCards('LEVEL UP', levelUpOptions()); }
    if ((G.comboT -= dt) <= 0) G.combo = 0;
    const r = roomAt(player.x, player.z);
    if (r && r !== G.curRoom) enterRoom(r);
    if (!r && G.curRoom && !G.curRoom.active && !ZOO) G.curRoom = null; // the zoo keeps its room (bosses aim inside G.curRoom)
    if (!ZOO || zoo.spells) castSpells(dt);
    updateUniqueFx(dt); updateFairy(dt);
    if (ZOO) zooUpdate(dt);
    if (G.daily && G.daily.mod.id === 'rocks') dailyRocks(dt);
    if (G.curRoom && !G.curRoom.active) G.safeRoom = G.curRoom; // a continued run starts here
    if (G.saveDue && runSafe()) checkpoint();
    // waves are driven by whichever room is locked, not by where the camera thinks we are
    const cr = rooms.find((q) => q.active);
    if (cr) {
      if (cr !== G.curRoom) console.warn('active room is not the current room', cr.type, G.curRoom && G.curRoom.type);
      if (G.swarm && G.swarm.room === cr) updateSwarm(cr, dt);
      else if (enemies.length === 0 && portals.length === 0) {
        G.waveDelay -= dt;
        if (G.waveDelay <= 0) { if (cr.waves > 0) { spawnWave(cr); G.waveDelay = 0.6; } else clearRoom(cr); }
      }
      // watchdog: an enemy stuck outside the room (spawned in a wall, knocked into the void) gets pulled back
      for (const e of enemies) {
        if (roomAt(e.x, e.z) === cr || e.isBoss) { e.out = 0; continue; }
        if ((e.out = (e.out || 0) + dt) > 2) { console.warn('enemy outside room, moved back', e.type); e.x = cr.cx + rr(-2, 2); e.z = cr.cz + rr(-2, 2); e.out = 0; }
      }
    }
  } else if (G.state === 'dead') {
    G.deadT += dt;
  }
  if (G.state === 'play' || G.state === 'dead' || G.state === 'trans') {
    for (const e of enemies) updateEnemy(e, dt);
    enemies = enemies.filter((e) => !e.dead);
    updateProjectiles(dt);
    updatePickups(dt);
    updateProps(dt);
    updateMisc(dt);
  }
  updateGlows(dt);
  updateDebris(dt);
}
function updateProjectiles(dt) {
  for (let i = projs.length - 1; i >= 0; i--) {
    const p = projs[i];
    p.life -= dt;
    if (p.fan) { // its lane in the fan: curve back in onto the point it was aimed at, then fly straight on (pierce lines stay lines)
      const dx = p.fx - p.x, dz = p.fz - p.z;
      if (dx * dx + dz * dz < 0.8 || dx * p.vx + dz * p.vz <= 0) p.fan = 0;
      else {
        const cur = Math.atan2(p.vz, p.vx), sp = Math.hypot(p.vx, p.vz); let da = Math.atan2(dz, dx) - cur; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
        const na = cur + clamp(da, -p.fan * dt, p.fan * dt); p.vx = Math.cos(na) * sp; p.vz = Math.sin(na) * sp;
      }
    }
    if (p.homing) {
      if (!p.target || p.target.dead) p.target = nearestEnemy(p.x, p.z, 6, p.hit);
      if (p.target) {
        const want = Math.atan2(p.target.z - p.z, p.target.x - p.x), cur = Math.atan2(p.vz, p.vx);
        let da = want - cur; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
        const na = cur + clamp(da, -p.homing * dt, p.homing * dt);
        p.vx = Math.cos(na) * p.speed; p.vz = Math.sin(na) * p.speed;
      }
    }
    if (p.boomerang && !p.back && p.life < p.maxLife * 0.5) { p.back = true; p.hit.clear(); }
    if (p.back) { const dx = player.x - p.x, dz = player.z - p.z, d = Math.hypot(dx, dz) || 1; p.vx = dx / d * p.speed * 1.2; p.vz = dz / d * p.speed * 1.2; if (d < 0.5) p.life = 0; }
    const ox = p.x, oz = p.z;
    p.x += p.vx * dt; p.z += p.vz * dt;
    p.y += (0.7 - p.y) * Math.min(1, dt * 6); // leave the weapon tip, settle to flight height
    if (p.bounce > 0 && solid(p.x, p.z, false)) { // bouncing rune: ricochet off walls
      if (solid(p.x, oz, false)) p.vx *= -1; if (solid(ox, p.z, false)) p.vz *= -1;
      p.x = ox; p.z = oz; p.bounce--; burst(p.x, p.y, p.z, p.color, 4, 2, 0.25, 0.2);
    }
    if (p.boomerang && solid(p.x, p.z, false) && !p.back) { p.back = true; p.hit.clear(); p.x = ox; p.z = oz; }
    if ((p.kind === 'boulder' || p.kind === 'magma') && (p.lobT = (p.lobT || 0) + dt) < 0.42) { // Boulder (user 11-15: "use the golems' lob"): hurled up in an
      // arc, lands with a thump and dust, then rolls on. No hits while it's in the air.
      const k = p.lobT / 0.42; placeProj(p, p.y + 1.7 * Math.sin(Math.PI * k), dt); p.shadow.scale.setScalar(0.5 + 0.5 * k);
      if (p.lobT + dt >= 0.42) { chunkDust(p.x, p.z, 0x8a6a4a); chunkDust(p.x, p.z, 0x6a5038); addRing(p.x, p.z, 0.2, 1.8, 0.3, 0xc8a878); addCrack(p.x, p.z, 1.0, false); splat(p.x, p.z, 0x2a1e12, 0.9, 0.7); pebbles(p.x, 0.3, p.z, MOBILE ? 2 : 4); addShake(0.15); sfx('slam'); } // the landing marks the floor (user 11-15)
      continue;
    }
    let bY = 0; // Boulder (user 11-15: 'bounce, move slower'): after landing it rolls at 55% speed and keeps hopping, each hop lower, with a thud
    if (p.kind === 'boulder' && p.lobT >= 0.42) { if (!p.slowed) { p.slowed = true; p.vx *= 0.55; p.vz *= 0.55; p.life *= 1.6; } const ph = (p.bt = (p.bt || 0) + dt) / 0.5, hop = Math.floor(ph); bY = Math.abs(Math.sin(ph * Math.PI)) * 0.6 * Math.pow(0.75, hop); if (hop !== p.hopN) { p.hopN = hop; chunkDust(p.x, p.z, 0x8a6a4a); addShake(0.05); sfx('thud'); } }
    placeProj(p, p.y + bY, dt); if (p.goo) gooHop(p);
    p.glow.scale.setScalar(p.size * 0.8 * (0.9 + Math.random() * 0.2));
    if (p.shards && (p.shA || 0) < Math.PI * 2 && (p.shT -= dt) <= 0) { // one full turn, then it stops spraying (user: '1 cycle stop') // Frozen Orb: a spinning pinwheel of ice shards (user 11-15: "circling, not left and right")
      // user 11-15: "side shots 360, fast, like the poison spores": a quick spinning spray - 2 opposite shards every 0.07 s
      // (0.05 s at Lv 3+), the pair turning ~37 deg each time; each shard lighter so the total is about the old 2-a-0.2s spray
      // one full rotation spread over the orb's whole flight (user: "is it rotating?" - the old turn was over in 0.7 s): a burst
      // every 0.06 s, the pair stepping round so the spray visibly sweeps a spiral the whole way
      p.shT = 0.1; // ONE shard every 0.1 s (user 11-15); the first one flies straight ahead along the orb's path, then the spray turns
      const fa = (p.shA || 0) + (p.shA0 ?? (p.shA0 = Math.atan2(p.vz, p.vx)));
      p.shA = (p.shA || 0) + Math.PI * 2 * 0.1 / Math.max(0.5, p.maxLife);
      for (const sg of [1]) addProj({ kind: 'bolt', x: p.x, z: p.z, y: p.y, a: fa + (sg - 1), speed: 11, dmg: p.dmg * 0.35, r: 0.18, color: p.color, size: 0.38, life: 0.42, els: p.els, pierce: 0 });
    }
    if (p.trail && (p.trT = (p.trT || 0) - dt) <= 0) { p.trT = 0.2; if (p.trail === 'fire') elPatch(p.x, p.z, 0.6, 2.2, Math.max(2, p.dmg * 0.3), 'fire', 0xff5a10); else elPatch(p.x, p.z, 0.6, 2.2, Math.max(2, p.dmg * 0.3), 'venom', 0x5fff4a); } // Venom Glaive: a poison trail; Magma Boulder: burning ground
    if (p.look) lookTrail(p); // fusion looks: the second element in the trail
    if (p.roll && Math.random() < 0.05) chunkDust(p.x, p.z, 0x8a6a4a); // Boulder: a rare puff of dust, no trail (user 11-15)
    // trail
    if (p.seek) spark(p.x, p.y, p.z, 0xffffff, { s: 0.15, life: 0.15, drag: 0 });
    if (p.kind !== 'boulder' && p.kind !== 'pebble') spark(p.x, p.y, p.z, p.color, { s: p.size * 0.45, life: p.kind === 'fire' ? 0.35 : 0.2, drag: 0, vy: p.kind === 'fire' ? 0.8 : 0, spread: p.kind === 'fire' ? 1 : 0.3 });
    if (p.kind === 'fire' && fxP(0.4)) spark(p.x, p.y, p.z, 0x40302a, { vy: 1, s: 0.5, life: 0.6, drag: 1 });
    if (p.gold && fxP(0.5)) spark(p.x + (Math.random() - 0.5) * 0.3, p.y + (Math.random() - 0.3) * 0.3, p.z + (Math.random() - 0.5) * 0.3, 0xffffff, { vy: 0.5, s: 0.18 + Math.random() * 0.2, life: 0.25, drag: 0 }); // Coin Spray: sparkle trail
    let dead = p.life <= 0 || (solid(p.x, p.z, false) && !p.boomerang);
    if (p.kind === 'fire' && Math.hypot(p.x - p.tx, p.z - p.tz) < 0.35) dead = true;
    if (!dead) {
      for (const e of enemies) {
        const hx = e.x - p.x, hz = e.z - p.z, hr = e.r + p.r; /* projectiles x foes: squared distance, no hypot */
        if (hx * hx + hz * hz >= hr * hr || e.dead || p.hit.has(e) || e.spawn < 0.5 || e.hidden) continue;
        if (e.y < 1.2) {
          if (p.aoe) { dead = true; break; }
          p.hit.add(e);
          if (p.kind === 'pebble') { pebbles(e.x, 0.6, e.z, MOBILE ? 1 : 2); chunkDust(e.x, e.z, 0xb09878); } // the pebble cracks on the foe: dust + bits bouncing off
          if (p.gold) { e.gold = true; dropPickup(e.x, e.z, 'coin', true); /* every coin that hits a foe drops a real coin that waits on the floor (user 11-15: all hits) */ spark(e.x, 0.8, e.z, 0xfff2a0, { s: 1.3, life: 0.1, drag: 0 }); burst(e.x, 0.75, e.z, 0xffd34f, fxN(7), 4, 0.3, 0.35); sfx('clink'); } // Coin Spray: cha-ching, coins spill off the hit
          hurtEnemy(e, p.dmg, p.vx, p.vz, p.kb || (p.kind === 'bolt' ? 2.5 : 1.2), p.color, p.els);
          if (p.reap && !e.dead && !e.isBoss && e.hp < e.maxHp * p.reap) { addText(e.x, 1.6, e.z, 'REAPED', '#c48cff', 1); burst(e.x, 0.7, e.z, 0xa35cff, 12, 4, 0.4, 0.4); hurtEnemyRaw(e, e.hp + 1, '#c48cff'); } // Reaper Scythe
          if (p.split) { // Prism Lance: splits into shards on its first hit
            const n = p.split, fa = Math.atan2(p.vz, p.vx); p.split = 0;
            for (let q = 0; q < n; q++) { const sp = { kind: 'bolt', x: e.x, z: e.z, y: p.y, a: fa + (q - (n - 1) / 2) * 0.55, speed: p.speed * 0.8, dmg: p.dmg * 0.45, r: 0.2, color: p.color, size: 0.55, life: 0.5, els: p.els, pierce: 1 }; addProj(sp); sp.hit.add(e); }
            burst(e.x, 0.7, e.z, 0xffffff, 6, 3, 0.3, 0.25);
          }
          if (p.bounce > 0) { // bouncing rune: jump to the next foe instead of stopping
            const nx = nearestEnemy(p.x, p.z, 5, p.hit);
            if (nx) { p.bounce--; const a2 = Math.atan2(nx.z - p.z, nx.x - p.x); p.vx = Math.cos(a2) * p.speed; p.vz = Math.sin(a2) * p.speed; p.target = nx; p.life = Math.max(p.life, 0.6); burst(p.x, p.y, p.z, p.color, 5, 2.5, 0.25, 0.2); break; }
          }
          if (p.storm) {
            const hit = new Set([e]); let from = e; const pts = [new THREE.Vector3(e.x, 0.6, e.z)];
            for (let k = 0; k < 2; k++) { const nx = nearestEnemy(from.x, from.z, 3.2, hit); if (!nx) break; hit.add(nx); pts.push(new THREE.Vector3(nx.x, 0.6, nx.z)); hurtEnemy(nx, p.dmg * 0.5, nx.x - from.x, nx.z - from.z, 1, 0xfff36a); from = nx; }
            if (pts.length > 1) { bolts.push({ pts, life: 0.15, color: '#fff36a' }); sfx('zap'); }
          }
          if (p.poison) { e.poison = 3; e.poisonDps = Math.min((e.poisonDps || 0) + p.poison, p.poison * 3); }
          if (p.pierce-- <= 0) { dead = true; break; }
          p.dmg *= 0.8; // pierce falloff (user, 11-12): -20% damage per foe passed through (2nd foe 80%, 3rd 64%, 4th 51%)
        }
      }
      for (const pot of pots) if (Math.hypot(pot.x - p.x, pot.z - p.z) < 0.4) { breakPot(pot); if (!p.aoe) dead = true; break; }
    }
    if (dead) {
      if (p.look) lookBoom(p); // fusion looks: the second element in the burst
      if (p.cb) corpseBoom(p.x, p.z, p.cb, 0, 1.4); // Corpse Blast's dark bolt (no corpses to blow up)
      else if (p.aoe) explode(p);
      else if (p.endBurst) explode({ x: p.x, z: p.z, aoe: p.endBurst, dmg: p.dmg * 0.6, els: p.els, color: p.color, lite: true, kb: p.kb }); // Ice Spear, Frozen Orb, Boulder
      else { burst(p.x, p.y, p.z, p.color, 6, 3, 0.3, 0.25); if (p.goo) gooPop(p); }
      killProj(p); projs.splice(i, 1);
    }
  }
  for (let i = eprojs.length - 1; i >= 0; i--) {
    const p = eprojs[i];
    if (G.still > 0) continue; // frozen in time
    if (p.homing && player.alive) {
      const want = Math.atan2(player.z - p.z, player.x - p.x), cur = Math.atan2(p.vz, p.vx), sp = Math.hypot(p.vx, p.vz);
      let da = want - cur; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
      const na = cur + clamp(da, -p.homing * dt, p.homing * dt); p.vx = Math.cos(na) * sp; p.vz = Math.sin(na) * sp;
    }
    const ox = p.x, oz = p.z;
    p.life -= dt; p.x += p.vx * dt; p.z += p.vz * dt;
    if (p.bounce > 0 && solid(p.x, p.z, true)) { // the Sentinel's saw gears ricochet off walls
      if (solid(p.x, oz, true)) p.vx *= -1; if (solid(ox, p.z, true)) p.vz *= -1;
      p.x = ox; p.z = oz; p.bounce--; burst(p.x, 0.55, p.z, p.color, 4, 2, 0.25, 0.2); sfx('hit');
    }
    if (p.slowTo && (p.sp0 = p.sp0 || Math.hypot(p.vx, p.vz)) > 0) { const k = Math.max(p.slowTo, Math.exp(-0.9 * dt)); p.vx *= k; p.vz *= k; if (Math.hypot(p.vx, p.vz) < p.sp0 * p.slowTo) { const sc = p.sp0 * p.slowTo / (Math.hypot(p.vx, p.vz) || 1); p.vx *= sc; p.vz *= sc; } } // spores drift and slow down
    placeProj(p, 0.55, dt);
    const kd = p.kind;
    if (kd === 'soul') { if (fxP(0.6)) { const w = Math.sin(p.t3 * 18) * 0.12, l = Math.hypot(p.vx, p.vz) || 1; spark(p.x - p.vz / l * w, 0.55, p.z + p.vx / l * w, p.color, { s: 0.35, life: 0.35, drag: 0 }); } } // a wavy trail
    else if (kd === 'spore') { if (fxP(0.35)) spark(p.x, 0.5, p.z, 0x9add4a, { vy: -0.6, s: 0.25, life: 0.4, drag: 1 }); } // a green drip
    else if (kd === 'tear') { if (fxP(0.5)) spark(p.x, 0.5, p.z, p.color, { vy: -1.2, s: 0.22, life: 0.35, drag: 0 }); } // drips
    else if (kd === 'gear') { if (fxP(0.7)) { const a = Math.random() * 6.28; spark(p.x + Math.cos(a) * 0.4, 0.55, p.z + Math.sin(a) * 0.4, Math.random() < 0.5 ? 0xfff2a0 : 0xffa040, { vx: Math.cos(a) * 3, vz: Math.sin(a) * 3, vy: rr(0.5, 2), s: 0.18, life: 0.2, drag: 3 }); } }
    else if (kd !== 'coin' && fxP(0.5)) spark(p.x, 0.55, p.z, p.color, { s: 0.3, life: 0.25, drag: 0 });
    let dead = p.life <= 0 || solid(p.x, p.z, true) && cellAt(p.x, p.z) !== OBST;
    if (!dead && player.alive && Math.hypot(player.x - p.x, player.z - p.z) < player.r + p.r) { damagePlayer(1, p.x - p.vx, p.z - p.vz); dead = true; }
    if (dead) {
      burst(p.x, 0.55, p.z, p.color, 6, 2.5, 0.3, 0.3);
      if (kd === 'slime') { splat(p.x, p.z, p.color, 0.55, 0.8); chunkDust(p.x, p.z, p.color); } // a glob leaves a splat
      else if (kd === 'spore') { for (let k = 0; k < 4; k++) spark(p.x + rr(-0.3, 0.3), rr(0.2, 0.6), p.z + rr(-0.3, 0.3), Math.random() < 0.5 ? 0x8a9a3a : 0x6a3a8a, { vy: 0.4, s: 0.7, life: 0.6, drag: 1 }); } // a little gas puff
      else if (kd === 'coin') { spark(p.x, 0.55, p.z, 0xffffff, { s: 0.6, life: 0.07, drag: 0 }); coinSpill(p.x, 0.45, p.z, 1, 1.4, 2); }
      else if (kd === 'gear') { for (let k = 0; k < 6; k++) spark(p.x, 0.55, p.z, 0xfff2a0, { vx: rr(-4, 4), vy: rr(1, 3), vz: rr(-4, 4), s: 0.2, life: 0.25, drag: 4 }); sfx('clink'); }
      killProj(p); eprojs.splice(i, 1);
    }
  }
}
function updateMisc(dt) {
  for (let i = portals.length - 1; i >= 0; i--) {
    const p = portals[i];
    if (G.still > 0) continue; // spawn cracks freeze too
    p.t += dt;
    const k = clamp((p.t - p.delay) / (p.dur - p.delay), 0, 1);
    p.mesh.scale.setScalar(p.size * (k < 0.15 ? k / 0.15 : 1) * (1 + Math.sin(p.t * 12) * 0.05));
    p.mesh.rotation.y += dt * 3;
    if (k > 0 && fxP(0.6)) { const a = Math.random() * 6.28, d = Math.random() * p.size; spark(p.x + Math.cos(a) * d, 0.05, p.z + Math.sin(a) * d, Math.random() < 0.5 ? 0x8a2aff : 0x3a1050, { vy: rr(1, 3), s: 0.3, life: 0.6, drag: 0 }); }
    if (k > 0.5 && Math.random() < 0.15) chunkDust(p.x, p.z, 0x6a6470);
    if (k >= 1) {
      const ne = spawnEnemy(p.type, p.x, p.z, p.elite);
      if (p.weak) { ne.hp *= BENCH ? 25 : 0.5; ne.maxHp = ne.hp; } // bench: tanky so the screen stays full
      if (p.hpMul) { ne.hp *= p.hpMul; ne.maxHp = ne.hp; }
      if (p.champ) {
        ne.name = p.champ.name; ne.hp *= 2.6; ne.maxHp = ne.hp; ne.r *= 1.2;
        ne.mesh.userData.bw *= 1.3; ne.mesh.userData.bh *= 1.3; if (ne.wpn) { ne.wpn.userData.bw *= 1.3; ne.wpn.userData.bh *= 1.3; } ne.shadow.scale.multiplyScalar(1.3);
        $('bossname').textContent = ne.name.toUpperCase(); $('bossbar').classList.remove('hidden'); fitBossName();
        banner('CHAMPION', ne.name.toUpperCase()); toastT = 0; $('toast').classList.remove('show'); addShake(0.4); sfx('lock');
      }
      burst(p.x, 0.3, p.z, 0x8a2aff, 10, 3, 0.4, 0.4); chunk(p.x, 0.1, p.z, 0x5a5660, 6, 3, 0.1);
      splat(p.x, p.z, 0x0a0a0a, p.size * 1.6);
      scene.remove(p.mesh); p.mesh.material.dispose(); p.mesh.children[0].material.dispose(); portals.splice(i, 1);
    }
  }
  for (let i = rings.length - 1; i >= 0; i--) {
    const r = rings[i]; r.t += dt;
    const k = r.t / r.dur, e = 1 - Math.pow(1 - Math.min(1, k), 3);
    r.mesh.scale.setScalar(lerp(r.r0, r.r1, e));
    r.mesh.material.opacity = 1 - k;
    if (k >= 1) { scene.remove(r.mesh); ringPool.push(r.mesh); rings.splice(i, 1); }
  }
  let pulled = false;
  for (let i = orbs.length - 1; i >= 0; i--) {
    const o = orbs[i]; o.life -= dt; o.a += dt * 4.2;
    const rad = o.breathe ? o.rad * (1.15 + 0.5 * Math.sin(G.time * 2.4)) : o.rad; // Rune Halo sweeps out and back in
    const x = player.x + Math.cos(o.a) * rad, z = player.z + Math.sin(o.a) * rad;
    if (o.pull && !pulled && player.alive) { // Void Halo: foes near Pip are dragged in to the ring (once a frame for all its orbs; never bosses)
      pulled = true;
      for (const e of enemies) { if (e.dead || e.isBoss || e.spawn < 0.5) continue; const dx = player.x - e.x, dz = player.z - e.z, d = Math.hypot(dx, dz) || 1; if (d < 4.2 && d > o.rad + 0.25) { e.kx += dx / d * 14 * dt; e.kz += dz / d * 14 * dt; } }
      if (fxP(0.4)) { const a = Math.random() * 6.28; spark(player.x + Math.cos(a) * 3.6, 0.4, player.z + Math.sin(a) * 3.6, 0x6a2aaa, { vx: -Math.cos(a) * 5, vz: -Math.sin(a) * 5, s: 0.3, life: 0.4, drag: 0 }); }
    }
    if (o.guard) for (let q = eprojs.length - 1; q >= 0; q--) { // Guardian Orbs: enemy shots they touch are destroyed
      const ep = eprojs[q]; if (Math.abs(ep.x - x) > 0.55 || Math.abs(ep.z - z) > 0.55) continue;
      burst(ep.x, 0.55, ep.z, 0xfff6c8, 6, 2.5, 0.3, 0.3); killProj(ep); eprojs.splice(q, 1);
    }
    o.glow.position.set(x, 0.6, z); o.glow.scale.setScalar(0.8 + Math.sin(G.time * 20) * 0.1);
    o.mesh.position.set(x, 0.6 + Math.sin(G.time * 6 + o.a) * 0.08, z); o.mesh.rotation.y += dt * 6; o.shadow.position.set(x, 0.04, z);
    if (o.saw) { o.mesh.scale.setScalar(1.7); const sp = o.mesh.userData.spinY; if (sp) sp.rotation.y += dt * 30; } // big, spinning hard
    else spark(x, 0.6, z, o.color || 0xb070ff, { s: 0.35, life: 0.25, drag: 0 });
    for (const e of enemies) {
      if (e.dead || e.spawn < 0.5) continue;
      if (Math.hypot(e.x - x, e.z - z) < e.r + 0.3 && (o.hits.get(e) || 0) < G.time) { o.hits.set(e, G.time + 0.4); if (o.saw) { for (let q = fxN(6); q > 0; q--) spark(x, 0.6, z, q & 1 ? 0xffe08a : 0xffffff, { vx: rr(-5, 5), vz: rr(-5, 5), vy: rr(1, 3), s: 0.22, life: 0.3, drag: 1, grav: 6 }); sfx('clink'); } hurtEnemy(e, o.dmg, e.x - player.x, e.z - player.z, 3, o.color || 0xb070ff, o.els); if (o.freeze) { ccFreeze(e, 0.8); e.slow = Math.max(e.slow, 2); } }
    }
    for (const pot of pots) if (Math.hypot(pot.x - x, pot.z - z) < 0.4) { breakPot(pot); break; }
    if (o.life <= 0) { burst(x, 0.6, z, 0xb070ff, 8, 3, 0.3, 0.3); killGlow(o.glow); scene.remove(o.mesh); scene.remove(o.shadow); orbs.splice(i, 1); }
  }
  if (G.still > 0) G.still -= dt;
  for (let i = holes.length - 1; i >= 0; i--) {
    const h = holes[i]; h.t += dt;
    const k = h.t / h.dur, open = ease3(Math.min(1, h.t / 0.35)), imp = Math.max(0, (h.t - (h.dur - 0.18)) / 0.18); // imp: implosion 0..1
    const R = (1.2 + 3.2 * open + 0.6 * k) * (1 - 0.85 * imp * imp), wob = 1 + Math.sin(h.t * 22) * 0.04;
    if (h.disc) { h.disc.scale.set(R * wob, R * wob, 1); h.disc.rotation.z += dt * (1.5 + k * 5); }
    if (h.swirl) { h.swirl.scale.set(R * 1.25, R * 1.25, 1); h.swirl.rotation.z -= dt * (3 + k * 7); h.swirl.material.opacity = 0.9 * (1 - imp); }
    h.core.scale.setScalar((0.6 + 1.2 * open + 0.3 * k) * (1 + Math.sin(h.t * 16) * 0.05) * (1 - 0.8 * imp));
    h.glow.scale.setScalar((2 + k * 3 + Math.sin(h.t * 30) * 0.2) * (1 - 0.6 * imp));
    for (let q = fxN(5); q > 0; q--) { const a = Math.random() * 6.28, d = 2.2 + Math.random() * 2.2; spark(h.x + Math.cos(a) * d, 0.3 + Math.random() * 0.8, h.z + Math.sin(a) * d, Math.random() < 0.55 ? 0xb77aff : 0x3a0a66, { vx: -Math.cos(a) * d * 2.6 - Math.sin(a) * 5, vz: -Math.sin(a) * d * 2.6 + Math.cos(a) * 5, vy: -0.3, s: 0.32, life: 0.4, drag: 0 }); } // streaks spiral in
    for (const e of enemies) {
      if (e.dead || e.isBoss) continue;
      const dx = h.x - e.x, dz = h.z - e.z, d = Math.hypot(dx, dz) || 1;
      if (d < 3.4) { e.kx += dx / d * 30 * dt + -dz / d * 16 * dt; // pull range 3.4 (was 5; user 11-15: less range) e.kz += dz / d * 30 * dt + dx / d * 16 * dt; // pulled in AND swirled round it
        e.voidTgt = Math.max(e.voidTgt || 0, clamp(1.15 - d / 3.0, 0, 1)); e.voidX = h.x; // the look: stretched / shrunk / leaning (enemy render)
        // held in the middle long enough: SWALLOWED whole (user 11-15) - never bosses, elites, named or big foes
        if (d < 1.1) { e.voidHold = (e.voidHold || 0) + dt; if (e.voidHold > 0.7 && !e.elite && !e.name && !isBigFoe(e)) { e.voidHold = 0; addText(e.x, 1.5, e.z, 'SWALLOWED', '#c48cff', 1); burst(h.x, 0.5, h.z, 0x6a1ab0, 12, 3, 0.4, 0.3); hurtEnemyRaw(e, e.hp + 1, '#c48cff'); } }
        else e.voidHold = Math.max(0, (e.voidHold || 0) - dt); }
    }
    if (k >= 1) {
      explode({ x: h.x, z: h.z, aoe: 3, dmg: 500 + G.floor * 56 }); // balance pass (user 11-15): was 70 + 8/floor, 0.4x Arcane Missiles on one foe
      burst(h.x, 0.6, h.z, 0x9a4aff, 40, 8, 0.6, 0.6); burst(h.x, 0.8, h.z, 0x120420, 18, 6, 0.5, 0.5); flash(0.3); addShake(0.5);
      addRing(h.x, h.z, 0.3, 4.2, 0.45, 0xc08aff); addRing(h.x, h.z, 0.2, 3, 0.6, 0x5a1aaa);
      killHole(h); holes.splice(i, 1);
    }
  }
  // sigils (rune traps)
  for (let i = mines.length - 1; i >= 0; i--) {
    const m = mines[i]; m.t += dt; m.arm -= dt; m.life -= dt;
    m.glow.scale.setScalar(1.1 + Math.sin(m.t * (m.arm > 0 ? 30 : 6)) * 0.15);
    if (m.rune) { const k = Math.min(1, m.t / 0.25), r = m.rune; r.scale.setScalar(r.userData.R * (0.4 + 0.6 * ease3(k)) * (1 + Math.sin(m.t * 5) * 0.04)); r.rotation.z += dt * 0.9;
      r.material.opacity = (m.arm > 0 ? 0.5 + 0.5 * Math.abs(Math.sin(m.t * 20)) : 0.75 + 0.25 * Math.sin(m.t * 4)) * Math.min(1, m.life / 0.4); }
    if (fxP(0.1)) spark(m.x, 0.15, m.z, m.color, { vy: 1, s: 0.2, life: 0.4, drag: 0 });
    const trig = m.arm <= 0 && enemies.some((e) => !e.dead && !e.d.fly && Math.hypot(e.x - m.x, e.z - m.z) < 0.9 + e.r);
    if (trig || m.life <= 0) {
      explode({ x: m.x, z: m.z, aoe: m.aoe, dmg: m.dmg, els: m.els, color: m.color });
      if (trig) { addRing(m.x, m.z, 0.3, m.aoe * 1.3, 0.35, m.color); burst(m.x, 0.3, m.z, m.color, 14, 4, 0.35, 0.4); } // the rune flashes up into a shockwave
      killRune(m.rune); killGlow(m.glow); mines.splice(i, 1);
    }
  }
  // rays: lock-on beams from the weapon tip (or a sweeping beam for Hollow Gaze)
  for (let i = rays.length - 1; i >= 0; i--) {
    const r = rays[i]; r.t -= dt; r.tick -= dt;
    const tp = staffTip(), sx = r.ox != null ? r.ox : tp.x, sy = r.ox != null ? 1.05 : tp.y, sz = r.oz != null ? r.oz : tp.z, segs = [];
    if (r.eye) { // the summoned eye: pops in, bobs, stares; fades with the beams
      const k = Math.min(1, (r.dur - r.t) / 0.25), f = Math.min(1, r.t / 0.2);
      r.eye.position.set(r.ox, 1.05 + Math.sin(G.time * 5) * 0.06, r.oz); r.eye.scale.setScalar(Math.max(0.01, ease3(k) * f * (1 + Math.sin(G.time * 24) * 0.08)));
      r.eyeGlow.scale.setScalar((1.8 + Math.sin(G.time * 18) * 0.2) * f);
    }
    if (r.lock) { // Hollow Gaze (user 11-15: "not rotating - aim all 4, each sticks to its foe"): up to 4 beams from the orb, each
      // locked on a different foe within reach of the orb, kept until it dies or leaves reach, then the next nearest
      for (let m = 0; m < r.lock.length; m++) { const e = r.lock[m]; if (!e || e.dead || e.hidden || Math.hypot(e.x - sx, e.z - sz) > r.range + 1) r.lock[m] = null; }
      r.lock = r.lock.filter(Boolean); gazeSeen.clear(); for (const e of r.lock) gazeSeen.add(e);
      while (r.lock.length < r.spokes) { const e = nearestEnemy(sx, sz, r.range, gazeSeen); if (!e) break; r.lock.push(e); gazeSeen.add(e); }
      for (const e of r.lock) segs.push([sx, sz, e.x, e.z, e]);
    }
    else if (r.sweep) { // each beam stops at the first wall: that's where its impact ring sits
      for (let m = 0, n = r.spokes || 1; m < n; m++) {
        const ang = r.a0 + (1 - r.t / r.dur) * r.arc + m * Math.PI * 2 / n, ca = Math.cos(ang), sa = Math.sin(ang);
        let L = r.range; for (let d = 0.6; d < r.range; d += 0.25) if (solid(sx + ca * d, sz + sa * d, true)) { L = d; break; }
        segs.push([sx, sz, sx + ca * L, sz + sa * L, null]);
      }
    }
    else {
      if (!r.target || r.target.dead || r.target.hidden || Math.hypot(r.target.x - player.x, r.target.z - player.z) > r.range) r.target = nearestEnemy(player.x, player.z, r.range);
      if (r.target) segs.push([sx, sz, r.target.x, r.target.z, r.target]);
      if (r.split && r.target) { const t2 = nearestEnemy(r.target.x, r.target.z, 4, new Set([r.target])); if (t2) segs.push([sx, sz, t2.x, t2.z, t2]); }
      // Static Ray's sparks are beams of the same ray (user 11-15: "should be just ray as well", not lightning): target -> foe, ~0.3 s
      if (r.sp) { r.sp = r.sp.filter((q) => (q.t -= dt) > 0 && !q.a.dead && !q.b.dead); for (const q of r.sp) segs.push([q.a.x, q.a.z, q.b.x, q.b.z, 'spark']); }
    }
    while (r.lasers.length < segs.length) r.lasers.push(getLaser(r.color)); // thin pooled lasers (see placeLaser)
    for (let k = 0; k < r.lasers.length; k++) {
      const sg = segs[k], L = r.lasers[k];
      if (!sg) { hideLaser(L); continue; }
      const len = Math.hypot(sg[2] - sg[0], sg[3] - sg[1]) || 0.01, fade = Math.min(1, r.t / 0.15); // fades out over its last 0.15s
      placeLaser(L, sg[0], sy, sg[1], Math.atan2(sg[3] - sg[1], sg[2] - sg[0]), len, 0.7 * fade, (r.sweep ? 0.45 : 0.35) * (0.6 + 0.4 * fade), r.color);
    }
    if (r.look) rayLook(r, segs, sy); // fusion beams: Ether Ray's crackle, Sunfire's embers
    if (r.tick <= 0) {
      r.tick = 0.12; r.n++;
      for (const sg of segs) {
        if (sg[4] === 'spark') continue; // drawn only: the spark's damage lands when it fires
        if (sg[4]) {
          dotHit(sg[4], r.dmg, r.color, r.els, r.n % 3 === 0);
          if (r.spark && r.n % 3 === 0 && !sg[4].dead) { // Static Ray: every third tick sparks from the target to 2 foes near it
            arcSeen.clear(); arcSeen.add(sg[4]);
            for (let q = 0; q < 2; q++) { const nx = nearestEnemy(sg[4].x, sg[4].z, 3.4, arcSeen); if (!nx) break; arcSeen.add(nx);
              (r.sp || (r.sp = [])).push({ a: sg[4], b: nx, t: 0.3 }); burst(nx.x, 0.7, nx.z, r.color, 6, 3, 0.25, 0.25);
              dotHit(nx, r.dmg * 1.5, r.color, r.els, true); }
          }
        }
        else {
          const dx = sg[2] - sg[0], dz = sg[3] - sg[1], L = Math.hypot(dx, dz) || 1;
          for (const e of [...enemies]) {
            if (e.dead) continue;
            const ex = e.x - sg[0], ez = e.z - sg[1], al = (ex * dx + ez * dz) / L;
            if (al > 0 && al < L && Math.abs(ex * dz - ez * dx) / L < 0.5 + e.r) dotHit(e, r.dmg, r.color, r.els, r.n % 3 === 0);
          }
        }
      }
    }
    if (r.sweep && r.ox != null && fxP(0.6)) for (const sg of segs) spark(sg[2], 0.5, sg[3], r.color, { s: 0.35, life: 0.25, spread: 2 }); // beam ends sizzle
    if (r.t <= 0) { for (const L of r.lasers) releaseLaser(L); if (r.eye) { killMesh(r.eye); r.eye.material.dispose(); burst(r.ox, 1, r.oz, r.color, 10, 3, 0.3, 0.3); } if (r.eyeGlow) killGlow(r.eyeGlow); rays.splice(i, 1); }
  }
  // wisps: familiars that circle you and shoot
  for (let i = wisps.length - 1; i >= 0; i--) {
    const w = wisps[i]; w.life -= dt; w.cd -= dt; w.a += dt * 1.6;
    const tx = player.x + Math.cos(w.a) * 1.3, tz = player.z + Math.sin(w.a) * 1.3;
    w.x += (tx - w.x) * Math.min(1, dt * 6); w.z += (tz - w.z) * Math.min(1, dt * 6);
    const y = 1.2 + Math.sin(G.time * 4 + w.a) * 0.15;
    w.mesh.position.set(w.x, y, w.z); w.glow.position.set(w.x, y, w.z); w.shadow.position.set(w.x, 0.04, w.z);
    if (fxP(0.3)) spark(w.x, y, w.z, w.color, { vy: 0.4, s: 0.25, life: 0.4, drag: 0 });
    if (w.cd <= 0) {
      const t = nearestEnemy(w.x, w.z, 8);
      if (t) { w.cd = w.rate; addProj({ kind: 'bolt', x: w.x, z: w.z, y, a: Math.atan2(t.z - w.z, t.x - w.x), speed: 12, dmg: w.dmg, r: 0.25, color: w.color, size: 0.6, homing: 7, target: t, life: 1, els: w.els }); }
    }
    if (w.life <= 0) { burst(w.x, y, w.z, w.color, 10, 3, 0.3, 0.4); killGlow(w.glow); scene.remove(w.mesh); scene.remove(w.shadow); wisps.splice(i, 1); }
  }
  // Frostwalkers: a chilling trail behind you
  if (player && player.alive && player.g.flags.frostwalk && Math.hypot(player.vx, player.vz) > 1 && (G.trailT = (G.trailT || 0) - dt) <= 0) {
    G.trailT = 0.25;
    fires.push({ x: player.x, z: player.z, r: 0.7, life: 1.6, dmg: 2 + G.floor, tick: 0, els: ['frost'], color: 0x8fe6ff, glow: makeGlowAt(player.x, 0.1, player.z, 0x8fe6ff, 1.2, 0.3) });
  }
  const ft = G.fireTrail; // Flame Wall: Pip's steps leave fire for a few seconds after a cast
  if (ft && player && ((ft.t -= dt) <= 0 || ft.n >= 8)) G.fireTrail = null;
  else if (ft && player && player.alive && Math.hypot(player.x - ft.x, player.z - ft.z) > 1) {
    ft.x = player.x; ft.z = player.z; ft.n++;
    fires.push({ x: ft.x, z: ft.z, r: 0.55, life: ft.life, dmg: ft.dmg, tick: 0.1, els: ft.els, color: ft.col, glow: makeGlowAt(ft.x, 0.2, ft.z, ft.col, 1.4, 0.45) });
  }
  gfxBegin(); // ground-effect decals are refilled every frame (fires here, vents and spore gas in updateHazards / updateClouds)
  for (let i = fires.length - 1; i >= 0; i--) {
    const f = fires[i]; f.life -= dt; f.tick -= dt;
    if (f.drift) { // Toxic Cloud: drifts after the nearest foe
      const t = nearestEnemy(f.x, f.z, 9);
      if (t && CLOUD_DRIFT) { const dx = t.x - f.x, dz = t.z - f.z, d = Math.hypot(dx, dz) || 1; if (d > 0.3) { f.x += dx / d * f.drift * dt; f.z += dz / d * f.drift * dt; f.glow.position.x = f.x; f.glow.position.z = f.z; } } // user 11-17: the cloud stays where it was cast (CLOUD_DRIFT off)
    }
    if (f.kind === undefined) { // first frame: what it looks like, and its fade clock
      f.kind = f.poison || (f.els && f.els.includes('venom') && !f.els.includes('fire')) ? 'venom' : !f.els || f.els.includes('fire') ? 'fire' : 'other';
      f.age = 0; f.rot = Math.random() * 6.28; f.spin = (Math.random() < 0.5 ? -1 : 1) * rr(0.35, 0.7); f.g0 = Math.min(0.5, f.glow.material.opacity);
    }
    f.age += dt;
    const fin = Math.min(1, f.age / 0.18), fade = fin * clamp(f.life / 0.6, 0, 1); // grow in, fade out (no pop)
    playerGroundFx(f, dt, fade, fin);
    if (f.zone) gfxPut(zoneBatch, f.x, 0.055, f.z, f.r, f.rot + G.time * 0.35 * f.spin, f.color, fade * (0.72 + 0.28 * Math.sin(G.time * 4 + f.rot))); // its exact hit area, following a drifting cloud
    if (f.tick <= 0 && f.els) { f.tick = 0.4; for (const e of [...enemies]) if (!e.dead && Math.hypot(e.x - f.x, e.z - f.z) < f.r + e.r) dotHit(e, f.dmg, f.color, f.els, Math.random() < 0.4); }
    else if (f.tick <= 0) { f.tick = 0.4; for (const e of enemies) if (!e.dead && Math.hypot(e.x - f.x, e.z - f.z) < f.r + e.r) { if (f.poison) { e.poison = 3; e.poisonDps = Math.max(e.poisonDps || 0, 10 + G.floor * 2); } else hurtEnemyRaw(e, f.dmg, '#ffa040'); } }
    if (f.life <= 0) { killGlow(f.glow); fires.splice(i, 1); }
  }
  for (let i = bolts.length - 1; i >= 0; i--) { bolts[i].life -= dt; if (bolts[i].life <= 0) bolts.splice(i, 1); }
  if (judgRunes.length) updateRunes(dt);
  for (let i = texts.length - 1; i >= 0; i--) {
    const t = texts[i]; t.life -= dt; if (t.punch > 0) t.punch = Math.max(0, t.punch - dt * 7);
    if (t.ghost) {
      const k = Math.max(0, t.life / (t.max || 0.25));
      t.ghost.material.uniforms.uAlpha.value = k * (t.grow ? 0.95 : 0.6);
      if (t.grow) setSpriteScale(t.ghost, 1 + (1 - k) * 0.7, 1 + (1 - k) * 0.7);
      if (t.life <= 0) { killMesh(t.ghost); texts.splice(i, 1); }
      continue;
    }
    t.y += t.vy * dt; t.vy -= 4 * dt; t.x += t.vx * dt;
    if (t.life <= 0) texts.splice(i, 1);
  }
  for (const pot of pots) if (pot.barrel && fxP(0.08)) spark(pot.x, 0.7, pot.z, 0xffb020, { vy: 1.5, s: 0.2, life: 0.3, drag: 0 });
  for (const b of barriers) {
    b.userData.t += dt; const fadeIn = Math.min(1, b.userData.t * 3), pulse = 0.75 + Math.sin(G.time * 4 + b.position.x) * 0.25;
    if (b.userData.veil) { b.material.opacity = 0.9 * fadeIn * pulse; continue; }
    if (b.userData.halo) { b.material.opacity = 0.75 * fadeIn * pulse; continue; }
    const grow = Math.min(1.3, b.userData.t * 5);
    b.userData.bars.forEach(([x, z], k) => {
      bMat.makeScale(0.09, Math.max(0.01, grow * (1 + Math.sin(G.time * 10 + x * 3) * 0.05)), 0.09).setPosition(x, 0, z); b.setMatrixAt(k, bMat);
      if (fxP(0.04)) spark(x, Math.random() * 1.2, z, 0xff9be8, { vy: 1.2, s: 0.18, life: 0.5, drag: 0 });
    });
    b.instanceMatrix.needsUpdate = true;
  }
  let nPool = 0; const still = G.still > 0; if (!still) flickT += dt; // Stillness freezes the torch flames too (user 11-15)
  for (let k = 0; k < torchFlames.length; k++) {
    const f = torchFlames[k];
    if (!f.userData.core) continue;
    f.userData.flare = Math.max(0, (f.userData.flare || 0) - dt * 1.5);
    const fl = (0.8 + Math.sin(flickT * 13 + k) * 0.1 + Math.sin(flickT * 23 + k * 2) * 0.08) * (1 + f.userData.flare * 1.8);
    f.scale.setScalar(fl); f.userData.core.scale.setScalar(0.35 * fl);
    if (torchPools && f.userData.pool) { // phones: the floor glow a torch light would cast (the one real torch light needs none)
      const [x, z] = f.userData.pool, on = f.visible && !G.dark && Math.hypot(x - torchLights[0].position.x, z - torchLights[0].position.z) > 1.2;
      torchPools.setMatrixAt(nPool++, bMat.makeScale(on ? 6 * (0.9 + fl * 0.12) : 0, 1, on ? 6 * (0.9 + fl * 0.12) : 0).setPosition(x, 0.045, z));
    }
    if (!still && fxP(0.05)) spark(f.position.x, f.position.y + 0.1, f.position.z + 0.05, 0xffa040, { vy: 1.2, s: 0.18, life: 0.5, spread: 0.3, drag: 0 });
  }
  if (torchPools) { torchPools.count = Math.min(nPool, MAXB); torchPools.instanceMatrix.needsUpdate = true; }
  torchLights.forEach((l, k) => { l.intensity = G.dark ? 0 : 14 + Math.sin(G.time * 15 + k * 2) * 1.6 + Math.sin(G.time * 37 + k) * 0.8; });
  hemi.intensity += ((G.dark ? 0.05 : G.biome.hemiI) - hemi.intensity) * damp(3, dt);
  sun.intensity += ((G.dark ? 0.04 : G.biome.sunI) - sun.intensity) * damp(3, dt);
  pLight.distance = G.dark ? 6.5 : 8;
  updateBeams(dt); updateHazards(dt); updateClouds(dt); updateFoeFx(dt); gfxEnd(); updateMeteors(dt); updateFrostRings(dt);
  fxLight.intensity *= Math.exp(-6 * dt);
  for (const r of rooms) {
    if (!r.shroud) continue;
    const sh = r.shroud, dim = sh.children[0];
    if (r.visited) {
      sh.material.opacity -= dt * 1.8; dim.material.opacity -= dt * 1.4;
      if (sh.material.opacity <= 0) { world.remove(sh); sh.material.dispose(); dim.material.dispose(); r.shroud = null; }
      continue;
    }
    // mist thins as you walk up to the room, so it reads as 'unexplored', never as 'blocked'
    const d = player ? Math.hypot(player.x - r.cx, player.z - r.cz) : 99;
    const k = clamp((d - 7) / 9, 0.25, 1);
    sh.material.opacity = 0.6 * k; dim.material.opacity = 0.45 * k;
    sh.position.x = r.cx + Math.sin(G.time * 0.2 + r.gx) * 0.4;
  }
  for (const f of fogPlanes) { const u = f.userData; f.position.x = u.base.x + Math.sin(G.time * 0.13 + u.ph) * 1.6; f.position.z = u.base.z + Math.cos(G.time * 0.11 + u.ph) * 1.2; f.rotation.y = G.time * 0.02 + u.ph; }
  if (player && !(G.still > 0)) { sparkAmb = true; biomeParticles(dt); sparkAmb = false; }
  if (G.lavaTex) G.lavaTex.offset.x += dt * 0.015; lavaMat.uniforms.uTime.value = G.time % 600;
  if (player && (G.dripT = (G.dripT || 2) - dt) <= 0) {
    G.dripT = rr(1.5, 4);
    const x = player.x + rr(-4.5, 4.5), z = player.z + rr(-5, 3);
    if (cellAt(x, z) === FLOOR) {
      spark(x, 3.4, z, 0x7fa4c8, { vy: -9, s: 0.14, life: 0.37, drag: 0 });
      later(0.37, () => { for (let k = 0; k < 5; k++) spark(x, 0.05, z, 0x7fa4c8, { vx: rr(-1, 1), vz: rr(-1, 1), vy: rr(1, 2), s: 0.08, life: 0.3, grav: -8, drag: 1 }); /* no drip sound: it kept looping in the background */ });
    }
  }
  if ((G.ambT = (G.ambT || 6) - dt) <= 0) { G.ambT = rr(6, 13); sfx(pick(['moan', 'chains', 'moan', 'creak'])); }
}

// ---------- 2D overlay: damage numbers, lightning, shop prices ----------
const pv = new THREE.Vector3();
// damage numbers from cached glyph strips (one per colour): strokeText + a fresh font string per number per frame cost
// ~11% of a phone frame; a drawImage per character is far cheaper. Texts with other characters use the old path.
const GLYPHS = '0123456789+-.,!?%x:/ ABCDEFGHIJKLMNOPQRSTUVWXYZ', GLYPH_PX = 40, glyphIdx = new Map([...GLYPHS].map((c, i) => [c, i]));
const glyphStrips = new Map();
function glyphStrip(color) {
  let s = glyphStrips.get(color); if (s) return s;
  const c = document.createElement('canvas'), g = c.getContext('2d'), font = `bold ${GLYPH_PX}px "Courier New", monospace`;
  g.font = font; const adv = g.measureText('0').width, pad = Math.ceil(GLYPH_PX * 0.15), cw = Math.ceil(adv) + pad * 2, ch = GLYPH_PX + pad * 2;
  c.width = cw * GLYPHS.length; c.height = ch;
  g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = GLYPH_PX * 3 / 13; g.strokeStyle = '#000'; g.fillStyle = color;
  for (let i = 0; i < GLYPHS.length; i++) { g.strokeText(GLYPHS[i], i * cw + cw / 2, ch / 2); g.fillText(GLYPHS[i], i * cw + cw / 2, ch / 2); }
  s = { c, adv, pad, cw, ch }; glyphStrips.set(color, s); return s;
}
function glyphText(text, x, y, sz, color) {
  for (const ch of text) if (!glyphIdx.has(ch)) return false;
  const s = glyphStrip(color), k = sz / GLYPH_PX, a = s.adv * k, x0 = x - (a * text.length) / 2 - s.pad * k;
  for (let j = 0; j < text.length; j++) fx.drawImage(s.c, glyphIdx.get(text[j]) * s.cw, 0, s.cw, s.ch, x0 + j * a, y - s.ch * k / 2, s.cw * k, s.ch * k);
  return true;
}
function toScreen(x, y, z) { pv.set(x, y, z).project(camera); return [(pv.x * 0.5 + 0.5) * W * DPR, (-pv.y * 0.5 + 0.5) * H * DPR, pv.z]; }
// where the DOM HUD really sits, in overlay units (CSS px of the canvas): the boss bar's bottom and the shown banner's top,
// 0 when hidden. Measured at most 4 times a second (a layout read), so the combo can sit clear of them on every layout.
const hudCache = { t: -1, boss: 0, banner: 0 };
function hudEdges() {
  const now = performance.now(); if (now - hudCache.t < 250) return hudCache;
  hudCache.t = now;
  const c = fxCanvas.getBoundingClientRect(), s = c.height ? H / c.height : 1, bb = $('bossbar'), bn = $('banner');
  hudCache.boss = bb && !bb.classList.contains('hidden') ? (bb.getBoundingClientRect().bottom - c.top) * s : 0;
  hudCache.banner = bn && bn.classList.contains('show') ? (bn.getBoundingClientRect().top - c.top) * s : 0;
  return hudCache;
}
// Vesper's Judgment pillar on the overlay: a soft column of light from the sky (soft edges, white core) that flares wide
// in its first 0.12 s, then narrows to a thread and fades; a glow pool where it meets the floor. pts = [top, foot], r = half width
const HOLY_BEAM_DY = -30; // px down the screen: where Holy Beam's column ends (user 11-15: 'manual offset, maybe 50px')
function drawPillar(b) {
  const P = b.pts, u = 1 - b.life / b.max;
  pv.set(P[1].x, P[1].y, P[1].z).project(camera); const fx0 = (pv.x * 0.5 + 0.5) * W * DPR, fyF = (-pv.y * 0.5 + 0.5) * H * DPR; // fyF: the true floor point
  pv.set(P[1].x + b.r, P[1].y, P[1].z + b.r).project(camera); const rx = Math.abs((pv.x * 0.5 + 0.5) * W * DPR - fx0), ry = Math.abs((-pv.y * 0.5 + 0.5) * H * DPR - fyF); // sizes from the TRUE point
  const fy0 = fyF + (b.steady ? HOLY_BEAM_DY * DPR : 0); // then the hand-tuned offset only MOVES the end (it used to also stretch ry)
  // the sky end straight UP the screen from the foot (user 11-15: the projected sky point made the column lean); top of the screen
  const tx = fx0, ty = Math.min(fy0 - 40 * DPR, -20 * DPR);
  const wk = b.steady ? 0.95 : u < 0.16 ? 1 - (1 - u / 0.16) ** 3 : Math.max(0, 1 - (u - 0.16) / 0.84) ** 0.8, hw = rx * (0.25 + 0.95 * wk) + 2 * DPR; // steady: Holy Beam's constant column
  const a = clamp(b.life / 0.25, 0, 1) * (b.int ?? 1); // int: Holy Beam ramps from no light to full
  // width + gradient across the column's own screen axis (user 11-15: a perspective-tilted column looked like a skewed cut-out)
  const ax = tx - fx0, ay = ty - fy0, al = Math.hypot(ax, ay) || 1, nx = -ay / al, ny = ax / al;
  const g = fx.createLinearGradient(fx0 - nx * hw, fy0 - ny * hw, fx0 + nx * hw, fy0 + ny * hw);
  g.addColorStop(0, `rgba(${b.color},0)`); g.addColorStop(0.28, `rgba(${b.color},${0.35 * a})`); g.addColorStop(0.5, `rgba(${b.core},${0.95 * a})`);
  g.addColorStop(0.72, `rgba(${b.color},${0.35 * a})`); g.addColorStop(1, `rgba(${b.color},0)`);
  fx.fillStyle = g; fx.beginPath(); // a little wider at the floor, where it lands
  fx.moveTo(tx - nx * hw * 0.7, ty - ny * hw * 0.7); fx.lineTo(tx + nx * hw * 0.7, ty + ny * hw * 0.7); fx.lineTo(fx0 + nx * hw, fy0 + ny * hw);
  if (b.steady) fx.ellipse(fx0, fy0, hw, Math.max(1, hw * ry / (rx || 1)), 0, 0, Math.PI, false); // Holy Beam: the end lies ON the floor (the floor's own foreshortening) at the rune's centre (user 11-15)
  else fx.arc(fx0, fy0, hw, Math.atan2(ny, nx), Math.atan2(ny, nx) + Math.PI, false); // a ROUND foot (a true circle on screen, user 11-15)
  fx.closePath(); fx.fill();
  if (!b.steady) { const er = hw * 0.75 + rx * 0.35, eg = fx.createRadialGradient(fx0, fy0, 0, fx0, fy0, er); eg.addColorStop(0, `rgba(${b.core},${0.55 * a})`); eg.addColorStop(0.6, `rgba(${b.color},${0.25 * a})`); eg.addColorStop(1, `rgba(${b.color},0)`); // soft-edged light pool
    fx.fillStyle = eg; fx.beginPath(); fx.arc(fx0, fy0, er, 0, 6.283); fx.fill(); } // a CIRCLE, not squashed into an oval (user 11-15)
  if (u < 0.12 && !b.steady) { fx.fillStyle = `rgba(255,255,255,${0.6 * (1 - u / 0.12)})`; fx.beginPath(); fx.ellipse(fx0, fy0, rx * 1.3, rx * 1.3 * ry / (rx || 1), 0, 0, 6.283); fx.fill(); }
}
// Momentum comet on the overlay: pts = [sky start, impact]. It has already hit when drawn: the tapered amber streak pulls its
// tail down into the impact over its life, with a white-hot head that fades
function drawComet(b) {
  const P = b.pts, u = 1 - b.life / b.max;
  pv.set(P[1].x, P[1].y, P[1].z).project(camera); const hx = (pv.x * 0.5 + 0.5) * W * DPR, hy = (-pv.y * 0.5 + 0.5) * H * DPR;
  pv.set(P[0].x, P[0].y, P[0].z).project(camera); const sx = (pv.x * 0.5 + 0.5) * W * DPR, sy = (-pv.y * 0.5 + 0.5) * H * DPR;
  const t0 = u * u, tx = lerp(sx, hx, t0), ty = lerp(sy, hy, t0), a = clamp(b.life / 0.12, 0, 1);
  fx.lineCap = 'round';
  for (let s = 0; s < 4; s++) { // 4 pieces, each wider toward the head: a tapered streak without gradients
    const x0 = lerp(tx, hx, s / 4), y0 = lerp(ty, hy, s / 4), x1 = lerp(tx, hx, (s + 1) / 4), y1 = lerp(ty, hy, (s + 1) / 4), k = (s + 1) / 4;
    fx.strokeStyle = `rgba(255,140,40,${0.3 * a})`; fx.lineWidth = (6 + 26 * k) * DPR; fx.beginPath(); fx.moveTo(x0, y0); fx.lineTo(x1, y1); fx.stroke();
    fx.strokeStyle = `rgba(255,200,90,${0.8 * a})`; fx.lineWidth = (2 + 10 * k) * DPR; fx.stroke();
    fx.strokeStyle = `rgba(255,255,235,${a})`; fx.lineWidth = (0.8 + 3.6 * k) * DPR; fx.stroke();
  }
  fx.lineCap = 'butt';
  fx.fillStyle = `rgba(255,170,60,${0.45 * a})`; fx.beginPath(); fx.arc(hx, hy, 20 * DPR * (1 + u), 0, 6.283); fx.fill();
  fx.fillStyle = `rgba(255,255,240,${a})`; fx.beginPath(); fx.arc(hx, hy, 7 * DPR * (1 - u * 0.5), 0, 6.283); fx.fill();
}
const BOLT_MAX = MOBILE ? 10 : 16, BOLT_SEG = MOBILE ? 4 : 6, boltXY = [], boltPath = [];
function drawOverlay() {
  fx.setTransform(1, 0, 0, 1, 0, 0);
  fx.clearRect(0, 0, fxCanvas.width, fxCanvas.height);
  fx.globalCompositeOperation = 'lighter';
  // lightning bolts, newest BOLT_MAX: one jagged path per bolt per frame (into reused arrays, no allocation), stroked 3 times
  // (wide glow, colour, white core). Phones draw fewer bolts with fewer kinks.
  for (let bi = Math.max(0, bolts.length - BOLT_MAX); bi < bolts.length; bi++) {
    const b = bolts[bi], P = b.pts, n = P.length;
    if (b.kind) { if (b.kind === 'pillar') drawPillar(b); else drawComet(b); continue; }
    for (let i = 0; i < n; i++) { pv.set(P[i].x, P[i].y, P[i].z).project(camera); boltXY[i * 2] = (pv.x * 0.5 + 0.5) * W * DPR; boltXY[i * 2 + 1] = (-pv.y * 0.5 + 0.5) * H * DPR; }
    let k = 0; boltPath[k++] = boltXY[0]; boltPath[k++] = boltXY[1];
    for (let i = 0; i < n - 1; i++) {
      const x0 = boltXY[i * 2], y0 = boltXY[i * 2 + 1], x1 = boltXY[i * 2 + 2], y1 = boltXY[i * 2 + 3];
      const nx = -(y1 - y0), ny = x1 - x0, nl = Math.hypot(nx, ny) || 1;
      for (let s = 1; s <= BOLT_SEG; s++) {
        const t = s / BOLT_SEG, j = s === BOLT_SEG ? 0 : (Math.random() - 0.5) * (b.lance ? 15 : b.straight ? 7 : 22) * DPR;
        boltPath[k++] = lerp(x0, x1, t) + nx / nl * j; boltPath[k++] = lerp(y0, y1, t) + ny / nl * j;
      }
    }
    // chain hops (b.max / b.grow / b.fork): the bolt shoots out from its source over b.grow s, crackles side forks, then fades
    if (b.max) fx.globalAlpha = clamp(b.life / b.max * 1.6, 0, 1);
    if (b.grow) { const f = clamp((b.max - b.life) / b.grow, 0.05, 1), m = Math.max(4, Math.round(k / 2 * f) * 2); k = Math.min(k, m); }
    for (let q = 0; q < 3; q++) {
      fx.strokeStyle = q === 0 ? b.glow || 'rgba(255,230,80,.35)' : q === 1 ? b.color : '#ffffff';
      fx.lineWidth = (q === 0 ? b.w || 7 : q === 1 ? (b.fork ? 3.6 : 3) : (b.fork ? 1.6 : 1.2)) * DPR;
      fx.beginPath(); fx.moveTo(boltPath[0], boltPath[1]);
      for (let i = 2; i < k; i += 2) fx.lineTo(boltPath[i], boltPath[i + 1]);
      fx.stroke();
    }
    if (b.fork && k > 6) { // 2 short side forks off the bolt's kinks
      fx.strokeStyle = b.color; fx.lineWidth = 1.6 * DPR; fx.beginPath();
      for (let f = 0; f < 2; f++) {
        const i = 2 + 2 * Math.floor(Math.random() * (k / 2 - 2)); let x = boltPath[i], y = boltPath[i + 1]; fx.moveTo(x, y);
        const a = Math.random() * Math.PI * 2, L = (10 + Math.random() * 14) * DPR;
        for (let st = 0; st < 2; st++) { x += Math.cos(a + (Math.random() - 0.5)) * L; y += Math.sin(a + (Math.random() - 0.5)) * L; fx.lineTo(x, y); }
      }
      fx.stroke();
    }
    fx.globalAlpha = 1;
  }
  fx.globalCompositeOperation = 'source-over';
  fx.textAlign = 'center'; fx.textBaseline = 'middle';
  for (const t of texts) {
    if (t.ghost) continue;
    pv.set(t.x, t.y, t.z).project(camera); /* no [x, y, z] array per number per frame */
    // damage numbers punch on every hit: a quick overshoot, a little shake and a white flash, then settle
    const pk = t.punch || 0, pj = pk * 3 * DPR;
    const x = (pv.x * 0.5 + 0.5) * W * DPR + (pk ? (Math.random() - 0.5) * pj : 0), y = (-pv.y * 0.5 + 0.5) * H * DPR + (pk ? (Math.random() - 0.5) * pj : 0);
    const sz = Math.round(13 * t.scale * DPR * (t.punch !== undefined ? 1 + pk * pk * 0.3 : t.life > 0.6 ? 1 + (t.life - 0.6) * 3 : 1));
    fx.globalAlpha = clamp(t.life / 0.3, 0, 1);
    if (glyphText(String(t.text), x, y, sz, pk > 0.55 ? '#ffffff' : t.color || '#fff')) continue;
    fx.font = `bold ${sz}px "Courier New", monospace`;
    fx.lineWidth = 3 * DPR; fx.strokeStyle = '#000'; fx.strokeText(t.text, x, y);
    fx.fillStyle = t.color; fx.fillText(t.text, x, y);
  }
  fx.globalAlpha = 1;
  if (G.swarm && G.state === 'play' && !BENCH) {
    fx.font = `bold ${Math.round(22 * DPR)}px "Courier New", monospace`; fx.lineWidth = 5 * DPR; fx.strokeStyle = '#1a0420';
    const txt = `SURVIVE ${Math.max(0, G.swarm.t).toFixed(1)}`;
    fx.strokeText(txt, W * DPR / 2, H * DPR * 0.1); fx.fillStyle = G.swarm.t < 5 ? '#8dff9f' : '#ff6a7a'; fx.fillText(txt, W * DPR / 2, H * DPR * 0.1);
  }
  if (G.hold && player && player.alive && G.state === 'play') { // small timer above the head, seconds inside
    const up = SPRITE_H.wizard + 0.85;
    const [x, y] = toScreen(player.x, Math.cos(PITCH) * up, player.z - Math.sin(PITCH) * up), R = 10 * DPR;
    fx.fillStyle = 'rgba(8,6,16,.85)'; fx.beginPath(); fx.arc(x, y, R, 0, Math.PI * 2); fx.fill();
    fx.lineWidth = 2.5 * DPR; fx.strokeStyle = G.hold.col; fx.beginPath(); fx.arc(x, y, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, G.hold.p)); fx.stroke();
    fx.font = `bold ${11 * DPR}px "Courier New", monospace`; fx.fillStyle = '#fff';
    fx.fillText(String(Math.max(1, Math.ceil(G.hold.left))), x, y + DPR);
  }
  if (G.combo >= 3 && G.state === 'play') {
    const k = 1 + G.comboPop * 0.5, a = clamp(G.comboT / 0.6, 0, 1);
    fx.globalAlpha = a;
    fx.font = `bold ${Math.round(26 * k * DPR)}px "Courier New", monospace`;
    fx.lineWidth = 5 * DPR; fx.strokeStyle = '#1a0420';
    const col = G.combo >= 50 ? '#ff4f6a' : G.combo >= 20 ? '#ffd34f' : '#ff8be0';
    // below the boss bar wherever it really ends (safe area, --lz scale, short screens); 24 = half the popped digits + a gap
    const hud = hudEdges(), cy = Math.max(LAND ? Math.max(H * 0.155, 136) : H * 0.155, hud.boss ? hud.boss + 24 : 0);
    fx.strokeText(`${G.combo}x`, W * DPR / 2, cy * DPR); fx.fillStyle = col; fx.fillText(`${G.combo}x`, W * DPR / 2, cy * DPR);
    const word = G.combo >= 50 ? 'UNSTOPPABLE' : G.combo >= 20 ? 'RAMPAGE' : 'COMBO', wy = cy + 22 * k;
    if (!hud.banner || wy + 8 < hud.banner) { // the word steps aside for a banner pushed into its row
      fx.font = `bold ${Math.round(11 * DPR)}px "Courier New", monospace`; fx.lineWidth = 3 * DPR;
      fx.strokeText(word, W * DPR / 2, wy * DPR); fx.fillStyle = '#fff'; fx.fillText(word, W * DPR / 2, wy * DPR);
    }
    fx.globalAlpha = 1;
  }
  if (player && player.alive && G.state !== 'title') {
    // above the head along the camera's up axis (sprites lean back with the billboard), one segment per heart
    const up = SPRITE_H.wizard + 0.45 + (player.drop > 0 ? 99 : 0);
    const [x, y] = toScreen(player.x, Math.cos(PITCH) * up, player.z - Math.sin(PITCH) * up);
    const hearts = player.maxHp / 2, gap = DPR, h = 3 * DPR, w = Math.min(34, 6 + hearts * 5) * DPR, seg = (w - (hearts - 1) * gap) / hearts;
    fx.fillStyle = 'rgba(10,4,8,.8)'; fx.fillRect(x - w / 2 - DPR, y - DPR, w + 2 * DPR, h + 2 * DPR);
    for (let k = 0; k < hearts; k++) {
      const v = clamp(player.hp - k * 2, 0, 2) / 2, sx = x - w / 2 + k * (seg + gap);
      fx.fillStyle = '#3a1020'; fx.fillRect(sx, y, seg, h);
      if (v > 0) { fx.fillStyle = player.hp <= 2 ? '#ff2a4a' : '#ff4f7a'; fx.fillRect(sx, y, seg * v, h); }
    }
    // Meteor's kill charge (the spell dials are hidden in this HUD): a thin ember bar under the hearts, pulsing when full
    const ms = spells.find((s) => s.id === 'u.meteor');
    if (ms) {
      const c = clamp(ms.ch || 0, 0, 1), my = y + h + 2 * DPR, mh = 2 * DPR;
      fx.fillStyle = 'rgba(10,4,8,.8)'; fx.fillRect(x - w / 2 - DPR, my - DPR, w + 2 * DPR, mh + 2 * DPR);
      fx.fillStyle = '#3a1a08'; fx.fillRect(x - w / 2, my, w, mh);
      fx.fillStyle = c >= 1 ? (Math.sin(G.time * 14) > 0 ? '#fff0a0' : '#ff8a1a') : '#ff7a1a'; fx.fillRect(x - w / 2, my, w * c, mh);
    }
  }
  barRects.length = 0;
  for (const e of enemies) {
    if (e.dead || e.isBoss || e.name || e.hp >= e.maxHp || e.hidden || e.spawn < 1) continue;
    // just above the art's real top, along the camera's up axis (the billboard leans back: straight up put the bar mid-body)
    const top = foeTop(e);
    pv.set(e.x, e.y + Math.cos(PITCH) * top, e.z - Math.sin(PITCH) * top).project(camera); /* no array per foe per frame */
    const w = Math.max(16, Math.min(46, Math.sqrt(e.maxHp / Math.pow(1.33, G.floor - 1)) * 2.6)) * DPR, h = 3 * DPR, x = (pv.x * 0.5 + 0.5) * W * DPR;
    let y = (-pv.y * 0.5 + 0.5) * H * DPR - h - 5 * DPR;
    for (let k = 0, moved = true; moved && k < 3; k++) { // two foes stacked: the second bar steps up above the first
      moved = false;
      for (let j = 0; j < barRects.length; j += 3) if (Math.abs(barRects[j] - x) < (barRects[j + 2] + w) / 2 + 2 * DPR && Math.abs(barRects[j + 1] - y) < h + 3 * DPR) { y = barRects[j + 1] - h - 4 * DPR; moved = true; }
    }
    barRects.push(x, y, w);
    fx.fillStyle = 'rgba(0,0,0,.7)'; fx.fillRect(x - w / 2 - DPR, y - DPR, w + 2 * DPR, h + 2 * DPR);
    fx.fillStyle = e.elite ? '#ffd34f' : '#ff4f6a'; fx.fillRect(x - w / 2, y, w * Math.max(0, e.hp / e.maxHp), h);
  }
  for (const e of enemies) {
    if (!e.name || e.dead) continue;
    const top = foeTop(e) + 0.25, [x, y] = toScreen(e.x, e.y + Math.cos(PITCH) * top, e.z - Math.sin(PITCH) * top);
    fx.font = `bold ${11 * DPR}px "Courier New", monospace`; fx.lineWidth = 3 * DPR; fx.strokeStyle = '#000';
    fx.strokeText(e.name, x, y); fx.fillStyle = '#ff6a7a'; fx.fillText(e.name, x, y);
  }
  for (const p of props) {
    if (p.kind !== 'shop' || p.sold) continue;
    const [x, y] = toScreen(p.x, 1.45, p.z);
    fx.font = `bold ${12 * DPR}px "Courier New", monospace`;
    fx.lineWidth = 3 * DPR; fx.strokeStyle = '#000'; fx.strokeText(p.offer.price + 'c', x, y);
    fx.fillStyle = G.coins >= p.offer.price ? '#ffd34f' : '#9a8a6a'; fx.fillText(p.offer.price + 'c', x, y);
  }
}

// ---------- input ----------
addEventListener('keydown', (e) => {
  input.keys.add(e.code);
  if (ZOO) zooKey(e);
  if (e.code === 'Escape' && !G.prologue && !ZOO) { if (G.state === 'play') pauseGame(); else if (G.state === 'paused' && !$('pause').classList.contains('hidden')) $('btnResume').click(); } // Esc: the painted pause menu (old STATS view is gone, user)
  if (e.code === 'KeyM') toggleMute();
  if (e.code === 'KeyR' && !window.RB_WEB && !window.Capacitor) toggleRecording(); // R records only on the dev/test link: never in the CrazyGames or store builds (players hit R next to WASD and got a .webm download)
});
addEventListener('keyup', (e) => input.keys.delete(e.code));
// cheat (user 11-16): type UNLOCKALL anywhere - every element, every spell (codex: signature, boss, unique, legendary) and every
// fairy unlocked. Nothing else changes: runs still have to be played (no levels, shards, floors or gear given).
let cheatBuf = '';
addEventListener('keydown', (e) => {
  if (e.key.length !== 1) return;
  cheatBuf = (cheatBuf + e.key.toLowerCase()).slice(-9);
  if (cheatBuf.endsWith('iamrich')) { cheatBuf = ''; meta.shards = (meta.shards || 0) + 9999; saveMeta(); sfx('coin', 14); toast('I AM RICH', '+9999 soul shards'); if (!$('title').classList.contains('hidden')) renderTitle(); return; } // cheat: +9999 shards
  if (cheatBuf !== 'unlockall') return;
  cheatBuf = '';
  meta.elements = [...ELEMENT_ORDER];
  const ids = [...SIG_IDS, ...Object.keys(BOSS_SPELLS), ...Object.keys(UNIQUE_SPELLS), ...Object.keys(LEGENDARY)].filter((id) => spellDef(id) && !CUT_IDS.has(id));
  for (const id of ids) if (!meta.codex.includes(id)) meta.codex.push(id);
  meta.fairies = meta.fairies || {}; for (const t of Object.keys(FAIRY)) if (!meta.fairies[t]) meta.fairies[t] = 1;
  if (!meta.fairy) meta.fairy = Object.keys(FAIRY)[0];
  meta.prologueDone = true;
  saveMeta(); sfx('clear'); toast('UNLOCK ALL', 'Every element, spell and fairy unlocked');
  if (G.state === 'title' || !$('title').classList.contains('hidden')) renderTitle();
});
function readKeys() {
  const k = input.keys;
  if (k.size && !document.hasFocus()) k.clear(); // safety net: keys can't be held in a page without focus (a missed blur)
  let x = (k.has('KeyD') || k.has('ArrowRight') && !ZOO ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') && !ZOO ? 1 : 0); // the zoo's left/right arrows are PREV / NEXT
  let z = (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0) - (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0);
  if (input.stick) { x = input.stick.x; z = input.stick.z; }
  input.x = x; input.z = z;
}
const stickEl = $('stick'), knobEl = $('knob');
app.addEventListener('pointerdown', (e) => {
  if (G.state !== 'play' || e.target.closest('#muteBtn,#pauseBtn,.card,.screen')) return;
  input.stick = { id: e.pointerId, ox: e.clientX, oy: e.clientY, x: 0, z: 0, mouse: e.pointerType === 'mouse' };
  if (e.pointerType === 'mouse') return; // desktop: mouse drag still steers, but the on-screen stick is for fingers only
  const rect = app.getBoundingClientRect();
  stickEl.style.left = e.clientX - rect.left + 'px'; stickEl.style.top = e.clientY - rect.top + 'px'; stickEl.style.display = 'block';
  knobEl.style.transform = '';
});
addEventListener('pointermove', (e) => {
  const s = input.stick; if (!s || s.id !== e.pointerId) return;
  let dx = e.clientX - s.ox, dy = e.clientY - s.oy; const l = Math.hypot(dx, dy), max = 48;
  if (l > max) { dx *= max / l; dy *= max / l; }
  s.x = dx / max; s.z = dy / max;
  if (l < 6) s.x = s.z = 0;
  knobEl.style.transform = `translate(${dx}px,${dy}px)`;
});
// iOS shows its text magnifier on a long press even with user-select:none; cancelling touchstart stops it (pointer events
// still fire, so the stick and pointerdown taps work). Buttons, links and panels that scroll keep native touch: click and pan-y need it.
const NATIVE_TOUCH = 'button, a, input, textarea, select, label, [contenteditable], .screen, #over, #title, #pause, #cards, .rw-overlay';
const scrolls = (el) => { for (; el && el !== app; el = el.parentElement) { const o = getComputedStyle(el).overflowY; if ((o === 'auto' || o === 'scroll') && el.scrollHeight > el.clientHeight) return true; } return false; };
document.addEventListener('touchstart', (e) => { const t = e.target; if (t.closest && !t.closest(NATIVE_TOUCH) && !scrolls(t)) e.preventDefault(); }, { passive: false });
for (const ev of ['selectstart', 'contextmenu', 'dblclick']) document.addEventListener(ev, (e) => { if (!(e.target.closest && e.target.closest('input, textarea, [contenteditable]'))) e.preventDefault(); });
const endStick = (e) => { if (input.stick && input.stick.id === e.pointerId) { input.stick = null; stickEl.style.display = 'none'; } };
addEventListener('pointerup', endStick); addEventListener('pointercancel', endStick); addEventListener('lostpointercapture', endStick);
// stuck controls (user): a key or mouse release the page never hears (Alt-Tab / focus switch, mouse let go outside the
// window or iframe, a native drag, Cmd held on Mac) left the hero walking. Drop every held input whenever that can happen.
function releaseInput() { input.keys.clear(); if (input.stick) { input.stick = null; stickEl.style.display = 'none'; } }
addEventListener('blur', releaseInput);
// web portals (CrazyGames runs us in an iframe): clicking outside the game moves the keyboard to the host page, so the run
// pauses behind a CLICK TO CONTINUE veil (user 11-15). G.focusHold keeps the portal shim in 'gameplay' (portal.json playing):
// CrazyGames asks for no gameplayStop on focus changes.
const FOCUS_PAUSE = !!window.RB_WEB || window.top !== window;
const CLOUD_DRIFT = false; // Toxic / Plague Cloud used to creep after the nearest foe
function focusResume() { const v = $('focusVeil'); if (v) v.remove(); if (!G.focusHold) return; G.focusHold = false; if (G.state === 'paused' && $('pause').classList.contains('hidden')) G.state = 'play'; try { window.focus(); } catch (e) { /* framed */ } }
// one pause screen at a time (user 11-17: two PAUSED overlays on CrazyGames after ads / reloads): the veil never shows over
// another pause or popup, and a veil left behind once something else resumed or re-paused the run is cleared
setInterval(() => { const v = $('focusVeil'); if (v && (!G.focusHold || G.state !== 'paused' || !$('pause').classList.contains('hidden'))) { v.remove(); if (G.focusHold && G.state !== 'paused') G.focusHold = false; } }, 250);
addEventListener('blur', () => {
  if (!FOCUS_PAUSE || AUTO || G.state !== 'play' || !player || !player.alive || $('focusVeil') || !$('pause').classList.contains('hidden') || document.querySelector('.rw-overlay, #keepVeil, #reviveVeil')) return;
  G.state = 'paused'; G.focusHold = true;
  const v = document.createElement('div'); v.id = 'focusVeil'; v.innerHTML = '<b>PAUSED</b><span>CLICK TO CONTINUE</span>';
  v.style.cssText = 'position:fixed;inset:0;z-index:9000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:rgba(6,3,14,.62);color:#f3e6c4;font-family:"Cormorant SC",serif;font-weight:700;letter-spacing:.12em;cursor:pointer;text-align:center';
  v.firstChild.style.cssText = 'font-size:34px'; v.lastChild.style.cssText = 'font-size:16px;opacity:.85';
  v.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); focusResume(); });
  document.body.appendChild(v);
});
addEventListener('keydown', () => { if (G.focusHold) focusResume(); }, true); // a key reaching us means the focus is back
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') releaseInput(); });
document.addEventListener('dragstart', (e) => { e.preventDefault(); releaseInput(); });
document.addEventListener('mouseleave', (e) => { if (!e.buttons) endStickMouse(); });
function endStickMouse() { if (input.stick && input.stick.mouse) { input.stick = null; stickEl.style.display = 'none'; } }
addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' && !e.buttons) endStickMouse(); }, true); // mouse moving with no button down: its release was missed
addEventListener('keyup', (e) => { if (e.key === 'Meta' || e.key === 'Control' || e.key === 'Alt') input.keys.clear(); }); // Mac: no keyup for keys released while Cmd was held

function toggleMute() {
  muted = !muted;
  if (master) master.gain.value = muted ? 0 : 0.8;

}
const screens = ['title', 'over', 'sanctum', 'statsScr', 'codex', 'dungeons', 'fairies'];
// One tap = one action. When a tap opens a screen, the rest of that tap (pointerup / click) must not hit a button that just
// appeared under the finger (e.g. the in-game menu opening, then its BACK firing), and the same button never fires twice in a row.
const tapGuard = (() => {
  let openT = 0; const last = {};
  new MutationObserver((ms) => {
    for (const m of ms) if (m.target.matches('.screen, #cards, .rw-overlay') && !m.target.classList.contains('hidden') && (m.oldValue || '').includes('hidden')) openT = performance.now();
  }).observe($('app'), { subtree: true, attributes: true, attributeFilter: ['class'], attributeOldValue: true });
  new MutationObserver((ms) => { if (ms.some((m) => m.addedNodes.length)) openT = performance.now(); }).observe($('app'), { childList: true }); // ad / purchase overlays opening (closing one doesn't block the next tap)
  for (const type of ['pointerdown', 'click']) {
    document.addEventListener(type, (e) => {
      const b = e.target.closest && e.target.closest('button, [data-tab], #pauseBtn, .card, [data-sku], [data-free]'); if (!b) return;
      const now = performance.now(), l = last[type];
      const tooSoon = now - openT < 350; // the rest of the tap that just opened a screen
      if (tooSoon || (l && l.b === b && now - l.t < 400)) { e.stopImmediatePropagation(); e.preventDefault(); return; }
      last[type] = { b, t: now };
      if (type === 'pointerdown' && !b.matches('.card')) { initAudio(); sfx('tap'); }
    }, true);
  }
  return { opened: () => { openT = performance.now(); } };
})();
function showScreen(id) { for (const sId of screens) { $(sId).classList.toggle('hidden', sId !== id); $(sId).scrollTop = 0; } if (id === 'title') { renderTitle(); setTimeout(loginPop, 700); } if (id === 'sanctum') renderSanctum(); if (id === 'statsScr') renderStats(); if (id === 'codex') renderCodex(); if (id === 'dungeons') renderDungeons(); if (id === 'fairies') renderFairies(); }
function startRun() { if (whenArt(() => startRun())) return; initAudio(); for (const sId of screens) $(sId).classList.add('hidden'); G.daily = null; G.dailyWon = null; G.dailyRet = null; newGame();
  if (meta.loginCoins) { G.coins += meta.loginCoins; $('coins').textContent = G.coins; toast('HEAD START', `+${meta.loginCoins} coins from Daily Rewards`); delete meta.loginCoins; saveMeta(); } }
// main menu: drifting motes, a pulsing staff crystal, and the wizard casting a random spell now and then
const titleFx = (() => {
  const cv = $('titleFx'); if (!cv) return null;
  const S = 420, g = cv.getContext('2d'); cv.width = cv.height = S * 2; g.scale(2, 2);
  const parts = [], shots = [], img = new Image(); img.src = 'sprites/wizard.png';
  const TIP = { x: 254, y: 236 };
  const wiz = document.querySelector('#titleWiz img');
  const ELS = Object.values(ELEMENTS);
  let next = 1.2, last = performance.now();
  const glow = (x, y, r, col, a) => { const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.globalAlpha = a; g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); };
  function cast() {
    const E = ELS[Math.floor(Math.random() * ELS.length)], kind = Math.floor(Math.random() * 3);
    const n = kind === 0 ? 1 : kind === 1 ? 5 : 12, base = -Math.PI / 2 + (Math.random() - 0.5) * 2.2;
    for (let k = 0; k < n; k++) {
      const a = kind === 2 ? k / n * Math.PI * 2 : base + (k - (n - 1) / 2) * 0.28, sp = kind === 2 ? 110 : 190 + Math.random() * 40;
      shots.push({ x: TIP.x, y: TIP.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1.1, col: E.color, r: kind === 0 ? 13 : 9 });
    }
    for (let k = 0; k < 18; k++) { const a = Math.random() * 6.28, v = 30 + Math.random() * 90; parts.push({ x: TIP.x, y: TIP.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.6, max: 0.6, col: E.color, r: 2 + Math.random() * 2 }); }
    flashT = 0.25; flashCol = E.color;
  }
  let flashT = 0, flashCol = '#ffffff';
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (!$('title').classList.contains('hidden') && cv.offsetParent) { // the menu art replaced the wizard: no work when it is hidden
      g.clearRect(0, 0, S, S);
      { // find the staff crystal on screen every frame (the sprite bobs)
        const cr = cv.getBoundingClientRect(), wr = wiz.getBoundingClientRect(), tip = (sheets.wizard && sheets.wizard.tip) || [0.89, 0.67];
        if (cr.width) { TIP.x = (wr.left + wr.width * tip[0] - cr.left) * S / cr.width; TIP.y = (wr.top + wr.height * (1 - tip[1]) - cr.top) * S / cr.height; }
      }
      if (Math.random() < 0.25) parts.push({ x: 40 + Math.random() * 340, y: 300 + Math.random() * 110, vx: (Math.random() - 0.5) * 14, vy: -18 - Math.random() * 30, life: 3.5, max: 3.5, col: ['#a07bff', '#6fe3ff', '#ff7fe0'][Math.floor(Math.random() * 3)], r: 2 + Math.random() * 3 });

      flashT = Math.max(0, flashT - dt);
      g.globalCompositeOperation = 'lighter';
      const pulse = 0.55 + Math.sin(now / 300) * 0.15;
      glow(TIP.x, TIP.y, 34 + flashT * 160, flashT > 0 ? flashCol : '#ff7fe0', Math.min(1, pulse + 0.25 + flashT * 3));
      glow(210, 300, 150, '#5a3aa8', 0.22 + Math.sin(now / 700) * 0.06);
      for (let i = shots.length - 1; i >= 0; i--) {
        const s = shots[i]; s.life -= dt; s.x += s.vx * dt; s.y += s.vy * dt;
        glow(s.x, s.y, s.r * 3.2, s.col, Math.min(1, s.life * 1.5));
        glow(s.x, s.y, s.r, '#ffffff', Math.min(1, s.life * 1.5) * 0.8);
        if (Math.random() < 0.7) parts.push({ x: s.x, y: s.y, vx: 0, vy: 0, life: 0.35, max: 0.35, col: s.col, r: s.r * 0.6 });
        if (s.life <= 0) { for (let k = 0; k < 8; k++) { const a = Math.random() * 6.28; parts.push({ x: s.x, y: s.y, vx: Math.cos(a) * 60, vy: Math.sin(a) * 60, life: 0.4, max: 0.4, col: s.col, r: 2 }); } shots.splice(i, 1); }
      }
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.97; p.vy *= 0.97;
        glow(p.x, p.y, p.r * 3, p.col, Math.max(0, p.life / p.max) * 0.9);
        if (p.life <= 0) parts.splice(i, 1);
      }
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  return { cast };
})();
function renderTitle() {
  const sv = loadRun(); // a saved run: CONTINUE leads, PLAY asks first
  $('btnContinue').classList.toggle('hidden', !sv); $('btnPlay').classList.toggle('big', !sv);
  if (sv) $('btnContinue').textContent = `CONTINUE - FLOOR ${sv.floor}`;
  $('btnPlay').textContent = sv ? 'NEW RUN' : 'PLAY';
  $('dailyCard').innerHTML = dailyCardHtml();
  $('btnFairies').querySelector('.cnt').textContent = `${fairyCount()}/${BOSSES.length}`;
  const fe = $('titleFairy');
  fe.classList.add('hidden'); // no fairy on the title art (user): it only shows in runs
  $('best').innerHTML = `<i class="gem"></i><span class="shard">${meta.shards}</span> soul shards${meta.stats.bestFloor ? ` · best floor ${meta.stats.bestFloor}` : ''}`; }
function heroThumb(id) { return spriteURL(HEROES[id].sprite); } // the sheet file itself (was a canvas copy: blank on a phone out of canvas memory)
function renderSanctum() {
  $('shardBal').innerHTML = `◆ ${meta.shards.toLocaleString()} <b>+</b>`;
  $('heroList').innerHTML = Object.entries(HEROES).filter(([id]) => id === 'wizard').map(([id, h]) => {
    const own = meta.heroes.includes(id), cur = meta.hero === id;
    return `<button class="sp${cur ? ' cur' : ''}" data-hero="${id}" ${!own && meta.shards < h.cost ? 'disabled' : ''} style="--c:#ff8be0" title="${h.info}">
      <img src="${heroThumb(id)}" alt="">${h.name}<small>${cur ? 'PLAYING' : own ? 'PICK' : '◆ ' + h.cost}</small></button>`;
  }).join('') + `<p class="beast" style="grid-column:1/-1;text-align:center">${HEROES[meta.hero].info}</p>`;
  $('upgList').innerHTML = UPGRADES.map((u) => {
    const l = mlv(u.id), maxed = l >= u.max, cost = maxed ? 0 : u.cost[l];
    return `<div class="upg"><div class="ci" style="--img:url(${iconPath('up_' + u.id) || iconURL(u.icon[0], u.icon[1])})"></div>
      <div class="ut"><h3>${u.name}</h3><p>${u.info}</p><div class="pips">${'<i class="on"></i>'.repeat(l)}${'<i></i>'.repeat(u.max - l)}</div></div>
      <button data-up="${u.id}" class="${!maxed && meta.shards < cost ? 'short' : ''}" ${maxed ? 'disabled' : ''}>${maxed ? 'MAX' : '◆ ' + cost}</button></div>`;
  }).join('');
  // any discovered single-element or boss spell whose element you have can start a run
  const starts = meta.codex.filter((id) => { const d = spellDef(id); return d && !d.fused && !d.legendary && !d.unique && d.els.every((e) => meta.elements.includes(e)); });
  $('startList').innerHTML = starts.map((id) => {
    const d = spellDef(id), cur = meta.start === id;
    return `<button class="sp${cur ? ' cur' : ''}" data-sp="${id}" style="--c:${d.color}"><span class="ci" style="--img:url(${spellIcon(d)})"></span>${d.name}<small>${cur ? 'EQUIPPED' : 'EQUIP'}</small></button>`;
  }).join('') || '<p class="beast">Discover spells in runs to start with them.</p>';

  renderVault(); renderVChest(); renderStore(); renderCharStats();
  $('elList').innerHTML = ELEMENT_ORDER.map((el) => {
    const E = ELEMENTS[el], has = meta.elements.includes(el);
    const by = Object.values(BOSS_SPELLS).find((b) => b.unlocks === el);
    const bossName = by ? (BOSSES.find((b) => b.type === by.boss) || {}).name : '';
    const src = elementIconSrc(el);
    return `<span class="elchip${has ? '' : ' off'}" style="--c:${E.color};--img:url(${elemIcon(el)})"><i></i>${E.name}${has ? '' : ` · beat ${bossName ? bossName.toLowerCase() : 'a boss'}`}</span>`;
  }).join('');
}
let vaultSel = null; // { from: 'slot' | 'stash', key }
const VCHEST_ODDS = [['Common gear', 50], ['Rare gear', 30], ['Epic gear', 15], ['Legendary gear', 5]];
const vchestCost = () => 300 + (meta.vchests || 0) * 75;
function renderVChest(target = 'vchest') {
  const c = vchestCost();
  const chest = iconPath('relic_tome') ? '' : '';
  if (!$(target)) return;
  if (target === 'overChest' && dailyReady()) { $(target).innerHTML = `<button data-vchest="daily" class="vchest">
      <span class="rays"></span><img src="${CHEST_IMG}" alt="">
      <div><b>FREE CHEST</b><small>Free gear for your Vault</small></div><em>OPEN<br>FREE</em></button>`; return; }
  const next = target === 'overChest' && meta.prologueDone ? `<small class="nextfree">Free chest in ${chestLeft()}</small>` : '';
  $(target).innerHTML = `<button data-vchest="1" class="vchest">
      <span class="rays"></span><img src="${CHEST_IMG}" alt="">
      <div><b>LUCKY CHEST</b><small>A random piece of gear for your Vault</small>${next}
        <div class="odds">${VCHEST_ODDS.map(([k, w], i) => `<i style="--c:${RARITY[i].color}">${k.replace(' gear', '')} ${w}%</i>`).join('')}</div></div>
      <em>${meta.shards < c && Monet.iapEnabled ? `BUY<br>${dealProduct().price}` : `OPEN<br>◆ ${c}`}</em></button>`;
}
const dealProduct = () => PRODUCTS.find((x) => x.deal);
// ---------- chest reveal: the one dramatic opening every chest reward uses (Daily Chest, Lucky Chests, in-run treasure) ----------
// The screen dims, the chest drops in and shakes with a building glow and climbing coin pitch, bursts open (flash, light rays
// and particles in the rarity colour), then the item card flies in on the painted banner frame. Rarity scales it: common ~1.6s,
// legendary ~2.3s with gold rays and a screen shake. A tap skips to the card. The reward is always granted before this runs,
// and any error here just shows the card (an intro calls then()), so a reward never gets stuck behind it.
// o: { label, rar 0-3, tag?, img, name, sub, lines[], note, foot, buttons [{ x, text }], onPick(x) } or { intro: true, rar, then }
// the shake runs in three rattles that get wilder, with a breath between them, then a hush (the chest swells, still) and BOOM
const REV_SHAKE = [1.3, 1.6, 1.9, 2.3], REV_PARTS = [34, 56, 80, 120], REV_RATTLE = [[0, 0.24, 0.45], [0.34, 0.58, 0.75], [0.66, 0.9, 1.15]], REV_HUSH = 0.9;
const hexA = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
function chestReveal(o) {
  const rar = Math.max(0, Math.min(3, o.rar | 0)), col = RARITY[rar].color, chestImg = CHEST_IMG;
  const el = document.createElement('div'); el.className = `rw-overlay crev r${rar}`;
  el.style.setProperty('--c', col); el.style.setProperty('--ca', hexA(col, 0.55)); el.style.setProperty('--cb', hexA(col, 0.22));
  el.innerHTML = `<div class="cr-rays"></div><canvas class="cr-fx"></canvas>
    <div class="cr-chest">${chestImg ? `<img class="base" src="${chestImg}" alt=""><img class="lid" src="${chestImg}" alt="">` : ''}</div><div class="cr-flash"></div><div class="cr-tada">${RARITY[rar].name.toUpperCase()}!</div>
    ${o.intro ? '' : `<div class="cr-card"><span class="cr-rib">${o.tag || RARITY[rar].name.toUpperCase()}</span>
      <div class="cr-ped"><i></i>${o.img ? `<img src="${o.img}" alt="">` : ''}</div>
      <div class="cr-txt"><small class="cr-lbl">${o.label}</small><b class="cr-name">${o.name}</b>${o.sub ? `<em class="cr-sub">${o.sub}</em>` : ''}
        ${o.lines && o.lines.length ? `<p class="cr-lines">${o.lines.join('<br>')}</p>` : ''}${o.note ? `<small class="cr-note">${o.note}</small>` : ''}
        ${o.foot ? `<div class="cr-foot">${o.foot}</div>` : ''}
        <div class="cr-btns">${(o.buttons || [{ x: 'ok', text: 'NICE' }]).map((b, k) => `<button class="${k ? 'cr-alt' : 'cr-go'}" data-x="${b.x}">${b.text}</button>`).join('')}</div></div></div>`}`;
  $('app').appendChild(el);
  const S = REV_SHAKE[rar], tLand = 0.35, tShake = 0.45, tOpen = tShake + S, tCard = tOpen + 0.75, tEnd = tOpen + 0.9; // the TA-DA word gets its moment before the card
  const cv = el.querySelector('.cr-fx'), g = cv.getContext('2d'), chest = el.querySelector('.cr-chest');
  const cols = rar === 3 ? ['#ffd34f', '#fff3c0', col] : [col, col, '#ffffff'];
  let W = 1, H = 1, t0 = performance.now(), last = t0, opened = false, carded = false, cardAt = 0, done = false, landed = false, ticks = 0, amb = 0;
  const parts = [];
  const size = () => { W = cv.width = Math.max(1, el.clientWidth); H = cv.height = Math.max(1, el.clientHeight); };
  size();
  const R = (a, b) => a + Math.random() * (b - a);
  const later2 = (s, fn) => setTimeout(() => { if (el.isConnected) fn(); }, s * 1000);
  const emit = (n, kind, sp = 1) => { for (let k = 0; k < n; k++) {
    const a = R(0, Math.PI * 2), v = (kind === 'burst' ? R(160, 520) : kind === 'dust' ? R(40, 140) : R(20, 70)) * sp, am = kind === 'amb';
    parts.push({ kind, x: W / 2 + (am ? R(-W * 0.4, W * 0.4) : R(-12, 12)), y: am ? H * R(0.75, 1) : H * 0.42 + (kind === 'dust' ? 40 : R(-10, 10)),
      vx: am ? R(-12, 12) : Math.cos(a) * v, vy: am ? -R(40, 90) : kind === 'glint' ? -R(60, 140) : Math.sin(a) * v - (kind === 'burst' ? 120 : 30),
      life: 0, max: kind === 'burst' ? R(0.6, 1.3) : am ? R(1.4, 2.6) : R(0.35, 0.7), s: kind === 'burst' ? R(2, 5.5) : R(1.5, 3), c: kind === 'dust' ? '#b89878' : cols[k % cols.length] });
  } };
  const open = () => {
    if (opened) return; opened = true; el.classList.add('open');
    emit(REV_PARTS[rar], 'burst'); sfx('chest'); sfx('clear'); try { addShake(0.25 + rar * 0.1); } catch (e) { /* no camera yet */ } // TA-DA
    if (rar >= 2) later2(0.14, () => emit(Math.round(REV_PARTS[rar] * 0.5), 'burst', 0.7));
    if (rar >= 3) { el.classList.add('quake'); later2(0.2, () => sfx('buy')); try { addShake(0.5); } catch (e) { /* no camera yet */ } }
  };
  const card = () => { if (carded || o.intro) return; carded = true; cardAt = performance.now(); el.classList.add('card'); sfx('card'); };
  const finish = () => { if (done) return; done = true; el.classList.add('out'); window.removeEventListener('resize', size); setTimeout(() => el.remove(), 260); try { if (o.then) o.then(); } catch (err) { console.error(err); } };
  const toEnd = () => { try { open(); card(); } catch (e) { el.classList.add('open', 'card'); carded = true; } if (o.intro) finish(); };
  const step = (now) => {
    if (done || !el.isConnected) return;
    try {
      const ts = window.__revSlow || 1, t = (now - t0) / 1000 / ts, dt = Math.min(0.05, Math.max(0, (now - last) / 1000)) / ts; last = now; // __revSlow: QA screenshots
      if (!opened && chest) {
        let y = 0, rot = 0, sx = 1, sy = 1, glow = 0;
        if (t < tLand) { const k = Math.max(0, t / tLand); y = -(1 - k * k) * H * 0.65; rot = -10 * (1 - k); }
        else if (t < tShake) { const q = Math.sin((t - tLand) / (tShake - tLand) * Math.PI) * 0.16; sx = 1 + q; sy = 1 - q; }
        else {
          const k = Math.min(1, (t - tShake) / S), rt = REV_RATTLE.findIndex((q) => k >= q[0] && k < q[1]);
          glow = k; sx = sy = 1 + k * 0.12;
          if (k >= REV_HUSH) { const h = (k - REV_HUSH) / (1 - REV_HUSH); sx = sy = 1.12 + h * 0.14; y = -h * 10; rot = Math.sin(t * 90) * 0.4; } // the hush: swells, almost still
          else if (rt >= 0) { // a rattle: hard and fast, wilder each time
            const q = REV_RATTLE[rt], u = (k - q[0]) / (q[1] - q[0]), a = q[2] * (9 + rar * 3) * Math.sin(u * Math.PI) ** 0.5;
            rot = Math.sin(t * 62) * a; y = -Math.abs(Math.sin(t * 31)) * a * 1.4; sx = 1 + k * 0.12 + Math.sin(t * 50) * 0.04 * q[2]; sy = 2 + k * 0.24 - sx;
            if (!el['rt' + rt]) { el['rt' + rt] = 1; sfx('coin', rt * 5 + rar * 2); emit(3 + rar * 2, 'glint'); emit(4, 'dust', 0.6); } // pitch climbs rattle to rattle
          } else rot = Math.sin(t * 20) * 1.2; // a nervous tremble between rattles
        }
        chest.style.transform = `translate(-50%, -50%) translateY(${y.toFixed(1)}px) rotate(${rot.toFixed(2)}deg) scale(${sx.toFixed(3)}, ${sy.toFixed(3)})`;
        chest.style.setProperty('--g', glow.toFixed(3));
        if (t >= tLand && !landed) { landed = true; sfx('land'); emit(10, 'dust'); }
      }
      if (t >= tOpen) open();
      if (t >= tCard) card();
      if (o.intro && t >= tEnd) finish();
      if (carded && rar >= 1 && (amb += dt) > 0.22 - rar * 0.05) { amb = 0; emit(1, 'amb'); }
      g.clearRect(0, 0, W, H); g.globalCompositeOperation = 'lighter';
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.life += dt; if (p.life >= p.max) { parts.splice(i, 1); continue; }
        if (p.kind === 'burst' || p.kind === 'dust') { p.vy += 520 * dt; p.vx *= 1 - dt * 1.5; }
        p.x += p.vx * dt; p.y += p.vy * dt;
        const f = 1 - p.life / p.max, a = p.kind === 'amb' ? Math.sin(f * Math.PI) * 0.8 : f;
        g.globalAlpha = a; g.fillStyle = p.c;
        g.beginPath(); g.arc(p.x, p.y, p.s * (p.kind === 'burst' ? 0.6 + f * 0.6 : 1), 0, 6.283); g.fill();
        if (p.kind !== 'dust') { g.globalAlpha = a * 0.25; g.beginPath(); g.arc(p.x, p.y, p.s * 3, 0, 6.283); g.fill(); }
      }
      g.globalAlpha = 1;
    } catch (err) { console.error(err); toEnd(); return; }
    requestAnimationFrame(step);
  };
  if (o.quick) { opened = carded = true; cardAt = performance.now(); el.classList.add('open', 'card', 'quick'); sfx('card'); } // quick: just the card (unused for now: Daily + Lucky both get the show, room chests skip chestReveal)
  requestAnimationFrame(step);
  if (!o.quick) setTimeout(() => { if (el.isConnected && !done && (!carded || o.intro)) toEnd(); }, (tEnd + 1.2) * 1000 * (window.__revSlow || 1)); // throttled / hidden tab: still lands on the card
  window.addEventListener('resize', size);
  el.addEventListener('pointerdown', (e) => { e.stopPropagation(); if (done || carded) return; t0 = performance.now() - (o.intro ? tEnd : tCard) * 1000 * (window.__revSlow || 1); }); // tap: skip ahead
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-x]'); if (!b || !carded || done || performance.now() - cardAt < 350) return; // the skipping tap can't also press a button
    done = true; window.removeEventListener('resize', size); el.remove(); sfx('tap');
    if (o.onPick) o.onPick(b.dataset.x);
  });
  return el;
}
const luckyRar = () => { let r = Math.random() * 100; for (let k = 0; k < VCHEST_ODDS.length; k++) { if ((r -= VCHEST_ODDS[k][1]) <= 0) return k; } return 0; }; // the Lucky Chest odds
const vaultGear = (rar) => { const it = rollGear(Math.random, Math.max(5, meta.stats.bestFloor || 1), 0, rar); it.rarity = Math.max(it.rarity, rar); return it; }; // gear for the Vault storage
async function openVChest(free = false) {
  const c = vchestCost();
  if (free && !dailyReady()) return;
  if (!free && meta.shards < c && !Monet.iapEnabled) return needShards(c); // no purchases (iOS for now): just say so
  if (!free && meta.shards < c) { // the button says BUY: purchase the deal, then open
    const prod = await Monet.buy(dealProduct().sku); if (!prod) return;
    grantProduct(prod); toast('PURCHASED', prod.name);
    if (meta.shards < c) { renderTitle(); renderVChest('overChest'); if (!$('sanctum').classList.contains('hidden')) renderSanctum(); return; }
  }
  if (free) meta.chestNext = dailyNow() + CHEST_CD; else { meta.shards -= c; meta.vchests = (meta.vchests || 0) + 1; }
  const first = free && (!meta.elemChestDone || elemChestTest), locked = first ? lockedEls() : [];
  if (first) { // the first free chest ever: an element (if one is locked) + the awesome pick, all saved before anything shows
    meta.elemChestDone = true; meta.aweNext = true; // the pick opens on the next 'play' frame of a normal run (aweNextTick)
  }
  const el = locked.length ? pick(locked) : null;
  if (el) meta.elements.push(el);
  const it = el ? null : vaultGear(luckyRar());
  if (it) meta.stash.push(it);
  saveMeta(); initAudio();
  if (!$('sanctum').classList.contains('hidden')) renderSanctum();
  renderTitle(); renderVChest('overChest'); if ($('overUps')) $('overUps').innerHTML = overUpgrades();
  if (el) return elemChest(el, () => { if (G.dailyHold) { G.dailyHold = false; G.state = 'play'; } });
  const again = meta.shards < vchestCost() && Monet.iapEnabled ? `BUY ANOTHER · ${dealProduct().price}` : `OPEN ANOTHER · ◆ ${vchestCost()}`;
  chestReveal({ label: free ? 'FREE CHEST' : 'LUCKY CHEST', rar: it.rarity, img: gearIcon(it), name: it.name, sub: `${RARITY[it.rarity].name} ${SLOT_NAMES[it.slot]}`,
    lines: gearLines(it), note: 'Sent to your storage', foot: free ? `Next free chest in ${chestLeft()}` : '',
    buttons: free ? [{ x: 'ok', text: 'NICE' }] : [{ x: 'ok', text: 'NICE' }, { x: 'again', text: again }],
    onPick: (x) => { if (x === 'again') openVChest(); if (G.dailyHold) { G.dailyHold = false; G.state = 'play'; } } });
}
// ---------- 7-day login calendar (D1 retention): one claim per local calendar day. Missing a day never resets it: the next
// visit claims the next day. meta.login = { v: 2, n: claims so far, day: local day number of the last claim, el: the element
// the next claim unlocks (pre-rolled when the day before is claimed, so the TOMORROW tease names it) }. A new player can
// claim only after the prologue AND the first run ended, so day 1 lands on the first death/victory screen and the first thing
// they see when leaving is tomorrow's reward. Shown on the main menu and the death/victory screen only (never in a fight, the
// prologue or over a card pick). Death/victory + pause tease TOMORROW.
// Rewards (user): never shards (the purchase currency) and never gear (the Free Chest's job). Permanent stats
// (meta.loginStats, added like the Sanctum's bought points but without raising their price), element unlocks, a coin head
// start for the next normal run (meta.loginCoins, not the Daily Dungeon) and a new fairy. Each week of 7 claims has its own
// table, 4 weeks rotate, then week 1 again with coins x1.5 per full rotation.
const LOGIN_WEEKS = [
  { name: 'SPELLCASTER', theme: 'int', days: [{ k: 'stat', s: 'int' }, { k: 'el' }, { k: 'coins', v: 150 }, { k: 'stat', s: 'vit' }, { k: 'coins', v: 300 }, { k: 'el' }, { k: 'all' }] },
  { name: 'WARRIOR', theme: 'str', days: [{ k: 'stat', s: 'str' }, { k: 'coins', v: 150 }, { k: 'stat', s: 'vit' }, { k: 'el' }, { k: 'stat', s: 'dex' }, { k: 'coins', v: 300 }, { k: 'fairy' }] },
  { name: 'FORTUNE', theme: 'luk', days: [{ k: 'stat', s: 'luk' }, { k: 'coins', v: 150 }, { k: 'stat', s: 'agi' }, { k: 'el' }, { k: 'stat', s: 'int' }, { k: 'coins', v: 300 }, { k: 'all' }] },
  { name: 'LEGEND', theme: 'dex', days: [{ k: 'stat', s: 'dex' }, { k: 'coins', v: 150 }, { k: 'stat', s: 'str' }, { k: 'coins', v: 200 }, { k: 'stat', s: 'vit' }, { k: 'stat', s: 'agi' }, { k: 'top', v: 2 }] },
];
const EL_GLYPH = { arcane: '✦', fire: '🔥', frost: '❄', storm: '⚡', venom: '☠', shadow: '☾', holy: '✚', earth: '⛰' };
const loginSt = () => { // migrates the first calendar (shards / gear, 7 days looping): keep the day number, start in week 1
  const L = meta.login || { n: 0, day: -1 };
  if (L.v !== 2) { L.n = (L.n || 0) % 7; L.v = 2; if (meta.login) meta.login = L; }
  return L;
};
const localDay = () => { const t = dailyNow(); return Math.floor((t - new Date(t).getTimezoneOffset() * 60000) / DAY_MS); };
const loginClaimedToday = () => loginSt().day >= localDay();
const loginReady = () => !AUTO && !BENCH && !ZOO && meta.prologueDone && (meta.stats.runs || 0) >= 1 && !loginClaimedToday();
const fairyToLevel = () => { const own = meta.fairies || {}, can = Object.keys(own).filter((t) => FAIRY[t] && own[t] < FAIRY_MAX); return can.includes(meta.fairy) ? meta.fairy : can[0]; };
const lockedEls = () => ELEMENT_ORDER.filter((e) => !meta.elements.includes(e));
const statImg = (k) => iconPath(STAT_ICON[k]) || iconURL('items', 3, 96);
const topStat = () => STATS.reduce((b, k) => (permStat(k) > permStat(b) ? k : b), STATS[0]);
// the element claim n unlocks: the pre-rolled one for the next claim (rolled now if missing or already unlocked), else unknown
function loginEl(n) {
  const L = loginSt(), lk = lockedEls();
  if (n !== L.n || !lk.length) return null;
  if (!lk.includes(L.el)) { L.el = pick(lk); meta.login = L; saveMeta(); }
  return L.el;
}
// what claim number n (0-based) gives, fallbacks resolved: { day 1-7, week, k, s?, v?, el?, fairy?, short, tile, icon, rar }
function loginInfo(n) {
  const i = n % 7, w = Math.floor(n / 7) % LOGIN_WEEKS.length, rot = Math.floor(n / (7 * LOGIN_WEEKS.length)), W = LOGIN_WEEKS[w];
  const R = W.days[i], base = { day: i + 1, week: w };
  const stat = (s, v = 1) => ({ ...base, k: 'stat', s, v, short: `+${v} ${STAT_NAMES[s]}`, tile: `+${v} ${STAT_NAMES[s]}`, icon: statImg(s), rar: v > 1 ? 3 : 1 });
  const all = () => ({ ...base, k: 'all', short: '+1 ALL stats', tile: '+1 ALL STATS', icon: 'icons/relic_tome.webp', rar: 2 });
  if (R.k === 'stat') return stat(R.s);
  if (R.k === 'all') return all();
  if (R.k === 'top') { const s = topStat(); return { ...stat(s, R.v), k: 'top', short: `+${R.v} ${STAT_NAMES[s]} (your best stat)` }; }
  if (R.k === 'coins') { const v = Math.round(R.v * 1.5 ** rot / 10) * 10; return { ...base, k: 'coins', v, short: `start with ${v} coins`, tile: `● ${v}`, icon: iconURL('items', 0, 96), rar: 0 }; }
  if (R.k === 'el') {
    if (!lockedEls().length) return stat(W.theme); // all 8 unlocked: the week's theme stat
    const el = loginEl(n);
    return el ? { ...base, k: 'el', el, short: `unlock ${EL_GLYPH[el]} ${ELEMENTS[el].name} spells`, tile: ELEMENTS[el].name.toUpperCase(), icon: elemIcon(el), rar: 2 }
      : { ...base, k: 'el', short: 'unlock a new element', tile: 'NEW ELEMENT', icon: 'icons/menu_codex.webp', rar: 2 };
  }
  // fairy: one you don't have yet; all owned -> a level for one of yours; all maxed -> +1 all stats
  const own = meta.fairies || {}, fresh = Object.keys(FAIRY).filter((t) => !own[t]);
  if (fresh.length) return { ...base, k: 'fairy', fairy: fresh[0], short: 'a new fairy companion', tile: 'NEW FAIRY', icon: spriteURL(FAIRY[fresh[0]].sheet), rar: 3 };
  const t = fairyToLevel();
  return t ? { ...base, k: 'fairylv', fairy: t, short: `${FAIRY[t].name} fairy level up`, tile: 'FAIRY LV+', icon: spriteURL(FAIRY[t].sheet), rar: 2 } : all();
}
// "TOMORROW: Day 2 · +1 STR" (death/victory and pause screens), only once today's reward is claimed
function loginTease() {
  if (!meta.prologueDone || !loginClaimedToday()) return '';
  const nx = loginInfo(loginSt().n);
  return `<div class="lgTease"><span class="lgtI"><img src="${nx.icon}" alt=""></span><div><small>TOMORROW · DAY ${nx.day}</small><b>${nx.short}</b></div><em>Come back!</em></div>`;
}
function refreshTease() { const t = $('overTease'); if (t) t.innerHTML = loginTease(); }
function claimLogin() { // grant today's reward, then the chest show
  if (!loginReady()) return;
  const L = meta.login = { ...loginSt() }, inf = loginInfo(L.n);
  L.n++; L.day = localDay(); delete L.el;
  const addStat = (s, v) => { meta.loginStats = meta.loginStats || {}; meta.loginStats[s] = (meta.loginStats[s] || 0) + v; };
  const perm = { note: 'Permanent · every run' };
  let card;
  if (inf.k === 'stat' || inf.k === 'top') { addStat(inf.s, inf.v); card = { ...perm, name: `+${inf.v} ${STAT_NAMES[inf.s]}`, sub: `${STAT_NAMES[inf.s]} is now ${permStat(inf.s)}`, lines: [] }; }
  else if (inf.k === 'all') { for (const s of STATS) addStat(s, 1); card = { ...perm, name: '+1 ALL Stats', sub: STATS.map((s) => `${STAT_NAMES[s]} ${permStat(s)}`).join(' · '), lines: [] }; }
  else if (inf.k === 'coins') { meta.loginCoins = (meta.loginCoins || 0) + inf.v; card = { name: `${inf.v} Coins`, sub: 'Head start', lines: ['Your next run starts with them.'] }; }
  else if (inf.k === 'el') {
    const el = inf.el || pick(lockedEls()); meta.elements.push(el); toast(`${ELEMENTS[el].name.toUpperCase()} UNBOUND`, `${ELEMENTS[el].name} spells now appear in runs`);
    card = { ...perm, img: elemIcon(el), name: `${ELEMENTS[el].name} Unbound`, sub: 'New element', lines: [ELEMENTS[el].info] };
  } else if (inf.k === 'fairy') {
    const t = inf.fairy, F = FAIRY[t]; meta.fairies = meta.fairies || {}; meta.fairies[t] = 1; if (!meta.fairy) meta.fairy = t;
    card = { name: `${F.name} Fairy`, sub: 'New fairy companion', lines: [`${fairyPro(F)[1]} casts ${F.skill}. Equip fairies from the main menu.`] };
  } else { const t = inf.fairy, F = FAIRY[t]; meta.fairies[t]++; card = { name: `${F.name} Fairy`, sub: `LEVEL ${meta.fairies[t]}`, lines: [`${F.skill} hits harder and casts more often.`] }; }
  const nx = loginInfo(L.n); // pre-rolls tomorrow's element (if it is an element day) and saves
  saveMeta(); initAudio();
  chestReveal({ img: inf.icon, rar: inf.rar, ...card, label: `DAY ${inf.day} REWARD`, tag: `DAY ${inf.day}`, foot: `Tomorrow: Day ${nx.day} · ${nx.short}`, buttons: [{ x: 'ok', text: 'NICE' }],
    onPick: () => { refreshTease(); if (G.state === 'title') renderTitle(); } });
  refreshTease();
}
function loginPop() {
  if (!loginReady() || document.querySelector('.rw-overlay, #loginPop.show, #dailyPop.show')) return;
  if (G.state === 'title' ? $('title').classList.contains('hidden') : G.state !== 'dead' || $('over').classList.contains('hidden')) return;
  const L = loginSt(), today = L.n % 7, wk = Math.floor(L.n / 7), W = LOGIN_WEEKS[wk % LOGIN_WEEKS.length], rot = Math.floor(wk / LOGIN_WEEKS.length);
  let el = $('loginPop');
  if (!el) {
    el = document.createElement('div'); el.id = 'loginPop'; $('app').appendChild(el);
    el.addEventListener('pointerdown', (e) => e.stopPropagation());
    el.addEventListener('click', (e) => { const b = e.target.closest('[data-lg]'); if (!b) return; el.classList.remove('show'); sfx('tap'); claimLogin(); });
  }
  const tiles = W.days.map((_, k) => {
    const inf = loginInfo(wk * 7 + k), st = k < today ? 'got' : k === today ? 'now' : k === today + 1 ? 'next' : '';
    return `<div class="lgT ${st}${k === 6 ? ' big' : ''}" style="--c:${RARITY[inf.rar].color}"><small>DAY ${k + 1}</small><span class="lgI"><img src="${inf.icon}" alt=""></span>
      <b>${inf.tile}</b>${st === 'got' ? '<i class="lgChk">✓</i>' : ''}${st === 'next' ? '<em>TOMORROW</em>' : st === 'now' ? '<em>TODAY</em>' : ''}</div>`;
  }).join('');
  el.innerHTML = `<div class="lgbox"><i class="dpgem"></i><small class="lgK">WEEK ${wk % LOGIN_WEEKS.length + 1} · ${W.name}${rot ? ` · ROUND ${rot + 1}` : ''}</small><b class="lgH">Come back every day</b>
    <div class="lgGrid">${tiles}</div><p>Miss a day? No problem, you just pick up where you left off.</p>
    <div class="dpbtns"><button class="dpgo" data-lg="claim">CLAIM DAY ${today + 1}</button></div></div>`;
  el.classList.add('show'); sfx('card');
}
// ---------- Daily Chest: a free Lucky Chest on a per-player timer. A small chest with a timer stays in the run HUD ----------
// The first one unlocks after 10 minutes of play once the prologue is done (play time, kept in meta.chestPlay), then every
// 20 h after each claim (meta.chestNext, server ms). Server time: the Date header of our own file (plus Age, a CDN's copy
// can be hours old), device clock if that fails, so moving the phone's clock can't skip the wait.
let dailySkew = 0;
fetch('index.html?t=' + Date.now(), { method: 'HEAD', cache: 'no-store' }).then((r) => { if (params.has('dailyday')) return; const d = Date.parse(r.headers.get('date')); if (d) { const a = d - Date.now(), b = a + (+r.headers.get('age') || 0) * 1000; dailySkew = Math.abs(b) < Math.abs(a) ? b : a; /* Date alone or Date + Age, whichever is closer to the device clock: a CDN that already refreshes Date made Date + Age run hours ahead (user 11-17: a 35 h chest timer) */ } }).catch(() => {});
const DAY_MS = 86400000, dailyNow = () => Date.now() + dailySkew;
const dayKey = () => Math.floor(dailyNow() / DAY_MS);
const CHEST_FIRST = 600, CHEST_CD = 20 * 3600000;
if (meta.chestNext === undefined && meta.chestPlay === undefined) { // saves from before the per-player timer
  if (meta.prologueDone) meta.chestNext = meta.dailyDay != null ? (meta.dailyDay + 1) * DAY_MS : 0; // ready when the old daily reset would have been
  else meta.chestPlay = 0; // new player: the 10-minute first chest
  delete meta.dailyDay; saveMeta();
}
if (params.has('dailyreset') || params.has('qaTool')) meta.chestNext = 0; // testing: ?dailyreset and the CrazyGames QA preview get a fresh chest on every load
const chestSecs = () => { if (meta.chestNext !== undefined && meta.chestNext - dailyNow() > CHEST_CD) meta.chestNext = dailyNow() + CHEST_CD; /* never longer than one cooldown (heals a timer set with a wrong clock) */ return Math.max(0, meta.chestNext === undefined ? CHEST_FIRST - (meta.chestPlay || 0) : (meta.chestNext - dailyNow()) / 1000); };
const dailyReady = () => meta.chestNext !== undefined && dailyNow() >= meta.chestNext;
const dailyMins = () => Math.ceil((DAY_MS - dailyNow() % DAY_MS) / 60000); // the Daily Dungeon still turns over with the server day
const dailyLeft = () => { const m = dailyMins(); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
const chestLeft = () => { const s = Math.ceil(chestSecs()), m = Math.floor(s / 60); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}:${String(s % 60).padStart(2, '0')}`; };
let chestSaveT = 0;
let chestWallT = performance.now();
function tickChestPlay() { // time toward the first chest: real elapsed time after the prologue, focused or not
  // user (11-15): it only counted down while the game had focus / was on screen. Now the wall-clock time since the last tick
  // counts (background tabs throttle timers to 1/s or 1/min, so a fixed 0.5 per call lost time); capped so a sleeping laptop
  // doesn't jump it. Not gated on meta.prologueDone alone: a meta that lost that flag froze the chest at 10:00 (CrazyGames, Nov 2026)
  const now = performance.now(), dt = Math.min(120, Math.max(0, (now - chestWallT) / 1000)); chestWallT = now;
  if (meta.chestNext !== undefined || G.prologue || AUTO || (!meta.prologueDone && !player)) return;
  meta.chestPlay = (meta.chestPlay || 0) + dt;
  if (meta.chestPlay >= CHEST_FIRST) { meta.chestNext = 0; delete meta.chestPlay; saveMeta(); if (G.state === 'play') toast('FREE CHEST', 'Your free chest is ready!'); }
  else if ((chestSaveT += dt) >= 10) { chestSaveT = 0; saveMeta(); }
}
// the in-run HUD's left column under the menu button: the Daily Chest (timer plate / OPEN!), the character sheet button (+ when
// stat points wait) and the Daily Dungeon button. All hidden in the prologue, the teaser recorder (?auto) and outside a run.
function tickDaily() {
  tickChestPlay();
  const btn = $('dailyBtn'), off = AUTO || (G.state !== 'play' && G.state !== 'paused') || !!G.prologue || !player || $('hud').classList.contains('hidden');
  btn.classList.toggle('hidden', off); syncHudCol(off); if (off) return;
  const ready = dailyReady(), txt = ready ? 'OPEN!' : chestLeft(), lbl = btn.querySelector('span'), cost = btn.querySelector('em');
  btn.classList.toggle('ready', ready); if (lbl.textContent !== txt) lbl.textContent = txt;
  // one chest in the HUD (user): free when the timer is done, otherwise a Lucky Chest for coins (its price under the timer)
  const ct = ready || G.daily ? '' : `● ${luckyCost()}`; if (cost.textContent !== ct) cost.textContent = ct; cost.classList.toggle('short', !ready && G.coins < luckyCost());
  if (!btn.firstElementChild.getAttribute('src')) btn.firstElementChild.src = CHEST_IMG;
}
function syncHudCol(off) {
  const db = $('dlyBtn');
  if (!off && flushRunPts()) recalcStats(); // leftover run points (old save, Lucky Chest) go into the main stat
  const ib = $('invBtn'); ib.classList.toggle('hidden', off); // PROFILE: hero portrait; "!" only when gear in the bag can be equipped and wasn't seen yet
  if (!off) { const im = ib.firstElementChild, src = heroPortrait(player.hero); if (im.getAttribute('src') !== src) im.src = src;
    const sig = bagSig(); if (player.invSeen === undefined) player.invSeen = sig; ib.classList.toggle('pts', player.bag.length > 0 && sig !== player.invSeen); }
  const dOff = off || !!G.daily || !meta.prologueDone; db.classList.toggle('hidden', dOff); if (dOff) return;
  const src = spriteURL(dailyOf().fairy.sheet), im = db.firstElementChild;
  if (im.getAttribute('src') !== src) im.src = src;
  db.classList.toggle('done', dailyDoneToday()); db.classList.toggle('busy', G.state === 'play' && !runSafe());
}
// STATS and INVENTORY: the pause screen showing only that part of the build (the game is paused while it's open)
function openPanel(view) {
  if (G.state !== 'play') return; pauseGame(view);
  if (view === 'inv' && player) player.invSeen = bagSig();
}
const bagSig = () => player.bag.map((it) => it.name).join('|');
const heroPortrait = (h) => (h.id === 'wizard' ? 'portraits/pip.webp' : spriteURL(h.sprite)); // PROFILE button and panel
// Daily Dungeon from inside a run: only between fights. The run is saved (and kept in memory); when the daily ends its
// result screen offers BACK TO YOUR RUN, which puts Pip back on the same spot (continueRun). A reload falls back to CONTINUE.
function openDailyPop() {
  if (G.state !== 'play' || G.daily || G.prologue || !player || !player.alive) return;
  if (!runSafe()) { toast('DAILY DUNGEON', 'Clear the room first'); return; }
  G.state = 'paused';
  const D = dailyOf(), done = dailyDoneToday();
  let el = $('dailyPop');
  if (!el) {
    el = document.createElement('div'); el.id = 'dailyPop'; $('app').appendChild(el);
    el.addEventListener('pointerdown', (e) => e.stopPropagation());
    el.addEventListener('click', (e) => {
      if (performance.now() - (el.openT || 0) < 400) return; // the click of the same tap that opened it (touch): it landed on the backdrop and closed the popup at once
      const b = e.target.closest('[data-dp]'); if (!b && e.target.closest('.dpbox')) return;
      el.classList.remove('show');
      if (b && b.dataset.dp === 'go' && !dailyDoneToday()) enterDaily(); else if (G.state === 'paused') G.state = 'play';
    });
  }
  el.innerHTML = `<div class="dpbox"><i class="dpgem"></i><small>DAILY DUNGEON</small>
    <div class="dprow"><img src="${spriteURL(D.fairy.sheet)}" alt=""><div><b>${D.boss.name}</b><em>${D.mod.name} · ${D.mod.info}</em><span>${done ? 'Done today ✓' : dailyRewardText(D)}</span></div></div>
    <p>${done ? `Come back tomorrow · next in <i class="dleft">${dailyLeft()}</i>` : 'Your run is saved. When the daily ends, you come back right here.'}</p>
    <div class="dpbtns">${done ? '' : '<button class="dpgo" data-dp="go">ENTER DAILY</button>'}<button class="dpback" data-dp="back">BACK</button></div></div>`;
  el.classList.add('show'); el.openT = performance.now(); sfx('card');
}
function enterDaily() {
  G.dailyRet = JSON.stringify(runSnapshot()); checkpoint(); // in memory for the way back, and the normal save for CONTINUE
  startDaily();
}
function backToRun() {
  let s = null; try { s = JSON.parse(G.dailyRet); } catch (e) { /* none */ }
  G.dailyRet = null;
  const toMenu = () => { G.state = 'title'; $('hud').classList.add('hidden'); showScreen('title'); };
  if (!s) return toMenu();
  try { continueRun(s); } catch (err) { console.error(err); return toMenu(); }
  const p = s.player; // the exact spot, not just the room's safe spot
  if (p && p.x != null && cellAt(p.x, p.z) === FLOOR) { player.x = p.x; player.z = p.z; camTarget.set(p.x, 0, p.z); }
  // no banner here (user, 11-12: 'BACK TO FLOOR n' overlapped and wasn't needed: you land on the same spot)
}
{ const mk = (id, html, fn) => { const b = document.createElement('button'); b.id = id; b.className = 'hcol hidden'; b.innerHTML = html; $('left').appendChild(b);
    b.addEventListener('pointerdown', (e) => { e.stopPropagation(); fn(); }); return b; };
  // no STATS button any more (no run points to spend; stats show read-only in PROFILE, and the 'stats' view stays for Esc / the pause screen)
  mk('invBtn', '<img src="portraits/pip.webp" alt="" class="hport"><b class="plus">!</b>', () => openPanel('inv')).setAttribute('aria-label', 'Profile');
  mk('dlyBtn', '<img alt=""><b class="dplate">DAILY</b><i class="dmark"></i>', openDailyPop).setAttribute('aria-label', 'Daily Dungeon');
  } // left: menu, stats, inventory, daily · right (under the minimap): only the Daily Chest
{ const b = document.createElement('button'); b.id = 'dailyBtn'; b.className = 'hidden'; b.innerHTML = '<img alt=""><span></span><em></em>'; $('right').appendChild(b);
  b.addEventListener('pointerdown', (e) => { e.stopPropagation();
    if (!dailyReady()) { if (G.state !== 'play' || G.daily) return; G.state = 'paused'; G.luckyHold = true; // not ready: buy a Lucky Chest
      // short on coins: the notice (or the store sheet) is a promise; the run resumes when it closes, not before. A chest that opens
      // resumes the run from its own NICE button (openLuckyChest)
      Promise.resolve(openLuckyChest()).catch((err) => console.error(err)).finally(() => setTimeout(() => {
        if (G.luckyHold && !document.querySelector('.crev')) { G.luckyHold = false; if (G.state === 'paused') G.state = 'play'; } }, 60)); return; }
    if (G.state === 'play') { G.state = 'paused'; G.dailyHold = true; }
    openVChest(true).catch((err) => console.error(err)).finally(() => { const pop = document.querySelector('.rw-overlay'); if (!G.dailyHold || (pop && pop.offsetParent)) return; if (pop) pop.remove(); G.dailyHold = false; G.state = 'play'; toast('FREE CHEST', 'New gear in your Vault'); }); }); // the run waits behind the reward, and never stays stuck if that fails
  setInterval(tickDaily, 500); }
// ---------- Daily Dungeon: one short run a day (same server day as the chest), the same for everyone: 3 floors, then the
// day's boss with one modifier. Beat it once a day and that boss becomes your fairy. Unlimited tries; no run save (closing
// a daily just ends that attempt), so the normal run's CONTINUE is never touched.
const DAILY_FLOORS = 3;
const DAILY_MODS = [
  { id: 'rocks', name: 'ROCKFALL', info: 'Rocks fall in every fight' },
  { id: 'swarm', name: 'SWARM', info: '50% more monsters, a little weaker' },
  { id: 'glass', name: 'GLASS CANNON', info: '+50% damage, half your hearts' },
  { id: 'frenzy', name: 'FRENZY', info: 'Monsters 30% faster, you cast 30% faster' },
  { id: 'greed', name: 'GREED', info: 'Double coins, monsters 25% tougher' },
];
// boss -> fairy: a small copy that follows Pip and casts that boss's own attack (its boss spell) at your foes
const FAIRY = {
  golemboss: { sheet: 'stoneking', spell: 'boss.rocks', name: 'Stone King', skill: 'Rockfall' },
  eyeboss: { sheet: 'hollow', spell: 'boss.gaze', name: 'Hollow Eye', skill: 'Sweeping laser' },
  boss: { sheet: 'boss', spell: 'boss.gloop', name: 'King Gloop', skill: 'Leap-slam' },
  wraithboss: { sheet: 'wraith', spell: 'boss.souls', name: 'Wraith Queen', skill: 'Homing souls', she: true },
  tyrant: { sheet: 'tyrant', spell: 'boss.bones', name: 'Bone Tyrant', skill: 'Bone boomerang' },
  sporeboss: { sheet: 'sporemother', spell: 'boss.spores', name: 'Mother Spore', skill: 'Spore spiral', she: true },
  mimiclord: { sheet: 'mimiclord', spell: 'boss.coins', name: 'Mimic Lord', skill: 'Coin spray' },
  frostboss: { sheet: 'frostmatriarch', spell: 'boss.frost', name: 'Frost Matriarch', skill: 'Frost rings', she: true },
  sentinel: { sheet: 'sentinel', spell: 'boss.gears', name: 'Clockwork Sentinel', skill: 'Saw gears', it: true },
};
const fairyPro = (F) => (F.she ? ['her', 'She'] : F.it ? ['it', 'It'] : ['him', 'He']);
const DAILY_BOSS_MOD = { mimiclord: 'greed', frostboss: 'frenzy', sentinel: 'glass' }; // the newer bosses always bring their own
const FAIRY_MAX = 3;
if (params.get('dailyday')) dailySkew = (+params.get('dailyday') - Math.floor(Date.now() / DAY_MS)) * DAY_MS + 3600000; // testing: pretend it's that day
function dailyOf(day = dayKey()) {
  const boss = BOSSES[((day % BOSSES.length) + BOSSES.length) % BOSSES.length];
  const mod = DAILY_MODS.find((m) => m.id === DAILY_BOSS_MOD[boss.type]) || DAILY_MODS[(((day * 5 + 1) % 4) + 4) % 4]; // the first 4 rotate; greed is the Mimic Lord's
  return { day, boss, fairy: FAIRY[boss.type], mod, dungeon: BIOME_KEYS[(((day * 7 + 2) % BIOME_KEYS.length) + BIOME_KEYS.length) % BIOME_KEYS.length],
    seed: (Math.imul(day + 1, 2654435761) ^ 0x5bd1e995) | 0 };
}
const fairyCount = () => Object.keys(meta.fairies || {}).length;
function dailyRewardText(D) {
  const lv = (meta.fairies || {})[D.boss.type] || 0;
  return !lv ? `Defeat the ${D.fairy.name} → get ${fairyPro(D.fairy)[0]} as your fairy` : lv < FAIRY_MAX ? `Defeat the ${D.fairy.name} → fairy Lv ${lv + 1}` : `Defeat the ${D.fairy.name} → ◆ 500`;
}
const dailyDoneToday = () => meta.dailyDone === dayKey();
function startDaily() {
  if (whenArt(() => startDaily())) return;
  const D = dailyOf();
  initAudio(); for (const sId of screens) $(sId).classList.add('hidden');
  G.daily = D; G.dailyWon = null; G.runDungeon = D.dungeon; seed = D.seed;
  newGame();
  // head start (user, 11-12: a clean slate was too hard): everyone begins the Daily at level 5 with 4 level-up picks right away
  player.lv = 5; G.lvPicks = 4; G.lvPickT = 1.8;
  G.dailyHi = Math.random() < 0.1 ? 3 : 2; // the strong-spell budget: T2 + T3 at most 2 this run, 3 in ~10% of runs (see hiTierOk)
  G.dailyAwe = 'head'; // one awesome spell (DAILY_AWESOME) offered per Daily: the first head-start pick, else the first chest if the budget allows (user 11-17)
  banner('DAILY DUNGEON', `${D.mod.name} · ${D.mod.info.toUpperCase()}`);
}
// rocks from the ceiling in every fight (the ROCKFALL modifier): red circles, a beat to step out, then the hit
function dailyRocks(dt) {
  const r = rooms.find((q) => q.active); if (!r || G.state !== 'play' || !player.alive) { G.dRockT = 3; return; }
  if ((G.dRockT = (G.dRockT ?? 3) - dt) > 0) return;
  G.dRockT = rr(4.5, 6.5);
  for (let q = 0; q < 3; q++) {
    const x = clamp(player.x + (q ? rr(-2.4, 2.4) : player.vx * 0.25), r.x0 + 1.5, r.x0 + r.w + 0.5), z = clamp(player.z + (q ? rr(-2.4, 2.4) : player.vz * 0.25), r.z0 + 1.5, r.z0 + r.h + 0.5);
    const mk = addMarker(x, z, 0.95, 0xff3050); mk.material.depthTest = false; mk.renderOrder = 8;
    later(1.0, () => {
      scene.remove(mk); mk.material.dispose(); if (!player || !player.alive) return;
      chunk(x, 2.5, z, 0x8a96a0, 5, 3, 0.18); burst(x, 0.3, z, 0xc0c8d0, 6, 3, 0.4, 0.4); splat(x, z, 0x2a2a30, 0.9); addShake(0.12); sfx('rockfall');
      if (Math.hypot(player.x - x, player.z - z) < 0.9) damagePlayer(1, x, z);
      for (const o of enemies) if (!o.dead && !o.isBoss && Math.hypot(o.x - x, o.z - z) < 0.9) hurtEnemyRaw(o, 20, '#c0c8d0');
    });
  }
}
// the day's boss is down: the reward (once a day), then the run ends like a victory
function dailyWin() {
  if (G.state !== 'play') return;
  const D = G.daily, t = D.boss.type, first = meta.dailyDone !== D.day;
  meta.fairies = meta.fairies || {};
  let title = 'CLEARED AGAIN', info = `Today's reward is already yours. A new Daily Dungeon in ${dailyLeft()}.`;
  if (first) {
    const lv = meta.fairies[t] || 0; meta.dailyDone = D.day;
    if (!lv) { meta.fairies[t] = 1; if (!meta.fairy) meta.fairy = t; title = `${D.fairy.name.toUpperCase()} IS YOUR FAIRY`; info = `${fairyPro(D.fairy)[1]} follows you on every run and casts ${D.fairy.skill}. Equip fairies from the main menu.`; }
    else if (lv < FAIRY_MAX) { meta.fairies[t] = lv + 1; title = `${D.fairy.name.toUpperCase()} FAIRY · LV ${lv + 1}`; info = `${D.fairy.skill} hits harder and casts more often.`; }
    else { meta.shards += 500; title = '◆ 500 SOUL SHARDS'; info = `Your ${D.fairy.name} fairy is already at max level.`; }
    saveMeta();
  }
  G.state = 'won'; G.dailyWon = first ? 'reward' : 'again'; flash(0.8); sfx('clear'); addShake(0.6);
  $('cardsTitle').textContent = 'DAILY DUNGEON CLEARED';
  const row = $('cardRow'); row.innerHTML = '';
  const c = document.createElement('div'); c.className = 'card legend'; c.style.setProperty('--c', '#ffd34f');
  c.innerHTML = `<div class="ci fairyci" style="--img:url(${spriteURL(D.fairy.sheet)})"></div><div><div class="tag">${first ? 'DAILY REWARD' : 'DAILY DUNGEON'}</div><h3>${title}</h3><p>${info}</p></div>`;
  c.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); $('cards').classList.add('hidden'); G.state = 'play'; player.revive = 0; player.iframe = 0; player.hp = 0; playerDie(); });
  row.appendChild(c); $('cards').classList.remove('hidden');
  if (AUTO) later(1, () => c.dispatchEvent(new PointerEvent('pointerdown')));
}
// the title's Daily Dungeon card and the line on the death screen
function dailyCardHtml(over = false) {
  if (!meta.prologueDone) return '';
  const D = dailyOf(), done = dailyDoneToday();
  return `<div class="dcard${done ? ' done' : ''}${over ? ' over' : ''}" ${done ? '' : 'data-daily="1"'}>
    <img src="${spriteURL(D.fairy.sheet)}" alt=""><div><small>DAILY DUNGEON</small><b>${D.boss.name}</b>
    <em>${D.mod.name} · ${D.mod.info}</em>
    <span>${done ? `Done today ✓ · next in <i class="dleft">${dailyLeft()}</i>` : `${dailyRewardText(D)}`}</span></div>
    ${done ? '' : `<button data-daily="1">${over && G.daily ? 'RETRY' : 'ENTER'}</button>`}</div>`;
}
document.addEventListener('click', (e) => { if (!e.target.closest('[data-daily]') || dailyDoneToday()) return; startDaily(); });
setInterval(() => { for (const el of document.querySelectorAll('.dleft')) el.textContent = dailyLeft(); }, 30000);
// ---------- the fairy: follows Pip, bobbing at his shoulder, and casts its boss's attack at the nearest foe ----------
let fairy = null;
function killFairy() { if (fairy) { killMesh(fairy.mesh); killGlow(fairy.glow); fairy = null; } }
function spawnFairy() {
  killFairy();
  const t = meta.fairy, lv = (meta.fairies || {})[t] || 0, F = FAIRY[t];
  if (!F || !lv || G.prologue || !player || !sheets[F.sheet]) return;
  if (sheets[F.sheet].w <= 16) { later(1, () => { if (!fairy && player && meta.fairy === t) spawnFairy(); }); return; } // its art is still loading: the sprite's shape comes from it
  const def = spellDef(F.spell); if (!def) return;
  fairy = { t, F, lv, def, s: { id: F.spell, lv }, x: player.x - 0.8, z: player.z + 0.4, cd: 2, bob: 0, col: hexOf(def.color),
    shotT: 1, wind: 0, dart: 0, dx: 0, dz: 0, pose: 0, ptg: null,
    mesh: makeSprite(F.sheet, 0.62), glow: makeGlow(hexOf(def.color), 1.1, 0.45) }; // a bit smaller (user 11-15)
}
// The fairy keeps busy: every FAIRY_SHOT s a small shot in its colour (~15% of Pip's bolt, +25% per fairy level) after a
// short glowing wind-up, with a quick dart toward the foe and back. Its boss spell (every 5-10 s) gets a cast pose: it
// rises and swells, sparks are drawn in, then a white flash and a ring as the spell goes off.
const FAIRY_SHOT = 1.2, FAIRY_WIND = 0.22, FAIRY_DART = 0.3, FAIRY_POSE = 0.45;
const FAIRY_SPK = { s: 0.3, life: 0.2, drag: 0 }, FAIRY_PULL = { s: 0.35, life: 0.22, drag: 0 };
function updateFairy(dt) {
  if (!fairy || !player) return;
  const f = fairy, alive = player.alive && !G.prologue;
  f.mesh.visible = alive; f.glow.visible = alive; if (!alive) return;
  const tx = player.x - player.face * 1.05, tz = player.z - 0.45; // up behind Pip's shoulder, away from the camera so it never covers him
  const k = 1 - Math.exp(-dt * 4); f.x += (tx - f.x) * k; f.z += (tz - f.z) * k;
  f.bob += dt;
  // the dart: out toward the foe and back (sin bump) on top of the follow position
  const dk = f.dart > 0 ? Math.sin((1 - f.dart / FAIRY_DART) * Math.PI) : 0; if (f.dart > 0) f.dart -= dt;
  const pk = f.pose > 0 ? 1 - f.pose / FAIRY_POSE : 0; // the cast pose: 0 -> 1
  const x = f.x + f.dx * dk, z = f.z + f.dz * dk, y = 1.0 + Math.sin(f.bob * 2.4) * 0.12 + pk * 0.4;
  const sc = 1 + pk * 0.3 + (f.wind > 0 ? 0.1 * (1 - f.wind / FAIRY_WIND) : 0);
  f.mesh.position.set(x, y, z); billboard(f.mesh, Math.sin(f.bob * 1.7) * 0.06 + (f.pose > 0 ? Math.sin(G.time * 30) * 0.05 : 0));
  setSpriteScale(f.mesh, sc, sc);
  const u = f.mesh.material.uniforms;
  u.uFlip.value = player.face < 0 ? 1 : 0;
  u.uFlash.value = Math.max(f.flash || 0, pk * 0.6, f.wind > 0 ? 0.35 * (1 - f.wind / FAIRY_WIND) : 0); u.uFlashCol.value.set(f.flash > 0.01 ? 0xffffff : f.col);
  if (f.flash > 0) f.flash -= dt * 3;
  f.glow.position.set(x, y + 0.45, z); f.glow.scale.setScalar(1.4 * (1 + pk * 0.8 + (f.wind > 0 ? 0.4 : 0)));
  if (G.state !== 'play' || player.drop > 0) return;
  // the big one: pose, then cast from the fairy
  if (f.pose > 0) {
    f.pose -= dt;
    if (fxP(0.6)) { const a = Math.random() * 6.283; spark(x + Math.cos(a) * 0.9, y + 0.4 + Math.sin(a) * 0.5, z, f.col, { ...FAIRY_PULL, vx: -Math.cos(a) * 4, vy: -Math.sin(a) * 2.2 }); }
    if (f.pose > 0) return;
    const target = f.ptg && !f.ptg.dead ? f.ptg : nearestEnemy(x, z, f.def.range); f.ptg = null;
    if (!target) { f.cd = 0.3; return; }
    // the boss spell casts from the fairy: its origin is borrowed for the call (rays and spirals then follow Pip)
    const px = player.x, pz = player.z, a = Math.atan2(target.z - z, target.x - x);
    player.x = x; player.z = z;
    try { castBossSpell(f.s, f.def, target, x, z, y + 0.4, a, f.col); } finally { player.x = px; player.z = pz; }
    spark(x, y + 0.4, z, 0xffffff, { s: 1.6, life: 0.16, drag: 0 }); burst(x, y + 0.4, z, f.col, 14, 4, 0.35, 0.4);
    addRing(x, z, 0.2, 1.6, 0.35, f.col); f.flash = 1; f.casts = (f.casts || 0) + 1;
    f.cd = f.def.cd * 1.6 * (1 - 0.15 * (f.lv - 1)) * player.cdMul;
    return;
  }
  // small shots: wind-up glow, then a dart and a shot
  if (f.wind > 0) {
    f.wind -= dt;
    if (fxP(0.5)) spark(x + rr(-0.25, 0.25), y + 0.4, z, f.col, FAIRY_SPK);
    if (f.wind <= 0) {
      const tg = nearestEnemy(x, z, 7);
      if (tg) {
        const a = Math.atan2(tg.z - z, tg.x - x), dmg = 10 * 0.15 * (1 + 0.25 * (f.lv - 1));
        addProj({ kind: 'orb', x, z, y: y + 0.35, a, speed: 13, dmg, r: 0.2, color: f.col, size: 0.45, scale: 0.55, homing: 7, target: tg, life: 0.9, els: f.def.els });
        f.dart = FAIRY_DART; f.dx = Math.cos(a) * 0.55; f.dz = Math.sin(a) * 0.55;
        spark(x, y + 0.4, z, 0xffffff, { s: 0.6, life: 0.08, drag: 0 });
      }
    }
  } else if ((f.shotT -= dt) <= 0) { f.shotT = FAIRY_SHOT; if (nearestEnemy(x, z, 7)) f.wind = FAIRY_WIND; }
  if ((f.cd -= dt) > 0) return;
  const target = nearestEnemy(x, z, f.def.range);
  if (!target) { f.cd = 0.3; return; }
  f.pose = FAIRY_POSE; f.ptg = target; f.wind = 0; sfx('whoosh');
}
// ---------- fairy collection (main menu) ----------
function renderFairies() {
  const own = meta.fairies || {};
  $('fairyList').innerHTML = BOSSES.map((b) => {
    const F = FAIRY[b.type], lv = own[b.type] || 0, cur = meta.fairy === b.type;
    return lv ? `<button class="fy${cur ? ' cur' : ''}" data-fairy="${b.type}"><img src="${spriteURL(F.sheet)}" alt=""><b>${F.name}</b><small>${F.skill} · Lv ${lv}/${FAIRY_MAX}</small><em>${cur ? 'EQUIPPED' : 'EQUIP'}</em></button>`
      : `<div class="fy off"><img src="${spriteURL(F.sheet)}" alt=""><b>???</b><small>Beat ${b.name.toLowerCase()} in the Daily Dungeon</small></div>`;
  }).join('');
  $('fairyCount').textContent = `${fairyCount()} / ${BOSSES.length} FOUND`;
}
$('fairyList').addEventListener('click', (e) => { const b = e.target.closest('[data-fairy]'); if (!b) return; meta.fairy = meta.fairy === b.dataset.fairy ? null : b.dataset.fairy; saveMeta(); sfx('buy'); renderFairies(); });
$('btnFairies').addEventListener('click', () => showScreen('fairies'));
// short on shards: go straight to buying a shard pack (the Mega Deal, or the smallest pack that covers the gap)
async function needShards(cost) {
  if (!Monet.iapEnabled) { Monet.notice('Not enough soul shards', `You need ◆ ${cost - meta.shards} more. Earn them on your runs.`); return; }
  const short = cost - meta.shards, packs = PRODUCTS.filter((x) => x.shards).sort((a, b) => a.shards - b.shards);
  const deal = packs.find((x) => x.deal);
  const prod = deal.shards >= short ? deal : packs.find((x) => x.shards >= short) || packs[packs.length - 1];
  initAudio();
  const got = await Monet.buy(prod.sku);
  if (got) { grantProduct(got); toast('PURCHASED', got.name); }
  if (!$('sanctum').classList.contains('hidden')) renderSanctum();
  if (!$('over').classList.contains('hidden') && $('overUps')) $('overUps').innerHTML = overUpgrades();
  renderTitle(); renderVChest('overChest');
}
// a purchase that finished while the app was closed (or the store answered late) is delivered when Play reports it
Monet.onGrant = (prod) => {
  grantProduct(prod); toast('PURCHASE DELIVERED', prod.name);
  renderTitle(); renderVChest('overChest'); if (!$('sanctum').classList.contains('hidden')) renderSanctum();
};
setTimeout(() => Monet.init(), 3000); // connect to Google Play Billing after the first frames, not during boot
function grantProduct(prod) {
  if (prod.shards) meta.shards += prod.shards;
  if (prod.sku === 'starter_pack') { meta.shards += 1000; const it = rollGear(Math.random, 20, 0, 3); if (!meta.vault[it.slot]) meta.vault[it.slot] = it; else meta.stash.push(it); }
  saveMeta(); sfx('clear');
}
function renderStore() {
  const free = Monet.dailyLeft('free_shards', 3);
  $('storeList').innerHTML = `<p class="beast">${Monet.mode === 'test' ? 'TEST MODE: no real money or ads on the web link.' : Monet.mode === 'web' ? 'WEB VERSION: no ads, everything is free.' : ''}</p>
    ${(Monet.iapEnabled ? [...PRODUCTS] : []).sort((a, b) => (b.deal ? 2 : b.sku === 'remove_ads' ? 1 : 0) - (a.deal ? 2 : a.sku === 'remove_ads' ? 1 : 0)).map((p) => { const owned = p.once && Monet.owns(p.sku);
      return `<button class="sitem${p.deal ? ' best' : ''}${p.sku === 'remove_ads' ? ' noads' : ''}" data-sku="${p.sku}" ${owned ? 'disabled' : ''}><b>${p.name}${p.deal ? ' <i>BEST DEAL</i>' : ''}${p.sku === 'remove_ads' && !owned ? ' <i class="pop">POPULAR</i>' : ''}</b><small>${p.info}</small><em>${owned ? 'OWNED' : p.price}</em></button>`; }).join('')}
    <button class="sitem free" data-free="1" ${free > 0 ? '' : 'disabled'}><b>Free soul shards</b><small>${Monet.mode === 'web' ? 'Claim' : 'Watch an ad for'} ◆ 100 · ${free} left today</small><em>${adsOn() ? '▶ ' : ''}FREE</em></button>
    ${Monet.canRestore ? '<button class="sitem" data-restore="1"><b>Restore purchases</b><small>Get back Remove Ads and the Starter Pack</small><em>↺</em></button>' : ''}`;
}
async function storeClick(e) {
  const f = e.target.closest('[data-free]'), b = e.target.closest('[data-sku]');
  if (e.target.closest('[data-restore]')) { await Monet.restore(); renderSanctum(); return; }
  if (f && !f.disabled) { if (await Monet.rewarded('free_shards')) { Monet.useDaily('free_shards'); meta.shards += 100; saveMeta(); sfx('coin', 10); renderSanctum(); } return; }
  if (!b || b.disabled) return;
  const prod = await Monet.buy(b.dataset.sku); if (!prod) return;
  grantProduct(prod); renderSanctum(); toast('PURCHASED', prod.name);
}
// permanent stat points bought with shards; each point in a stat costs more than the last
const statCost = (k) => 100 + 50 * ((meta.statBuy || {})[k] || 0);
function permStat(k) {
  const H = HEROES.wizard, mainStat = { mage: 'int', archer: 'dex', warrior: 'str', hunter: 'str' }[H.cls];
  return (H.base[k] || 0) + ((meta.statBuy || {})[k] || 0) + ((meta.loginStats || {})[k] || 0) + 2 * (meta.winStats || 0) + (k === mainStat ? meta.legacy || 0 : 0) + (k === 'vit' ? Math.floor((meta.legacy || 0) / 3) : 0);
}
function renderCharStats() {
  const cls = HEROES.wizard.cls;
  $('charStats').innerHTML = `<div class="invlabel">PERMANENT STATS</div><p class="cshint">Upgrade with ◆ shards · every run starts with these, level-ups add on top</p><div class="bstats">${STATS.map((k) => {
    const c = statCost(k), v = permStat(k), nx = MILESTONES[k].find(([m]) => m > v);
    return `<div class="bstat"><div><b>${STAT_NAMES[k]}</b><em>${v}</em></div><small>${statInfo(cls, k)}</small><small class="sms">${nx ? `<u>${nx[0]}:</u> ${nx[1]}` : 'all milestones reached'}</small>
      <button class="buy${meta.shards < c ? ' short' : ''}" data-buystat="${k}">+<span>◆${c}</span></button></div>`; }).join('')}</div>`;
}
function renderVault() {
  const tile = (it, attr, sel, slot) => it
    ? `<button class="vt${sel ? ' sel' : ''}" ${attr} style="--c:${RARITY[it.rarity].color};--img:url(${gearIcon(it)})"><i></i></button>`
    : `<button class="vt empty" ${attr} style="--img:url(${iconURL('gear', SLOTS.indexOf(slot))})"><i></i><small>${SLOT_NAMES[slot]}</small></button>`;
  const slots = paperDoll(meta.vault, (k) => `data-vslot="${k}"`, vaultSel && vaultSel.from === 'slot' ? vaultSel.key : null);
  const stash = meta.stash.map((it, i) => tile(it, `data-vstash="${i}"`, vaultSel && vaultSel.from === 'stash' && vaultSel.key === i)).join('');
  const empties = (6 - (meta.stash.length % 6)) % 6 + (meta.stash.length < 12 ? 12 - meta.stash.length - ((6 - (meta.stash.length % 6)) % 6) : 0);
  let detail = '<p class="beast">Tap an item.</p>';
  const it = vaultSel && (vaultSel.from === 'slot' ? meta.vault[vaultSel.key] : meta.stash[vaultSel.key]);
  if (it) {
    const cur = vaultSel.from === 'stash' ? meta.vault[it.slot] : null;
    detail = `<div class="vdet" style="--c:${RARITY[it.rarity].color}"><b>${it.name}</b><small>${RARITY[it.rarity].name} ${SLOT_NAMES[it.slot]}</small><p>${gearLines(it).join('<br>')}</p>
      ${cur ? `<small>Replaces ${cur.name}</small>` : ''}
      <div class="vbtns">${vaultSel.from === 'stash' ? '<button data-vact="equip">EQUIP</button>' : '<button data-vact="unequip">UNEQUIP</button>'}<button data-vact="discard">DISCARD</button></div></div>`;
  }
  $('vaultList').innerHTML = `<div class="invframe">${slots}
    <div class="invlabel">STORAGE · ${meta.stash.length} · tap to wear</div>
    <div class="vgrid inv">${stash}${'<div class="vt void"></div>'.repeat(empties)}</div></div>${detail}`;
}
$('vaultList').addEventListener('click', (e) => {
  const t = e.target.closest('[data-vslot],[data-vstash],[data-vact]'); if (!t) return;
  if (t.dataset.vslot) vaultSel = meta.vault[t.dataset.vslot] ? { from: 'slot', key: t.dataset.vslot } : null;
  else if (t.dataset.vstash !== undefined) vaultSel = { from: 'stash', key: +t.dataset.vstash };
  else if (vaultSel) {
    const a = t.dataset.vact;
    if (a === 'equip') { const it = meta.stash.splice(vaultSel.key, 1)[0], old = meta.vault[it.slot]; meta.vault[it.slot] = it; if (old) meta.stash.push(old); vaultSel = { from: 'slot', key: it.slot }; }
    if (a === 'unequip') { meta.stash.push(meta.vault[vaultSel.key]); delete meta.vault[vaultSel.key]; vaultSel = null; }
    if (a === 'discard') { if (vaultSel.from === 'slot') delete meta.vault[vaultSel.key]; else meta.stash.splice(vaultSel.key, 1); vaultSel = null; sfx('pot'); }
    saveMeta();
  }
  initAudio(); renderVault();
});
function renderRecords() {
  const st = meta.stats;
  $('records').innerHTML = [['Runs', st.runs], ['Victories', meta.wins || 0], ['Best floor', `${st.bestFloor} / ${WIN_FLOOR}`], ['Legacy level', meta.legacy || 0], ['Bosses slain', st.bosses], ['Foes slain', fmtNum(st.kills)], ['Spells found', `${meta.codex.length}/${TOTAL_SPELLS}`]]
    .map(([k, v]) => `<span>${k}</span><b>${v}</b>`).join('');
}
function renderCodex() {
  renderRecords();
  const codex = new Set(meta.codex);
  const found = meta.codex.filter((id) => ALL_SPELL_SET.has(id)).length; // only today's spells count (old ids were migrated on load)
  $('codexCount').innerHTML = `<b>${found}</b> / ${TOTAL_SPELLS} spells discovered`;
  const canStart = (d) => d && !d.fused && !d.legendary && !d.unique && d.els.every((e) => meta.elements.includes(e));
  const tile = (id) => { const d = spellDef(id); return codex.has(id) ? `<div class="got${meta.start === id ? ' start' : ''}" data-cx="${id}" title="${d.name}" style="--c:${d.color};--img:url(${spellIcon(d)})"></div>` : `<div class="unk" data-unk="${id}">?</div>`; };
  const sd = spellDef(meta.start);
  $('codexCount').innerHTML += `<br><span class="beast">Starting spell: <b style="color:${sd ? sd.color : '#fff'}">${sd ? sd.name : '-'}</b> · tap a spell you found to start with it</span><div id="cxDetail"></div>`;
  let html = '';
  for (const el of ELEMENT_ORDER) { // 3 signature spells per element
    const E = ELEMENTS[el], ids = SIG_IDS.filter((id) => SIGNATURE[id].el === el && !CUT_IDS.has(id)), n = ids.filter((id) => codex.has(id)).length;
    html += `<h3><span class="elchip${meta.elements.includes(el) ? '' : ' off'}" style="--c:${E.color};--img:url(${elemIcon(el)})"><i></i>${E.name}</span> ${n}/${ids.length} · ${E.info}</h3>`;
    html += `<div class="cgrid">${ids.map(tile).join('')}</div>`;
  }
  const fused = meta.codex.filter((id) => spellDef(id) && spellDef(id).fused);
  if (FUSION_IDS.length) html += `<h3>Fusions ${fused.filter((id) => ALL_SPELL_SET.has(id)).length}/${FUSION_IDS.length}</h3><div class="cgrid">${fused.map(tile).join('') || ''}</div>`; // no Fusions section while fusions are off
  if (!fused.length) html += '<p class="beast">Fuse two level-3 spells of different elements in a run.</p>';
  html += `<h3>Boss spells</h3><div class="cgrid">${Object.keys(BOSS_SPELLS).map(tile).join('')}</div>`;
  html += `<h3>Legendary</h3><div class="cgrid">${Object.keys(LEGENDARY).map(tile).join('')}</div>`;
  html += `<h3>Unique</h3><div class="cgrid">${Object.keys(UNIQUE_SPELLS).map(tile).join('')}</div>`;
  html += '<h3>Bestiary</h3>';
  const nameOf = { slime: 'Slime', big: 'Big slime', eye: 'Eye bat', imp: 'Shadow imp', skeleton: 'Skeleton', bomber: 'Bomber', ghost: 'Ghost', shroom: 'Mushroom', golem: 'Golem', mimic: 'Mimic',
    cursed: 'Cursed warrior', reaper: 'Grave reaper', boneknight: 'Bone knight', runegolem: 'Rune golem', crystalgolem: 'Crystal ruin golem', magmagolem: 'Obsidian magma golem',
    archer: 'Skeleton archer', spider: 'Crystal spider', salamander: 'Fire salamander', shieldk: 'Shield knight', cultist: 'Cultist caster', beetle: 'Rust beetle',
    boss: 'King Gloop', tyrant: 'Bone Tyrant', eyeboss: 'Hollow Eye', sporeboss: 'Mother Spore', golemboss: 'Stone King', wraithboss: 'Wraith Queen', mimiclord: 'Mimic Lord', frostboss: 'Frost Matriarch', sentinel: 'Clockwork Sentinel' };
  for (const [type, r] of Object.entries(RES)) {
    const weak = Object.entries(r).filter(([, v]) => v > 1).map(([k]) => ELEMENTS[k].name), res = Object.entries(r).filter(([, v]) => v < 1).map(([k, v]) => ELEMENTS[k].name + (v === 0 ? ' (immune)' : ''));
    html += `<p class="beast"><b>${nameOf[type] || type}</b>${UNDEAD.has(type) ? ' · undead' : ''} — ${weak.length ? `<span class="w">weak: ${weak.join(', ')}</span>` : ''}${weak.length && res.length ? ' · ' : ''}${res.length ? `<span class="r">resists: ${res.join(', ')}</span>` : ''}</p>`;
  }
  $('codexBody').innerHTML = html;
  $('codexBody').onclick = (e) => {
    const u = e.target.closest('[data-unk]');
    if (u) { // a locked tile still answers the tap: say how to find it, without giving the spell away
      const d = spellDef(u.dataset.unk), how = !d ? 'Keep diving to find it.' : BOSS_SPELLS[d.id] ? 'Beat the boss that wields it.' : d.legendary ? 'A legendary spell from the deepest floors.' : d.unique ? 'A unique spell: it turns up as a level-up pick.'
        : `Find it as a level-up pick in a run${meta.elements.includes(d.els[0]) ? '' : ` once ${ELEMENTS[d.els[0]].name} is unlocked`}.`;
      $('cxDetail').innerHTML = `<div class="vdet" style="--c:#8a7fb8"><button class="cxclose" data-cxclose="1">✕</button><b>Undiscovered spell</b><p>${how}</p></div>`;
      $('cxDetail').classList.add('open'); return;
    }
    const t = e.target.closest('[data-cx]'); if (!t) return;
    const d = spellDef(t.dataset.cx), ok = canStart(d);
    $('cxDetail').innerHTML = `<div class="vdet" style="--c:${d.color}"><button class="cxclose" data-cxclose="1">✕</button><b>${d.name}</b><small>${d.els.map((x) => ELEMENTS[x].name).join(' + ')} · ${d.kills ? 'charged by kills' : d.cd + 's'}</small><p>${d.info}</p>
      ${ok ? `<div class="vbtns"><button data-start="${d.id}">${meta.start === d.id ? 'STARTING SPELL ✓' : 'START WITH THIS'}</button></div>` : `<small>${d.fused || d.legendary || d.unique ? 'Fusions, legendaries and unique spells cannot be starting spells.' : `Unlock ${d.els.filter((x) => !meta.elements.includes(x)).map((x) => ELEMENTS[x].name).join(' and ')} by beating its boss to start with this.`}</small>`}</div>`;
    $('cxDetail').classList.add('open'); // a sheet over the bottom of the screen: the list stays where you scrolled it
  };
  $('codexCount').onclick = (e) => { if (e.target.closest('[data-cxclose]')) { $('cxDetail').classList.remove('open'); return; } const b = e.target.closest('[data-start]'); if (!b) return; meta.start = b.dataset.start; saveMeta(); renderCodex(); };
}
function renderStats() {
  const st = meta.stats;
  const rows = [['Runs', st.runs], ['Best floor', st.bestFloor], ['Foes slain', fmtNum(st.kills)], ['Bosses slain', st.bosses], ['Champions slain', st.champs],
    ['Damage dealt', fmtNum(st.dmg)], ['Best combo', st.bestCombo + 'x'], ['Coins found', fmtNum(st.coins)], ['Time in the depths', fmtTime(st.time)], ['Shards earned', fmtNum(st.shardsTotal)]];
  $('statList').innerHTML = rows.map(([k, v]) => `<span>${k}</span><b>${v}</b>`).join('');
}
$('sanctum').addEventListener('click', (e) => {
  const bs = e.target.closest('[data-buystat]');
  if (bs) { if (bs.disabled) return; const k = bs.dataset.buystat, c = statCost(k); if (meta.shards < c) return needShards(c); meta.shards -= c; meta.statBuy = meta.statBuy || {}; meta.statBuy[k] = (meta.statBuy[k] || 0) + 1; saveMeta(); initAudio(); sfx('buy'); renderSanctum(); return; }
  if (e.target.closest('#storeList')) { storeClick(e); return; }
  const tb = e.target.closest('.tabs button');
  if (tb) { for (const b of document.querySelectorAll('.tabs button')) b.classList.toggle('on', b === tb); for (const d of document.querySelectorAll('#sanctum .tab')) d.classList.toggle('hidden', d.dataset.tab !== tb.dataset.tab); $('sanctum').scrollTop = 0; return; }
  const b = e.target.closest('button'); if (!b || b.disabled) return;
  if (b.dataset.up) { const u = UPGRADES.find((x) => x.id === b.dataset.up), l = mlv(u.id); if (l < u.max && meta.shards < u.cost[l]) return needShards(u.cost[l]); if (l < u.max && meta.shards >= u.cost[l]) { meta.shards -= u.cost[l]; meta.up[u.id] = l + 1; saveMeta(); initAudio(); sfx('buy'); } }
  if (b.dataset.sp) { meta.start = b.dataset.sp; saveMeta(); }
  if (b.dataset.hero) {
    const h = b.dataset.hero;
    if (!meta.heroes.includes(h) && meta.shards >= HEROES[h].cost) { meta.shards -= HEROES[h].cost; meta.heroes.push(h); }
    if (meta.heroes.includes(h)) meta.hero = h;
    saveMeta(); initAudio(); sfx('card');
  }
  renderSanctum();
});
function renderDungeons() {
  $('dungeonList').innerHTML = BIOME_KEYS.map((k) => {
    const [name, desc] = DUNGEON_INFO[k], cur = meta.dungeon === k, img = ICONS.has('dungeon_' + k) ? `icons/dungeon_${k}.webp` : '';
    const B = BIOMES[k], c = '#' + new THREE.Color(B.wall).getHexString(), f = '#' + new THREE.Color(B.fog).getHexString();
    return `<button class="dng${cur ? ' cur' : ''}" data-dng="${k}" style="--c:${c};background:${img ? `url(${img}) center/cover` : `linear-gradient(135deg, ${c}, ${f})`}">
      <span><b>${name}</b><small>${desc}</small></span></button>`;
  }).join('');
}
$('dungeonList').addEventListener('click', (e) => {
  const b = e.target.closest('[data-dng]'); if (!b) return;
  meta.dungeon = b.dataset.dng; saveMeta(); startRun();
});
// every run rolls a dungeon (never the same twice in a row) and shows you where you are going
function rollAndRevealDungeon() {
  const opts = BIOME_KEYS.filter((k) => k !== meta.lastDungeon);
  G.runDungeon = AUTO ? (meta.lastDungeon || 'crypt') : opts[Math.floor(Math.random() * opts.length)];
  meta.lastDungeon = G.runDungeon; saveMeta();
  const [name, desc] = DUNGEON_INFO[G.runDungeon], img = ICONS.has('dungeon_' + G.runDungeon) ? `icons/dungeon_${G.runDungeon}.webp` : '';
  const el = $('reveal');
  const kept = SLOTS.map((k) => meta.vault[k]).filter(Boolean);
  const carry = kept.length ? `<div class="carry"><p class="beast">YOU CARRY</p><div>${kept.map((it) => `<span title="${it.name}" style="--c:${RARITY[it.rarity].color};--img:url(${gearIcon(it)})"><i></i><b>${it.name}</b></span>`).join('')}</div></div>` : '';
  el.innerHTML = `<p class="beast">YOU DESCEND INTO</p>${img ? `<img src="${img}" alt="">` : ''}<h1>${name}</h1><p class="sub">${desc}</p>${carry}`;
  for (const sId of screens) $(sId).classList.add('hidden');
  el.classList.remove('hidden'); initAudio(); sfx('stairs');
  setTimeout(() => { el.classList.add('hidden'); startRun(); }, kept.length ? 3200 : 2200);
}
$('btnPlay').addEventListener('click', () => { const sv = loadRun(); if (sv) confirmNewRun(sv.floor); else rollAndRevealDungeon(); });
$('btnContinue').addEventListener('click', () => { const sv = loadRun(); if (sv) continueRun(sv); else renderTitle(); });
function confirmNewRun(floor) {
  Monet.ask('Start a new run?', `Your saved run on Floor ${floor} will be lost.`, 'START NEW RUN', 'KEEP IT').then((yes) => { if (yes) { clearRun(); rollAndRevealDungeon(); } });
}
$('shardBal').addEventListener('click', () => { const t = document.querySelector('.tabs [data-tab=store]'); if (t) t.click(); }); // tap the balance to open the store
document.addEventListener('click', (e) => { const b = e.target.closest('[data-vchest]'); if (b) openVChest(b.dataset.vchest === 'daily'); });
$('btnAgain').addEventListener('click', () => {
  if (G.deadT < 1) return;
  if (keepFirst(() => $('btnAgain').click())) return;
  if ($('btnAgain').classList.contains('locked')) { const v = document.querySelector('.vault.keep'); if (v && !G.kept) { keepModal(true); return; } if (v) { v.classList.remove('nudge'); void v.offsetWidth; v.classList.add('nudge'); v.scrollIntoView({ block: 'center', behavior: 'smooth' }); } return; }
  if (G.daily && G.dailyRet) return backToRun();
  G.runsSinceAd = (G.runsSinceAd || 0) + 1;
  if (G.runsSinceAd >= 2 && !AUTO) { G.runsSinceAd = 0; Monet.interstitial('between_runs').then(rollAndRevealDungeon); return; }
  rollAndRevealDungeon();
});
$('overStats').addEventListener('click', async (e) => {
  if (e.target.closest('#adRevive')) { await reviveNow(); return; }
  const dbl = e.target.closest('#adDouble');
  if (dbl && !dbl.disabled) {
    if (!(await Monet.rewarded('double_shards'))) return;
    const t = +dbl.dataset.total; meta.shards += t; meta.stats.shardsTotal += t; saveMeta(); sfx('clear');
    dbl.disabled = true; dbl.textContent = `+${t} SHARDS ADDED`; $('shardCount').textContent = String(t * 2);
    $('overUps').innerHTML = overUpgrades(); return;
  }
  const b = e.target.closest('[data-buyup]'); if (!b || b.disabled) return;
  const u = UPGRADES.find((x) => x.id === b.dataset.buyup), l = mlv(u.id);
  if (l < u.max && meta.shards < u.cost[l]) return needShards(u.cost[l]);
  if (l < u.max && meta.shards >= u.cost[l]) { meta.shards -= u.cost[l]; meta.up[u.id] = l + 1; saveMeta(); sfx('buy'); $('overUps').innerHTML = overUpgrades(); }
});
// the death screen's first question (user): revive here, or end the run (-> keep one item -> results)
function reviveAsk() {
  const v = document.createElement('div'); v.id = 'reviveVeil';
  v.innerHTML = `<div class="rvBox"><span>✦ SECOND CHANCE ✦</span><small>${adsOn() ? 'Watch an ad to get' : 'Get'} back up with full health and keep this run going.</small><button class="rwbtn big" id="adRevive">${adsOn() ? '▶ WATCH AD · REVIVE' : '✦ REVIVE · FULL HEALTH'}</button><button class="rvNo">No thanks · end the run</button></div>`;
  v.addEventListener('click', async (e) => {
    if (e.target.closest('#adRevive')) { await reviveNow(); return; }
    if (e.target.closest('.rvNo')) { v.remove(); if (vaultChoices.length && !G.kept) keepModal(true, true); }
  });
  $('over').appendChild(v);
}
async function reviveNow() {
  {
    if (!(await Monet.rewarded('revive'))) return;
    { const rv = $('reviveVeil'); if (rv) rv.remove(); }
    G.run.adRevive = true; lastRun = G.deadRun; storeRun(); G.saveDue = true;
    { // the run isn't over after all: take back what the death screen paid out (it is paid again at the real end)
      const d = G.deathDelta || {}, st = meta.stats;
      meta.shards = Math.max(0, meta.shards - (d.total || 0)); st.shardsTotal -= d.total || 0; st.runs--;
      st.kills -= d.kills || 0; st.bosses -= d.bosses || 0; st.champs -= d.champs || 0; st.coins -= d.coins || 0; st.time -= d.time || 0; st.dmg -= d.dmg || 0;
      meta.legacyXp = Math.max(0, (meta.legacyXp || 0) - (d.lgGain || 0)); saveMeta();
    }
    showScreen(null); $('hud').classList.remove('hidden'); G.state = 'play';
    player.alive = true; player.hp = player.maxHp; player.iframe = 3; player.mesh.visible = player.shadow.visible = player.staffGlow.visible = true;
    renderHearts(); flash(0.6); sfx('heal'); explode({ x: player.x, z: player.z, aoe: 3.5, dmg: 80 }); toast('REVIVED', 'back in the fight');
    return;
  }
}
// the shard shop, right on the death screen: what you can afford first, then what is next
function overUpgrades() {
  const list = UPGRADES.filter((u) => mlv(u.id) < u.max).map((u) => ({ u, cost: u.cost[mlv(u.id)] })).sort((a, b) => (meta.shards >= b.cost) - (meta.shards >= a.cost) || a.cost - b.cost).slice(0, 4);
  if (!list.length) return '';
  return `<div class="overups"><span>SPEND SOUL SHARDS · ◆ ${meta.shards}</span>${list.map(({ u, cost }) => `<button data-buyup="${u.id}" class="${meta.shards < cost ? 'short' : ''}">
    <i style="--img:url(${iconPath('up_' + u.id) || iconURL(u.icon[0], u.icon[1])})"></i><b>${u.name} ${mlv(u.id) + 1}/${u.max}</b><small>${u.info}</small><em>◆ ${cost}</em></button>`).join('')}</div>`;
}
$('btnSanctum').addEventListener('click', () => showScreen('sanctum'));
$('btnSanctum2').addEventListener('click', () => { if (keepFirst(() => showScreen('sanctum'))) return; showScreen('sanctum'); });
// the run's last step: an item to keep forever is picked when leaving the results (PLAY AGAIN / SANCTUM), then that action goes on
function keepFirst(then) { if (G.kept || !vaultChoices.length || !document.querySelector('.vault.keep [data-keep]')) return false; G.afterKeep = then; keepModal(true, true); return true; }
$('btnCodex').addEventListener('click', () => showScreen('codex'));
{ const syncMute = () => $('btnMute').classList.toggle('off', muted); // the title's sound button (same toggle as the M key)
  $('btnMute').addEventListener('click', () => { toggleMute(); syncMute(); }); addEventListener('keyup', (e) => { if (e.code === 'KeyM') syncMute(); }); }
for (const b of document.querySelectorAll('.back')) b.addEventListener('click', () => showScreen(player && !player.alive ? 'over' : 'title'));
// in-run build / stats panel (pauses the game)
// ---------- Lucky Chest: spend coins any time for one random reward (odds shown on the button) ----------
const LUCKY_ODDS = [['Gear', 30], ['Spell level', 22], ['+2 stat points', 18], ['New spell', 12], ['Relic', 10], ['Healing', 7], ['Legendary spell', 1]];
const luckyCost = () => 20 + (G.run.chests || 0) * 10 + G.floor * 3;
// short on coins: the button says BUY. Buying the deal opens this chest for free on top.
async function needCoins(cost) {
  if (!Monet.iapEnabled) return Monet.notice('Not enough coins', `This chest costs ● ${cost}. Pick up more coins on this floor.`); // resolves on OK
  const prod = await Monet.buy(dealProduct().sku);
  if (!prod) return;
  grantProduct(prod); toast('PURCHASED', prod.name); openLuckyChest(true);
}
function openLuckyChest(paid = false) {
  const cost = luckyCost();
  if (!paid && G.coins < cost) return needCoins(cost);
  if (!paid) { G.coins -= cost; $('coins').textContent = G.coins; }
  G.run.chests = (G.run.chests || 0) + 1;
  let roll = rand() * 100, what = LUCKY_ODDS[0][0];
  for (const [k, w] of LUCKY_ODDS) { if ((roll -= w) <= 0) { what = k; break; } }
  const owned = new Set(spells.map((s) => s.id));
  const slotFree = spells.filter((s) => isSlotSpell(s.id)).length < 4;
  const upg = spells.filter((s) => canLevel(s));
  let res = null; // what the reveal card shows
  const spellRes = (id, tag, rar, sub) => { const d = spellDef(id); res = { rar, tag, img: spellIcon(d), name: d.name, sub, lines: d.info ? [d.info] : [] }; };
  const newSpell = () => { const pool = sigPool(owned).filter(hiOk); const id = weightedSample(pool, (x) => SPELL_TIERS[spellTier(spellDef(x))].w, 1)[0]; if (!id) { if (upg.length) levelUp(); return; } spells.push({ id, lv: 1, t: 0.3 }); discover(id); spellRes(id, 'NEW SPELL', 2, 'Learned · Lv 1'); };
  const levelUp = () => { const s = pick(upg); s.lv++; spellRes(s.id, 'LEVEL UP', 1, `Now Lv ${s.lv}`); };
  const legend = Object.keys(LEGENDARY).filter((id) => !owned.has(id));
  if (legend.length && rand() < legendChance()) { /* the chest's legendary roll follows the same floor table */ const id = pick(legend); spells.push({ id, lv: 1, t: 1 }); discover(id); spellRes(id, 'LEGENDARY SPELL', 3, 'Legendary spell · Lv 1'); }
  else if (what === 'New spell' && slotFree) newSpell();
  else if ((what === 'Spell level' || what === 'New spell') && upg.length) levelUp();
  else if (what === '+2 stat points') { player.statPts += 2; $('pauseBtn').classList.add('pts'); res = { rar: 1, tag: 'STAT POINTS', img: 'icons/relic_tome.webp', name: '+2 Stat Points', sub: 'Spend them in STATS' }; }
  else if (what === 'Relic') { const r = relicOptions(1)[0]; r.pick(); res = { rar: 2, tag: 'RELIC', img: typeof r.icon === 'string' ? r.icon : iconURL(r.icon[0], r.icon[1], 128), name: r.name, lines: [r.info] }; }
  else if (what === 'Healing' && player.hp < player.maxHp) { player.hp = Math.min(player.maxHp, player.hp + 4); renderHearts(); res = { rar: 0, tag: 'HEALING', img: iconURL('items', 2, 128), name: 'Healed 2 Hearts' }; }
  else { const it = rollGear(rand, G.floor, player.g.luck + player.der.loot, what === 'Legendary spell' ? 2 : 0); dropGear(player.x, player.z, 0, it, true); res = { rar: it.rarity, img: gearIcon(it), name: it.name, sub: `${RARITY[it.rarity].name} ${SLOT_NAMES[it.slot]}`, lines: gearLines(it), note: 'Dropped next to you' }; }
  burst(player.x, 1, player.z, 0xffd34f, 30, 5, 0.45, 0.7); G.saveDue = true;
  try { chestReveal({ label: 'LUCKY CHEST', buttons: [{ x: 'ok', text: 'NICE' }], onPick: () => { if (G.luckyHold) { G.luckyHold = false; if (G.state === 'paused') G.state = 'play'; } }, ...(res || { rar: 0, name: 'Lucky!' }) }); } catch (err) { console.error(err); sfx('clear'); toast('LUCKY CHEST', res ? res.name : ''); }
  if (paid && !$('pause').classList.contains('hidden')) renderBuild(); // ad / shard path finishes after the click handler re-rendered
}
function paperDoll(gear, attrOf, sel, lv) {
  const tile = (k) => { const it = gear[k]; return it
    ? `<button class="vt${sel === k ? ' sel' : ''}" ${attrOf(k)} style="--c:${RARITY[it.rarity].color};--img:url(${gearIcon(it)})"><i></i></button>`
    : `<button class="vt empty" ${attrOf(k)} style="--img:url(${iconURL('gear', SLOTS.indexOf(k))})"><i></i><small>${SLOT_NAMES[k]}</small></button>`; };
  return `<div class="doll"><div class="dcol">${['hat', 'robe', 'staff'].map(tile).join('')}</div>
    <div class="dmid"><div class="aura"></div><img src="sprites/wizard.png" alt="">${lv ? `<span class="dlv">LV ${lv}</span>` : ''}</div>
    <div class="dcol">${['amulet', 'ring', 'boots'].map(tile).join('')}</div></div>`;
}
function renderBuild() {
  const p = player, d = p.der, g = p.g, pct = (v) => `${v >= 0 ? '+' : ''}${Math.round(v * 100)}%`;
  const pop = G.statPop; G.statPop = null;
  // read-only (no run points to spend any more): "1 + 3" = permanent part (Sanctum) + this run's STAT BOOST cards in green
  // (+ gear in blue), and the next milestone
  const statRows = `<div class="bstats">${STATS.map((k) => { const run = runOf(p, k), gs = (g.st && g.st[k]) || 0, nx = MILESTONES[k].find(([v]) => v > p.st[k]);
    return `<div class="bstat${pop === k ? ' pop' : ''}"><div><b>${STAT_NAMES[k]}</b><em>${permOf(p, k)}${run ? `<i class="srun"> + ${run}</i>` : ''}${gs ? `<i class="sgear"> + ${gs}</i>` : ''}</em></div>
    <small class="sms">${nx ? `<u>${nx[0]}:</u> ${nx[1]}` : 'all milestones reached'}</small></div>`; }).join('')}</div>`;
  // PROFILE (the 'inv' view): who you are, your level, your gear, your stats and this run's record
  const xpk = clamp(p.xp / xpNeed(p.lv), 0, 1), cls = { mage: 'Mage', archer: 'Archer', warrior: 'Warrior', hunter: 'Hunter' }[p.hero.cls] || '';
  const profHead = `<div class="phead"><img src="${heroPortrait(p.hero)}" alt=""><div><b>${p.hero.id === 'wizard' ? 'Pip' : p.hero.name}</b><small>${p.hero.id === 'wizard' ? 'Wizard · ' : ''}${cls}</small>
    <div class="plv"><span>LV ${p.lv}</span><i class="pxp"><i style="width:${(xpk * 100).toFixed(0)}%"></i></i><em>${Math.floor(p.xp)} / ${xpNeed(p.lv)} XP</em></div></div></div>`;
  const runRec = `<h3>This run</h3><div class="bnums"><div><small>Floor</small><b>${G.floor}</b></div><div><small>Kills</small><b>${G.run.kills}</b></div>
    <div><small>Best floor</small><b>${Math.max(meta.stats.bestFloor || 0, G.floor)}</b></div><div><small>Time</small><b>${fmtTime(G.run.time)}</b></div></div>`;
  const rows = [['Hearts', `${(p.hp / 2).toFixed(1)} / ${p.maxHp / 2}`], ['Damage', pct(p.dmgMul * g.dmg * d.dmg - 1)], ['Cooldowns', pct(p.cdMul * g.cd * d.cd - 1)],
    ['Crit', `${Math.round((p.crit + g.crit + d.crit) * 100)}% · x${(p.critDmg + g.critDmg + d.critDmg).toFixed(1)}`], ['Dodge', Math.round((g.dodge + d.dodge) * 100) + '%'],
    ['Resist', Math.round(d.resist * 100) + '% (max 40%)'], ['Boss dmg', pct(d.bossDmg - 1)], ['Move speed', pct(moveSpeed(p) / 5.4 - 1) + ' (max +80%)'], ['Status power', pct(d.status - 1)], ['Area', pct(p.area * g.area * d.area - 1)], ['Luck', pct(g.luck + d.loot)], ['Floor', G.floor], ['Time', fmtTime(G.run.time)]];
  const runeTxt = (s) => s.runes ? Object.entries(s.runes).map(([k, v]) => ({ pierce: `pierce ${v}`, bounce: `bounce ${v}`, seek: 'seeking' })[k]).join(', ') : '';
  const slot = (it, k, bag) => it
    ? `<div class="gearslot${bag ? ' bagit' : ''}" ${bag ? `data-bag="${k}"` : ''} style="--c:${RARITY[it.rarity].color}"><i class="ci" style="--img:url(${gearIcon(it)})"></i><div><b>${it.name}</b>${bag ? ' · tap to equip' : ''}<br>${gearLines(it).join(' · ')}</div></div>`
    : `<div class="gearslot empty"><i class="ci" style="--img:url(${iconURL('gear', SLOTS.indexOf(k))})"></i><div>${SLOT_NAMES[k]}: empty</div></div>`;
  const v = G.buildView || 'all', has = (...vs) => v === 'all' || vs.includes(v);
  $('pause').classList.toggle('focus', false); // PROFILE is the only in-run menu button on phones now: it carries SAVE & EXIT / GIVE UP too (no ≡ in a run)
  $('buildTitle').textContent = { stats: 'STATS', inv: 'PROFILE', menu: 'PAUSED' }[v] || 'YOUR BUILD';
  // the pause menu (Esc / leaving the app): painted panel over the blurred game, spells as framed tiles, run info, RESUME in thumb reach
  $('pause').classList.toggle('vmenu', v === 'menu' || v === 'inv'); $('pause').classList.toggle('vprof', v === 'inv'); $('btnResume').textContent = v === 'menu' || v === 'inv' ? 'RESUME' : '‹ RESUME';
  if (v === 'menu') {
    const info = G.prologue ? [['TIME', fmtTime(G.run.time)], ['KILLS', G.run.kills || G.kills || 0], ['LEVEL', p.lv]] // no floor or coins in the story fight
      : [['FLOOR', G.floor], ['TIME', fmtTime(G.run.time)], ['KILLS', G.run.kills || G.kills || 0], ['COINS', G.coins], ['LEVEL', p.lv]];
    $('buildList').innerHTML = `<div class="pmPanel"><i class="pmGem"></i>
      <div class="pmHead"><b>PAUSED</b><small>${G.prologue ? 'PROLOGUE' : G.daily ? 'DAILY DUNGEON' : (G.pal && G.pal.name) || ''}</small></div>
      <div class="pmInfo">${info.map(([k, w]) => `<div><small>${k}</small><b>${w}</b></div>`).join('')}</div>${loginTease()}
      <div class="pmH">SPELLS</div>
      <div class="pmSpells">${spells.map((sp) => { const df = spellDef(sp.id); return `<div class="pmSp" style="--c:${df.color}"><i style="--img:url(${spellIcon(df)})"></i>
        <span class="pips">${[1, 2, 3, 4, 5].map((n) => `<u${n <= sp.lv ? ' class="on"' : ''}></u>`).join('')}</span><b>${df.name}</b></div>`; }).join('') || '<em>No spells yet</em>'}</div></div>`;
    G.lastNums = Object.fromEntries(rows); return;
  }
  // PROFILE in the pause screen's painted kit: banner panel, portrait in the round gold frame, level + XP bar, the paper doll in
  // framed slots, stats and numbers as framed chips, this run's record, relics. Two columns in landscape. SAVE & EXIT / GIVE UP /
  // RESUME stay below (the phone's only route to them).
  if (v === 'inv') {
    const sc = STATS.map((k) => { const run = runOf(p, k), gs = (g.st && g.st[k]) || 0, nx = MILESTONES[k].find(([q]) => q > p.st[k]);
      return `<div class="pfSt${pop === k ? ' pop' : ''}"><small>${STAT_NAMES[k]}</small><b>${permOf(p, k)}${run ? `<i class="srun">+${run}</i>` : ''}${gs ? `<i class="sgear">+${gs}</i>` : ''}</b>
        <em>${nx ? `<u>${nx[0]}</u> ${nx[1]}` : 'all milestones'}</em></div>`; }).join('');
    const rec = [['FLOOR', G.floor], ['KILLS', G.run.kills || 0], ['BEST', Math.max(meta.stats.bestFloor || 0, G.floor)], ['TIME', fmtTime(G.run.time)]];
    const worn = SLOTS.filter((k) => p.gear[k]).map((k) => { const it = p.gear[k]; return `<div style="--c:${RARITY[it.rarity].color}"><b>${it.name}</b> ${gearLines(it).join(' · ')}</div>`; }).join('');
    $('buildList').innerHTML = `<div class="pmPanel pfPanel"><i class="pmGem"></i><div class="pfScroll">
      <div class="pfHead"><span class="pfPort"><img src="${heroPortrait(p.hero)}" alt=""></span><div class="pfWho"><b>${p.hero.id === 'wizard' ? 'Pip' : p.hero.name}</b>
        <small>${p.hero.id === 'wizard' ? 'WIZARD · ' : ''}${cls.toUpperCase()}</small>
        <div class="pfLv"><span>LV ${p.lv}</span><i class="pxp"><i style="width:${(xpk * 100).toFixed(0)}%"></i></i><em>${Math.floor(p.xp)} / ${xpNeed(p.lv)}</em></div></div></div>
      <div class="pfCols"><div class="pfL"><div class="pmH">EQUIPMENT</div>${paperDoll(p.gear, (k) => (p.gear[k] ? `data-ginfo="g:${k}"` : ''), null, 0)}
        ${worn ? `<div class="wornlist">${worn}</div>` : ''}
        ${p.bag.length ? `<div class="pmH">BAG</div>${p.bag.map((it, k) => slot(it, k, true)).join('')}` : ''}</div>
      <div class="pfR"><div class="pmH">STATS</div><div class="pfStats">${sc}</div>
        <div class="pfNums">${rows.filter(([k]) => k !== 'Floor' && k !== 'Time').map(([k, w]) => `<div${pop && G.lastNums && G.lastNums[k] !== undefined && G.lastNums[k] !== w ? ' class="fl"' : ''}><small>${k}</small><b>${w}</b></div>`).join('')}</div>
        <div class="pmH">THIS RUN</div><div class="pmInfo">${rec.map(([k, w]) => `<div><small>${k}</small><b>${w}</b></div>`).join('')}</div>
        <div class="pmH">RELICS</div><div class="pfRelics">${p.relics.length ? p.relics.map((id) => `<span>${RELICS.find((r) => r.id === id).name}</span>`).join('') : '<em>none yet</em>'}</div>${loginTease()}</div></div>
      </div></div>`;
    G.lastNums = Object.fromEntries(rows); return;
  }
  $('buildList').innerHTML = `
    ${v === 'inv' ? profHead : ''}
    ${has('inv') ? `${paperDoll(p.gear, (k) => (p.gear[k] ? `data-ginfo="g:${k}"` : ''), null, p.lv)}
    <div class="wornlist">${SLOTS.filter((k) => p.gear[k]).map((k) => { const it = p.gear[k]; return `<div style="--c:${RARITY[it.rarity].color}"><b>${it.name}</b> ${gearLines(it).join(' · ')}</div>`; }).join('') || '<div>Nothing worn yet.</div>'}</div>
    ${p.bag.length ? `<h3>Bag</h3>${p.bag.map((it, k) => slot(it, k, true)).join('')}` : ''}` : ''}
    ${has('stats', 'inv') ? `${v === 'inv' ? '<h3>Stats</h3>' : ''}${statRows}
    <div class="bnums">${rows.filter(([k]) => k !== 'Floor' && k !== 'Time').map(([k, w]) => `<div${pop && G.lastNums && G.lastNums[k] !== undefined && G.lastNums[k] !== w ? ' class="fl"' : ''}><small>${k}</small><b>${w}</b></div>`).join('')}</div>` : ''}
    ${has('menu', 'stats') ? `<h3>Spells</h3><div class="chips">${spells.map((sp) => { const df = spellDef(sp.id); return `<span style="--c:${df.color}"><i class="ci" style="--img:url(${spellIcon(df)})"></i>${df.name} Lv ${sp.lv}${sp.runes ? ` <small>(${runeTxt(sp)})</small>` : ''}</span>`; }).join('')}</div>` : ''}
    ${v === 'menu' || v === 'stats' ? `<div class="bnums">${rows.filter(([k]) => k === 'Floor' || k === 'Time').map(([k, w]) => `<div><small>${k}</small><b>${w}</b></div>`).join('')}</div>` : ''}
    ${v === 'inv' ? runRec : ''}
    ${has('inv') ? `<h3>Relics</h3><div class="chips">${p.relics.length ? p.relics.map((id) => `<span>${RELICS.find((r) => r.id === id).name}</span>`).join('') : '<span>none yet</span>'}</div>` : ''}`; // (the Lucky Chest strip left the INVENTORY panel: user, "bugged")
  G.lastNums = Object.fromEntries(rows);
}
// what n more points in k give, read off derive itself: ['+30% damage', ...] (STAT BOOST cards)
function statGains(k, n0 = 1) {
  const p = player, a = p.der, nx = (n) => derive(p.hero.cls, { ...p.st, [k]: p.st[k] + n }, p.hero.base), b = nx(n0), out = [];
  const f = (x) => { const v = x * 100; return Math.abs(v) < 10 ? +v.toFixed(1) : Math.round(v); };
  if (b.dmg > a.dmg + 1e-9) out.push(`+${f(b.dmg / a.dmg - 1)}% damage`);
  if (b.cd < a.cd - 1e-9) out.push(`${f(b.cd / a.cd - 1)}% cooldowns`);
  if (b.hearts > a.hearts) out.push(`+${b.hearts - a.hearts} heart${b.hearts - a.hearts > 1 ? 's' : ''}`);
  else if (k === 'vit') { for (let n = n0 + 1; n <= n0 + 5; n++) if (nx(n).hearts > a.hearts) { out.push(`a heart in ${n - n0} more`); break; } }
  if (b.resist > a.resist + 1e-9) out.push(`+${f(b.resist - a.resist)}% resist`);
  if (b.bossDmg > a.bossDmg + 1e-9) out.push(`+${f(b.bossDmg - a.bossDmg)}% boss dmg`);
  if (b.kb > a.kb + 1e-9) out.push(`+${f(b.kb / a.kb - 1)}% knockback`);
  if (b.dodge > a.dodge + 1e-9) out.push(`+${f(b.dodge - a.dodge)}% dodge`);
  if (b.crit > a.crit + 1e-9) out.push(`+${f(b.crit - a.crit)}% crit`);
  if (b.critDmg > a.critDmg + 0.5) out.push(`+${f(b.critDmg - a.critDmg)}% crit dmg`);
  return out;
}
// spend / refund run points; refunds only for points spent since this panel opened (G.statUndo), then they're permanent
function spendStat(k) {
  const p = player, c = ptCost(p, k); if (p.statPts < c) return;
  const t0 = p.der.T[k];
  p.alloc[k]++; p.statPts -= c; (G.statUndo = G.statUndo || []).push({ k, c }); recalcStats(); sfx('card');
  G.statPop = k;
  if (p.der.T[k] > t0) { const m = MILESTONES[k][p.der.T[k] - 1]; toast(`${STAT_NAMES[k]} ${m[0]} UNLOCKED`, m[1]); sfx('levelup'); burst(p.x, 1, p.z, 0xffe14f, 30, 5, 0.45, 0.7); }
}
function undoStat(k) {
  const p = player, st = G.statUndo || [];
  let i = st.length - 1; while (i >= 0 && st[i].k !== k) i--; if (i < 0) return;
  const u = st.splice(i, 1)[0], hp0 = p.hp, m0 = p.maxHp;
  p.alloc[k]--; p.statPts += u.c; recalcStats();
  const lost = m0 - p.maxHp; if (lost > 0) { p.hp = Math.max(1, Math.min(p.maxHp, hp0 - lost)); renderHearts(); } // the heart it gave goes again
  $('pauseBtn').classList.add('pts'); G.statPop = k;
}
$('buildList').addEventListener('click', (e) => {
  const gi = e.target.closest('[data-ginfo]');
  if (gi) return; // gear is locked during a run; change it in the Vault before you go in
  const b = e.target.closest('[data-stat],[data-unstat],[data-undoall],[data-bag],[data-lucky]'); if (!b || b.disabled) return;
  if (b.dataset.lucky) openLuckyChest();
  if (b.dataset.stat) spendStat(b.dataset.stat);
  if (b.dataset.unstat) { undoStat(b.dataset.unstat); sfx('whoosh'); }
  if (b.dataset.undoall) { while ((G.statUndo || []).length) undoStat(G.statUndo[G.statUndo.length - 1].k); G.statPop = null; sfx('whoosh'); }
  if (b.dataset.bag !== undefined) { const it = player.bag.splice(+b.dataset.bag, 1)[0]; if (it) equipOrStash(it, true); }
  renderBuild();
});
$('pauseBtn').addEventListener('pointerdown', (e) => { e.stopPropagation(); pauseGame(); });
$('btnResume').addEventListener('click', () => { $('pause').classList.add('hidden'); G.state = 'play'; G.statUndo = null; }); // points spent are permanent now
// leave mid-run without losing it: save at the last safe point and go to the title, where CONTINUE picks it up
$('btnSaveExit').addEventListener('click', () => {
  $('pause').classList.add('hidden'); G.state = 'play'; checkpoint(); // live state; the fight you left resumes at its wave
  G.state = 'title'; $('hud').classList.add('hidden'); showScreen('title');
});
// GIVE UP asks first (the painted confirm); the run stays paused behind it
$('btnQuit').addEventListener('click', () => {
  Monet.ask('Give up this run?', `Floor ${G.floor} · the run ends here, like a death. Shards and Legacy XP still count.`, 'KEEP PLAYING', 'GIVE UP').then((keep) => {
    if (keep || G.state !== 'paused' || !player || !player.alive) return;
    $('pause').classList.add('hidden'); G.state = 'play'; player.revive = 0; player.iframe = 0; player.hp = 0; playerDie(); });
});
addEventListener('resize', resize);

// ---------- loop ----------
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const rdt = Math.min(0.05, (now - last) / 1000); last = now;
  $('app').classList.toggle('noTut', G.state !== 'play'); // the move hint (and its hand) never sits over menus, cards or the title
  tick(rdt);
  render();
}
const timers = [];
function later(sec, fn) { timers.push({ t: sec, fn }); }
let lowOp = '';
const setLow = (v) => { if (v !== lowOp) lowEl.style.opacity = lowOp = v; }; // only touch the style when it changes
function tick(rdt) {
  readKeys(); FX_FR = Math.min(2, Math.max(0, rdt * 60));
  const frozen = G.state === 'paused' || (G.state === 'play' && Monet.blocking > 0); // pause menu / daily chest hold / a notice up: queued hits, Rockfall, text and banners all wait
  const zs = ZOO && zoo.slow ? 0.35 : 1; // the zoo's SLOW-MO: the game and its queued hits run at 0.35x
  if (!frozen) for (let i = timers.length - 1; i >= 0; i--) if ((timers[i].t -= rdt * zs) <= 0) { const f = timers[i].fn; timers.splice(i, 1); f(); }
  let dt = rdt;
  if (frozen) dt = 0;
  else if (G.hitstop > 0) { G.hitstop = 0; } // global freeze-frames OFF entirely (user 11-15: 'I don't want the freeze hit')
  else if (G.finisher) { dt *= 0.16; if ((G.finisher.t -= rdt) <= 0) G.finisher = null; }
  else if (G.slowmo > 0) { G.slowmo -= rdt; dt *= 0.35; }
  dt *= zs;
  if (music) { // the whole prologue is the Stone King's; the title screen has its own theme
    const cr = G.state === 'title' ? null : rooms.find((q) => q.active);
    music.menu(G.state === 'title'); music.combat(!!cr); music.boss(!!G.prologue || (!!cr && cr.type === 'boss'));
  }
  if (G.state !== 'cards' && G.state !== 'title' && !frozen) update(dt);
  if (G.prologue && !frozen) vnUpdate(rdt);
  updateCamera(rdt);
  G.comboPop = Math.max(0, G.comboPop - rdt * 5);
  if (player && player.alive && G.state === 'play' && !frozen) { // footsteps: one soft step per ~1.1 tiles walked
    G.stepD = (G.stepD || 0) + Math.hypot(player.vx || 0, player.vz || 0) * rdt;
    if (G.stepD > 1.1) { G.stepD = 0; sfx('step'); }
  }
  if (player && player.alive && G.state === 'play' && player.hp <= 2) {
    G.beatT = (G.beatT || 0) - rdt;
    if (G.beatT <= 0) { G.beatT = 0.9; sfx('beat'); } if (music) music.duck(true);
    setLow((0.25 + 0.35 * Math.pow(Math.max(0, Math.sin((0.9 - G.beatT) / 0.9 * Math.PI * 2)), 4)).toFixed(2));
  } else { setLow('0'); if (music) music.duck(false); }
  if (!frozen && toastT > 0 && (toastT -= rdt) <= 0) $('toast').classList.remove('show');
  if (!frozen && bannerT > 0 && (bannerT -= rdt) <= 0) $('banner').classList.remove('show');
}
const FPS = params.has('fps');
const perf = { n: 0, t: performance.now(), fps: 0, cpu: 0, calls: 0, worst: 0, last: performance.now() };
let perfEl = null;
if (FPS) { perfEl = document.createElement('div'); perfEl.style.cssText = 'position:absolute;left:8px;bottom:8px;z-index:60;font:12px monospace;color:#7fff9f;background:rgba(0,0,0,.6);padding:4px 6px;border-radius:6px;pointer-events:none;white-space:pre'; $('app').appendChild(perfEl); }
window.__perf = perf;
window.__g = { THREE, camera, renderer, scene, sun, hemi, torchLights, get pLight() { return pLight; }, fxLight, fxCanvas, glowPoints, debrisMesh, splatMesh, resize };
function render() {
  const t0 = performance.now();
  if (player) { updateHud(); drawMinimap(); }
  flushBatches(); renderer.render(scene, camera);
  drawOverlay();
  if (FPS || window.__perfOn) {
    const now = performance.now();
    perf.cpu = perf.cpu * 0.9 + (now - t0) * 0.1; perf.calls = renderer.info.render.calls; perf.worst = Math.max(perf.worst, now - perf.last); perf.last = now; perf.n++;
    if (now - perf.t > 1000) {
      perf.fps = Math.round(perf.n * 1000 / (now - perf.t)); perf.n = 0; perf.t = now;
      if (perfEl) perfEl.textContent = `${perf.fps} fps  worst ${perf.worst.toFixed(0)}ms
render ${perf.cpu.toFixed(1)}ms  calls ${perf.calls}
fx ${gData.filter((d) => d.life > 0).length}  enemies ${enemies.length}  dpr ${renderer.getPixelRatio().toFixed(2)}`;
      perf.worst = 0;
    }
  }
  if (recorder) { recCtx.drawImage(renderer.domElement, 0, 0, recCanvas.width, recCanvas.height); recCtx.drawImage(fxCanvas, 0, 0, recCanvas.width, recCanvas.height); }
}
let recorder = null, recCanvas = null, recCtx = null;
function toggleRecording(sec = 0) {
  if (recorder) { recorder.stop(); return; }
  if (!window.MediaRecorder) return;
  recCanvas = document.createElement('canvas');
  recCanvas.width = renderer.domElement.width; recCanvas.height = renderer.domElement.height;
  recCtx = recCanvas.getContext('2d');
  const mime = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm', 'video/mp4'].find((m) => MediaRecorder.isTypeSupported(m));
  const chunks = [];
  recorder = new MediaRecorder(recCanvas.captureStream(30), { mimeType: mime, videoBitsPerSecond: 10e6 });
  recorder.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
  recorder.onstop = () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(chunks, { type: mime }));
    a.download = `runebound_${Date.now()}.${mime.includes('mp4') ? 'mp4' : 'webm'}`;
    a.click(); recorder = null; toast('RECORDING SAVED', a.download);
  };
  recorder.start(500);
  toast('RECORDING', sec ? `${sec}s` : 'press R to stop');
  if (sec) setTimeout(() => recorder && recorder.stop(), sec * 1000);
}

// compile every shader the effects use before play, so the first meteor / explosion / beam doesn't hitch
let spriteKeep = null, spriteKeepRim = null;
function warmShaders() {
  const tmp = [];
  const add = (o) => { if (o) { o.position.set(rooms[0].cx, 0.5, rooms[0].cz); tmp.push(o); if (!o.parent) scene.add(o); } };
  for (const rocky of [false, true]) { const m = makeMeteor(rooms[0].cx, rooms[0].cz, 0xff7a2a, rocky, 1.5); add(m.g); tmp.push(m.glow); }
  for (const k of ['bolt', 'fire', 'venom', 'lance', 'glaive', 'orb', 'javelin', 'axe', 'arrow', 'skull']) add(makeProjMesh(k, 0xff7fe0));
  add(new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ map: softRingTex, color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })));
  add(new THREE.Mesh(markerGeo, new THREE.MeshBasicMaterial({ map: markTex, color: 0xff3050, transparent: true, opacity: 0.4, depthWrite: false, blending: THREE.AdditiveBlending })));
  add(new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color: 0xff2040, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false })));
  add(makeShadow(1)); add(makeGlow(0xffffff, 1, 1));
  add(new THREE.Mesh(spearShaftGeo, spearShaftMat)); add(new THREE.Mesh(spearTipGeo, spearTipMat)); { const f = fballGet(); if (f) { add(f.core); add(f.shell); fballFree(f); scene.add(f.core, f.shell); tmp.push(f.core, f.shell, f.shell2); } } // batch-3 foe FX (spear, fireball); the rocks' instanced meshes sit in the scene already
  { const g = makeGlow(0xffffff, 1, 1); g.material.depthTest = false; add(g); } // the over-the-wizard glow batch too
  // the see-through sprite program (death ghosts, ghost foes, Pip's trail): one material that is never disposed keeps it
  // compiled. Without it, every kill after a quiet moment recompiled the shader (killMesh disposes the last user).
  if (!spriteKeep && sheets.slime) { spriteKeep = makeSprite('slime'); spriteKeep.material.transparent = true; spriteKeep.material.uniforms.uFlash.value = 1; add(spriteKeep); }
  if (!spriteKeepRim && sheets.slime) { spriteKeepRim = makeSprite('slime'); spriteKeepRim.material.defines = { RIM: 1 }; add(spriteKeepRim); } // the rim-lit foe variant (imps, reapers...), same reason
  // renderer.compile visits every object that has a .material: the batched glow stand-ins carry a fake one with no geometry, and
  // it threw on them, so nothing here was ever precompiled and spriteKeep never held its program (the see-through sprite shader
  // was rebuilt ~1x a second in busy fights). Their fake material is hidden for the compile only.
  flushBatches();
  const fakes = []; scene.traverse((o) => { if (o.material && !o.geometry) fakes.push(o); });
  const fakeMats = fakes.map((o) => o.material); for (const o of fakes) o.material = null;
  try { renderer.compile(scene, camera); } catch (e) { /* warm-up is best effort */ }
  fakes.forEach((o, k) => { o.material = fakeMats[k]; });
  try { renderer.render(scene, camera); } catch (e) { /* warm-up is best effort */ }
  for (const o of tmp) { scene.remove(o); if (o.isSprite) o.material.dispose(); }
  meteors.length = 0;
}
// ---------- ?zoo: the monster zoo (dev page). Every foe with an attack, one at a time, in one clean room ----------
// PREV / NEXT (or the left / right arrows) step through ZOO_LIST. Pip can walk (WASD / drag), is invulnerable (a hit still
// flashes, shakes and knocks back), and his spells are off until SPELLS ON (to see blocks and hit reactions; a killed
// monster comes back). SLOW-MO runs everything at 0.35x. No waves, cards, ads, toasts or saves. Inert without ?zoo.
const ZOO_LIST = [
  ['skeleton', 'SKELETON', 'Raises its sword overhead, then one fast chop'],
  ['cursed', 'CURSED WARRIOR', 'Shield up (blocks frontal hits), then a sword chop'],
  ['reaper', 'GRAVE REAPER', 'Throws its sickle: it spins out a marked loop and boomerangs back'],
  ['boneknight', 'BONE KNIGHT', '3-hit combo; the last swing is heavy and cracks the floor'],
  ['golem', 'STONE GOLEM', 'Rolls down a marked lane, lobs boulders, fist slam; ground smash brings rocks down'],
  ['runegolem', 'RUNE GOLEM', 'Roll, glowing rune-rock lob, fist slam with a rune shockwave, ground smash'],
  ['crystalgolem', 'CRYSTAL GOLEM', 'Roll, crystal lob that splits into shards, shard-spraying slam, ground smash'],
  ['magmagolem', 'MAGMA GOLEM', 'Roll leaves a lava trail; molten rock lob splashes lava; ground smash'],
  ['archer', 'SKELETON ARCHER', 'Keeps its distance; the aim line locks, then one fast arrow'],
  ['spider', 'CRYSTAL SPIDER', 'Skitters, crouches, then pounces onto a marked spot'],
  ['salamander', 'FIRE SALAMANDER', 'Skitters in bursts on a burning trail, freezes, then a quick fire bite'],
  ['shieldk', 'SHIELD KNIGHT', 'Shield blocks the front; long pike thrust; throws the spear, then fetches it'],
  ['cultist', 'CULTIST CASTER', 'Keeps away; crimson fireball down an aim line; heals allies, opens portals'],
  ['beetle', 'RUST BEETLE', 'Curls up (immune), rolls and ricochets off walls, then lies dizzy'],
  ['slime', 'SLIME', 'Squashes down, a ring marks where it lands, then the hop'],
  ['big', 'BIG SLIME', 'Heavy hops onto a marked ring; splits into two slimes when it dies'],
  ['eye', 'FLOATING EYE', 'Holds its range (backs off), charges up, spits a fan of orbs'],
  ['imp', 'IMP', 'Stalks and pauses; from a stop a lane-marked raking lunge'],
  ['bomber', 'BOMBER', 'Runs at you, lights its fuse (ring), explodes'],
  ['ghost', 'GHOST', 'Floats at a distance; every blink-in ends in a cone-marked scream'],
  ['shroom', 'SPORE SHROOM', 'Hops back to range; puffs up and fires a fan of spores'],
  ['mimic', 'MIMIC', 'Hops onto marked rings; hops away, the lid flaps, then a coin ring'],
  ['boss', 'KING GLOOP', 'Boss: big jumps onto you, slime sprays'],
  ['eyeboss', 'THE HOLLOW EYE', 'Boss: circles the walls, sweeping lasers, tear bursts, calls its children'],
  ['golemboss', 'THE STONE KING', 'Boss: boulder roll (enraged: ricochet), fist slam, ground smash rockfall'],
  ['tyrant', 'THE BONE TYRANT', 'Boss: 3-slash combo and sweep up close, bone lines from range, raises the dead'],
  ['sporeboss', 'MOTHER SPORE', 'Boss: rooted; digs away when crowded, erupts under you, spirals, gas, brood'],
  ['wraithboss', 'THE WRAITH QUEEN', 'Boss: blinks around you, homing souls, a court of ghosts'],
  ['mimiclord', 'THE MIMIC LORD', 'Boss: heavy hops spilling gold, tongue lash, coin fans, decoy chests'],
  ['frostboss', 'THE FROST MATRIARCH', 'Boss: 16-way frost diver burst, icicle lines, ice floor'],
  ['sentinel', 'THE CLOCKWORK SENTINEL', 'Boss: four-way laser cross, saw gears on dashed lanes, overheat'],
].filter(([t]) => ENEMY[t]);
const zoo = { i: 0, e: null, room: null, spells: false, slow: false, hits: 0, respawnT: 0, on: false };
function zooHit(fx, fz) { // damagePlayer in the zoo: everything a hit shows, nothing it costs
  zoo.hits++; player.iframe = 0.45; zoo.last = [+fx.toFixed(2), +fz.toFixed(2), +player.x.toFixed(2), +player.z.toFixed(2), zoo.e ? zoo.e.state : '']; // headless checks: where the last hit came from
  const dx = player.x - fx, dz = player.z - fz, dl = Math.hypot(dx, dz) || 1;
  player.vx += dx / dl * 6; player.vz += dz / dl * 6; player.squash = 0.6;
  addShake(0.45); G.hitstop = Math.max(G.hitstop, 0.07); sfx('hurt');
  $('hurt').style.transition = 'none'; $('hurt').style.opacity = 0.8;
  requestAnimationFrame(() => { $('hurt').style.transition = 'opacity .5s'; $('hurt').style.opacity = 0; });
  burst(player.x, 0.6, player.z, 0xff2a4a, 14, 5, 0.4, 0.45);
  addText(player.x, 1.6, player.z, 'HIT', '#ff8a9a', 0.9);
}
function zooClear() { // NEXT / PREV: the old monster, its minions, projectiles, markers, portals, lava / fire patches and drops all go
  for (const t of texts) if (t.ghost) killMesh(t.ghost);
  for (const o of enemies) o.dead = true; // the old monster's queued attacks (later()) see it gone
  timers.length = 0; // ...and nothing it queued fires into the next one (dev page only)
  resetLevelObjects(true);
  clearSplats(); grimeFloor();
  zoo.e = null;
}
function zooSpawn() {
  const [type] = ZOO_LIST[zoo.i], boss = BOSSES.find((b) => b.type === type);
  if (boss) G.boss = boss;
  const d = boss ? 4.6 : 3;
  let x = player.x, z = player.z - d;
  for (let k = 1; k < 18 && solid(x, z, false); k++) { const a = -Math.PI / 2 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * 0.35; x = player.x + Math.cos(a) * d; z = player.z + Math.sin(a) * d; }
  zoo.e = spawnEnemy(type, x, z);
  if (type === 'shieldk') zoo.e.fa = Math.atan2(player.z - z, player.x - x); // faces Pip from the start
  zoo.t = 0;
}
function zooShow(i) {
  const n = ZOO_LIST.length; zoo.i = ((i % n) + n) % n;
  zooClear();
  const r = zoo.room;
  player.x = r.cx; player.z = r.cz + 0.8; player.vx = player.vz = 0; player.iframe = 0.8;
  if (solid(player.x, player.z, false)) player.z = r.cz;
  camTarget.set(player.x, 0, player.z);
  zoo.respawnT = 0; zoo.hits = 0;
  zooSpawn();
  const [, name, info] = ZOO_LIST[zoo.i];
  $('zooName').textContent = name; $('zooDesc').textContent = info; $('zooNum').textContent = `${zoo.i + 1} / ${n}`;
}
function zooUpdate(dt) {
  if (SPELLV) return spvUpdate(dt);
  if (!zoo.on) return;
  zoo.t = (zoo.t || 0) + dt;
  if (zoo.e && zoo.e.dead) { zoo.e = null; zoo.respawnT = 1.2; } // killed (spells on, or a bomber's own blast): it comes back
  if (!zoo.e && zoo.respawnT > 0 && (zoo.respawnT -= dt) <= 0) {
    zooSpawn();
  }
}
function zooSetSpells(on) {
  zoo.spells = on;
  if (on) {
    const start = player.hero.start;
    spells = [{ id: start, lv: 3, t: 0.4 }, { id: 'fire.ball', lv: 2, t: 0.9 }].filter((s) => spellDef(s.id));
    buildSpellHud();
  }
  const b = $('zooSpells'); b.classList.toggle('on', on); b.querySelector('b').textContent = on ? 'ON' : 'OFF';
}
function zooSetSlow(on) { zoo.slow = on; const b = $('zooSlow'); b.classList.toggle('on', on); b.querySelector('b').textContent = on ? 'ON' : 'OFF'; }
function zooKey(e) {
  if (SPELLV) return spvKey(e);
  if (!zoo.on || e.repeat) return;
  if (e.code === 'ArrowRight') zooShow(zoo.i + 1);
  else if (e.code === 'ArrowLeft') zooShow(zoo.i - 1);
}
function zooStart() {
  if (SPELLV) return spvStart();
  if (whenArt(zooStart)) return;
  document.documentElement.classList.add('zoo');
  for (const sId of screens) $(sId).classList.add('hidden');
  G.daily = null; G.runDungeon = BIOMES[params.get('biome')] ? params.get('biome') : 'forge';
  newGame();
  for (const r of rooms) { r.cleared = true; r.waves = 0; r.totalWaves = 0; } // no room ever locks or spawns waves
  zoo.room = roomAt(player.x, player.z) || rooms[0];
  spells = []; buildSpellHud();
  const st = document.createElement('style');
  st.textContent = `
html.zoo #title, html.zoo #toast, html.zoo #banner, html.zoo #spells, html.zoo #stats, html.zoo #right, html.zoo #invBtn, html.zoo #dlyBtn,
html.zoo #dailyBtn, html.zoo #tut, html.zoo #reveal { display: none !important; }
#zooBar { position: absolute; z-index: 40; left: 50%; translate: -50% 0; bottom: calc(10px + env(safe-area-inset-bottom)); width: min(calc(100% - 16px), 640px);
  display: flex; align-items: center; gap: 6px; pointer-events: auto; font-family: "Cinzel", "Cormorant SC", serif; }
#zooBar button { --bh: 50px; flex: none; height: var(--bh); padding: 0 calc(var(--bh) * .42); background: none; box-shadow: none; border-radius: 0; cursor: pointer;
  font: 900 14px "Cinzel", "Cormorant SC", serif; letter-spacing: 1px; white-space: nowrap; color: #f3e6ff; text-shadow: 0 1px 0 #1a0628;
  border: 0 solid transparent; border-image: url(ui/btn_purple.webp) 0 80 fill / 0 calc(var(--bh) * .548) / 0 stretch; filter: drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#zooBar #zooNext { color: #4a2506; text-shadow: 0 1px 0 rgba(255,246,200,.85); border-image: url(ui/btn_gold.webp) 0 130 fill / 0 calc(var(--bh) * .514) / 0 stretch;
  filter: drop-shadow(0 0 10px rgba(255,190,70,.35)) drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#zooBar button:active, #zooTog button:active { transform: scale(.95); }
#zooInfo { flex: 1 1 0; min-width: 0; min-height: 64px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;
  padding: 8px 12px; color: #fff; border: 0 solid transparent; border-image: url(ui/banner.webp) 95 fill / 20px / 0 stretch; filter: drop-shadow(0 6px 10px rgba(0,0,0,.6)); }
#zooName { font: 900 16px "Cinzel", serif; letter-spacing: 1px; color: #ffe6a8; text-shadow: 0 2px 0 #2a0a10; line-height: 1.1; }
#zooDesc { display: block; margin-top: 3px; font: 700 12.5px/1.2 "Alegreya Sans", sans-serif; color: #f3e6ff; }
#zooNum { display: block; margin-top: 3px; font: 700 11px "Cinzel", serif; letter-spacing: 1px; color: #c9a7ff; font-style: normal; }
#zooTog { position: absolute; z-index: 40; top: calc(10px + env(safe-area-inset-top)); right: 10px; display: flex; flex-direction: column; align-items: flex-end; gap: 8px; pointer-events: auto; }
#zooTog button { --bh: 40px; height: var(--bh); padding: 0 calc(var(--bh) * .5); background: none; box-shadow: none; border-radius: 0; cursor: pointer; white-space: nowrap;
  font: 900 12px "Cinzel", "Cormorant SC", serif; letter-spacing: 1px; color: #f3e6ff; text-shadow: 0 1px 0 #1a0628;
  border: 0 solid transparent; border-image: url(ui/btn_purple.webp) 0 80 fill / 0 calc(var(--bh) * .548) / 0 stretch; filter: drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#zooTog button b { color: #ff9aa8; } #zooTog button.on b { color: #7dff9a; }
#zooTog button.on { filter: drop-shadow(0 0 8px rgba(125,255,154,.45)) drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#zooTitle { position: absolute; z-index: 40; top: calc(14px + env(safe-area-inset-top)); left: 12px; font: 900 13px "Cinzel", serif; letter-spacing: 2px; color: #ffe6a8;
  text-shadow: 0 2px 0 #2a0a10, 0 0 10px rgba(0,0,0,.8); pointer-events: none; }
@media (max-width: 420px) { #zooBar { gap: 4px; width: calc(100% - 10px); } #zooBar button { --bh: 44px; min-width: 76px; padding: 0 20px; font-size: 11.5px; letter-spacing: .5px; } #zooInfo { padding: 7px 10px; } #zooName { font-size: 14px; } #zooDesc { font-size: 11.5px; } }
@media (max-width: 350px) { #zooBar button { min-width: 64px; padding: 0 18px; } #zooBar .lbl { display: none; } }
html.land #zooBar { width: min(calc(100% - 24px), 760px); }
@media (max-height: 460px) { #zooBar { bottom: calc(6px + env(safe-area-inset-bottom)); } #zooBar button { --bh: 42px; } #zooInfo { min-height: 52px; padding: 5px 12px; } #zooTog button { --bh: 34px; } }`;
  document.head.appendChild(st);
  const bar = document.createElement('div'); bar.id = 'zooBar';
  bar.innerHTML = '<button id="zooPrev" aria-label="Previous monster">◀<span class="lbl"> PREV</span></button><div id="zooInfo"><b id="zooName"></b><small id="zooDesc"></small><i id="zooNum"></i></div><button id="zooNext" aria-label="Next monster"><span class="lbl">NEXT </span>▶</button>';
  const tog = document.createElement('div'); tog.id = 'zooTog';
  tog.innerHTML = '<button id="zooSpells">SPELLS <b>OFF</b></button><button id="zooSlow">SLOW-MO <b>OFF</b></button>';
  const ttl = document.createElement('div'); ttl.id = 'zooTitle'; ttl.textContent = 'MONSTER ZOO';
  $('app').append(bar, tog, ttl);
  const on = (id, fn) => $(id).addEventListener('pointerdown', (ev) => { ev.stopPropagation(); ev.preventDefault(); fn(); }); // stopPropagation: not a joystick drag
  on('zooPrev', () => zooShow(zoo.i - 1)); on('zooNext', () => zooShow(zoo.i + 1));
  on('zooSpells', () => zooSetSpells(!zoo.spells)); on('zooSlow', () => zooSetSlow(!zoo.slow));
  zoo.on = true;
  const first = ZOO_LIST.findIndex(([t]) => t === params.get('zoo')); // ?zoo=golem starts at that monster
  $('zooName').textContent = 'MONSTER ZOO'; $('zooDesc').textContent = 'Loading...'; $('zooNum').textContent = '';
  later(1.6, () => zooShow(Math.max(0, first))); // after Pip lands
  window.__zoo = { get i() { return zoo.i; }, get type() { return ZOO_LIST[zoo.i][0]; }, get e() { return zoo.e; }, get hits() { return zoo.hits; }, get last() { return zoo.last; }, list: ZOO_LIST.map((z) => z[0]),
    show: zooShow, spells: zooSetSpells, slow: zooSetSlow, get eprojs() { return eprojs.length; }, get enemies() { return enemies.length; } }; // headless checks
}
// ---------- ?spells: the spell viewer (dev page). Every castable spell, one at a time, on training dummies ----------
// Built on the zoo (ZOO is on too: no saves, cards, ads, toasts or login popups; Pip can't be hurt). The spell auto-casts through
// the normal castSpells path on its own cooldown. PREV / NEXT (or the left / right arrows) step through SPV_LIST, LV 1-5 (or
// [ / ]) set its level, T1 / T2 / T3 (or keys 1-3) rate its tier and move on, the group chips jump to signature / fusion / boss / unique / legendary, SLOW-MO runs at 0.35x.
// ?spells=fire.ring (an id or a name: ?spells=phoenix) starts at that spell, &lv=3 at that level. Inert without ?spells.
const SPV_TYPES = [['sig', 'SIGNATURE'], ...(FUSION_IDS.length ? [['fusion', 'FUSION']] : []), ['boss', 'BOSS'], ['unique', 'UNIQUE'], ['legend', 'LEGENDARY', 'LEGEND']]; // no FUSION chip while fusions are off // [key, panel name, chip label]
const spvType = (d) => (d.legendary ? 'legend' : d.unique ? 'unique' : d.bossSpell ? 'boss' : d.fused ? 'fusion' : 'sig');
const SPV_LIST = SPELLV ? (() => { // by type, then element(s); inside one element the data order (signatures: tier order)
  const ids = [...SIG_IDS, ...FUSION_IDS, ...Object.keys(BOSS_SPELLS), ...Object.keys(UNIQUE_SPELLS), ...Object.keys(LEGENDARY)].filter((id) => spellDef(id) && !CUT_IDS.has(id));
  const ti = (d) => SPV_TYPES.findIndex(([k]) => k === spvType(d)), ei = (d, k) => (d.els[k] ? ELEMENT_ORDER.indexOf(d.els[k]) : -1);
  return ids.sort((a, b) => { const A = spellDef(a), B = spellDef(b); return ti(A) - ti(B) || ei(A, 0) - ei(B, 0) || ei(A, 1) - ei(B, 1); });
})() : [];
// training dummies around Pip (offsets from his spot): one close (novas, rings), a fan further out (chains, rains, fields), one far (lances)
const SPV_DUMMIES = [[0, -2.6], [-2.3, -4.4], [2.3, -4.4], [-3.9, -1.7], [3.9, -1.7], [0, -6.6]];
const SPV_HP = 500, SPV_NEUTRAL = Object.fromEntries(ELEMENT_ORDER.map((el) => [el, 1])); // no resistances: every element reads the same
const spv = { i: 0, lv: 1, on: false, room: null, home: null, cam: null, dum: [], rt: [], tiers: {}, unrated: false, adv: 0, awe: new Set(DAILY_AWESOME) };
// tier rating (the user rates every spell T1 / T2 / T3; not applied to the game yet). Kept in localStorage 'rb_spell_tiers'
// and POSTed to the test server (tools/serve_review.py -> E:\rbqa_tmp\spell_tiers.json) on every tap, so Claude can read it.
const SPV_TIER_KEY = 'rb_spell_tiers', SPV_TIER_URL = '__tiers'; // relative: /runebound/__tiers on the test link
const spvSuggest = (d) => (d.sig || d.fused ? Math.min(3, spellTier(d) + 1) : 0); // COMMON->T1, RARE->T2, EPIC->T3; boss / unique / legendary: none
const spvTierOk = (o) => { const out = {}; if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) if (ALL_SPELL_SET.has(k) && (v === 1 || v === 2 || v === 3)) out[k] = v; return out; };
async function spvLoadTiers() { // server first, then this device's own ratings on top (localStorage wins)
  let local = {}; try { local = spvTierOk(JSON.parse(localStorage.getItem(SPV_TIER_KEY) || '{}')); } catch (e) { /* none */ }
  spv.tiers = { ...spv.tiers, ...local };
  try { const r = await fetch(SPV_TIER_URL, { cache: 'no-store' }); if (r.ok) spv.tiers = { ...spvTierOk(await r.json()), ...local, ...spv.tiers }; } catch (e) { /* no server: local only */ }
  if (spv.on && $('spvTier')) spvTierUi();
}
function spvSaveTiers() {
  const j = JSON.stringify(spv.tiers);
  try { localStorage.setItem(SPV_TIER_KEY, j); } catch (e) { /* storage blocked */ }
  try { fetch(SPV_TIER_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: j, keepalive: true }).catch(() => {}); } catch (e) { /* fire and forget */ }
}
// the Daily's awesome list (★ DAILY AWESOME, key A): starts as DAILY_AWESOME, then this device's saved set
// (localStorage 'rb_daily_awesome'), then the server's (E:\rbqa_tmp\daily_awesome.json) so every device shows the same picks.
// Every toggle saves both. The game itself uses DAILY_AWESOME (Claude copies the user's picks into it).
const SPV_AWE_KEY = 'rb_daily_awesome', SPV_AWE_URL = '__awesome'; // relative: /runebound/__awesome on the test link
const spvAweOk = (a) => (Array.isArray(a) ? [...new Set(a.filter((id) => typeof id === 'string' && ALL_SPELL_SET.has(id)))].slice(0, 300) : null);
async function spvLoadAwe() {
  try { const l = spvAweOk(JSON.parse(localStorage.getItem(SPV_AWE_KEY) || 'null')); if (l) spv.awe = new Set(l); } catch (e) { /* none */ }
  try { const r = await fetch(SPV_AWE_URL, { cache: 'no-store' }); if (r.ok) { const a = spvAweOk(await r.json()); if (a && a.length) spv.awe = new Set(a); } } catch (e) { /* no server: local only */ }
  if (spv.on && $('spvAwe')) spvTierUi();
}
function spvToggleAwe() {
  const id = SPV_LIST[spv.i]; if (spv.awe.has(id)) spv.awe.delete(id); else spv.awe.add(id);
  const j = JSON.stringify([...spv.awe]);
  try { localStorage.setItem(SPV_AWE_KEY, j); } catch (e) { /* storage blocked */ }
  try { fetch(SPV_AWE_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: j, keepalive: true }).catch(() => {}); } catch (e) { /* fire and forget */ }
  spvTierUi(); sfx('card');
}
function spvTierUi() {
  const id = SPV_LIST[spv.i], d = spellDef(id), got = spv.tiers[id], sug = spvSuggest(d);
  for (const b of $('spvTier').querySelectorAll('button[data-t]')) { const t = +b.dataset.t; b.classList.toggle('on', got === t); b.classList.toggle('sug', !got && sug === t); }
  $('spvRated').textContent = `rated ${SPV_LIST.filter((x) => spv.tiers[x]).length} / ${SPV_LIST.length}`;
  const u = $('spvUnrated'); u.classList.toggle('on', spv.unrated); u.querySelector('b').textContent = spv.unrated ? 'ON' : 'OFF';
  const aw = $('spvAwe'), on = spv.awe.has(id); aw.classList.toggle('on', on); aw.querySelector('b').textContent = on ? '★' : '☆';
  $('spvAweN').textContent = `AWESOME ${SPV_LIST.filter((x) => spv.awe.has(x)).length}`;
}
function spvStep(dir, from = spv.i) { // PREV / NEXT; with UNRATED ONLY on, skips the rated ones
  const n = SPV_LIST.length;
  for (let k = 1; k <= n; k++) { const j = (((from + dir * k) % n) + n) % n; if (!spv.unrated || !spv.tiers[SPV_LIST[j]]) return spvShow(j); }
  spvTierUi(); $('spvRated').textContent = `all ${n} rated`;
}
function spvRate(t) {
  const id = SPV_LIST[spv.i]; spv.tiers[id] = t; spvSaveTiers(); spvTierUi(); sfx('card');
  clearTimeout(spv.adv); spv.adv = setTimeout(() => { if (SPV_LIST[spv.i] === id) spvStep(1); }, 400); // on to the next spell
}
const spvMax = (d) => (d.legendary ? 1 : 5);
function spvDummy(k) {
  const beh = spells[0] && spellDef(spells[0].id).sh.beh, close = k === 0 && (beh === 'orbit' || beh === 'gears'); // orbiting orbs / gears: the front dummy steps into their circle
  const [ox, oz] = close ? [0, -1.75] : SPV_DUMMIES[k], h = spv.home;
  let x = h[0] + ox, z = h[1] + oz;
  for (let q = 1; q < 8 && solid(x, z, false); q++) { x = h[0] + ox * (1 - q * 0.1); z = h[1] + oz * (1 - q * 0.1); } // a pillar: pull it in
  const e = spawnEnemy('skeleton', x, z);
  e.dummy = true; e.hp = e.maxHp = SPV_HP; e.affinity = SPV_NEUTRAL; e.hx = x; e.hz = z; e.hitT = 9; e.lastHp = e.hp;
  e.faceLock = x > h[0] + 0.2 ? -1 : 1; // faces Pip
  spv.dum[k] = e; spv.rt[k] = 0;
  return e;
}
function spvCd(d, lv) { // the real cooldown with Pip's multipliers (castSpells)
  const m = player.cdMul * player.g.cd * player.der.cd;
  if (d.unique) return uniqCd(d, lv) * m * (d.sh.beh === 'momentum' && lv >= 5 ? 0.8 : 1);
  return d.cd * m * (lv >= 5 && d.sh.beh === 'proj' ? 0.85 : 1);
}
function spvPanel() {
  const n = SPV_LIST.length, id = SPV_LIST[spv.i], d = spellDef(id), lv = spv.lv, T = SPELL_TIERS[spellTier(d)];
  const typ = SPV_TYPES.find(([k]) => k === spvType(d));
  const ico = $('spvIco'); ico.style.backgroundImage = `url(${spellIcon(d)})`; ico.style.setProperty('--c', d.color);
  $('spvName').textContent = d.name;
  const els = d.els.map((el) => `<span style="color:${ELEMENTS[el].color}">${ELEMENTS[el].name}</span>`).join(' + ');
  const cd = d.kills ? 'charges on kills' : `cooldown ${spvCd(d, lv).toFixed(1)}s`;
  $('spvMeta').innerHTML = `<span style="color:${T.color}">${T.name}</span>${typ[1] === T.name ? '' : ' · ' + typ[1]} · ${els} · ${cd}`;
  $('spvDesc').textContent = d.info;
  const ups = []; for (let k = 2; k <= lv; k++) ups.push(`<b>Lv ${k}</b> ${levelText(d, k)}`);
  $('spvLvTxt').innerHTML = d.legendary ? 'Legendary: does not level up' : ups.length ? ups.join(' · ') : 'Lv 1: base spell';
  $('spvNum').textContent = `${spv.i + 1} / ${n} · ${id}`;
  for (const b of $('spvLv').children) { const k = +b.dataset.lv; b.classList.toggle('on', k === lv); b.disabled = k > spvMax(d); }
  for (const b of $('spvGroups').children) b.classList.toggle('on', b.dataset.t === typ[0]);
  spvTierUi();
}
function spvShow(i) {
  const n = SPV_LIST.length; spv.i = ((i % n) + n) % n; clearTimeout(spv.adv);
  zooClear(); // the old spell's projectiles, rings, fields, beams, queued casts and the dummies all go
  spv.dum = []; spv.rt = [];
  player.x = spv.home[0]; player.z = spv.home[1]; player.vx = player.vz = 0;
  const id = SPV_LIST[spv.i], d = spellDef(id);
  spv.lv = Math.min(Math.max(1, spv.lv), spvMax(d));
  spells = [{ id, lv: spv.lv, t: 0.6 }]; buildSpellHud();
  for (let k = 0; k < SPV_DUMMIES.length; k++) spvDummy(k);
  spvPanel();
  try { const q = new URLSearchParams(location.search); q.set('spells', id); q.set('lv', spv.lv); history.replaceState(null, '', '?' + q.toString().replace(/=(&|$)/g, '$1')); } catch (e) { /* the URL is a convenience */ }
}
function spvSetLv(lv) {
  const s = spells[0]; if (!s) return;
  const d = spellDef(s.id); spv.lv = Math.min(Math.max(1, lv), spvMax(d));
  s.lv = spv.lv; s.t = Math.min(s.t, 0.4); buildSpellHud(); spvPanel();
  try { const q = new URLSearchParams(location.search); q.set('lv', spv.lv); history.replaceState(null, '', '?' + q.toString().replace(/=(&|$)/g, '$1')); } catch (e) { /* ignore */ }
}
function spvUpdate(dt) {
  if (!spv.on || !spv.home) return;
  for (let k = 0; k < SPV_DUMMIES.length; k++) {
    const e = spv.dum[k];
    if (!e) continue;
    if (e.dead) { spv.rt[k] += dt; if (spv.rt[k] > 1.1) spvDummy(k); continue; } // killed: a new one rises after ~1 s
    if (e.hp < e.lastHp - 0.01) e.hitT = 0; else e.hitT += dt;
    if (e.hitT > 1.5 && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * dt); // left alone for 1.5 s: heals up
    e.lastHp = e.hp;
    const dx = e.hx - e.x, dz = e.hz - e.z; // knocked away (earth, boulders, pulls): springs back to its post
    if (dx * dx + dz * dz > 0.01) { e.kx += dx * 14 * dt; e.kz += dz * 14 * dt; }
  }
  const s = spells[0];
  if (s && spellDef(s.id).kills && (s.ch || 0) < 1) s.ch = Math.min(1, (s.ch || 0) + dt / 2.5); // Meteor fills on kills: here on a timer
}
function spvKey(e) {
  if (!spv.on || e.repeat) return;
  if (e.code === 'ArrowRight') spvStep(1);
  else if (e.code === 'ArrowLeft') spvStep(-1);
  else if (/^(Digit|Numpad)[1-3]$/.test(e.code)) spvRate(+e.code.slice(-1)); // 1 / 2 / 3: rate the tier
  else if (e.code === 'KeyA') spvToggleAwe(); // A: in / out of the Daily's awesome list
  else if (e.code === 'BracketLeft' || e.code === 'Minus') spvSetLv(spv.lv - 1); // [ / ]: level down / up
  else if (e.code === 'BracketRight' || e.code === 'Equal') spvSetLv(spv.lv + 1);
}
function spvStart() {
  if (whenArt(spvStart)) return;
  document.documentElement.classList.add('zoo', 'spv');
  for (const sId of screens) $(sId).classList.add('hidden');
  G.daily = null; G.runDungeon = BIOMES[params.get('biome')] ? params.get('biome') : 'forge';
  newGame();
  for (const r of rooms) { r.cleared = true; r.waves = 0; r.totalWaves = 0; } // no room ever locks or spawns waves
  const r = spv.room = zoo.room = roomAt(player.x, player.z) || rooms[0];
  spv.home = [r.cx, r.cz + 2.6]; if (solid(spv.home[0], spv.home[1], false)) spv.home = [r.cx, r.cz + 1.4];
  spv.cam = [r.cx, r.cz - 0.6];
  zoo.spells = true; spells = []; buildSpellHud(); // castSpells runs (the zoo keeps it off until SPELLS ON)
  const st = document.createElement('style');
  st.textContent = `
html.spv #title, html.spv #toast, html.spv #banner, html.spv #spells, html.spv #stats, html.spv #right, html.spv #invBtn, html.spv #dlyBtn,
html.spv #dailyBtn, html.spv #tut, html.spv #reveal { display: none !important; }
#spvBar { position: absolute; z-index: 40; left: 50%; translate: -50% 0; bottom: calc(8px + env(safe-area-inset-bottom)); width: min(calc(100% - 12px), 640px);
  display: flex; flex-direction: column; gap: 6px; pointer-events: auto; }
#spvInfo { padding: 10px 16px; color: #fff; border: 0 solid transparent; border-image: url(ui/banner.webp) 95 fill / 20px / 0 stretch; filter: drop-shadow(0 6px 10px rgba(0,0,0,.6)); }
#spvHead { display: flex; align-items: center; gap: 10px; }
#spvIco { flex: none; width: 46px; height: 46px; border-radius: 9px; background: #120a1c center / cover no-repeat; box-shadow: 0 0 0 2px var(--c), 0 0 14px var(--c); }
#spvName { display: block; font: 900 17px "Cinzel", serif; letter-spacing: 1px; color: #ffe6a8; text-shadow: 0 2px 0 #2a0a10; line-height: 1.1; }
#spvMeta { display: block; margin-top: 2px; font: 800 11.5px/1.25 "Alegreya Sans", sans-serif; color: #e6d6ff; letter-spacing: .3px; }
#spvDesc { margin: 6px 0 0; font: 700 12.5px/1.25 "Alegreya Sans", sans-serif; color: #f3e6ff; }
#spvLvTxt { margin: 4px 0 0; font: 700 12px/1.25 "Alegreya Sans", sans-serif; color: #ffd98a; } #spvLvTxt b { color: #fff3c8; }
#spvNum { display: block; margin-top: 4px; font: 700 10.5px "Cinzel", serif; letter-spacing: 1px; color: #c9a7ff; font-style: normal; }
#spvRow { display: flex; align-items: center; gap: 6px; }
#spvTier { display: flex; align-items: center; gap: 6px; padding: 6px 8px; border-radius: 12px; background: rgba(14,6,24,.82); box-shadow: 0 3px 8px rgba(0,0,0,.5); }
#spvTier .tl { font: 900 11px "Cinzel", serif; letter-spacing: 1px; color: #c9a7ff; writing-mode: vertical-rl; rotate: 180deg; }
#spvTier button[data-t] { flex: 1 1 0; min-width: 0; height: 52px; cursor: pointer; border-radius: 10px; border: 2px solid #6a4a8a; background: rgba(40,16,60,.9); color: #f3e6ff;
  font: 900 22px "Cinzel", serif; box-shadow: 0 2px 6px rgba(0,0,0,.5); padding: 0; }
#spvTier button[data-t].sug { border-style: dashed; border-color: #c9a7ff; }
#spvTier button[data-t].on { border: 2px solid #ffd36a; color: #3a1c04; background: linear-gradient(#ffe9a6, #e0a83a); box-shadow: 0 0 12px rgba(255,200,90,.55); }
#spvTier .side { flex: 0 0 auto; display: flex; flex-direction: column; align-items: center; gap: 4px; }
#spvRated { font: 800 11px "Alegreya Sans", sans-serif; color: #ffd98a; white-space: nowrap; }
#spvUnrated { cursor: pointer; height: 30px; padding: 0 8px; border-radius: 8px; border: 2px solid #6a4a8a; background: rgba(20,8,32,.9); color: #e6d6ff; font: 900 10px "Cinzel", serif; white-space: nowrap; }
#spvUnrated b { color: #ff9aa8; } #spvUnrated.on b { color: #7dff9a; } #spvUnrated.on { border-color: #7dff9a; }
#spvAwe { flex: 0 0 auto; width: 66px; height: 52px; cursor: pointer; border-radius: 10px; border: 2px solid #6a4a8a; background: rgba(40,16,60,.9); color: #f3e6ff; padding: 0 2px;
  display: flex; flex-direction: column; align-items: center; justify-content: center; font: 900 8.5px/1.05 "Cinzel", serif; letter-spacing: .3px; box-shadow: 0 2px 6px rgba(0,0,0,.5); }
#spvAwe b { font-size: 20px; line-height: 1; color: #c9a7ff; }
#spvAwe.on { border-color: #7dffe0; background: linear-gradient(#2a5a6a, #12323e); box-shadow: 0 0 12px rgba(125,255,224,.5); } #spvAwe.on b { color: #ffe36a; }
#spvAweN { font: 800 11px "Alegreya Sans", sans-serif; color: #7dffe0; white-space: nowrap; }
#spvTier button:active { transform: scale(.95); }
#spvRow > button { --bh: 48px; flex: none; height: var(--bh); padding: 0 calc(var(--bh) * .42); background: none; box-shadow: none; border-radius: 0; cursor: pointer;
  font: 900 14px "Cinzel", "Cormorant SC", serif; letter-spacing: 1px; white-space: nowrap; color: #f3e6ff; text-shadow: 0 1px 0 #1a0628;
  border: 0 solid transparent; border-image: url(ui/btn_purple.webp) 0 80 fill / 0 calc(var(--bh) * .548) / 0 stretch; filter: drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#spvRow > #spvNext { color: #4a2506; text-shadow: 0 1px 0 rgba(255,246,200,.85); border-image: url(ui/btn_gold.webp) 0 130 fill / 0 calc(var(--bh) * .514) / 0 stretch;
  filter: drop-shadow(0 0 10px rgba(255,190,70,.35)) drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#spvLv { flex: 1 1 0; min-width: 0; display: flex; justify-content: center; gap: 4px; }
#spvLv button, #spvGroups button { cursor: pointer; border-radius: 9px; border: 2px solid #6a4a8a; background: rgba(20,8,32,.82); color: #e6d6ff; box-shadow: 0 2px 6px rgba(0,0,0,.5);
  font: 900 13px "Cinzel", serif; padding: 0; }
#spvLv button { flex: 0 1 44px; height: 40px; min-width: 30px; }
#spvLv button.on, #spvGroups button.on { border-color: #ffd36a; color: #3a1c04; background: linear-gradient(#ffe9a6, #e0a83a); box-shadow: 0 0 10px rgba(255,200,90,.5); }
#spvLv button:disabled { opacity: .3; cursor: default; }
#spvRow button:active, #spvGroups button:active, #spvSlow:active { transform: scale(.95); }
#spvTop { position: absolute; z-index: 40; top: calc(10px + env(safe-area-inset-top)); left: 10px; right: 10px; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
#spvTop > div { display: flex; align-items: center; gap: 6px; }
#spvTitle { flex: 1; font: 900 13px "Cinzel", serif; letter-spacing: 2px; color: #ffe6a8; text-shadow: 0 2px 0 #2a0a10, 0 0 10px rgba(0,0,0,.8); }
#spvSlow { --bh: 38px; height: var(--bh); padding: 0 calc(var(--bh) * .5); background: none; box-shadow: none; border-radius: 0; cursor: pointer; white-space: nowrap; pointer-events: auto;
  font: 900 12px "Cinzel", "Cormorant SC", serif; letter-spacing: 1px; color: #f3e6ff; text-shadow: 0 1px 0 #1a0628;
  border: 0 solid transparent; border-image: url(ui/btn_purple.webp) 0 80 fill / 0 calc(var(--bh) * .548) / 0 stretch; filter: drop-shadow(0 3px 4px rgba(0,0,0,.55)); }
#spvSlow b { color: #ff9aa8; } #spvSlow.on b { color: #7dff9a; }
#spvGroups { justify-content: center; }
#spvGroups button { height: 30px; padding: 0 9px; white-space: nowrap; font-size: 11px; letter-spacing: .5px; pointer-events: auto; }
@media (max-width: 420px) { #spvRow > button { --bh: 44px; padding: 0 16px; font-size: 11.5px; letter-spacing: .5px; } #spvInfo { padding: 8px 12px; } #spvName { font-size: 15px; }
  #spvDesc { font-size: 11.5px; } #spvLvTxt, #spvMeta { font-size: 11px; } #spvIco { width: 40px; height: 40px; } #spvLv button { height: 36px; } #spvGroups button { padding: 0 7px; font-size: 10px; } }
@media (max-width: 350px) { #spvRow .lbl { display: none; } }
@media (max-height: 460px) { #spvTier button[data-t], #spvAwe { height: 40px; font-size: 18px; } #spvAwe { font-size: 7.5px; } #spvAwe b { font-size: 16px; } #spvBar { bottom: calc(4px + env(safe-area-inset-bottom)); gap: 4px; } #spvInfo { padding: 5px 14px; } #spvDesc { margin-top: 3px; } #spvRow > button { --bh: 40px; } #spvLv button { height: 34px; } }`;
  document.head.appendChild(st);
  const bar = document.createElement('div'); bar.id = 'spvBar';
  bar.innerHTML = '<div id="spvInfo"><div id="spvHead"><i id="spvIco"></i><div><b id="spvName">SPELL VIEWER</b><small id="spvMeta">Loading...</small></div></div>' +
    '<p id="spvDesc"></p><p id="spvLvTxt"></p><i id="spvNum"></i></div>' +
    '<div id="spvTier"><span class="tl">TIER</span>' + [1, 2, 3].map((t) => `<button data-t="${t}" aria-label="Tier ${t}">T${t}</button>`).join('') +
    '<button id="spvAwe" aria-label="Daily awesome spell (A)"><b>☆</b>DAILY AWESOME</button>' +
    '<div class="side"><small id="spvRated"></small><small id="spvAweN"></small><button id="spvUnrated">UNRATED ONLY <b>OFF</b></button></div></div>' +
    '<div id="spvRow"><button id="spvPrev" aria-label="Previous spell">◀<span class="lbl"> PREV</span></button><div id="spvLv">' +
    [1, 2, 3, 4, 5].map((k) => `<button data-lv="${k}" aria-label="Level ${k}">Lv${k}</button>`).join('') +
    '</div><button id="spvNext" aria-label="Next spell"><span class="lbl">NEXT </span>▶</button></div>';
  const top = document.createElement('div'); top.id = 'spvTop';
  top.innerHTML = '<div><span id="spvTitle">SPELL VIEWER</span><button id="spvSlow">SLOW-MO <b>OFF</b></button></div><div id="spvGroups">' +
    SPV_TYPES.filter(([k]) => SPV_LIST.some((id) => spvType(spellDef(id)) === k)).map(([k, name, chip]) => `<button data-t="${k}">${chip || name}</button>`).join('') + '</div>';
  $('app').append(bar, top);
  const tap = (el, fn) => el.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); ev.preventDefault(); fn(); }); // stopPropagation: not a joystick drag
  tap($('spvPrev'), () => spvStep(-1)); tap($('spvNext'), () => spvStep(1));
  for (const b of $('spvTier').querySelectorAll('button[data-t]')) tap(b, () => spvRate(+b.dataset.t));
  tap($('spvAwe'), spvToggleAwe);
  tap($('spvUnrated'), () => { spv.unrated = !spv.unrated; spvTierUi(); if (spv.unrated && spv.tiers[SPV_LIST[spv.i]]) spvStep(1); });
  for (const b of $('spvLv').children) tap(b, () => { if (!b.disabled) spvSetLv(+b.dataset.lv); });
  for (const b of $('spvGroups').children) tap(b, () => { const f = SPV_LIST.findIndex((id) => spvType(spellDef(id)) === b.dataset.t); if (f >= 0) { if (spv.unrated && spv.tiers[SPV_LIST[f]]) spvStep(1, f); else spvShow(f); } });
  tap($('spvSlow'), () => { zoo.slow = !zoo.slow; $('spvSlow').classList.toggle('on', zoo.slow); $('spvSlow').querySelector('b').textContent = zoo.slow ? 'ON' : 'OFF'; });
  for (const el of [bar, top]) el.addEventListener('pointerdown', (ev) => ev.stopPropagation()); // taps on the panel never steer Pip
  spv.on = true; spvLoadTiers(); spvLoadAwe();
  const want = (params.get('spells') || '').toLowerCase(), norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  let first = want ? SPV_LIST.findIndex((id) => id.toLowerCase() === want) : -1;
  if (first < 0 && want) first = SPV_LIST.findIndex((id) => norm(spellDef(id).name) === norm(want) || id.toLowerCase() === 'u.' + want);
  spv.lv = Math.min(5, Math.max(1, +params.get('lv') || 1));
  later(1.6, () => spvShow(Math.max(0, first))); // after Pip lands
  window.__spv = { get i() { return spv.i; }, get id() { return SPV_LIST[spv.i]; }, get lv() { return spv.lv; }, list: SPV_LIST, show: spvShow, setLv: spvSetLv, rate: spvRate, get tiers() { return spv.tiers; },
    get dummies() { return spv.dum.map((e) => e && [e.dead ? 'dead' : 'up', Math.round(e.hp)]); }, get casts() { return player.casts; } }; // headless checks
}
let portalReady; window.__portalReady = new Promise((r) => { portalReady = r; }); // set before the page's load event; portal shims wait on it
(async function boot() {
  // app build: a save iOS dropped from localStorage comes back from native storage; portal build: the cloud save (CrazyGames
  // SDK data) comes back on a new device or after the browser dropped the iframe's storage. Reload once so every module
  // reads it. The rank keeps a fresh default meta (new t, no progress) from ever beating the real one.
  const reloadOk = () => { let ok = false; try { ok = Date.now() - (+sessionStorage.getItem('rbd_restored') || 0) > 10000; sessionStorage.setItem('rbd_restored', Date.now()); } catch (e) { /* no reload loop */ } return ok; };
  const metaRank = (key, o) => (key !== META_KEY || !o || o.fresh ? 0 : 1 + (+(o.stats && o.stats.runs) || 0) * 4 + (o.prologueDone ? 2 : 0) + (o.tutDone ? 1 : 0));
  const late = () => { if (ZOO || !reloadOk()) return false; setTimeout(() => location.reload(), 0); return true; }; // the cloud answered after the boot wait with better saves
  if (await restore([META_KEY, 'rbd_monet_v1', RUN_KEY], RUN_KEY, RUN_END, { rank: metaRank, late, debug: params.has('cgdebug') })) {
    if (reloadOk()) { location.reload(); return; }
    unlock();
  }
  // progress without a meta (a continue-able run, shards, runs) but the meta looks new: a returning player, never the
  // half state where the prologue flag is missing mid-run (that froze the chest timer at 10:00)
  if (!AUTO && !BENCH && !ZOO && !meta.prologueDone && (loadRun() || (meta.stats.runs || 0) > 0 || meta.stats.shardsTotal > 0 || meta.tutDone)) { meta.prologueDone = true; meta.tutDone = true; saveMeta(); }
  resize();
  renderTitle(); if (window.__titleReady) window.__titleReady(); // the menu needs only the save, not the art: fill it in and fade it in now (index.html)
  // a new player boots straight into the prologue (same test as below): load only its art now
  const proFirst = !AUTO && !BENCH && !ZOO && G.state === 'title' && (PROLOGUE || !meta.prologueDone && (meta.stats.runs || 0) === 0 && !meta.tutDone && !loadRun());
  await loadSheets(proFirst);
  try { ICONS = new Set(await (await fetch('icons/manifest.json', { cache: 'no-cache' })).json()); } catch (e) { /* no painted icons yet */ }
  loadImg(CHEST_IMG).catch(() => {}); // warm the cache: the chest reveal drops it in 0.35 s
  heartImg = iconURL('items', 2, 44); coinImg = iconURL('items', 0, 32);
  $('coinIco').style.backgroundImage = `url(${coinImg})`;
  renderTitle();
  // a dungeon behind the title screen
  player = newPlayer(); player.mesh.visible = false; player.shadow.visible = false;
  G.biome = BIOMES.crypt; applyBiomeLight(G.biome);
  genFloor(1); buildWorld(biomePalette(G.biome)); const s = rooms[0];
  camTarget.set(s.cx, 0, s.cz); G.curRoom = null;
  s.flames.slice(0, 4).forEach((f, k) => torchLights[k].position.copy(f.position).add(new THREE.Vector3(0, 0.3, 0.5)));
  killMesh(player.mesh); scene.remove(player.shadow); killGlow(player.staffGlow); player = null;
  warmShaders();
  $('fade').style.opacity = 0;
  // first visit: no menu and no dungeon reveal, straight into the prologue (or floor 1 if it was seen); the menu is there from run 2
  if (!AUTO && !BENCH && !ZOO && G.state === 'title' && $('reveal').classList.contains('hidden') && (PROLOGUE || (meta.stats.runs || 0) === 0 && !meta.tutDone && !loadRun())) {
    if (PROLOGUE || !meta.prologueDone) startPrologue(); // the betrayal prologue once, then straight into floor 1
    else { G.runDungeon = meta.lastDungeon = 'crypt'; saveMeta(); startRun(); }
  }
  document.documentElement.classList.remove('autostart'); // the menu comes back if boot didn't start a run
  if (G.state === 'title') setTimeout(loginPop, 900); // the login calendar, once a day
  portalReady(); // portal shims: the game is playable now (loadingStop)
  if (ZOO) zooStart();
  if (AUTO) {
    $('title').classList.add('hidden'); if (PROLOGUE) startPrologue(); else newGame();
    if (FFWD > 0) { silent = true; const steps = Math.round(FFWD * 60); for (let i = 0; i < steps; i++) tick(1 / 60); silent = false; }
  }
  if (REC) toggleRecording(REC);
  if (BENCH) later(2.5, () => {
    spells = (DEBUG_SPELLS.length ? DEBUG_SPELLS /* ?bench&spell=a,b: the bench's spell list */ : ['arcane.bolt', 'fire.orb', 'frost.nova', 'storm.chain', 'venom.fan', 'arcane.halo', 'fire.rain', 'shadow.wisp', 'fire+frost.field', 'meteor', 'hole']).map((id) => ({ id, lv: 5, t: Math.random() }));
    const r = rooms.find((q) => q.type === 'combat') || rooms[1];
    player.x = r.cx; player.z = r.cz;
    later(0.5, () => { if (!r.active) enterRoom(r); r.waves = 0; G.swarm = { room: r, t: 99999, spawnT: 0 }; });
  });
  if (BENCH) window.__dbg = () => ({ texts: texts.length, bolts: bolts.length, projs: projs.length, eprojs: eprojs.length, rings: rings.length, meteors: meteors.length, beams: beams.length, gusts: gusts.length, fires: fires.length, timers: timers.length, glows: glowsLive.length, shadows: shadowsLive.length, sceneKids: scene.children.length, worldKids: world ? world.children.length : 0 }); // bench: live effect counts
  window.__win = () => showVictory();
  // QA hooks (debug only): open any overlay directly for layout checks
  window.__qa = { toast, banner, tutShow, showSwapCompare, offerRevive, openVChest, openLuckyChest, showVictory, playerDie, showScreen, confirmNewRun, rollAndRevealDungeon, pauseGame, rollGear: (r) => rollGear(Math.random, 5, 0, r) };
  window.__game = { G, get input() { return input; }, lvOpts: () => levelUpOptions().map((c) => c.tag + ': ' + c.name), lvOpen: () => openCards('LEVEL UP', levelUpOptions()), get player() { return player; }, spawn: (type, x, z, elite) => spawnEnemy(type, x, z, elite), recalc: () => recalcStats(), reveal: (o) => chestReveal(o), vchest: (f) => openVChest(f), lucky: () => openLuckyChest(true), get pickups() { return pickups; }, cell: (x, z) => cellAt(x, z), dps: (detail) => expectedDps(detail), hpMul: () => enemyHpMul(), dropGear: (r, given) => dropGear(player.x, player.z, r || 0, given), drop: (k) => dropPickup(player.x, player.z, k || 'coin'), get enemies() { return enemies; }, get eprojs() { return eprojs; }, get rocks() { return rocks; }, get spears() { return spears; }, get fballs() { return fballs; }, get beams() { return beams; }, get gusts() { return gusts; }, phx: () => phxs.filter((b) => b.on).map((b) => [b.phase, +b.x.toFixed(1), +b.z.toFixed(1), b.out.size + b.back.size]), booms: () => booms.filter((b) => b.on).length, get frings() { return frings; }, get ices() { return ices; }, get portals() { return portals; }, get rooms() { return rooms; }, get hazards() { return hazards; }, get fires() { return fires; }, get clouds() { return clouds; }, get props() { return props; }, spells: () => spells, tick, cards: () => openCards('ROOM CLEARED', upgradeOptions()), bossCards: (id) => openCards('BOSS SPELL', bossOffer(id || Object.keys(BOSS_SPELLS)[0])), chest: () => { G.run.boon = true; openCards('TREASURE', boonOptions()); }, chestOpts: () => boonOptions().map((c) => c.tag + ': ' + c.name + ' | ' + c.info), bossOpts: (id) => bossOffer(id || Object.keys(BOSS_SPELLS)[0]).map((c) => c.tag + ': ' + c.name + ' | ' + c.info), setFloor: (n) => { G.floor = n; }, get meta() { return meta; }, goDaily: () => startDaily(), setSpells: (L) => { spells = L.map(([id, lv]) => ({ id, lv, t: 0 })); buildSpellHud(); }, castNow: (id, fake) => { const t = nearestEnemy(player.x, player.z, 20) || (fake && { x: player.x + 4, z: player.z + 0.6, r: 0.4, hp: 1, dead: false }); if (t) castSpell({ id, lv: 1, t: 0 }, spellDef(id), t); },
    meta, daily: { start: startDaily, of: dailyOf, nextFloor, win: dailyWin, clear: (r) => clearRoom(r), get fairy() { return fairy; }, spawnFairy } };
  requestAnimationFrame(frame);
})();
