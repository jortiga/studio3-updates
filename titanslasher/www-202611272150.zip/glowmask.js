// glowmask.js: emissive masks for painted sprites + selective bloom (three.js r15x+). Shared by every studio game:
// canonical copy E:\jgmkr\tools\web\glowmask.js; copy it into a game with `python tools/glow_mask.py --sync-js game/`.
// Masks come from tools/glow_mask.py (<stem>_glow.webp). A packed RGB mask carries 3 independent glow groups
// (convention: R = cracks / energy lines, G = eyes / gems, B = runes); a grayscale mask is one group (mono: true).
//
//   import { addGlow, GLOW, GlowDriver, renderGlowPass } from './glowmask.js';
//   const g = addGlow(material, maskTex, { cols: [0x53f3ff, 0x9ff8ff, 0x53f3ff], k: [1, 1.4, 1.2], rate: [1.3, 2.2, 3], depth: [.15, .25, .3] });
//   GLOW.time.value = t;                         // once per frame (shared by every glow material)
//   g.glowK.value.set(r, gEyes, bRunes);         // per-group intensity from game code (or use GlowDriver)
//   mesh.layers.enable(GLOW_LAYER);              // only if you use the selective bloom pass
//
// Cost: one extra texture sample per fragment of a masked sprite, a few ALU ops. No extra pass per sprite. The optional
// selective bloom pass re-renders only GLOW_LAYER meshes once, into the (quarter-res) bloom input.
import * as THREE from 'three';

export const GLOW = { time: { value: 0 }, only: { value: 0 } }; // shared uniforms: time (set per frame), only = 1 during the glow pass
export const GLOW_LAYER = 3;

THREE.ShaderChunk.glowmask_pars_fragment = /* glsl */`
uniform sampler2D glowMap; uniform vec3 glowK; uniform vec3 glowC0; uniform vec3 glowC1; uniform vec3 glowC2;
uniform vec3 glowRate; uniform vec3 glowDepth; uniform float glowFlick; uniform float glowSrc; uniform float glowPhase;
uniform float glowBloom; uniform float glowTime; uniform float glowOnly;
vec3 glowEmit(vec2 uv, vec3 src) {
  vec3 m = texture2D(glowMap, uv).rgb;
#ifdef GLOW_MONO
  m = vec3(m.r, 0., 0.);
#endif
  vec3 p = 1. + glowDepth * sin(glowTime * glowRate + glowPhase + vec3(0., 1.7, 3.4));           // per-group pulse
  float fl = 1. - glowFlick * fract(sin(floor(glowTime * 15. + glowPhase * 7.) * 12.9898) * 43758.5453); // flicker
  vec3 k = m * glowK * max(p, 0.) * fl;
  vec3 hue = src / max(max(src.r, max(src.g, src.b)), .05);                                          // painted colour, full bright
  return k.x * mix(glowC0, hue * glowC0, glowSrc) + k.y * mix(glowC1, hue * glowC1, glowSrc) + k.z * mix(glowC2, hue * glowC2, glowSrc);
}`;
// runs after the material has written gl_FragColor (lit, fogged): adds the emissive, or in the glow pass outputs ONLY it
THREE.ShaderChunk.glowmask_fragment = /* glsl */`
{ vec3 ge = glowEmit(GLOW_UV, GLOW_SRC);
  if (glowOnly > .5) gl_FragColor = vec4(ge * glowBloom, gl_FragColor.a); else gl_FragColor.rgb += ge; }`;

const col3 = (c, d) => (Array.isArray(c) ? new THREE.Color(c[0], c[1], c[2]) : new THREE.Color(c ?? d)); // 0xhex, '#css', Color or [r, g, b] 0..1
export function glowUniforms(mask, o = {}) {
  const C = o.cols || [o.col, o.col, o.col]; // cols: per-group [R, G, B] colours; col: one colour for every group
  const v3 = (a, d) => Array.isArray(a) ? new THREE.Vector3(...a) : new THREE.Vector3(a ?? d, a ?? d, a ?? d);
  return {
    glowMap: { value: mask }, glowK: { value: v3(o.k, 1) },
    glowC0: { value: col3(C[0], 0x53f3ff) }, glowC1: { value: col3(C[1], 0x53f3ff) }, glowC2: { value: col3(C[2], 0x53f3ff) },
    glowRate: { value: v3(o.rate, 2) }, glowDepth: { value: v3(o.depth, 0) }, glowFlick: { value: o.flicker ?? 0 },
    glowSrc: { value: o.src ?? .6 }, glowPhase: { value: o.phase ?? Math.random() * 6.28 }, glowBloom: { value: o.bloom ?? 1.4 },
    glowTime: GLOW.time, glowOnly: GLOW.only,
  };
}

// Add an emissive mask to a material. Returns the glow uniforms (also material.userData.glow).
//  - ShaderMaterial: writes `#include <glowmask_pars_fragment>` before main() and `#include <glowmask_fragment>` at the end of
//    main() unless the shader already has them. o.uv / o.src name the GLSL uv and texel colour (default vUv / gl_FragColor.rgb).
//  - Built-in materials (MeshBasic/Standard/Lambert/Sprite...): patched in onBeforeCompile (uv = vMapUv, so they need a .map).
// Options: col (one colour, 0xhex or [r, g, b]) or cols ([R, G, B] group colours), k (intensity or [r, g, b]), rate / depth (pulse speed / depth per
// group), flicker 0..1, src 0..1 (how much the painted colour tints the glow), bloom (gain in the glow pass), mono (grayscale mask).
export function addGlow(mat, mask, o = {}) {
  const u = glowUniforms(mask, o);
  mat.userData.glow = u;
  if (mask) { mask.colorSpace = THREE.NoColorSpace; mask.needsUpdate = true; }
  if (mat.isShaderMaterial) {
    Object.assign(mat.uniforms, u);
    mat.defines = { ...(mat.defines || {}), GLOWMASK: '', GLOW_UV: o.uv || 'vUv', GLOW_SRC: o.src_var || 'gl_FragColor.rgb', ...(o.mono ? { GLOW_MONO: '' } : {}) };
    let fs = mat.fragmentShader;
    if (!fs.includes('glowmask_pars_fragment')) fs = fs.replace(/void\s+main\s*\(/, '#include <glowmask_pars_fragment>\nvoid main(');
    if (!fs.includes('glowmask_fragment>')) { const i = fs.lastIndexOf('}'); fs = fs.slice(0, i) + '\n#include <glowmask_fragment>\n' + fs.slice(i); }
    mat.fragmentShader = fs; mat.needsUpdate = true;
  } else {
    mat.defines = { ...(mat.defines || {}), GLOWMASK: '', GLOW_UV: 'vMapUv', GLOW_SRC: 'diffuseColor.rgb', ...(o.mono ? { GLOW_MONO: '' } : {}) };
    const prev = mat.onBeforeCompile;
    mat.onBeforeCompile = (sh, r) => { if (prev) prev(sh, r); Object.assign(sh.uniforms, u);
      sh.fragmentShader = sh.fragmentShader.replace(/void\s+main\s*\(/, '#include <glowmask_pars_fragment>\nvoid main(')
        .replace('#include <opaque_fragment>', '#include <opaque_fragment>\n#include <glowmask_fragment>'); };
    mat.customProgramCacheKey = () => 'glowmask' + (o.mono ? 'm' : '');
    mat.needsUpdate = true;
  }
  return u;
}

// Game-side intensity: base levels per group + decaying kicks (hit flashes, roar flares) + a master fade.
//   const d = new GlowDriver([1, 1, 1]); d.kick('r', 2, 6);  // R +2, decays at 6/s
//   d.update(dt); d.apply(glowUniformsOrArray);
export class GlowDriver {
  constructor(base = [1, 1, 1]) { this.base = base.slice(); this.add = [0, 0, 0]; this.dec = [6, 6, 6]; this.fade = 1; this.mul = [1, 1, 1]; this.k = [0, 0, 0]; }
  kick(ch, amt, decay = 6) { const i = typeof ch === 'number' ? ch : 'rgb'.indexOf(ch); this.add[i] = Math.max(this.add[i], amt); this.dec[i] = decay; }
  update(dt) { for (let i = 0; i < 3; i++) { this.add[i] *= Math.exp(-this.dec[i] * dt); this.k[i] = (this.base[i] * this.mul[i] + this.add[i]) * this.fade; } return this.k; }
  apply(list) { for (const u of [].concat(list)) { const g = u.glowK ? u : u.userData?.glow; if (g) g.glowK.value.set(this.k[0], this.k[1], this.k[2]); } }
}

// Selective bloom: render ONLY the GLOW_LAYER meshes, each outputting just its emissive (black body, so it still occludes the
// bloom behind it), into `target` (the bloom input, e.g. the bright-pass result) WITHOUT clearing it. Replace a whole-frame
// threshold with this, or run it after a high-threshold bright pass so slashes / sparks still bloom.
export function renderGlowPass(renderer, scene, camera, target) {
  const mask = camera.layers.mask, ac = renderer.autoClear, bg = scene.background;
  camera.layers.set(GLOW_LAYER); renderer.autoClear = false; scene.background = null; GLOW.only.value = 1;
  renderer.setRenderTarget(target); renderer.render(scene, camera);
  GLOW.only.value = 0; scene.background = bg; renderer.autoClear = ac; camera.layers.mask = mask;
}
