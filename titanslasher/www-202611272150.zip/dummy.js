// Lobby TRAINING DUMMY (user 11-26: "a dummy is not a golem, just a training totem"; "there should be no jump to fight").
// Codex-painted cutout parts (tools/make_dummy.py -> art/dummy/: base, body, arms, head, chip1-3; body_glow = the cyan rune).
// Rig: base (planted in the cloud sea) > pivot at the post joint (tilt spring + squash) > body, crossbar arms (own spring, behind
// the body) and sack head (own spring, lags the body). Every hit tilts it AWAY from the tap and it springs back, with a squash,
// chips (painted splinters / straw), and a rune flash. Idle = a gentle sway. crumble(): it bursts apart and the base sinks while
// the titan rises behind it (main.js handover). restore(): it drops back in from above and lands with a squash.
// Hit test = alpha of the parts under the tap (raycast UV -> 128 px alpha map), like the titan's puppet.hit().
import * as THREE from 'three';

// 11-26 ?style=ink: art/dummy_ink/ (tools/make_dummy_ink.py), the same parts repainted in the ink look on IDENTICAL canvases
// (same sizes / bounds / pivots, so PX fits both), with a muted teal rune glow
const INK = new URLSearchParams(location.search).get('style') === 'ink';
export const DUMMY_DIR = INK ? 'art/dummy_ink' : 'art/dummy';
const GLOW_COL = INK ? [.45, .9, .82] : [.4, .95, 1], GLOW_BLOOM = INK ? 1.6 : 2.4;
const PX = { baseH: 392, joint: 330, bodyH: 648, armsY: 505, headY: 578, total: 1270 }; // assembly in painted px (y up from the base bottom)
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rand = (a, b) => a + Math.random() * (b - a);

function alphaMap(tex) { // 128 px alpha grid of a texture (CPU hit test)
  const img = tex.image, s = 128 / Math.max(img.width, img.height), w = Math.max(1, Math.round(img.width * s)), h = Math.max(1, Math.round(img.height * s));
  const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.drawImage(img, 0, 0, w, h);
  const d = g.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) a[i] = d[i * 4 + 3]; return { w, h, a };
}

export class Dummy {
  // T: { base, body, arms, head, chips: [..], glow }  o: { spriteMat, fx: { sparks(p, n, dir), chipsHit(p) ... }, ro }
  constructor(scene, T, o) {
    this.T = T; this.fx = o.fx || {}; this.root = new THREE.Group(); scene.add(this.root);
    const ro = o.ro ?? 330, mk = (tex, ax, ay, r, mo = {}) => { // ax/ay: anchor (0..1) of the plane origin
      const g = new THREE.PlaneGeometry(1, 1); g.translate(.5 - ax, .5 - ay, 0);
      const m = new THREE.Mesh(g, o.spriteMat(tex, { fogNear: 9999, fogFar: 99999, glow: 0, ...mo })); m.renderOrder = ro + r; m.userData.am = alphaMap(tex); m.userData.asp = tex.image.width / tex.image.height; return m; };
    this.base = mk(T.base, .5, 0, 0);
    this.pivot = new THREE.Group(); this.root.add(this.base, this.pivot);
    this.body = mk(T.body, .5, 0, 2, T.glow ? { glowMap: T.glow, glowOpts: { mono: true, col: GLOW_COL, k: 1, rate: 2.2, depth: .25, src: .5, bloom: GLOW_BLOOM } } : {});
    this.armsG = new THREE.Group(); this.arms = mk(T.arms, .5, .5, 1); this.armsG.add(this.arms);
    this.headG = new THREE.Group(); this.head = mk(T.head, .5, .08, 3); this.headG.add(this.head);
    this.pivot.add(this.armsG, this.body, this.headG);
    this.parts = [this.head, this.body, this.arms, this.base]; // front-most first (hit test order)
    this.glowU = this.body.material.userData.glow || null;
    this.chips = Array.from({ length: 18 }, (_, i) => { const t = T.chips[i % T.chips.length]; const m = mk(t, .5, .5, 4); m.visible = false; this.root.add(m); return { m, v: new THREE.Vector3(), w: 0, life: 0, max: 1, s: 1 }; });
    this.ray = new THREE.Raycaster();
    this.sp = { th: 0, thV: 0, sq: 0, sqV: 0, hd: 0, hdV: 0, ar: 0, arV: 0 };
    this.kick = 0; this.flashK = 0; this.state = 'off'; this.st = 0; this.k = .01; this.root.visible = false;
  }
  get present() { return this.state === 'idle' || this.state === 'drop' || (this.state === 'crumble' && this.st < .9); }
  // place by screen fraction: foot on the cloud sea (y seaY) under screen point (fx*W, fy*H), height = hFrac of the screen
  layout(camera, W, H, portrait, seaY = -.5) {
    // 11-26 UI pass: centred and fully visible between the top icon row and the bottom FIGHT button (no lobby plate any more).
    // Hero idles bottom-left.
    const fx = .5, fy = portrait ? .8 : .8, hFrac = portrait ? .46 : .56; // 11-26 thumb zone: the tap target sits middle-to-low, UI is all at the top
    this.ray.setFromCamera({ x: fx * 2 - 1, y: -fy * 2 + 1 }, camera); const o = this.ray.ray.origin, d = this.ray.ray.direction;
    let t = (seaY - o.y) / d.y; if (!(t > 0)) t = 30; const p = o.clone().addScaledVector(d, t); if (p.z < -32) p.copy(o).addScaledVector(d, (-32 - o.z) / d.z); // stays in front of the titan (front plane z -40)
    this.home = p; this.root.position.copy(p);
    camera.getWorldDirection(this.ray.ray.direction); const depth = this.ray.ray.direction.dot(p.clone().sub(camera.position));
    const worldH = hFrac * 2 * depth * Math.tan(camera.fov * Math.PI / 360); this.k = worldH / PX.total; const k = this.k;
    const sz = (m, tex, mul = 1) => m.scale.set(tex.image.width * k * mul, tex.image.height * k * mul, 1);
    sz(this.base, this.T.base); sz(this.body, this.T.body); sz(this.arms, this.T.arms, 1.04); sz(this.head, this.T.head);
    this.pivotY = PX.joint * k; this.armsY = PX.armsY * k; this.headY = PX.headY * k;
    if (this.state !== 'crumble') this.reset();
  }
  reset() {
    const s = this.sp; Object.assign(s, { th: 0, thV: 0, sq: 0, sqV: 0, hd: 0, hdV: 0, ar: 0, arV: 0 });
    this.pivot.position.set(0, this.pivotY, 0); this.pivot.rotation.set(0, 0, 0); this.armsG.position.set(0, this.armsY, .01); this.armsG.rotation.set(0, 0, 0);
    this.headG.position.set(0, this.headY, .02); this.headG.rotation.set(0, 0, 0); this.base.position.set(0, 0, 0); this.body.position.z = .015;
    this.free = null; this.setAlpha(1);
  }
  setAlpha(a) { for (const m of this.parts) m.material.uniforms.alpha.value = a; }
  // screen tap -> { p: world point on the part, part } or null. 8-point margin ring like the titan (r px)
  hit(sx, sy, camera, W, H, r = 8) {
    if (!this.present || !this.root.visible) return null;
    this.root.updateMatrixWorld(true);
    const test = (x, y) => { this.ray.setFromCamera({ x: x / W * 2 - 1, y: -(y / H) * 2 + 1 }, camera);
      for (const m of this.parts) { if (!m.visible || m.material.uniforms.alpha.value < .25) continue; const hit = this.ray.intersectObject(m, false)[0]; if (!hit || !hit.uv) continue;
        const A = m.userData.am, ix = clamp(Math.floor(hit.uv.x * A.w), 0, A.w - 1), iy = clamp(Math.floor((1 - hit.uv.y) * A.h), 0, A.h - 1);
        if (A.a[iy * A.w + ix] > 90) return { m, p: hit.point }; } return null; };
    let h = test(sx, sy); for (let i = 0; i < 8 && !h; i++) { const a = i * Math.PI / 4; h = test(sx + Math.cos(a) * r, sy + Math.sin(a) * r); }
    if (!h) return null;
    this.ray.setFromCamera({ x: sx / W * 2 - 1, y: -(sy / H) * 2 + 1 }, camera); const o = this.ray.ray.origin, d = this.ray.ray.direction; // number + slash at the exact tap point (dummy depth)
    const p = o.clone().addScaledVector(d, (this.root.position.z + .3 - o.z) / d.z);
    return { p, part: h.m === this.head ? 'head' : h.m === this.arms ? 'arms' : h.m === this.base ? 'base' : 'body' };
  }
  // a hit at world point p: tilt away from the tap side, squash, head / arms wobble, rune flash, chips + sparks
  impact(p, part = 'body', crit = false) {
    const loc = this.root.worldToLocal(p.clone()), s = this.sp, dir = Math.abs(loc.x) < this.k * 30 ? (Math.random() < .5 ? 1 : -1) : Math.sign(loc.x), st = crit ? 1.7 : 1;
    s.thV += dir * 2.6 * st; s.sqV -= 2.4 * st; s.hdV += dir * (part === 'head' ? 9 : 4) * st; s.arV += -dir * (part === 'arms' ? 7 : 3) * st * (loc.y > this.armsY + this.pivotY ? 1 : .6);
    this.kick = Math.min(3.2, this.kick + (part === 'body' ? 1.6 : .8) * st); this.flashK = Math.min(1, this.flashK + .55);
    this.hitPart = part === 'head' ? this.head : part === 'arms' ? this.arms : part === 'base' ? this.base : this.body;
    const n = crit ? 5 : 2 + (Math.random() < .5 ? 1 : 0);
    for (let i = 0; i < n; i++) this.spawnChip(loc, dir, crit ? 1.3 : 1, part === 'head' ? 1 : null);
    this.fx.sparks?.(p, crit ? 22 : 10, dir);
  }
  spawnChip(loc, dir, sp = 1, kind = null) {
    const c = this.chips.find((x) => x.life <= 0) || this.chips[0], m = c.m, ti = kind ?? Math.floor(Math.random() * this.T.chips.length), t = this.T.chips[ti];
    m.material.uniforms.map.value = t; const s = this.k * rand(.35, .7) * (ti === 1 ? 1.3 : 1); m.scale.set(t.image.width * s, t.image.height * s, 1);
    m.position.set(loc.x, loc.y, .05); c.v.set(dir * rand(2, 7) * sp + rand(-1.5, 1.5), rand(3, 8) * sp, 0).multiplyScalar(this.k * 160); c.w = rand(-14, 14); c.life = c.max = rand(.55, .9); m.visible = true; m.material.uniforms.alpha.value = 1;
  }
  // lobby -> fight: bursts apart, pieces tumble off, the base sinks into the cloud sea (~1.2 s)
  crumble() {
    if (this.state === 'off') return; this.state = 'crumble'; this.st = 0; const k = this.k * 160;
    this.free = [
      { g: this.pivot, v: new THREE.Vector3(rand(-1, 1) * 2, 5, 0).multiplyScalar(k), w: rand(-1, 1) * 3 },
      { g: this.headG, v: new THREE.Vector3(rand(-1, 1) * 6, 9, 0).multiplyScalar(k), w: rand(-8, 8) },
      { g: this.armsG, v: new THREE.Vector3((Math.random() < .5 ? -1 : 1) * 5, 6, 0).multiplyScalar(k), w: rand(-6, 6) }];
    const c = new THREE.Vector3(0, this.pivotY + this.armsY, 0);
    for (let i = 0; i < 14; i++) this.spawnChip(c, Math.random() < .5 ? -1 : 1, 1.6);
    this.kick = 3.5; this.flashK = 1; this.hitPart = this.body;
    this.fx.burst?.(this.root.localToWorld(c.clone()));
  }
  // back to the lobby: drops in from above and lands with a squash + dust
  restore() { this.reset(); const drop = new URLSearchParams(location.search).get('dummydrop') === '1'; this.state = drop ? 'drop' : 'idle'; this.st = 0; this.dropY = drop ? this.k * PX.total * 1.6 : 0; this.dropV = 0; this.root.visible = true; } // 11-26 user: no drop-in in the lobby - it just stands there (?dummydrop=1 = the old drop)
  update(dt, t, camera) {
    if (this.state === 'off') return;
    this.st += dt; const s = this.sp, R = this.root; R.quaternion.copy(camera.quaternion); R.position.copy(this.home);
    if (this.state === 'drop') { this.dropV -= 9 * this.k * PX.total * dt; this.dropY += this.dropV * dt;
      if (this.dropY <= 0) { this.dropY = 0; this.state = 'idle'; s.sqV -= 5; s.thV += rand(-1, 1); s.hdV += rand(-4, 4); this.fx.land?.(this.home.clone()); }
      R.position.y += this.dropY; }
    // springs (sub-stepped): tilt (underdamped ~1.5 Hz), squash, head + arms driven by the body's angular acceleration
    const n = Math.ceil(dt / (1 / 120)), h = dt / n, sway = this.state === 'idle' ? .035 * Math.sin(t * 1.3) + .012 * Math.sin(t * 3.1 + 1) : 0;
    for (let i = 0; i < n; i++) {
      const a = -90 * (s.th - sway) - 6.5 * s.thV; s.thV += a * h; s.th += s.thV * h; s.th = clamp(s.th, -.5, .5);
      s.sqV += (-420 * s.sq - 16 * s.sqV) * h; s.sq += s.sqV * h;
      s.hdV += (-170 * s.hd - 7 * s.hdV - a * .5) * h; s.hd += s.hdV * h;
      s.arV += (-130 * s.ar - 6 * s.arV + a * .35) * h; s.ar += s.arV * h;
    }
    if (this.state !== 'crumble') {
      this.pivot.rotation.z = s.th; const q = clamp(s.sq, -.2, .25); this.pivot.scale.set(1 - q * .6, 1 + q, 1);
      this.headG.rotation.z = clamp(s.hd, -.6, .6); this.armsG.rotation.z = clamp(s.ar, -.4, .4);
    } else { // tumbling pieces + sinking base + fade
      const u = this.st, g = this.k * 160 * 14;
      for (const f of this.free) { f.v.y -= g * dt; f.g.position.addScaledVector(f.v, dt); f.g.rotation.z += f.w * dt; }
      this.base.position.y = -this.k * PX.baseH * Math.min(1, u / 1.1) ** 2 * 1.1;
      const a = clamp(1 - (u - .45) / .7, 0, 1); this.setAlpha(a);
      if (u > 1.3) { this.state = 'off'; R.visible = false; for (const c of this.chips) { c.life = 0; c.m.visible = false; } return; }
    }
    // rune glow + hit flash on the struck part
    this.kick *= Math.exp(-5 * dt); this.flashK *= Math.exp(-14 * dt);
    if (this.glowU) this.glowU.glowK.value.setScalar(.9 + this.kick);
    for (const m of this.parts) { const f = m === this.hitPart ? this.flashK : this.flashK * .25; m.material.uniforms.flash.value.setRGB(f * .38, f * .3, f * .5); }
    // chips: gravity, spin, fade
    const g = this.k * 160 * 16;
    for (const c of this.chips) { if (c.life <= 0) continue; c.life -= dt; if (c.life <= 0) { c.m.visible = false; continue; }
      c.v.y -= g * dt; c.m.position.addScaledVector(c.v, dt); c.m.rotation.z += c.w * dt; c.m.material.uniforms.alpha.value = Math.min(1, c.life / c.max * 2.5); }
  }
  centerWorld() { const p = new THREE.Vector3(rand(-.25, .25) * this.T.body.image.width * this.k, this.pivotY + rand(.35, .65) * this.T.body.image.height * this.k, .3); return this.root.localToWorld(p); }
  // random point on the body for the visual-test bot (screen px)
  botPoint(camera, W, H) { const p = new THREE.Vector3(rand(-.6, .6) * this.T.body.image.width * this.k * .5, this.pivotY + rand(.2, .8) * this.T.body.image.height * this.k, 0); this.root.localToWorld(p); p.project(camera); return { x: (p.x * .5 + .5) * W, y: (-p.y * .5 + .5) * H }; }
}
