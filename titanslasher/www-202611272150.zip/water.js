// Living painted layers + sea splashes (user 11-25: "splash effect on the water if the titan is hitting the water; animate the
// environment, not static"). Everything is cheap: UV scroll / noise wobble in the layer shader, pooled meshes and points.
import * as THREE from 'three';
import { SH } from './fx.js';

// ---------- the sea surface (the flat plane at y -0.8 the titan stands in; to the player it reads as water) ----------
// Domain-warped flowing noise, slow swell bands, a rolling shimmer, twinkling sparkles, foam churn + wake where the titan's body
// meets the surface, and up to NR ripple / foam rings from splashes (rg[i] = x, z, age, size; age < 0 = off). All in one pass.
export const NR = 10;
// 11-28 WATER SCALE (user: "the water animation was scaled on the wrong distance"). Every water size below (noise / swell / foam
// frequencies, scroll speed, wake depth, splash rings, splash sheets, droplets, puffs) was authored for the titan at z -42, ~58 units
// from the camera. The ink look stands him at z -2 (main.js TDEF), 18.5 units away, so the same world sizes read ~3x too big. ws =
// titan's camera distance / the authored distance: the shaders divide world coordinates by it, Water multiplies world sizes / speeds
// by it. 1 at z -42 (default style unchanged), ~.32 in ink. Fixed per framing (not the live camera): the pattern never swims.
const CAM_Z = 16.5, AUTHOR_Z = -42; // fight camera rest z (main.js CAM_FIGHT.pos), titan depth the sizes were made for
export const waterScale = (titanZ) => Math.max(.25, Math.min(1.5, (CAM_Z - titanZ) / (CAM_Z - AUTHOR_Z)));
export function seaFloorMat(noise) {
  noise.wrapS = noise.wrapT = THREE.RepeatWrapping; noise.needsUpdate = true;
  const rg = Array.from({ length: NR }, () => new THREE.Vector4(0, 0, -1, 1));
  // 11-26 arenas: colours / flow / swell / whitecaps / lava veins are uniforms (Water.setTheme, arena.json theme.sea); defaults = sky ruins
  const C = (r, g, b) => ({ value: new THREE.Color(r, g, b) }), F = (v) => ({ value: v });
  return new THREE.ShaderMaterial({ fog: false, uniforms: { n: { value: noise }, t: SH.time, fogColor: SH.fogColor, rg: { value: rg }, wake: { value: new THREE.Vector4(0, -41, 13, 1) },
    cDeep: C(.17, .1, .38), cMid: C(.62, .52, .9), cHi: C(.95, .75, 1), cRune: C(.1, .55, .7), cShim: C(.45, .7, 1), cFoam: C(.88, .9, 1), cVein: C(1, .45, .1),
    flow: F(1), swellA: F(1), caps: F(0), vein: F(0), shimK: F(1), ws: F(1) },
    vertexShader: 'varying vec3 vW; varying float vD; void main(){ vec4 w = modelMatrix * vec4(position,1.); vW = w.xyz; vec4 mv = viewMatrix * w; vD = -mv.z; gl_Position = projectionMatrix * mv; }',
    fragmentShader: `uniform sampler2D n; uniform float t; uniform vec3 fogColor; uniform vec4 rg[${NR}]; uniform vec4 wake; varying vec3 vW; varying float vD;
      uniform vec3 cDeep; uniform vec3 cMid; uniform vec3 cHi; uniform vec3 cRune; uniform vec3 cShim; uniform vec3 cFoam; uniform vec3 cVein;
      uniform float flow; uniform float swellA; uniform float caps; uniform float vein; uniform float shimK; uniform float ws;
      void main(){ vec2 au = vW.xz / ws; float aD = vD / sqrt(ws); // au = the point in authored water units (waterScale); aD = distance for the anti-alias fades
        vec2 p = au * 0.018; float T = t * flow;
        vec2 w = vec2(texture2D(n, p * .6 + vec2(T * .011, T * .004)).r, texture2D(n, p * .6 + vec2(.37, .11) - vec2(T * .007, -T * .003)).r) - .5; // flow warp
        float a = texture2D(n, p + w * .16 + vec2(T * .016, 0.)).r, b = texture2D(n, p * 2.3 + w * .3 - vec2(T * .01, T * .022)).r; float c = a * .6 + b * .4;
        // 11-26 grain: near the horizon vW.z changes by tens of units per pixel, so the swell rows / shimmer band (sin of z, pow 10)
        // aliased into a speckle band on the iPhone; both fade out with distance (hz) before they get sub-pixel
        float hz = smoothstep(115., 55., aD);
        float sw = sin(au.y * .35 + au.x * .06 - T * .8 + w.x * 6.) * hz; c += sw * .035 * swellA; // slow swell rows rolling toward the camera
        vec3 col = mix(cDeep, cMid, smoothstep(.3, .75, c)); col = mix(col, cHi, smoothstep(.72, .95, c) * .6);
        if (vein > 0.) { float v = abs(b - .5 + w.y * .3); col = mix(col, cVein * 1.25, smoothstep(.06, .0, v) * vein * smoothstep(110., 20., aD)); } // lava: glowing veins between crust plates
        float g = exp(-length(au - wake.xy / ws + vec2(0., 1.)) * .03); /* rune glow under the titan, at his real depth */ col += cRune * g * .5 * (.5 + c);
        float band = pow(.5 + .5 * sin(au.x * .07 + au.y * .12 - T * .55 + c * 5.), 10.); col += cShim * band * .22 * shimK * hz * smoothstep(.45, .8, c); // shimmer
        // (11-26 UI pass: the per-cell hash sparkles are gone; far cells went sub-pixel and still showed as colourful grain on the iPhone)
        // wake: foam churn hugging the titan's waist line (wake.x = centre x, .y = z, .z = half width, .w = strength)
        vec2 q = (vW.xz - wake.xy) / vec2(wake.z, 5. * ws); float wd = length(q); float fn = texture2D(n, au * .09 + vec2(t * .05, -t * .09)).r;
        float foam = smoothstep(1.1, .25, wd) * smoothstep(.42, .68, fn + .25 * sin(t * 2.2 + au.x * .7) * .5 + (1. - wd) * .25) * wake.w;
        if (caps > 0.) foam += smoothstep(.62, .8, c + sw * .08 * swellA) * smoothstep(.45, .7, fn) * caps * smoothstep(140., 30., aD); // storm whitecaps on the swell crests
        // splash rings: an expanding bright ring + a softer inner one + a foam patch that breaks up as it ages
        for (int i = 0; i < ${NR}; i++) { vec4 R = rg[i]; if (R.z < 0.) continue; float d = length((vW.xz - R.xy) / ws * vec2(1., 1.15)); float age = R.z; // R.xy world, R.w authored size
          float rad = R.w * (1. - exp(-age * 1.6)) * 1.15, wid = .5 + R.w * .08 + age * .5, k = exp(-age * .9);
          float ring = smoothstep(wid, 0., abs(d - rad)) * k + smoothstep(wid * .7, 0., abs(d - rad * .62)) * k * .55;
          float fp = smoothstep(rad * .8 + .5, 0., d) * exp(-age * 1.3) * smoothstep(.3, .6, fn + .3 - age * .12);
          foam += ring * (.75 + .25 * fn) + fp; }
        col = mix(col, cFoam, clamp(foam, 0., 1.) * .85);
        col = mix(col, fogColor, smoothstep(30., 150., vD) * .75 * (1. - clamp(foam, 0., 1.) * .35)); gl_FragColor = vec4(col, 1.); }` });
}

// ---------- flowing painted layer (cloud bank, cloud-sea strips) ----------
// Same look as spriteMat (tint, cyan glow, light, fog) plus: horizontal UV scroll on a MIRRORED-repeat texture (seamless wrap for
// art whose edges are opaque), a small noise wobble, a vertex swell along the top edge (plane needs x segments) and, for the sea,
// a moving shimmer band + twinkling sparkles on the bright / cyan "water" pixels.
const LVS = `uniform float t; uniform float swell; uniform float swellF; varying vec2 vUv; varying vec3 vW; varying float vD;
void main(){ vUv = uv; vec3 p = position; p.y += (sin(p.x * swellF + t * .55) * .6 + sin(p.x * swellF * 2.3 - t * .9) * .4) * swell * uv.y;
  vec4 w = modelMatrix * vec4(p, 1.); vW = w.xyz; vec4 mv = viewMatrix * w; vD = -mv.z; gl_Position = projectionMatrix * mv; }`;
const LFS = `uniform sampler2D map; uniform vec3 tint; uniform float alpha; uniform vec3 flash; uniform float glow; uniform float fogNear; uniform float fogFar;
uniform vec3 fogColor; uniform vec3 lightPos; uniform vec3 lightCol; uniform float lightK; uniform float t; uniform float scroll; uniform float wob; uniform float shimmer;
uniform float floorY; uniform float floorFade;
varying vec2 vUv; varying vec3 vW; varying float vD;
void main(){ float fl = smoothstep(floorY, floorY + floorFade, vW.y); if (fl < .004) discard; // 11-26: never below the sea surface, thins into mist just above it
  vec2 uv = vUv; uv.x += mod(t * scroll, 2.); // 11-26 grain: wrapped (mirrored repeat period 2) so the UV never grows large (fp16 GPUs)
  float k = 1. - smoothstep(.55, 1., vUv.y); // wobble less at the silhouette edge (top) so the outline stays painterly
  uv += vec2(sin(vUv.y * 23. + t * .9 + vUv.x * 9.), cos(vUv.x * 17. - t * .7 + vUv.y * 6.)) * wob * (.35 + .65 * k) * (1. - smoothstep(60., 140., vD) * .8); // far strips: almost no wobble (sub-pixel UV jitter)
  vec4 c = texture2D(map, uv); if (c.a < 0.02) discard;
  vec3 col = c.rgb * tint;
  float cy = clamp((min(c.g, c.b) - c.r - 0.06) * 3.2, 0., 1.);
  col += c.rgb * cy * glow;
  if (shimmer > 0.) { float l = max(c.r, max(c.g, c.b));
    float band = pow(.5 + .5 * sin(vW.x * .16 - t * .9 + sin(vW.x * .05 + t * .3) * 2.), 6.); // slow light band rolling across
    col += c.rgb * band * shimmer * (.25 + cy) * smoothstep(.35, .9, l) * k; } // 11-26: the hash glints on a 260x90 cell grid are gone (colourful grain on phones)
  float d = distance(vW, lightPos); col += col * lightCol * lightK * (1.4 / (1. + d * d * 0.0035));
  float f = smoothstep(fogNear, fogFar, vD); col = mix(col, fogColor, f * 0.85);
  col += flash; gl_FragColor = vec4(col, c.a * alpha * fl); }`;
export function layerMat(tex, o = {}) {
  tex.wrapS = THREE.MirroredRepeatWrapping; tex.needsUpdate = true;
  return new THREE.ShaderMaterial({ vertexShader: LVS, fragmentShader: LFS, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    uniforms: { map: { value: tex }, tint: { value: new THREE.Color(1, 1, 1) }, alpha: { value: 1 }, flash: { value: new THREE.Color(0, 0, 0) }, glow: { value: o.glow ?? .4 },
      fogNear: { value: o.fogNear ?? 9999 }, fogFar: { value: o.fogFar ?? 99999 }, fogColor: SH.fogColor, lightPos: SH.lightPos, lightCol: SH.lightCol, lightK: SH.lightK, t: SH.time,
      scroll: { value: o.scroll ?? 0 }, wob: { value: o.wob ?? 0 }, shimmer: { value: o.shimmer ?? 0 }, swell: { value: o.swell ?? 0 }, swellF: { value: o.swellF ?? 12 },
      floorY: { value: o.floorY ?? -1e4 }, floorFade: { value: o.floorFade ?? 1 } } });
}

// ---------- procedural splash sheet: a crown of tapered water jets that shoot up and collapse (billboard, anchored at the base) ----------
function splashMat(noise) {
  return new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide,
    uniforms: { n: { value: noise }, prog: { value: 0 }, seed: { value: 0 }, fade: { value: 1 }, fogColor: SH.fogColor, fogK: { value: 0 } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
    fragmentShader: `uniform sampler2D n; uniform float prog; uniform float seed; uniform float fade; uniform vec3 fogColor; uniform float fogK; varying vec2 vUv;
      float h1(float x){ return fract(sin(x * 91.7 + seed * 13.1) * 43758.5453); }
      void main(){ vec2 p = vec2(vUv.x * 2. - 1., vUv.y); float a = 0., foam = 0., st = 0.;
        float rise = sin(min(prog * 1.35, 1.) * 3.14159); // jets shoot up (~0.37 of the life) then fall back
        for (int i = 0; i < 9; i++) { float fi = float(i), r = h1(fi), x0 = (fi - 4.) / 4. * .62 + (r - .5) * .12, lean = x0 * (.55 + r * .5);
          float top = (1. - abs(x0) * .75) * (.55 + .45 * r) * rise; if (top < .01) continue;
          float yy = p.y, u = yy / top; if (u > 1.15) continue;
          float cx = x0 + lean * yy * (1. + prog * .6), wid = (.07 + .06 * r) * (1. - .55 * clamp(u, 0., 1.)) * (1. + prog * .9);
          float nz = texture2D(n, vec2(p.x * 1.3 + fi * .17 + seed, yy * 1.6 - prog * .7)).r;
          float d = abs(p.x - cx) - wid * (.6 + .8 * nz);
          float m = smoothstep(.025, -.02, d) * smoothstep(1.06, .9, u + (nz - .5) * .25) * smoothstep(-.01, .02, yy);
          a = max(a, m); foam = max(foam, m * (smoothstep(.6, 1., u) + smoothstep(-.03, .0, d) * .7)); }
        float skirt = smoothstep(.14 + prog * .1, 0., p.y) * smoothstep(.9 + prog * .1, .3, abs(p.x)) * (1. - prog * .6); // foam skirt at the waterline
        float nz2 = texture2D(n, vec2(p.x * 2.5 + seed, p.y * 1.2 - prog)).r; skirt *= smoothstep(.25, .55, nz2 + .2);
        a = max(a, skirt); foam = max(foam, skirt);
        st = texture2D(n, vec2(p.x * 3. + seed, p.y * .5 - prog * 1.6)).r; // streaks inside the sheet
        vec3 body = mix(vec3(.36, .3, .82), vec3(.55, .9, 1.), smoothstep(.35, .75, st));
        vec3 col = mix(body, vec3(.95, .97, 1.), clamp(foam, 0., 1.)); col = mix(col, fogColor, fogK);
        float al = a * (.5 + .45 * clamp(foam, 0., 1.) + .15 * st) * fade * (1. - smoothstep(.65, 1., prog));
        gl_FragColor = vec4(col, al); }` });
}

// ---------- painted splash sprite (Codex, art/fx/splash1-3: crown / spout / wave): grows up out of the sea, then sinks back under the
// opaque sea plane (depth hides the part below the surface) while a noisy edge eats it from the top; white flash at the start
const SPL_TINT = { value: new THREE.Color(1, 1, 1) }; // shared by every painted splash sheet (arena theme.splash.tint)
function splashSprMat(tex, noise) {
  return new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide,
    uniforms: { map: { value: tex }, n: { value: noise }, cut: { value: 2 }, alpha: { value: 1 }, flash: { value: 0 }, fogColor: SH.fogColor, fogK: { value: 0 }, seed: { value: 0 }, tint: SPL_TINT },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
    fragmentShader: `uniform sampler2D map; uniform sampler2D n; uniform float cut; uniform float alpha; uniform float flash; uniform vec3 fogColor; uniform float fogK; uniform float seed; uniform vec3 tint; varying vec2 vUv;
      void main(){ vec4 c = texture2D(map, vUv); float nz = texture2D(n, vUv * vec2(1.6, 2.2) + seed).r;
        float a = c.a * alpha * smoothstep(cut + .06, cut - .06, vUv.y + (nz - .5) * .35); if (a < .02) discard;
        vec3 col = mix(c.rgb * tint, fogColor, fogK) + flash * (.4 + .6 * c.rgb); gl_FragColor = vec4(col, a); }` });
}

// ---------- pooled droplets / foam flecks / falling pebbles / dust (one Points draw call, normal blend) ----------
class Drops {
  constructor(n) {
    this.n = n; this.i = 0; this.pos = new Float32Array(n * 3); this.vel = new Float32Array(n * 3); this.col = new Float32Array(n * 4); this.sz = new Float32Array(n);
    this.life = new Float32Array(n); this.max = new Float32Array(n); this.siz = new Float32Array(n); this.grav = new Float32Array(n); this.kind = new Uint8Array(n); this.drag = new Float32Array(n);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('size', new THREE.BufferAttribute(this.sz, 1).setUsage(THREE.DynamicDrawUsage));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.u = { px: { value: 300 } };
    this.mesh = new THREE.Points(g, new THREE.ShaderMaterial({ uniforms: this.u, transparent: true, depthWrite: false,
      vertexShader: `attribute vec4 color; attribute float size; uniform float px; varying vec4 vC; void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.); gl_Position = projectionMatrix * mv; gl_PointSize = size * px / max(1., -mv.z); }`,
      fragmentShader: `varying vec4 vC; void main(){ vec2 p = gl_PointCoord - .5; float d = length(p) * 2.; if (d > 1. || vC.a < .01) discard; float a = smoothstep(1., .55, d); vec3 c = vC.rgb + (1. - d) * .25; gl_FragColor = vec4(c, vC.a * a); }` }));
    this.mesh.frustumCulled = false;
  }
  // kind: 0 droplet (dies in the sea), 1 pebble (plops a tiny splash when it reaches the sea), 2 dust / mist fleck (no sea test)
  emit(x, y, z, vx, vy, vz, life, size, r, g, b, a, grav, kind = 0, drag = 0) {
    const i = this.i, j = i * 3; this.i = (i + 1) % this.n;
    this.pos[j] = x; this.pos[j + 1] = y; this.pos[j + 2] = z; this.vel[j] = vx; this.vel[j + 1] = vy; this.vel[j + 2] = vz;
    const k = i * 4; this.col[k] = r; this.col[k + 1] = g; this.col[k + 2] = b; this.col[k + 3] = a;
    this.life[i] = life; this.max[i] = life; this.siz[i] = size; this.grav[i] = grav; this.kind[i] = kind; this.drag[i] = drag;
  }
  update(dt, seaY, wind, onPlop) {
    let lo = this.n, hi = -1; // 11-27 PERF PASS: upload only the changed span (nothing while no drop is alive)
    for (let i = 0; i < this.n; i++) {
      if (this.life[i] <= 0) { if (this.sz[i] !== 0) { this.sz[i] = 0; if (i < lo) lo = i; hi = i; } continue; }
      if (i < lo) lo = i; hi = i;
      this.life[i] -= dt; const j = i * 3;
      this.vel[j + 1] -= this.grav[i] * dt; if (this.drag[i]) { const d = Math.pow(1 - Math.min(.95, this.drag[i]), dt); this.vel[j] *= d; this.vel[j + 1] *= d; this.vel[j + 2] *= d; }
      this.pos[j] += (this.vel[j] + wind * (this.kind[i] === 2 ? 1 : .15)) * dt; this.pos[j + 1] += this.vel[j + 1] * dt; this.pos[j + 2] += this.vel[j + 2] * dt;
      if (this.kind[i] !== 2 && this.pos[j + 1] < seaY && this.vel[j + 1] < 0) { if (this.kind[i] === 1 && onPlop) onPlop(this.pos[j], this.pos[j + 2], this.siz[i]); this.life[i] = 0; this.sz[i] = 0; continue; }
      const t = Math.max(0, this.life[i] / this.max[i]); this.sz[i] = this.siz[i] * (.45 + .55 * t); this.col[i * 4 + 3] = Math.min(this.col[i * 4 + 3], Math.min(1, t * 3));
    }
    if (hi < 0) return; const g = this.mesh.geometry.attributes, n = hi - lo + 1;
    g.position.clearUpdateRanges(); g.position.addUpdateRange(lo * 3, n * 3); g.position.needsUpdate = true;
    g.color.clearUpdateRanges(); g.color.addUpdateRange(lo * 4, n * 4); g.color.needsUpdate = true;
    g.size.clearUpdateRanges(); g.size.addUpdateRange(lo, n); g.size.needsUpdate = true;
  }
}

const rnd = (a, b) => a + Math.random() * (b - a);
// The sea system. Flavour only: nothing here touches gameplay or the camera.
// o: { seaMat (seaFloorMat), noise, puff (soft puff texture), shock(p, size, dur, amp) distortion ring, coarse (phone caps), seaY }
export class Water {
  constructor(scene, o) {
    this.o = o; this.seaY = o.seaY ?? -.8; this.coarse = !!o.coarse; this.k = this.coarse ? .6 : 1; // phone: fewer particles per splash
    this.rg = o.seaMat.uniforms.rg.value; this.wakeU = o.seaMat.uniforms.wake.value; this.ri = 0;
    this.tex = (o.tex || []).filter(Boolean); // painted splashes if loaded, else the procedural sheet
    this.cols = []; for (let i = 0; i < (this.coarse ? 5 : 8); i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1).translate(0, .5, 0), this.tex.length ? splashSprMat(this.tex[0], o.noise) : splashMat(o.noise));
      m.visible = false; m.renderOrder = 200; m.userData = { t: 9, dur: 1, w: 1, h: 1 }; scene.add(m); this.cols.push(m); } // over the titan + base mist, under the front sea strip / near mist
    this.puffs = []; for (let i = 0; i < (this.coarse ? 6 : 10); i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: o.puff, transparent: true, depthWrite: false, color: 0xd8ccff, opacity: 0 }));
      m.visible = false; m.renderOrder = 132; m.userData = { t: 9, dur: 1, s0: 1, s1: 2, a: .5, vx: 0, vy: 0 }; scene.add(m); this.puffs.push(m); }
    this.drops = new Drops(this.coarse ? 220 : 400); this.drops.mesh.renderOrder = 134; scene.add(this.drops.mesh);
    this.plop = this.plop.bind(this); this.wind = 0; this.gust = 0; this.gustT = rnd(6, 12); this.lapT = 0; this.pebT = rnd(2, 4); this.lastSink = 0; this.churnT = 0;
    this.titanX = 0; this.titanZ = -40; this.titanW = 14; this.ws = 1; // ws: waterScale, set every frame in update()
    this.dropA = [.92, .95, 1]; this.dropB = [.6, .85, 1]; // splash droplet colours (arena theme.splash.drop / drop2)
  }
  // 11-26 arenas (arena.js): swap the sea look + splash art at runtime, no rebuild. th = merged arena theme, tex = painted splashes
  setTheme(th, tex) {
    const s = th.sea || {}, u = this.o.seaMat.uniforms, c = (k, v) => { if (v && u[k]) u[k].value.setRGB(v[0], v[1], v[2]); };
    c('cDeep', s.deep); c('cMid', s.mid); c('cHi', s.hi); c('cRune', s.rune); c('cShim', s.shim); c('cFoam', s.foam); c('cVein', s.veinCol);
    u.flow.value = s.flow ?? 1; u.swellA.value = s.swell ?? 1; u.caps.value = s.caps ?? 0; u.vein.value = s.vein ?? 0; u.shimK.value = s.shimK ?? 1;
    const sp = th.splash || {};
    if (tex && tex.filter(Boolean).length && this.cols[0]?.material.uniforms.map) this.tex = tex.filter(Boolean);
    SPL_TINT.value.setRGB(...(sp.tint || [1, 1, 1]));
    this.dropA = sp.drop || [.92, .95, 1]; this.dropB = sp.drop2 || [.6, .85, 1];
    const pc = sp.puff || [.85, .8, 1]; for (const m of this.puffs) m.material.color.setRGB(pc[0], pc[1], pc[2]);
  }
  // ring / column take AUTHORED sizes (scaled by ws: rings in the shader, columns here); x, z are world
  ring(x, z, size, age = 0) { const r = this.rg[this.ri = (this.ri + 1) % this.rg.length]; r.set(x, z, age, size); }
  // kind 0 crown, 1 spout, 2 wave (flip = -1 mirrors); w = authored width (painted: height follows the art's aspect)
  column(x, z, w, h, dur, kind = 0, flip = 1) { if (this.dry) return; // 11-26 ink ?water=abyss / fog (inkdeco.js): no water, no splash columns
    const S = this.ws; w *= S; h *= S;
    const m = this.cols.find((c) => !c.visible) || this.cols.reduce((a, b) => (a.userData.t / a.userData.dur > b.userData.t / b.userData.dur ? a : b));
    const u = m.userData, mu = m.material.uniforms; m.visible = true; u.t = 0; u.dur = dur;
    if (this.tex.length) { const t = this.tex[Math.min(kind, this.tex.length - 1)]; mu.map.value = t; h = w * t.image.height / t.image.width; }
    m.renderOrder = z < this.titanZ - 3 * S ? 95 : 200; // 11-26: a splash BEHIND the (now close) titan draws under him (titan = 100), in front of him over him
    u.w = w * flip; u.h = h; m.position.set(x, this.seaY - .3 * S, z); m.scale.set(w * flip, h, 1); mu.seed.value = Math.random() * 10; mu.fogK.value = Math.min(.55, Math.max(0, (-z - 40) / 120)); }
  puff(x, y, z, s0, s1, dur, a, vx = 0, vy = 1) { const m = this.puffs.find((p) => !p.visible) || this.puffs[0]; m.visible = true; m.position.set(x, y, z); const u = m.userData; Object.assign(u, { t: 0, dur, s0, s1, a, vx, vy }); m.material.opacity = 0; }
  // big splash where something hits the sea at world point p (x, z used; y snaps to the surface). power ~ .2 (pebble) .. 1 (fist) .. 1.5
  // o.dz = authored units toward the camera
  splash(p, power = 1, o = {}) {
    const S = this.ws; // every offset / size / speed / gravity of the burst x S: same timing, same shape, right size for the depth
    let x = p.x; const z = p.z + (o.dz ?? 1.5) * S, y = this.seaY, P = power, k = this.k;
    const c = this.cam; if (c && !o.free) { const hw = Math.tan(c.fov * Math.PI / 360) * c.aspect * (c.position.z - z); x = Math.max(-hw * .62, Math.min(hw * .62, x)); } // narrow phone frame: pull the burst into view (the fist itself is off-screen there)
    if (o.wave) this.column(x, z, 20 * P, 0, 1.1 + .4 * P, 2, o.wave); // sweep: a wave burst leaning the way the arm travels
    else if (P > .25) this.column(x, z, 22 * P * (o.wide || 1), 17 * P, 1 + .5 * P, 0, Math.random() < .5 ? 1 : -1);
    if (P > .6 && !o.wave) this.column(x + rnd(-2, 2) * P * S, z + .8 * S, 9 * P, 24 * P, 1.2 + .4 * P, 1, Math.random() < .5 ? 1 : -1); // tall spout inside the crown
    this.ring(x, z, 10 * P + 1.5); if (P > .5) this.ring(x, z, 16 * P, -.25); // second ring starts a beat later
    const n = this.dry ? 0 : Math.round((P > .5 ? 70 : 24) * P * k + 4); // dry modes: no water droplets either (only the puffs, read as dust / mist)
    const dA = this.dropA, dB = this.dropB;
    for (let i = 0; i < n; i++) { const a = rnd(0, 6.283), sp = rnd(.25, 1) * 14 * P, up = rnd(10, 26) * Math.sqrt(P), w = Math.random(), dc = w < .5 ? dA : dB;
      this.drops.emit(x + Math.cos(a) * rnd(0, 3) * P * S, y + rnd(0, 2) * S, z + Math.sin(a) * rnd(0, 2) * S, Math.cos(a) * sp * S, up * S, (Math.sin(a) * sp * .5 + rnd(0, 3)) * S, rnd(1, 2.2), rnd(.5, 1.3) * (.6 + P * .5) * S, dc[0], dc[1], dc[2], rnd(.7, 1), 26 * S, 0, .15); }
    for (let i = 0; i < Math.round(3 * P * k + 1); i++) this.puff(x + rnd(-5, 5) * P * S, y + rnd(2, 6) * P * S, z + 2 * S, 7 * P * S, 18 * P * S, rnd(1.6, 2.6), .3, (rnd(-1.5, 1.5) + this.wind * .4) * S, rnd(.5, 1.8) * S);
    if (P > .5 && this.o.shock) this.o.shock(new THREE.Vector3(x, y + 4 * P * S, z), 26 * P * S, .55, .55); // light refraction ripple through the existing distortion pass
  }
  plop(x, z, s) { // tiny splash: pebbles / debris falling in
    this.ring(x, z, 1.4 + s * 1.5); const y = this.seaY, S = this.ws;
    const dA = this.dropA; if (!this.dry) for (let i = 0; i < Math.round(5 * this.k + 1); i++) this.drops.emit(x + rnd(-.3, .3) * S, y, z, rnd(-2, 2) * S, rnd(3, 7) * S, rnd(-1, 1) * S, rnd(.4, .8), rnd(.35, .6) * S, dA[0], dA[1], dA[2], .9, 24 * S, 0, 0);
    if (s > .5 && Math.random() < .5) this.column(x, z, 2.5 + s * 2, 3 + s * 2, .8, Math.random() < .5 ? 0 : 1);
  }
  // per frame. s: { titanX, titanZ (his body's z), titanW (half width at the waterline), sink 0..1, on (titan present), px (point scale), side (env floating pieces) }
  update(t, dt, cam, s) {
    this.cam = cam; const bodyZ = s.titanZ ?? AUTHOR_Z, S = this.ws = waterScale(bodyZ); this.o.seaMat.uniforms.ws.value = S;
    // wind gusts: every 7-15 s a 2-3 s push sideways (mist + dust + flecks follow it); env reads water.wind
    this.gustT -= dt; if (this.gustT < 0) { this.gust = rnd(2.2, 3.4); this.gustT = rnd(7, 15) + this.gust; this.gustDir = Math.random() < .75 ? 1 : -1; }
    const gk = this.gust > 0 ? Math.sin(Math.PI * (1 - (this.gust -= dt) / 3.4)) : 0; this.wind = (this.gustDir || 1) * Math.max(0, gk) * 6;
    // rings age
    for (const r of this.rg) if (r.z > -.9) { r.z += dt; if (r.z > 5) r.z = -1; }
    // splash sheets
    for (const m of this.cols) if (m.visible) { const u = m.userData, mu = m.material.uniforms; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = false; continue; } m.quaternion.copy(cam.quaternion);
      if (!mu.map) { mu.prog.value = k; continue; }
      const up = 1 - Math.pow(1 - Math.min(1, k / .28), 3), down = Math.pow(Math.max(0, (k - .38) / .62), 1.6); // shoots up fast, then falls back under gravity
      m.scale.set(u.w * (.6 + .4 * up + .15 * k), u.h * (.3 + .7 * up), 1); m.position.y = this.seaY - .3 * S - u.h * .85 * down;
      mu.cut.value = 1.15 - down * .9; mu.alpha.value = Math.min(1, k * 12) * (1 - Math.max(0, (k - .85) / .15)); mu.flash.value = Math.max(0, 1 - k * 6) * .6; }
    for (const m of this.puffs) if (m.visible) { const u = m.userData; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = false; continue; }
      const sc = u.s0 + (u.s1 - u.s0) * (1 - Math.pow(1 - k, 2)); m.scale.set(sc, sc * .6, 1); m.position.x += (u.vx + this.wind * .5 * S) * dt; m.position.y += u.vy * dt;
      m.material.opacity = u.a * Math.min(1, k * 6) * (1 - k); m.quaternion.copy(cam.quaternion); }
    // wake + foam churn where the titan's body meets the surface
    const sink = s.sink || 0, on = s.on ? 1 : 0, ds = Math.abs(sink - this.lastSink) / Math.max(dt, 1e-3); this.lastSink = sink;
    this.titanX = s.titanX ?? 0; this.titanZ = bodyZ + 2 * S; this.titanW = s.titanW ?? 14; // wake / churn / laps sit just in front of his body plane
    const wk = on * (sink < .95 ? 1 : 0); this.wakeU.set(this.titanX, this.titanZ, this.titanW * (1 + ds * .3), wk * (.8 + Math.min(.6, ds)));
    this.lapT -= dt; if (wk && !this.dry && this.lapT < 0) { this.lapT = rnd(.08, .2) / this.k; // little laps along the waist line
      const x = this.titanX + rnd(-1, 1) * this.titanW, z = this.titanZ + rnd(.5, 3) * S;
      const dA = this.dropA; for (let i = 0; i < 3; i++) this.drops.emit(x + rnd(-.5, .5) * S, this.seaY, z, rnd(-1.5, 1.5) * S, rnd(2.5, 6) * S, rnd(0, 1.5) * S, rnd(.4, .8), rnd(.4, .75) * S, dA[0], dA[1] * .98, dA[2], .8, 22 * S, 0, 0);
      if (Math.random() < .12) this.ring(x, z, rnd(2, 4)); }
    // sinking / rising: heavy churn along the waist (intro / exit / previews)
    if (on && ds > .04 && sink < .98) { this.churnT -= dt; if (this.churnT < 0) { this.churnT = .16 / this.k; const P = Math.min(1, .3 + ds * 1.2);
      this.splash({ x: this.titanX + rnd(-1, 1) * this.titanW * .9, z: this.titanZ }, P * rnd(.5, .9), { dz: rnd(1, 3), wide: 1.3, free: 1 }); } }
    // pebbles crumble off the floating pieces now and then and plop into the sea
    this.pebT -= dt; if (this.pebT < 0 && s.side && s.side.length) { this.pebT = rnd(1.6, 3.6);
      const f = s.side[Math.floor(Math.random() * s.side.length)]; if (f.bob && f.m.visible) { const h = Math.abs(f.m.scale.y), w = Math.abs(f.m.scale.x);
        for (let i = 0, nn = 1 + Math.floor(Math.random() * 3); i < nn; i++) this.drops.emit(f.m.position.x + rnd(-.3, .3) * w, f.m.position.y - h * .35, f.m.position.z + .3, rnd(-.4, .4), rnd(-.5, .5), 0, 8, Math.max(.25, h * rnd(.02, .04)), .32, .26, .5, 1, 14, 1, 0); } }
    // foreground pillars shed a little dust now and then (drifts down, follows the wind)
    this.dustT = (this.dustT ?? rnd(3, 6)) - dt; if (this.dustT < 0 && s.side) { this.dustT = rnd(3.5, 7); const ps = s.side.filter((f) => f.kind === 'pillar' && f.m.visible);
      const f = ps[Math.floor(Math.random() * ps.length)]; if (f) { const h = Math.abs(f.m.scale.y), w = Math.abs(f.m.scale.x), y0 = f.m.position.y + h * rnd(-.1, .4), x0 = f.m.position.x + rnd(-.3, .3) * w;
        for (let i = 0; i < Math.round(8 * this.k); i++) { const g = rnd(.55, .8); this.drops.emit(x0 + rnd(-.25, .25), y0 + rnd(-.3, .3), f.m.position.z + .4, rnd(-.2, .2), rnd(-.4, 0), 0, rnd(2.2, 3.5), rnd(.04, .09), g, g * .92, g * 1.15, .55, 1.2, 2, .6); } } }
    this.drops.u.px.value = s.px || 300; this.drops.update(dt, this.seaY, this.wind, this.plop);
  }
}

