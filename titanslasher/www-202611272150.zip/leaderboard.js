// Titan Slasher online leaderboard (Supabase, no login). Server: server/supabase.sql (tables + SECURITY DEFINER RPCs).
// - Identity: a random player id (UUID) + a random secret, made on first run and kept in localStorage ('st_lb'); the server stores
//   sha256(secret). No account, no personal data. Nickname auto "Slasher1234", editable (3-16 letters / digits / _ -).
// - 11-26 (user: "there is no rotation, the titan is per day"): one titan per UTC DAY; since the cycle change (below) a score's
//   fight id = the 15-min cycle (floor(unix s / 900)) and the day board keeps each player's best cycle of the day;
//   today's titan = (day - rotation_start) % titans in game/titans/index.json order (titanNow()), so everyone fights the same titan all day and
//   shares one board (unlimited fights, best of the day kept). `?day=N` forces a day (testing; such fights are unranked unless
//   N is today). Server time comes back with every board read (offset).
// - During the fight: one small board read (top 50) every POLL_S s. At the end: submit_score -> the board around the player.
// - Offline / not configured / any failure: silently falls back to the ghost board (always labelled GHOST). Real players are shown
//   as real; ghost rows only fill the empty slots while the board has fewer than BOARD_N players.
// Plain fetch to the PostgREST RPC endpoints, no SDK, no CDN.

// Project "slash-titans" (jortiga). The anon / publishable key is public by design (RLS + RPC checks guard the data).
const SUPA_URL = 'https://mxtpwookidszvcprsgas.supabase.co';
const SUPA_KEY = 'sb_publishable_xU1lXBi_byciD_GsG_YzCw_EWiMx_gH';

import PASS from './pass.js'; // ?pass=N game pass = unranked
const Q = new URLSearchParams(location.search);
// 11-28 user "push it": the KILL-TIME board (timeboard.js: local ghosts + your best) is the DEFAULT; ?timeboard=0 = the old damage
// board. FREE mode only; damage scores are no longer sent (RANKED false), everything else online (server clock, guild, rewards)
// stays. The test link's explicit ?timeboard=1 is fully offline: nothing is ever written to the live project.
const TIMEBOARD = Q.get('timeboard') !== '0';
const CONFIGURED = !!(SUPA_URL && SUPA_KEY) && Q.get('lb') !== '0' && Q.get('timeboard') !== '1';
const BOARD_N = 50, POLL_S = 12, TIMEOUT_MS = 6000, DAY_MS = 86400000;
const FORCE_DAY = Q.get('day') != null ? +Q.get('day') : null;

// ---------------------------------------------------------------- fight mode + world-clock cycle (11-26)
// User: "it's auto-start, like every 10 mins, then 5 mins rest" (11-26). 11-27 user decision (docs/ECONOMY_PROPOSAL.md §8
// item 1): ENERGY FIGHTS SHIP; the world-clock mode is not the release mode (release app builds use FREE too).
//   FREE:  the FIGHT button starts a 75 s fight whenever you like (costs energy, energy.js). Default everywhere; ?cycle=0.
//   CYCLE: a global 15-min cycle aligned to UTC (:00 :15 :30 :45) = a 10-min FIGHT that starts by itself, then a 5-min REST
//          (dummy). Join in progress, one score per cycle. Only with ?cycle=1 (or ?cycle=fight|rest).
// Both submit to the server's cycle id (floor(unix s / 900)); the board keeps each player's best fight of the UTC day.
// >>> ONE-LINE SWITCH: 'free' -> 'cycle' puts web + store builds on the world clock. <<<
const DEF_MODE = 'free';
const CYC_Q = Q.get('cycle');
const MODE = TIMEBOARD || CYC_Q === '0' ? 'free' : CYC_Q != null ? 'cycle' : DEF_MODE;
const SERVER_CYC_S = 900, CYCLE_FIGHT_S = 600, FREE_FIGHT_S = 75;
// test flags (cycle mode): ?fightlen=S&restlen=S shorten the cycle, ?cyclenow=ISO fakes the clock, ?cycle=fight|rest jumps to the
// start of that phase now (+ ?cycleat=S seconds into it). Any of them = unranked (no submit). ?auto=1 alone starts 12 s before a fight.
const FIGHT_LEN = MODE === 'cycle' ? +(Q.get('fightlen') || CYCLE_FIGHT_S) : +(Q.get('fight') || FREE_FIGHT_S);
const REST_LEN = +(Q.get('restlen') || SERVER_CYC_S - CYCLE_FIGHT_S), CYC_LEN = FIGHT_LEN + REST_LEN;
// anchored lazily at the first cycle() call (the game start), so a slow asset load does not eat the forced phase
const FAKE_ON = MODE === 'cycle' && (Q.has('cyclenow') || CYC_Q === 'fight' || CYC_Q === 'rest' || Q.get('auto') === '1');
let FAKE = FAKE_ON ? undefined : null;
const fakeInit = () => {
  if (MODE !== 'cycle') return null; const n0 = Date.now(), at = +(Q.get('cycleat') || 0);
  if (Q.get('cyclenow')) { const t = Date.parse(Q.get('cyclenow')); return isNaN(t) ? null : t - n0; }
  const c0 = Math.floor(n0 / 1000 / CYC_LEN) * CYC_LEN;
  if (CYC_Q === 'fight') return (c0 + at) * 1000 - n0;
  if (CYC_Q === 'rest') return (c0 + FIGHT_LEN + at) * 1000 - n0;
  if (Q.get('auto') === '1') return (c0 + CYC_LEN - 12) * 1000 - n0;
  return null;
};
const RANKED = !TIMEBOARD && !PASS.ON && (+Q.get('limitevery') || 30) === 30 &&FORCE_DAY == null &&(MODE === 'cycle' ? !FAKE_ON && FIGHT_LEN === CYCLE_FIGHT_S && CYC_LEN === SERVER_CYC_S : FIGHT_LEN === FREE_FIGHT_S);
const NICK_RE = /^[A-Za-z0-9_-]{3,16}$/;
// basic client-side filter (the server has the same list, server/supabase.sql lb_nick_ok)
const BAD = ['fuck', 'fuk', 'fck', 'shit', 'cunt', 'bitch', 'bastard', 'dick', 'cock', 'pussy', 'penis', 'vagina', 'slut', 'whore', 'fag', 'nigg',
  'retard', 'rape', 'nazi', 'hitler', 'kkk', 'porn', 'sex', 'jizz', 'twat', 'wank', 'chink', 'kike', 'tranny', 'asshole', 'dildo', 'boob',
  'tits', 'molest', 'pedo', 'admin', 'moderator', 'official'];
export function nickOk(n) {
  if (!NICK_RE.test(n || '')) return false;
  const f = n.toLowerCase().replace(/[013457]/g, (c) => ({ 0: 'o', 1: 'i', 3: 'e', 4: 'a', 5: 's', 7: 't' }[c])).replace(/[^a-z]/g, '');
  return !BAD.some((w) => f.includes(w));
}

// ---------------------------------------------------------------- device identity
function rnd(n) { const a = new Uint8Array(n); crypto.getRandomValues(a); return a; }
function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  const b = rnd(16); b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128; const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
const ID = (() => {
  let s = null; try { s = JSON.parse(localStorage.getItem('st_lb') || 'null'); } catch (e) {}
  if (!s || !s.id || !s.secret) s = { id: uuid(), secret: [...rnd(32)].map((x) => x.toString(16).padStart(2, '0')).join(''), nick: 'Slasher' + String(1000 + (rnd(2)[0] * 256 + rnd(1)[0]) % 9000), reg: 0 };
  return s;
})();
const saveId = () => { try { localStorage.setItem('st_lb', JSON.stringify(ID)); } catch (e) {} };
saveId();

// ---------------------------------------------------------------- transport
async function rpc(fn, args) {
  if (!CONFIGURED) throw new Error('offline');
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), TIMEOUT_MS);
  const h = { 'Content-Type': 'application/json', apikey: SUPA_KEY }; if (!SUPA_KEY.startsWith('sb_')) h.Authorization = 'Bearer ' + SUPA_KEY; // legacy anon JWT
  try {
    const r = await fetch(`${SUPA_URL}/rest/v1/rpc/${fn}`, { method: 'POST', headers: h, body: JSON.stringify(args), signal: ac.signal });
    if (!r.ok) { const e = new Error(fn + ' ' + r.status); e.missing = r.status === 404; throw e; }
    const j = await r.json(); LB.online = true; if (j && j.now) LB.offset = j.now - Date.now(); return j;
  } catch (e) { if (!e.missing) LB.online = false; throw e; } finally { clearTimeout(to); } // 11-27: a function not deployed yet (404, e.g. rewards.sql) is not "offline"
}
let regP = null;
function register() {
  if (ID.reg) return Promise.resolve(true);
  if (!regP) regP = rpc('lb_register', { p_id: ID.id, p_secret: ID.secret, p_nick: ID.nick })
    .then((j) => { ID.reg = 1; if (j && j.nick) { if (ID.nickPending && ID.nickPending !== j.nick) setNick(ID.nickPending); else ID.nick = j.nick; } saveId(); return true; })
    .catch(() => false).finally(() => { regP = null; });
  return regP;
}

// ---------------------------------------------------------------- state
const toRow = (a) => ({ name: a[0], score: +a[1], shown: +a[1], real: true, me: !!a[2] });
export const LB = {
  configured: CONFIGURED, online: false, offset: 0,
  get id() { return ID.id; }, get nick() { return ID.nick; },
  fight: null, titan: 0, real: [], total: 0, meBest: 0, meRank: 0, around: [], pollT: 0, busy: false,
  names: [], // display names in schedule order (set by titans/loader.js)
  mode: MODE, cycleMode: MODE === 'cycle', timeboard: TIMEBOARD, fightLen: FIGHT_LEN, restLen: REST_LEN, ranked: RANKED, faked: FAKE_ON,
  // trusted clock: Supabase server time (offset from every RPC), else the device; a test fake (?cyclenow / ?cycle=) wins
  now() { return Date.now() + (FAKE ?? this.offset); },
  // the world-clock cycle now: { id, phase: 'fight'|'rest', t (s into the phase), left (s to the phase end), end (ms, fight end) }
  cycle(ms) {
    if (FAKE === undefined) FAKE = fakeInit(); if (ms == null) ms = this.now();
    const s = ms / 1000, id = Math.floor(s / CYC_LEN), u = s - id * CYC_LEN, f = u < FIGHT_LEN;
    return { id, phase: f ? 'fight' : 'rest', t: f ? u : u - FIGHT_LEN, left: f ? FIGHT_LEN - u : CYC_LEN - u, end: (id * CYC_LEN + FIGHT_LEN) * 1000 };
  },
  serverCycle(ms = this.now()) { return Math.floor(ms / 1000 / SERVER_CYC_S); },
  day() { return FORCE_DAY ?? Math.floor(this.now() / DAY_MS); },
  events: [], // enabled seasonal events [{ idx, from, to }] (UTC day numbers; titans/index.json "events", same as SQL lb_events)
  day0: 0, // UTC day of rotation position 0 (titans/index.json "rotation_start" = SQL lb_config titan_rot_day0); earlier days = position 0
  titanOfDay(d, n) { const e = this.events.find((x) => d >= x.from && d <= x.to && x.idx < n); return e ? e.idx : d < this.day0 ? 0 : (d - this.day0) % n; }, // = SQL lb_titan_of_day
  titanNow(n) { return this.titanOfDay(this.day(), n); },
  // ms until the next UTC midnight (the next titan); "HH:MM" for the menu / leaderboard (never a lobby timer)
  nextIn() { const ms = DAY_MS - (this.now() % DAY_MS); return ms; },
  nextInText() { const m = Math.floor(this.nextIn() / 60000); return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; },
  todayText() { const n = this.names.length; return n ? `TODAY: ${this.names[this.titanNow(n)]} · NEW TITAN IN ${this.nextInText()}` : ''; },
  // fight start: this.fight = the server cycle id (null = unranked: test lengths / fake clock / ?day= / ?titan= another titan).
  // CYCLE mode: the cycle being fought (cycleId). FREE mode: the cycle now; submit() re-picks the cycle at the fight's end.
  startFight(titanIdx, n, cycleId) {
    const ok = RANKED && this.titanOfDay(this.day(), n) === titanIdx;
    this.fight = !ok ? null : MODE === 'cycle' ? cycleId : this.serverCycle(); this.titan = titanIdx;
    this.real = []; this.total = 0; this.meBest = 0; this.meRank = 0; this.around = []; this.pollT = 0; this.label();
  },
  // live poll during the fight (one RPC, top 50, every POLL_S s)
  tick(dt) {
    if (!CONFIGURED || this.fight == null) return; this.pollT -= dt; if (this.pollT > 0 || this.busy) return; this.pollT = POLL_S; this.busy = true;
    rpc('get_board', { p_titan: this.titan, p_fight: this.fight, p_id: ID.id, p_limit: BOARD_N }).then((b) => this.take(b)).catch(() => {}).finally(() => { this.busy = false; });
  },
  take(b) {
    if (!b || !b.top) return; const rows = b.top.map(toRow), me = rows.find((r) => r.me);
    this.real = rows.filter((r) => !r.me); this.total = +b.total || 0; this.meBest = me ? me.score : b.me ? +b.me.score : 0;
    this.meRank = b.me ? +b.me.rank : 0; this.around = (b.around || []).map((a) => ({ rank: +a[0], name: a[1], score: +a[2], real: true, me: !!a[3] })); this.label();
  },
  others() { return Math.max(this.real.length, this.total - (this.meBest ? 1 : 0)); },
  ghostKeep(n) { return Math.max(0, Math.min(n, BOARD_N - 1 - this.others())); },
  // rivals for the live board / rank news: real players (fixed best this hour) + ghosts only in the empty slots
  merge(gs) { const k = this.ghostKeep(gs.length); return k >= gs.length && !this.real.length ? gs : [...this.real, ...gs.slice(0, k)]; },
  // results board: [{ name, score, me, real, rank }] with .meRank / .n; uses the server rank when the player is beyond the top 50
  board(gs, score) {
    const you = Math.max(score, this.meBest), list = this.merge(gs).map((g) => ({ name: g.name, score: g.score, real: !!g.real }));
    list.push({ name: ID.nick, score: you, me: true, real: true, best: you > score }); list.sort((a, b) => b.score - a.score);
    let out = list.map((r, i) => ({ ...r, rank: i + 1 })), meRank = out.findIndex((r) => r.me) + 1, n = Math.max(out.length, this.total);
    if (meRank > BOARD_N && this.around.length) { out = out.slice(0, BOARD_N).concat(this.around.map((r) => (r.me ? { ...r, score: you, name: ID.nick } : r))); meRank = this.meRank; }
    out.meRank = meRank; out.n = n; out.anyGhost = out.some((r) => !r.real); return out;
  },
  // top 3 + 2 above / 2 below the player
  rowsHtml(board, fmt) {
    const me = board.findIndex((r) => r.me), show = [...new Set([0, 1, 2, me - 2, me - 1, me, me + 1, me + 2])].filter((i) => i >= 0 && i < board.length).sort((a, b) => a - b);
    const h = []; let prev = -1;
    for (const i of show) { const r = board[i]; if (prev >= 0 && (i > prev + 1 || r.rank > board[prev].rank + 1)) h.push('<div class="lrow gap"><span>...</span></div>');
      h.push(`<div class="lrow ${r.me ? 'me' : ''}${r.real ? '' : ' gh'}"><span>#${r.rank}</span><span>${esc(r.name)}${r.me ? `<i class="you">YOU${r.best ? ' · BEST TODAY' : ''}</i>` : r.real ? '' : '<i>GHOST</i>'}</span><span>${fmt(r.score)}</span></div>`); prev = i; }
    h.push(`<div class="lnote">${board.anyGhost ? 'GHOST = OFFLINE DEMO SCORES, NOT REAL PLAYERS' : this.online ? "LIVE BOARD - TODAY'S TITAN" : ''}</div>`);
    return h.join('');
  },
  // fight end: keep the best per window on the server; resolves with true when the board was refreshed
  // o.fight / o.titan: a stored run sent late (CYCLE mode, the app was closed at the fight's end; server grace ~2 min)
  async submit(o) {
    const fight = o.fight ?? (this.fight == null ? null : MODE === 'cycle' ? this.fight : this.serverCycle()), titan = o.titan ?? this.titan;
    if (!CONFIGURED || fight == null || !(o.score > 0)) return false;
    if (!(await register())) return false;
    try {
      const j = await rpc('submit_score', { p_id: ID.id, p_secret: ID.secret, p_fight: fight, p_titan: titan, p_damage: Math.round(o.score),
        p_combo: Math.floor(o.combo || 0), p_taps: Math.floor(o.taps || 0), p_up_tap: o.up.tap | 0, p_up_slash: o.up.slash | 0, p_up_crit: o.up.crit | 0 });
      if (!j || !j.ok) { this.lastError = j && j.error; return false; }
      this.take(j); return true;
    } catch (e) { return false; }
  },
  totals(scope) { return rpc('get_totals', { p_scope: scope, p_id: ID.id, p_fight: this.day(), p_limit: BOARD_N }); },
  // one tiny read at boot: brings the server clock (offset) before the cycle state machine needs it
  sync() { return rpc('get_board', { p_titan: 0, p_fight: this.day(), p_id: null, p_limit: 1 }).catch(() => null); },
  titanBoard() { return rpc('get_board', { p_titan: this.titan, p_fight: null, p_id: ID.id, p_limit: BOARD_N }); },
  label() { const el = document.querySelector('#live .lv-h i'); if (!el) return; const g = this.ghostKeep(49) > 0;
    el.textContent = !g ? '' : this.real.length ? 'GHOST rows = demo scores' : 'GHOST = offline demo scores'; },
};
function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ---------------------------------------------------------------- nickname
async function setNick(n) {
  ID.nick = n; ID.nickPending = n; saveId(); paintNick();
  if (!CONFIGURED || !(await register())) return true; // synced at the next register
  try { const j = await rpc('lb_set_nick', { p_id: ID.id, p_secret: ID.secret, p_nick: n }); if (j && j.ok) { delete ID.nickPending; saveId(); return true; } return false; }
  catch (e) { return true; }
}
function paintNick() { document.querySelectorAll('.lbNickBtn b').forEach((b) => { b.textContent = ID.nick; }); }
function openNick() {
  let p = document.getElementById('lbNick');
  if (!p) {
    p = document.createElement('div'); p.id = 'lbNick'; p.className = 'panel hidden';
    p.innerHTML = '<div class="card plate"><span><button class="nk-back" aria-label="Back"></button><h2>YOUR NAME</h2><small>Shown on the leaderboard. 3-16 letters, digits, _ or -</small>' +
      '<input id="lbNickIn" maxlength="16" autocomplete="off" autocapitalize="off" spellcheck="false"><em id="lbNickErr"></em>' +
      '<div class="lbBtns"><button class="btn" id="lbNickNo">CANCEL</button><button class="btn hot" id="lbNickOk">SAVE</button></div></span></div>';
    document.body.appendChild(p);
    const inp = p.querySelector('input'), err = p.querySelector('#lbNickErr'), close = () => p.classList.add('hidden');
    inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') p.querySelector('#lbNickOk').click(); if (e.key === 'Escape') close(); });
    inp.addEventListener('input', () => { inp.value = inp.value.replace(/[^A-Za-z0-9_-]/g, ''); err.textContent = ''; });
    p.querySelector('#lbNickNo').onclick = close; p.querySelector('.nk-back').onclick = close;
    p.querySelector('#lbNickOk').onclick = async () => { const v = inp.value.trim();
      if (!nickOk(v)) { err.textContent = NICK_RE.test(v) ? 'Please pick another name' : '3-16 letters, digits, _ or -'; return; }
      const ok = await setNick(v); if (ok) close(); else err.textContent = 'Please pick another name'; };
  }
  p.querySelector('input').value = ID.nick; p.querySelector('#lbNickErr').textContent = ''; p.classList.remove('hidden'); setTimeout(() => p.querySelector('input').focus(), 50);
}
function nickBtn() { const b = document.createElement('button'); b.className = 'lbNickBtn'; b.innerHTML = `&#9998; <b>${esc(ID.nick)}</b>`; b.onclick = (e) => { e.stopPropagation(); openNick(); }; return b; }

// ---------------------------------------------------------------- results tabs (TODAY'S TITAN / THIS TITAN ALL TIME / ALL TIME)
LB.mountResults = function (renderHour, fmt) {
  const board = document.getElementById('resBoard'); if (!board) return; let bar = document.getElementById('lbTabs');
  if (!bar) { bar = document.createElement('div'); bar.id = 'lbTabs'; board.parentNode.insertBefore(bar, board); }
  bar.innerHTML = ''; bar.appendChild(nickBtn());
  { const d = document.createElement('div'); d.className = 'lbToday'; d.textContent = LB.todayText(); bar.appendChild(d); } // today's titan + next-titan countdown (menu / board only)
  if (!CONFIGURED) return;
  // 'hour' = today's board (key kept: main.js passes renderHour for it)
  const tabs = [['hour', "TODAY'S TITAN"], ['titan', 'THIS TITAN, ALL TIME'], ['all', 'ALL TIME']];
  for (const [k, t] of tabs) { const b = document.createElement('button'); b.className = 'lbTab' + (k === 'hour' ? ' on' : ''); b.textContent = t; b.dataset.k = k; bar.appendChild(b);
    b.onclick = async (e) => { e.stopPropagation(); bar.querySelectorAll('.lbTab').forEach((x) => x.classList.toggle('on', x === b));
      if (k === 'hour') return renderHour();
      board.innerHTML = '<div class="lnote">LOADING...</div>';
      try { const j = k === 'titan' ? await LB.titanBoard() : await LB.totals(k); if (!b.classList.contains('on')) return;
        const rows = (j.top || []).map((a, i) => ({ name: a[0], score: +a[1], me: !!a[2], real: true, rank: i + 1 })).concat((j.around || []).map((a) => ({ rank: +a[0], name: a[1], score: +a[2], me: !!a[3], real: true })));
        if (!rows.length) { board.innerHTML = '<div class="lnote">NO SCORES YET</div>'; return; }
        if (!rows.some((r) => r.me)) rows.push({ name: ID.nick, score: 0, me: true, real: true, rank: (+j.total || rows.length) + 1 });
        board.innerHTML = LB.rowsHtml(rows, fmt).replace(/<div class="lnote">[^<]*<\/div>$/, `<div class="lnote">${k === 'titan' ? 'BEST DAY PER PLAYER VS THIS TITAN' : k === 'day' ? 'TOTAL DAMAGE TODAY (UTC)' : 'TOTAL DAMAGE, ALL TIME (BEST FIGHT PER DAY)'}</div>`);
      } catch (err) { board.innerHTML = '<div class="lnote">OFFLINE</div>'; } };
  }
};
LB.nickBtn = nickBtn; LB.openNick = openNick; // 11-26: the PROFILE panel (hud-menu.js) owns the nickname now
LB.rpc = rpc; LB.register = register; LB.auth = () => ({ p_id: ID.id, p_secret: ID.secret }); // 11-27 rewards.js (daily winner rewards)
LB.mountLobby = function () { const box = document.querySelector('#lobbyBox > span'); if (box && !box.querySelector('.lbNickBtn')) box.appendChild(nickBtn()); };
// "Today: <titan> · new titan in HH:MM" for a menu / profile element (not a lobby timer); refreshes once a minute
LB.mountToday = function (el) { if (!el) return; const f = () => { el.textContent = LB.todayText(); }; f(); clearInterval(el._lbT); el._lbT = setInterval(f, 30000); };

// ---------------------------------------------------------------- styles (kept here so style.css stays untouched)
{ const st = document.createElement('style'); st.textContent = `
.lbNickBtn{pointer-events:auto;font:700 13px/1 'Barlow Condensed',sans-serif;letter-spacing:.06em;color:#d9ccff;background:rgba(20,10,45,.55);border:1px solid rgba(170,140,255,.45);border-radius:999px;padding:5px 11px;margin:8px auto 0;display:inline-block;cursor:pointer}
.lbNickBtn b{color:#fff}
#lbTabs{display:flex;flex-wrap:wrap;gap:5px;align-items:center;justify-content:center;margin:6px 0 4px}
#lbTabs .lbNickBtn{margin:0 6px 0 0}
.lbTab{pointer-events:auto;font:700 12px/1 'Barlow Condensed',sans-serif;letter-spacing:.06em;color:#bfb0ee;background:rgba(20,10,45,.5);border:1px solid rgba(170,140,255,.3);border-radius:6px;padding:5px 8px;cursor:pointer}
.lbTab.on{color:#fff;background:rgba(120,80,230,.6);border-color:rgba(210,190,255,.8)}
.lbToday{flex-basis:100%;text-align:center;font:700 11px/1.2 'Barlow Condensed',sans-serif;letter-spacing:.08em;color:#cdbff5;opacity:.85}
.lrow.gh{opacity:.78}.lrow i.you{color:#ffe08a;font-style:normal;margin-left:6px;font-size:.8em}
#live .lv.gh span:nth-child(2)::after{content:' GHOST';font-size:.7em;opacity:.65;font-style:italic}
#lbNick{z-index:60}#lbNick .card{max-width:340px;margin:auto}#lbNick small{display:block;opacity:.75;margin:4px 0 10px}
#lbNickIn{font:700 20px/1.2 'Barlow Condensed',sans-serif;width:100%;box-sizing:border-box;padding:8px 10px;border-radius:8px;border:1px solid rgba(190,160,255,.6);background:rgba(10,5,25,.7);color:#fff;text-align:center}
#lbNickErr{display:block;min-height:1.2em;color:#ff8a9a;font-style:normal;margin:6px 0}
#lbNick .lbBtns{display:flex;gap:10px;justify-content:center}#lbNick .nk-back{display:none}
`; document.head.appendChild(st); }

if (CONFIGURED) { register(); LB.sync(); }
if (typeof window !== 'undefined') window.__lb = LB;
