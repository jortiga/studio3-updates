// Titan Slasher DAILY REWARDS (11-26), ported from Runebound's 30-day popup (rougulike/game/main.js trackPop / claimLogin / loginInfo,
// commit e10aa40) and its server clock (dailyNow, commit 49e3e81). Balance: data/daily.json (live-updatable).
//
// ONE popup, two things:
//  (a) a repeating 7-day LOGIN cycle (daily.json weeks: coins and item chests rising through the week, an epic / legendary chest on
//      day 7; 4 weeks rotate, then coins x coinRot per rotation),
//  (b) a 30-DAY TRACK toward an exclusive legendary blade (items.json trackOnly: Skyrender, never in shops / drops / chests).
// One free claim per LOCAL day ("CLAIM DAY n") pays today's login reward AND +1 track day. A rewarded ad adds track days only (+2 before
// the free claim, +1 after it; max track.perDayMax a day), hidden until daily.json ads.enabled and window.__rewardedAd exist (AdMob later).
// A missed day costs nothing: no streak reset, you continue at the next day. Day 1 is the first calendar day AFTER a new player's first
// day (startAfterDays; existing players at once). Before the free claim the popup can't be closed (Runebound: the claim is one tap).
// Once the track is done the blade stays on the card as an OWNED showcase.
//
// Clock (anti-cheat): "today" = dailyNow() = trusted server time when we have it: Supabase (leaderboard.js puts the server's `now`
// into LB.offset on every board fetch) > the Date header of our own file (Date or Date + Age, whichever is closer to the device
// clock, Runebound 11-17; not on a Capacitor localhost, where that header is the phone's own clock) > the device clock (offline).
// SAVE.daily.hi = the latest trusted time seen. Offline, a device clock that went BACK (before hi) blocks the claim, and an offline
// claim can be at most 1 day past the last trusted day; a claim made with a forwarded clock only borrows tomorrow's (the stored day
// stays ahead of the real one until real time catches up).
//
// API (lobby UI): window.DAILY = { open, claimable, isOpen, lobby }. main.js calls DAILY.init(ctx) once and DAILY.lobby() on every
// lobby entry (auto-opens once per local day when the free claim is open; never in a fight).
// Test: ?dayoffset=N (shift "today" by N days, persists in the save like a real day passing), ?track=N (track progress N, claimable
// now), ?devskew=H (fake the device clock by H hours), ?noclock=1 (no server time: offline), ?dailyreset=1 (wipe the daily save).
import * as EQ from './equipment.js';
import PASS from './pass.js'; // ?pass=N game pass: a scaled game day (DAY / N) in its own save (tt_save_pass)
import { UI, itemIcon } from './uiart.js';

const Q = new URLSearchParams(location.search);
const DAY = 86400000 / PASS.N, $ = (id) => document.getElementById(id);
const fmt = (n) => Math.round(n).toLocaleString('en-US');
const DAYOFF = (+Q.get('dayoffset') || 0) * DAY, DEVSKEW = (+Q.get('devskew') || 0) * 3600000, NOCLOCK = Q.get('noclock') === '1', AUTO = Q.get('auto') === '1';
let D = null, C = null, el = null, busy = false;

// ---------------- clock ----------------
const deviceNow = () => Date.now() + DEVSKEW;
let hdrSkew = null, clockDone = NOCLOCK; // hdrSkew: server - real Date.now(); clockDone: a source answered (or failed / timed out)
const lbNow = () => { const lb = window.__lb; return !NOCLOCK && lb && lb.online && lb.offset ? Date.now() + lb.offset : null; };
function trustedNow() { const l = lbNow(); if (l != null) return l; return hdrSkew != null ? Date.now() + hdrSkew : null; }
export const dailyNow = () => (trustedNow() ?? deviceNow()) + DAYOFF;
const dayOf = (t) => Math.floor((t - new Date(t).getTimezoneOffset() * 60000) / DAY);
const localDay = () => dayOf(dailyNow());
if (!NOCLOCK && location.hostname !== 'localhost') {
  fetch('index.html?t=' + Date.now(), { method: 'HEAD', cache: 'no-store' }).then((r) => {
    const d = Date.parse(r.headers.get('date')); if (!d) return;
    const a = d - Date.now(), b = a + (+r.headers.get('age') || 0) * 1000; hdrSkew = Math.abs(b) < Math.abs(a) ? b : a;
  }).catch(() => {}).finally(() => { clockDone = true; refresh(); });
} else clockDone = true;
setTimeout(() => { if (!clockDone) { clockDone = true; refresh(); } }, 4000);
const clockReady = () => clockDone || trustedNow() != null;
// tamper check: null = fine, else the reason the claim is blocked
function clockBad() {
  const S = st(), tr = trustedNow();
  if (tr != null) { S.hi = Math.max(S.hi || 0, tr); return null; }
  if (!S.hi) return null; // never had a trusted time: device clock (Runebound's offline rule)
  const now = deviceNow();
  if (now < S.hi - 10 * 60000) return 'Your clock went back. Connect to the internet to claim.';
  if (dayOf(now + DAYOFF) > dayOf(S.hi + DAYOFF) + 1) return 'Connect to the internet to claim.';
  return null;
}

// ---------------- state ----------------
// SAVE.daily = { n: login claims, day: last login claim's local day, last: today's loot, start, auto: last auto-open day, hi,
//               t: { n: track days, day, got: days gained that day, unlocked } }
function st() {
  const S = C.SAVE;
  if (!S.daily || Q.get('dailyreset') === '1' && !st.reset) { st.reset = 1; S.daily = { n: 0, day: -1, t: { n: 0, day: -1, got: 0 }, start: (S.titans || 0) > 0 ? 0 : dayOf(deviceNow() + DAYOFF) }; C.save(); }
  return S.daily;
}
const T = () => st().t;
const W = () => D.weeks;
const shown = () => !!D && !AUTO && (Q.has('track') || (C.SAVE.titans || 0) >= (D.minFights ?? 1));
const dayOk = () => Q.has('track') || localDay() >= st().start + (D.startAfterDays ?? 1);
const loginClaimedToday = () => st().day >= localDay();
const loginReady = () => shown() && dayOk() && !loginClaimedToday();
const trackGot = () => (T().day === localDay() ? T().got || 0 : 0);
const adsOk = () => !!(D && D.ads && D.ads.enabled && typeof window.__rewardedAd === 'function');
const freeOpen = () => shown() && dayOk() && (loginReady() || (!T().unlocked && trackGot() === 0));
const adOpen = () => shown() && dayOk() && !T().unlocked && adsOk() && trackGot() < (D.track.perDayMax || 2);
const TRACK_N = () => D.track.days || 30;
const trackItem = () => EQ.DATA && EQ.DATA.byId[D.track.item];

// what login claim n (0-based) gives: { day 1-7, week, name, k, v | r, icon, short, rar }
const RAR = (r) => (EQ.DATA ? EQ.DATA.rarity[r] : { name: ['Common', 'Rare', 'Epic', 'Legendary'][r], color: ['#d8d8e0', '#5fb4ff', '#c07aff', '#ffa040'][r] });
const gemsIcon = (v) => `${UI}/daily/gems_${v < 700 ? 1 : v < 1800 ? 2 : 3}.webp`;
function info(n) {
  const wk = W(), i = n % 7, w = Math.floor(n / 7) % wk.length, rot = Math.floor(n / (7 * wk.length)), R = wk[w].days[i], base = { day: i + 1, week: w, wname: wk[w].name };
  // 11-27 text says "shards" (the game's currency name); the data kind stays 'coins' until the economy build replaces these rewards
  if (R.k === 'coins') { const v = Math.round(R.v * Math.pow(D.coinRot || 1.5, rot) / 10) * 10; return { ...base, k: 'coins', v, icon: gemsIcon(v), short: `${fmt(v)} shards`, tag: fmt(v), rar: v >= 1800 ? 2 : v >= 700 ? 1 : 0, col: '#ffd35a' }; }
  const r = R.r | 0, rr = RAR(r); return { ...base, k: 'chest', r, icon: `${UI}/daily/chest_${r}.webp`, short: `${rr.name} chest`, tag: rr.name.toUpperCase(), rar: r, col: rr.color };
}
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

// an item of exactly rarity r (falls to lower rarities if empty), never trackOnly / starter; items you don't own first
function chestItem(r) {
  const X = EQ.DATA; if (!X) return null;
  for (let q = r; q >= 0; q--) {
    const pool = X.items.filter((d) => d.rarity === q && !d.trackOnly && !X.starter.includes(d.id)); if (!pool.length) continue;
    const fresh = pool.filter((d) => !EQ.owned(d.id)), use = fresh.length ? fresh : pool;
    return use[Math.floor(Math.random() * use.length)].id;
  }
  return null;
}

// ---------------- claim ----------------
async function claim(ad) {
  if (busy || !clockReady() || clockBad()) return;
  const t = T();
  if (ad) { if (!adOpen()) return; busy = true; let ok = false; try { ok = !!(await window.__rewardedAd(D.ads.placement || 'daily30')); } catch (e) {} busy = false; if (!ok || !adOpen()) return; }
  else if (!freeOpen()) return;
  const got = trackGot(), unlocked0 = !!t.unlocked, max = D.track.perDayMax || 2;
  const gain = unlocked0 ? 0 : ad ? max - got : got === 0 ? 1 : 0;
  if (gain) { t.n = Math.min(TRACK_N(), t.n + gain); t.day = localDay(); t.got = got + gain; }
  const justUnlocked = !unlocked0 && t.n >= TRACK_N();
  let loot = null; const S = st();
  if (loginReady()) { // the free claim (or an ad claim made before it) also pays today's login reward
    const inf = info(S.n); S.n++; S.day = localDay();
    if (inf.k === 'coins') { C.SAVE.coins += inf.v; loot = { k: 'coins', v: inf.v, n: S.n - 1 }; }
    else { const id = chestItem(inf.r), g = id && EQ.grant(id); loot = { k: 'chest', r: inf.r, n: S.n - 1, id, dup: g ? g.dup : false, lv: g ? g.it.lv : 0 }; }
    S.last = { ...loot, day: S.day };
  }
  let blade = null;
  if (justUnlocked) { t.unlocked = true; const d = trackItem(); if (d) { const g = EQ.grant(d.id); EQ.equip(g.it); blade = d; } }
  C.save(); busy = true;
  await animateClaim(loot, gain, blade);
  busy = false; render(); C.coinHud && C.coinHud(); C.onChange && C.onChange();
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
// 11-27 v2 (user: "too much stuff"): no big reward stage any more - today's grid cell shakes + bursts; shards fly from it into the
// shard pill, a chest opens in a short overlay over the frame (item + name, tap or ~2 s), then the cell is stamped
async function animateClaim(loot, gain, blade) {
  const box = el.querySelector('.dframe'), cell = el.querySelector('.dt.now'), btn = el.querySelector('.dclaim');
  hideTip();
  if (btn) { btn.disabled = true; btn.classList.add('going'); }
  if (loot) {
    const col = loot.k === 'coins' ? '#ffd35a' : RAR(loot.r).color;
    if (cell) { cell.classList.add('shake'); C.sfx('charge'); await wait(620); cell.classList.remove('shake'); cell.classList.add('burst'); }
    sparks(fxAt(box, cell), col, 16);
    if (loot.k === 'chest') { C.sfx(loot.r >= 2 ? 'rank' : 'card'); await gotPop(box, loot); }
    else { C.sfx('card'); await flyCoins(cell || box, el.querySelector('.dcoin b'), loot.v); }
  }
  // stamp today's cell
  if (cell && (gain || loot)) { cell.classList.remove('now', 'burst'); cell.classList.add('on', 'stamp'); C.sfx('buy'); }
  const bar = el.querySelector('.dbar i'); if (bar) bar.style.width = `${Math.round(100 * T().n / TRACK_N())}%`;
  const num = el.querySelector('.dprog b'); if (num) num.textContent = `DAY ${T().n}`;
  await wait(600);
  if (blade) await bladeReveal(blade);
}
// a positioned spark host at an element's centre inside the frame (the cells clip their own content)
function fxAt(box, ref) {
  const h = document.createElement('i'); h.className = 'dfx'; const b = box.getBoundingClientRect(), r = (ref || box).getBoundingClientRect();
  h.style.left = `${r.left - b.left - box.clientLeft + r.width / 2}px`; h.style.top = `${r.top - b.top - box.clientTop + box.scrollTop + r.height / 2}px`; box.appendChild(h); setTimeout(() => h.remove(), 1300); return h;
}
// the chest result: open chest + the item over the frame, gone on tap or after ~2 s
function gotPop(box, loot) {
  return new Promise((done) => {
    const d = loot.id && EQ.DATA && EQ.def(loot.id), o = document.createElement('div'); o.className = 'dgot'; o.style.setProperty('--c', RAR(d ? d.rarity : loot.r).color);
    o.innerHTML = `<div class="dgstage"><i class="drays"></i><img class="dgchest" src="${UI}/daily/open_${loot.r}.webp" alt="">${d ? `<img class="dgitem${d.slot === 'weapon' ? ' wpn' : ''}" src="${itemIcon(d.icon)}" alt="">` : ''}</div><b>${lootName(loot)}</b><small>TAP TO CONTINUE</small>`;
    box.appendChild(o); sparks(o.querySelector('.dgstage'), RAR(loot.r).color, 14);
    let t = 0; const end = () => { if (t < 0) return; clearTimeout(t); t = -1; o.classList.add('out'); setTimeout(() => { o.remove(); done(); }, 220); };
    o.addEventListener('click', (e) => { e.stopPropagation(); end(); }); t = setTimeout(end, 2200);
  });
}
function lootName(l) {
  if (!l) return '';
  if (l.k === 'coins') return `${fmt(l.v)} shards`;
  const d = l.id && EQ.DATA && EQ.def(l.id); if (!d) return `${RAR(l.r).name} chest`;
  return `<span style="color:${RAR(d.rarity).color}">${d.name}</span> <em>${l.dup ? `+1 LV (${l.lv})` : 'NEW!'}</em>`;
}
function sparks(host, col, n) {
  for (let i = 0; i < n; i++) {
    const s = document.createElement('i'); s.className = 'dspark'; const a = Math.random() * Math.PI * 2, r = 60 + Math.random() * 90;
    s.style.cssText = `--c:${col};--x:${Math.cos(a) * r}px;--y:${Math.sin(a) * r * .8 - 30}px;animation-delay:${Math.random() * .12}s`;
    host.appendChild(s); setTimeout(() => s.remove(), 1100);
  }
}
function flyCoins(from, to, v) {
  return new Promise((done) => {
    if (!from || !to) return done();
    const a = from.getBoundingClientRect(), b = to.getBoundingClientRect(), N = 14, c0 = C.SAVE.coins - v; let left = N;
    to.textContent = fmt(c0);
    for (let i = 0; i < N; i++) {
      const c = document.createElement('div'); c.className = 'flycoin'; c.textContent = '◆'; document.body.appendChild(c);
      const x0 = a.left + a.width * (.3 + Math.random() * .4), y0 = a.top + a.height * .45, x1 = b.left + b.width * .3, y1 = b.top + b.height * .5;
      c.animate([{ transform: `translate(${x0}px, ${y0}px) scale(.6)`, opacity: 0 }, { transform: `translate(${x0 + (Math.random() - .5) * 140}px, ${y0 - 50 - Math.random() * 80}px) scale(1.25)`, opacity: 1, offset: .35 }, { transform: `translate(${x1}px, ${y1}px) scale(.7)`, opacity: 1 }],
        { duration: 650 + i * 40, delay: i * 50, easing: 'cubic-bezier(.4,0,.6,1)', fill: 'forwards' }).onfinish = () => {
        c.remove(); C.sfx('coin'); to.textContent = fmt(c0 + v * (N - left + 1) / N); const p = to.parentElement; p.classList.remove('pop'); void p.offsetWidth; p.classList.add('pop');
        if (--left === 0) { const hud = $('coinN'); if (hud) hud.textContent = fmt(C.SAVE.coins); done(); }
      };
    }
  });
}
function bladeReveal(d) {
  return new Promise((done) => {
    const o = document.createElement('div'); o.className = 'dreveal';
    o.innerHTML = `<i class="drays big"></i><img src="${itemIcon(d.icon)}" alt=""><small>30-DAY REWARD COMPLETE</small><b>${d.name.toUpperCase()}</b><p>${D.track.pitch}.<br>Equipped. Find it in GEAR.</p><button class="btn hot">AWESOME</button>`;
    el.querySelector('.dframe').appendChild(o); C.sfx('victory'); sparks(o, '#ff7cf0', 16); setTimeout(() => sparks(o, '#7ff6ff', 16), 250);
    o.querySelector('button').onclick = () => { C.sfx('click'); o.remove(); done(); };
  });
}

// ---------------- popup ----------------
// 11-27 v2 layout (user iPhone: "too much stuff in here" + "I need to see the 30-day reward sword"): one header row (DAILY REWARDS +
// shard pill), the Skyrender hero strip (big glowing blade + DAY n / 30 bar), the 30-day grid (today glows with its reward, tap any
// cell for a tooltip), ONE action row at the bottom (CLAIM DAY n, or "NEXT IN hh:mm:ss" on the daily server clock + the small ad).
// Once the blade is owned the grid becomes this week's 7 login days.
function ensure() {
  if (el) return el;
  if (!document.querySelector('link[href="daily.css"]')) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'daily.css'; document.head.appendChild(l); }
  el = document.createElement('div'); el.id = 'dailyPop'; el.className = 'panel hidden'; document.body.appendChild(el);
  el.addEventListener('pointerdown', (e) => e.stopPropagation());
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-d]'); if (busy) return;
    if (!b) { hideTip(); if (e.target === el && !freeOpen()) close(); return; } // backdrop closes only once the free claim is done
    const k = b.dataset.d;
    if (k === 'tip') return showTip(b, tips[b.dataset.i]);
    hideTip(); C.sfx('click');
    if (k === 'free') claim(false); else if (k === 'ad') claim(true); else if (k === 'close') close();
  });
  return el;
}
// tooltip over a cell / the hero strip (one at a time; tap it again or anywhere else hides it)
let tips = {}, tipFor = null;
function hideTip() { if (!el) return; el.querySelectorAll('.dtip').forEach((t) => t.remove()); if (tipFor) tipFor.classList.remove('tipon'); tipFor = null; }
function showTip(ref, html) {
  const box = el.querySelector('.dframe'); if (!box || !html) return;
  if (tipFor === ref) return hideTip();
  hideTip(); C.sfx('click'); tipFor = ref; ref.classList.add('tipon');
  const t = document.createElement('div'); t.className = 'dtip'; t.innerHTML = html; box.appendChild(t);
  const b = box.getBoundingClientRect(), r = ref.getBoundingClientRect(), ox = b.left + box.clientLeft, oy = b.top + box.clientTop - box.scrollTop, w = t.offsetWidth, h = t.offsetHeight;
  const cx = r.left - ox + r.width / 2, x = Math.max(4, Math.min(box.clientWidth - w - 4, cx - w / 2)); // the frame clips at its padding box
  const up = r.top - h - 10 > b.top + box.clientTop, y = up ? r.top - oy - h - 8 : r.bottom - oy + 8;
  t.classList.add(up ? 'up' : 'dn'); t.style.left = `${x}px`; t.style.top = `${y}px`; t.style.setProperty('--ax', `${Math.round(cx - x)}px`);
}
const pad = (n) => String(n).padStart(2, '0');
const hms = (ms) => { const s = Math.ceil(ms / 1000); return `${Math.floor(s / 3600)}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}`; };
// time to the next local day on the daily clock (dayOf's boundary: t - tzOffset = (day + 1) * DAY)
const nextIn = () => { const n = dailyNow(); return Math.max(0, (localDay() + 1) * DAY + new Date(n).getTimezoneOffset() * 60000 - n); };
let shownDay = null, tick = 0;
function onTick() {
  if (!isOpen()) { clearInterval(tick); tick = 0; return; }
  if (busy) return;
  if (shownDay !== localDay()) return render(); // a new day: the claim opens
  const b = el.querySelector('.dnext b'); if (b) b.textContent = hms(nextIn());
}
function render() {
  if (!el || el.classList.contains('hidden') || !D) return;
  hideTip(); shownDay = localDay();
  const S = st(), t = T(), L = S.n, claimed = loginClaimedToday(), fo = freeOpen() && shown(), ao = adOpen(), got = trackGot(), own = !!t.unlocked, N = TRACK_N();
  const notYet = !claimed && !fo && !ao, bad = clockReady() ? clockBad() : null, sync = !clockReady(), blade = trackItem();
  const bname = blade ? blade.name.toUpperCase() : 'LEGENDARY BLADE', bimg = blade ? itemIcon(blade.icon) : '';
  const dayTip = (head, r) => `<small>${head}</small><b>${cap(r.short)}</b>${r.k === 'chest' ? `<em>One ${RAR(r.r).name.toLowerCase()} item</em>` : ''}`;
  const bladeTip = `<small>DAY ${N} · LEGENDARY BLADE</small><b>${bname}</b><em>${D.track.pitch}.</em><em>${own ? 'Yours to keep · find it in GEAR.' : 'Every daily claim adds a day. Missed days never reset the track.'}</em>`;
  tips = { hero: bladeTip };
  // the grid: 30 track days (each coming day shows its login reward: claim L + (i - t.n)), or this week's 7 login days once owned
  let cells;
  if (!own) {
    cells = Array.from({ length: N }, (_, i) => {
      const last = i === N - 1, r = info(Math.max(0, L + (i - t.n))), now = i === t.n && fo, done = i < t.n;
      tips[i] = last ? bladeTip : dayTip(`DAY ${i + 1}${now ? ' · TODAY' : done ? ' · CLAIMED ✓' : ''}`, r);
      const cls = `dt${done ? ' on' : ''}${now ? ' now' : ''}${last ? ' end' : r.k === 'chest' && r.r >= 2 ? ' m' : ''}`;
      const img = last ? (bimg ? `<img class="wpn" src="${bimg}" alt="">` : '★') : `<img src="${r.icon}" alt="">`;
      return `<i class="${cls}" style="--c:${last ? '#ffd35a' : r.col}" data-d="tip" data-i="${i}">${img}<b>${i + 1}</b>${now ? `<em>${r.tag}</em>` : ''}<s>✓</s></i>`;
    }).join('');
  } else {
    const cur = claimed ? L - 1 : L, base = Math.max(0, cur - (cur % 7));
    cells = Array.from({ length: 7 }, (_, k) => {
      const n = base + k, r = info(n), now = n === L && loginReady(), done = n < L;
      tips[k] = dayTip(`WEEK ${r.week + 1} · ${r.wname} · DAY ${k + 1}${now ? ' · TODAY' : done ? ' · CLAIMED ✓' : ''}`, r);
      return `<i class="dt${done ? ' on' : ''}${now ? ' now' : ''}${r.k === 'chest' && r.r >= 2 ? ' m' : ''}" style="--c:${r.col}" data-d="tip" data-i="${k}"><img src="${r.icon}" alt=""><b>${k + 1}</b>${now ? `<em>${r.tag}</em>` : ''}<s>✓</s></i>`;
    }).join('');
  }
  const pct = Math.round(100 * t.n / N);
  const hero = `<div class="dhero${own ? ' own' : ''}" data-d="tip" data-i="hero"><div class="dsword"><i class="drays"></i>${bimg ? `<img src="${bimg}" alt="">` : ''}</div>
    <div class="dhtxt"><small>${own ? `${N}-DAY REWARD · OWNED` : `DAY ${N} · LEGENDARY`}</small><b>${bname}</b>${own ? '<em>Yours to keep · find it in GEAR</em>'
      : `<div class="dprog"><b>DAY ${t.n}</b><span>/ ${N}</span>${got && adsOk() ? `<em>ads ${got}/${D.track.perDayMax || 2}</em>` : ''}</div><i class="dbar"><i style="width:${pct}%"></i></i>`}</div><i class="dinfo">i</i></div>`;
  // ONE action row: CLAIM (free claim open) or the next-day timer; the rewarded-ad track skip stays as a small button beside it
  const claimN = own ? info(L).day : t.n + 1;
  const ad = ao ? `<button class="btn dad" data-d="ad">▶ AD<small>+${got === 0 ? 2 : 1} DAY${got === 0 ? 'S' : ''}</small></button>` : '';
  const act = fo ? `<button class="btn hot dclaim" data-d="free" ${sync || bad ? 'disabled' : ''}>${sync ? 'SYNCING TIME…' : loginReady() ? `CLAIM DAY ${claimN}` : 'CLAIM +1 DAY'}</button>`
    : `<p class="dnext${notYet ? ' soon' : ''}"><small>${notYet ? 'REWARDS START TOMORROW · IN' : '✓ CLAIMED · NEXT IN'}</small><b>${hms(nextIn())}</b></p>`;
  el.innerHTML = `<div class="dframe"><div class="dhead"><b class="dtitle">DAILY REWARDS</b><div class="dcoin"><i class="gem">&#9670;</i> <b>${fmt(C.SAVE.coins)}</b></div></div>
    <div class="dbody">${hero}${own ? `<small class="dwk">THIS WEEK · ${info(claimed ? L - 1 : L).wname}</small>` : ''}<div class="dgrid${own ? ' wk' : ''}">${cells}</div><div class="dact"><div class="drow">${act}${ad}</div>${bad ? `<p class="dsub bad">${bad}</p>` : ''}</div></div></div>`;
  if (!tick) tick = setInterval(onTick, 1000);
}
let wantOpen = false;
export function open() {
  if (!D || !C) { wantOpen = true; return false; } // still loading: opens once daily.json is in
  if (C.inFight && C.inFight()) return false; // never during a fight
  warmArt(); ensure(); const fresh = el.classList.contains('hidden'); el.classList.remove('hidden'); if (fresh) { el.classList.remove('go'); void el.offsetWidth; el.classList.add('go'); C.sfx('card'); }
  render(); return true;
}
export function close() { if (!el || busy) return; hideTip(); el.classList.add('hidden'); clearInterval(tick); tick = 0; C.onChange && C.onChange(); }
export const isOpen = () => !!el && !el.classList.contains('hidden');
export const claimable = () => !!D && !!C && clockReady() && freeOpen() && !clockBad();
function refresh() { render(); if (pendingAuto) lobby(); }
let pendingAuto = false;
// warm the popup art so the first open (and the chest swap on CLAIM) never shows empty tiles. 11-26 load speed: no longer at boot,
// only when the popup is about to open (lobby entry with a claim open, ~900 ms ahead of the auto-open) or on open()
let warmed = false;
function warmArt() {
  if (warmed || !D) return; warmed = true;
  for (const f of ['chest_0', 'chest_1', 'chest_2', 'chest_3', 'open_0', 'open_1', 'open_2', 'open_3', 'gems_1', 'gems_2', 'gems_3']) new Image().src = `${UI}/daily/${f}.webp`;
  new Image().src = `${UI}/panel.webp`; const ti = EQ.DATA && EQ.DATA.byId[D.track.item]; if (ti) new Image().src = `${itemIcon(ti.icon)}`;
}
// lobby entry: auto-open once per local day while the free claim is open
export function lobby() {
  pendingAuto = false; if (!D || !C || AUTO || isOpen()) return;
  if (claimable()) warmArt();
  if (!clockReady()) { pendingAuto = true; return; }
  if (!claimable() || st().auto === localDay()) return;
  setTimeout(() => { if (!C.inLobby || C.inLobby()) { if (!claimable() || st().auto === localDay()) return; st().auto = localDay(); C.save(); open(); } }, 900);
}
// ctx: { SAVE, save, sfx, coinHud, inFight(), inLobby(), onChange? }
export async function init(ctx) {
  C = ctx;
  try { D = await fetch('data/daily.json?' + Date.now()).then((r) => (r.ok ? r.json() : null)); } catch (e) { D = null; }
  if (!D) return;
  st();
  if (Q.has('track')) { const n = Math.max(0, +Q.get('track') || 0), N = TRACK_N(); st().t = n >= N ? { n: N, day: -1, got: 0, unlocked: true } : { n, day: -1, got: 0 }; st().day = -1; }
  if (wantOpen) { wantOpen = false; open(); } else if (pendingAuto) lobby();
}
window.DAILY = { open, claimable, isOpen, lobby, close, canClose: () => !freeOpen() && !busy, _st: () => C && st(), _now: dailyNow, _day: () => localDay(), _D: () => D };
