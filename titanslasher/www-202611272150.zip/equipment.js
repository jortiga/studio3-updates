// Titan Slasher equipment (11-26, modelled on Runebound's gear: slots, rarity colours, paper doll + bag).
// Data: data/items.json (items, rarity, costs, drops; balance there, live-updatable). Hero art: art/hero/*.webp (no sword) +
// data/hero_rig.json (per pose: TEXK, hand anchor + blade direction, weapon in front / behind; per weapon: grip point).
// Save: SAVE.inv = { items: [{ uid, id, lv }], eq: { slot: uid }, n: next uid }. Old SAVE.up (tap / slash / crit levels from the
// upgrades panel) is folded into the starter sword / amulet / ring levels once (items.json "migrate").
import * as THREE from 'three';

export let DATA = null, RIG = null;
// 11-26 INK STYLE TEST (?style=ink): the hero art comes from art/hero_ink/ (same frames / k as art/hero/, tools/make_ink_art.py);
// its hand / dir anchors are overridden from data/hero_rig_ink.json (fetched only with ?style=ink, default data untouched)
const INK = new URLSearchParams(location.search).get('style') === 'ink';
// 11-27 cloth scarf test (game/cloth.js): ?cloth=1 = verlet ribbon + scarf-less frames (art/hero_ink/noscarf/), ?cloth=2 = ribbon over the painted scarf
// 11-27 mask = whole head (?head=1, test): headless body frames art/hero_ink/body/ (tools/hero_headless.py) + one static head sprite
// per look (hero_rig_ink.json heads, tools/make_heads.py) at poses.*.hs; a Mask item swaps the whole head. Body has no scarf tails -> cloth on.
const HEAD = INK && new URLSearchParams(location.search).get('head') === '1';
const CLOTH = HEAD ? '1' : INK ? (new URLSearchParams(location.search).get('cloth') || '').replace(/^0$/, '') : '';
let SAVE = null, saveFn = () => {};
const listeners = new Set();
export const onChange = (f) => listeners.add(f);
const changed = () => { recompute(); saveFn(); listeners.forEach((f) => { try { f(); } catch (e) { console.error(e); } }); };

// live stats read by main.js (multipliers, crit chance 0..1). Before load(): the legacy upgrade formulas.
export const S = { tap: 1, fin: 1, crit: .05, critMul: 2, wp: 1, combo: 1, coins: 1, pct: {} };
export function init(save, fn) {
  SAVE = save; saveFn = fn; const u = SAVE.up || {};
  Object.assign(S, { tap: 1 + (u.tap || 0) * .25, fin: 1 + (u.slash || 0) * .3, crit: Math.min(.5, .05 + (u.crit || 0) * .02) });
}
export async function load() {
  const j = (p) => fetch(p + '?' + Date.now()).then((r) => r.ok ? r.json() : null).catch(() => null);
  let INKRIG = null;
  [DATA, RIG, INKRIG] = await Promise.all([j('data/items.json'), j('data/hero_rig.json'), INK ? j('data/hero_rig_ink.json') : null]);
  if (INK && RIG) {
    for (const o of [...Object.values(RIG.poses || {}), RIG.idle_anim]) if (o?.file) o.file = o.file.replace('art/hero/', 'art/hero_ink/'); // art/hero_ink/idle_anim.webp = the ink idle loop
    for (const [k, v] of Object.entries(INKRIG?.poses || {})) if (RIG.poses?.[k]) Object.assign(RIG.poses[k], v); // ink hero (v5 bug-knight): own hand / dir anchors incl. idle_0..5 (same frames / k)
    if (CLOTH === '1') for (const o of [...Object.values(RIG.poses || {}), RIG.idle_anim]) if (o?.file) o.file = o.file.replace('art/hero_ink/', HEAD ? 'art/hero_ink/body/' : 'art/hero_ink/noscarf/');
    for (const [k, v] of Object.entries(INKRIG?.weapons || {})) if (RIG.weapons?.[k]) Object.assign(RIG.weapons[k], v); // ink-only blade swaps (w_starter -> pale needle)
    RIG.masks = INKRIG?.masks || null; // 11-27 worn masks (Mask slot, key 'boots'): static sprite at poses.*.head (tools/hero_head.py)
    if (HEAD && INKRIG?.heads) { RIG.heads = INKRIG.heads; const q = new URLSearchParams(location.search).get('headdef'); RIG.headDef = RIG.heads[q] ? q : INKRIG.default_head || 'default'; RIG.headSeat = INKRIG.head_seat || [0, 0];
      if (CLOTH === '1') for (const p of Object.values(RIG.poses || {})) if (p.hn) p.neck = p.hn; } // 11-27 short neck: body/ wrap is a low collar, cloth root follows it down
  }
  if (!DATA) return;
  DATA.byId = Object.fromEntries(DATA.items.map((d) => [d.id, d]));
  migrate(); recompute();
}
function migrate() {
  let inv = SAVE.inv;
  if (!inv || !Array.isArray(inv.items)) {
    inv = SAVE.inv = { items: [], eq: {}, n: 1 };
    const up = SAVE.up || {}, lvOf = {};
    for (const [k, id] of Object.entries(DATA.migrate || {})) lvOf[id] = up[k] || 0;
    for (const id of DATA.starter) { const it = add(id, lvOf[id] || 0); inv.eq[DATA.byId[id].slot] = it.uid; }
    inv.migratedFrom = { ...up };
  }
  inv.items = inv.items.filter((it) => DATA.byId[it.id]); // items removed from the data file
  for (const [s, uid] of Object.entries(inv.eq)) if (!inv.items.some((it) => it.uid === uid)) delete inv.eq[s];
}
function add(id, lv = 0) { const inv = SAVE.inv, it = { uid: inv.n++, id, lv }; inv.items.push(it); return it; }

export const def = (it) => DATA.byId[typeof it === 'string' ? it : it.id];
export const rarity = (it) => DATA.rarity[def(it).rarity];
export const maxLv = (it) => rarity(it).maxLv;
export function statsAt(it, lv = it.lv) { // { stat: percent points } of one item at a level
  const d = def(it), m = DATA.rarity[d.rarity].mult, o = {};
  for (const k of new Set([...Object.keys(d.base || {}), ...Object.keys(d.per || {})])) { const v = ((d.base || {})[k] || 0) + ((d.per || {})[k] || 0) * lv; if (v) o[k] = v * m; }
  return o;
}
export function upgradeCost(it) { const d = def(it); return Math.round(d.cost0 * DATA.rarity[d.rarity].costK * Math.pow(d.growth, it.lv)); }
export const equipped = () => EQM ? { ...EQM } : Object.fromEntries(Object.entries(SAVE.inv?.eq || {}).map(([s, uid]) => [s, byUid(uid)]).filter((e) => e[1]));
let EQM = null; // 11-27 PERF PASS: equipped() built ONCE per updateVisuals (weaponDef / look / maskId rebuilt it 3-4x a frame); cleared after the frame's task
export const byUid = (uid) => SAVE.inv?.items.find((it) => it.uid === uid) || null;
export const isEquipped = (it) => SAVE.inv?.eq[def(it).slot] === it.uid;
export const items = () => SAVE.inv?.items || [];
export const owned = (id) => items().find((it) => it.id === id) || null;

// 11-28 user "the random sword must always be better, at least higher damage than what you have": every stat of the trial blade is at
// least your own sword's, and its attack + finisher are at least 25% + 15 points above it, whatever blade the reel lands on
export function trialStats(it = TRIAL) {
  const own = equipped().weapon, a = own ? statsAt(own) : {}, b = statsAt(it), o = {};
  for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) o[k] = Math.max(a[k] || 0, b[k] || 0);
  for (const k of ['tap', 'fin']) o[k] = Math.max(o[k] || 0, Math.ceil((a[k] || 0) * 1.25 + 15));
  return o;
}
// the live stats of your OWN gear (no trial blade): the time board sizes the titan's HP from these, so the ad blade really kills faster
export function ownStats() { const t = TRIAL; TRIAL = null; recompute(); const o = { ...S }; TRIAL = t; recompute(); return o; }
export function recompute() {
  if (!DATA || !SAVE.inv) return;
  const p = { tap: 0, fin: 0, crit: 0, critDmg: 0, wp: 0, combo: 0, coins: 0 }, eq = equipped();
  if (TRIAL) eq.weapon = TRIAL; // 11-27 pre-fight ad blade: its stats replace the sword's for one fight
  for (const it of Object.values(eq)) for (const [k, v] of Object.entries(it.trial ? trialStats(it) : statsAt(it))) p[k] = (p[k] || 0) + v;
  S.pct = p;
  S.tap = 1 + p.tap / 100; S.fin = 1 + p.fin / 100; S.crit = Math.min((DATA.caps?.crit ?? 60) / 100, .05 + p.crit / 100);
  S.critMul = 2 * (1 + p.critDmg / 100); S.wp = 1 + p.wp / 100; S.combo = 1 + p.combo / 100; S.coins = 1 + p.coins / 100;
}
export const sig = () => (SAVE.inv ? Object.values(equipped()).map((it) => it.id + ':' + it.lv).join(',') : '');

// 11-27 gear level requirement (progression.js setReqCheck(canEquip)): an item above the player's level can be owned, not worn
let reqCheck = () => true;
export const setReqCheck = (f) => { reqCheck = typeof f === 'function' ? f : () => true; };
export const canWear = (it) => { try { return reqCheck(it); } catch (e) { return true; } };
export function equip(it) { if (!canWear(it)) return false; SAVE.inv.eq[def(it).slot] = it.uid; changed(); return true; }
export function unequip(slot) { if (slot === 'weapon') return false; delete SAVE.inv.eq[slot]; changed(); return true; } // the hero always holds a sword
export function upgrade(it) {
  if (it.lv >= maxLv(it)) return { ok: false, why: 'max' };
  const c = upgradeCost(it); if (SAVE.coins < c) return { ok: false, why: 'coins', cost: c };
  SAVE.coins -= c; it.lv++; changed(); return { ok: true, cost: c };
}
// 11-27 SALVAGE (user: "change it salvage"): an unequipped item -> shards = base by rarity + 75% of the shards spent upgrading it
export const SALVAGE_BASE = [10, 40, 150, 600];
export function salvageValue(it) { const d = def(it); return Math.round(SALVAGE_BASE[d.rarity] * (1 + .1 * (it.lv || 0))); } // 11-27 user: 15 items gave 60K - the 75% upgrade refund on today's steep (x1.5-1.6 per level) costs exploded; flat: base x (1 + 10% per level) until the economy build
export function salvage(uids) { let got = 0; const set = new Set(uids);
  for (const uid of set) { const it = byUid(uid); if (!it || isEquipped(it)) continue; got += salvageValue(it); SAVE.inv.items.splice(SAVE.inv.items.indexOf(it), 1); }
  SAVE.coins += got; changed(); return got; }
// a new item (or +1 level on the copy you own); empty slot -> worn straight away
export function grant(id) {
  const dup = !!owned(id); // 11-27 user: a duplicate is ANOTHER COPY in the bag (no more +1 level); keep it or salvage it
  const it = add(id); if (dup) { changed(); return { it, dup: true }; } if (!SAVE.inv.eq[def(id).slot] && canWear(it)) SAVE.inv.eq[def(id).slot] = it.uid; changed(); return { it, dup: false };
}
const pickW = (w, r) => { let t = w.reduce((a, b) => a + b, 0) * r; for (let i = 0; i < w.length; i++) if ((t -= w[i]) <= 0) return i; return 0; };
// end-of-fight chest: rank band -> chance + rarity weights (items.json drops). First fight always drops.
export function rollDrop(rank, n) {
  if (!DATA) return null;
  const D = DATA.drops, band = rank === 1 ? 'top1' : rank <= 10 ? 'top10' : rank <= n / 2 ? 'half' : 'rest';
  const first = !SAVE.inv.firstDrop; if (!first && Math.random() > D.chance[band]) return null; SAVE.inv.firstDrop = 1;
  let r = pickW(D.weights[band], Math.random()); let pool = [];
  for (; r >= 0 && !pool.length; r--) pool = DATA.items.filter((d) => d.rarity === r && !DATA.starter.includes(d.id) && !d.trackOnly); // trackOnly = the Daily Rewards 30-day blade
  // prefer things you don't own yet (a duplicate still counts: +1 level)
  const fresh = pool.filter((d) => !owned(d.id)), use = fresh.length && Math.random() < .75 ? fresh : pool;
  const d = use[Math.floor(Math.random() * use.length)]; return d ? grant(d.id) : null;
}
// shop: a few offers of items you don't own, rotating every fight (seeded by titans fought)
export function shopOffers() {
  if (!DATA) return [];
  let s = 977 + (SAVE.titans || 0) * 131; const r = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const pool = DATA.items.filter((d) => !owned(d.id) && !d.trackOnly).sort((a, b) => a.id < b.id ? -1 : 1);
  const out = []; while (pool.length && out.length < (DATA.shop?.offers || 4)) out.push(pool.splice(Math.floor(r() * pool.length), 1)[0]);
  return out.sort((a, b) => a.rarity - b.rarity);
}
export const price = (d) => DATA.rarity[d.rarity].price;
export function buy(id) { const d = def(id), c = price(d); if (SAVE.coins < c || owned(id)) return null; SAVE.coins -= c; return grant(id); }
// ?weapon=<id> (dev / screenshots): show that blade in hand + its fx + arcs without touching the save
const FORCE_W = new URLSearchParams(location.search).get('weapon');
// 11-27 gear view preview (inventory-ui.js, ink lobby GEAR only): an item def shown on the 3D hero (blade + element fx, cape,
// gem sparkles) WITHOUT equipping it. Visual only: SAVE.inv / EQ.S never see it; lobby-ui.js clears it outside the gear view.
let PREV = null;
export const setPreview = (id) => { PREV = id && DATA?.byId[id] ? DATA.byId[id] : null; };
export const previewDef = () => PREV;
// 11-27 PRE-FIGHT AD BLADE (prefight.js): a trial sword for ONE fight = visuals (blade sprite, WFX element, slash colours, sparkles)
// AND stats (recompute). Never saved / equipped; main.js clears it at the results and on every lobby entry. Level = the equipped
// sword's level (capped at the trial blade's max), so a trial is never weaker than the scaling of the player's own blade.
let TRIAL = null;
export function setTrial(id) {
  const d = id && DATA?.byId[id]; if (!d || d.slot !== 'weapon') return false;
  const own = equipped().weapon; TRIAL = { id, lv: Math.min(own?.lv || 0, DATA.rarity[d.rarity].maxLv), uid: -2, trial: true };
  recompute(); wtexLoad(id); return true;
}
export function clearTrial() { if (!TRIAL) return; TRIAL = null; recompute(); }
export const trialId = () => TRIAL?.id || null;
export const trialItem = () => TRIAL;
const look = () => { const e = equipped(); if (TRIAL) e.weapon = TRIAL; if (PREV) e[PREV.slot] = { id: PREV.id, lv: 0, uid: -1 }; return e; }; // equipped + the trial blade + the preview (visuals only)
export const weaponDef = () => { if (FORCE_W && DATA?.byId[FORCE_W]) return DATA.byId[FORCE_W]; if (TRIAL) return DATA.byId[TRIAL.id]; if (PREV?.slot === 'weapon') return PREV; const w = equipped().weapon; return w ? def(w) : DATA?.byId.w_starter; };
export const isInk = () => INK;
// 11-27 worn mask (ink only): ?mask=boots_N (dev panel "Mask on hero") > gear preview > equipped Mask slot (key 'boots')
const FORCE_M = new URLSearchParams(location.search).get('mask');
// a Mask item counts if it has a worn-mask sprite (non-head mode) or, in head mode, a head that names it (11-27 boots_4 Old Shell: head only)
const maskOk = (id) => !!(RIG.masks?.[id] || (RIG.heads && Object.values(RIG.heads).some((h) => h.mask === id)));
const maskId = () => { if (!RIG?.masks && !RIG?.heads) return null; if (FORCE_M && maskOk(FORCE_M)) return FORCE_M; const b = look().boots; return b && maskOk(b.id) ? b.id : null; };
// head mode: the head sprite to draw = the Mask item's head, else the default head (key into RIG.heads)
const headId = () => { if (FORCE_M && RIG.heads[FORCE_M]) return FORCE_M; const m = maskId(); /* ?mask=<head key> previews a staged (not item-linked) bone head */ return (m && Object.keys(RIG.heads).find((k) => RIG.heads[k].mask === m)) || RIG.headDef; };

// ---------------- hero art + weapon visuals ----------------
// heroFile(pose): the sword-less sprite (art/hero/<pose>.webp; the old painted-sword art is in tools/raw/hero_v1, not shipped)
export const heroFile = (pose) => (RIG?.poses?.[pose]?.file) || `art/hero/${pose}.webp`;
// 2D hero picture (topbar avatar, level-up, gear portrait): head mode = the idle body + the current head baked offline (tools/make_heads.py --check)
// 11-27 v3 head seat: rig head_seat [dx, dy] (head heights, + = forward / up) + the dev panel live nudge (headnx / headny in % of head
// height, headsz scale); window.__headNudge(key, value) changes it without reload (devpanel live)
const HQ = new URLSearchParams(location.search), HN = { headnx: +HQ.get('headnx') || 0, headny: +HQ.get('headny') || 0, headsz: +HQ.get('headsz') || 1 };
window.__headNudge = (k, v) => { if (k in HN) HN[k] = v === '' || v == null || !isFinite(+v) ? (k === 'headsz' ? 1 : 0) : +v; };
export const headSeat = () => { const r = RIG?.headSeat || [0, 0]; return { dx: r[0] + HN.headnx / 100, dy: r[1] + HN.headny / 100, s: HN.headsz || 1 }; };
export const headLook = () => (RIG?.heads ? RIG.heads[headId()] : null); // head mode: { file, pivot, h } of the head on the hero now (GEAR portrait layer)
export const portraitFile = () => (RIG?.heads ? `art/hero_ink/body/portrait_${headId()}.webp` : heroFile('idle'));
export const heroK = (pose, old) => RIG?.poses?.[pose]?.k ?? old;
const V = { ctx: null, poseOf: new Map(), wtex: {}, att: [], cur: null, capeU: { value: new THREE.Vector4(0, 0, 0, 0) }, fxT: 0 };
export const poseTex = (tex, name) => V.poseOf.set(tex, name); // extra hero textures -> rig pose (heroanim.js idle frames: idle_<i>)
// ctx: { scene, spriteMat, loadTex, T, sprites: [mesh...], sparks(x,y,z,r,g,b) }; T.hi / T.land / T.poses = the hero textures
export async function initVisuals(ctx) {
  V.ctx = ctx; if (!RIG) return;
  if (INK) { V.ink = await import('./inkhero.js').catch(() => null); V.ink?.initShadow(ctx.scene, ctx.sprites[0].renderOrder); } // ink-only hero grade / rim / contact shadow
  const { T } = ctx; V.poseOf.set(T.hi, 'idle'); if (T.land) V.poseOf.set(T.land, 'land'); ['slash', 'pose1', 'pose2', 'pose3', 'pose4'].forEach((p, i) => T.poses[i] && V.poseOf.set(T.poses[i], p));
  // 11-26 load speed: only the equipped blade (+ the starter fallback) before the first frame; the others load when equipped
  const wd = weaponDef(), cur = wd && RIG.weapons?.[wd.id] ? wd.id : 'w_starter';
  await Promise.all([...new Set([cur, 'w_starter'])].map(wtexLoad));
  if (V.ink?.initEyes && !RIG.heads) await V.ink.initEyes(V.poseOf, RIG, ctx.loadTex); // glowing eye holes (masks per hero texture; the headless body has none)
  for (const m of ctx.sprites) attach(m);
  if (CLOTH) { V.cloth = await import('./cloth.js').catch((e) => { console.warn('cloth', e); return null; });
    V.cloth?.initCloth(ctx, (mat) => { capeTint(mat); V.ink?.grade(mat, false); }); if (V.cloth) window.__cloth = V.cloth.cloth; }
}
export const eyeFlare = (amt) => V.ink?.eyeFlare?.(amt); // ink hero: eyes flare (crit); no-op in the default style
const wtexP = {};
function wtexLoad(id) { // one load per weapon id; V.wtex[id] stays undefined until it is in (the blade is just hidden meanwhile)
  const w = RIG?.weapons?.[id]; if (!w || !V.ctx) return Promise.resolve(null);
  return wtexP[id] || (wtexP[id] = V.ctx.loadTex(w.file).then((t) => (V.wtex[id] = t)).catch(() => null));
}
function capeTint(mat) { // armour tier: re-hue the red cape (strongly red pixels only; skin, hair and the gold crest keep their colour)
  mat.uniforms.capeT = V.capeU;
  mat.fragmentShader = mat.fragmentShader.replace('uniform vec3 tint;', 'uniform vec3 tint; uniform vec4 capeT;')
    .replace('vec3 col = c.rgb * tint;', 'vec3 cc = c.rgb; float cm = smoothstep(.3, .48, c.r - max(c.g, c.b)) * capeT.w; cc = mix(cc, capeT.rgb * (c.r * .85 + c.g * .3), cm); vec3 col = cc * tint;');
  mat.needsUpdate = true;
}
function attach(sprite) {
  const { spriteMat } = V.ctx;
  capeTint(sprite.material);
  const g = new THREE.Group(), m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), spriteMat(null, { glow: .5, fogNear: 999, fogFar: 9999, outline: true }));
  m.material.depthTest = false; m.material.depthWrite = false; m.frustumCulled = false; g.add(m); V.ctx.scene.add(g);
  if (V.ink) { V.ink.grade(sprite.material); V.ink.grade(m.material, false); V.ink.eyeMat?.(sprite); }
  let kg = null, km = null; // worn mask ("head bone"): group at the head anchor, quad offset so the mask's eye point sits on it
  if (RIG.masks || RIG.heads) { kg = new THREE.Group(); km = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), spriteMat(null, { glow: 0, fogNear: 999, fogFar: 9999, outline: true }));
    km.material.depthTest = false; km.material.depthWrite = false; km.frustumCulled = false; kg.add(km); kg.visible = false; V.ctx.scene.add(kg);
    if (V.ink) V.ink.grade(km.material, false); }
  V.att.push({ sprite, g, m, kg, km });
}
const mtexP = {}, mtex = {};
function mtexLoad(id) { return mtexP[id] || (mtexP[id] = V.ctx.loadTex((RIG.heads ? RIG.heads[id] : RIG.masks[id]).file).then((t) => (mtex[id] = t)).catch(() => null)); }
// mask follows the sprite's current frame (per-pose head = [u, v, rotDeg, size in idle texels]); mirrors with the sprite
function updateMask(a, mid, s, mu, P) {
  const t = mid && mtex[mid], h = RIG.heads ? P?.hs : P?.head;
  a.kg.visible = !!(t && h && s.visible && mu.alpha.value > .01); if (!a.kg.visible) return;
  s.updateMatrixWorld();
  const img = mu.map.value.image, sx = Math.sign(s.scale.x) || 1;
  _p.set(h[0] - .5, 1 - h[1], 0); s.localToWorld(_p); a.kg.position.copy(_p);
  a.kg.quaternion.copy(s.quaternion); a.kg.rotateZ(-h[2] * Math.PI / 180 * sx); a.kg.scale.set(sx, 1, 1);
  const px = h[3] * Math.abs(s.scale.y) / (img.height * (P.k || 1)), asp = t.image.width / t.image.height;
  if (RIG.heads) { const D = RIG.heads[mid], S = headSeat(), ht = px * (D.h || 1) * S.s, w = ht * asp; // whole head: pivot (neck socket in the sprite) on the hs anchor
    a.km.scale.set(w, ht, 1); a.km.position.set((.5 - D.pivot[0]) * w + ((D.dx || 0) + S.dx) * ht, (D.pivot[1] - .5) * ht + ((D.dy || 0) + S.dy) * ht, 0);
  } else { const M = RIG.masks[mid], w = px * M.w, ht = w / asp;
    a.km.scale.set(w, ht, 1); a.km.position.set((.5 - M.eye[0]) * w, (M.eye[1] - .5) * ht, 0); }
  a.km.renderOrder = s.renderOrder + .001;
  const ku = a.km.material.uniforms; ku.map.value = t; ku.alpha.value = mu.alpha.value * (mu.cut.value > -1 ? Math.max(0, mu.cut.value) : 1);
  ku.flash.value.copy(mu.flash.value); ku.tint.value.copy(mu.tint.value); ku.olA.value = mu.olA.value; ku.olC.value.copy(mu.olC.value);
  ku.olW.value.set(3 / t.image.width, 3 / t.image.height);
  if (V.ink) V.ink.perSprite(a.km.material, sx, false);
}
const _p = new THREE.Vector3();
export function updateVisuals(dt) {
  if (!V.ctx || !RIG) return;
  if (!EQM) { EQM = equipped(); queueMicrotask(() => { EQM = null; }); }
  const wd = weaponDef(), wr = wd && RIG.weapons[wd.id] ? wd.id : 'w_starter', W = RIG.weapons[wr], tex = V.wtex[wr];
  if (!tex) wtexLoad(wr); // newly equipped blade: fetched on demand
  const arm = look().armor, cape = arm && def(arm).cape; V.capeU.value.set(...(cape || [0, 0, 0]), cape ? 1 : 0);
  const mid = RIG.heads ? headId() : maskId(); if (mid && !mtex[mid]) mtexLoad(mid);
  for (const a of V.att) {
    const s = a.sprite, mu = s.material.uniforms, pose = V.poseOf.get(mu.map.value), P = pose && RIG.poses[pose];
    if (a.kg) updateMask(a, mid, s, mu, P);
    if (V.ink) { const sx0 = Math.sign(s.scale.x) || 1, idl = !!pose && pose.startsWith('idle');
      if (a === V.att[0]) { V.ink.updateShadow(s, idl || pose === 'land', dt); if (V.ink.tickEyes) { V.ink.tickEyes(dt); if (pose !== V.pose0 && s.visible && pose && !idl && pose !== 'land') V.ink.eyeFlare(.7); V.pose0 = pose; } } // strike pose -> eyes flare
      V.ink.perSprite(s.material, sx0, idl && !CLOTH); if (a === V.att[0] && V.cloth) { V.cloth.updateCloth(dt, s, P, mu, idl); V.ink.perSprite(V.cloth.cloth.mesh.material, sx0, false); } // cloth test: no painted flutter
      V.ink.perSprite(a.m.material, sx0, false); }
    a.g.visible = !!(s.visible && P && P.hand && tex && mu.alpha.value > .01);
    if (!a.g.visible) continue;
    s.updateMatrixWorld();
    const img = mu.map.value.image, sx = Math.sign(s.scale.x) || 1;
    _p.set(P.hand[0] - .5, 1 - P.hand[1], 0); s.localToWorld(_p); a.g.position.copy(_p);
    // blade direction (image px, y down) -> angle in the sprite plane; mirrored sprites mirror it
    const th = Math.atan2(-P.dir[1], P.dir[0] * sx);
    a.g.quaternion.copy(s.quaternion); a.g.rotateZ(th - Math.PI / 2);
    // world size: weapon length in idle texels -> world (sprite world height / (texture height * TEXK))
    const wpx = Math.abs(s.scale.y) / (img.height * (P.k || 1)), L = (RIG.len || 560) * (W.len || 1) * wpx, asp = tex.image.width / tex.image.height;
    a.g.scale.set(sx, 1, 1);
    a.m.scale.set(L * asp, L, 1); a.m.position.set(-(W.grip[0] - .5) * L * asp, -(.5 - W.grip[1]) * L, 0);
    a.m.renderOrder = s.renderOrder + (P.front ? .002 : -.002);
    a.id = wr; a.L = L; a.tipY = W.grip[1] * L; a.bw = L * asp; a.tex = tex; // weaponfx.js: blade line = group origin (grip) -> (0, tipY) in a.g
    a.uvx = -(W.grip[0] - .5) * L * asp; a.uvy = -(.5 - W.grip[1]) * L; // blade quad centre in a.g
    const wu = a.m.material.uniforms; wu.map.value = tex; wu.alpha.value = mu.alpha.value * (mu.cut.value > -1 ? Math.max(0, mu.cut.value) : 1);
    wu.flash.value.copy(mu.flash.value); if (V.ch > 0) { const c = V.chC, k = V.ch * (.75 + .25 * Math.sin(performance.now() * .018)); wu.flash.value.r += c.r * k; wu.flash.value.g += c.g * k; wu.flash.value.b += c.b * k; } // combo charge (combo-fx.js)
    wu.tint.value.copy(mu.tint.value); wu.olA.value = mu.olA.value; wu.olC.value.copy(mu.olC.value);
    wu.olW.value.set(3 / tex.image.width, 3 / tex.image.height);
  }
  // combo charge trail (combo-fx.js, ?combo1=0 off): flame / lightning sparks streaming off the main hero's blade
  const a0 = V.att[0];
  if (V.ch > .25 && a0 && a0.g.visible && V.ctx.sparks) { V.trT = (V.trT || 0) - dt;
    while (V.trT < 0) { V.trT += .05 / (V.ch * 1.6); const c = V.chRain ? new THREE.Color().setHSL(Math.random(), 1, .65) : V.chC;
      _p.set((Math.random() - .5) * .25, Math.random() * .5, 0); a0.m.localToWorld(_p); V.ctx.sparks(_p.x, _p.y, _p.z, c.r, c.g, c.b, Math.abs(a0.sprite.scale.y) * (.6 + V.ch * .8), 1); } }
  // ring / amulet: a faint sparkle on the hero in the gem colour (main hero sprite only, idle-ish rate)
  V.fxT -= dt; const hero = V.att[0]?.sprite;
  if (V.fxT <= 0 && hero && hero.visible && V.ctx.sparks) {
    V.fxT = .16; const e = look(), gems = ['ring', 'amulet'].map((k) => e[k] && def(e[k]).rarity > 0 && def(e[k]).glow).filter(Boolean);
    const wg = e.weapon && def(e.weapon); if (wg && wg.glow) gems.push(wg.glow, wg.glow2 || wg.glow, wg.glow); // a glowing blade (Skyrender) adds its star sparks
    if (gems.length) { const c = new THREE.Color(gems[Math.floor(Math.random() * gems.length)]), h = Math.abs(hero.scale.y), w = Math.abs(hero.scale.x);
      _p.set((Math.random() - .5) * .7, .25 + Math.random() * .6, 0); hero.localToWorld(_p); V.ctx.sparks(_p.x, _p.y, _p.z, c.r, c.g, c.b, h, w); }
  }
}
export const blades = () => V.att; // [{ sprite, g (grip-anchored group, +y = toward the tip), m (blade quad), id, L, tipY, bw, tex }]; [0] = the main hero
// combo charge on the blade (combo-fx.js): k 0..1 glow strength, c = THREE.Color of the tier, rainbow = per-spark hue
export function setCharge(k, c, rainbow = false) { V.ch = k; V.chC = c; V.chRain = rainbow; }
// slash-arc colour of the equipped blade (painted arcs are white-violet; tint multiplies them)
export function arcTint(col, r) {
  const w = weaponDef(), a = w?.arc2 && Math.random() < .5 ? w.arc2 : w?.arc; if (!a || a.join() === '1,0.92,1') { if (INK) col.setRGB(r < .3 ? .7 : .95, r < .3 ? 1 : .98, 1); else col.setRGB(r < .3 ? .85 : 1, r < .3 ? .95 : .9, 1); return; }
  const v = .9 + r * .2; col.setRGB(a[0] * v, a[1] * v, a[2] * v);
}
