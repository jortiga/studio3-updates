// Titan Slasher GAME PASS (11-27, user: balancing test mode, "make sure it includes energy"). ?pass=N runs the whole progression
// N x faster so the user can play through it by hand: energy refill (energy.js REGEN_MS / N), XP x N (progression.js addXp: fights,
// dummy, daily login), fight shards x N (main.js showResults), chest drop chance x N capped at 100% (drops.js), auto-train coins x N
// while in the lobby + offline time x N (autotrain.js; the offline cap stays N game hours = cap / N real time), free chest cooldown
// / N (inventory-ui.js), daily reward day length / N (daily.js DAY: a scaled "game day", so the 30-day track runs N x faster).
// Prices, upgrade costs, salvage values, chest prices, energy cost / ad +5 / 200-shard +5 stay UNCHANGED (what is being balanced).
// SAVE: a separate localStorage key (tt_save_pass, a fresh start) so the real tt_save is never inflated; ?passreset=1 wipes it once.
// Unranked (leaderboard.js RANKED), a small "PASS 10x" badge (top edge, no pointer events). Never in release builds (TT_DEV false).
// Values: ?pass=5|10|20 (any 2-100); ?pass=1 / on = 10; absent / 0 = off.
const Q = new URLSearchParams(location.search);
const raw = Q.get('pass');
let n = 1;
if (raw != null && raw !== '' && raw !== '0' && raw !== 'off') { const v = Math.round(+raw); n = raw === 'on' || v === 1 || !isFinite(v) ? 10 : Math.max(2, Math.min(100, v)); }
if (typeof window !== 'undefined' && window.TT_DEV === false) n = 1; // release builds: never
export const N = n, ON = n > 1;
export const SAVE_KEY = ON ? 'tt_save_pass' : 'tt_save';
if (ON && Q.get('passreset') === '1') { // one-shot: wipe the pass save, then drop the flag so it doesn't wipe on every load
  try { localStorage.removeItem('tt_save_pass'); const d = JSON.parse(localStorage.getItem('tt_dev') || 'null'); if (d && 'passreset' in d) { delete d.passreset; localStorage.setItem('tt_dev', JSON.stringify(d)); } } catch (e) { /* no storage */ }
  try { const u = new URL(location.href); u.searchParams.delete('passreset'); history.replaceState(history.state, '', u.pathname + (u.searchParams.toString() ? '?' + u.searchParams : '') + u.hash); } catch (e) { /* */ }
}
if (ON && typeof document !== 'undefined') {
  const add = () => { if (document.getElementById('passBadge')) return; const b = document.createElement('div'); b.id = 'passBadge'; b.textContent = `PASS ${N}×`;
    b.title = 'Game pass test mode: progression x' + N + ', separate save, unranked';
    b.style.cssText = 'position:fixed;left:50%;top:calc(env(safe-area-inset-top, 0px) + 1px);transform:translateX(-50%);z-index:2147483000;pointer-events:none;'
      + 'font:800 9px/1 system-ui,sans-serif;letter-spacing:.12em;color:#1a1200;background:#ffd35a;padding:2px 6px 2px 7px;border-radius:0 0 6px 6px;opacity:.9;box-shadow:0 1px 4px #0008';
    document.body.appendChild(b); };
  if (document.body) add(); else addEventListener('DOMContentLoaded', add);
}
const PASS = { N, ON, SAVE_KEY };
if (typeof window !== 'undefined') window.PASS = PASS;
export default PASS;
