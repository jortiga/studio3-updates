// Lobby home HUD (11-26 UI pass): the painted round icon buttons along the top (index.html #menu) and their panels.
// PROFILE (nickname + bests), RANKS (leaderboard), DAILY (window.DAILY from daily.js, built separately), SHOP + GEAR
// (inventory-ui.js), SETTINGS (music / SFX). Badges: "!" on GEAR when an equipped item can be upgraded or a new item is in the bag,
// "!" on DAILY when window.DAILY.claimable(). DOM + menu.css only; main.js passes the pieces it owns in init().
import * as EQ from './equipment.js';
import * as TB from './timeboard.js'; // 11-28 ?timeboard=1 kill-time board (default OFF)
import { UI, INK } from './uiart.js';

const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.round(n).toLocaleString('en-US');
let C = null, el = null, kind = '', badgeT = 0;

export function init(ctx) { // ctx: { SAVE, save, sfx, A (audio), LB, INV, board(score) -> ghost board rows, titanIdx() }
  C = ctx;
  el = document.createElement('div'); el.id = 'mpanel'; el.className = 'panel hidden';
  el.innerHTML = '<div class="mframe"><div class="mhead"><button class="hback" aria-label="Back"></button><img alt=""><h2></h2><button class="mclose" aria-label="Close">&#10005;</button></div><div class="mbody"></div></div>';
  document.body.appendChild(el);
  el.addEventListener('click', (e) => { if (e.target === el || e.target.closest('.mclose, .hback') || (el.classList.contains('sheet') && e.target.closest('.mhead h2, .mhead img'))) { C.sfx('click'); close(); } });
  $('menu').addEventListener('click', (e) => { const b = e.target.closest('.mb'); if (!b) return; e.stopPropagation(); C.A.init(); open(b.dataset.k); });
  $('menu').addEventListener('pointerdown', (e) => e.stopPropagation()); // a circle tap is never a slash
  updateBadges();
}
export const isOpen = () => el && !el.classList.contains('hidden');
// 11-27 ink lobby (user: "connected from the bottom like scrolling up"): RANKS / SETTINGS opened from the tab bar are a bottom
// sheet (#mpanel.sheet, kit-ui.css) that slides down on close; instant = no slide (switching to another tab screen)
let outT = 0;
export function close(instant) {
  clearTimeout(outT); kind = ''; updateBadges();
  if (!instant && el.classList.contains('sheet') && !el.classList.contains('hidden')) { el.classList.add('out'); outT = setTimeout(done, 220); return; }
  done();
}
function done() { el.classList.add('hidden'); el.classList.remove('out', 'sheet'); el.dataset.k = ''; updateBadges(); }

function show(k, title, html) {
  kind = k; el.dataset.k = k; /* 11-27 ink lobby: board / settings take the tab-screen geometry (kit-ui.css #mpanel[data-k]) */ el.querySelector('.mhead img').src = INK ? `art/ui_ink/kit/ic_${k === 'board' ? 'ranks' : k}.webp` : `${UI}/ic_${k}.webp`; el.querySelector('.mhead h2').textContent = title; // 11-27 ink: UI kit icons (kit-ui.css medallion)
  el.querySelector('.mbody').innerHTML = html; clearTimeout(outT); el.classList.toggle('sheet', INK && document.documentElement.classList.contains('ui2') && document.body.dataset.st === 'lobby' && (k === 'board' || k === 'settings' || k === 'profile')); el.classList.remove('hidden', 'go', 'out'); void el.offsetWidth; el.classList.add('go');
}
export function open(k) {
  // no-interruption rule: during the fight only SETTINGS opens (an overlay, the fight keeps running); the rest are dimmed tap-through
  if (['fight', 'intro', 'retreat'].includes(document.body.dataset.st) && k !== 'settings') return;
  C.sfx('click');
  if (k === 'gear' || k === 'shop') { if (k === 'gear') markGearSeen(); C.INV.open(k); return updateBadges(); }
  if (k === 'daily') { C.SAVE.dailySeenDay = Math.floor(Date.now() / 864e5); C.save(); updateBadges(); if (window.DAILY?.open) window.DAILY.open(); return; } // daily.js (separate agent) owns the reward logic + its popup
  if (k === 'profile') return profile();
  if (k === 'board') return board();
  if (k === 'settings') return settings();
}

function profile() {
  const S = C.SAVE, eq = EQ.equipped(), w = eq.weapon && EQ.def(eq.weapon);
  show('profile', 'PROFILE', `<div class="mnick"></div>
    <div class="mstats"><div><b>${fmt(S.best || 0)}</b><small>BEST DAMAGE</small></div><div><b>${fmt(S.bestCombo || 0)}</b><small>BEST COMBO</small></div>
    <div><b>${fmt(S.titans || 0)}</b><small>TITANS FOUGHT</small></div><div><b>${w ? w.name.toUpperCase() : '-'}</b><small>BLADE</small></div></div>
    ${lastFight(S.last)}
    <div class="mnote">Tap your name to change it. It is shown on the leaderboard.</div>`);
  const nb = C.LB.nickBtn?.(); if (nb) el.querySelector('.mnick').appendChild(nb);
}

// the results screen's old stat cards + coin breakdown (11-26 minimal results moved them here)
function lastFight(L) {
  if (!L) return '';
  const rw = (t, v) => `<div class="rw"><span>${t}</span><b>${v} <i class="gem">&#9670;</i></b></div>`;
  return `<div class="mlabel">LAST FIGHT &middot; RANK #${L.rank} OF ${L.n}${TB.ON && L.tb ? ` &middot; ${L.tb}` : ''}</div>
    <div class="mstats m3"><div><b>${fmt(L.combo)}</b><small>BEST COMBO</small></div><div><b>${fmt(L.runes)}</b><small>RUNES BROKEN</small></div><div><b>${fmt(L.taps)}</b><small>TOTAL HITS</small></div></div>
    <div class="mrew">${rw(`Damage ${fmt(L.score)}`, fmt(L.dmgCoins))}${rw(`Rank #${L.rank} reward`, fmt(L.bonus))}${L.best ? rw('New personal best', '+100') : ''}${L.charm ? rw('Charm bonus', '+' + fmt(L.charm)) : ''}<div class="rw tot"><span>TOTAL</span><b>+${fmt(L.coins)} <i class="gem">&#9670;</i></b></div></div>`;
}

const TABS = [['hour', "TODAY'S TITAN"], ['titan', 'THIS TITAN, ALL TIME'], ['all', 'ALL TIME']]; // same as leaderboard.js mountResults
export const fightWindow = (LB) => (LB.day || LB.hour).call(LB); // the board window (UTC day since 11-26, was the hour)
function board() {
  const online = C.LB.configured, L = C.SAVE.last, hourScore = L && L.hour === fightWindow(C.LB) ? L.score : 0;
  show('board', TB.ON ? 'RIVALS' : 'LEADERBOARD', `<div class="mtabs">${(online && !TB.ON ? TABS : TABS.slice(0, 1)).map(([k, t], i) => `<button data-t="${k}" class="${i ? '' : 'on'}">${t}</button>`).join('')}</div><div class="mboard"></div>`);
  const box = el.querySelector('.mboard');
  const ghost = () => { box.innerHTML = TB.ON ? TB.panelHtml(C.LB.day(), C.titanIdx()) : C.LB.rowsHtml(C.board(hourScore), fmt); }; // this hour: real rows + GHOST fillers, your best this hour (?timeboard=1: kill times)
  const load = async (k) => {
    if (k === 'hour') return ghost();
    box.innerHTML = '<div class="lnote">LOADING...</div>'; C.LB.titan = C.titanIdx();
    try { const j = k === 'titan' ? await C.LB.titanBoard() : await C.LB.totals(k); if (kind !== 'board' || !el.querySelector(`.mtabs button[data-t="${k}"]`)?.classList.contains('on')) return;
      const rows = (j.top || []).map((a, i) => ({ name: a[0], score: +a[1], me: !!a[2], real: true, rank: i + 1 })).concat((j.around || []).map((a) => ({ rank: +a[0], name: a[1], score: +a[2], me: !!a[3], real: true })));
      if (!rows.length) { box.innerHTML = '<div class="lnote">NO SCORES YET - BE THE FIRST</div>'; return; }
      if (!rows.some((r) => r.me)) rows.push({ name: C.LB.nick, score: 0, me: true, real: true, rank: (+j.total || rows.length) + 1 });
      box.innerHTML = C.LB.rowsHtml(rows, fmt).replace(/<div class="lnote">[^<]*<\/div>$/, `<div class="lnote">${k === 'titan' ? 'BEST FIGHT PER PLAYER, THIS TITAN' : k === 'day' ? 'TOTAL DAMAGE TODAY (UTC)' : 'TOTAL DAMAGE, ALL TIME'}</div>`).replace('BEST FIGHT PER PLAYER, THIS TITAN', 'BEST DAY PER PLAYER VS THIS TITAN');
    } catch (e) { ghost(); } };
  el.querySelectorAll('.mtabs button').forEach((b) => { b.onclick = (e) => { e.stopPropagation(); C.sfx('click'); el.querySelectorAll('.mtabs button').forEach((x) => x.classList.toggle('on', x === b)); load(b.dataset.t); }; });
  load('hour');
}

function settings() {
  const A = C.A;
  show('settings', 'SETTINGS', `<div class="mrow"><span>MUSIC</span><button class="mtog${A.isMusicOn() ? ' on' : ''}" data-s="music" aria-label="Music"></button></div>
    <div class="mrow"><span>SOUND FX</span><button class="mtog${A.isSfxOn() ? ' on' : ''}" data-s="sfx" aria-label="Sound effects"></button></div>
    ${window.GFX ? `<div class="mrow"><span>GRAPHICS</span><div class="mseg">${(window.GFX.levels || ['high', 'med', 'low']).map((k) => `<button data-g="${k}" class="${(window.GFX.get() || 'auto') === k ? 'on' : ''}">${window.GFX.labels?.[k] || k.toUpperCase()}</button>`).join('')}</div></div>` : ''}
    <div class="mnote">Titan Slasher &middot; Studio 3 Games<span class="mver"></span></div>`);
  if (window.Capacitor?.isNativePlatform?.()) fetch('bundle.json', { cache: 'no-store' }).then((r) => r.json()).then((b) => { const v = el.querySelector('.mver'); if (v && b.stamp) v.textContent = ` \u00b7 ${b.stamp}`; }).catch(() => {}); // app: the build number (is the update in?)
  el.querySelectorAll('.mtog').forEach((b) => { b.onclick = (e) => { e.stopPropagation(); const on = !b.classList.contains('on'); b.classList.toggle('on', on);
    if (b.dataset.s === 'music') A.setMusicOn(on); else if (b.dataset.s === 'voice') A.setVoiceOn(on); else A.setSfxOn(on); if (A.isMuted() && on) A.setMuted(false); C.sfx('click'); }; });
  el.querySelectorAll('.mseg button').forEach((b) => { b.onclick = (e) => { e.stopPropagation(); C.sfx('click'); try { window.GFX.set(b.dataset.g); } catch (err) { console.warn('gfx', err); }
    el.querySelectorAll('.mseg button').forEach((x) => x.classList.toggle('on', x === b)); }; }); // render quality (the render agent's window.GFX, saved in tt_gfx)
}

// ---- badges ----
const maxUid = () => EQ.items().reduce((m, it) => Math.max(m, it.uid || 0), 0);
// 11-26 user: "when the screen has been visited the notification should be gone" - a visit clears EVERY reason for the badge;
// it only comes back for something NEW after that visit (a new item, an upgrade that became affordable since, a new daily day)
const cheapestUp = () => Object.values(EQ.equipped()).filter((it) => it.lv < EQ.maxLv(it)).reduce((m, it) => Math.min(m, EQ.upgradeCost(it)), Infinity);
function markGearSeen() { C.SAVE.gearSeen = maxUid(); C.SAVE.gearSeenCoins = C.SAVE.coins; C.save(); }
function gearBadge() {
  if (!EQ.DATA || !C.SAVE.inv) return false;
  if (C.SAVE.gearSeen == null) { C.SAVE.gearSeen = maxUid(); C.save(); } // first run: the starter items are not "new"
  if (maxUid() > C.SAVE.gearSeen) return true;
  const up = cheapestUp(); return C.SAVE.coins >= up && (C.SAVE.gearSeenCoins ?? -1) < up; // affordable now, and was NOT at the last visit
}
export function updateBadges() {
  if (!C) return; const set = (k, on) => document.querySelector(`#menu .mb[data-k="${k}"]`)?.classList.toggle('on', !!on);
  set('gear', gearBadge());
  let d = false; try { d = window.DAILY?.claimable?.(); } catch (e) { d = false; } set('daily', d && C.SAVE.dailySeenDay !== Math.floor(Date.now() / 864e5)); // seen today -> no badge
  document.querySelector('#menu .mb[data-k="daily"]')?.classList.toggle('off', !window.DAILY);
}
export function tick(dt) { badgeT -= dt; if (badgeT <= 0) { badgeT = .5; updateBadges(); } }
