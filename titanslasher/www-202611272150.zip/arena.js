// Per-titan ARENAS (11-26, user: "the environment should change too"). An arena = game/arenas/<id>/arena.json:
//   "layers": painted files (tools/build_arena.py writes these; missing layers point at the base arena's files)
//   "glow":   layer files that have an emissive mask <file>_glow.webp (tools/glow_mask.py; runes, lava cracks, gems)
//   "theme":  look values merged over DEFAULT below (hand-tuned; build_arena.py never touches them)
// titan.json "arena": "<id>" picks it (default skyruins); ?arena=<id> forces one for every titan (dev panel: Visuals > Arena).
// Only the current arena's textures are loaded; the next titan's arena is preloaded in the background; textures used by
// neither are disposed. The swap is cheap: Env / Water / SeaReflect .setTheme() swap maps + uniforms on the existing meshes.
// main.js: loadArena() in build(), initArena(ctx, A) once the world exists, switchArena(id) from mountTitan() (lobby entry, the
// titan waits under the sea), AR.fog / AR.titanLight read by the per-frame fog / titan light code.
import * as THREE from 'three';
import { SH } from './fx.js';

const Q = new URLSearchParams(location.search);
const bust = () => '?' + (Q.get('nocache') === '0' ? '' : Date.now());
const getJson = (u) => fetch(u + bust()).then((r) => { if (!r.ok) throw new Error(u + ' ' + r.status); return r.json(); });

// DEFAULT = the sky ruins look (the golem's arena, the values that were hard-coded before 11-26). Colours are linear 0..1 RGB.
export const DEFAULT = {
  fog: [.35, .29, .6], fogNear: 40, fogFar: 190, fogK: 1, // fog colour (SH.fogColor + scene.fog), scene.fog range, painted-layer fog distance scale
  titanLight: [.28, .22, .5], // titan glow light on the sprites (SH.lightCol base; rage pushes red)
  sky: [1, 1, 1], sun: { col: [1, .82, .95], a: .1 }, rays: { col: [.72, .6, 1], col2: [1, .85, 1], k: 1 }, cloudScroll: 1,
  hemi: { sky: [.804, .722, 1], ground: [.169, .09, .376], i: 1 }, sunLight: { col: [1, .94, 1], i: 1.1 }, flashLight: [.77, .61, 1],
  tints: { clouds: [.78, .7, .9], far: [.92, .9, 1.05], mid: [.82, .8, .95], seaBack: [.9, .85, 1], seaFront: [.95, .9, 1], mist: [.85, .78, 1],
    ledge: [.9, .88, 1], props: [.85, .82, .97], propsFloat: [.7, .65, .85], baseMist: [.55, .45, .85] },
  farAlpha: .9, mistA: 1, glowCol: [.5, .95, 1], // glowCol: rune glow-mask colour on the ledge / ruins / props
  dust: { type: 'dust', col: [.85, .78, 1], col2: [1, .55, .25] }, // type: dust | ash | rain | snow | sprinkles | spores (col3 for sprinkles)
  bolt: { on: true, col: [.75, .85, 1], flash: [.05, .06, .09], every: [14, 30] }, birds: { on: true, col: [.12, .06, .25] },
  sea: { deep: [.17, .1, .38], mid: [.62, .52, .9], hi: [.95, .75, 1], rune: [.1, .55, .7], shim: [.45, .7, 1], foam: [.88, .9, 1], veinCol: [1, .45, .1],
    flow: 1, swell: 1, caps: 0, vein: 0, shimK: 1, // sea plane: flow speed, swell rows, whitecaps, lava veins, shimmer band
    stripScroll: 1, stripWob: 1, stripShimmer: 1, stripSwell: 1, stripGlow: .4 }, // painted sea strips (x the per-strip defaults)
  splash: { tint: [1, 1, 1], drop: [.92, .95, 1], drop2: [.6, .85, 1], puff: [.85, .8, 1] },
  refl: { k: .55, body: 1, col: [.3, .22, .58] }, // reflection strength, body (0 = glow-only), sea tint
  debris: { col: [2.2, 1.85, 2.5], emissive: [.165, .094, .314] },
};
const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
const merge = (a, b) => { const o = { ...a }; for (const k in b || {}) o[k] = isObj(a[k]) && isObj(b[k]) ? merge(a[k], b[k]) : b[k]; return o; };

export const AR = { id: null, fog: new THREE.Color(...DEFAULT.fog), titanLight: new THREE.Color(...DEFAULT.titanLight), theme: DEFAULT };
export const arenaOf = (cfg) => (Q.get('style') === 'ink' ? 'inkcave' : Q.get('arena')) || cfg?.arena || 'skyruins'; // ink style always uses its cave (a saved dev-panel arena must not override it)

const TC = new Map(), AC = new Map(); // texture promises by path, arena promises by id
let LT = null, ctx = null, cur = null, pending = null, nextId = null, decoMod = null;
const tex = (p) => { if (!TC.has(p)) TC.set(p, LT(p).catch(() => null)); return TC.get(p); };

export function loadArena(id, loadTex) {
  if (loadTex) LT = loadTex;
  if (AC.has(id)) return AC.get(id);
  const p = (async () => {
    let cfg; try { cfg = await getJson(`arenas/${id}/arena.json`); } catch (e) { if (id !== 'skyruins') { console.warn('arena', id, e); return loadArena('skyruins'); } throw e; }
    const L = cfg.layers || {}, paths = new Set(), one = (f) => (f ? (paths.add(f), tex(f)) : Promise.resolve(null)), many = (a) => Promise.all((a || []).map(one));
    const gl = Q.get('noglow') === '1' ? [] : (cfg.glow || []);
    const [sky, clouds, far, sea, ledge, mid, fg, mist, splash, masks] = await Promise.all([one(L.sky), one(L.clouds), one(L.far), one(L.sea), one(L.ledge),
      many(L.mid), many(L.props), many(L.mist), many(L.splash), Promise.all(gl.map((f) => one(f.replace(/\.webp$/, '_glow.webp'))))]);
    const glow = new Map(); for (let i = 0; i < gl.length; i++) { const t = await one(gl[i]); if (t && masks[i]) glow.set(t, masks[i]); }
    const dc = cfg.theme?.deco; // 11-26 ink environment (inkdeco.js, dynamic import: arenas without "deco" never load it); it replaces frametop / framebot
    const frame = !dc && (L.frametop || L.framebot) ? { top: await one(L.frametop), bot: await one(L.framebot) } : null; // optional screen-edge silhouettes
    // shore (rocks / reeds strip over the far water edge) + rocks atlas; ?water=abyss swaps the shore for the chasm rim, ?water=fog
    // uses neither (only the art in use loads)
    const water = Q.get('water') || 'shore';
    const deco = dc ? await Promise.all([import('./inkdeco.js'), one(L.ruinsback), one(L.ruinsmid), one(L.framerock), one(L.frameplants),
      one(water === 'abyss' ? L.rim : water === 'fog' ? null : L.shore), one(water === 'fog' ? null : L.rocks), one(L.waist)])
      .then(([mod, back, mid, rock, plants, shore, rocks, waist]) => ({ mod, back, mid, rock, plants, shore, rocks, waist, water })) : null; // waist: churn ring at the titan's waterline (all modes)
    return { id: cfg.id || id, cfg, paths, theme: merge(DEFAULT, cfg.theme || {}), tex: { sky, clouds, far, sea, ledge, mid, fg, mist, splash, glow, frame, deco } };
  })();
  AC.set(id, p); p.catch(() => AC.delete(id));
  return p;
}

// ctx: { world, scene, lights: { hemi, sun, fl }, canvas, next: () => next titan's arena id }
export function initArena(c, A) { ctx = c; apply(A); }

function apply(A) {
  const w = ctx.world, th = A.theme, c3 = (col, v) => v && col.setRGB(v[0], v[1], v[2]);
  w.env.setTheme(th, A.tex); w.water.setTheme(th, A.tex.splash); w.refl?.setTheme?.(th.refl, w.tcfg);
  const L = ctx.lights; if (L.hemi) { c3(L.hemi.color, th.hemi.sky); c3(L.hemi.groundColor, th.hemi.ground); L.hemi.intensity = th.hemi.i ?? 1; }
  if (L.sun) { c3(L.sun.color, th.sunLight.col); L.sun.intensity = th.sunLight.i ?? 1.1; } if (L.fl) c3(L.fl.color, th.flashLight);
  c3(AR.fog, th.fog); c3(AR.titanLight, th.titanLight); SH.fogColor.value.copy(AR.fog);
  if (ctx.scene.fog) { ctx.scene.fog.color.copy(AR.fog); ctx.scene.fog.near = th.fogNear; ctx.scene.fog.far = th.fogFar; }
  for (const m of w.mist || []) c3(m.m.material.uniforms.tint.value, th.tints.baseMist);
  if (w.debris) { c3(w.debris.material.color, th.debris.col); c3(w.debris.material.emissive, th.debris.emissive); }
  setFrame(A.tex.frame, th.frame);
  const dk = A.tex.deco; if (dk) { decoMod = dk.mod; dk.mod.applyDeco(ctx, dk, th.deco); } else decoMod?.applyDeco(ctx, null); // ink environment layers (or clear them)
  AR.id = A.id; AR.theme = th; cur = A; w.arenaId = A.id;
  gc(); clearTimeout(apply.pre); apply.pre = setTimeout(preloadNext, 6000);
}
function preloadNext() { const id = ctx?.next?.(); if (!id || id === cur?.id) return; nextId = id; loadArena(id).then(gc).catch(() => {}); }
// drop every texture the current arena and the preloaded next one don't use (shared art/env files stay while either uses them)
async function gc() {
  if (pending) return; // a swap is loading: its textures are not in either set yet
  const keep = new Set(cur?.paths || []);
  if (nextId && AC.has(nextId)) { try { const N = await AC.get(nextId); for (const p of N.paths) keep.add(p); } catch (e) { /* failed preload */ } }
  for (const [id] of AC) if (id !== cur?.id && id !== nextId && id !== pending) AC.delete(id);
  for (const [p, pr] of TC) if (!keep.has(p)) { TC.delete(p); pr.then((t) => t?.dispose()); }
}

// 11-26 screen-edge FRAME silhouettes (ink style test, arenas/inkcave layers frametop / framebot): flat black stalactites / thorny
// vines along the top, brambles / grass along the bottom, drawn in clip space over the scenery (renderOrder 355: over the ledge,
// under the hero + slashes). The strip keeps its aspect: height = theme.frame.top / bot x screen height, mirrored repeat across.
// Arenas without frame layers never create these meshes (default look untouched).
const FRAME = [];
function setFrame(F, o = {}) {
  if (!F && !FRAME.length) return;
  [['top', 1, o.top ?? .2], ['bot', 0, o.bot ?? .15]].forEach(([k, top, hf], i) => {
    const t = F?.[k] || null;
    if (!FRAME[i] && t) {
      const u = { map: { value: t }, top: { value: top }, hf: { value: hf }, rep: { value: 1 }, tint: { value: new THREE.Color(...(o.tint || [.02, .03, .05])) }, a: { value: o.a ?? 1 } };
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: u, transparent: true, depthTest: false, depthWrite: false,
        vertexShader: 'uniform float top; uniform float hf; varying vec2 vUv; void main(){ vUv = uv; float y = top > .5 ? 1. - (1. - uv.y) * 2. * hf : -1. + uv.y * 2. * hf; gl_Position = vec4(position.x * 2., y, 0., 1.); }',
        fragmentShader: 'uniform sampler2D map; uniform float rep; uniform vec3 tint; uniform float a; varying vec2 vUv; void main(){ vec4 c = texture2D(map, vec2((vUv.x - .5) * rep + .5, vUv.y)); gl_FragColor = vec4(mix(c.rgb, tint, .85), c.a * a); }' }));
      m.frustumCulled = false; m.renderOrder = 355; const v = new THREE.Vector2();
      m.onBeforeRender = (r) => { r.getDrawingBufferSize(v); const img = u.map.value?.image; if (img) u.rep.value = v.x / Math.max(1, v.y * u.hf.value * img.width / img.height); };
      FRAME[i] = m; ctx.scene.add(m);
    }
    const m = FRAME[i]; if (!m) return;
    m.visible = !!t; if (t) { t.wrapS = THREE.MirroredRepeatWrapping; t.needsUpdate = true; m.material.uniforms.map.value = t; m.material.uniforms.hf.value = hf; }
  });
}

// runtime swap (lobby entry with another titan): load, then a short fade over the canvas hides the texture swap
let veil = null;
export function switchArena(id) {
  if (!ctx || id === cur?.id || id === pending) return;
  pending = id;
  loadArena(id).then((A) => { if (pending !== id) return; if (A.id === cur?.id) { pending = null; return; }
    fadeSwap(() => { pending = null; apply(A); }); }).catch((e) => { console.warn('arena', id, e); pending = null; });
}
function fadeSwap(fn) {
  const cv = ctx.canvas || document.querySelector('canvas');
  if (!veil) { veil = document.createElement('div'); veil.style.cssText = 'position:fixed;inset:0;pointer-events:none;opacity:0;transition:opacity .22s ease-in;background:#07040f';
    cv?.parentNode ? cv.parentNode.insertBefore(veil, cv.nextSibling) : document.body.appendChild(veil); } // right above the canvas, under the HUD / menus
  veil.style.transition = 'opacity .22s ease-in'; veil.style.opacity = '1';
  setTimeout(() => { fn(); requestAnimationFrame(() => requestAnimationFrame(() => { veil.style.transition = 'opacity .45s ease-out'; veil.style.opacity = '0'; })); }, 240);
}
export const ARENA_DEBUG = { get cur() { return cur; }, TC, AC, switchArena };
