// 11-27 real-money shard packs (Google Play / App Store), same pattern as Runebound (rougulike/game/monet.js):
// cordova-plugin-purchase 13 (window.CdvPurchase) in the store app, same product ids on both stores, consumables granted
// client-side on "approved" and then finished (= consumed). A purchase paid while the app was closed is delivered on the
// next start. Browser builds (CrazyGames, the test link) never sell anything: the packs stay display-only there.
// A native build without the plugin (an older store build that got this file by live update) is treated like the web.
//
// iOS: needs Apple's Paid Apps agreement Active (11-27: still "Pending User Info") + the 4 IAPs in App Store Connect.
// Consumables only, so no Restore button is required by Apple (Runebound has one for its non-consumables).
// 11-27 first iOS version: NO in-app purchases (user: "do no in-app first on ios"; Apple Paid Apps agreement still
// "Pending User Info") -> the iOS app shows no real-money packs at all. TO TURN ON: change false -> true (one line).
const IOS_IAP = false;

// ids identical in Play Console and App Store Connect (consumable). Store ids can never be renamed or reused, so they are
// amount-neutral (pack1..4): the shard amount n lives only here (the shop reads it too). Re-tier = edit n + the console price.
// price = placeholder until the store answers with the player's local price.
export const PACKS = [
  { sku: 'shards_pack1', n: 100, price: '$0.99' },
  { sku: 'shards_pack2', n: 500, price: '$4.99' },
  { sku: 'shards_pack3', n: 1000, price: '$9.99' },
  { sku: 'shards_pack4', n: 5000, price: '$39.99' },
];

let C = null; // { SAVE, save, coinHud, sfx }
let billing = null; // { store, waiting: Map(sku -> resolve), status }
const native = () => (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) ? window.Capacitor : null;
const ios = () => !!native() && native().getPlatform() === 'ios';
const storePlatform = (P) => (ios() ? P.Platform.APPLE_APPSTORE : P.Platform.GOOGLE_PLAY);
const storeName = () => (ios() ? 'The App Store' : 'Google Play');

// true only in the store app with the billing plugin present: the shop then shows BUY buttons with the store's price
export const enabled = () => !!native() && !!window.CdvPurchase && (IOS_IAP || !ios());
// iOS store app without IAP (IOS_IAP off): hide the packs entirely (fake prices fail App Review)
export const hidden = () => ios() && !IOS_IAP;
export const status = () => (billing ? billing.status : 'off');
export const pack = (sku) => PACKS.find((p) => p.sku === sku) || null;

// ---------- grant (each store transaction id once, so a re-sent "approved" never pays twice) ----------
function grant(sku, txId) {
  const p = pack(sku); if (!p || !C) return null;
  const S = C.SAVE; S.iap = S.iap || { tx: [], n: 0 };
  if (txId && S.iap.tx.includes(txId)) return null;
  if (txId) { S.iap.tx.push(txId); if (S.iap.tx.length > 60) S.iap.tx.splice(0, S.iap.tx.length - 60); }
  S.coins += p.n; S.iap.n++; C.save(); C.coinHud(); window.S3A?.log('purchase', { item: sku });
  return p;
}
function deliver(sku, txId) {
  const w = billing.waiting.get(sku); billing.waiting.delete(sku);
  const p = grant(sku, txId);
  if (w) w(p);
  else if (p) notice('Purchase delivered', `${p.n.toLocaleString('en-US')} shards were added to your balance.`); // paid while the app was closed
}

function initBilling() {
  const P = window.CdvPurchase; if (billing || !enabled() || !P) return;
  const { store, ProductType } = P;
  billing = { store, waiting: new Map(), status: 'connecting' };
  store.register(PACKS.map((p) => ({ id: p.sku, type: ProductType.CONSUMABLE, platform: storePlatform(P) })));
  store.when()
    .productUpdated((pr) => { const p = pack(pr.id); if (p && pr.pricing && pr.pricing.price) { p.price = pr.pricing.price; p.live = true; C && C.onPrice && C.onPrice(); } }) // the player's local price
    .approved((tx) => { for (const it of tx.products) deliver(it.id, tx.transactionId); tx.finish(); });
  store.error((e) => console.warn('billing', e && e.code, e && e.message));
  store.initialize([storePlatform(P)]).then(() => { billing.status = 'ready'; C && C.onPrice && C.onPrice(); }, () => { billing.status = 'offline'; });
}

// ctx: { SAVE, save, coinHud, sfx, onPrice() }
export function init(ctx) {
  C = ctx;
  if (window.CdvPurchase) initBilling(); else document.addEventListener('deviceready', initBilling);
}

// resolves the pack on success, null on cancel / failure
export async function buy(sku) {
  const p = pack(sku); if (!p || !enabled()) return null;
  initBilling(); if (!billing) return null;
  const P = window.CdvPurchase, pr = billing.store.get(sku, storePlatform(P)), offer = pr && pr.getOffer();
  if (!offer) { notice('Store unavailable', `${storeName()} could not be reached. Check your connection and try again.`); return null; }
  if (billing.waiting.has(sku)) return null; // already in progress
  return new Promise((resolve) => {
    billing.waiting.set(sku, resolve);
    offer.order().then((err) => {
      if (!err) return; // success arrives through "approved"
      billing.waiting.delete(sku); resolve(null);
      if (err.code !== P.ErrorCode.PAYMENT_CANCELLED) notice('Purchase failed', err.message || 'Please try again.');
    });
  });
}

// ---------- a small popup (own styles; reuses the game's button look) ----------
let css = false;
export function notice(title, text) {
  if (!css) { css = true; const s = document.createElement('style'); s.textContent = `
#iapPop{position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;background:#05030ccc;padding:16px}
#iapPop .ib{max-width:320px;width:100%;background:#1a1230;border:2px solid #c9a24a;border-radius:14px;padding:18px 16px 14px;text-align:center;color:#f3ead2;font:600 15px/1.35 system-ui,sans-serif;box-shadow:0 10px 40px #000c}
#iapPop b{display:block;font-size:19px;letter-spacing:.04em;margin-bottom:8px;color:#ffd77a}
#iapPop p{margin:0 0 14px}
#iapPop button{min-width:120px;padding:10px 16px;border:0;border-radius:10px;background:linear-gradient(#ffd77a,#c9902a);color:#2a1a05;font:800 15px system-ui,sans-serif;letter-spacing:.06em}`; document.head.appendChild(s); }
  return new Promise((resolve) => {
    document.getElementById('iapPop')?.remove();
    const el = document.createElement('div'); el.id = 'iapPop';
    el.innerHTML = `<div class="ib"><b></b><p></p><button>OK</button></div>`;
    el.querySelector('b').textContent = title; el.querySelector('p').textContent = text;
    el.querySelector('button').onclick = () => { C && C.sfx && C.sfx('click'); el.remove(); resolve(true); };
    document.body.appendChild(el);
  });
}
