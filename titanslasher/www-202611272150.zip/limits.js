// LIMIT BREAKS (11-26, user: "we need more of those Omni Slash type, like limit breaks, random").
// Every COMBO_STEP combo main.js finisher() asks pick() for one; OMNI SLASH stays the old hop burst in main.js, every other one is a
// small sequencer here over the existing pooled FX (painted arcs, light arcs, streaks, flashes, shocks, clones, sparks, debris) plus
// two cheap procedural meshes of its own (6 rune circles, 1 crescent moon; additive shaders, no textures).
// Rules (user): braindead tapping, nothing interrupts it: no slow motion, no input pause, no banner; taps keep counting while a limit
// plays (11-26: taps during a limit only spark + small number, they never move the hero: the HERO performs every limit, hops /
// blinks / clones, or rises into a held blade-up pose via hover()). Name = the small finisher pop, one camera shake at the climax only. Damage: every limit deals the Omni Finisher's total
// (6.5 hop units, see data/limits.json) split over its hits, so the leaderboard cap model is unchanged.
// Data: data/limits.json. Dev: ?limit=<id>|cycle (force / cycle through all), ?limitevery=N (main.js COMBO_STEP). window.__LIM for tests.
import * as THREE from 'three';
import * as EQ from './equipment.js';

const Q = new URLSearchParams(location.search);
let LIST = [], BY = {}, last = '', cycI = 0, X = null, R = null, beat = 0;
export const ready = fetch(new URL('./data/limits.json', import.meta.url)).then((r) => r.json()).then((d) => {
  LIST = d.limits.map((l) => ({ ...l, label: `${l.icon || '⚔'} ${l.name}` })); BY = Object.fromEntries(LIST.map((l) => [l.id, l]));
}).catch((e) => console.warn('limits.json', e));

const rand = (a, b) => a + Math.random() * (b - a), clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ease = (u) => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };

// ---------------- pick ----------------
export function pick(chain) {
  if (!LIST.length) return null;
  const nx = API.next; API.next = null; if (nx && BY[nx]) return (last = nx, BY[nx]);
  const f = Q.get('limit');
  if (f === 'cycle') { const L = LIST[cycI++ % LIST.length]; last = L.id; return L; }
  if (f && BY[f]) { last = f; return BY[f]; }
  let pool = LIST.filter((l) => chain >= (l.minCombo || 0) && l.weight > 0);
  if (pool.length > 1) pool = pool.filter((l) => l.id !== last); // no immediate repeat
  let s = pool.reduce((a, l) => a + l.weight, 0) * Math.random(), L = pool[pool.length - 1];
  for (const l of pool) { s -= l.weight; if (s <= 0) { L = l; break; } }
  last = L.id; return L;
}

// ---------------- own meshes: rune circles + crescent moon (created once, on the first play) ----------------
const VS = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }';
const RUNE_FS = `uniform float fade; uniform float spin; uniform float hot; uniform vec3 col; varying vec2 vUv;
  void main(){ vec2 p = (vUv - .5) * 2.; float d = length(p); if (d > 1.) discard; float a = atan(p.y, p.x) + spin;
    float r1 = smoothstep(.035, 0., abs(d - .93)), r2 = smoothstep(.025, 0., abs(d - .64)), r3 = smoothstep(.02, 0., abs(d - .2));
    float u = (a / 6.28318 + .5) * 18., seg = floor(u), fa = fract(u), h = fract(sin(seg * 91.7) * 4375.3);
    float band = step(.68, d) * step(d, .89);
    float g = (smoothstep(.09, 0., abs(fa - .5)) * step(abs(d - .785), .05 + .05 * h) + smoothstep(.035, 0., abs(d - (.73 + .12 * h))) * step(abs(fa - .5), .32)) * band * step(.2, fract(h * 7.));
    float hx = 0.; for (int i = 0; i < 6; i++) { float b = float(i) * 1.0472 - spin * 1.6; hx += smoothstep(.022, 0., abs(dot(p, vec2(cos(b), sin(b))) - .32)); }
    hx *= step(d, .64);
    float v = (r1 + r2 * .8 + r3 * .6 + g * .9 + hx * .7 + pow(max(0., 1. - d), 3.) * (.35 + hot * 1.5)) * fade;
    gl_FragColor = vec4(min(col * v * 1.5 + vec3(v * v * .25 + hot * pow(max(0., 1. - d), 2.)), vec3(2.)), v); }`;
const MOON_FS = `uniform float fade; uniform vec3 col; varying vec2 vUv;
  void main(){ vec2 p = (vUv - .5) * 2.; float m = max(length(p) - .9, -(length(p - vec2(.36, .1)) - .84)); // crescent SDF
    float body = smoothstep(.02, -.03, m), edge = exp(-abs(m) * 22.), glow = exp(-max(m, 0.) * 6.) * .4;
    float a = (body * .5 + edge * 1.4 + glow) * fade; vec3 c = mix(col * 1.2, vec3(1.), edge * .55 + body * .2);
    gl_FragColor = vec4(c * a, a); }`;
// 11-26 LEAK FIX: main.js LCTX() builds a NEW ctx object for every limit, so the old `if (X.runes)` guard never held and every
// limit break added 7 more meshes + materials to the scene (never removed: ~190 extra objects after 2 min of tapping).
// The meshes now live once per module (MK) and are only re-attached to the fresh ctx.
let MK = null;
function mkMeshes() {
  if (MK && MK.scene === X.scene) { X.runes = MK.runes; X.moon = MK.moon; return; }
  if (MK) for (const m of [...MK.runes, MK.moon]) { m.parent?.remove(m); m.material.dispose(); } // scene swapped (never in play): drop the old set
  if (MK) MK.runes[0].geometry.dispose();
  const g = new THREE.PlaneGeometry(1, 1), add = (fs, u) => { const m = new THREE.Mesh(g, new THREE.ShaderMaterial({ vertexShader: VS, fragmentShader: fs, uniforms: u,
    transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
  m.visible = false; m.frustumCulled = false; m.renderOrder = (X.RO?.top ?? 360) + 12.5; m.onBeforeRender = () => { if (performance.now() - beat > 250) m.visible = false; }; // a limit cut off (fight end) never leaves its meshes up
  X.scene.add(m); return m; };
  X.runes = Array.from({ length: 6 }, () => add(RUNE_FS, { fade: { value: 0 }, spin: { value: 0 }, hot: { value: 0 }, col: { value: new THREE.Color() } }));
  X.moon = add(MOON_FS, { fade: { value: 0 }, col: { value: new THREE.Color() } });
  MK = { scene: X.scene, runes: X.runes, moon: X.moon };
}

// ---------------- helpers over main.js FX ----------------
const _c = new THREE.Color(), _p = new THREE.Vector3(), _q = new THREE.Vector3();
function blade(out = new THREE.Color()) { // equipped blade colour; the white default blade -> the game's violet
  EQ.arcTint(out, .5); if (Math.min(out.r, out.g, out.b) > .82) out.setRGB(.72, .5, 1); return out; }
const S0 = () => Math.min(X.W, X.Hh);
const px = (n, p) => X.pxToWorld(n, p);
function dummyMode() { return !!(X.world.dummy?.present && (X.titanState.sink || 0) > .5); }
function liveWp() { return X.world.wps.find((x) => x.on && x.state === 'live'); }
function target() { const w = liveWp(); if (w) return w.pos.clone(); if (dummyMode()) return X.world.dummy.centerWorld(); return X.socketCenter(); }
function onScreen(p, mx = .12, top = .14, bot = .8) { const s = X.toScreen(p, {}); return s.x > X.W * mx && s.x < X.W * (1 - mx) && s.y > X.Hh * top && s.y < X.Hh * bot; }
function jitter(p, r) { const s = X.toScreen(p, {}); return X.screenToPlane(s.x + rand(-r, r), s.y + rand(-r, r), p.z, new THREE.Vector3()); }
function sockets() { // on-screen body sockets (index + area), the weak-point spots
  const ts = X.titanState, out = []; (ts.sockets || []).forEach((s, i) => { if (s.weak === false) return; const p = X.socketWorld(i, new THREE.Vector3()); if (onScreen(p)) out.push({ i, area: s.area || 'chest', p }); }); return out; }
function spot(r = 50) { // a random point on the body (or on the dummy in the lobby)
  if (dummyMode()) return jitter(X.world.dummy.centerWorld(), r * .5);
  const s = sockets(); if (!s.length) return jitter(X.socketCenter(), r);
  return jitter(s[Math.floor(Math.random() * s.length)].p, r);
}
function flinch(p, k, area) { const ts = X.titanState; ts.hit = Math.max(ts.hit, 1); ts.flinch = Math.min(1.5, ts.flinch + k * .4); ts.flinchDir = p.x > 0 ? -1 : 1;
  if (!dummyMode()) X.world.anim?.flinch?.(area || ['head', 'chest', 'shoulderL', 'shoulderR'][Math.floor(Math.random() * 4)], p.x > 0 ? -1 : 1, .3 + k * .6);
  else X.world.dummy.impact(p, 'body', k > .8); }
// one damage hit: share of the Omni total (data/limits.json hits / final / dmg) + up to 5 weak-point hits (x2.5) like the Omni
function hit(p, fin = false) {
  const L = R.L; if (fin ? R.finDone : R.nDone >= R.n - 1) return; if (fin) R.finDone = true; else R.nDone++;
  const unit = 520 * X.slashPow() * (1 + X.G.chain * .015) * 6.5 * (L.dmg ?? 1) / (R.n - 1 + (L.final ?? 1));
  if (fin) X.G.finHit = true; // main.js damage(): the skill's last hit always plays the ultra crit
  X.damage(unit * (fin ? (L.final ?? 1) : 1), 'fin', p, 'fin');
  const i = R.nDone + (R.finDone ? 1 : 0), want = Math.floor(i * 5 / R.n), w = liveWp();
  if (w && R.wpDone < 5 && R.wpDone < want) { R.wpDone++; X.wpHit(w, 2.5, w.pos); }
  flinch(p, fin ? 1.2 : .35); X.lights.fl.position.set(p.x, p.y, -34); X.lights.fl.intensity = Math.max(X.lights.fl.intensity, fin ? 9 : 5);
  if (!fin && L.sfx?.hit) { if (L.sfx.hit === 'tap') X.hitSound(); else X.A.sfx(L.sfx.hit, R.nDone % 14); } // 'tap' = slash hit via hitSound (deduped with the arc's own; starfall's light arcs are silent)
  if (fin) { X.shake((L.shake ?? 1.4) * 1.4); X.buzz(60); X.G.hitstop = Math.max(X.G.hitstop || 0, .14); /* 11-26 user: last hit very strong */ for (const s of L.sfx?.climax || []) X.A.sfx(s); if (!X.AT.on && !dummyMode()) X.startAct('stagger'); } // crit / ultra crit sounds: main.js damage() (by hit size)
}
function arcAt(p, sizePx, rot, dur, o = {}) { // painted arc; o.tint (Color), o.boost, o.warp
  const ts = X.toScreen(p, {}), q = X.screenToPlane(ts.x, ts.y, -34, new THREE.Vector3()), m = X.spawnArc(q, sizePx, rot, Math.random() < .5, dur), mu = m.material.uniforms;
  if (o.tint && mu.tint) mu.tint.value.copy(o.tint); if (mu.boost) mu.boost.value = o.boost ?? 1.3; m.userData.warp = o.warp != null ? o.warp : 1; return m; } // skill arcs = top hits: they warp (o.warp 0 opts out)
function lightArc(p, sizePx, rot, dur, col) { const m = X.spawnArc(p, sizePx, rot, Math.random() < .5, dur, 'light'); const mu = m.material.uniforms; mu.c1.value.copy(col); mu.bend.value = rand(.25, .5); return m; }
function streak(a, b, thPx, dur, col) { const m = X.streakBetween(a, b, px(thPx, b)); m.userData.dur = dur; m.material.uniforms.c1.value.copy(col); return m; }
function glow(p, s0, s1, dur, col, o) { X.flashAt(p, s0, s1, dur, col.r, col.g, col.b, o); }
function sparksAt(p, n, sp, col, grav = 6, size = 1) { for (let i = 0; i < n; i++) { const a = rand(0, 6.283), v = sp * rand(.35, 1);
  X.world.sparks.emit(p.x, p.y, p.z + .5, Math.cos(a) * v, Math.sin(a) * v + rand(0, 4), rand(0, v * .4), rand(.3, .8), rand(.6, 1.3) * size, col.r, col.g, col.b, grav); } }
function bigBurst(p, col, k = 1) { // climax: triple ring + glow + refraction ring + sparks + debris
  glow(p, 4, 38 * k, .5, col, { ring: .95 }); glow(p, 2, 26 * k, .45, _c.setRGB(1, 1, 1)); X.shock(p, 90 * k, .75, 1);
  const pc = p.clone(), cc = col.clone(); for (let i = 1; i < 3; i++) setTimeout(() => glow(pc, 4, (38 + i * 18) * k, .5, cc, { ring: .95 }), i * 90);
  X.burst(p, Math.round(90 * k), 46, 'slash', 1.5); X.debris(p, Math.round(14 * k), 26); X.flash([cc.r * .7, cc.g * .7, cc.b * .7], .1);
}
function heroCenter() { const h = X.world.hero; return _q.copy(h.position).setY(h.position.y + (h.userData.h || X.world.heroH) * .5); }
// 11-26 HERO PERFORMS THE LIMIT (taps no longer move him while a limit plays): at time t he rises from where he stands into a
// held strike pose (pi: 1 / 3 = blade raised) at screen height yF above the target, eases there over dur s with a spark trail
// and a slight hover bob, and stays until the limit hops him again (a later X.hop replaces hero.userData and ends the hover).
function hover(t, yF = .3, dur = .32, pi = 1) {
  at(t, () => { const tg = target(), s = X.toScreen(tg, {}), from = heroCenter().clone(); from.z = -30;
    const sx = clamp(s.x + (s.x < X.W / 2 ? 1 : -1) * X.W * .24, X.W * .18, X.W * .82); // beside the target (never covering it / its weak point), above its height
    const to = X.screenToPlane(sx, clamp(Math.min(X.Hh * yF, s.y - X.Hh * .06), X.Hh * .25, X.Hh * .6), -30, new THREE.Vector3());
    const u = X.heroPose(from, pi, tg); R.hv = { u, c0: from, c1: to, t0: R.t, dur };
    // 11-26 user: the floating hero always faces OUTWARD (away from the titan, from where he hovers), whatever side he came from
    u.flip = Math.abs(u.flip) * Math.sign(u.flip * (tg.x >= from.x ? 1 : -1)) * (to.x >= tg.x ? 1 : -1); glow(from, 1, 8, .25, blade(), { vs: 1 }); });
}
function hoverTick() {
  const h = R.hv; if (!h) return; const u = X.world.hero.userData; if (u !== h.u) { R.hv = null; return; }
  const k = clamp((R.t - h.t0) / h.dur, 0, 1), e = 1 - Math.pow(1 - k, 3);
  u.c.copy(h.c0).lerp(h.c1, e); u.c.y += Math.sin((R.t - h.t0) * 5) * px(4, u.c) * k; u.t = Math.min(u.t, .12); // keep the pose crisp, no lunge drift
  if (Math.random() < (k < 1 ? .9 : .35)) sparksAt(heroCenter(), 1, k < 1 ? 4 : 2, blade(_c), k < 1 ? 0 : -2, .9);
}

// ---------------- the limit breaks (OMNI SLASH = main.js) ----------------
const IMPL = {
  // a storm of 24 thin cuts all over the titan in ~1 s, the hero blinking around it, then a 4-arc cross at the target
  cuts(L) {
    R.n = L.hits; const col = blade(), tg = target(), N = L.hits - 1;
    at(0, () => X.hop(tg, {}));
    for (let i = 0; i < N; i++) at(.08 + i * .042, () => { const p = spot(70), r = rand(0, 6.283), s = S0();
      if (i % 3 === 1) X.hop(p, {}); // the hero blinks to every third cut (~8 blinks in 1 s): he IS the storm
      if (i % 2) arcAt(p, s * rand(.3, .45), r, .28, { boost: 1.25, warp: i % 4 === 1 ? 1 : 0 }); else lightArc(p, s * rand(.3, .5), r, .26, col);
      glow(p, 1, 3.5, .14, col); X.burst(p, 5, 20, 'slash', .9); hit(p); });
    hover(.08 + N * .042 + .04, .3, .2, 3); // a beat of stillness above the titan, blade up, before the final cross
    at(1.2, () => { const p = target(), s = S0() * .95, r0 = rand(0, 3.14); X.hop(p, {}); for (let i = 0; i < 4; i++) arcAt(p, s * [1, .9, .8, .7][i], r0 + i * .8, .4, { boost: 1.45 });
      bigBurst(p, col, .9); hit(p, true); });
    R.dur = 1.7;
  },
  // 10 blades of light rain onto the titan (streak from the top edge + impact flash / pillar), then a giant one
  // 11-26 v3 default = he vanishes in a flash, the stars rain, the giant last star IS him (he appears mid-slash at its impact).
  // v2 GROUNDED (?starfall=ground; ?starfall=old = the v1 rise / dive): he stays on his spot, blade raised, the sky
  // dims and the stars rain diagonally from HIS side (faster and faster), a giant last star - he teleport-slashes through its
  // impact (the ultra crit) - then blinks straight home (no gravity drop). ~1.6 s.
  starfall(L) {
    const mode = new URLSearchParams(location.search).get('starfall'); // v3 default: he vanishes; ground = v2; old = v1
    if (mode === 'old') return IMPL.starfallOld(L);
    R.n = L.hits; const col = blade(), N = L.hits - 1, ground = mode === 'ground';
    at(0, () => { X.blinkHome(); const hm = X.world.heroHome, c = new THREE.Vector3(hm.x, hm.y + (X.world.heroH || 4) * .5, hm.z), tg = target(); // his ledge spot
      R.side = X.toScreen(c, {}).x >= X.toScreen(tg, {}).x ? 1 : -1;
      if (ground) { X.heroPose(c, 1, tg); glow(c, 1, 10, .35, col, { vs: 1 }); return; }
      // v3 (user: "have him invisible, not even existing, and the last star is him"): a flash where he stood, then he is gone
      glow(c, 1, 14, .3, col, { vs: 1 }); glow(c, 2, 18, .3, _c.setRGB(1, 1, 1), { ring: .9 }); // vanish flash at his ledge spot (no strike-pose afterimage)
      X.world.heroAway = true; X.world.heroMat.uniforms.alpha.value = 0; });
    const star = (t, big) => at(t, () => { const p = big ? target() : spot(60), s = X.toScreen(p, {}),
        sky = X.screenToPlane(s.x + R.side * X.Hh * (big ? .3 : .38), -X.Hh * .06, p.z, new THREE.Vector3());
      streak(sky, p, big ? 70 : 30, big ? .36 : .26, col); if (big) streak(sky, p, 24, .4, _c.setRGB(1, 1, 1));
      at(R.t + (big ? .15 : .1), () => { glow(p, 1, big ? 34 : 15, big ? .5 : .32, col, { vs: 1 }); glow(p, 2, big ? 30 : 16, .34, col, { ring: .9 });
        if (big) { X.hop(p, {}); /* the last star is him: hop() shows him again, mid-slash at the impact */ bigBurst(p, col, 1.1); arcAt(p, S0() * 1.1, Math.atan2(1, -R.side) , .45, { boost: 1.6 }); hit(p, true); }
        else { lightArc(p, S0() * .34, Math.PI / 2 + rand(-.25, .25), .26, col); X.hitSound(); X.burst(p, 16, 28, 'slash', 1.1); if (R.nDone % 3 === 0) X.shock(p, 22, .3, .7); hit(p); } }); });
    for (let i = 0; i < N; i++) star(.3 + .85 * Math.sqrt((i + 1) / N) - .85 / N * .5, false); // gaps shrink: faster and faster
    star(1.15, true);
    at(1.58, () => X.blinkHome());
    R.tick = () => { const t = R.t, dim = t < .3 ? t / .3 : t < 1.3 ? 1 : clamp(1 - (t - 1.3) / .3, 0, 1);
      const f = X.post.flash; for (let i = 0; i < 3; i++) f[i] = Math.min(f[i], -.12 * dim); X.post_.vig = Math.max(X.post_.vig, .45 + .4 * dim); };
    R.dur = 1.65;
  },
  starfallOld(L) {
    R.n = L.hits; const col = blade(), N = L.hits - 1, tilt = (Math.random() < .5 ? -1 : 1) * .16;
    at(0, () => X.hop(target(), {}));
    hover(.1, .28, .35, 1); // he rises above the titan, blade raised, and calls the stars down; dives with the last one
    const fall = (t, big) => at(t, () => { if (big) at(R.t + .13, () => X.hop(target(), {})); const p = big ? target() : spot(60), s = X.toScreen(p, {}), sky = X.screenToPlane(s.x + X.Hh * tilt * (s.y / X.Hh + .1), -X.Hh * .06, p.z, new THREE.Vector3());
      streak(sky, p, big ? 70 : 30, big ? .36 : .28, col); if (big) streak(sky, p, 24, .4, _c.setRGB(1, 1, 1)); glow(sky.lerp(p, .5), 1, big ? 22 : 9, .25, col, { vs: 1 });
      at(R.t + (big ? .15 : .12), () => { glow(p, 1, big ? 34 : 15, big ? .5 : .32, col, { vs: 1 }); glow(p, 1, big ? 20 : 8, .3, _c.setRGB(1, 1, 1)); glow(p, 2, big ? 30 : 16, .34, col, { ring: .9 }); if (!big) lightArc(p, S0() * .34, Math.PI / 2 + rand(-.25, .25), .24, col);
        if (big) { bigBurst(p, col, 1.05); arcAt(p, S0() * 1.1, -tilt * 1.2, .45, { boost: 1.5 }); hit(p, true); }
        else { X.burst(p, 16, 28, 'slash', 1.1); if (R.nDone % 3 === 0) X.shock(p, 22, .3, .7); if (Math.random() < .4) X.debris(p, 2, 14); hit(p); } }); });
    for (let i = 0; i < N; i++) fall(.12 + i * .11 + rand(-.02, .02), false);
    fall(.12 + N * .11 + .2, true);
    R.dur = 2.0;
  },
  // 5 afterimage clones appear around the titan (quick hops, each clone kept), strike in unison at the target, then shatter
  legion(L) {
    R.n = L.hits; const col = blade(), N = L.hits - 1, tg = target(), clones = [];
    for (let i = 0; i <= N; i++) at(i * .07, () => { X.hop(target(), {}); if (i > 0) { const m = X.world.clones[X.S.cloneI]; m.userData.life = m.userData.max = 1.3;
      m.material.uniforms.tint.value.setRGB(col.r * .8 + .2, col.g * .8 + .2, col.b * .8 + .2); clones.push(m); hit(_p.copy(m.position).setY(m.position.y + Math.abs(m.scale.y) * .5).clone(), false); } });
    at(.6, () => { const p = target(), ts = X.toScreen(p, {}), arms = [...clones.filter((m) => m.visible), X.world.hero];
      arms.forEach((m, k) => { const c = m === X.world.hero ? heroCenter().clone() : _p.copy(m.position).setY(m.position.y + Math.abs(m.scale.y) * .5).clone(), cs = X.toScreen(c, {});
        if (m !== X.world.hero) m.material.uniforms.flash.value.setRGB(col.r * .7, col.g * .7, col.b * .7);
        streak(c, p, 7, .3, col); arcAt(p, S0() * rand(.7, .95), Math.atan2(-(ts.y - cs.y), ts.x - cs.x) + Math.PI / 2 + rand(-.15, .15), .38 + k * .02, { boost: 1.35, warp: k < 3 ? 1 : 0 }); });
      bigBurst(p, col, 1); hit(p, true); });
    at(.95, () => { for (const m of clones) if (m.visible) { const u = m.userData, c = _p.copy(m.position).setY(m.position.y + Math.abs(m.scale.y) * .5);
      u.dis = 0; u.disDur = .32; u.a0 = m.material.uniforms.alpha.value; sparksAt(c, 16, 16, col, 14, 1.1); glow(c, 1, 6, .25, col); } X.A.sfx('shatter'); });
    R.dur = 1.5;
  },
  // two giant screen-spanning X slashes, a rune circle at the crossing charges, then explodes
  cross(L) {
    R.n = L.hits; const col = blade(), tg = target(), big = Math.max(X.W, X.Hh) * 1.05;
    at(0, () => X.hop(tg, {}));
    const cut = (t, a) => at(t, () => { const p = R.cx || (R.cx = target()), s = X.toScreen(p, {}), L2 = Math.hypot(X.W, X.Hh) * .7, dx = Math.cos(a) * L2, dy = Math.sin(a) * L2;
      const A0 = X.screenToPlane(s.x - dx, s.y - dy, p.z, new THREE.Vector3()), B0 = X.screenToPlane(s.x + dx, s.y + dy, p.z, new THREE.Vector3());
      streak(A0, B0, 16, .5, col); arcAt(p, big, -a - Math.PI / 2, .42, { boost: 1.5 }); arcAt(p, big * .8, -a + Math.PI / 2, .4, { boost: 1.2, warp: 0 });
      glow(p, 2, 16, .3, col); X.burst(p, 30, 36, 'slash', 1.3); hit(p); });
    cut(.08, -.75); cut(.3, .75); at(.29, () => X.hop(R.cx || target(), {})); // he blinks across for the second cut of the X
    hover(.44, .27, .3, 3); // then hangs above the crossing, blade raised, while the rune charges
    at(.97, () => X.hop(R.cx, {})); // and dives into it as it explodes
    at(.42, () => { const r = X.runes[0]; r.visible = true; R.rune = r; R.runeT = R.t; r.material.uniforms.col.value.copy(col); X.A.sfx('ready'); });
    R.tick = () => { const r = R.rune; if (!r) return; const p = R.cx, k = R.t - R.runeT, mu = r.material.uniforms, sz = px(S0() * .62, p);
      const g = k < .5 ? ease(k / .5) : 1 + (k - .5) * .5, out = R.t > 1.0 ? clamp(1 - (R.t - 1.0) / .3, 0, 1) : 1;
      r.position.copy(p); r.position.z += 1; r.quaternion.copy(X.camera.quaternion); r.scale.setScalar(sz * g * (R.t > 1 ? 1 + (R.t - 1) * 2.2 : 1));
      mu.spin.value = k * (1.5 + k * 4); mu.hot.value = clamp((k - .3) / .3, 0, 1) * (.5 + .5 * Math.sin(k * 30)); mu.fade.value = Math.min(1, k * 4) * out; if (out <= 0) { r.visible = false; R.rune = null; } };
    at(1.0, () => { const p = R.cx; bigBurst(p, col, 1.25); arcAt(p, big * .7, rand(0, 6.28), .45, { boost: 1.6 }); hit(p, true); });
    R.dur = 1.6;
  },
  // rune circles lock onto every weak-point socket in view (chained by light lines), the hero hops to each and they detonate in order
  prison(L) {
    const col = blade(); let socks = dummyMode() ? [] : sockets().sort(() => Math.random() - .5).slice(0, L.hits);
    if (socks.length < 3) socks = Array.from({ length: 4 }, () => ({ i: -1, area: 'chest', p: spot(90) })); // lobby dummy / odd framing
    R.n = socks.length; R.socks = socks;
    const posOf = (s, out) => (s.i >= 0 ? X.socketWorld(s.i, out) : out.copy(s.p));
    socks.forEach((s, k) => { s.r = X.runes[k]; s.t0 = k * .06; s.boom = .62 + k * .17; s.pos = new THREE.Vector3(); posOf(s, s.pos);
      s.r.material.uniforms.col.value.copy(col); at(s.t0, () => { s.r.visible = true; glow(s.pos, 1, 8, .25, col, { ring: .9 }); }); });
    at(.4, () => { for (let k = 0; k < socks.length; k++) streak(socks[k].pos, socks[(k + 1) % socks.length].pos, 5, .55, col); X.A.sfx('ready'); });
    socks.forEach((s, k) => at(s.boom, () => { const fin = k === socks.length - 1, p = s.pos.clone(); X.hop(p, {});
      arcAt(p, S0() * (fin ? .9 : .5), rand(0, 6.28), .32, { boost: 1.4 }); arcAt(p, S0() * (fin ? .8 : .42), rand(0, 6.28), .3, { boost: 1.2, warp: 0 });
      if (fin) bigBurst(p, col, 1.1); else { glow(p, 2, 18, .35, col, { ring: .95 }); glow(p, 1, 10, .25, _c.setRGB(1, 1, 1)); X.shock(p, 34, .35, .9); X.burst(p, 26, 30, 'wp', 1.2); X.debris(p, 3, 16); }
      hit(p, fin); }));
    R.tick = () => { for (const s of R.socks) { const r = s.r; if (!r.visible) continue; posOf(s, s.pos); const k = R.t - s.t0, mu = r.material.uniforms, after = R.t - s.boom;
      if (after > .25) { r.visible = false; continue; } const sz = px(S0() * .24, s.pos) * (k < .25 ? .3 + .7 * ease(k / .25) : 1) * (after > 0 ? 1 + after * 6 : 1);
      r.position.copy(s.pos); r.position.z += 1; r.quaternion.copy(X.camera.quaternion); r.scale.setScalar(sz);
      mu.spin.value = k * 2.2; mu.hot.value = clamp(1 - (s.boom - R.t) / .35, 0, 1); mu.fade.value = Math.min(1, k * 5) * (after > 0 ? 1 - after / .25 : 1); } };
    R.dur = .62 + socks.length * .17 + .5;
  },
  // the hero leaps high above the titan and falls with one colossal vertical slash: a light line splits the screen, the sea splits
  sky(L) {
    R.n = L.hits; const col = blade(); let tg = target();
    at(0, () => { X.hop(tg, {}); const u = X.world.hero.userData; R.hu = u; R.c0 = u.c.clone(); const s = X.toScreen(tg, {});
      R.top = X.screenToPlane(s.x + rand(-30, 30), X.Hh * .17, u.c.z, new THREE.Vector3()); glow(heroCenter(), 1, 9, .3, col, { vs: 1 }); });
    R.tick = (dt) => { const u = X.world.hero.userData; if (u !== R.hu || !R.c0) return; // a player tap moved him: let it be
      if (R.t < .5) u.c.copy(R.c0).lerp(R.top, 1 - Math.pow(1 - R.t / .5, 3));
      else if (R.t < .62) u.c.copy(R.top);
      else if (R.t < .74) { const k = (R.t - .62) / .12; u.c.copy(R.top).lerp(R.c0, k * k); }
      else u.c.copy(R.c0);
      if (R.t < .74 && Math.random() < .8) { const c = heroCenter(); sparksAt(c, 1, 3, col, 0, .9); } };
    at(.62, () => { streak(R.top, R.c0, 9, .2, col); X.dropClone(X.world.hero, .4); });
    at(.74, () => { tg = target(); const s = X.toScreen(tg, {}), A0 = X.screenToPlane(s.x, -X.Hh * .05, tg.z, new THREE.Vector3()), B0 = X.screenToPlane(s.x, X.Hh * 1.05, tg.z, new THREE.Vector3());
      streak(A0, B0, 40, .7, col); streak(A0, B0, 14, .9, _c.setRGB(1, 1, 1));
      arcAt(tg, X.Hh * .7, rand(-.06, .06), .5, { boost: 1.5 }); arcAt(tg, X.Hh * .55, Math.PI + rand(-.08, .08), .45, { boost: 1.2, warp: 0 });
      for (let i = 0; i < 4; i++) X.shock(X.screenToPlane(s.x, X.Hh * (.15 + i * .24), tg.z, new THREE.Vector3()), 26, .5 + i * .05, .9); // the long distortion line
      bigBurst(tg, col, .9); hit(tg, true);
      const wa = X.world.water; if (wa) { const x = tg.x; for (let i = 0; i < 4; i++) setTimeout(() => wa.splash ? wa.splash(_p.set(x, 0, X.titanGroupZ() + 1 + i * 4), 1.25 - i * .2, { free: true }) : wa.plop(x, -38 + i * 7, 1.2), i * 70); } });
    at(.95, () => { const p = spot(40); glow(p, 2, 16, .3, col, { ring: .9 }); X.burst(p, 24, 30, 'slash', 1.2); hit(p); });
    at(1.12, () => { const p = spot(40); glow(p, 2, 16, .3, col, { ring: .9 }); X.burst(p, 24, 30, 'slash', 1.2); hit(p); });
    R.dur = 1.7;
  },
  // rare (combo 200+): the screen dims (no slow-mo), a giant crescent moon blade sweeps across the titan, then a white burst
  eclipse(L) {
    const Q = .4; // 11-26 user: "that moon skill is shit, maybe just super quick" - the whole timeline x0.4 (2.1 s -> 0.84 s)
    R.n = L.hits; const col = blade().lerp(_c.setRGB(.85, .9, 1), .5), m = X.moon, N = L.hits - 1;
    hover(.12 * Q, .3, .4 * Q, 1); at(1.47 * Q, () => X.hop(target(), {})); // he rises into the eclipse, blade raised, and cuts the white burst
    // 11-26 user: the moon comes from the hero's side, mirrored vertically (hero top-right of the titan -> it enters bottom-right and
    // sweeps through the titan to the top-left), the crescent rotated along its path. Screen path S -> E through the target T.
    // v2 (user, screenshot): the hero floats above the titan on one side (hover() picks the side away from screen centre); the moon
    // comes from the OPPOSITE BOTTOM corner and sweeps up through the titan toward him (hero top-left -> moon from bottom-right).
    at(0, () => { const T = X.toScreen(target(), {}), sx = T.x < X.W / 2 ? 1 : -1; // = hover()'s side for the hero
      R.S = { x: T.x - sx * X.W * .7, y: T.y + X.Hh * .3 }; R.E = { x: T.x + sx * X.W * .7, y: T.y - X.Hh * .3 };
      R.ang = Math.atan2(-(R.E.y - R.S.y), R.E.x - R.S.x); R.dir = Math.cos(R.ang) >= 0 ? 1 : -1;
      X.hop(target(), {}); m.visible = true; m.material.uniforms.col.value.copy(col); X.A.sfx('glide'); });
    for (let i = 0; i < N; i++) at((.55 + (i + .5) * (.85 / N)) * Q, () => { const f = .2 + .6 * (i + .5) / N, p = X.screenToPlane(R.S.x + (R.E.x - R.S.x) * f + rand(-20, 20), R.S.y + (R.E.y - R.S.y) * f + rand(-20, 20), -40, new THREE.Vector3());
      arcAt(p, S0() * .8, R.ang + Math.PI / 2 + rand(-.2, .2), .4, { boost: 1.3, tint: col, warp: i % 2 }); glow(p, 1, 9, .25, col); X.burst(p, 16, 26, 'slash', 1.1); hit(p); });
    at(1.5 * Q, () => { const p = target(); X.flash([1, 1, 1], .45); bigBurst(p, _c.setRGB(1, 1, 1), 1.4); arcAt(p, S0() * 1.2, rand(0, 6.28), .5, { boost: 1.7, tint: col }); hit(p, true); });
    R.tick = () => { const t = R.t / Q, dim = t < .35 ? ease(t / .35) : t < 1.5 ? 1 : clamp(1 - (t - 1.5) / .45, 0, 1);
      const f = X.post.flash; for (let i = 0; i < 3; i++) if (t < 1.5) f[i] = Math.min(f[i], -.22 * dim); X.post_.vig = Math.max(X.post_.vig, .55 + .6 * dim); X.post_.sat = Math.min(X.post_.sat, 1.08 - .6 * dim);
      const k = clamp((t - .35) / 1.15, 0, 1), e = k * k * (3 - 2 * k), p = X.screenToPlane(R.S.x + (R.E.x - R.S.x) * e, R.S.y + (R.E.y - R.S.y) * e, -36, _p);
      m.position.copy(p); m.quaternion.copy(X.camera.quaternion); m.rotateZ(R.ang + R.dir * (-.5 - e * .5)); // = the old horizontal rotation when ang is 0 / PI, tilted along the diagonal path m.scale.setScalar(px(S0() * .85, p));
      m.material.uniforms.fade.value = clamp((t - .25) / .2, 0, 1) * (t > 1.5 ? clamp(1 - (t - 1.5) / .15, 0, 1) : 1); if (t > 1.7) m.visible = false;
      if (t > .35 && t < 1.5 && Math.random() < .7) sparksAt(p, 2, 6, col, 0, 1.2); };
    R.dur = 2.1 * Q;
  },
};

// ---------------- sequencer ----------------
function at(t, fn) { R.ev.push({ t, fn }); R.ev.sort((a, b) => a.t - b.t); }
export function bind(ctx) { X = ctx; return X; }
export function warm(ctx) { X = ctx; mkMeshes(); } // 11-27 PERF PASS: rune circles + moon built (hidden) at boot so main.js warmGPU compiles them (the first Cross / Eclipse linked 2 programs mid-fight)
export function play(L, ctx) {
  if (ctx) X = ctx; mkMeshes(); beat = performance.now();
  for (const r of X.runes) r.visible = false; X.moon.visible = false;
  R = { L, t: 0, ev: [], tick: null, dur: 1.5, n: L.hits, nDone: 0, finDone: false, wpDone: 0 };
  X.pop(L.label, 'LIMIT BREAK', L.tier ?? 2); if (L.sfx?.start) X.A.sfx(L.sfx.start); X.titanState.hit = 1;
  const hc = heroCenter(); glow(hc, 1, (X.world.hero.userData.h || X.world.heroH) * 3, .6, blade(), { ring: .95 }); X.shock(hc, 30, .6, .8); // the wind-up flash at the hero
  (IMPL[L.id] || IMPL.cuts)(L);
}
// per frame while S.on (main.js updateFinisher); false = finished
export function update(dt) {
  if (!R) return false; R.t += dt; beat = performance.now();
  while (R.ev.length && R.ev[0].t <= R.t) { const e = R.ev.shift(); try { e.fn(); } catch (err) { console.warn('limit', R.L.id, err); } }
  if (R.tick) try { R.tick(dt); } catch (err) { console.warn('limit tick', err); R.tick = null; }
  if (R.hv) try { hoverTick(); } catch (err) { console.warn('limit hover', err); R.hv = null; }
  if (R.t >= R.dur && !R.ev.length) { if (!R.finDone) hit(target(), true); R = null; return false; }
  return true;
}
const API = { next: null, get list() { return LIST.map((l) => l.id); }, get active() { return R?.L.id || null; }, pick, play, update };
window.__LIM = API;
