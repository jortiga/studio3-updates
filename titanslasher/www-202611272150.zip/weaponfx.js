// WEAPON FX (11-26, user: "focus on the weapon - a sword with lightning, the sword flaming, shining. That's what we are selling").
// Every blade carries its element on the hero's hand at all times, and its hits land in that element.
//  - AURA: one small quad parented to the blade group (equipment.js a.g: origin = grip, +y = toward the tip), drawn right after
//    the blade. Shader samples the blade's own alpha (8-16 taps) -> a blade-shaped halo, then per mode: flame tongues licking
//    up (screen-up, any pose / flip), lightning crackle, frost mist, glint sweep hilt -> tip, spores, inverted void smoke.
//    Premultiplied blend (One, OneMinusSrcAlpha): adds light AND can darken (void smoke, the ink style's inky underlay).
//  - PARTICLES: ONE pooled THREE.Points (N = 96 fixed: slots 0-63 blade, 64-95 impacts / trail), one draw call, shapes in
//    the fragment shader (dot, 4-point star, flame tongue, ice shard, leaf, smoke). No per-frame allocation.
//  - BOLTS: two reused ribbon meshes (3 bolts on the blade, re-jagged ~14x/s; a 2-bolt fork at storm impacts).
// Quality: AUTO tier >= 5 (1.5x) halves the emit rates + impact counts, tier 6 (lite) also drops to 1 blade bolt.
// ?wfx=0 = off (no meshes created). Data: TABLE below (per weapon id; INK overrides for ?style=ink).
import * as THREE from 'three';
import * as EQ from './equipment.js';

const Q = new URLSearchParams(location.search);
export const ON = Q.get('wfx') !== '0';
const INK = Q.get('style') === 'ink';

// mode: shine | flame | storm | frost | spore | void. core = hot centre colour, edge = halo colour, edge2 = alternate edge
// (aurora), halo = halo strength, rate = blade particles / s, hit = impact kind, trail = afterimage colour.
export const TABLE = {
  w_starter: { mode: 'shine', core: [1, .95, 1], edge: [.7, .48, 1], halo: .32, rate: 5, hit: 'stars', trail: [.7, .5, 1] },
  w_ember: { mode: 'flame', core: [1, .86, .4], edge: [1, .34, .07], halo: .55, rate: 30, hit: 'fire', trail: [1, .45, .12] },
  w_storm: { mode: 'storm', core: [.93, .97, 1], edge: [.38, .66, 1], spark: [1, .9, .45], halo: .5, rate: 12, hit: 'bolt', trail: [.5, .75, 1] },
  w_frost: { mode: 'frost', core: [.88, 1, 1], edge: [.3, .85, 1], halo: .5, rate: 13, hit: 'shards', trail: [.4, .9, 1] },
  w_skyrune: { mode: 'shine', core: [1, 1, 1], edge: [1, .42, .95], edge2: [.42, 1, 1], halo: .42, rate: 10, hit: 'stars', trail: [.9, .55, 1] },
  w_verdant: { mode: 'spore', core: [.85, 1, .55], edge: [.3, .95, .35], halo: .4, rate: 8, hit: 'leaves', trail: [.45, 1, .45] },
  w_void: { mode: 'void', core: [1, .22, .38], edge: [.5, .14, .78], halo: .45, rate: 15, hit: 'void', trail: [.6, .2, .85] },
};
const INK_TABLE = { w_starter: { core: [1, 1, 1], edge: [.72, .86, 1], trail: [.7, .85, 1] } }; // ink: the pale needle shines steel-white
const MODE = { shine: 0, flame: 1, storm: 2, frost: 3, spore: 4, void: 5 };
const SH = { dot: 0, star: 1, flame: 2, shard: 3, leaf: 4, smoke: 5 };

const rand = (a, b) => a + Math.random() * (b - a);
let C = null; // ctx from main.js
const st = { id: null, cfg: null, flare: 0, boltT: 0, emitT: 0, t: 0, flickT: 0, hitBolt: 0, hitBoltT: 0 };
const cols = { core: new THREE.Color(), edge: new THREE.Color(), edge2: new THREE.Color(), trail: new THREE.Color(), spark: new THREE.Color() };
function setCol(c, a) { c.setRGB(a[0], a[1], a[2]); if (INK) { const l = c.r * .3 + c.g * .59 + c.b * .11; c.r += (l - c.r) * .22; c.g += (l - c.g) * .22; c.b += (l - c.b) * .22; } return c; }

// ---------------- aura (per-blade quad) ----------------
const AURA_FS = `uniform sampler2D map; uniform vec4 uvT; uniform vec2 rr; uniform vec2 up; uniform vec2 ay; uniform float axw;
uniform float t, mode, k, ink, flick, glint; uniform vec3 c1, c2, c3; varying vec2 vUv;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f); return mix(mix(h21(i), h21(i + vec2(1., 0.)), f.x), mix(h21(i + vec2(0., 1.)), h21(i + 1.), f.x), f.y); }
float fbm(vec2 p){ return vn(p) * .62 + vn(p * 2.13 + 7.1) * .38; }
float B(vec2 uv){ vec2 b = uv * uvT.xy + uvT.zw; vec2 inb = step(vec2(0.), b) * step(b, vec2(1.)); return texture2D(map, b).a * inb.x * inb.y; }
float halo(vec2 uv, float r){ vec2 d = rr * r, e = d * .7071; return (B(uv + vec2(d.x, 0.)) + B(uv - vec2(d.x, 0.)) + B(uv + vec2(0., d.y)) + B(uv - vec2(0., d.y))
  + B(uv + e) + B(uv - e) + B(uv + vec2(e.x, -e.y)) + B(uv + vec2(-e.x, e.y))) * .125; }
void main(){
  float a = vUv.y * ay.x + ay.y; // 0 = grip, 1 = tip
  vec2 p = vec2((vUv.x - .5) * axw, a); // blade-length units
  float bm = smoothstep(.08, .24, a); // the blade, not the hilt / pommel
  float h1 = halo(vUv, 1.), h2 = halo(vUv, 2.4), core = B(vUv);
  vec3 col = vec3(0.); float dark = 0.;
  vec2 upP = up * vec2(1. / max(axw, .001), 1.); // screen-up in p units (approx)
  if (mode < .5) { // SHINE: soft halo + a glint band sweeping hilt -> tip + a star flare riding it
    float s = glint * 1.5 - .2; float band = exp(-pow((a - s + p.x * .9) / .05, 2.)) * bm;
    col = c2 * (clamp(h1 - core * .8, 0., 1.) * .8 + h2 * .3) * bm + mix(c1, vec3(1.), .5) * band * (core * 1.3 + h1 * .5);
    vec2 q = p - vec2(0., s); float st = (exp(-abs(q.x) * 70.) * exp(-abs(q.y) * 9.) + exp(-abs(q.y) * 70.) * exp(-abs(q.x) * 9.)) * step(0., s) * step(s, 1.05);
    col += vec3(1.) * st * 1.1 + c3 * exp(-dot(q, q) * 260.) * .8 * step(0., s) * step(s, 1.05);
  } else if (mode < 1.5) { // FLAME: halo sampled below (against screen-up) by noise = tongues licking upward
    float n = fbm(p * vec2(9., 5.) - upP * t * 3.2), n2 = vn(p * vec2(18., 10.) - upP * t * 5.);
    vec2 off = -up * (.05 + .3 * n * n) / max(ay.x, .001);
    float fl = halo(vUv + off * vec2(1. / max(axw, .001), 1.), 1.5) * smoothstep(.06, .3, a);
    float fire = smoothstep(.22, .7, fl * (.3 + n * 1.2) + n2 * .08) * (1. - core * .55);
    col = mix(c2 * .85, c1, smoothstep(.45, .95, fire)) * fire * 1.15 + c2 * clamp(h2 - core, 0., 1.) * .45 * bm + c1 * core * bm * .1 * n;
    dark = ink * smoothstep(.05, .4, h2) * (1. - fire) * .45 * bm;
  } else if (mode < 2.5) { // STORM: flickering blue-white halo + fine crackle veins inside it
    float r = abs(vn(p * vec2(26., 9.) + vec2(t * 7., -t * 13.)) - .5); float vein = smoothstep(.05, 0., r) * smoothstep(.02, .3, h2);
    float rimS = clamp(h1 - core * .85, 0., 1.);
    col = c2 * (rimS * .9 + h2 * .35) * bm * flick + mix(c2, c1, .6) * vein * (1. - core * .7) * bm * (.6 + flick * .6);
    dark = ink * smoothstep(.05, .4, h2) * .35 * bm;
  } else if (mode < 3.5) { // FROST: cold rim + slow drifting mist
    float n = fbm(p * vec2(7., 4.) + vec2(t * .25, -t * .45) - upP * t * .3); float mist = smoothstep(.35, .85, n) * smoothstep(.0, .35, h2 * 1.6) * bm;
    float rim = clamp(h1 - core * .8, 0., 1.);
    col = c2 * (rim * 1.1 + h2 * .4) * bm + mix(c2, c1, .5) * mist * .75 + c1 * core * bm * .15;
    dark = ink * smoothstep(.05, .4, h2) * .3 * bm;
  } else if (mode < 4.5) { // SPORE: breathing green halo
    float pl = .75 + .25 * sin(t * 2.4 - a * 6.);
    col = c2 * (h1 * .7 + h2 * .45) * bm * pl + c1 * core * bm * .12;
    dark = ink * smoothstep(.05, .4, h2) * .3 * bm;
  } else { // VOID: dark smoke (darkens) rising off the blade + a thin crimson edge
    float n = fbm(p * vec2(8., 4.5) - upP * t * 1.6);
    vec2 off = -up * (.05 + .12 * n) / max(ay.x, .001);
    float sm = halo(vUv + off * vec2(1. / max(axw, .001), 1.), 2.2) * smoothstep(.05, .3, a);
    float smoke = smoothstep(.06, .5, sm * (.5 + n));
    dark = smoke * .62 * k; col = c2 * smoke * .35 + c1 * clamp(h1 - core * .7, 0., 1.) * 1.3 * bm;
  }
  col *= k; float al = clamp(dark, 0., .85);
  gl_FragColor = vec4(col * (1. - al * .5), al); }`;
const VS = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }';
const PREMUL = { transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide, blending: THREE.CustomBlending,
  blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor, blendEquation: THREE.AddEquation };
function auraMat() {
  return new THREE.ShaderMaterial({ ...PREMUL, vertexShader: VS, fragmentShader: AURA_FS, uniforms: {
    map: { value: null }, uvT: { value: new THREE.Vector4(1, 1, 0, 0) }, rr: { value: new THREE.Vector2(.02, .02) }, up: { value: new THREE.Vector2(0, 1) },
    ay: { value: new THREE.Vector2(1, 0) }, axw: { value: 1 }, t: { value: 0 }, mode: { value: 0 }, k: { value: 1 }, ink: { value: INK ? 1 : 0 }, flick: { value: 1 }, glint: { value: 0 },
    c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() }, c3: { value: new THREE.Color() } } });
}

// ---------------- particles: one Points pool ----------------
const N = 96, NB = 64; // 0..63 blade ring, 64..95 impact / trail ring
const P = { pos: new Float32Array(N * 3), col: new Float32Array(N * 4), aux: new Float32Array(N * 4), vel: new Float32Array(N * 3), life: new Float32Array(N), max: new Float32Array(N),
  siz: new Float32Array(N), grav: new Float32Array(N), drag: new Float32Array(N), spin: new Float32Array(N), a0: new Float32Array(N), bi: 0, ii: NB, live: 0, mesh: null };
const PTS_VS = `attribute vec4 color; attribute vec4 aux; uniform float px; varying vec4 vC; varying vec2 vA;
void main(){ vC = color; vA = aux.yz; vec4 mv = modelViewMatrix * vec4(position, 1.); gl_Position = projectionMatrix * mv; gl_PointSize = aux.x * px / max(.5, -mv.z); }`;
const PTS_FS = `varying vec4 vC; varying vec2 vA;
void main(){ vec2 p = gl_PointCoord - .5; p.y = -p.y; float s = vA.x, a = 0., dk = 0.;
  float cs = cos(vA.y), sn = sin(vA.y); vec2 q = vec2(cs * p.x - sn * p.y, sn * p.x + cs * p.y);
  if (s < .5) { float d = length(p) * 2.; a = pow(max(0., 1. - d), 1.6); }
  else if (s < 1.5) { a = (exp(-abs(q.x) * 30.) * exp(-abs(q.y) * 5.) + exp(-abs(q.y) * 30.) * exp(-abs(q.x) * 5.)) * 1.3 + exp(-dot(p, p) * 60.); }
  else if (s < 2.5) { float y = p.y + .5; float w = .3 * pow(max(0., 1. - y), .7) * smoothstep(0., .25, y); a = smoothstep(w, w * .2, abs(p.x + sin(y * 6. + vA.y) * .05 * y)) * smoothstep(1., .55, y); }
  else if (s < 3.5) { a = smoothstep(1., .6, abs(q.x) * 5.5 + abs(q.y) * 2.1); }
  else if (s < 4.5) { float e = length(vec2(q.x * 2.6, q.y * 1.15)) * 2.; a = smoothstep(1., .8, e) * (.75 + .25 * smoothstep(.06, 0., abs(q.x))); }
  else { float d = length(p) * 2.; a = pow(max(0., 1. - d), 1.3) * .8; dk = .75; }
  a *= vC.a; if (a < .004) discard; gl_FragColor = vec4(vC.rgb * a * (1. - dk * .6), a * dk); }`;
function buildPoints() {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(P.pos, 3).setUsage(THREE.DynamicDrawUsage));
  g.setAttribute('color', new THREE.BufferAttribute(P.col, 4).setUsage(THREE.DynamicDrawUsage));
  g.setAttribute('aux', new THREE.BufferAttribute(P.aux, 4).setUsage(THREE.DynamicDrawUsage));
  g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
  const m = new THREE.Points(g, new THREE.ShaderMaterial({ ...PREMUL, uniforms: { px: { value: 1 } }, vertexShader: PTS_VS, fragmentShader: PTS_FS }));
  m.frustumCulled = false; m.renderOrder = 401; return m;
}
// emit into the blade ring (imp = false) or the impact ring
function emit(imp, x, y, z, vx, vy, vz, life, size, shape, c, br = 1, grav = 0, drag = 1.2, ang = 0, spin = 0) {
  let i; if (imp) { i = P.ii; P.ii = P.ii + 1 >= N ? NB : P.ii + 1; } else { i = P.bi; P.bi = (P.bi + 1) % NB; }
  const j = i * 3, k = i * 4; P.pos[j] = x; P.pos[j + 1] = y; P.pos[j + 2] = z; P.vel[j] = vx; P.vel[j + 1] = vy; P.vel[j + 2] = vz;
  P.col[k] = c.r * br; P.col[k + 1] = c.g * br; P.col[k + 2] = c.b * br; P.col[k + 3] = 1;
  P.aux[k] = size; P.aux[k + 1] = shape; P.aux[k + 2] = ang; P.life[i] = life; P.max[i] = life; P.siz[i] = size; P.grav[i] = grav; P.drag[i] = drag; P.spin[i] = spin;
}
function updatePoints(dt) {
  let live = 0;
  for (let i = 0; i < N; i++) {
    const k = i * 4; if (P.life[i] <= 0) { if (P.aux[k] !== 0) P.aux[k] = 0; continue; }
    live++; P.life[i] -= dt; const j = i * 3, d = Math.exp(-P.drag[i] * dt);
    P.vel[j] *= d; P.vel[j + 1] = P.vel[j + 1] * d - P.grav[i] * dt; P.vel[j + 2] *= d;
    P.pos[j] += P.vel[j] * dt; P.pos[j + 1] += P.vel[j + 1] * dt; P.pos[j + 2] += P.vel[j + 2] * dt;
    const t = Math.max(0, P.life[i] / P.max[i]), sh = P.aux[k + 1];
    P.aux[k] = P.siz[i] * (sh === SH.flame ? .35 + .65 * t : sh === SH.smoke ? 1.6 - .6 * t : .3 + .7 * t); P.aux[k + 2] += P.spin[i] * dt;
    P.col[k + 3] = Math.min(1, t * 2.2) * Math.min(1, (1 - t) * 12 + .2);
  }
  if (live || P.live) { const a = P.mesh.geometry.attributes; a.position.needsUpdate = a.color.needsUpdate = a.aux.needsUpdate = true; }
  P.live = live;
}

// ---------------- bolts: ribbon strips (local xy plane of their parent) ----------------
class Bolts {
  constructor(nb, ns) {
    this.nb = nb; this.ns = ns; const nv = nb * (ns + 1) * 2;
    this.pos = new Float32Array(nv * 3); this.uv = new Float32Array(nv * 2); this.al = new Float32Array(nv); this.pt = new Float32Array((ns + 1) * 2);
    const idx = []; for (let b = 0; b < nb; b++) for (let s = 0; s < ns; s++) { const o = (b * (ns + 1) + s) * 2; idx.push(o, o + 1, o + 2, o + 1, o + 3, o + 2); }
    for (let b = 0; b < nb; b++) for (let s = 0; s <= ns; s++) { const o = (b * (ns + 1) + s) * 2; this.uv[o * 2] = s / ns; this.uv[o * 2 + 1] = 0; this.uv[o * 2 + 2] = s / ns; this.uv[o * 2 + 3] = 1; }
    const g = new THREE.BufferGeometry(); g.setIndex(idx);
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage)); g.setAttribute('uv', new THREE.BufferAttribute(this.uv, 2));
    g.setAttribute('al', new THREE.BufferAttribute(this.al, 1).setUsage(THREE.DynamicDrawUsage)); g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.mesh = new THREE.Mesh(g, new THREE.ShaderMaterial({ ...PREMUL, uniforms: { c1: { value: new THREE.Color(1, 1, 1) }, c2: { value: new THREE.Color(.4, .7, 1) }, k: { value: 1 } },
      vertexShader: 'attribute float al; varying vec2 vUv; varying float vA; void main(){ vUv = uv; vA = al; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }',
      fragmentShader: 'uniform vec3 c1; uniform vec3 c2; uniform float k; varying vec2 vUv; varying float vA; void main(){ float c = 1. - abs(vUv.y * 2. - 1.); float tp = smoothstep(0., .12, vUv.x) * smoothstep(1., .85, vUv.x);'
        + ' vec3 col = mix(c2, c1, pow(c, 4.)) * (pow(c, 1.4) * 1.6) * vA * k * tp; gl_FragColor = vec4(col, 0.); }' }));
    this.mesh.frustumCulled = false;
  }
  // bolt b from (x0,y0) to (x1,y1), jag = max sideways offset, w = half width, a = brightness (0 hides it)
  set(b, x0, y0, x1, y1, jag, w, a) {
    const ns = this.ns, P2 = this.pt, dx = x1 - x0, dy = y1 - y0, l = Math.hypot(dx, dy) || 1, nx = -dy / l, ny = dx / l;
    for (let s = 0; s <= ns; s++) { const f = s / ns, o = s && s < ns ? (Math.random() - .5) * 2 * jag * Math.sin(Math.PI * f) * (.6 + .4 * Math.random()) : 0; P2[s * 2] = x0 + dx * f + nx * o; P2[s * 2 + 1] = y0 + dy * f + ny * o; }
    for (let s = 0; s <= ns; s++) { const s0 = Math.max(0, s - 1), s1 = Math.min(ns, s + 1), tx = P2[s1 * 2] - P2[s0 * 2], ty = P2[s1 * 2 + 1] - P2[s0 * 2 + 1], tl = Math.hypot(tx, ty) || 1;
      const px = -ty / tl * w, py = tx / tl * w, o = (b * (ns + 1) + s) * 2;
      this.pos[o * 3] = P2[s * 2] + px; this.pos[o * 3 + 1] = P2[s * 2 + 1] + py; this.pos[o * 3 + 2] = 0;
      this.pos[o * 3 + 3] = P2[s * 2] - px; this.pos[o * 3 + 4] = P2[s * 2 + 1] - py; this.pos[o * 3 + 5] = 0; this.al[o] = this.al[o + 1] = a; }
    const g = this.mesh.geometry.attributes; g.position.needsUpdate = true; g.al.needsUpdate = true;
  }
  hide(b) { const o = b * (this.ns + 1) * 2; this.al.fill(0, o, o + (this.ns + 1) * 2); this.mesh.geometry.attributes.al.needsUpdate = true; }
}

// ---------------- public ----------------
const A = { mesh: null, owner: null, bolts: null, hit: null };
// ctx: { scene, camera, renderer, tier: () => AUTO tier index (0 best .. 6 lite), H: () => CSS height }
export function init(ctx) {
  if (!ON) return; C = ctx;
  A.mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), auraMat()); A.mesh.frustumCulled = false; A.mesh.visible = false;
  P.mesh = buildPoints(); ctx.scene.add(P.mesh);
  A.bolts = new Bolts(3, 8); A.bolts.mesh.visible = false; A.bolts.mesh.renderOrder = 0;
  A.hit = new Bolts(3, 9); A.hit.mesh.visible = false; A.hit.mesh.renderOrder = 402; ctx.scene.add(A.hit.mesh);
  const ab = EQ.blades()[0]; if (ab) { ab.g.add(A.mesh); ab.g.add(A.bolts.mesh); A.owner = ab.g; } // in the scene from the start: the boot warm-up compiles the shaders
}
function cfgFor(id) {
  const base = TABLE[id] || TABLE.w_starter, ink = INK && INK_TABLE[id]; const c = ink ? { ...base, ...ink } : base;
  setCol(cols.core, c.core); setCol(cols.edge, c.edge); setCol(cols.edge2, c.edge2 || c.edge); setCol(cols.trail, c.trail || c.edge); setCol(cols.spark, c.spark || c.core);
  return c;
}
const low = () => (C?.tier?.() ?? 0) >= 5, lite = () => (C?.tier?.() ?? 0) >= 6;
const _v = new THREE.Vector3(), _u = new THREE.Vector3(), _q = new THREE.Quaternion(), _hc = new THREE.Vector3(), _tc = new THREE.Vector3();
let _ph = 0; // projection scale cache
// per frame, after EQ.updateVisuals (blade groups placed)
export function update(dt) {
  if (!ON || !C) return;
  st.t += dt; st.flare = Math.max(0, st.flare - dt * 2.2);
  const ab = EQ.blades()[0];
  const vis = !!(ab && ab.g.visible && ab.tex && ab.tipY);
  if (vis && st.id !== ab.id) { st.id = ab.id; st.cfg = cfgFor(ab.id); }
  const cfg = st.cfg, cam = C.camera, r = C.renderer;
  _ph = r.domElement.height / (2 * Math.tan(cam.fov * Math.PI / 360)); P.mesh.material.uniforms.px.value = _ph; // world size -> buffer px at depth 1
  if (A.owner !== ab?.g && ab) { ab.g.add(A.mesh); ab.g.add(A.bolts.mesh); A.owner = ab.g; }
  A.mesh.visible = vis; A.bolts.mesh.visible = vis && cfg?.mode === 'storm';
  if (vis) {
    const T = ab.tipY, mode = MODE[cfg.mode] ?? 0, wide = cfg.mode === 'flame' || cfg.mode === 'void' ? .62 : .44;
    const y0 = -.06 * T, y1 = cfg.mode === 'flame' || cfg.mode === 'void' ? 1.32 * T : 1.14 * T, aw = wide * T, ah = y1 - y0;
    A.mesh.position.set(0, (y0 + y1) / 2, 0); A.mesh.scale.set(aw, ah, 1); A.mesh.renderOrder = ab.m.renderOrder + .0005;
    const u = A.mesh.material.uniforms, bw = ab.bw, L = ab.L;
    // aura uv -> blade uv: bx = ((u-.5)*aw - uvx)/bw + .5 ; by = (y0 + v*ah - uvy)/L + .5
    u.uvT.value.set(aw / bw, ah / L, (-.5 * aw - ab.uvx) / bw + .5, (y0 - ab.uvy) / L + .5);
    const g = .045 * T; u.rr.value.set(g / aw, g / ah); u.ay.value.set(ah / T, y0 / T); u.axw.value = aw / T;
    u.map.value = ab.tex; u.t.value = st.t; u.mode.value = mode;
    const fade = ab.m.material.uniforms.alpha.value; u.k.value = (cfg.halo / .5) * (1 + st.flare * .8) * fade;
    // screen-up in the blade group's local frame (flames / smoke rise up the screen in every pose and flip)
    _q.copy(ab.g.quaternion).invert(); _u.set(0, 1, 0).applyQuaternion(cam.quaternion).applyQuaternion(_q); _u.x *= Math.sign(ab.g.scale.x) || 1;
    { const l = Math.hypot(_u.x, _u.y) || 1; u.up.value.set(_u.x / l, _u.y / l); }
    if ((st.flickT -= dt) <= 0) { st.flickT = rand(.03, .08); u.flick.value = Math.random() < .15 ? rand(1.4, 1.9) : rand(.65, 1.1); }
    u.glint.value = (st.t % 1.5) / 1.5;
    u.c1.value.copy(cols.core); if (cfg.edge2) u.c2.value.lerpColors(cols.edge, cols.edge2, .5 + .5 * Math.sin(st.t * 1.7)); else u.c2.value.copy(cols.edge); u.c3.value.copy(cfg.edge2 ? cols.edge2 : cols.edge); // aurora blades drift between their two edge colours
    // blade particles
    ab.g.updateMatrixWorld();
    _hc.set(0, 0, 0); ab.g.localToWorld(_hc); _tc.set(0, T, 0); ab.g.localToWorld(_tc);
    const wl = _hc.distanceTo(_tc) || 1; // blade length in world units
    _u.set(0, 1, 0).applyQuaternion(cam.quaternion); // world screen-up
    let rate = cfg.rate * (low() ? .5 : 1) * (1 + st.flare * 1.5) * fade; st.emitT += dt * rate;
    while (st.emitT >= 1) { st.emitT -= 1; bladeParticle(cfg, wl); }
    if (cfg.mode === 'storm') stormBolts(dt, T, bw, fade);
  }
  if (st.hitBolt > 0) { st.hitBolt -= dt; const k = Math.max(0, st.hitBolt / .2); A.hit.mesh.material.uniforms.k.value = k; if ((st.hitBoltT -= dt) <= 0) { st.hitBoltT = .035; jagHit(); } if (st.hitBolt <= 0) A.hit.mesh.visible = false; }
  updatePoints(dt);
}
function bladeParticle(cfg, wl) {
  const f = Math.random(), x = _hc.x + (_tc.x - _hc.x) * (.15 + f * .9), y = _hc.y + (_tc.y - _hc.y) * (.15 + f * .9), z = _hc.z + (_tc.z - _hc.z) * f + .05;
  const j = wl * .05, ux = _u.x, uy = _u.y, s = wl;
  switch (cfg.mode) {
    case 'flame': if (Math.random() < .62) emit(0, x + rand(-j, j), y + rand(-j, j), z, ux * s * rand(.5, 1) + rand(-.1, .1) * s, uy * s * rand(.6, 1.2), 0, rand(.28, .5), s * rand(.22, .36), SH.flame, Math.random() < .5 ? cols.core : cols.edge, rand(.9, 1.3), -s * .6, 2.5, rand(0, 6));
      else emit(0, x, y, z, rand(-.5, .5) * s, s * rand(.8, 1.8), 0, rand(.5, .9), s * rand(.05, .09), SH.dot, cols.core, 1.6, -s * .4, 1.2); break;
    case 'storm': emit(0, x + rand(-j, j), y + rand(-j, j), z, rand(-1.6, 1.6) * s, rand(-1.6, 1.6) * s, 0, rand(.12, .25), s * rand(.06, .1), Math.random() < .4 ? SH.star : SH.dot, Math.random() < .35 ? cols.spark : cols.core, 1.8, s * 2, 4); break;
    case 'frost': if (Math.random() < .5) emit(0, x + rand(-j, j) * 2, y + rand(-j, j) * 2, z, rand(-.1, .1) * s, rand(-.05, .15) * s, 0, rand(.6, 1.1), s * rand(.07, .12), SH.star, cols.core, 1.3, -s * .05, 1);
      else emit(0, x + rand(-j, j), y + rand(-j, j), z, rand(-.15, .15) * s, -uy * s * .1, 0, rand(.8, 1.3), s * rand(.25, .4), SH.dot, cols.edge, .35, s * .15, 1.5); break;
    case 'spore': if (Math.random() < .45) emit(0, x, y, z, rand(-.4, .4) * s, rand(-.1, .3) * s, 0, rand(.9, 1.5), s * rand(.09, .14), SH.leaf, Math.random() < .5 ? cols.edge : cols.core, 1, s * .35, 1.5, rand(0, 6), rand(-4, 4));
      else emit(0, x + rand(-j, j), y, z, rand(-.2, .2) * s, s * rand(.15, .4), 0, rand(.9, 1.6), s * rand(.04, .07), SH.dot, cols.core, 1.4, -s * .05, .8); break;
    case 'void': if (Math.random() < .55) emit(0, x + rand(-j, j), y + rand(-j, j), z, ux * s * rand(.2, .5), uy * s * rand(.3, .6), 0, rand(.6, 1), s * rand(.25, .4), SH.smoke, cols.edge, .8, -s * .1, 1.5);
      else emit(0, x + rand(-j, j), y, z, rand(-.3, .3) * s, s * rand(.3, .8), 0, rand(.4, .8), s * rand(.05, .08), SH.dot, cols.core, 1.5, -s * .2, 1); break;
    default: { // shine: sparkle stars blinking on / just off the blade
      const sp = cfg.edge2 && Math.random() < .5 ? cols.edge2 : Math.random() < .5 ? cols.edge : cols.core;
      emit(0, x + rand(-j, j) * 2.5, y + rand(-j, j) * 2.5, z, rand(-.08, .08) * s, rand(0, .12) * s, 0, rand(.35, .6), s * rand(.12, .2), SH.star, sp, 1.4, 0, 1, rand(0, .8)); }
  }
}
function stormBolts(dt, T, bw, fade) {
  A.bolts.mesh.material.uniforms.c2.value.copy(cols.edge); A.bolts.mesh.material.uniforms.k.value = fade * (1 + st.flare);
  if ((st.boltT -= dt) > 0) return; st.boltT = rand(.05, .1);
  const hw = bw * .16, nb = lite() ? 1 : 3;
  for (let b = 0; b < 3; b++) {
    if (b >= nb || Math.random() < .3) { A.bolts.hide(b); continue; }
    const y0 = rand(.12, .8) * T, y1 = Math.min(T * 1.12, y0 + rand(.2, .5) * T), s0 = Math.random() < .5 ? -1 : 1;
    if (b === 2 && Math.random() < .5) A.bolts.set(b, 0, T * rand(.85, 1), rand(-.25, .25) * T, T * rand(1.1, 1.3), .07 * T, .012 * T, rand(.6, 1)); // off the tip into the air
    else A.bolts.set(b, s0 * hw * rand(.6, 1.6), y0, -s0 * hw * rand(.6, 1.6), y1, .09 * T, .014 * T, rand(.7, 1.2));
  }
}
// impact bolt fork (storm): world-space, facing the camera, from above the hit down into it
const HB = { p: new THREE.Vector3(), s: 1 }, _R = [0, 0, 0];
function R(k) { const a = rand(0, 6.283), v = _R.s * k * rand(.55, 1); _R[0] = Math.cos(a) * v; _R[1] = Math.sin(a) * v; _R[2] = a; return _R; } // random radial velocity (k x hit size) -> _R
function jagHit() { const s = HB.s, ox = (Math.random() - .5) * s * .5; A.hit.set(0, ox, s * 1.1, 0, 0, s * .14, s * .022, 1.2); A.hit.set(1, ox * .5, s * .55, s * rand(.2, .45) * (Math.random() < .5 ? -1 : 1), -s * .15, s * .1, s * .016, .9);
  A.hit.set(2, 0, 0, s * rand(-.5, .5), -s * rand(.2, .45), s * .08, s * .013, .8); }

// a strike landed at world point p; size = world size scale of the hit (hero height there); big = finisher
export function impact(p, size, big = false) {
  if (!ON || !C || !st.cfg) return; const cfg = st.cfg, s = size * (big ? 1.4 : 1), n = Math.round((big ? 1.5 : 1) * (low() ? .5 : 1) * 16), z = p.z + .6;
  st.flare = 1;
  emit(1, p.x, p.y, z, 0, 0, 0, big ? .32 : .22, s * (big ? 2.6 : 1.8), SH.dot, cols.edge, cfg.mode === 'void' ? .45 : .55, 0, 0); // element-coloured hit glow
  _R.s = s;
  switch (cfg.hit) {
    case 'fire': for (let i = 0; i < n; i++) { R(7); emit(1, p.x, p.y, z, _R[0], _R[1] * .8 + s * 2, 0, rand(.4, .7), s * rand(.5, .85), SH.flame, i % 4 ? cols.edge : cols.core, .85, -s * 3, 3.2, rand(0, 6)); } // flame tongues thrown out, rising
      for (let i = 0; i < n * .6; i++) { R(10); emit(1, p.x, p.y, z, _R[0], _R[1] + s * 3, 0, rand(.6, 1), s * rand(.09, .14), SH.dot, cols.core, 2, s * 9, 1.2); } break; // embers arcing down
    case 'bolt': HB.p.copy(p); HB.s = s * 3.2; A.hit.mesh.position.set(p.x, p.y, z); A.hit.mesh.quaternion.copy(C.camera.quaternion); A.hit.mesh.material.uniforms.c2.value.copy(cols.edge);
      A.hit.mesh.visible = true; st.hitBolt = big ? .32 : .24; st.hitBoltT = 0; jagHit();
      for (let i = 0; i < n; i++) { R(14); emit(1, p.x, p.y, z, _R[0], _R[1], 0, rand(.2, .38), s * rand(.12, .2), i % 3 ? SH.dot : SH.star, i % 3 ? cols.core : cols.spark, 2.2, s * 6, 3.5); } break;
    case 'shards': for (let i = 0; i < n; i++) { R(9); emit(1, p.x, p.y, z, _R[0], _R[1] + s * 1.5, 0, rand(.45, .75), s * rand(.45, .75), SH.shard, i % 3 ? cols.edge : cols.core, 1.05, s * 10, 2.2, Math.PI / 2 - _R[2], rand(-.6, .6)); }
      for (let i = 0; i < 3; i++) { R(1.5); emit(1, p.x, p.y, z, _R[0], _R[1], 0, rand(.6, .9), s * rand(1.1, 1.6), SH.dot, cols.edge, .28, 0, 2); } break; // frost mist puff
    case 'leaves': for (let i = 0; i < n; i++) { R(7); emit(1, p.x, p.y, z, _R[0], _R[1] + s * 2, 0, rand(.7, 1.1), s * rand(.3, .45), i % 3 ? SH.leaf : SH.dot, i % 2 ? cols.edge : cols.core, 1.2, s * 5, 2.8, rand(0, 6), rand(-8, 8)); } break;
    case 'void': for (let i = 0; i < Math.ceil(n / 2); i++) { R(3); emit(1, p.x, p.y, z, _R[0], _R[1] + s, 0, rand(.6, .9), s * rand(.9, 1.4), SH.smoke, cols.edge, .7, -s * .6, 2); }
      for (let i = 0; i < n; i++) { R(10); emit(1, p.x, p.y, z, _R[0], _R[1], 0, rand(.3, .55), s * rand(.12, .18), SH.dot, cols.core, 2, 0, 3); } break;
    default: for (let i = 0; i < Math.ceil(n * .75); i++) { R(8); const c = st.cfg.edge2 && i % 2 ? cols.edge2 : i % 3 ? cols.edge : cols.core;
      emit(1, p.x, p.y, z, _R[0], _R[1], 0, rand(.4, .65), s * rand(.35, .6), SH.star, c, 1.15, 0, 3.5, rand(0, .8)); }
  }
}
// teleport-slash departure: a short element-coloured trail from the old spot toward the new one (a few particles, no line)
export function trail(from, to, size) {
  if (!ON || !C || !st.cfg) return; const n = low() ? 4 : 8, s = size;
  for (let i = 0; i < n; i++) { const f = Math.random() * .45, x = from.x + (to.x - from.x) * f + rand(-.15, .15) * s, y = from.y + (to.y - from.y) * f + rand(-.3, .3) * s;
    const sh = st.cfg.mode === 'flame' ? SH.flame : st.cfg.mode === 'frost' ? SH.shard : st.cfg.mode === 'void' ? SH.smoke : st.cfg.mode === 'spore' ? SH.leaf : SH.star;
    emit(1, x, y, from.z + .3, (to.x - from.x) * .4 + rand(-.3, .3) * s, (to.y - from.y) * .4 + rand(-.3, .3) * s, 0, rand(.25, .45), s * rand(.12, .2), sh, i % 2 ? cols.trail : cols.core, 1.2, st.cfg.mode === 'flame' ? -s : 0, 3, rand(0, 6)); }
}
// afterimage clone in the element colour (main.js dropClone, after its violet defaults)
export function tintClone(mu) {
  if (!ON || !st.cfg) return false; const c = cols.trail; mu.tint.value.setRGB(.35 + c.r * .3, .35 + c.g * .3, .35 + c.b * .3); mu.flash.value.setRGB(c.r * .3, c.g * .3, c.b * .3); return true;
}
export const current = () => st.id;
