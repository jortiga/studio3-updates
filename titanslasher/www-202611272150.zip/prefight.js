// 11-27 PRE-FIGHT REWARDED AD (user: "the ad is: fight the titan with a random blade — we need a carousel, let them stop it").
// FIGHT (lobby-ui.js fight()) -> this popup: WATCH AD · FIGHT WITH A RANDOM BLADE | FIGHT (no ad, always works).
// Ad earned -> a horizontal reel of blade icons spins (fast, ticking), the player taps STOP, the reel eases out with friction and
// lands centred on one cell = their blade (the landing cell is the one nearest to where the friction would stop it, so the timing of
// the tap decides). Reveal (name, rarity colour, slash colour) -> the fight starts with EQ.setTrial(id) (blade sprite + WFX + arc
// colours + stats for that one fight; main.js clears it at the results / lobby entry).
// Pool: every live blade with in-hand art except the starter, the equipped sword and trackOnly (Skyrender stays the 30-day
// exclusive). Reel = 24 cells with fixed rarity counts (W below: ~54% rare, 33% epic, 12.5% legendary), shuffled, no twin
// neighbours, so the odds of a stop are the cell shares.
// Limits: MAX ad blades a local day (daily.js clock: window.DAILY._day() = trusted server time when known), SAVE.adBlades.
// Ads: native app only (window.__rewardedAd(placement) / __rewardedAdReady, TASKS.md "11-27 ADMOB REWARDED ADS"), placement
// 'prefight'. Web without ?adfake=1: no ad -> no popup, FIGHT starts at once. ?adfake=1: a 2.5 s "AD" overlay that always rewards.
// Leaderboard: trial fights count but are marked ⚡: SAVE.last.trial + SAVE.trialLog (the submit_score RPC has no extra field yet;
// see TASKS.md "11-27 PRE-FIGHT AD BLADE" for what the server needs).
import * as EQ from './equipment.js';
import { TABLE as WFX } from './weaponfx.js';
import { itemIcon } from './uiart.js';

const Q = new URLSearchParams(location.search);
export const MAX = 3, PLACEMENT = 'prefight';
const W = { 1: 13, 2: 8, 3: 3 }; // reel cells per rarity (of 24)
const SHOW_WHEN_CAPPED = true; // limit reached: the popup still shows (ad button = COME BACK TOMORROW); false = FIGHT goes straight in
const $ = (s, r = document) => r.querySelector(s);
let C = null, el = null, phase = '', onGo = null, reel = null, autoT = 0, pollT = 0;

// ---------------- fake ad (?adfake=1, web / iPhone link testing) ----------------
if (Q.get('adfake') === '1' && typeof window.__rewardedAd !== 'function') {
  window.__rewardedAdReady = () => true;
  window.__rewardedAd = (placement) => new Promise((res) => {
    const d = document.createElement('div'); d.id = 'pfAdFake';
    d.innerHTML = `<b>AD</b><small>fake rewarded ad · ${String(placement).replace(/[<>&"]/g, '')}</small><i>3</i>`;
    for (const ev of ['pointerdown', 'touchstart', 'click']) d.addEventListener(ev, (e) => e.stopPropagation(), { passive: true });
    document.body.appendChild(d); let n = 3; const t = setInterval(() => { n--; const i = d.querySelector('i'); if (i) i.textContent = n > 0 ? n : '✓'; }, 800);
    setTimeout(() => { clearInterval(t); d.remove(); res(true); }, 2500);
  });
}
const native = () => typeof window.__rewardedAdReady === 'function'; // the app build (the fake defines it too)
const adReady = () => typeof window.__rewardedAd === 'function';

// ---------------- daily cap ----------------
const today = () => { try { const d = window.DAILY?._day?.(); if (d != null) return d; } catch (e) {} const t = Date.now(); return Math.floor((t - new Date(t).getTimezoneOffset() * 60000) / 864e5); };
export function usedToday() { const a = C?.SAVE.adBlades; return a && a.day === today() ? a.n : 0; }
export const leftToday = () => Math.max(0, MAX - usedToday());
function useOne() { const S = C.SAVE, d = today(); if (!S.adBlades || S.adBlades.day !== d) S.adBlades = { day: d, n: 0 }; S.adBlades.n++; C.save(); }

// ---------------- pool + reel ----------------
function pool() {
  const D = EQ.DATA, R = EQ.RIG; if (!D) return [];
  const eqW = EQ.equipped().weapon?.id;
  return D.items.filter((d) => d.slot === 'weapon' && d.rarity >= 1 && !d.trackOnly && d.id !== eqW && !D.starter.includes(d.id) && (!R?.weapons || R.weapons[d.id]));
}
function buildSeq() {
  const P = pool(); if (!P.length) return [];
  const by = {}; for (const d of P) (by[d.rarity] = by[d.rarity] || []).push(d);
  const seq = []; let spare = 0;
  for (const r of [3, 2, 1]) { const n = W[r] + spare; if (!by[r]) { spare = n; continue; } spare = 0; // a rarity with no blade gives its cells to the next one down
    const L = by[r].slice().sort(() => Math.random() - .5); for (let i = 0; i < n; i++) seq.push(L[i % L.length]); }
  if (spare) for (let i = 0; i < spare; i++) seq.push(P[i % P.length]);
  let best = seq, bad = 1e9; // shuffle, keep the order with the fewest equal neighbours (wrap included)
  for (let k = 0; k < 40 && bad; k++) { const s = seq.slice().sort(() => Math.random() - .5); let b = 0; for (let i = 0; i < s.length; i++) if (s[i].id === s[(i + 1) % s.length].id) b++; if (b < bad) { bad = b; best = s; } }
  return best;
}
const css = (a) => { if (!a) return '#e8f4ff'; const m = Math.max(1, ...a); return `rgb(${a.map((v) => Math.round(Math.max(0, v / m) * 255)).join(',')})`; };
const rcol = (d) => EQ.DATA.rarity[d.rarity].color;
const rname = (d) => EQ.DATA.rarity[d.rarity].name.toUpperCase();

// ---------------- API ----------------
// lobby-ui.js: wants() -> show the popup instead of starting at once; open(go) -> go() starts the fight (true = it started)
export function init(ctx) { C = ctx; } // { SAVE, save, sfx }
export function wants() {
  if (!C || !EQ.DATA || !pool().length) return false;
  if (!native()) return false; // web: no ad -> nothing to offer, FIGHT goes straight in
  return leftToday() > 0 || SHOW_WHEN_CAPPED;
}
export const isOpen = () => !!el && !el.classList.contains('hidden');
export const closable = () => isOpen() && phase === 'offer'; // after the ad the blade is theirs: no backing out of the reel
export function close() { if (!closable()) return; hide(); }
function hide() { if (el) el.classList.add('hidden'); phase = ''; cancelAnimationFrame(reel?.raf || 0); clearTimeout(autoT); clearInterval(pollT); reel = null; }

function mount() {
  if (el) return;
  const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'prefight.css'; document.head.appendChild(l);
  el = document.createElement('div'); el.id = 'pfPop'; el.className = 'panel hidden'; el.innerHTML = '<div class="mframe"></div>';
  document.body.appendChild(el);
  for (const ev of ['pointerdown', 'touchstart']) el.addEventListener(ev, (e) => e.stopPropagation(), { passive: true });
  el.addEventListener('click', (e) => { e.stopPropagation(); if (e.target === el && closable()) { C.sfx('click'); hide(); } });
}
export function open(go) {
  mount(); onGo = go; phase = 'offer';
  const fr = $('.mframe', el), P = pool(), left = leftToday();
  const fan = [3, 2, 1].map((r) => P.find((d) => d.rarity === r)).filter(Boolean).slice(0, 3);
  fr.innerHTML = `<div class="pf-fan">${fan.map((d, i) => `<img style="--c:${rcol(d)};--i:${i - (fan.length - 1) / 2}" src="${itemIcon(d.icon)}" alt="">`).join('')}</div>
    <h2>RANDOM BLADE?</h2>
    <p class="pf-s">Watch an ad and fight this titan with a <b>random blade</b>. Rare, epic or <em>legendary</em>. One fight only.</p>
    <button class="btn hot pf-ad"><i>&#9654;</i> WATCH AD &middot; RANDOM BLADE</button>
    <small class="pf-left"></small>
    <button class="btn pf-go">FIGHT</button>`;
  $('.pf-go', fr).addEventListener('click', (e) => { e.stopPropagation(); C.sfx('click'); hide(); go(); });
  $('.pf-ad', fr).addEventListener('click', watch);
  paintOffer(); clearInterval(pollT); pollT = setInterval(paintOffer, 250); // an ad that loads while the popup is up switches the button on
  el.classList.remove('hidden', 'go'); void el.offsetWidth; el.classList.add('go');
}
function paintOffer() {
  if (phase !== 'offer' || !el) return; const b = $('.pf-ad', el), s = $('.pf-left', el), left = leftToday();
  const t = left <= 0 ? 'COME BACK TOMORROW' : adReady() ? '' : 'NO AD RIGHT NOW';
  b.disabled = !!t || b.dataset.busy === '1';
  const h = t ? t : '<i>&#9654;</i> WATCH AD &middot; RANDOM BLADE'; if (b.dataset.h !== h) { b.dataset.h = h; b.innerHTML = h; }
  const st = left <= 0 ? `${MAX} of ${MAX} used today` : `${left} of ${MAX} left today`; if (s.textContent !== st) s.textContent = st;
}
async function watch(e) {
  e.stopPropagation(); const b = e.currentTarget; if (b.disabled || !adReady() || leftToday() <= 0) return;
  C.sfx('click'); b.dataset.busy = '1'; b.disabled = true; let ok = false;
  try { ok = !!(await window.__rewardedAd(PLACEMENT)); } catch (err) { ok = false; }
  b.dataset.busy = '';
  if (!ok || phase !== 'offer') { paintOffer(); return; } // closed early / no fill: nothing spent, the popup stays
  useOne(); spin();
}

// ---------------- the reel ----------------
function spin() {
  phase = 'spin'; clearInterval(pollT);
  const seq = buildSeq(), fr = $('.mframe', el);
  const cells = (k) => seq.map((d, i) => `<div class="pf-cell" data-i="${i}" style="--c:${rcol(d)}"><img src="${itemIcon(d.icon)}" alt=""></div>`).join('');
  fr.innerHTML = `<h2>YOUR BLADE</h2><p class="pf-s">Tap <b>STOP</b> when you feel it.</p>
    <div class="pf-reel"><div class="pf-strip">${cells(0)}${cells(1)}${cells(2)}</div><i class="pf-mark"></i></div>
    <b class="pf-name">&nbsp;</b>
    <button class="btn hot pf-stop">STOP</button>`;
  const strip = $('.pf-strip', fr), win = $('.pf-reel', fr), first = $('.pf-cell', strip);
  const cw = first.getBoundingClientRect().width || 92, L = seq.length, cyc = cw * L;
  reel = { seq, strip, win, cw, cyc, off: Math.random() * cyc, v: 0, vMax: cw * 26, t0: performance.now(), last: performance.now(), stop: null, lastCell: -1, tickAt: 0, raf: 0 };
  $('.pf-stop', fr).addEventListener('click', (ev) => { ev.stopPropagation(); stopReel(); });
  reel.raf = requestAnimationFrame(step);
}
// offset = px of reel scrolled; the marker sits at the window centre; cell i's centre is at i * cw + cw / 2 (one copy = cyc px)
function step(now) {
  const R = reel; if (!R || !el) return; const dt = Math.min(.1, (now - R.last) / 1000); R.last = now;
  if (!R.stop) { R.v = Math.min(R.vMax, R.v + R.vMax * dt * 2.2); R.off += R.v * dt; } // spin-up over ~.45 s, then full speed
  else { const u = Math.min(1, (now - R.stop.t0) / (R.stop.T * 1000)); R.off = R.stop.p0 + R.stop.d * (1 - Math.pow(1 - u, 3)); R.v = (3 * R.stop.d / R.stop.T) * Math.pow(1 - u, 2);
    if (u >= 1) { R.off = R.stop.p0 + R.stop.d; place(); return land(); } }
  place(); R.raf = requestAnimationFrame(step);
}
function place() {
  const R = reel, mid = R.win.clientWidth / 2, o = ((R.off % R.cyc) + R.cyc) % R.cyc;
  R.strip.style.transform = `translate3d(${(mid - (o + R.cyc)).toFixed(1)}px,0,0)`; // middle copy under the marker, the others fill both sides
  const bl = Math.min(2.5, Math.max(0, R.v / R.cw / 7 - .6)).toFixed(1); if (bl !== R.bl) { R.bl = bl; R.strip.style.filter = +bl ? `blur(${bl}px)` : ''; } // speed blur (full speed ~2.5 px, gone below ~4 cells/s)
  const cell = Math.floor(o / R.cw) % R.seq.length; // the cell under the marker
  if (cell !== R.lastCell) { R.lastCell = cell; const t = performance.now();
    if (t - R.tickAt > 34) { R.tickAt = t; C.sfx('click'); const m = $('.pf-mark', R.win); m.classList.remove('tk'); void m.offsetWidth; m.classList.add('tk'); } // tick (rate-capped at full speed)
    const n = $('.pf-name', el); if (n && R.stop) { const d = R.seq[cell]; n.textContent = d.name; n.style.color = rcol(d); } }
}
function stopReel() {
  const R = reel; if (!R || R.stop || phase !== 'spin') return; phase = 'stopping'; C.sfx('click');
  const b = $('.pf-stop', el); b.disabled = true; b.textContent = 'STOPPING';
  // friction: an ease-out (cubic) whose start speed = the current speed; nominal ~2 s of slowing, then the distance is snapped to the
  // NEAREST cell centre (+-half a cell; the duration follows so the speed stays continuous): it always settles dead centre on a blade
  const v = Math.max(R.v, R.cw * 6), Tn = 2.1, dn = v * Tn / 3, p0 = R.off, target = Math.round((p0 + dn - R.cw / 2) / R.cw) * R.cw + R.cw / 2;
  let d = target - p0; if (d < R.cw * 2) d += R.cw * Math.ceil((R.cw * 2 - d) / R.cw);
  R.stop = { p0, d, T: 3 * d / v, t0: performance.now() };
}
function land() {
  const R = reel, o = ((R.off % R.cyc) + R.cyc) % R.cyc, i = Math.round((o - R.cw / 2) / R.cw) % R.seq.length, d = R.seq[(i + R.seq.length) % R.seq.length];
  phase = 'landed'; C.sfx('buy'); const sb = $('.pf-stop', el); if (sb) sb.style.visibility = 'hidden'; R.strip.style.filter = ''; const k = (i + R.seq.length) % R.seq.length;
  R.strip.querySelectorAll(`.pf-cell[data-i="${k}"]`).forEach((c) => c.classList.add('hit')); R.win.classList.add('done');
  const n = $('.pf-name', el); if (n) { n.textContent = d.name; n.style.color = rcol(d); }
  autoT = setTimeout(() => { if (phase !== 'landed') return; phase = 'reveal'; reveal(d); }, 800); // a beat on the landed cell, then the reveal
}
function reveal(d) {
  const fr = $('.mframe', el), w = WFX[d.id] || {}, a1 = css(d.arc), a2 = css(d.arc2 || w.edge || d.arc), col = rcol(d);
  const look = EQ.def(d.id), lv = Math.min(EQ.equipped().weapon?.lv || 0, EQ.DATA.rarity[d.rarity].maxLv), st = EQ.trialStats({ id: d.id, lv }), own = EQ.equipped().weapon, so = own ? EQ.statsAt(own) : {};
  const atk = Math.round(st.tap || 0), atk0 = Math.round(so.tap || 0);
  fr.innerHTML = `<div class="pf-rev" style="--c:${col};--s1:${a1};--s2:${a2}">
      <div class="pf-big"><i class="pf-rays"></i><img src="${itemIcon(d.icon)}" alt=""></div>
      <small class="pf-rar">${rname(d)} BLADE &middot; 1 FIGHT</small>
      <h2 class="pf-bn">${look.name}</h2>
      <div class="pf-slash"><i></i><span>SLASH</span></div>
      <p class="pf-s">${look.info || ''}</p>
      <p class="pf-atk">ATTACK <b>+${atk}%</b>${atk0 ? ` <s>your blade +${atk0}%</s>` : ''}</p>
    </div>
    <button class="btn hot pf-fight">FIGHT!</button>`;
  const go = () => { if (phase !== 'reveal') return; clearTimeout(autoT); C.sfx('click'); hide(); EQ.setTrial(d.id);
    let ok = false; try { ok = onGo ? onGo() : false; } catch (e) { console.error(e); } if (ok === false) EQ.clearTrial(); else badge(d); };
  $('.pf-fight', fr).addEventListener('click', (e) => { e.stopPropagation(); go(); });
  autoT = setTimeout(go, 6000); // never stalls: the fight starts by itself
}
// fight HUD: a small "⚡ TRIAL · <blade>" tag while the trial blade is in hand (kept until EQ.clearTrial())
function badge(d) {
  let b = document.getElementById('pfTrial'); if (!b) { b = document.createElement('div'); b.id = 'pfTrial'; document.body.appendChild(b); }
  b.innerHTML = `<i>&#9889;</i> TRIAL &middot; <b style="color:${rcol(d)}">${d.name}</b>`; b.classList.remove('hidden');
  const t = setInterval(() => { if (!EQ.trialId() || document.body.dataset.st === 'results' || document.body.dataset.st === 'lobby') { b.classList.add('hidden'); if (!EQ.trialId()) clearInterval(t); } }, 250);
}
window.__pf = { open, wants, usedToday, leftToday, stop: stopReel, trial: () => EQ.trialId(), tap: () => EQ.S.tap, weapon: () => EQ.weaponDef()?.id, get phase() { return phase; }, get reel() { return reel; }, reset: () => { if (C) { delete C.SAVE.adBlades; C.save(); } }, _setUsed: (n) => { if (C) { C.SAVE.adBlades = { day: today(), n }; C.save(); } } }; // test hooks
