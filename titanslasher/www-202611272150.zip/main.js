// Titan Tap: single-player visual prototype. three.js stage (perspective low hero camera), puppet-rigged stone titan,
// Omni Slash teleport-strike sequence, weak points bound to titan bones, fake local leaderboard (ghost scores).
import * as THREE from 'three';
import { SH, spriteMat, Post, Sparks, arcMat, lightArcMat, streakMat, glowMat, paintArcMat, arcDistMat, shockDistMat } from './fx.js';
import { GLOW } from './glowmask.js';
import { Puppet } from './puppet.js';
import { Env } from './env.js';
import { seaFloorMat, Water } from './water.js';
import { TitanAnim, ACTS, applyTiming, MOTION, setMotion } from './titan.js';
import { ProcAnim, humanoidProc } from './titans/procanim.js'; // beast / serpent / core archetypes (titans/<id>/titan.json "anim.kind": "proc")
import * as A from './audio.js';
import PASS from './pass.js'; // 11-27 ?pass=N game pass: progression N x faster, own save (tt_save_pass), unranked
import { Dummy, DUMMY_DIR } from './dummy.js';
import { LB } from './leaderboard.js'; // online leaderboard (Supabase, no login), ghost fallback
import * as CUT from './cutend.js'; // 11-28 the kill ending: screen slashed, paper pieces, TITAN SLAIN (time-board kills)
import GUILD from './guild.js'; // 11-28 guild bonus: more shards per titan fight, +1% to +7% by guild size
import * as TB from './timeboard.js'; // 11-28 ?timeboard=1 (default OFF): titan HP by gear, ranked by kill time, local ghosts (TB.ON gates every use)
import { HurtFX, HURT_ON } from './titans/hurt.js'; // 11-27 "is it getting hurt?": hit flash, red hurt tint, wound marks
import { TIX, titanIdxNow, loadTitanData, preloadNext } from './titans/loader.js'; // data-driven titans (titans/index.json + titans/<id>/titan.json)
import * as EQ from './equipment.js'; // gear: slots, items, upgrades, weapon in hand (data/items.json, data/hero_rig.json)
import { HA } from './heroanim.js'; // hero idle flipbook (art/hero/idle_anim.webp, per-frame hand anchors idle_<i>)
import * as INV from './inventory-ui.js'; // inventory / equipment / shop screen
import * as WFX from './weaponfx.js'; // 11-26 per-weapon blade VFX (flame / lightning / frost / shine ...) + element impacts (?wfx=0 off)
import * as CFX from './combo-fx.js'; // 11-26 combo display: blade charge + edge aura (?combo1=0 / ?combo3=0)
import * as MENU from './hud-menu.js'; // 11-26 lobby home HUD: round icon buttons (profile / ranks / daily / shop / gear / settings)
import * as DAILY from './daily.js'; // Daily Rewards popup (window.DAILY = { open, claimable }, data/daily.json)
import { itemIcon, UI as UIDIR } from './uiart.js'; // 11-27 chest reveal before the results
import * as LUI from './lobby-ui.js'; // 11-27 lobby UI v2: top bar (avatar / energy / coins), bottom tab bar (SHOP GEAR FIGHT RANKS SETTINGS), energy (energy.js)
import * as PUI from './prog-ui.js'; // 11-27 progression: levels / XP, titan drops, auto-train, daily winner rewards (progression.js drops.js autotrain.js rewards.js)
import { SeaReflect } from './reflect.js'; // 11-26 fake sea reflections (?refl=K, 0 = off) + cloud sea option (?sea=clouds)
import { NumFX } from './numfx.js'; // 11-26 perf: damage numbers / xN counters in WebGL (bitmap Anton atlas, one instanced draw)
import * as LIM from './limits.js'; // 11-26 LIMIT BREAKS: random finisher ultimates (data/limits.json, ?limit= / ?limitevery=)
import { warmGPU } from './warm.js'; // 11-27 PERF PASS: boot shader compile + texture upload for every pass (no first-use hitches)
import { AR, arenaOf, loadArena, initArena, switchArena } from './arena.js'; // 11-26 per-titan arenas (arenas/<id>/arena.json, ?arena=<id>)

THREE.ColorManagement.enabled = false;
const Q = new URLSearchParams(location.search);
// 11-26 fight timing has two modes (leaderboard.js MODE, one-line switch DEF_MODE there):
//   CYCLE (only ?cycle=1 since 11-27): world clock, a 10-min fight starts by itself every 15 min (:00 :15 :30 :45), then a 5-min
//     rest on the dummy; opening the app mid-fight joins it (your damage in this window is kept across app restarts, tt_run).
//   FREE (default, web + release apps): the warm-up is free play on the dummy, the FIGHT button starts a 75 s energy fight
//     (?fight=S); ?lobby=S (tests) and ?auto=1 (recordings) start it automatically after S seconds.
const CYCLE = LB.cycleMode, FIGHT_S = LB.fightLen, LOBBY_S = +(Q.get('lobby') || 12);
const LOBBY_AUTO = !CYCLE && (Q.has('lobby') || Q.get('auto') === '1');
const RES_S = 12; // CYCLE: the results stay this long (or until NEXT), then the rest on the dummy
const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const WEAK_S = +(Q.get('weak') || 10);
const AUTO = Q.get('auto') === '1', SKIP = Q.get('skip') === '1' || AUTO;
const NODIST = Q.get('nodistort') === '1', HITDEBUG = Q.get('hitdebug') === '1', BONES = Q.get('bones') === '1', WEIGHTS = Q.get('weights') === '1';
// ?clean=1 (animation review / Codex reference frames): no hero, no HUD / anim label, no foreground ledge + props, no near mist
const CLEAN = Q.get('clean') === '1';
// titan move source: mix (default, 11-26: per move, mocap idle / swipe / stagger / roar / guard + Codex slam / throw, tools/mocap_to_2d.py mix)
// | codex (Codex-directed keys) | mocap (11-25 CMU mocap retarget). All three are bend-locked bakes (tools/bake_anim.py).
const ANIM_SRC = Q.get('src') || 'mix';
const NOGLOW = Q.get('noglow') === '1', SELBLOOM = Q.get('selbloom') !== '0'; // glow masks off / selective bloom pass off (?selbloom=0)
const COARSE = matchMedia('(pointer:coarse)').matches;
const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rand = (a, b) => a + Math.random() * (b - a);
const lerp = (a, b, t) => a + (b - a) * t;
const damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));
// 11-26 perf: toLocaleString was ~3.5% of a throttled fight frame (called per number per frame); same output for |n| < 1e21
const fmt = (n) => { n = Math.round(n); const s = String(Math.abs(n)); if (s.length < 4 || s.includes('e')) return n.toLocaleString('en-US'); return (n < 0 ? '-' : '') + s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); };
const buzz = (ms) => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };

// ---------------- save ----------------
const SAVE = { coins: 150, up: { tap: 0, slash: 0, crit: 0 }, best: 0, titans: 0 };
try { Object.assign(SAVE, JSON.parse(localStorage.getItem(PASS.SAVE_KEY) || '{}')); } catch (e) {}
const save = () => { try { localStorage.setItem(PASS.SAVE_KEY, JSON.stringify(SAVE)); } catch (e) {} };
// app hidden (switch / Home / lock / killed): save, silence the audio; the frame loop stops with rAF, so the fight pauses.
// On show: resume the audio and restart the frame clock, so the first frame back is not one huge step.
const onHide = () => { save(); saveRun(); A.hold(true); }; // saveRun: CYCLE mode keeps this window's damage (tt_run)
document.addEventListener('visibilitychange', () => { if (document.hidden) onHide(); else { A.hold(false); last = performance.now(); } });
addEventListener('pagehide', onHide);
document.addEventListener('pause', onHide); // Cordova / Capacitor native pause event (store app)
const UP = {
  tap: { name: 'TAP POWER', desc: (l) => `+${l * 25}% tap damage`, cost: (l) => Math.round(60 * Math.pow(1.55, l)) },
  slash: { name: 'SLASH POWER', desc: (l) => `+${l * 30}% finisher damage`, cost: (l) => Math.round(90 * Math.pow(1.6, l)) },
  crit: { name: 'CRIT CHANCE', desc: (l) => `${Math.min(50, 5 + l * 2)}% critical hits`, cost: (l) => Math.round(80 * Math.pow(1.5, l)) },
};
// 11-26: the upgrade levels live on the gear now (equipment.js; SAVE.up is migrated once into the starter sword / amulet / ring)
EQ.init(SAVE, save);
const CRIT_TEST = new URLSearchParams(location.search).has('critch') ? +new URLSearchParams(location.search).get('critch') : -1; // dev: ?critch=0.5
const tapPow = () => EQ.S.tap, slashPow = () => EQ.S.fin, critCh = () => (CRIT_TEST >= 0 ? CRIT_TEST : EQ.S.crit), comboG = () => .03 * EQ.S.combo;

// ---------------- game state ----------------
const TITANS = TIX.names; // 11-26: one titan per UTC day (titans/index.json rotation), names from each titans/<id>/titan.json
const ANIM = Q.get('anim'); // ?anim=NAME loops one titan act for review (slamL slamR swipe throw roar guard stagger idle rise sink)
const COMBO_GAIN = +(new URLSearchParams(location.search).get('combogain') || .5), COMBO_HOLD = +(new URLSearchParams(location.search).get('combohold') || 1);
const CHAIN_MAX = 999, COMBO_STEP = +(new URLSearchParams(location.search).get('limitevery')) || 30; // ?limitevery= dev only (unranked) // every tap is an omni-slash hop; each COMBO_STEP taps fires an auto finisher
const G = { state: 'start', t: 0, lobbyT: LOBBY_S, fightT: 0, phase: 0, score: 0, chain: 0, lastTap: 0, shield: 0, shieldMax: 1, stun: 0,
  titanIdx: titanIdxNow(), wpHits: 0, slashes: 0, taps: 0, coinsEarned: 0, retreat: 0, scoreShown: 0 };
const S = { on: false, queue: 0, qT: 0, total: 0, dmg: 0, hopN: 0, lastHop: -9, lastSpot: -1, lastSpot2: -1, cloneI: 0, nextFin: COMBO_STEP }; // hops + finisher
// 11-28 time board: app hidden / paused mid-fight = the kill clock stops AND the combo is gone (a pause can't bank it)
if (TB.ON) { const away = () => { if (G.state !== 'fight') return; TB.pause(); G.chain = 0; };
  document.addEventListener('visibilitychange', () => (document.hidden ? away() : TB.resume()));
  addEventListener('pagehide', away); document.addEventListener('pause', away);
  document.addEventListener('resume', () => TB.resume()); addEventListener('pageshow', () => TB.resume()); }

// ---------------- renderer / scene ----------------
const canvas = $('gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', alpha: false, stencil: false });
// colour pipeline (checked 11-26): ColorManagement off + every texture NoColorSpace + LinearSRGB output = no conversion anywhere,
// the painted sRGB colours reach the screen exactly as painted (blending / fog / bloom were all tuned in this space). Keep it.
renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
renderer.autoClear = true;
const post = new Post(renderer);
const ANISO = Math.min(8, renderer.capabilities.getMaxAnisotropy() || 1);
// ---------------- graphics quality (11-26, user: "make sure it's rendering high quality"; perf pass 11-26: "fps is really bad") ----------------
// The render scale = canvas pixels per CSS pixel. AUTO (default since the perf pass) = adaptive tiers below; HIGH = native
// (phones devicePixelRatio up to 3, desktop up to 2), MED = 2x, LOW = 1.5x. ?q=auto|high|med|low overrides for one load;
// window.GFX.set() saves the player's choice (tt_gfx2; the old tt_gfx key is ignored, so everybody starts on AUTO once).
// HIGH / MED / LOW keep the old safety net (fight frames > 24 ms: MSAA off, then a half-res bloom; never lowers the scale).
// AUTO ladder (tier 0 = best). Phones start at A1 (2x), measure 1.5 s windows in the lobby / intro / fight: 2 slow windows
// (avg > 20 ms or > 25% of frames over 20 ms) step DOWN (2 tiers at once below ~30 fps); 3 smooth windows (avg < 17.4 ms) try one
// step UP; a tier that fails within 8 s of stepping up to it is never retried this session. The settled tier is remembered
// (tt_gfx_auto1) and the next launch starts one step better (never at 3x: 3x is only reached by measuring).
const PHONE = COARSE || /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
const GFX_DPR = { high: +Q.get('dpr') || (PHONE ? 3 : 2), med: 2, low: 1.5 }; // ?dpr=N: test override of the HIGH cap
const AUTO_T = [ // dpr cap + switches: bloomDrop = half-res bloom, noRefl = no sea reflections, noDist = no screen warp, lite = fewer overdraw layers
  { n: 'native', dpr: GFX_DPR.high }, { n: '2x', dpr: 2 }, { n: '2x bloom/2', dpr: 2, bloomDrop: 1 }, { n: '2x no refl', dpr: 2, bloomDrop: 1, noRefl: 1 },
  { n: '2x no warp', dpr: 2, bloomDrop: 1, noRefl: 1, noDist: 1 }, { n: '1.5x', dpr: 1.5, bloomDrop: 1, noRefl: 1, noDist: 1, noGlowSel: 1 },
  { n: '1.5x lite', dpr: 1.5, bloomDrop: 1, noRefl: 1, noDist: 1, noGlowSel: 1, lite: 1 }]; // noGlowSel: no selective-bloom re-render of the titan (~33 draws)
const gfxNorm = (v) => { v = String(v).toLowerCase(); v = v === 'medium' ? 'med' : v; return v === 'auto' || Object.prototype.hasOwnProperty.call(GFX_DPR, v) ? v : null; };
let gfxQ = gfxNorm(Q.get('q')) || (() => { try { return gfxNorm(localStorage.getItem('tt_gfx2')); } catch (e) { return null; } })() || 'auto';
const gfxAuto = { step: 0, acc: 0, n: 0, slow: 0, log: [], // step (HIGH/MED/LOW safety net): 1 = MSAA off, 2 = + half-res bloom
  tier: (() => { const lo = PHONE ? 1 : 0; let h = null; try { h = localStorage.getItem('tt_gfx_auto1'); } catch (e) { /* */ } const f = +Q.get('tier'); // ?tier=N: start tier (tests)
    return Number.isFinite(f) && Q.has('tier') ? clamp(f, 0, AUTO_T.length - 1) : h == null || isNaN(+h) ? lo : clamp(+h - 1, lo, AUTO_T.length - 1); })(),
  win: 0, nslow: 0, wn: 0, fast: 0, bad: {}, upAt: -1e9, hold: 0, lock: Q.has('tier') };
const DK0 = post.dk; // distortion strength (fx.js Post)
post.setDither(Q.has('dither') ? Q.get('dither') === '1' : !PHONE); // composite dither: desktop only (iPhone speckle grain suspect), ?dither=0/1
renderer.info.autoReset = false; // per-frame draw-call / triangle totals over every pass (reset in gfxMonitor)
const gfxTier = () => (gfxQ === 'auto' ? AUTO_T[gfxAuto.tier] : null);
function gfxApply() { // render scale + post targets from the real drawing-buffer size
  const t = gfxTier(), dpr = Math.min(devicePixelRatio || 1, t ? t.dpr : GFX_DPR[gfxQ]);
  renderer.setPixelRatio(dpr); renderer.setSize(W, Hh, false);
  const db = renderer.getDrawingBufferSize(new THREE.Vector2());
  // MSAA on the scene target only below ~2.5x: at native 3x the pixels are already finer than MSAA would add, and 4x MSAA at
  // 1170x2532 would cost ~95 MB on an iPhone. WebGL2 only; the auto step 1 turns it off. AUTO on phones: never (multisample
  // resolve = one more full-screen copy per frame on a tile GPU).
  const ms = renderer.capabilities.isWebGL2 && dpr < 2.5 && gfxAuto.step < 1 && !(t && PHONE) ? Math.min(PHONE ? 2 : 4, renderer.capabilities.maxSamples || 0) : 0;
  post.size(db.x, db.y, { dpr, samples: ms, bloomDrop: t ? !!t.bloomDrop : gfxAuto.step >= 2 });
  GFX.dpr = dpr; GFX.samples = ms;
  return dpr;
}
// per-frame switches of the AUTO tier (frame(), just before post.render): reflections, screen warp, overdraw layers
function gfxFrameFx() {
  const t = gfxTier() || {}, rf = world.refl;
  if (rf && !rf.off) { if (t.noRefl) rf.root.visible = false; else if (!rf.root.visible && rf.shared.str.value > 0) rf.root.visible = true; }
  post.dk = NODIST || t.noDist ? 0 : DK0; post.glowSel = SELBLOOM && !t.noGlowSel && (puppet?.glowParts?.length || 0) > 0;
  const lite = !!t.lite; if (world.liteOn !== lite && !CLEAN) { world.liteOn = lite; // every other base / near mist sheet + the second god-ray sheet off (big transparent overdraw)
    [...(world.mist || []), ...(world.env?.mists || [])].forEach((it, i) => { if (i % 2) it.m.visible = !lite; }); if (world.env?.rays2) world.env.rays2.visible = !lite; }
}
// FRAME CAP (11-26 thermal): ?fpscap=auto (default) | 60 | 45 | 30. auto = 60, dropped to 45 then 30 by the AUTO ladder on
// sustained slow frames (never back up this session); a number = fixed. frame() skips rAF ticks with an accumulator, so 45 on
// a 60 Hz screen = 3 of 4 vsyncs. Fewer frames = less GPU + CPU heat per second at the same look per frame.
const CAP = { mode: (() => { const v = String(Q.get('fpscap') || 'auto').toLowerCase(); return ['60', '45', '30'].includes(v) ? v : 'auto'; })(), fps: 60, acc: 0, prev: 0, log: [], upWin: 0 };
CAP.auto = CAP.mode === 'auto'; CAP.fps = CAP.auto ? 60 : +CAP.mode;
function capSet(fps, why) { if (fps === CAP.fps) return; CAP.log.push(`${G.state} ${why || ''}: cap ${CAP.fps} -> ${fps}`); if (CAP.log.length > 8) CAP.log.shift(); CAP.fps = fps; CAP.acc = 0; gfxAuto.win = gfxAuto.wn = gfxAuto.nslow = 0; gfxAuto.fast = 0; }
const GFX = window.GFX = {
  // cap('auto' | 60 | 45 | 30): frame cap (dev panel "FPS cap"); returns the current cap
  cap(v) { if (v != null) { v = String(v).toLowerCase(); CAP.mode = ['60', '45', '30'].includes(v) ? v : 'auto'; CAP.auto = CAP.mode === 'auto'; capSet(CAP.auto ? 60 : +CAP.mode, 'set'); } return CAP.fps; },
  levels:['auto', 'high', 'med', 'low'], labels: { auto: 'AUTO', high: 'HIGH', med: 'MED', low: 'LOW' }, dpr: 1, samples: 0, tiers: AUTO_T,
  get: () => gfxQ,
  set(v) { v = gfxNorm(v); if (!v) return gfxQ; gfxQ = v; try { localStorage.setItem('tt_gfx2', v); } catch (e) {} gfxAuto.step = 0; gfxAuto.slow = 0; gfxAuto.fast = 0; gfxAuto.hold = performance.now() + 1500; if (world.hero) layout(); else gfxApply(); return v; },
  tier: (i) => { if (i != null) { gfxAuto.tier = clamp(+i, 0, AUTO_T.length - 1); gfxAuto.lock = true; gfxAuto.hold = performance.now() + 1500; if (world.hero) layout(); else gfxApply(); } return gfxAuto.tier; }, // tests: force + lock a tier
  info: () => ({ q: gfxQ, tier: gfxQ === 'auto' ? `A${gfxAuto.tier} ${AUTO_T[gfxAuto.tier].n}` : null, dpr: GFX.dpr, samples: GFX.samples, canvas: [canvas.width, canvas.height], css: [W, Hh], scene: [post.w, post.h], bloom: [post.bw, post.bh], autoStep: gfxAuto.step, autoLog: gfxAuto.log, cap: CAP.fps, capMode: CAP.mode, capLog: CAP.log, fps: PERF.fps, ms: PERF.ms, work: PERF.work, calls: PERF.calls, tris: PERF.tris }),
};
// frame monitor (frame() start): PERF counters + the AUTO controller; HIGH/MED/LOW: the old fight safety net
function gfxMonitor(rawMs) {
  const now = performance.now(); PERF.tick(rawMs, now);
  const a = gfxAuto; if (document.hidden || rawMs > 250 || now < a.hold) { a.win = a.wn = a.nslow = 0; return; }
  if (gfxQ !== 'auto') {
    if (G.state !== 'fight' || a.step >= 2) return;
    a.acc += rawMs; a.n++; if (a.acc < 2000) return;
    const avg = a.acc / a.n; a.acc = 0; a.n = 0; a.slow = avg > 24 ? a.slow + 1 : 0;
    if (a.slow >= 2) { a.slow = 0; a.step = GFX.samples ? a.step + 1 : 2; a.log.push(`${avg.toFixed(1)} ms -> step ${a.step}`); gfxApply(); }
    return; }
  if (a.lock || !['lobby', 'fight', 'intro'].includes(G.state) || INV.isOpen() || DAILY.isOpen() || MENU.isOpen()) { a.win = a.wn = a.nslow = 0; return; }
  // budget = the frame interval of the current cap (16.7 ms at 60, 22.2 at 45, 33.3 at 30): "slow" is relative to the cap
  const bud = 1000 / Math.min(60, CAP.fps);
  // 11-27 PERF PASS: at cap 45 on a 60 Hz screen every 3rd frame is naturally 33.3 ms (vsync pacing), which counted as "slow" (> 27 ms)
  // -> the 45 rung always fell to 30 within 3 s (Note 9: "cap 45 -> 30" at 22.2 ms avg). Slow = beyond the longest natural interval.
  a.win += rawMs; a.wn++; if (rawMs > Math.max(bud * 1.23, Math.ceil(bud / 16.7 - .05) * 16.7 + 4)) a.nslow++; if (a.win < 1500) return;
  const avg = a.win / a.wn, sf = a.nslow / a.wn; a.win = a.wn = a.nslow = 0;
  if (avg > bud * 1.2 || sf > .25) { a.slow++; a.fast = 0; } else if (avg < bud * 1.045 && sf < .04) { a.fast++; a.slow = 0; } else { a.slow = 0; a.fast = 0; }
  let to = a.tier;
  // 11-26 THERMAL (user: "the slowdown is related to my phone heating up"): sustained-load ladder. Slow windows step DOWN
  // (2 in a row = 3 s, hysteresis); the frame cap (auto) is one rung of it: A0-A3 first, then 60 -> 45 fps, then A4 / A5,
  // then 45 -> 30, then A6. Stepping UP is only allowed in the first CAP.upWin ms after boot on phones (probing a cool phone):
  // after that a hot phone never climbs back into the load that heated it (no oscillation).
  if (a.slow >= 2 && CAP.auto && ((a.tier >= 5 && CAP.fps > 45) || (a.tier >= 6 && CAP.fps > 30))) { // 11-27 user "60 fps by default": drop to 1.5x resolution (A5) BEFORE capping at 45
    capSet(CAP.fps > 45 ? 45 : 30, `${avg.toFixed(1)} ms A${a.tier}`); a.slow = 0; a.hold = now + 1000; return; }
  if (a.slow >= 2 && a.tier < AUTO_T.length - 1) { if (now - a.upAt < 8000) a.bad[a.tier] = true; to = Math.min(AUTO_T.length - 1, a.tier + (avg > bud * 2 ? 2 : 1)); if (CAP.auto && a.tier < 5 && to > 5) to = 5; }
  else if (a.fast >= 3 && a.tier > 0 && !a.bad[a.tier - 1] && (!PHONE || now < CAP.upWin)) { to = a.tier - 1; a.upAt = now; }
  if (to === a.tier) return;
  a.log.push(`${G.state} ${avg.toFixed(1)} ms ${(sf * 100).toFixed(0)}% slow: A${a.tier} -> A${to}`); if (a.log.length > 12) a.log.shift();
  const dprChange = AUTO_T[to].dpr !== AUTO_T[a.tier].dpr || AUTO_T[to].bloomDrop !== AUTO_T[a.tier].bloomDrop;
  a.tier = to; a.slow = a.fast = 0; a.hold = now + 1000; try { localStorage.setItem('tt_gfx_auto1', String(to)); } catch (e) { /* */ }
  if (dprChange) { if (world.hero) layout(); else gfxApply(); }
}
// ---------------- PERF: fps / frame time / draw calls for the dev panel, ?fps=1 overlay (sticky: ?fps=0 turns it off) ----------------
const PERF = window.PERF = { fps: 0, ms: 0, work: 0, calls: 0, tris: 0, _n: 0, _t: 0, _ft: 0, _w: 0, _c: 0, _tr: 0, el: null,
  tick(rawMs, now) { const ri = renderer.info.render; if (this._n) { this._c += ri.calls; this._tr += ri.triangles; } renderer.info.reset();
    this._n++; this._ft += Math.min(rawMs, 250);
    if (now - this._t >= 500) { const n = Math.max(1, this._n - 1); this.fps = Math.round(1000 * this._n / Math.max(1, now - this._t)); this.ms = +(this._ft / this._n).toFixed(1); this.work = +(this._w / n).toFixed(1);
      this.calls = Math.round(this._c / n); this.tris = Math.round(this._tr / n); this._n = 0; this._t = now; this._ft = this._w = this._c = this._tr = 0;
      if (this.el) this.el.textContent = this.line(); } },
  line() { const t = gfxTier(), f = fxCounts(); return `${this.fps} fps ${this.ms} ms (js ${this.work}) · ${this.calls} dc ${Math.round(this.tris / 1000)}k tri · ${GFX.dpr}x ${post.w}x${post.h} · ${t ? 'AUTO A' + gfxAuto.tier + ' ' + t.n : gfxQ.toUpperCase()} · cap ${CAP.fps}${CAP.auto ? ' auto' : ''}${CAP.log.length ? ' (' + CAP.log.length + ' drop)' : ''} · fx ${f.arcs} arc ${f.warp} warp${post.dOn ? '*' : ''} ${f.glow} glow · ${f.geo} geo ${f.tex} tex`; } };
// live effect counts (dev panel / ?fps=1 line, __g.perfStats): pooled FX alive now + GPU resources (a leak = geo / tex that only grow)
function fxCounts() { const vis = (a) => { let n = 0; if (a) for (const m of a) if (m.visible) n++; return n; }, mem = renderer.info.memory;
  return { arcs: vis(world.arcs) + vis(world.larcs), warp: vis(world.darcs) + vis(world.shocks), glow: vis(world.flashes) + vis(world.streaks), clones: vis(world.clones), geo: mem.geometries, tex: mem.textures }; }
function perfEnd(t0) { PERF._w += performance.now() - t0; }
{ let on = null; try { if (Q.has('fps')) localStorage.setItem('tt_fps', Q.get('fps') === '0' ? '0' : '1'); on = localStorage.getItem('tt_fps') === '1'; } catch (e) { on = Q.get('fps') === '1'; }
  if (on) { const d = PERF.el = document.createElement('div'); d.id = 'fpsBox'; d.style.cssText = 'position:fixed;left:calc(4px + env(safe-area-inset-left,0px));bottom:calc(2px + env(safe-area-inset-bottom,0px));z-index:99;pointer-events:none;font:600 10px/1.2 monospace;color:#e8ffe8;background:#000a;padding:2px 5px;border-radius:4px;white-space:nowrap'; document.body.appendChild(d); } }
const scene = new THREE.Scene(), dscene = new THREE.Scene(); // dscene: distortion writers only
if (NODIST) post.dk = 0;
scene.fog = new THREE.Fog(0x5a4a98, 40, 190);
const camera = new THREE.PerspectiveCamera(50, 1, 0.5, 400);
const BASE_POS = new THREE.Vector3(0, 2.2, 15), BASE_LOOK = new THREE.Vector3(0, 12.5, -42);
const CAM = { shake: 0, fov: 50 }; // fixed rest framing + shake only
// 11-26 fight angle (user: "maybe move the camera once when the titan fight is on, like a little angle from the top"), ?camfight=0/1:
// on fight start the camera eases ONCE (CAM_FIGHT.dur s, ease-in-out) up to a slightly raised, looking-down rest; holds for the
// whole fight (shake only) and eases back on the exit / lobby. CAM_FIGHT.pos / look are the fight rest (tweak live via __g.CAM_FIGHT).
const CAM_FIGHT = { on: Q.get('camfight') !== '0', pos: new THREE.Vector3(0, 3.5, 16.5), look: new THREE.Vector3(0, 10.6, -42), dur: 1.35, k: 0 };
const _camP = new THREE.Vector3(), _camL = new THREE.Vector3();
let W = 1, Hh = 1, portrait = false;

const loader = new THREE.TextureLoader();
// HD titan parts (tools/hq_export.py): <titan folder>/hd.json lists each part's 1x rig size; a texture exported at 2x gets
// userData.up = 2 and puppet.js keeps the mesh in 1x rig pixels. No hd.json / a 1x file = up 1 (unchanged).
const hdJson = new Map();
const hdFor = (dir) => { if (!hdJson.has(dir)) hdJson.set(dir, fetch(dir + 'hd.json?' + Date.now()).then((r) => (r.ok ? r.json() : {})).catch(() => ({}))); return hdJson.get(dir); };
// 11-27 user: the loading bar shows REAL progress (textures requested vs arrived during boot), then fills to 100% before it hides
const LDP = { n: 0, d: 0, on: true, shown: 0 };
function ldBar(p) { const b = document.querySelector('#loading .ld-bar i'); if (!b) return; LDP.shown = Math.max(LDP.shown, p); b.style.animation = 'none'; b.style.width = `${(LDP.shown * 100).toFixed(1)}%`; }
const ldTick = () => { if (LDP.on && LDP.n) ldBar(Math.min(.8, .06 + .74 * LDP.d / LDP.n)); }; // scene art 0-80%, UI art (preloadUI) 80-100%
// every image the DOM UI uses (CSS url()s of the loaded stylesheets + item icons + daily / shop art), fetched AND decoded while the
// loading screen is up; the Image objects are kept so the browser keeps them decoded in memory. Counts into the loading bar.
const UIKEEP = [];
async function preloadUI() {
  const urls = new Set();
  for (const sh of document.styleSheets) { let rules; try { rules = sh.cssRules; } catch (e) { continue; }
    const walk = (rs) => { for (const r of rs) { if (r.cssRules) walk(r.cssRules); const t = r.cssText || ''; for (const m of t.matchAll(/url\(["']?([^"')]+\.(?:webp|png|jpg|svg))["']?\)/g)) urls.add(new URL(m[1], sh.href || location.href).href); } };
    walk(rules); }
  const ink = document.documentElement.classList.contains('ink'), UI = ink ? 'art/ui_ink' : 'art/ui';
  try { const { itemIcon } = await import('./uiart.js'); for (const d of EQ.DATA?.items || []) urls.add(new URL(itemIcon(d.icon), location.href).href); } catch (e) { /* icons load on demand */ }
  for (const f of ['chest_0', 'chest_1', 'chest_2', 'chest_3', 'open_0', 'open_1', 'open_2', 'open_3', 'gems_1', 'gems_2', 'gems_3', 'star']) urls.add(new URL(`${UI}/daily/${f}.webp`, location.href).href);
  if (ink) for (let i = 1; i <= 4; i++) urls.add(new URL(`art/ui_ink/kit/shards_${i}.webp`, location.href).href);
  const list = [...urls]; let done = 0; const base = LDP.shown;
  await Promise.all(list.map((u) => new Promise((ok) => { const im = new Image(); im.decoding = 'async'; UIKEEP.push(im);
    const fin = () => { done++; ldBar(Math.min(.99, base + (1 - base) * done / list.length)); ok(); };
    im.onload = () => { (im.decode ? im.decode() : Promise.resolve()).catch(() => {}).then(fin); }; im.onerror = fin; im.src = u; })));
  window.__boot && (window.__boot.ui = list.length);
}
function loadTex(src, o = {}) {
  if (LDP.on) { LDP.n++; const p = loadTexRaw(src, o); p.then(() => { LDP.d++; ldTick(); }, () => { LDP.d++; ldTick(); }); return p; }
  return loadTexRaw(src, o);
}
function loadTexRaw(src, o = {}) {
  const hm = /^(.*\/)(part_\d+)\.webp$/.exec(src);
  if (hm) hdFor(hm[1]); // request hd.json alongside the parts (was one more round trip after the first part arrived)
  return new Promise((ok, no) => {
    const go = (n) => loader.load(src, (t) => {
      t.colorSpace = THREE.NoColorSpace; t.anisotropy = ANISO; if (o.flipY === false) t.flipY = false; // mipmaps + LinearMipmapLinear are three's defaults
      if (o.repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
      if (hm) hdFor(hm[1]).then((hd) => { const s = hd.parts?.[hm[2]]; if (s) t.userData.up = Math.max(1, Math.round(t.image.width / s[0] * 4) / 4); ok(t); });
      else ok(t);
    }, undefined, () => (n > 0 && !o.quiet ? setTimeout(() => go(n - 1), 400) : no(new Error('load ' + src))));
    go(3);
  });
}
function canvasTex(w, h, draw, repeat) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.NoColorSpace; if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; return t;
}
const rockTex = () => canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#4b4170'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 2600; i++) { const a = Math.random(); g.fillStyle = `rgba(${a > .5 ? '150,130,200' : '20,10,45'},${rand(.04, .16)})`; g.fillRect(Math.random() * w, Math.random() * h, rand(2, 22), rand(1, 7)); }
  g.strokeStyle = 'rgba(10,4,30,.7)'; g.lineWidth = 2; for (let i = 0; i < 9; i++) { g.beginPath(); let x = Math.random() * w, y = Math.random() * h; g.moveTo(x, y); for (let k = 0; k < 5; k++) g.lineTo(x += rand(-30, 30), y += rand(-30, 30)); g.stroke(); }
  g.strokeStyle = 'rgba(83,243,255,.85)'; g.lineWidth = 1.5; g.shadowColor = '#53f3ff'; g.shadowBlur = 6; for (let i = 0; i < 3; i++) { g.beginPath(); let x = Math.random() * w, y = Math.random() * h; g.moveTo(x, y); for (let k = 0; k < 4; k++) g.lineTo(x += rand(-25, 25), y += rand(-25, 25)); g.stroke(); }
}, true);
const puffTex = () => canvasTex(256, 128, (g, w, h) => {
  for (let i = 0; i < 14; i++) { const x = rand(.2, .8) * w, y = rand(.35, .7) * h, r = rand(.12, .3) * w; const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(255,255,255,.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); }
});
const noiseTex = () => canvasTex(256, 256, (g, w, h) => {
  const im = g.createImageData(w, h); const o = [[0, 0, 0, 0]]; const oct = []; for (let k = 0; k < 4; k++) { const n = 4 << k, grid = Array.from({ length: n * n }, Math.random); oct.push([n, grid]); }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { let v = 0, a = 1, tot = 0; for (const [n, gr] of oct) { const fx = x / w * n, fy = y / h * n, x0 = Math.floor(fx), y0 = Math.floor(fy), tx = fx - x0, ty = fy - y0;
    const s = (t) => t * t * (3 - 2 * t), g00 = gr[(y0 % n) * n + x0 % n], g10 = gr[(y0 % n) * n + (x0 + 1) % n], g01 = gr[((y0 + 1) % n) * n + x0 % n], g11 = gr[((y0 + 1) % n) * n + (x0 + 1) % n];
    v += a * lerp(lerp(g00, g10, s(tx)), lerp(g01, g11, s(tx)), s(ty)); tot += a; a *= 0.55; }
    v /= tot; const i = (y * w + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = v * 255; im.data[i + 3] = 255; }
  g.putImageData(im, 0, 0);
}, true);

// ---------------- world ----------------
const world = {};
const lights = {};
let puppet, rigJson, animJson, weightJson, titanGroup, bgMesh, rays;
const T = {}; // textures
const RO = { bg: 0, far: 10, titan: 100, behind: 90, hero: 200, fx: 300, fg: 350, top: 360 }; // top: hero layer (no depth test, drawn after titan + scenery)
const onTop = (m) => { m.material.depthTest = false; m.material.depthWrite = false; return m; }; // user 11-25: no clipping by titan / rocks / ruins

// ---------------- data-driven titans (11-26): titans/<id>/ (titan.json + rig + anims + parts), titans/loader.js ----------------
// mountTitan() swaps the puppet + animator + colours + hooks; it runs at build and when the lobby starts with another titan (the
// titan waits under the sea in the lobby, so the swap is invisible and the dummy -> titan rise stays seamless).
const ACTS0 = JSON.parse(JSON.stringify(ACTS)); // the golem / humanoid act table (procanim.js overwrites ACTS for other archetypes)
const PAL = { wp: [[.5, 1, 1], [.7, 1, 1], [1, 1, 1]] }; // titan colour theme (spark colours of weak-point hits)
function mountTitan(TD) {
  const cfg = TD.cfg || {};
  if (puppet) { titanGroup.remove(puppet.group); puppet.group.traverse((o) => { if (o.isMesh) { o.geometry.dispose(); o.material.dispose(); } }); }
  rigJson = TD.rig; animJson = TD.anim; weightJson = TD.weights; world.titanId = TD.id; world.tcfg = cfg;
  const g = cfg.glow || {}, GO = { cols: g.cols || [[.5, .95, 1], [1, 1, 1], [.55, .95, 1]], k: g.k || [.55, 1.1, .9], rate: g.rate || [1.1, 2.4, 1.6], depth: g.depth || [.2, .18, .35], src: g.src ?? .85, bloom: g.bloom ?? 2.2 };
  puppet = new Puppet(rigJson, TD.tex, (tex, pt, mask) => spriteMat(tex, { glow: mask ? 0 : (cfg.keyGlow ?? (TD.id === 'golem' ? 1.1 : 0)), fogNear: 80, fogFar: 200, glowMap: mask, glowOpts: GO }), TD.glow, weightJson);
  puppet.glowBase = GO.k.slice(); puppet.glow.base = puppet.glowBase.slice();
  post.glowSel = SELBLOOM && puppet.glowParts.length > 0;
  puppet.fit(rigJson.view?.height || 50); titanGroup.add(puppet.group);
  world.hurt = new HurtFX(puppet); world.hurt.setEdge(cfg.colors?.rune || GO.cols[0]); // 11-27 hurt feedback (titans/hurt.js)
  for (const k in ACTS) delete ACTS[k]; Object.assign(ACTS, JSON.parse(JSON.stringify(ACTS0)));
  setMotion(cfg.motion);
  if (cfg.anim?.kind === 'proc') world.anim = new ProcAnim(puppet, animJson, cfg);
  else { world.anim = new TitanAnim(puppet, animJson); applyTiming(animJson); world.anim.stiffOv = cfg.springs || null; world.anim.procFn = cfg.proc ? humanoidProc(cfg.proc) : null; } // humanoid template (+ repaint extras)
  world.anim.phone = portrait;
  for (const k of ['slamL', 'slamR', 'swipe']) if (ACTS[k]) ATK[k].hit = ACTS[k].hit;
  if (animJson.moves.throw?.release) { ATK.throw.release = animJson.moves.throw.release; ATK.throw.hit = animJson.moves.throw.release + .75; }
  titanState.sockets = rigJson.sockets || []; titanState.act = null; world.ambient = cfg.ambient || null; world.hooks = cfg.hooks || {};
  world.weak = cfg.weak || null; // sockets that host weak points (null = all except weak:false)
  const col = cfg.colors || {}; if (col.spark) PAL.wp = col.spark;
  if (lights.cy) lights.cy.color.set(col.light || '#53f3ff');
  for (const w of world.wps || []) w.m.material.uniforms.col.value.setRGB(...(col.rune || [.3, .95, 1]));
  world.refl?.setPuppet?.(puppet);
  if (world.env) switchArena(arenaOf(cfg)); // 11-26 arenas: the lobby swaps to this titan's arena (short fade) while it waits under the sea
  if (world.hero) layout();
}
// the lobby's titan: today's (or ?titan=); swaps while it waits under the sea, preloads the next one
let swapping = null;
function ensureTitan() {
  const id = TIX.ids[G.titanIdx]; if (!id || world.titanId === id || swapping === id) return;
  swapping = id; loadTitanData(id, loadTex, { src: ANIM_SRC, noglow: NOGLOW }).then((TD) => { if (swapping === id && G.state !== 'fight') mountTitan(TD); swapping = null; preloadNext(G.titanIdx, loadTex, { src: ANIM_SRC, noglow: NOGLOW }); }).catch((e) => { console.warn('titan', id, e); swapping = null; });
}

async function build() {
  // titans/<id>/ via titans/loader.js (rig.json, anims, weights.json, part_N.webp + _glow); golem ?src=mix|codex|mocap
  // 11-26 load speed: every texture of the first scene is requested AT ONCE (was ~12 awaits in a row = 12 round trips over the
  // Funnel before the loading screen could end). Only EQ.load (hero_rig.json names the hero files) runs before the art.
  const opt = (f) => loadTex(f).catch(() => null);
  const tdP = loadTitanData(TIX.ids[G.titanIdx] || 'golem', loadTex, { src: ANIM_SRC, noglow: NOGLOW });
  // 11-26 arenas (arena.js): only this titan's arena (arenas/<id>/arena.json: painted layers + glow masks + theme), in parallel
  const envP = loadArena(arenaOf(TIX.cfg(G.titanIdx)), loadTex);
  const slashP = Promise.all([1, 2, 3, 4].map((i) => opt(`art/slash${i}.webp`)));
  const dummyP = Promise.all(['base', 'body', 'arms', 'head', 'chip1', 'chip2', 'chip3'].map((n) => loadTex(`${DUMMY_DIR}/${n}.webp`))); // art/dummy_ink under ?style=ink
  const dGlowP = NOGLOW ? Promise.resolve(null) : loadTex(`${DUMMY_DIR}/body_glow.webp`, { quiet: true }).catch(() => null);
  await EQ.load(); // items + hero rig (sword-less hero art in art/hero/, the weapon is its own sprite)
  const heroP = Promise.all([loadTex(EQ.heroFile('slash')), loadTex(EQ.heroFile('idle')), ...[1, 2, 3, 4].map((i) => opt(EQ.heroFile(`pose${i}`))), opt(EQ.heroFile('land'))]);
  const haP = HA.init({ rig: EQ.RIG, loadTex, setK: (t, k) => TEXK.set(t, k), poseTex: EQ.poseTex }); // idle flipbook frames (off = the still idle)
  const [TD, AR0, slashT, [hs, hi, p1, p2, p3, p4, land]] = await Promise.all([tdP, envP, slashP, heroP]);
  const bg = AR0.tex.sky || await loadTex('art/env/sky.webp');
  rigJson = TD.rig; animJson = TD.anim; weightJson = TD.weights;
  T.env = AR0.tex; // { sky, clouds, far, sea, ledge, mid[], fg[], mist[], splash[], glow: Map(texture -> mask) }, read by env.js
  T.slash = slashT.filter(Boolean); T.poses = [hs, p1, p2, p3, p4];
  T.land = land; // landing / sword-lowered recover pose (idle return)
  // TEXK per sprite (hero_rig.json k: the v2 art is registered onto the old frames, the strike poses at 2x -> 2.75 / 2)
  TEXK.set(hi, EQ.heroK('idle', 1)); TEXK.set(hs, EQ.heroK('slash', 1)); if (T.land) TEXK.set(T.land, EQ.heroK('land', 1.013)); T.poses.slice(1).forEach((t, i) => t && TEXK.set(t, EQ.heroK(`pose${i + 1}`, 2.75)));
  await haP;
  Object.assign(T, { bg, hs, hi, puff: puffTex(), noise: noiseTex(), rock: rockTex() });
  const partTex = TD.tex;
  // emissive masks (E:/jgmkr/tools/glow_mask.py): packed R cracks / G eyes+gem / B runes, loaded by titans/loader.js.
  // A part without a mask file has no glow. ?noglow=1 = old procedural cyan key, for comparison.
  T.glowMask = TD.glow;

  // lights (for the rock geometry)
  lights.hemi = new THREE.HemisphereLight(0xcdb8ff, 0x2b1760, 1.0); scene.add(lights.hemi); // colours per arena (arena.js theme.hemi / sunLight)
  const sun = lights.sun = new THREE.DirectionalLight(0xfff0ff, 1.1); sun.position.set(-12, 22, 14); scene.add(sun);
  lights.cy = new THREE.PointLight(0x53f3ff, 2.4, 70, 1.4); lights.cy.position.set(0, 18, -34); scene.add(lights.cy);
  lights.fl = new THREE.PointLight(0xc59bff, 0, 55, 1.6); lights.fl.position.set(0, 14, -20); scene.add(lights.fl);

  // sky plate
  bgMesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), spriteMat(T.env.sky || bg, { fogNear: 9999, fogFar: 99999 }));
  bgMesh.position.set(0, 20, -150); bgMesh.renderOrder = RO.bg; scene.add(bgMesh);
  // god rays
  rays = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { t: SH.time, col: { value: new THREE.Color(.72, .6, 1) }, k: { value: 1 } }, vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
    fragmentShader: `uniform float t; uniform vec3 col; uniform float k; varying vec2 vUv; void main(){ float x = vUv.x; float r = 0.; for (int i = 0; i < 5; i++) { float fi = float(i); float c = 0.5 + (fi - 2.) * 0.16 + sin(t * .15 + fi) * .02; float w = .035 + .02 * sin(fi * 3.); r += smoothstep(w, 0., abs(x - c - (1. - vUv.y) * (fi - 2.) * .09)) * (.5 + .5 * sin(t * .4 + fi * 2.)); }
      gl_FragColor = vec4(col * r * .13 * k * pow(vUv.y, 1.3), r * .13 * k); }` }));
  rays.position.set(0, 25, -130); rays.scale.set(150, 110, 1); rays.renderOrder = RO.bg + 1; scene.add(rays);

  // cloud sea floor
  const floorMat = seaFloorMat(T.noise); // water.js: flowing sea + wake + splash rings (was a static-ish noise shader here)
  // 11-26 grain fix: the sea used to run to z -400, THROUGH the sky plate (z -150), far ruins (-140) and cloud bank (-170); those
  // depth-tested planes z-fought with it along the horizon (iPhone render-target depth is coarse: colourful speckle band). The sea
  // now ends at z -135, in front of all of them; the cloud strips clip themselves at the waterline in their shader (water.js).
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(500, 235), floorMat); floor.rotation.x = -Math.PI / 2; floor.position.set(0, -0.8, -17.5); scene.add(floor);

  // titan puppet
  titanGroup = new THREE.Group(); titanGroup.position.set(0, -1.2, -42 + TZ); scene.add(titanGroup);
  // masked parts: glow 0 (the procedural key would double the emissive); colours / intensities per titan (titan.json "glow")
  mountTitan(TD); preloadNext(G.titanIdx, loadTex, { src: ANIM_SRC, noglow: NOGLOW });
  world.shield = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { t: SH.time, k: { value: 0 }, hit: { value: 0 }, hp: { value: 1 } }, vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
    fragmentShader: `uniform float t; uniform float k; uniform float hit; uniform float hp; varying vec2 vUv; void main(){ vec2 p = (vUv - .5) * 2.; float d = length(p * vec2(1., .9)); float edge = smoothstep(.55, 1., d) * smoothstep(1.02, .95, d);
      vec2 h = p * 9.; h.x += floor(h.y) * .5; vec2 f = abs(fract(h) - .5); float hex = smoothstep(.42, .5, max(f.x * 1.15, f.y * .9)); float sh = sin(t * 2. + p.y * 5.) * .5 + .5;
      float a = (edge * 1.1 + hex * .22 * smoothstep(1., .3, d) + .06 * (1. - d)) * k * (.65 + .35 * sh) + hit * edge; vec3 c = mix(vec3(.2, .7, 1.), vec3(.8, 1., 1.), hit); gl_FragColor = vec4(c * a, a); }` }));
  world.shield.renderOrder = RO.titan + 60; titanGroup.add(world.shield); world.shield.visible = false;

  // layered painted environment (env.js): sky, cloud bank, far ruins, rays, mid ruins, cloud sea strips, mist, foreground ledge + props, dust
  world.env = new Env(scene, T.env);
  const splashT = AR0.tex.splash; // the arena's splash art (art/fx/ or arenas/<id>/splash1-3)
  world.water = new Water(scene, { seaMat: floorMat, noise: T.noise, puff: T.puff, tex: splashT, shock, coarse: COARSE, seaY: -.8 }); world.env.water = world.water; world.env.sky = bgMesh; // sea splashes, wake, wind gusts; env breathes the sky colour
  world.ruins = []; world.mist = [];
  for (let i = 0; i < 6; i++) { // soft puffs hugging the titan's base (over his lower body, under the front cloud-sea strip)
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), spriteMat(T.puff, { fogNear: 999, fogFar: 9999 })); m.material.uniforms.tint.value.set(.55, .45, .85); m.material.uniforms.alpha.value = .42;
    // 11-25 v3: lower + thinner (was y -1..4, alpha .5) so they wrap the waist only and never wash out the raised arms / elbows
    const sc = rand(34, 56); m.scale.set(sc, sc * .4, 1); m.position.set(rand(-36, 36), rand(-3.5, 1), rand(-40, -33));
    m.renderOrder = 115.7 - (i % 3) * .1; // 11-26 arms down: between the body / pauldrons (<= 115) and the forearms + fists (116+), so the hanging fists stay crisp in front of the waist mist
    scene.add(m); world.mist.push({ m, sp: rand(.2, .7) * (i % 2 ? 1 : -1), x: m.position.x }); }

  // hero
  const hh = 1, heroGeo = new THREE.PlaneGeometry(1, 1); heroGeo.translate(0, .5, 0);
  const heroMat = spriteMat(hi, { glow: .6, fogNear: 999, fogFar: 9999, outline: true }); // violet outline glow so the (smaller) hero pops on the titan
  world.hero = new THREE.Mesh(heroGeo, heroMat); world.hero.renderOrder = RO.top + 20; onTop(world.hero); /* drawn over the slash arcs so he stays readable */ scene.add(world.hero);
  // second hero sprite on top: the OUTGOING pose while poses crossfade (strike -> land -> idle)
  world.heroOld = new THREE.Mesh(heroGeo, spriteMat(hi, { glow: .6, fogNear: 999, fogFar: 9999, outline: true })); world.heroOld.renderOrder = RO.top + 20.5; onTop(world.heroOld); world.heroOld.visible = false; scene.add(world.heroOld);
  world.heroHome = new THREE.Vector3(-2.6, 0, 7.5); world.heroH = 2.6; world.heroAsp = hi.image.width / hi.image.height;
  world.hero.position.copy(world.heroHome);
  world.clones = [];
  for (let i = 0; i < 12; i++) { const m = new THREE.Mesh(heroGeo, spriteMat(hs, { glow: 0, fogNear: 999, fogFar: 9999 })); m.visible = false; m.renderOrder = RO.top + 1 + 0.01 * i; onTop(m); m.userData = { life: 0 }; scene.add(m); world.clones.push(m); }
  world.heroMat = heroMat;
  // ghost slashers (other players, ghosts for now): tinted, semi-transparent copies of the hero poses, drawn under our hero + clones
  world.gs = []; const GSN = GHOST_SLASHERS ? (COARSE ? 3 : 4) : 0; // off = no meshes, no updates, no cost
  for (let i = 0; i < GSN; i++) { const mk = (ro) => { const m = new THREE.Mesh(heroGeo, spriteMat(hs, { glow: 0, fogNear: 999, fogFar: 9999 })); m.visible = false; m.renderOrder = ro; onTop(m); scene.add(m); return m; };
    const lab = document.createElement('div'); lab.className = 'gsl gc' + i; $('hud').appendChild(lab);
    world.gs.push({ i, m: mk(RO.top + .5 + i * .01), ai: mk(RO.top + .3 + i * .01), lab, col: GS_COL[i], t: rand(.4, 1.5), burst: 2, aiL: 0, labT: 0, ghost: null }); }
  world.heroGlow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), glowMat(.75, .5, 1)); world.heroGlow.renderOrder = RO.top; onTop(world.heroGlow); scene.add(world.heroGlow);

  // vfx pools (11-26: ONE shared unit quad FXQ for every pooled FX mesh instead of 108 identical PlaneGeometries / GPU buffers)
  const FXQ = new THREE.PlaneGeometry(1, 1);
  world.arcs = []; world.streaks = []; world.flashes = [];
  for (let i = 0; i < 24; i++) { const m = new THREE.Mesh(FXQ, T.slash.length ? paintArcMat(T.slash[i % T.slash.length]) : arcMat()); m.visible = false; m.renderOrder = RO.top + 10 + i * .01; onTop(m); m.userData = { t: 9, dur: 0.4 }; scene.add(m); world.arcs.push(m); }
  // LIGHT arcs (user 11-25): cheap additive shader crescents for every normal tap + the ghost slashers. The painted arcs above are
  // reserved for SKILL moments (finisher, crits, rune broken, combo milestones) and keep their distortion; light arcs have none.
  world.larcs = []; for (let i = 0; i < 28; i++) { const m = new THREE.Mesh(FXQ, lightArcMat()); m.visible = false; m.renderOrder = RO.top + 9 + i * .01; onTop(m); m.userData = { t: 9, dur: .3 }; scene.add(m); world.larcs.push(m); }
  for (let i = 0; i < 12; i++) { const m = new THREE.Mesh(FXQ, streakMat()); m.visible = false; m.renderOrder = RO.top + 11; onTop(m); m.userData = { t: 9, dur: 0.3 }; scene.add(m); world.streaks.push(m); }
  for (let i = 0; i < 36; i++) { const m = new THREE.Mesh(FXQ, glowMat(1, 1, 1)); m.visible = false; m.renderOrder = RO.top + 12; onTop(m); m.userData = { t: 9, dur: 0.3, s0: 1, s1: 2 }; scene.add(m); world.flashes.push(m); }
  world.sparks = new Sparks(1100); scene.add(world.sparks.mesh);
  // distortion pools (own scene, rendered at 1/4 res into post.d): one warp mirror per slash arc + shockwave rings
  world.darcs = world.arcs.map((a, i) => { const m = new THREE.Mesh(a.geometry, arcDistMat(T.slash.length ? T.slash[i % T.slash.length] : T.noise)); m.visible = false; m.renderOrder = i * .01; dscene.add(m); return m; });
  world.shocks = Array.from({ length: 8 }, () => { const m = new THREE.Mesh(FXQ, shockDistMat()); m.visible = false; m.renderOrder = 1; m.userData = { t: 9, dur: .3, s: 1 }; dscene.add(m); return m; });
  // debris (real boxes, lit)
  // 11-25 fix "pure black debris cubes": three r160 lights are physical (Lambert / PI) and output is LinearSRGB without an sRGB
  // encode, so 0xa890e0 x the dark rock canvas came out ~rgb(18,11,53). Albedo pushed into the titan's stone range (>1 is fine)
  // + a violet emissive floor so faces turned away from the sun never go black.
  const debMat = new THREE.MeshLambertMaterial({ map: T.rock, emissive: 0x2a1850 }); debMat.color.setRGB(2.2, 1.85, 2.5);
  world.debris = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), debMat, 140); world.debris.frustumCulled = false;
  world.debris.count = 140; scene.add(world.debris);
  world.dd = Array.from({ length: 140 }, () => ({ p: new THREE.Vector3(0, -99, 0), v: new THREE.Vector3(), r: new THREE.Vector3(), w: new THREE.Vector3(), s: 0, life: 0 }));
  world.di = 0;
  // weak points
  world.wps = [];
  const wpMat = () => new THREE.ShaderMaterial({ transparent: true, depthWrite: false, depthTest: false, blending: THREE.NormalBlending, side: THREE.DoubleSide, // normal blend + dark outline: readable over white slash arcs
    uniforms: { t: SH.time, k: { value: 1 }, flash: { value: 0 }, left: { value: 1 }, col: { value: new THREE.Color(.3, .95, 1) } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
    fragmentShader: `uniform float t; uniform float k; uniform float flash; uniform float left; uniform vec3 col; varying vec2 vUv; void main(){ vec2 p = (vUv - .5) * 2.; float d = length(p);
      float ring1 = smoothstep(.07, 0., abs(d - .86 + sin(t * 4.) * .03)), ring2 = smoothstep(.05, 0., abs(d - .55)), dot_ = smoothstep(.22, 0., d);
      float ang = atan(p.x, p.y) / 6.28318 + .5; float tick = step(ang, left) * smoothstep(.09, .02, abs(d - .97)) * 1.6 + smoothstep(.05, 0., abs(d - .97)) * .25;
      float cross_ = (smoothstep(.04, 0., abs(p.x)) + smoothstep(.04, 0., abs(p.y))) * smoothstep(1., .62, d) * step(.55, d);
      float a = (ring1 + ring2 * .7 + dot_ * 1.2 + tick * .8 + cross_ * .8 + (1. - d) * .12 * step(d, 1.)) * k; a += flash * smoothstep(1., 0., d) * 1.5;
      float dark = (smoothstep(.16, .08, abs(d - .86)) + smoothstep(.13, .07, abs(d - .55)) * .8 + smoothstep(.1, .05, abs(d - .97)) * .8) * min(k, 1.) * .75;
      float b = clamp(a, 0., 1.); vec3 c = mix(vec3(.04, .02, .14), mix(col * 1.3, vec3(1.), clamp(a - 1., 0., 1.) * .6), b);
      gl_FragColor = vec4(c, max(b, min(1., dark))); }` });
  for (let i = 0; i < 2; i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), wpMat()); m.visible = false; m.renderOrder = RO.top + 15; scene.add(m); // over the arcs, under the hero
    const label = document.createElement('div'); label.className = 'wpc'; $('hud').appendChild(label);
    world.wps.push({ m, label, on: false, pos: new THREE.Vector3(), sock: -1, state: 'off', life: 0, kick: 0, pop: 0, size: 5, hits: 0, cool: i ? 2.5 : .6 }); }
  for (const w of world.wps) w.m.material.uniforms.col.value.setRGB(...(world.tcfg?.colors?.rune || [.3, .95, 1])); // titan rune colour
  titanState.sockets = rigJson.sockets || [];
  // the rock the titan throws (flavour only)
  const rockTx = partTex.part_10 || Object.values(partTex)[0]; world.rockP = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), spriteMat(rockTx, { glow: 1.2, fogNear: 999, fogFar: 9999 }));
  world.rockP.userData.asp = rockTx.image.width / rockTx.image.height; world.rockP.material.uniforms.flash.value.setRGB(.25, .02, .05); world.rockP.renderOrder = RO.top + 25; onTop(world.rockP); world.rockP.visible = false; scene.add(world.rockP);
  // lobby training dummy (game/dummy.js, art/dummy/ from tools/make_dummy.py): wooden totem planted in the cloud sea in front of where the titan rises
  const [DT, dGlow] = await Promise.all([dummyP, dGlowP]); // requested at the top of build()
  world.dummy = new Dummy(scene, { base: DT[0], body: DT[1], arms: DT[2], head: DT[3], chips: DT.slice(4), glow: dGlow }, { spriteMat, ro: 330, fx: {
    sparks: (p, n, dir) => { for (let i = 0; i < n; i++) world.sparks.emit(p.x, p.y, p.z + .3, dir * rand(1, 7) + rand(-3, 3), rand(-1, 7), rand(0, 3), rand(.25, .5), rand(.5, 1.1), 1, rand(.7, .9), rand(.4, .7), 2); },
    burst: (p) => { burst(p, 70, 18, 'dust', 2); burst(p, 30, 22, 'wp', 1.4); flashAt(p, 1, 9, .3, .5, .9, 1, { ring: .95 }); shock(p, 16, .4, .9); A.sfx('slam'); world.water?.splash(_v.set(p.x, -.8, p.z), .55); },
    land: (p) => { burst(_v.copy(p).setY(p.y + .2), 30, 9, 'dust', 1.4); shock(p, 9, .3, .6); world.water?.splash(_v.set(p.x, -.8, p.z), .35); A.sfx('land'); } } });
  // equipped weapon follows the hand of every hero sprite (hero, crossfade sprite, afterimage clones); ring / amulet sparkle
  await EQ.initVisuals({ scene, spriteMat, loadTex, T, sprites: [world.hero, world.heroOld, ...world.clones],
    sparks: (x, y, z, r, g, b, h) => world.sparks.emit(x, y, z, rand(-.3, .3), rand(.4, 1.2), 0, rand(.5, .9), rand(.35, .6) * h * .5, r, g, b, -.5) });
  WFX.init({ scene, camera, renderer, tier: () => (gfxQ === 'auto' ? gfxAuto.tier : gfxQ === 'low' ? 5 : 0) }); // blade element fx (weaponfx.js)
  world.refl = new SeaReflect(scene, { world, q: Q, cfg: TIX.cfg(G.titanIdx) }); // after titan + env + water + dummy exist
  world.env.rays = rays; // main god rays: colour per arena
  initArena({ world, scene, lights, canvas, titan: titanGroup, next: () => arenaOf(TIX.cfg((G.titanIdx + 1) % Math.max(1, TIX.n))) }, AR0); // applies the arena theme to env / water / reflections / lights / fog
  if (DOJO_ON) import('./dojo.js').then((m) => m.initDojo({ scene, world, camera, renderer, titan: titanGroup, loadTex, restPos: BASE_POS, restLook: BASE_LOOK, state: () => G.state })).catch((e) => console.warn('dojo', e)); // 11-27 lobby = dojo hall (ink style), fights = the cave
  A_ready();
}
const titanState = { sockets: [], flinch: 0, flinchDir: 0, hit: 0, act: null, actT: 0, nextAct: 5, tint: 1, rage: 0, dormant: 1, shake: 0, retreatY: 0, alpha: 1, roar: 0, guard: 0, slamPunch: 0 };
function A_ready() { /* hook for later */ }

// ---------------- layout ----------------
function layout() {
  // the canvas' real CSS box (fixed, inset 0): the backing store must be exactly this x the render scale, or the browser rescales it
  const cr = canvas.getBoundingClientRect(); W = cr.width || innerWidth; Hh = cr.height || innerHeight; portrait = W / Hh < 1.05;
  // 11-26: phones render at NATIVE resolution (MOBILE_PERFORMANCE.md section 3 + the user's rule: below native reads pixelated;
  // the old 1.35 cap upscaled ~2.2x on an iPhone and blew sub-pixel sea sparkles up into visible grain). Capped at 3.
  // Render scale + post targets: gfxApply() (graphics quality block near the renderer).
  const dpr = gfxApply();
  camera.aspect = W / Hh; CAM.fov = portrait ? clamp(66 + (0.55 - W / Hh) * 30, 62, 78) : 57; camera.fov = CAM.fov; camera.updateProjectionMatrix();
  if (world.hero) {
    const dist = 140 + 8, vh = 2 * 150 * Math.tan(CAM.fov * Math.PI / 360) * 1.7;
    bgMesh.scale.set(Math.max(vh * 16 / 9, vh * camera.aspect * 1.2), vh, 1);
    rays.scale.set(vh * 1.4, vh * 1.1, 1);
    world.heroHome.set(portrait ? -1.3 : -3.2, 0, portrait ? 6.5 : 7.2); world.heroHome0 = world.heroHome.clone(); // heroHome0 = the fixed lobby spot (on the dojo step)
    // 11-27 user (twice): the hero must be this SMALL size. Keep this line on its own - a comment once swallowed it (hero went 2.6).
    world.heroH = (portrait ? 1.47 : 1.34) * HERO_SCALE; // idle ~13-14% of screen height on phones, ~17% desktop (user 11-25 x2: hero smaller; was 2.1 / 1.92)
    for (const m of [...world.darcs, ...world.shocks]) m.material.uniforms.asp.value = W / Hh;
    if (world.anim) world.anim.phone = portrait; // portrait plays the baked phone variant (fists clamped into the frame)
    // user 11-25: titan BIG (was 1 / .9 at y -1.2): scaled up and sunk deeper into the cloud sea. 11-26 phone (iPhone shot: "too close"):
    // 1.6 -> .88 so the whole golem reads (head under the HUD, both hanging fists in frame); titanY puts the waterline at the hips
    // (rig y ~ -140, as desktop). anim_spec.json phone_view (frame in rig px) is measured for this framing: rebake if it changes.
    { const fr = TIX.cfg(G.titanIdx)?.framing || { s: 1.142, y: -2.54, phone: { s: .716, y: -1.89 } }, f = portrait ? fr.phone || fr : fr; world.titanS0 = f.s; world.titanY0 = f.y; applyTitanDist(); } // per-titan framing (titans/<id>/titan.json); 11-26 v4 golem stands to mid-thigh
    camera.position.copy(BASE_POS); camera.lookAt(BASE_LOOK); world.env.layout(camera, W, Hh, world.heroHome, portrait);
    world.env.dustU.px.value = Hh * dpr / (2 * Math.tan(camera.fov * Math.PI / 360)) * .09; // point size in real buffer pixels
    world.dummy?.layout(camera, W, Hh, portrait);
  }
  post.comp.uniforms.ctr.value.set(0.5, 0.45);
  const wide = innerWidth > 600; $('hint').textContent = COARSE ? 'TAP TO SLASH  -  HAMMER THE GLOWING RUNES' : 'CLICK OR SPACE TO SLASH  -  HAMMER THE GLOWING RUNES';
  if ($('startTxt')) $('startTxt').textContent = COARSE ? 'TAP TO START' : 'CLICK TO START'; // #start is removed after the first tap
}
addEventListener('resize', () => { if (world.hero) layout(); });
// iOS: the toolbar collapse / rotation changes the visual viewport, and the first resize after a rotation can carry stale
// sizes; re-measure on those too (cheap: layout() only resizes when called). A DPR change (window moved to another screen,
// browser zoom) re-applies the native scale.
window.visualViewport?.addEventListener('resize', () => { if (world.hero) layout(); });
addEventListener('orientationchange', () => { for (const ms of [60, 300, 700]) setTimeout(() => { if (world.hero) layout(); }, ms); });
(function watchDpr() { const mq = matchMedia(`(resolution: ${devicePixelRatio}dppx)`); const f = () => { mq.removeEventListener?.('change', f); if (world.hero) layout(); watchDpr(); }; mq.addEventListener?.('change', f); })();

// ---------------- helpers: fx ----------------
const _c = new THREE.Color(), _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _v3 = new THREE.Vector3(), _ray = new THREE.Raycaster();
function toScreen(p, out = { x: 0, y: 0 }) { _v.copy(p).project(camera); out.x = (_v.x * .5 + .5) * W; out.y = (-_v.y * .5 + .5) * Hh; out.z = _v.z; return out; }
function titanPlanePoint(x, y) { // screen -> point on the titan's front plane z=-40
  _ray.setFromCamera({ x: x / W * 2 - 1, y: -(y / Hh) * 2 + 1 }, camera); const o = _ray.ray.origin, d = _ray.ray.direction;
  const t = (-40 - o.z) / d.z; return new THREE.Vector3(o.x + d.x * t, o.y + d.y * t, -40);
}
function flashAt(p, s0, s1, dur, r, g, b, o = {}) {
  const m = world.flashes.find((f) => !f.visible) || world.flashes[0]; m.visible = true; m.position.copy(p); const u = m.userData; u.t = 0; u.dur = dur; u.s0 = s0; u.s1 = s1; u.billboard = true;
  const mu = m.material.uniforms; mu.col.value.setRGB(r, g, b); mu.ring.value = o.ring || 0; mu.vs.value = o.vs || 0; mu.fade.value = 1; m.quaternion.copy(camera.quaternion); m.scale.set(s0, s0, 1);
}
function burst(p, n, speed, kind = 'slash', scale = 1) {
  const cols = kind === 'slash' ? [[1, .8, 1], [.8, .55, 1], [1, .45, .9], [.6, .9, 1]] : kind === 'wp' ? PAL.wp : [[1, .85, .6], [1, .7, .4]];
  for (let i = 0; i < n; i++) {
    const a = rand(0, 6.283), e = rand(-.6, 1.2), sp = speed * rand(.4, 1.2), c = cols[i % cols.length];
    world.sparks.emit(p.x, p.y, p.z + .5, Math.cos(a) * sp, Math.sin(a) * sp * (e > 0 ? 1 : .6) + rand(0, 4), rand(0, sp * .5), rand(.35, .9), rand(.5, 1.3) * scale, c[0], c[1], c[2], rand(2, 9));
  }
}
function debris(p, n, speed) {
  for (let i = 0; i < n; i++) {
    const d = world.dd[world.di]; world.di = (world.di + 1) % world.dd.length;
    d.p.copy(p); d.p.x += rand(-1.5, 1.5); d.p.y += rand(-1.5, 1.5); const a = rand(0, 6.283), sp = speed * rand(.3, 1);
    d.v.set(Math.cos(a) * sp, Math.abs(Math.sin(a)) * sp * .8 + rand(2, 9), rand(2, sp * .8)); d.r.set(rand(0, 6), rand(0, 6), rand(0, 6)); d.w.set(rand(-6, 6), rand(-6, 6), rand(-6, 6)); d.s = rand(.18, .6); d.life = rand(1.6, 3.2);
  }
}
// 11-26 DEV "Titan distance" (user: move the titan closer so the middle ground is used): size multiplier + vertical offset on top of
// the per-titan framing, live from the dev panel (?tsize / ?ty). Bigger + lower = it stands nearer, its feet in the middle ground.
const TQ = new URLSearchParams(location.search);
// 11-26: tz / tsize / ty used to be DEV panel params - their saved values were merged back into the URL on every load (devshim) and
// beat the default. They live in the in-game POS panel now: drop them from the saved dev params and ignore ones the shim added.
{ const added = window.__devShim?.added || []; for (const k of ['tz', 'tsize', 'ty']) if (added.includes(k)) TQ.delete(k);
  try { const d = JSON.parse(localStorage.getItem('tt_dev') || 'null'); if (d && ('tz' in d || 'tsize' in d || 'ty' in d)) { delete d.tz; delete d.tsize; delete d.ty; localStorage.setItem('tt_dev', JSON.stringify(d)); } } catch (e) {} }
const TDEF = TQ.get('style') === 'ink' ? { s: .5, y: 2.5, z: 40 } : { s: 1, y: 0, z: 0 }; // 11-26 user picked (ink): depth 40, size .5, height 2.5
window.__titanPosDef = () => ({ ...TDEF });
let TSIZE = +(TQ.get('tsize') || TDEF.s), TY = TQ.has('ty') ? +TQ.get('ty') : TDEF.y, TZ = TQ.has('tz') ? +TQ.get('tz') : TDEF.z;
try { localStorage.removeItem('tt_titan_pos'); } catch (e) {} // 11-26: old slider saves (before the defaults were set) no longer override them
try { const sv = JSON.parse(localStorage.getItem('tt_titan_pos2') || 'null'); if (sv) { if (!TQ.has('tsize')) TSIZE = +sv.s || TDEF.s; if (!TQ.has('ty')) TY = sv.y != null ? +sv.y : TDEF.y; if (!TQ.has('tz')) TZ = sv.z != null ? +sv.z : TDEF.z; } } catch (e) {} // the in-game TITAN sliders (devpanel.js)
window.__titanPos = () => ({ s: TSIZE, y: TY, z: TZ });
// tz = REAL depth: the titan walks toward the camera (default z -42; +tz = closer). Effects draw on top (depthTest off), hits use its z.
function applyTitanDist() { if (titanGroup) titanGroup.position.z = -42 + TZ; if (world.titanS0 == null) return; world.titanS = world.titanS0 * TSIZE; world.titanY = world.titanY0 + TY; }
window.__setTitanDist = (size, y, z) => { if (size != null) TSIZE = +size || 1; if (y != null) TY = +y || 0; if (z != null) TZ = +z || 0; applyTitanDist(); };
let arcSndT = 0; const ARC_MAX = +(new URLSearchParams(location.search).get('arcmax') || 7);
function hitSound() { const t = performance.now(); if (t - arcSndT > 40) { arcSndT = t; A.sfx('tap', G.chain); } } // one slash hit per strike moment (arcs spawned together / a skill hit + its arc = one sound)
function spawnArc(p, size, rot, flip, dur, kind = 'arc', col) {
  // 11-26 user: "slash hit is every time you draw that slash" - one 'tap' per drawn slash (arcs spawned together = one sound)
  // ('light' arcs = the ghost slashers / skill light streaks: no sound - 11-26 "weird auto slash" was the ghosts' arcs playing slash hit)
  if (kind !== 'light') hitSound();
  // size = arc length in screen pixels -> world units at the arc's depth
  const light = kind === 'light', pool = light ? world.larcs : world.arcs;
  // 11-26 perf (FPS 5 at a x247 combo, slash size .8): every arc is a big screen quad + a full-screen distortion copy, and fast
  // taps filled all 24 -> GPU overdraw. Budget: at most ARC_MAX painted arcs alive (the oldest ends early), size capped at 1.2x
  // the short screen side, and only every 2nd arc drives the distortion.
  if (!light) { let alive = 0, old = null; for (const a of pool) if (a.visible) { alive++; if (!old || a.userData.t / a.userData.dur > old.userData.t / old.userData.dur) old = a; }
    for (; alive >= ARC_MAX && old; alive--) { old.visible = false; old.userData.t = old.userData.dur; const d = world.darcs[pool.indexOf(old)]; if (d) d.visible = false;
      old = null; for (const a of pool) if (a.visible && (!old || a.userData.t / a.userData.dur > old.userData.t / old.userData.dur)) old = a; }
    size = Math.min(size, Math.min(W, Hh) * 1.2); }
  const m = light ? pool[world.larcI = ((world.larcI || 0) + 1) % pool.length] : pool[world.arcI = ((world.arcI || 0) + 1) % pool.length]; m.visible = true;
  const u = m.userData; u.t = 0; u.dur = dur; u.amp = 1; u.warp = light ? 1 : 0; /* 11-26 user: distortion only on the top hits - normal tap arcs never warp; superSlash / big / skill arcs set warp 1 */ m.position.copy(p); m.quaternion.copy(camera.quaternion); m.rotateZ(rot);
  const wsz = pxToWorld(size, p), mu = m.material.uniforms;
  if (mu.map) { const img = mu.map.value.image, asp = img.width / img.height; const h = wsz / Math.max(1, asp); m.scale.set(h * asp * (flip ? -1 : 1), h, 1); mu.dir.value = Math.random() < .5 ? 1 : -1;
    EQ.arcTint(mu.tint.value, Math.random()); if (G.state === 'fight') CFX.arcTier(mu.tint.value, G.chain); } // the equipped blade colours the arcs (frost cyan, ember orange ...)
  else m.scale.set(wsz * (flip ? -1 : 1), wsz * 1.4, 1);
  if (mu.boost) mu.boost.value = 1.05; // superSlash raises it
  if (light) { m.scale.set(wsz * (flip ? -1 : 1), wsz * .5, 1); mu.c1.value.setRGB(.62, .42, 1); mu.c2.value.setRGB(1, 1, 1); mu.bend.value = rand(.3, .55); }
  return m;
}
function shake(a) { CAM.shake = Math.max(CAM.shake, a); }
function shock(p, size, dur = .3, amp = 1) { // radial refraction ring (distortion buffer only)
  if (NODIST) return; const m = world.shocks.find((s) => !s.visible) || world.shocks[0]; m.visible = true; m.position.copy(p); m.quaternion.copy(camera.quaternion);
  m.userData.t = 0; m.userData.dur = dur; m.scale.set(size, size, 1); m.material.uniforms.amp.value = amp;
}

// ---------------- numbers ----------------
// user 11-25: "damage is flying from nowhere". Every number is placed EXACTLY at the slash centre (= the tap point, or the rune it
// snapped to), positioned before it is shown (no stale frame at 0,0), then just rises ~40 px over 0.7 s (ease-out) and fades.
// No random offsets, no following a moving bone, no travelling.
// 11-26 perf (user: "apply reusing of text, or maybe use an image instead"): every number is drawn by numfx.js in WebGL (bitmap
// Anton atlas, one instanced draw call after the post chain). No DOM nodes, no per-hit layout (the old `void el.offsetWidth`
// restart forced a full style + layout per hit), no CSS animation. Same looks, timings and positions as the old CSS.
const NFX = new NumFX();
const shots = []; let shotI = 0; // one-shot numbers (old .dmg): x? crit counters, ghost numbers
// user 11-26: "move the dmg a bit up, it's covered by my hands" - numbers spawn this many CSS px above the tap on touch screens
const NUM_UP = () => (COARSE ? 72 : 18);
// user 11-26: "maybe my slashes are too big" - global slash size factor (?slash=0.8 to try other sizes)
const SLASH_K = +(new URLSearchParams(location.search).get('slash') || .8); // 11-26 user: slash size .8 (was .5)
// 11-27 user: slashes scale WITH the hero - at the approved hero size (1.47 portrait / 1.34 landscape) they are exactly SLASH_K
const HERO_SCALE = 1.8 / 1.47; // 11-27 user: try hero 1.8 (was 1.47); slashes follow via slashK()
const HERO_H0 = () => (portrait ? 1.47 : 1.34);
const slashK = () => SLASH_K * (world.heroH || HERO_H0()) / HERO_H0();
// old CSS classes -> numfx style + font px (style.css .dmg.*)
function shotStyle(cls) { const c = String(cls || ''), gc = /gc(\d)/.exec(c);
  if (c.includes('gsn')) return { st: 'gc' + (gc ? gc[1] % 4 : 0), px: c.includes('big') ? 21 : 15, ghost: false };
  if (c.includes('ghost')) return { st: 'ghost', px: 17, ghost: true };
  return c.includes('crit') ? { st: 'crit', px: 24 } : c.includes('wp') ? { st: 'wpD', px: 21 } : c.includes('fin') ? { st: 'fin', px: 22 } : c.includes('slash') ? { st: 'slashD', px: 19 } : c.includes('train') ? { st: 'trainD', px: 16 } : { st: 'tap', px: 18 }; }
// 11-26 TIDY NUMBERS (user: the numbers buried the titan): small one-shots (x10! milestones, taps during a limit break, ghosts) are
// small, live 0.4 s, get a little horizontal jitter, and at most SHOT_MAX are alive (the oldest is culled for a new one).
const SHOT_MAX = 6, SHOT_S = .4;
function number(p, text, cls) {
  const s = toScreen(p); let o = shots.find((q) => !q.on);
  if (!o) o = shots.length < SHOT_MAX ? (shots[shots.length] = {}) : shots.reduce((a, b) => (a.t >= b.t ? a : b));
  Object.assign(o, shotStyle(cls), { text: String(text), x: s.x + rand(-16, 16), y: s.y - NUM_UP() + rand(-4, 4), t: 0, on: true });
}
function drawShots(dt) {
  for (const o of shots) { if (!o || !o.on) continue; o.t += dt;
    if (o.ghost) { const k = o.t / .6; if (k >= 1) { o.on = false; continue; } const e = 1 - Math.pow(1 - k, 2); NFX.text(o.text, o.x, o.y - 22 * e, o.px, o.st, .75 * (1 - e)); continue; } // old dmgG (ease-out)
    const k = o.t / SHOT_S; if (k >= 1) { o.on = false; continue; } // pop 1.15 -> 1, rise ~24 px (ease-out), fade after 40%
    const y = -24 * (1 - Math.pow(1 - k, 3)), sc = k < .15 ? 1.15 - .15 * (k / .15) : 1;
    NFX.text(o.text, o.x, o.y + y, o.px, o.st, k < .4 ? 1 : 1 - (k - .4) / .6, sc); }
}

// merged damage number (readable while hammering). 11-26 TIDY NUMBERS: only ONE big running number at a time (the current hit
// area: 'wp' or 'body'; crits no longer fork a gold group, they flash it gold). It glides to the LATEST hit point, counts up to the
// running total, pulses on every add, and rises + fades once the hits stop; when the area changes the old one makes way (0.2 s
// fade). The only other big number is the limit-break total (limNum), shown once at the end of a limit near the titan's chest.
const NUM_GAP = .45, NUM_RISE = .7, NUM_PX = 40; let numCur = null, numOld = null, limNum = null;
const NUM_SZ = { slash: 30, wp: 32, crit: 34, fin: 40, train: 24 }; // font px (crit = the gold flash on the running number)
function dmgNum(p, amt, cls, key) {
  const now = performance.now() / 1000; let g = numCur;
  if (!g || now - g.last > NUM_GAP || g.key !== key) {
    if (g && now - g.last <= NUM_RISE) { g.out = now; numOld = g; } // the previous number makes way (fast fade)
    g = numCur = { total: 0, shown: 0, last: now, hits: 0, key, x: 0, y: 0, tx: 0, ty: 0, st: NUM_SZ[cls] && cls !== 'crit' ? cls : 'slash', s: 1, popT: 9, critT: 9, txt: '' };
  }
  const sp = toScreen(p); g.tx = sp.x; g.ty = sp.y - NUM_UP(); // just above the latest hit (user 11-26: the finger covered it)
  if (!g.hits) { g.x = g.tx; g.y = g.ty; }
  g.total += amt; g.hits++; g.last = now; if (g.hits === 1) g.shown = g.total; // never an empty / '0' first frame
  if (cls === 'crit') g.critT = 0;
  g.popT = 0; g.s = 1 + Math.min(.22, Math.log10(1 + g.hits) * .14); // pulse (1.3x -> 1x over 0.22 s, ease-out)
}
function placeNum(g, now, dt) {
  const k = 1 - Math.exp(-dt * 16); g.x += (g.tx - g.x) * k; g.y += (g.ty - g.y) * k; // glide, never jump
  const st = g.critT < .3 ? 'crit' : g.st, u = clamp((now - g.last) / NUM_RISE, 0, 1), rise = NUM_PX * (1 - Math.pow(1 - u, 3)), px = NUM_SZ[st] * g.s, hw = Math.min(W * .45, NFX.width(g.txt, px) / 2 + 4);
  const pop = g.popT < .22 ? 1 + .3 * Math.pow(1 - g.popT / .22, 2) : 1, out = g.out ? clamp(1 - (now - g.out) / .2, 0, 1) : 1;
  NFX.text(g.txt, clamp(g.x, hw, W - hw), g.y - rise, NUM_SZ[st], st, (u < .45 ? 1 : 1 - (u - .45) / .55) * out, g.s * pop);
}
function tickNum(g, now, dt) {
  g.shown = g.shown + (g.total - g.shown) * (1 - Math.exp(-dt * 18)); if (g.total - g.shown < 1) g.shown = g.total;
  g.popT += dt; g.critT += dt; const r = Math.round(g.shown); if (r !== g.r) { g.r = r; g.txt = fmt(r); } placeNum(g, now, dt);
}
// limit-break total: one big number near the titan's chest at the end of the limit (pop in, hold, rise + fade, 1.5 s)
function showLimTotal() {
  const d = S.limTot || 0; S.limTot = 0; if (d <= 0) return;
  // 11-26 user: the total appears where the LAST slash of the skill landed and floats up (it was a random chest point)
  const p = S.limP || (world.dummy?.present && (titanState.sink || 0) > .5 ? world.dummy.centerWorld() : socketCenter()), s = toScreen(p); S.limP = null;
  limNum = { txt: fmt(Math.round(d)), x: s.x, y: clamp(s.y - NUM_UP() * .3, Hh * .12, Hh * .85), t: 0 };
}
function drawLimNum(dt) {
  const g = limNum; if (!g) return; g.t += dt; if (g.t >= 1.5) { limNum = null; return; }
  const px = 48, sc = g.t < .18 ? 1.5 - .5 * (1 - Math.pow(1 - g.t / .18, 2)) : 1, hw = Math.min(W * .48, NFX.width(g.txt, px * sc) / 2 + 6);
  const rise = 70 * (1 - Math.pow(1 - g.t / 1.5, 2)), a = g.t > .9 ? 1 - (g.t - .9) / .6 : 1; // floats up the whole time (ease-out), fades at the end
  NFX.text(g.txt, clamp(g.x, hw, W - hw), g.y - rise, px, 'fin', a, sc);
}
function updateNums(dt) {
  const now = performance.now() / 1000;
  if (numOld) { if (now - numOld.out > .2) numOld = null; else tickNum(numOld, now, dt); }
  if (numCur) { if (now - numCur.last > NUM_RISE) numCur = null; else tickNum(numCur, now, dt); }
  drawLimNum(dt); drawShots(dt);
}

// ---------------- damage ----------------
function multiplier() { let m = 1; if (G.state === 'fight') { if (G.buffT > 0) m *= 1.5; } return m; } // 11-26: no phase multipliers (armor / cracked / enrage removed)
function damage(base, kind, p, key, follow) {
  const training = G.state !== 'fight';
  let crit = Math.random() < critCh(); let d = base * (crit ? EQ.S.critMul : 1); const m = multiplier(); d *= m;
  if (crit) EQ.eyeFlare(1.6); // ink hero: eyes flare on a crit (inkhero.js; no-op otherwise)
  if (G.inLim && kind !== 'wp' && p) hurtHit(null, kind === 'fin' ? 'fin' : crit ? 'crit' : 'tap', null, null); // limit / finisher blows: whole-body flash + red pulse
  if (training && G.state === 'lobby') { G.practice = (G.practice || 0) + d; $('hud').classList.add('hit'); } // small practice counter, shown after the first hit
  if (!training && (!TB.ON || TB.counts())) { G.critRun = crit ? (G.critRun || 0) + 1 : 0; if (G.critRun >= 3) { G.critRun = 0; pop('CRITICAL!', 'x3 CHAIN', 2); } scoreNews(G.score, G.score + d); G.score += d; if (G.shield > 0 && kind !== 'tap') hurtShield(base * (kind === 'wp' ? 1 : .15)); else if (G.shield > 0) hurtShield(base * .06);
    if (TB.ON) TB.check(G.score); } // time board: nothing counts after the kill / past the limit; HP gone = kill, timed at this hit
  // 11-26 DYNAMIC HIT SOUNDS (user): the sound follows the hit size vs a regular tap (running average of non-crit taps):
  // 2x+ = crit hit, 4x+ = ultra crit (user 11-26; was 5x) (usually a skill's last slash). Slash hit itself comes from every drawn arc (spawnArc).
  // Weak points are left out (always 4-35x, they have their own 'weak' sound). Debug: window.__dmgLog = [] records [kind, inLimit, ratio].
  if (kind === 'hop' && !crit) G.dmgRef = G.dmgRef ? G.dmgRef * .8 + d * .2 : d;
  if (kind !== 'wp') { const r = d / (G.dmgRef || 120); if (window.__dmgLog) window.__dmgLog.push([kind, G.inLim ? 1 : 0, +r.toFixed(2)]); if (G.finHit || (!G.inLim && r >= 4)) A.sfx('ultracrit'); else if (crit || (!G.inLim && r >= 2)) A.sfx('crit', G.chain); } /* 11-26: skill strikes are all 2x+ - only a real crit or the skill's last hit get the loud sounds there (21 stacked crits flattened the music) */ G.finHit = false; /* finHit = a skill's last hit: always ultra */ // a real crit (5%, 2x) always sounds as a crit
  const cls = training ? 'train' : crit ? 'crit' : kind === 'wp' ? 'wp' : kind === 'fin' ? 'fin' : 'slash';
  // 11-26 TIDY NUMBERS: limit-break hits add up silently (one total at the end, showLimTotal); taps during a limit get small
  // one-shot numbers at the tap point; otherwise one running number per area ('wp' / 'body' / 'fin' / the dummy)
  if (G.inLim) { S.limTot = (S.limTot || 0) + d; if (p) (S.limP || (S.limP = new THREE.Vector3())).copy(p); return crit; } // limP = the latest skill hit (the total rises from there)
  if (S.on) { number(p, fmt(Math.round(d)), cls); return crit; }
  const k = String(key || kind); dmgNum(p, d, cls, k.startsWith('wp') ? 'wp' : k.startsWith('b') ? 'body' : k);
  return crit;
}
function hurtShield(x) {
  G.shield -= x; world.shield.material.uniforms.hit.value = 1;
  if (G.shield <= 0) { G.shield = 0; G.stun = 6; A.sfx('shieldBreak'); pop('ARMOR CRACKED', 'DAMAGE x2', 2); shake(.7); burst(new THREE.Vector3(0, 20, -38), 90, 38, 'wp', 1.6); flash([.5, .9, 1], .12); titanState.act = null; startAttack(Math.random() < .5 ? 'slamL' : 'slamR'); titanState.hit = 1.5; shock(_v.set(0, 22, -38), 70, .55, 1); }
}

// ---------------- weak points ----------------
// Each weak point sits on ONE bone socket for WEAK_S seconds (rides the body animation, never jumps), shows a countdown
// ring, can be hammered any number of times (escalating counter / flashes / pitch), then fades and a new one appears elsewhere.
function socketWorld(i, out) { const s = titanState.sockets[i % titanState.sockets.length]; puppet.point(s.bone, s.x, s.y, out); titanGroup.localToWorld(out); return out; }
const WP_COUNT = new URLSearchParams(location.search).get('wpcount') === '1'; // 11-26 user: the x-hits counter on the weak point is off (?wpcount=1 shows it)
function wpWanted() { return G.state === 'fight' ? (G.phase === 2 ? 2 : 1) : 1; }
// 11-26 user: the weak point keeps the SAME screen size whatever the titan's depth (Z slider): world size x (its distance / the default distance)
function wpBase() { const cz = camera.position.z, dk = titanGroup ? Math.max(.08, (cz - titanGroup.position.z) / (cz + 42)) : 1;
  return (portrait ? 9.5 : 6.8) * 1.5 * (G.phase === 2 && G.state === 'fight' ? 1.2 : 1) * dk; } // x1.5 (user 11-26: too small next to the close titan)
function updateWPs(dt) {
  const want = G.retreat > 0 || G.state !== 'fight' || G.rise < RISE_S ? 0 : wpWanted(), rageK = G.phase === 2 && G.state === 'fight' ? 1 : 0;
  let active = world.wps.filter((w) => w.on).length;
  for (const w of world.wps) {
    if (!w.on) { w.cool -= dt; if (w.cool <= 0 && active < want && titanState.sockets.length) {
      w.on = true; active++; w.state = 'live'; w.m.visible = true; w.life = 0; w.hits = 0; w.kick = 0; w.pop = 0; w.dmg = 0; w.hpMax = 0;
      const used = world.wps.filter((x) => x.on && x !== w).map((x) => x.sock); let opts = titanState.sockets.map((_, i) => i).filter((i) => !used.includes(i) && i !== w.sock && titanState.sockets[i].weak !== false && (!world.weak || world.weak.includes(titanState.sockets[i].id))); // titan.json "weak" (e.g. one per head)
      // 11-26 user: "the weakness circle must be part of the titan": only spots that are ON his body right now - above the water line
      // (the closer titan has belt / fists under the water), really covered by a body part at that screen point, never a floating rock
      { const ha = G.hitArea, hr = G.hitRig, hp_ = G.hitPart, onBody = opts.filter((i) => { const sk = titanState.sockets[i]; if (/^rock/.test(sk.id || sk.bone || '')) return false;
          const wp = socketWorld(i, _v3); if (wp.y < -.8 + 1.5) return false; const sp = toScreen(wp); return !!bodyAt(sp.x, sp.y); });
        G.hitArea = ha; G.hitRig = hr; G.hitPart = hp_; if (onBody.length) opts = onBody; }
      const clear = opts.filter((i) => { const sp = toScreen(socketWorld(i, _v3)); return sp.y > Hh * (portrait ? .26 : .18) && sp.y < Hh * .78 && sp.x > W * (portrait ? .2 : .15) && sp.x < W * (portrait ? .8 : .85); }); if (clear.length) opts = clear; // not under the HUD
      w.sock = opts.length ? opts[Math.floor(Math.random() * opts.length)] : 0; socketWorld(w.sock, w.pos);
      flashAt(w.pos, 2, wpBase() * 1.6, .35, .4, 1, 1, { ring: .95 }); A.sfx('ready');
    } else { w.label.style.opacity = 0; continue; } }
    w.life += dt; w.pop = Math.min(1, w.pop + dt * 5); w.kick = Math.max(0, w.kick - dt * 5);
    if (G.retreat > 0 && w.state === 'live') { w.state = 'fade'; w.life = WEAK_S; }
    if (w.state === 'live' && w.life >= WEAK_S) { w.state = 'fade'; } // timed out unbroken: it just fades (11-26: breaking happens on the hit, see runeBreak)
    const fade = w.state === 'fade' ? clamp(1 - (w.life - WEAK_S) / .5, 0, 1) : 1;
    if (w.state === 'fade' && fade <= 0) { w.on = false; w.m.visible = false; w.cool = .45; active--; w.label.style.opacity = 0; continue; }
    socketWorld(w.sock, w.pos);
    w.size = wpBase() * (1 + Math.sin(w.life * 7) * .04) * (1 + w.kick * .3) * (.3 + .7 * w.pop) * (w.state === 'fade' ? 1 + (1 - fade) * .6 : 1);
    w.m.position.copy(w.pos); w.m.position.z += 1.5 * clamp((camera.position.z - titanGroup.position.z) / (camera.position.z + 42), .1, 1); // depth-scaled lift (a close titan + a full 1.5 pulled it off its spot) w.m.quaternion.copy(camera.quaternion); w.m.rotateZ(w.life * (rageK ? 1.2 : .5)); w.m.scale.set(w.size, w.size, 1);
    const mu = w.m.material.uniforms; mu.flash.value = w.kick * (.5 + Math.min(w.hits, 30) * .04); mu.k.value = fade * (1 + Math.min(w.hits, 30) * .02);
    mu.left.value = clamp(1 - (w.dmg || 0) / runeHp(w), 0, 1); /* HP left */ mu.col.value.setRGB(rageK ? 1 : .3, rageK ? .55 : .95, rageK ? .7 : 1);
    // hit counter: small, pinned at a fixed spot on the ring's upper-right rim (11-26 TIDY NUMBERS: never on the damage number,
    // which sits above the tap); flips to the upper-left near the right screen edge
    if (WP_COUNT && w.hits > 0) { const s = toScreen(w.pos), px = 17 + Math.min(w.hits, 40) * .12, r = wpPx(w) * .5; if (w.txN !== w.hits) { w.txN = w.hits; w.tx = 'x' + w.hits; } // 11-26 perf: WebGL text (numfx.js), the DOM label stays hidden
      const hw = NFX.width(w.tx, px) / 2, side = s.x + r * .8 + hw * 2 > W - 4 ? -1 : 1;
      NFX.text(w.tx, s.x + side * (r * .8 + hw), s.y - r * .62, px, 'wpc', fade, 1 + w.kick * .25); }
  }
}
function wpPx(w) { const s = toScreen(w.pos), e = toScreen(_v2.copy(w.pos).add(_v.set(w.size * .5, 0, 0).applyQuaternion(camera.quaternion)), { x: 0, y: 0 }); return Math.hypot(e.x - s.x, e.y - s.y) * 2; }
function wpAt(sx, sy) { // nearest weak point under a screen position (generous on phones)
  let best = null, bd = 1e9;
  for (const w of world.wps) {
    if (!w.on || w.state === 'fade') continue; const s = toScreen(w.pos);
    const r = Math.max(COARSE ? 60 : 44, wpPx(w) * .62), d = Math.hypot(sx - s.x, sy - s.y);
    if (d < r && d < bd) { bd = d; best = w; }
  } return best;
}
// 11-26 user: a rune has HEALTH - the hit that brings it to RUNE_HP hits breaks it right away (shatter + pop out), not when its timer ends
// v2 (user: "HP based, not x hits"): HP = RUNE_HP x a plain rune hit (no combo, no crit) at the moment it appears - combo, crits and the
// weak-point gear stat (EQ.S.wp) break it faster. The ring shows the HP left (it used to show the time left).
const RUNE_HP = +(new URLSearchParams(location.search).get('runehp') || 10);
const runeHp = (w) => w.hpMax || (w.hpMax = RUNE_HP * 100 * tapPow() * EQ.S.wp * 4.25);
function runeBreak(w) { if (w.state !== 'live') return; w.state = 'fade'; w.life = WEAK_S; if (G.state !== 'fight') return;
  G.wpBroken = (G.wpBroken || 0) + 1; pop('RUNE BROKEN', 'x' + w.hits, 1); A.sfx('rune'); A.voice('rune'); burst(w.pos, 40, 34, 'wp', 1.4); flashAt(w.pos, 2, wpBase() * 2.4, .4, .4, 1, 1, { ring: .95 }); shock(w.pos, wpBase() * 3, .4, .9); shake(.6); /* 11-26 user: no phantom slash when a rune breaks (was superSlash) - a rune shatter burst instead */ if (!AT.on && (!titanState.act || titanState.act === 'idle')) { startAct('roar'); A.sfx('roar'); shake(.6); }
}
function wpHit(w, mult = 1, at = null) { // at = where the slash landed (number goes there)
  w.hits++; w.kick = 1; G.wpHits++; const h = Math.min(w.hits, 40);

  const base = 100 * tapPow() * EQ.S.wp * (4 + h * .25) * (1 + G.chain * comboG()) * mult;
  { const crit = damage(base, 'wp', at || w.pos, 'wp' + world.wps.indexOf(w)); w.dmg = (w.dmg || 0) + base * (crit ? EQ.S.critMul : 1) * multiplier(); } // rune HP takes the real hit
  if (G.shield > 0) hurtShield(base * 1.2);
  if (w.state === 'live' && w.dmg >= runeHp(w)) setTimeout(() => runeBreak(w), 0); // HP gone -> it breaks on this hit (after the fx below)
  burst(w.pos, 12 + Math.round(h * .4), 26 + h * .5, 'wp', 1 + h * .015); flashAt(w.pos, 1, wpBase() * (.8 + h * .02), .16, .3, .8, .9);
  shock(w.pos, wpBase() * (2.2 + h * .03), .32, .8);
  if (w.hits % 10 === 0) { flashAt(w.pos, 3, wpBase() * 3.2, .45, .6, 1, 1, { ring: .95 }); G.hitstop = Math.max(G.hitstop, .03); if (WP_COUNT) number(at || w.pos, `x${w.hits}!`, 'crit'); shock(w.pos, wpBase() * 5, .5, 1); }
  { const sb = titanState.sockets[w.sock % titanState.sockets.length]?.bone; // the hammered rune flares (only on its own bone's parts)
    if (sb) { const fk = Math.min(2.6, 1.1 + w.hits * .04) * (w.hits % 10 === 0 ? 1.6 : 1); puppet.glowKick('b', fk, 4, sb); puppet.glowKick('r', fk * .6, 5, sb); } }
  A.sfx('weak', w.hits); buzz(12); titanState.hit = 1; titanState.flinch = Math.min(1.2, titanState.flinch + .35); titanState.flinchDir = (w.pos.x > 0 ? -1 : 1);
  const sk = titanState.sockets[w.sock], wrig = sk ? { bone: sk.bone, ...(({ x, y }) => ({ x, y }))(puppet.point(sk.bone, sk.x + (Math.random() - .5) * 40, sk.y, _hp)) } : null;
  world.anim.flinch(sk ? sk.area : 'chest', w.pos.x > 0 ? -1 : 1, .35 + (w.hits % 10 === 0 ? .6 : 0), wrig);
  if (!G.inLim) { const x10 = w.hits % 10 === 0; hurtHit(wrig ? puppet.hit(wrig.x, wrig.y) || puppet.parts.find((q) => q.pt.bone === sk.bone) : null, x10 ? 'wp10' : 'wp', wrig, null);
    if (HURT_ON && !S.on) G.hitstop = Math.max(G.hitstop, x10 ? .06 : .028); } // 11-27: weak-point blows land heavier (x10 milestone longest)
  return base;
}

// ---------------- every tap = an omni-slash hop ----------------
// The hero blinks out (flash + afterimage), a streak connects old and new spot, he reappears big and in view on a new side
// of the target (left / right / above / low ...), holds a strike pose, and painted slash arcs cross the target.
const SPOTS = [[-1, -.15], [1, -.1], [0, -1], [-.8, .55], [.8, .55], [-.75, -.8], [.75, -.8], [0, .85]]; // screen dirs (y down)
const POSE_FACE = [1, 1, 1, -1, 1]; // natural facing of hs, pose1..4 (+1 = faces right)
function comboK() { return clamp(G.chain / 60, 0, 1); }
// ONE character scale for every hero sprite (user 11-25: no pop / rescale between idle and attack). TEXK = how many idle-art
// texels one texel of that sprite is worth (measured from head size: the pose sheet was painted ~2.75x smaller than idle;
// hero_land.webp was saved at 1000/1013 of its raw). Sprite height = texture height * TEXK * charPx (idle px per texel).
const TEXK = new Map();
function texK(tex) { return TEXK.get(tex) || 1; }
function charPx() { return world.heroH / pxToWorld(1, homeCenter(_hc)) / T.hi.image.height; } // on-screen px per idle texel
const _hc = new THREE.Vector3();
function spritePx(tex) { return charPx() * tex.image.height * texK(tex); }
function screenToPlane(x, y, z, out = new THREE.Vector3()) { _ray.setFromCamera({ x: x / W * 2 - 1, y: -(y / Hh) * 2 + 1 }, camera); const o = _ray.ray.origin, d = _ray.ray.direction; const t = (z - o.z) / d.z; return out.set(o.x + d.x * t, o.y + d.y * t, z); }
const _fw = new THREE.Vector3(), _fd = new THREE.Vector3();
function pxToWorld(px, p) { camera.getWorldDirection(_fw); const d = Math.max(.5, _fw.dot(_fd.copy(p).sub(camera.position))); return /* view depth, matches the projection */ px / Hh * 2 * d * Math.tan(camera.fov * Math.PI / 360); }
// SLASH ROTATION (unchanged from the side-bag version, user 11-25: keep the attack exactly as before): the 8 SPOTS are drawn
// from a shuffled bag, off-screen sides skipped, and the arc is rotated along that side -> tap point, as when the hero stood there.
function slashRot(ts) {
  const R = Math.min(W, Hh) * (portrait ? .16 : .14);
  const place = (k) => { const pi = k === 2 || k === 5 || k === 6 ? 3 : k === 3 || k === 4 || k === 7 ? (Math.random() < .5 ? 1 : 0) : (Math.random() < .5 ? 2 : 4);
    const tex = T.poses[pi] || T.hs, asp = tex.image.width / tex.image.height, hp = spritePx(tex), hw = hp * asp, [dx, dy] = SPOTS[k];
    const cx = ts.x + dx * (hw * .5 + R * .35), cy = ts.y + dy * (hp * .5 + R * .25);
    const mx = hw * .45, top = hp * .5 + (portrait ? 70 : 50), bot = Hh - hp * .5 - (portrait ? 70 : 60);
    let bad = Math.max(0, mx - cx) + Math.max(0, cx - (W - mx)) + Math.max(0, top - cy) + Math.max(0, cy - bot);
    for (const g of world.gs || []) if (g.m.visible) { const q = toScreen(_v.copy(g.m.position).setY(g.m.position.y + Math.abs(g.m.scale.y) * .5), {}); if (Math.hypot(q.x - cx, q.y - cy) < hw * .7) bad += 40; }
    return { k, cx, cy, bad, mx, top, bot }; };
  if (!S.bag || !S.bag.length) S.bag = SPOTS.map((_, i) => i).sort(() => Math.random() - .5);
  let pick = null, best = null;
  for (let tries = 0; tries < S.bag.length; tries++) { const k = S.bag.shift(); const c = place(k);
    if (c.bad <= 0 && !(k === S.lastSpot && k === S.lastSpot2)) { pick = c; break; } S.bag.push(k); if (!best || c.bad < best.bad) best = c; }
  if (!pick) { pick = best; S.bag = S.bag.filter((k) => k !== best.k); }
  S.lastSpot2 = S.lastSpot; S.lastSpot = pick.k;
  const cx = clamp(pick.cx, pick.mx, W - pick.mx), cy = clamp(pick.cy, pick.top, Math.max(pick.top, pick.bot));
  return Math.atan2(-(ts.y - cy), ts.x - cx) + Math.PI / 2;
}
function hop(target, o = {}) { // target: world point on the titan; o.big (finisher), o.wp
  if (world.ret) cancelReturn(); // tapping mid-return: teleport straight away
  const hero = world.hero, ts = toScreen(target);
  // RANDOM LANDING (user 11-25: "where he lands, I want it to be random"): a random point anywhere in the playable area - sprite
  // fully on screen and out of the HUD bands, not covering the tap point, >= 15% of the short side from the tap (so the slash
  // reads; no maximum) and >= 10% away from the previous 2 landings (never looks repeated). No 8-direction pattern.
  // (Old bug: the side bag offset him only ~half a sprite + 0.35R from the tap, so with the smaller hero every landing hugged the
  // tap point, and near the edges most sides failed the check and it fell back to the same 'least bad' side.)
  // SPOTS is now only used to choose a strike pose from the travel direction (tap -> hero).
  const S0 = Math.min(W, Hh), padX = 6, minD = S0 * .15, sepD = S0 * .1, prev = S.landHist || [];
  const lb = null; // 11-26 perf: the #live board is hidden for good (menu.css); its getBoundingClientRect here forced a full layout on EVERY tap
  const poseFor = (dx, dy) => { let k = 0, bd = -9; const l = Math.hypot(dx, dy) || 1;
    SPOTS.forEach(([sx, sy], i) => { const d = (sx * dx + sy * dy) / l / Math.hypot(sx, sy); if (d > bd) { bd = d; k = i; } });
    return { k, pi: k === 2 || k === 5 || k === 6 ? 3 : k === 3 || k === 4 || k === 7 ? (Math.random() < .5 ? 1 : 0) : (Math.random() < .5 ? 2 : 4) }; };
  // user 11-25: "character is too far" - random, but NEAR the slash: a random angle and a random distance in a ring around the tap
  // point (maxD), not anywhere on screen. The full-screen sample is only a fallback when the ring has no valid spot (tap in a corner).
  // user 11-25 (2): "the stupid slash in the air, too far" - he must land within sword reach so the strike connects with the slash.
  // Ring = his reach (from the idle sprite size), random angle only; landing spots still vary around the tap.
  const reach = spritePx(T.hs) * .55, minR = reach * .7, maxD = reach * 1.05; // user 11-25: "the attack is correct now" - keep this
  const place = (u, v, ring = true) => { // ring: u = angle, v = distance minD..maxD around the tap; else u, v in 0..1 over the area
    const hp0 = spritePx(T.poses[3] || T.hs), top = hp0 * .5 + (portrait ? 96 : 80), bot = Hh - hp0 * .5 - (portrait ? 64 : 56);
    let cx, cy;
    if (ring) { const a = u * Math.PI * 2, r = minR + v * (maxD - minR); cx = ts.x + Math.cos(a) * r; cy = ts.y + Math.sin(a) * r; }
    else { cx = padX + u * (W - 2 * padX); cy = top + v * Math.max(0, bot - top); }
    const { k, pi } = poseFor(cx - ts.x, cy - ts.y), tex = T.poses[pi] || T.hs, asp = tex.image.width / tex.image.height, hp = spritePx(tex), hw = hp * asp;
    const mx = hw * .5 + padX, t2 = hp * .5 + (portrait ? 96 : 80), b2 = Hh - hp * .5 - (portrait ? 64 : 56); // fully on screen, out of the HUD bands (phone 430x900: top HUD to ~95 px, combo meter from ~842 px)
    cx = clamp(cx, mx, W - mx); cy = clamp(cy, t2, Math.max(t2, b2));
    const d = Math.hypot(cx - ts.x, cy - ts.y), covers = Math.abs(cx - ts.x) < hw * .42 && Math.abs(cy - ts.y) < hp * .42;
    let bad = Math.max(0, minR * .8 - d) + (covers && d < minR * .5 ? 30 : 0);
    for (const p of prev) bad += Math.max(0, Math.min(sepD, reach * .6) - Math.hypot(p.x - cx, p.y - cy));
    if (lb && cx + hw * .3 > lb.left && cx - hw * .3 < lb.right && cy + hp * .3 > lb.top && cy - hp * .3 < lb.bottom) bad += 20; // not on the LIVE board
    for (const g of world.gs || []) if (g.m.visible) { const q = toScreen(_v.copy(g.m.position).setY(g.m.position.y + Math.abs(g.m.scale.y) * .5), {}); if (Math.hypot(q.x - cx, q.y - cy) < hw * .7) bad += 40; }
    return { k, pi, tex, asp, hp, hw, cx, cy, bad, mx, top: t2, bot: b2 }; };
  let pick = null, best = null;
  for (let j = 0; j < 60 && !pick; j++) { const ring = j < 40, c = place(Math.random(), Math.random(), ring); const far = ring ? 0 : Math.max(0, Math.hypot(c.cx - ts.x, c.cy - ts.y) - maxD) * .5; c.bad += far; if (c.bad <= 0) pick = c; else if (!best || c.bad < best.bad) best = c; }
  if (!pick) pick = best; // tiny screens only: the least-bad random sample
  S.landHist = [{ x: pick.cx, y: pick.cy }, ...prev].slice(0, 2); S.landK = pick.k;
  S.lastLand = { tx: ts.x, ty: ts.y, x: clamp(pick.cx, pick.mx, W - pick.mx), y: clamp(pick.cy, pick.top, Math.max(pick.top, pick.bot)), w: pick.hw, h: pick.hp }; // debug / scripted checks
  const { pi, tex, asp, hp } = pick, cx = clamp(pick.cx, pick.mx, W - pick.mx), cy = clamp(pick.cy, pick.top, Math.max(pick.top, pick.bot));
  o.rot = slashRot(ts); // user 11-25: "the attack should be what it was before" - slash rotation unchanged, independent of the landing
  const z = -30, c = screenToPlane(cx, cy, z), h = pxToWorld(hp, c);
  // departure: burst + clone at the old spot
  const old = _v3.copy(hero.position).setY(hero.position.y + (hero.userData.h || world.heroH) * .5), oldH = hero.userData.h || world.heroH;
  dropClone(hero, o.big ? 1 : .65);
  flashAt(old, 1.5, (hero.userData.h || world.heroH) * .6, .2, .7, .45, 1); if (o.big) flashAt(old, 1, (hero.userData.h || world.heroH) * .8, .18, .5, .35, .9, { vs: 1 }); // the vertical light pillar only on the finisher
  for (let i = 0; i < 10; i++) world.sparks.emit(old.x + rand(-1, 1), old.y + rand(-2, 2), old.z, rand(-6, 6), rand(-6, 6), rand(-2, 2), .4, 1.2, .8, .6, 1, 0);
  // streak connecting old and new: finisher only (user 11-25: 'I see a line, then a slash' - normal taps show ONE effect)
  if (o.big) streakBetween(old, c, h * .07);
  WFX.trail(old, c, oldH * .3); // element-coloured departure wisps (weaponfx.js)
  // arrival: pose, facing, scale
  const face = (T.poses[pi] ? POSE_FACE[pi] : 1), want = target.x >= c.x ? 1 : -1;
  world.heroMat.uniforms.map.value = tex;
  hero.userData = { h, hs: h, asp, flip: want * face, t: 0, c: c.clone(), to: target.clone(), tex };
  hero.position.set(c.x, c.y - h * .5, z); hero.quaternion.copy(camera.quaternion);
  world.heroOld.visible = false; world.heroMat.uniforms.alpha.value = 1; world.heroMat.uniforms.cut.value = -2;
  world.heroAway = true; S.lastHop = G.t;
  flashAt(c, 1, h * .55, .18, .55, .35, .9); flashAt(c, 1, h * .9, .2, .45, .3, .9, { ring: .95 });
  shock(c, h * 1.3, .26, .55); // teleport-in refraction pop
  world.heroGlow.position.copy(c); world.heroGlow.position.z -= .5;
  A.sfx('blink'); A.sfx('hop', S.hopN++ % 14); A.voice('atk'); // hero grunt: ~1 in 6 hops, cooldown (audio.js VO)
  // camera stays at its rest framing (user 11-25: no sway / lean / whip); impact = short positional shake only
  if (o.big) shake(.55); // user 11-25: camera shake only on important things (finisher, crits, rune broken, exit); none per tap
  // strike
  slashArcs(target, o);
}
function streakBetween(a, b, th) {
  const m = world.streaks.find((s) => !s.visible) || world.streaks[0]; m.visible = true; m.userData.t = 0; m.userData.dur = .24;
  m.position.copy(a).add(b).multiplyScalar(.5); const sa = toScreen(a, {}), sb = toScreen(b, {});
  m.quaternion.copy(camera.quaternion); m.rotateZ(Math.atan2(-(sb.y - sa.y), sb.x - sa.x)); m.scale.set(a.distanceTo(b) * 1.1, Math.max(1.2, th), 1);
  m.material.uniforms.c1.value.setRGB(.75, .5, 1); return m;
}
function slashArcs(target, o) {
  // user 11-25: normal taps use the painted slash graphics again (v2 look, distortion on) - ONE arc per tap, centred on the tap point,
  // swept along the hop direction. Skill moments (finisher here, crits / rune broken / milestones via superSlash) stack 2-3 bigger arcs.
  // The light crescent (lightArcMat) is kept only for the ghosts.
  const ck = comboK(), ts = toScreen(target, {});
  const n = o.big ? 3 : 1, base = Math.min(W, Hh) * (portrait ? .62 : .48) * slashK() * (o.big ? 1.7 : (1 + .45 * ck) * (o.wp ? 1.1 : 1)); // user 11-26: slashes too big -> SLASH_K
  for (let i = 0; i < n; i++) { const p = screenToPlane(ts.x + (i ? rand(-16, 16) : 0), ts.y + (i ? rand(-16, 16) : 0), -34, _v3);
    const am = spawnArc(p, base * (i ? rand(.7, .85) : rand(.92, 1.08)), (o.rot ?? rand(0, 6.283)) + (i ? i * 1.1 + rand(-.3, .3) : rand(-.2, .2)), Math.random() < .5, (o.big ? .42 : .26 + ck * .05)); if (o.big && i === 0) am.userData.warp = 1; }
  { const p = screenToPlane(ts.x, ts.y, -34, _wq); WFX.impact(p, pxToWorld(Math.min(W, Hh) * .1, p), !!o.big); } // element impact (flames / lightning fork / ice shards ...)
}
const _wq = new THREE.Vector3();
// a SUPER slash at a point (crits, rune broken, combo milestones): 3 stacked painted arcs, bigger and brighter, strong distortion
function superSlash(p, scale = 1) {
  const ts = toScreen(p, {}), q = screenToPlane(ts.x, ts.y, -34, new THREE.Vector3()), r0 = rand(0, 6.283), base = Math.min(W, Hh) * (portrait ? .82 : .64) * slashK() * 1.1 * scale;
  for (let i = 0; i < 3; i++) { const m = spawnArc(q, base * [1, .82, .66][i], r0 + i * 1.05, Math.random() < .5, .38 + i * .03); if (m.material.uniforms.boost) m.material.uniforms.boost.value = 1.35; if (i === 0) m.userData.warp = 1; }
  shock(q, 48 * scale, .45, 1); flashAt(q, 2, 14 * scale, .25, .8, .6, 1, { ring: .9 });
}
// ---------------- accurate hits: CPU test against the skinned puppet parts' alpha ----------------
const HIT_R = () => (COARSE ? 11 : 8); // forgiveness margin in px
const _hp = new THREE.Vector3();
function bodyAt(sx, sy) { // exact (no margin) test of one screen point -> the part hit (or null)
  screenToPlane(sx, sy, titanGroup.position.z, _hp); titanGroup.worldToLocal(_hp); const p = puppet.hit(_hp.x, _hp.y); if (p) { G.hitArea = p.pt.area || areaOf(p.pt.bone); G.hitRig = { bone: p.pt.bone, x: _hp.x, y: _hp.y }; G.hitPart = p; } return p;
}
function titanHit(sx, sy) { // world point on the body under (sx, sy) with a small margin, or null
  titanGroup.updateMatrixWorld(); const r = HIT_R();
  if (bodyAt(sx, sy)) return titanPlanePoint(sx, sy);
  for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; if (bodyAt(sx + Math.cos(a) * r, sy + Math.sin(a) * r)) return titanPlanePoint(sx, sy); }
  return null;
}
function whiff(sx, sy) { // tap on empty space: no damage, no combo, no hop, and no effect at all (user 11-25: no small click slash)
  G.misses = (G.misses || 0) + 1;
}
// 11-27 HURT FEEDBACK (titans/hurt.js): flash the struck part in the blade's colour, red hurt pulse, wound mark; + a few sparks in the
// titan's own colour (stone / ember / ink chips read as "a piece came off"). kind: tap | crit | wp | wp10 | fin
const _hb = new THREE.Color();
function hurtHit(part, kind, rig, p) {
  if (!world.hurt || !HURT_ON || G.state === 'lobby') return; EQ.arcTint(_hb, .5); world.hurt.hit(part, kind, rig, _hb);
  if (p) burst(p, kind === 'tap' ? 5 : kind === 'wp' ? 6 : 12, kind === 'tap' ? 15 : 22, 'wp', kind === 'tap' ? .7 : .95);
}
function tapStrike(sx, sy, w, hitP) {
  const target = w ? titanPlanePoint(sx, sy) : hitP; // slash + number at the EXACT tap point (a rune tap still counts on the rune)
  // 11-26 HERO PERFORMS THE LIMIT (user pick): while a limit break / Omni finisher plays (S.on) taps still count fully (damage,
  // combo, weak-point hits, rank) but the hero does NOT teleport and no slash arc is drawn: a small spark + a small number only
  const lim = S.on;
  if (!lim) hop(target, { wp: !!w }); else slashArcs(target, { wp: !!w, rot: slashRot(toScreen(target)) }); // 11-26 user: during a skill a tap still slashes (arc + hit sound), the hero just doesn't teleport
  if (w) { wpHit(w, 1, target); if (!lim) G.hitstop = Math.max(G.hitstop, .022); }
  else {
    const base = 120 * tapPow() * (1 + G.chain * comboG()); // only called for taps that hit the body
    const crit = damage(base, 'hop', target, 'b' + (G.hitArea || 'chest'));
    burst(target, crit ? 34 : lim ? 10 : 18, lim ? 18 : 24, 'slash', lim ? .8 : 1.1); flashAt(target, 1, crit ? 7 : lim ? 3 : 4, .14, .6, .45, .9); if (crit) flashAt(target, 2, 12, .22, .8, .6, .3, { ring: .9 });
    buzz(6); if (crit && !lim) { shake(.5); superSlash(target, .9); } if (!lim) G.hitstop = Math.max(G.hitstop, crit && HURT_ON ? .045 : .018); // 11-27: crits get a real hit-stop
    titanState.hit = Math.max(titanState.hit, .5); titanState.flinch = Math.min(1, titanState.flinch + .15); titanState.flinchDir = target.x > 0 ? -1 : 1;
    world.anim.flinch(G.hitArea, target.x > 0 ? -1 : 1, crit ? .5 : .25, G.hitRig); // + spring push + part punch at the tap (titans/react.js)
    hurtHit(G.hitPart, crit ? 'crit' : 'tap', G.hitRig, target); // part flash, red hurt pulse, wound mark, titan-coloured chips
    if (world.anim.lookAt && G.hitRig && puppet.byName.head) { const e = puppet.point('head', 0, 0, _v3); world.anim.lookAt((G.hitRig.x - e.x) / puppet.k, (e.y - G.hitRig.y) / puppet.k); } // core titans: the eye follows the taps
    if (crit || Math.random() < .4) debris(target, crit ? 4 : 2, crit ? 16 : 12);
  }
  lights.fl.position.set(target.x, target.y, -34); lights.fl.intensity = Math.max(lights.fl.intensity, 4); SH.lightPos.value.set(target.x, target.y, -36); SH.lightCol.value.setRGB(.3, .2, .5);
  flash([.5, .35, 1], .05); post.chroma = .12;
}
// a tap on the training dummy (lobby, and its pieces during the handover): same hop + slash + number at the tap point as on the
// titan; the dummy wobbles away from the hit, squashes, sheds chips and its rune flashes (dummy.js)
function dummyStrike(dh) {
  const target = dh.p, lim = S.on; if (!lim) hop(target, {}); else slashArcs(target, { rot: slashRot(toScreen(target)) }); // a limit break plays: the hero performs it, taps only spark (tapStrike)
  const crit = damage(120 * tapPow() * (1 + G.chain * comboG()), 'hop', target, 'dummy');
  world.dummy.impact(target, dh.part, crit);
  burst(target, crit ? 30 : 14, 20, 'slash', 1); flashAt(target, 1, crit ? 5 : 3, .14, .6, .45, .9);
  buzz(6); if (crit && !lim) superSlash(target, .7); if (!lim) G.hitstop = Math.max(G.hitstop, .018);
  lights.fl.position.set(target.x, target.y, target.z + 2); lights.fl.intensity = Math.max(lights.fl.intensity, 4); flash([.5, .35, 1], .04); post.chroma = .1;
}
function dropClone(hero, life = .9) {
  const u = hero.userData || {};
  const m = world.clones[S.cloneI = (S.cloneI + 1) % world.clones.length]; m.visible = true; m.position.copy(hero.position); m.quaternion.copy(hero.quaternion);
  m.scale.copy(hero.scale); m.userData.life = life; m.userData.max = life; m.userData.dis = undefined; m.material.uniforms.map.value = u.tex || T.hi;
  const mu = m.material.uniforms; mu.tint.value.set(.45, .35, .9); mu.flash.value.setRGB(.14, .05, .32); WFX.tintClone(mu); mu.alpha.value = .42; mu.cut.value = -2; // afterimage in the blade's element colour
}

// ---------------- combo finisher (auto, every COMBO_STEP) ----------------
// spotlight (user 11-25): ~0.62 s of 0.3x slow motion + darkened vignette + painted OMNI FINISHER banner, THEN 5 big hops in real
// time, a big final shockwave. The banner sits mid-screen and is sized for phones.
const FIN_GAP = .07; // in-flow (user 11-25: nothing interrupts tapping): no slow motion, no dark vignette, no big banner, no hit-stop
// 11-26 LIMIT BREAKS (limits.js + data/limits.json): each finisher picks one at random; OMNI SLASH = the hop burst below
// limit damage goes through limDmg / limWp: G.inLim makes damage() add it to the silent limit total (one number at the end)
function inLim(fn, ...a) { G.inLim = 1; try { return fn(...a); } finally { G.inLim = 0; } }
const limDmg = (...a) => inLim(damage, ...a), limWp = (...a) => inLim(wpHit, ...a);
// the hero holds a strike pose (T.poses index; 1 / 3 = blade raised) centred at world point c, facing `to`: limits.js poses him
// mid-air while a limit's effect plays (hero.userData.c can then be moved; the frame loop draws the held strike pose there)
// 11-26 skills: snap the hero straight back to his idle spot (no gravity return) - an afterimage where he was
function blinkHome() { if (world.ret) cancelReturn(); // 11-26: no afterimage / flash left at the strike spot (it read as a late extra attack after Starfall)
  world.heroAway = false; world.heroMat.uniforms.alpha.value = 1; HA.reset(); }
function heroPose(c, pi = 1, to = null) {
  if (world.ret) cancelReturn();
  const hero = world.hero, tex = T.poses[pi] || T.hs, asp = tex.image.width / tex.image.height, h = pxToWorld(spritePx(tex), c), tg = to || c;
  world.heroMat.uniforms.map.value = tex; world.heroOld.visible = false; world.heroMat.uniforms.alpha.value = 1; world.heroMat.uniforms.cut.value = -2;
  hero.userData = { h, hs: h, asp, flip: (tg.x >= c.x ? 1 : -1) * (T.poses[pi] ? POSE_FACE[pi] : 1), t: 0, c: c.clone(), to: tg.clone(), tex };
  hero.position.set(c.x, c.y - h * .5, c.z); hero.quaternion.copy(camera.quaternion); world.heroAway = true; S.lastHop = G.t;
  return hero.userData;
}
const LCTX = () => LIM.bind({ titanGroupZ: () => titanGroup.position.z, blinkHome, hitSound, world, G, S, titanState, A, AT, lights, post, post_, scene, camera, RO, hop, heroPose, spawnArc, shock, flashAt, streakBetween, dropClone, damage: limDmg, wpHit: limWp, burst, debris,
  shake, flash, pop, buzz, socketWorld, socketCenter, toScreen, screenToPlane, pxToWorld, startAct, slashPow, get W() { return W; }, get Hh() { return Hh; } });
function finisher() {
  if (S.on) return; const L = LIM.pick(G.chain); S.lim = null; S.limTot = 0; A.voice('lim_' + (L ? L.id : 'omni')); // limit callout
  if (L && L.id !== 'omni') { S.on = true; S.lim = L; G.slashes++; LIM.play(L, LCTX()); return; }
  S.on = true; S.queue = 5; S.qT = 0; S.dmg = 0; S.total = 5; G.slashes++;
  A.sfx('charge'); pop(L ? L.label : 'THOUSAND CUTS', L ? 'LIMIT BREAK' : 'x5', 2); titanState.hit = 1;
  const hc = _v.copy(world.hero.position); hc.y += (world.hero.userData.h || world.heroH) * .5; flashAt(hc, 1, (world.hero.userData.h || world.heroH) * 3, .6, .7, .5, 1, { ring: .95 }); shock(hc, 30, .6, .8);
}
function updateFinisher(dt) {
  if (S.lim) { if (!LIM.update(dt)) { S.lim = null; S.on = false; showLimTotal(); } return; } // a limits.js limit break
  S.qT -= dt; if (S.qT > 0) return; S.qT = FIN_GAP;
  const w = world.wps.find((x) => x.on && x.state === 'live'), last = S.queue === 1;
  const dm = !w && world.dummy?.present && (titanState.sink || 0) > .5 ? world.dummy.centerWorld() : null; // lobby finisher hits the dummy
  const target = w ? w.pos.clone() : dm || socketCenter();
  hop(target, { big: true }); if (dm) world.dummy.impact(target, 'body', last);
  const dmg = 520 * slashPow() * (1 + G.chain * .015) * (last ? 2.5 : 1); if (w) S.dmg += limWp(w, 2.5, target);
  if (last) G.finHit = true; // the Omni finisher's last hit = always the ultra crit
  limDmg(dmg, 'fin', target, 'fin'); S.dmg += dmg;
  burst(target, last ? 120 : 50, last ? 50 : 34, 'slash', 1.6); debris(target, last ? 18 : 6, 26); shake(last ? 1.6 : .7); buzz(last ? 40 : 14);
  shock(target, last ? 75 : 28, last ? .65 : .35, 1); // finisher shockwave ripple
  titanState.hit = 1.2; titanState.flinch = Math.min(1.5, titanState.flinch + (last ? 1.2 : .45)); titanState.flinchDir = target.x > 0 ? -1 : 1; world.anim.flinch(last ? 'chest' : ['head', 'chest', 'shoulderL', 'shoulderR'][S.queue % 4], target.x > 0 ? -1 : 1, last ? 1.2 : .6);
  lights.fl.position.set(target.x, target.y, -34); lights.fl.intensity = 9;
  flash([.6, .5, 1], last ? .14 : .05);
  if (last) { shock(target, 120, .9, 1); flash([.7, .6, 1], .08); const sw = target.clone(); for (let i = 0; i < 3; i++) setTimeout(() => flashAt(sw, 4, 40 + i * 18, .5, .7, .55, 1, { ring: .95 }), i * 90); A.sfx('finish'); G.hitstop = Math.max(G.hitstop, .14); flashAt(target, 4, 34, .5, .8, .7, 1, { ring: .95 }); if (!AT.on) startAct('stagger');
    S.on = false; showLimTotal(); }
  S.queue--;
}
function socketCenter() { const hd = new THREE.Vector3(); puppet.point('chest', 0, 0, hd); titanGroup.localToWorld(hd); hd.x += rand(-5, 5); hd.y += rand(-3, 8); hd.z = titanGroup.position.z + 3; return hd; }
// ---------------- idle return (user 11-25: "come back more elegantly to idle") ----------------
// ~0.5 s after the last hop the hero floats home along an arc with a violet trail (eased, slight stretch + lean), lands with
// a squash / settle and a cape flourish, while the sprites crossfade strike pose -> landing pose (sword lowered) -> idle.
// Lingering clones dissolve upward into sparkles. A tap mid-return cancels it (hop() -> cancelReturn()).
// 11-26 user: "weird pause mid-air after the attack" - hang time before the drop home 0.5 -> 0.2 s (?retdelay=S to tune)
const RET_DELAY = +(new URLSearchParams(location.search).get('retdelay') || .2), RET_FLY = .5, RET_END = 1.3;
const RETGLIDE = new URLSearchParams(location.search).get('retglide') === '1'; // 11-26: 1 = the old floaty eased glide home
const HA_BOB = .3; // with the painted idle loop (heroanim.js) only 30% of the procedural bob / breathing stays on top
function homeCenter(out) { return out.set(world.heroHome.x, world.heroHome.y + world.heroH * .5, world.heroHome.z); }
// 11-26: fight start - the hero drops in from above the screen onto the ledge (the gravity return + its landing pose / dust); 11-27: ?jumpin=1 only
function heroJumpIn() { if (!world.hero || new URLSearchParams(location.search).get('jumpin') !== '1') return; // 11-27: opt-in only (?jumpin=1)
  if (world.ret) cancelReturn(); const hero = world.hero, hm = world.heroHome, h = world.heroH || 4;
  const top = screenToPlane(toScreen(hm, {}).x, -Hh * .18, hm.z); // well above the top edge, straight over his spot
  hero.position.set(hm.x, top.y - h * .5, hm.z); hero.userData = { ...hero.userData, h, hs: h, tex: T.poses[1] || T.hi, flip: world.heroFace || 1 };
  world.heroMat.uniforms.map.value = T.poses[1] || T.hi; world.heroMat.uniforms.alpha.value = 1; world.heroAway = true; startReturn(); }
function startReturn() {
  const hero = world.hero, u = hero.userData, hs = u.hs || u.h, c = hero.position.clone().setY(hero.position.y + hs * .5), s = toScreen(c, {});
  world.heroAway = false;
  // user 11-25: "landing is after you stop attacking" - he lands on a RANDOM spot along the ledge each time, not the same home.
  // Range = the visible part of the ledge (15-85% of the screen width, inside the painted ledge), at least 20% of the width from
  // the last spot. Only x changes, so his depth and size stay the same.
  if (G.state === 'lobby' && world.heroHome0) { world.heroHome.copy(world.heroHome0); world.heroFace = 1; } // 11-26 user: lobby = fixed spot on the dojo step (the step kept jumping to his random landing spot)
  else { const hm = world.heroHome, fy = toScreen(hm, {}).y, L = world.env.ledge;
    let x0 = screenToPlane(W * .15, fy, hm.z).x, x1 = screenToPlane(W * .85, fy, hm.z).x;
    if (L) { x0 = Math.max(x0, L.position.x - L.scale.x * .42); x1 = Math.min(x1, L.position.x + L.scale.x * .42); }
    if (x1 > x0) { const minGap = (x1 - x0) * .25; let nx = hm.x;
      for (let i = 0; i < 12; i++) { nx = rand(x0, x1); if (Math.abs(nx - hm.x) >= minGap) break; }
      hm.x = nx; }
    world.heroFace = toScreen(hm, {}).x > W / 2 ? -1 : 1; } // user 11-25: on the right side he flips to face the titan / centre
  S.retN = ((S.retN ?? Math.floor(Math.random() * 4)) + 1) % 4; // arc shape cycles: over the top, swing in from the left, from the right, low swoop
  world.ret = { mode: S.retN, t: 0, x0: s.x, y0: s.y, z0: c.z, tex0: u.tex || T.hi, flip0: u.flip || 1, landed: false, trailT: 0, prev: c.clone() };
  let n = 0; for (const m of world.clones) if (m.visible) { const cu = m.userData; cu.dis = 0; cu.disDur = .6 + .07 * n++; cu.a0 = m.material.uniforms.alpha.value; }
  A.sfx('glide');
}
function cancelReturn() { world.ret = null; world.heroOld.visible = false; world.heroMat.uniforms.alpha.value = 1; }
const sstep = (a, b, x) => { const u = clamp((x - a) / (b - a), 0, 1); return u * u * (3 - 2 * u); };
function setSprite(m, tex, hgt, flip, foot, tilt, sx, sy, alpha) { // bottom-anchored hero sprite: feet at `foot`, height hgt
  const asp = tex.image.width / tex.image.height; m.material.uniforms.map.value = tex; m.material.uniforms.alpha.value = alpha;
  m.position.copy(foot); m.quaternion.copy(camera.quaternion); m.rotateZ(tilt); m.scale.set(hgt * asp * flip * sx, hgt * sy, 1);
}
function updateReturn(dt, t) {
  const R = world.ret, hero = world.hero, old = world.heroOld; R.t += dt; const rt = R.t;
  const x = clamp(rt / RET_FLY, 0, 1), e = RETGLIDE ? lerp(sstep(0, 1, x), 1 - Math.pow(1 - x, 3), .55) : x; // old: eased glide; now linear time (gravity is in y)
  const hc = homeCenter(_v2), hs = toScreen(hc, {});
  // user 11-25: "less curvy, natural, not going beyond the landing" - a near-straight glide with only a slight lift at the middle;
  // the control point sits between the two ends, so the path never swings past the landing spot (no side / swoop modes).
  // (2) "I still want the arc, but the middle point should not be beyond the X of the landing spot": the arc shapes are back (high
  // arc / lean from a side / low swoop), but the control point's X is clamped between the start X and the landing X.
  // (3) user 11-26: "more natural, like gravity doing itself, not staying flying" - a BALLISTIC drop instead of an eased glide:
  // constant horizontal speed (linear in time, so x never passes the landing X) and a vertical parabola with a small upward kick
  // at the start, then constant gravity, so he speeds up into the landing (no floaty slow-down). ?retglide=1 = the old glide.
  let bx, by;
  if (RETGLIDE) {
    let cx = (R.x0 + hs.x) * .5, cy = Math.min(R.y0, hs.y) - Hh * .12; const i = 1 - e;
    if (R.mode === 1 || R.mode === 2) { cx = hs.x + (R.mode === 1 ? -1 : 1) * W * .3; cy = hs.y - Hh * .06; }
    else if (R.mode === 3) cy = Math.min(Hh * .9, Math.max(R.y0, hs.y) + Hh * .04);
    cx = clamp(cx, Math.min(R.x0, hs.x), Math.max(R.x0, hs.x));
    bx = i * i * R.x0 + 2 * i * e * cx + e * e * hs.x; by = i * i * R.y0 + 2 * i * e * cy + e * e * hs.y;
  } else {
    const up = R.drop ? 0 : Hh * (R.y0 < hs.y ? .05 : .1); // R.drop (descent arrival): falling already, no hop up // small hop up first (a bigger one when he starts at or below the ledge)
    bx = lerp(R.x0, hs.x, x); by = R.y0 - up * 2 * x + (hs.y - R.y0 + up * 2) * x * x; // y(0)=y0, y(1)=landing, constant +y accel
  }
  const ctr = screenToPlane(bx, by, lerp(R.z0, hc.z, e), _v3), H = pxToWorld(spritePx(T.hi), ctr); // constant on-screen character scale (no lerp)
  // squash / stretch / lean
  const fly = Math.sin(Math.PI * x) * (x < 1 ? 1 : 0), u = Math.max(0, rt - RET_FLY);
  const land = rt >= RET_FLY ? .06 * (1 - Math.exp(-u * 45)) * Math.exp(-u * 9) : 0; // soft landing squash, no rebound / overshoot
  const sy = (1 + .08 * fly) * (1 - land), sx = (1 - .05 * fly) * (1 + land * .6);
  const dirX = Math.sign(hs.x - R.x0) || 1, tilt = -dirX * .16 * fly + .05 * Math.exp(-u * 5) * Math.sin(u * 13) * (rt >= RET_FLY ? 1 : 0); // lean into the glide, cape-settle wobble
  const idleK = sstep(.65, 1.25, rt) * (HA.on ? HA_BOB : 1), bob =(Math.sin(t * 1.6) * .04 + Math.max(0, Math.sin(t * 3)) * .02) * idleK, br = .012 * Math.sin(t * 1.6) * idleK;
  const foot = _v.copy(ctr); foot.y += -lerp(H * .41, H * .5, e) + bob; // shared hip pivot in the air (crouch sprite centred on the path), feet at landing
  if (rt >= RET_FLY) foot.copy(world.heroHome).setY(world.heroHome.y + bob); // planted
  const landTex = T.land || T.hi, HL = pxToWorld(spritePx(landTex), ctr);
  if (rt < .34) { // strike pose (top, fading) over the landing pose (bottom, rising)
    const k = sstep(0, .34, rt), sh = pxToWorld(spritePx(R.tex0), ctr); // same character scale, centred on the path
    setSprite(hero, landTex, HL, world.heroFace || 1, foot, tilt, sx, sy, Math.min(1, k * 1.7));
    setSprite(old, R.tex0, sh, R.flip0, _v2.copy(ctr).setY(ctr.y - sh * .5), tilt, sx, sy, 1 - k); old.visible = true;
  } else if (rt < .72) { setSprite(hero, landTex, HL, world.heroFace || 1, foot, tilt, sx, sy, 1); old.visible = false; }
  else { // landing pose (top, fading) over idle (bottom, rising) + idle breathing fading in
    const k = sstep(.72, 1.2, rt); if (!R.ha) { R.ha = 1; HA.reset(); } // idle flipbook starts at frame 0 under the landing pose
    setSprite(hero, HA.tick(dt) || T.hi, H, world.heroFace || 1, foot, tilt, sx * (1 + br * .8), sy * (1 + br), Math.min(1, k * 1.7));
    setSprite(old, landTex, HL, world.heroFace || 1, foot, tilt, sx, sy, 1 - k); old.visible = k < 1;
  }
  hero.userData = { h: H, hs: H, tex: rt < .72 ? landTex : (HA.cur || T.hi), asp: hero.material.uniforms.map.value.image.width / hero.material.uniforms.map.value.image.height };
  // violet glide trail + glow + magic tint while in the air
  world.heroMat.uniforms.flash.value.setRGB(.2, .1, .34).multiplyScalar(fly * .8); old.material.uniforms.flash.value.copy(world.heroMat.uniforms.flash.value);
  world.heroGlow.visible = x < 1; world.heroGlow.position.set(ctr.x, ctr.y, ctr.z - .5); world.heroGlow.quaternion.copy(camera.quaternion); world.heroGlow.scale.setScalar(H * 1.2); world.heroGlow.material.uniforms.fade.value = .2 * (1 - e);
  if (x < 1) {
    for (let k = 0; k < 3; k++) { const f = Math.random(); world.sparks.emit(lerp(R.prev.x, ctr.x, f) + rand(-.3, .3) * H, lerp(R.prev.y, ctr.y, f) + rand(-.25, .25) * H, lerp(R.prev.z, ctr.z, f), rand(-1, 1), rand(0, 1.5), 0, rand(.35, .6), rand(.5, .9), k ? .75 : 1, k ? .5 : .9, 1, -1.5); }
    R.trailT -= dt; if (R.trailT <= 0) { R.trailT = .05; streakBetween(R.prev, ctr, H * .06); R.prev.copy(ctr); }
  } else if (!R.landed) { // touch-down: soft ring at the feet, sideways dust, refraction pop
    R.landed = true; const f = _v2.copy(world.heroHome).setY(.25);
    flashAt(f, H * .3, H * 1.4, .35, .6, .45, 1, { ring: .95 }); shock(f, H * 2.2, .35, .5); A.sfx('land'); buzz(4);
    for (let k = 0; k < 16; k++) { const s = k % 2 ? 1 : -1; world.sparks.emit(f.x + rand(-.3, .3), f.y, f.z, s * rand(2, 6), rand(.5, 2.5), rand(-1, 1), rand(.3, .6), rand(.6, 1.1), .8, .6, 1, 3); }
  }
  if (rt >= RET_END) { world.ret = null; old.visible = false; world.heroMat.uniforms.alpha.value = 1; }
}
function flash(c, k) { post.flash[0] = Math.max(post.flash[0], c[0] * k); post.flash[1] = Math.max(post.flash[1], c[1] * k); post.flash[2] = Math.max(post.flash[2], c[2] * k); }

// ---------------- taps ----------------
// 11-26 user: ONE close X for every popup, OUTSIDE the box at the screen's top-right (the popups' open animation transforms them,
// so an X inside can't be pinned to the screen). It closes whichever popup is open (daily only once its free claim is done).
{ const x = document.createElement('button'); x.id = 'popX'; x.innerHTML = '&#10005;'; x.setAttribute('aria-label', 'Close'); document.body.appendChild(x);
  for (const ev of ['pointerdown', 'touchstart']) x.addEventListener(ev, (e) => e.stopPropagation(), { passive: true });
  x.addEventListener('click', (e) => { e.stopPropagation(); A.sfx('click');
    if (window.DAILY?.isOpen?.()) { if (window.DAILY.canClose?.() !== false) window.DAILY.close(); } else if (LUI.popOpen()) LUI.closePop(); else if (MENU.isOpen()) MENU.close(); else if (INV.isOpen()) INV.close(); else if (window.PUI?.closable?.()) window.PUI.close(); }); // PUI: the auto-train panel (prog-ui.js)
  // 11-27: the SHOP / GEAR tab screens (lobby-ui.js) are navigation, not popups: no X (back arrow / the tab again) in the old style
  // 11-27 ink UI kit: the same one X, but placed on the open popup's frame (its top-right corner, like the mockups) every frame.
  // Ink (user 11-27 "the x button is not same across shop and gear"): SHOP / GEAR get this X too (no back arrow), and the
  // four lobby tabs share one frame geometry (kit-ui.css), so the X sits on the same screen spot on every tab.
  const INKX = document.documentElement.classList.contains('ink'), FR = `#dailyPop:not(.hidden) .dframe, #enPop:not(.hidden) .mframe, #pfPop:not(.hidden) .mframe, #mpanel:not(.hidden) .mframe, #inv:not(.hidden)${INKX ? '' : ':not(.tabscr)'} .iframe, .pu-pop .pu-frame`;
  const place = () => { const f = [...document.querySelectorAll(FR)].find((e) => e.offsetParent); if (!f) { x.style.left = x.style.top = ''; return; } const r = f.getBoundingClientRect();
    const s = x.offsetWidth, corner = f.classList.contains('dframe'); // daily: its coin pill owns the header's right end -> the X sits on the frame corner
    if (INKX) { x.style.left = `${Math.round(Math.max(4, r.left + 12))}px`; x.style.top = `${Math.round(Math.max(4, r.top + 12))}px`; return; } // 11-27 user: ink = a BACK arrow on the frame's top-left ('<' like the tab screens)
    x.style.left = `${Math.round(Math.min(innerWidth - s - 4, corner ? r.right - s * .8 : r.right - s - 14))}px`; x.style.top = `${Math.round(Math.max(4, corner ? r.top - s * .2 : r.top + 14))}px`; };
  const sync = () => { const d = window.DAILY?.isOpen?.(), on = (d && window.DAILY.canClose?.() !== false) || (!d && ((INV.isOpen() && (INKX || !LUI.tabOpen())) || MENU.isOpen() || LUI.popOpen() || !!window.PUI?.closable?.())); x.classList.toggle('on', !!on); if (INKX && on) place(); requestAnimationFrame(sync); };
  requestAnimationFrame(sync); }
let lastPtr = { x: innerWidth / 2, y: innerHeight * .45 };
// the finisher window (cutend.js): the hero strikes where you tap (no damage: the time is already stopped) + one screen cut
function finishTap(sx, sy) { CUT.tap(sx, sy); PUI.tapXp(); const p = titanPlanePoint(sx, sy); hop(p, {}); burst(p, 18, 24, 'slash', 1.1); titanState.hit = Math.max(titanState.hit, .6); shake(.35); buzz(6); }
const MISS_WHIFF = new URLSearchParams(location.search).get('missattack') === '0'; // 11-26 user: tap anywhere attacks (a miss hits a random spot) is the DEFAULT; ?missattack=0 = old (a miss does nothing)
function tapAt(sx, sy, retry = false) {
  if (G.state === 'lobby' && LUI.gearView()) return; // 11-27 3D gear view: the hero stands idle (no dummy hits)
  if (G.state === 'intro') return skipIntro();
  if (G.state === 'descent') return skipDescent();
  if (G.state === 'blackout') return; // fading to black: no attack
  if (G.state === 'retreat' && CUT.tapping()) return finishTap(sx, sy); // the kill finisher: every tap = one slash (11-28)
  if (G.state !== 'fight' && G.state !== 'lobby') return;
  // training dummy first (it stands in front; during the lobby -> fight handover its flying pieces still count), then the titan
  const w = wpAt(sx, sy), dh = w ? null : world.dummy?.hit(sx, sy, camera, W, Hh, HIT_R()), hitP = w || dh || G.state === 'lobby' ? null : titanHit(sx, sy);
  if (HITDEBUG) dbgTaps.push({ x: sx, y: sy, r: w ? 'wp' : hitP || dh ? 'hit' : 'miss', t: performance.now() });
  if (!w && !hitP && !dh) { // 11-26 user: a tap that misses still attacks - a random spot on the titan (lobby: the dummy), like the bot picks
    if (!retry && !MISS_WHIFF) {
      // 11-26 user: "not middle all the time, but inside the titan": walk from the tap toward the titan's chest (lobby: the dummy's
      // centre) and land on the first point that is really on its body, a step further in - near where you tapped, never off it
      const c = G.state === 'lobby' ? (world.dummy?.present ? toScreen(world.dummy.centerWorld(), {}) : null) : toScreen(socketCenter(), {});
      const on = (x, y) => G.state === 'lobby' ? !!world.dummy.hit(x, y, camera, W, Hh, HIT_R()) : !!titanHit(x, y);
      let p = c; if (c) {
        for (let i = 1; i <= 24; i++) { const k = i / 24, x = sx + (c.x - sx) * k, y = sy + (c.y - sy) * k; if (on(x, y)) { const k2 = Math.min(1, k + .12); p = { x: sx + (c.x - sx) * k2, y: sy + (c.y - sy) * k2 }; break; } } }
      if (p && c && !on(p.x, p.y)) for (let j = 0; j < 10; j++) { const q = G.state === 'lobby' ? toScreen(world.dummy.centerWorld(), {}) : toScreen(socketCenter(), {}); if (on(q.x, q.y)) { p = q; break; } } // never a whiff
      // 11-27 user "random: I can't tap during the titan fight": on titans whose chest socket is empty space (strider's hull gap, coils)
      // every fallback point missed -> the tap became a silent whiff. Last resort: random points spiralling out from the centre.
      if (c && (!p || !on(p.x, p.y))) { const R = Math.min(W, Hh) * .45; for (let j = 1; j <= 48; j++) { const a2 = j * 2.399, r2 = R * Math.sqrt(j / 48), x = c.x + Math.cos(a2) * r2, y = c.y + Math.sin(a2) * r2; if (on(x, y)) { p = { x, y }; break; } } }
      if (p) return tapAt(p.x, p.y, true); }
    G.lastHit = 'miss'; whiff(sx, sy); return; } // ?missattack=0: a miss does nothing
  G.lastHit = w ? 'wp' : dh ? 'dummy' : 'hit';
  G.taps++; const c0 = G.chain; if (!PUI.isAuto()) G.chain = Math.min(CHAIN_MAX, G.chain + COMBO_GAIN); G.lastTap = G.t; // auto-train hits build no combo (it carries into the fight) // 11-26 user: x filled too easily -> +0.5 per hit (?combogain=)
  if (G.state === 'fight') tapNews(c0, G.chain);
  if (dh) dummyStrike(dh); else tapStrike(sx, sy, w, hitP);
  if (dh && !SAVE.dummyHint) { SAVE.dummyHint = 1; save(); $('tapHint').classList.add('gone'); } // the first-launch "TAP THE DUMMY" hint, once
  if (G.state === 'fight' || (G.state === 'lobby' && dh)) PUI.tapXp(); // 11-28 user: taps are the only XP. NO shards in the main menu
  if (G.chain >= S.nextFin) { S.nextFin += COMBO_STEP; finisher(); }
}
// 11-26 "if I swipe it stops working": iOS can cancel a swiped touch sequence and then stop sending pointer events to the canvas,
// while raw touch events keep coming. Taps now come from BOTH: touchstart (each new finger) and pointerdown (mouse / pen, or touch
// when no touchstart arrived just before - deduped). A swipe can also scroll / rubber-band the page: snap it back.
const INP = window.__inp = { pd: 0, ts: 0, pc: 0 }; let lastTouchT = -1e9;
// 11-27 user "I hit them, then all of a sudden it stopped": ?inpdbg=1 = a tiny live line (bottom-left): touch/pointer events that reached
// the canvas, taps that became hits, game state, last hit type, and the element under the last touch - screenshot it when taps die
if (new URLSearchParams(location.search).get('inpdbg') === '1') { const d = document.createElement('div'); d.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:99999;font:11px monospace;color:#0f0;background:#000b;padding:2px 4px;pointer-events:none;white-space:pre';
  document.body.appendChild(d); let lastEl = '-'; addEventListener('touchstart', (e) => { const t = e.changedTouches[0], el = t && document.elementFromPoint(t.clientX, t.clientY); lastEl = el ? (el.id || el.tagName + '.' + [...el.classList].join('.')) : '-'; }, { capture: true, passive: true });
  setInterval(() => { d.textContent = `ts ${INP.ts} pd ${INP.pd} taps ${G.taps} ${G.state} ${G.lastHit || ''}
under: ${lastEl}`; }, 200); }
const tapFrom = (x, y, ts) => { A.init(); if (G.state === 'start') return; lastPtr = { x, y }; TB.stamp(ts); try { tapAt(x, y); } finally { TB.stamp(null); } }; // ts = the event's time (time board kill clock)
canvas.addEventListener('touchstart', (e) => { INP.ts++; lastTouchT = performance.now(); for (const t of e.changedTouches) tapFrom(t.clientX, t.clientY, e.timeStamp); }, { passive: true });
canvas.addEventListener('pointerdown', (e) => { INP.pd++; if (e.pointerType === 'touch' && performance.now() - lastTouchT < 500) return; tapFrom(e.clientX, e.clientY, e.timeStamp); });
canvas.addEventListener('pointercancel', () => { INP.pc++; });
addEventListener('scroll', () => { if (scrollX || scrollY) scrollTo(0, 0); }, { passive: true });
addEventListener('touchend', () => { if (scrollX || scrollY) scrollTo(0, 0); }, { passive: true });
addEventListener('pointermove', (e) => { lastPtr = { x: e.clientX, y: e.clientY }; });
addEventListener('keydown', (e) => {
  if (e.repeat) return;
  if (e.code === 'Space') { e.preventDefault(); if (G.state === 'start') return startGame(); TB.stamp(e.timeStamp); try { tapAt(lastPtr.x, lastPtr.y); } finally { TB.stamp(null); } }
  else if (e.code === 'KeyM') toggleMute();
});

// ---------------- titan animation (titan.js: keyframed acts through per-joint springs) ----------------
// pd* = pauldron (rides the chest), sh* = upper arm (11-25 re-rig: the pauldron no longer spins with the arm)
const BONE_AREA = { head: 'head', jaw: 'head', neck: 'head', chest: 'chest', hips: 'chest', pdL: 'shoulderL', pdR: 'shoulderR', shL: 'armL', shR: 'armR', elL: 'armL', elR: 'armR', wrL: 'fistL', wrR: 'fistR' };
const areaOf = (bone) => BONE_AREA[bone] || (bone && bone.startsWith('rock') ? bone : 'chest');
function startAct(a, side) { const ts = titanState; ts.act = a; ts.actT = 0; ts.fired = false; ts.side = side || (Math.random() < .5 ? 1 : -1); }
// review hook (cutout-animation skill): __g.animAt('slamL', 1.3) pre-rolls 3 s of idle, simulates the act at 60 fps up to u, then FREEZES it
// there (springs included), so frame strips are exact. __g.animAt(null) resumes.
// hits = [[u, area, dir, strength], ...] replays hit flinches at those times (review videos of the flinch layer)
function animAt(act, u = 0, side = 1, t0 = 10, hits = null) {
  const ts = titanState, A = world.anim; if (!act) { ts.freeze = null; return; }
  G.pvNext = 1e9; A.ch = {}; A.fl = {}; A.reset?.(); ts.act = act === 'idle' ? null : act; ts.side = side; ts.freeze = { t: t0 + u, u };
  for (let i = -180; i < 0; i++) A.update(1 / 60, { act: null, u: 0, rage: 0, dormant: 0, t: t0 + i / 60, side }); // 3 s idle pre-roll: an act starts from the settled ready stance, not from the bind pose
  const n = Math.round(u * 60); for (let i = 0; i <= n; i++) {
    if (hits) for (const h of hits) if (Math.round(h[0] * 60) === i) A.flinch(h[1], h[2] || 1, h[3] || 1);
    A.update(i ? 1 / 60 : 0, { act: ts.act, u: i / 60, rage: 0, dormant: 0, t: t0 + i / 60, side }); }
  return { act, u, frames: n };
}
function poseTitan(dt, t) {
  const ts = titanState, a = ts.act;
  if (ts.freeze) { world.anim.update(0, { act: ts.act, u: ts.freeze.u, rage: 0, dormant: 0, t: ts.freeze.t, side: ts.side }); return; }
  if (a) { ts.actT += dt; const d = ACTS[a] || { dur: 2 };
    if (a === 'guard') { if (G.shield <= 0 && G.state !== 'preview') { ts.act = null; } }
    else if (ts.actT >= d.dur) ts.act = null; }
  world.anim.update(dt, { act: ts.act, u: ts.actT, rage: ts.rage, dormant: ts.dormant, t, side: ts.side });
}
// fist hits the cloud sea where it comes down (beside the titan, far from the hero): dust wall, debris, ring, distortion. No screen flash.
function slamFx(p) {
  A.sfx('slam'); shake(.25); titanState.slam = 1; // ambient: very light
  const x = p.x, z = p.z + 3; _v.set(x, 1, z);
  burst(_v, 60, 26, 'dust', 2.4); debris(_v, 14, 22); flashAt(_v.set(x, 1.5, z), 3, 26, .4, 1, .45, .6, { ring: .95 }); shock(_v, 40, .5, 1);
  world.water?.splash(p, 1.15); // water.js: crown + spout, droplets, foam/ripple rings, mist, refraction (flavour, no extra shake)
}

// ---------------- titan moves: AMBIENT FLAVOUR ONLY (user 11-25: "braindead game - no dodge, no HP, nothing to avoid") ----------------
// Slams, sweeps and rock throws make the titan feel alive and nothing else: no warning, no damage, no stun, no combo change,
// no hit-stop, no screen flash, nothing to react to. Slams hit the cloud sea at the fist, the sweep rakes dust off the clouds,
// a thrown rock flies toward the hero's area and either gets shattered in passing by his next slash or smashes harmlessly
// into the scenery beside the ledge. Triggers: a timer, rune breaks (roar), phase changes / enrage (rage slam).
const ATK = { slamL: { hit: ACTS.slamL.hit }, slamR: { hit: ACTS.slamR.hit }, swipe: { hit: ACTS.swipe.hit }, throw: { hit: 2.0, release: ACTS.throw.hit } }; // contact frames live in titan.js
const AT = { on: false };
function startAttack(kind) {
  if (AT.on) return;
  const side = kind === 'slamL' ? -1 : kind === 'slamR' ? 1 : Math.random() < .5 ? 1 : -1;
  startAct(kind, kind === 'swipe' ? side : 1);
  Object.assign(AT, { on: true, kind, t: 0, hit: ATK[kind].hit, resolved: false, released: false, shattered: false, side });
}
function fistSockOf(kind, side) { const h = world.hooks?.[kind], id = h ? (h.sock || (side > 0 ? h.sockL : h.sockR)) : null; // titan.json "hooks" (paw / head / tentacle sockets)
  return titanState.sockets.findIndex((s) => s.id === (id || (kind === 'throw' ? 'fistR' : kind === 'slamL' ? 'fistL' : kind === 'slamR' ? 'fistR' : side > 0 ? 'fistL' : 'fistR'))); }
function updateAttack(dt) {
  if (!AT.on) return; AT.t += dt;
  const fistSock = fistSockOf(AT.kind, AT.side);
  if (fistSock >= 0 && AT.t < AT.hit && Math.random() < .35) { socketWorld(fistSock, _v2); world.sparks.emit(_v2.x + rand(-2, 2), _v2.y + rand(-2, 2), _v2.z + 1, rand(-3, 3), rand(0, 4), 0, .4, 2.2, 1, .45, .3, 0); } // embers on the winding-up fist
  if (AT.kind === 'throw') {
    const R = world.rockP;
    if (!AT.released && AT.t >= ATK.throw.release) { AT.released = true; A.sfx('throw'); socketWorld(fistSock, AT.from = new THREE.Vector3()); R.visible = true;
      AT.to = new THREE.Vector3(world.heroHome.x + rand(1.8, 3.4), world.heroHome.y + .3, world.heroHome.z - 4); AT.hopN = S.hopN; } // lands in the scenery beside the hero, never on him
    if (AT.released && !AT.shattered) { const u = clamp((AT.t - ATK.throw.release) / (AT.hit - ATK.throw.release), 0, 1), e = u * u * (3 - 2 * u) * .4 + u * u * .6;
      R.position.lerpVectors(AT.from, AT.to, e); R.position.y += Math.sin(u * Math.PI) * 9;
      const s = lerp(7, 3.2, u); R.scale.set(s * R.userData.asp, -s, 1); /* part textures are flipY=false */ R.quaternion.copy(camera.quaternion); R.rotateZ(AT.t * 7);
      if (Math.random() < .8) world.sparks.emit(R.position.x, R.position.y, R.position.z, rand(-2, 2), rand(-2, 2), rand(-4, -1), .35, 1.6, 1, .5, .35, 0);
      // the hero's slashes shatter it in passing (any hop while it is in the air, past the first third of its flight)
      if (u > .3 && S.hopN !== AT.hopN) shatterRock(R.position); else if (u <= .3) AT.hopN = S.hopN; }
  }
  if (!AT.resolved && AT.t >= AT.hit) resolveAttack();
  if (AT.t >= AT.hit + .6) { AT.on = false; world.rockP.visible = false; }
}
function shatterRock(p) { // free flourish: rock bursts into pieces, a small pop number, no gameplay effect
  AT.shattered = true; world.rockP.visible = false; A.sfx('shatter', G.chain);
  burst(p, 40, 26, 'slash', 1.2); debris(p, 14, 24); flashAt(p, 1, 8, .2, .7, .55, 1, { ring: .9 }); shock(p, 14, .3, .6); pop('ROCK SHATTERED!', '', 1);
}
function resolveAttack() {
  AT.resolved = true; const kind = AT.kind, fs = fistSockOf(kind, AT.side);
  if (kind === 'slamL' || kind === 'slamR') { const p = fs >= 0 ? socketWorld(fs, new THREE.Vector3()) : new THREE.Vector3((kind === 'slamL' ? -1 : 1) * 12, 0, -30); slamFx(p); }
  else if (kind === 'swipe') { A.sfx('slam'); const p = fs >= 0 ? socketWorld(fs, new THREE.Vector3()) : new THREE.Vector3(AT.side * 12, 2, -30); p.y = Math.min(p.y, 4);
    for (let i = 0; i < 5; i++) burst(_v.set(p.x + AT.side * -i * 4, 1.5, p.z + 4), 14, 22, 'dust', 2); shock(p, 34, .45, .8);
    for (let i = 0; i < 3; i++) world.water?.splash(_v.set(p.x + AT.side * -i * 7 * (world.water.ws || 1), 0, p.z), .8 - i * .15, { wave: -AT.side }); } // sweep rakes a line of wave bursts across the sea
  else if (!AT.shattered) { const p = world.rockP.position.clone(); A.sfx('slam'); burst(p, 50, 22, 'dust', 1.6); debris(p, 14, 20); shock(p, 12, .35, .7); world.rockP.visible = false; } // harmless smash into the scenery
}

// ---------------- fight flow ----------------
function banner(t, sub) { const b = $('banner'); b.innerHTML = t + (sub ? `<small>${sub}</small>` : ''); b.className = ''; void b.offsetWidth; b.classList.add('show'); }
// ---------------- POPS: small punchy news plates (user 11-25: "more of those to make it feel like more is happening") ----------------
// Purple angular mini-plate, scale-in, ~0.8 s hold, fly-out, own rising sting. Max 2 on screen (2 slots stacked just above the combo
// meter, never over the tap area); the rest wait in a short queue (oldest dropped past 5). No hit-stop, no slow motion.
const POPQ = [], POPS = [0, 1, 2, 3].map(() => ({ el: null, until: 0 })); // 11-26 user: pills show together, stacked top -> bottom (4 slots)
function pop(text, sub = '', tier = 0, cls = '') { if (POPQ.length >= 5) POPQ.shift(); POPQ.push({ text, sub, tier, cls }); }
function updatePops() {
  const now = performance.now();
  for (let i = 0; i < POPS.length && POPQ.length; i++) { const sl = POPS[i]; if (now < sl.until) continue; const q = POPQ.shift(); // first free slot from the top
    if (!sl.el) { sl.el = document.createElement('div'); $('pops').appendChild(sl.el); }
    sl.el.className = `pp plate t${q.tier} slot${i} ${q.cls}`; sl.el.innerHTML = `<span><b>${q.text}</b>${q.sub ? `<small>${q.sub}</small>` : ''}</span>`;
    void sl.el.offsetWidth; sl.el.classList.add('show'); sl.until = now + 1300; A.sfx('sting', q.tier); } // 1.3 s = the slide-in, hold, slide-out (menu.css ppR)
}
// news triggers (fight only): combo milestones, best combo / personal best, damage milestones, ghost-board rank climbs, tap speed
const COMBO_NEWS = [[25, 'FRENZY', 1], [50, 'BLADE STORM', 2], [100, 'GODSPEED', 3], [200, 'SLASH GOD', 4]];
const DMG_NEWS = [[1e4, '10K!', 0], [1e5, '100K!', 2], [1e6, '1M!', 3], [1e7, '10M!', 4]];
const NEWS = { taps: [], rank: 99, rankT: 0, speedT: 0, bestC: false, bestS: false, ghosts: [],
  reset() { this.taps.length = 0; this.rankT = 1; this.speedT = 0; this.bestC = !(SAVE.bestCombo >= 10); this.bestS = !(SAVE.best > 0);
    this.rank = LB.merge(ghosts()).length + 1; },
  tick(dt) { this.speedT -= dt; this.rankT -= dt;
    if (!TB.ON && this.rankT <= 0) { this.rankT = 2.2; const r = LB.merge(ghosts()).filter((g) => g.shown > G.score).length + 1; if (r < this.rank && G.score > 0) { pop('RANK UP', '#' + r, r <= 3 ? 3 : r <= 10 ? 2 : 0); A.voice('rank'); } this.rank = r; } } };
function tapNews(c0, c1) {
  for (const [n, t, tier] of COMBO_NEWS) if (c0 < n && c1 >= n) { pop(t, 'x' + n, tier); if (world.hero.userData.to) superSlash(world.hero.userData.to, 1 + tier * .15); }
  if (!NEWS.bestC && c1 > SAVE.bestCombo) { NEWS.bestC = true; pop('NEW BEST COMBO!', 'x' + Math.floor(c1), 2); }
  const now = performance.now(), q = NEWS.taps; q.push(now); while (q.length && now - q[0] > 1000) q.shift();
  if (!portrait && q.length >= 10 && NEWS.speedT <= 0) { NEWS.speedT = 6; /* 11-26 phones: no tap-speed pop (clutter) */ pop(`${q.length} TAPS/SEC!`, '', q.length >= 15 ? 2 : 1); }
}
function scoreNews(a, b) {
  if (G.state !== 'fight') return;
  for (const [n, t, tier] of DMG_NEWS) if (a < n && b >= n) pop(t, 'DAMAGE', tier);
  if (!TB.ON && !NEWS.bestS && b > SAVE.best) { NEWS.bestS = true; pop('NEW PERSONAL BEST!', '', 3); A.voice('best'); }
}
function enterLobby() {
  if (world.heroHome0) { world.heroHome.copy(world.heroHome0); world.heroFace = 1; } // lobby: always the fixed step spot
  ensureTitan(); // titans/loader.js: today's titan (or ?titan=) is mounted while it waits under the sea
  EQ.clearTrial(); // 11-27 pre-fight ad blade (prefight.js): one fight only, the hero's own sword is back
  G.state = 'lobby'; G.lobbyT = LOBBY_S; G.score = 0; G.scoreShown = 0; G.chain = 0; G.retreat = 0; G.phase = 0; G.shield = 0; G.stun = 0; G.fightT = 0; G.wpHits = 0; G.slashes = 0; G.taps = 0;
  // 11-26: the titan waits UNDER the cloud sea (sink 1; after a fight it is already down there), the training dummy drops in
  titanState.dormant = 1; titanState.rage = 0; titanState.act = null; titanState.alpha = 1; titanState.sink = 1; G.rise = undefined; world.dummy?.restore(); $('titanName').textContent = TITANS[G.titanIdx]; $('lobbyName').textContent = TITANS[G.titanIdx];
  LB.mountLobby(); $('lobby').classList.remove('hidden'); $('results').classList.add('hidden'); $('shield').classList.add('hidden'); $('hud').classList.remove('armor'); setPhaseLabel('TRAINING DUMMY'); $('scoreLab').textContent = 'PRACTICE';
  // 11-26 lobby home HUD (menu.css): no timer / phase / combo bar / slash hint, icon row + FIGHT button; practice counter after the first hit
  G.practice = 0; const hd = $('hud'); hd.classList.add('lobby'); hd.classList.remove('hit'); $('menu').classList.remove('hidden'); MENU.updateBadges();
  $('tapHint').classList.toggle('hidden', !!SAVE.dummyHint); $('tapHint').classList.remove('gone');
  A.setMode('lobby'); world.wps.forEach((w) => { w.on = false; w.m.visible = false; }); document.body.classList.remove('cine');
  // the HUD was display:none behind the results, which froze the exit banner / queued pops mid-animation: clear them (no stale "THE TITAN RETREATS" in the lobby)
  $('banner').className = ''; POPQ.length = 0; POPS.forEach((s) => { s.until = 0; if (s.el) s.el.classList.remove('show'); });
  G.lobbyAge = 0; fightBtn(); restLine(); flushRun(); // CYCLE: no FIGHT button, one small "TITAN RISES IN m:ss" line; FREE: the FIGHT button
  DAILY.lobby(); // auto-opens the Daily Rewards once per day when a claim is open
  PUI.lobby(); // level-up / offline gains / winner reward popups (queued after the daily popup)
}
// FREE mode keeps the FIGHT button (user 11-26: "for now leave the fight button"); made here if index.html has none
function fightBtn() {
  let b = $('fightNow');
  if (!b && !CYCLE && $('lobby')) { b = document.createElement('button'); b.id = 'fightNow'; b.className = 'btn hot'; b.textContent = 'FIGHT'; $('lobby').appendChild(b); b.addEventListener('click', (e) => { e.stopPropagation(); A.sfx('click'); handover(); }); }
  if (b) b.classList.toggle('hidden', CYCLE); document.documentElement.classList.toggle('cycle', CYCLE); // menu.css: html.cycle hides it too
}
// 11-26 (user: "I don't need the titan countdown either"): no rest countdown; in CYCLE mode the titan just rises when the fight
// starts. #restLine stays empty (CSS hides :empty); LB.cycle().left still has the time for anything that wants it later.
function restLine() { const el = $('restLine'); if (el && el.textContent) el.textContent = ''; }
// ---- world-clock cycle (CYCLE mode) ----
// the player's damage in the current window, kept across app restarts: localStorage tt_run = { id (cycle), titan, score, taps, combo, runes, sent }
const RUN = { get() { try { return JSON.parse(localStorage.getItem('tt_run') || 'null'); } catch (e) { return null; } },
  put(r) { try { localStorage.setItem('tt_run', JSON.stringify(r)); } catch (e) {} } };
function saveRun() { if (!CYCLE || G.state !== 'fight' || G.cycleId == null) return; RUN.put({ id: G.cycleId, titan: G.titanIdx, score: Math.round(G.score), taps: G.taps | 0, combo: Math.floor(G.bestCombo || 0), runes: G.wpBroken | 0, sent: 0 }); }
// a run whose fight ended while the app was closed: send it within the server's grace (~2 min after the fight end)
function flushRun() {
  if (!CYCLE || !LB.ranked) return; const r = RUN.get(), c = LB.cycle(); if (!r || r.sent || !(r.score > 0)) return; // test clocks never send
  const end = (r.id * (LB.fightLen + LB.restLen) + LB.fightLen) * 1000; if (G.state === 'fight' && G.cycleId === r.id) return;
  if (LB.now() < end - 2000 || LB.now() > end + 115000 || (c.id === r.id && c.phase === 'fight')) return;
  r.sent = 1; RUN.put(r); LB.submit({ score: r.score, combo: r.combo, taps: r.taps, up: SAVE.up, fight: r.id, titan: r.titan }).catch(() => {});
}
// 11-27 daily rotation: the lobby swaps to the new titan at UTC midnight (or when the server clock corrects the day)
function dayTick() { if (G.state !== 'lobby') return; const i = titanIdxNow(); if (i === G.titanIdx) return; G.titanIdx = i; $('titanName').textContent = $('lobbyName').textContent = TITANS[i]; ensureTitan(); }
// fight starts by itself at the cycle start; opening the app (or coming back) mid-fight joins it with the time left
function cycleTick(dt) {
  dayTick();
  if (!CYCLE || G.state === 'start' || G.state === 'preview') return; const c = LB.cycle();
  if (G.state === 'lobby') { G.lobbyAge = (G.lobbyAge || 0) + dt; restLine();
    if (c.phase === 'fight') { if (INV.isOpen()) INV.close(); if (MENU.isOpen()) MENU.close(); if (DAILY.isOpen()) DAILY.close(); if ($('lbNick')) $('lbNick').classList.add('hidden'); handover(c); } }
  else if (G.state === 'results') { G.resT = (G.resT || 0) + dt;
    if ((c.phase === 'fight' && c.id !== G.cycleId) || (G.resT > RES_S && !INV.isOpen() && !MENU.isOpen())) lobbyBack(() => { $('hud').classList.remove('hidden'); G.titanIdx = titanIdxNow(); }); }
}
// SHORT intro (user 11-25: "focus on a million taps"; cinematics only at the titan's exit). The titan is already standing there
// (dormant in the lobby): rune ignites + roar (non-blocking act), a small name tag, FIGHT! pop, fight starts at 1.4 s. Any tap skips.
const INTRO = { ignite: .2, card: .25, fight: 1.1, end: 1.4 };
function startIntro() {
  G.state = 'intro'; G.introT = 0; G.introFx = {}; $('lobby').classList.add('hidden');
  world.wps.forEach((w) => { w.on = false; w.m.visible = false; w.label.style.opacity = 0; }); titanState.act = null; titanState.sink = 0; A.sfx('rumble');
  $('skip').classList.remove('hidden');
}
function updateIntro(dt) {
  const t = (G.introT += dt), F = G.introFx, ts = titanState;
  ts.dormant = t < INTRO.ignite ? 1 : damp(ts.dormant, 0, 8, dt);
  if (!F.ignite && t > INTRO.ignite) { F.ignite = 1; A.sfx('ignite'); ts.hit = 2; puppet.glowKick('b', 2.5, 2.5); puppet.glowKick('g', 2.2, 2.2); const a = rigJson.anchors.rune; puppet.point(a.bone, a.x, a.y, _v); titanGroup.localToWorld(_v); flashAt(_v, 2, 30, .6, .3, 1, 1, { ring: .95 }); burst(_v, 60, 30, 'wp', 1.8);
    startAct('roar'); A.sfx('roar'); shake(.5); const hd = _v.set(0, 0, 0); puppet.point('head', 0, -60, hd); titanGroup.localToWorld(hd); shock(hd, 90, .8, 1); }
  if (!F.card && t > INTRO.card) { F.card = 1; const c = $('nameCard'); $('ncName').textContent = TITANS[G.titanIdx]; $('ncSub').textContent = `TITAN ${SAVE.titans + 1}  -  ${FIGHT_S}s  -  TAP TAP TAP`; c.classList.remove('show'); void c.offsetWidth; c.classList.add('show'); A.sfx('card'); }
  if (!F.fight && t > INTRO.fight) { F.fight = 1; pop('FIGHT!', '', 3); A.sfx('go'); }
  if (t > INTRO.end) beginFight();
}
function skipIntro() { if (G.state !== 'intro') return; titanState.sink = 0; titanState.dormant = 0; if (!G.introFx.fight) { pop('FIGHT!', '', 3); A.sfx('go'); } beginFight(); }
function beginFight() {
  SAVE.introSeen = 1; save(); $('skip').classList.add('hidden'); document.body.classList.remove('cine');
  G.state = 'fight'; G.fightT = 0; G.score = 0; G.scoreShown = 0; G.phase = 0; G.chain = 0; G.coinsEarned = 0; G.bestCombo = 0; G.wpBroken = 0; G.buffT = 0; G.critRun = 0;
  G.taps = 0; G.saveT = 0; G.cycleId = CYCLE ? LB.cycle().id : null; window.S3A?.log('fight_start', { titan: TIX.ids[G.titanIdx] }); /* analytics (app only): no player ids or names */ // taps = fight taps only (server cap: 600 s at max rate)
  LB.startFight(G.titanIdx, TIX.n, G.cycleId); NEWS.reset(); liveReset();
  if (TB.ON) tbBegin();
  $('hud').classList.remove('lobby', 'hit'); $('tapHint').classList.add('hidden'); if (MENU.isOpen()) MENU.close(); // fight HUD: timer + phase, rank gauge, score, coins; the side circles stay (dimmed, menu.css body[data-st=fight])
  $('timer').firstElementChild.textContent = `${Math.floor(FIGHT_S / 60)}:${String(Math.floor(FIGHT_S % 60)).padStart(2, '0')}`;
  { const h = $('hint'); h.classList.remove('gone'); clearTimeout(G.hintT); G.hintT = setTimeout(() => h.classList.add('gone'), SAVE.titans ? 0 : 5000); } // phones (CSS): the hint shows only the first 5 s of the first fight
  $('scoreLab').textContent = 'DAMAGE'; titanState.dormant = 0; titanState.sink = 0; titanState.nextAct = MOTION.gap[0] * .6; A.setMode('fight'); A.voice('start'); setPhaseLabel('PHASE 1  -  ASSAULT');
}
function startFight() { handover(); } // kept for tools / __g
if (TB.ON) CUT.init({ renderer, canvas: $('gl'), sfx: (n) => A.sfx(n) });
// time board (timeboard.js): HP from the stats on the hero now (trial blade included). Nothing from the lobby comes along: no
// combo, no finisher / limit break still playing (either would take HP off before the clock).
function tbBegin() {
  CUT.stop(); G.cut = false;
  S.on = false; S.lim = null; S.queue = 0; S.limTot = 0; S.nextFin = COMBO_STEP;
  const o = EQ.ownStats(); // HP from your OWN gear: the stronger ad blade is a real speed boost
  TB.begin({ titan: G.titanIdx, stats: { tap: o.tap, fin: o.fin, crit: o.crit, critMul: o.critMul, wp: o.wp, comboG: .03 * o.combo },
    cfg: { gain: COMBO_GAIN, step: COMBO_STEP, runeHp: RUNE_HP, weakS: WEAK_S, chainMax: CHAIN_MAX }, limitMs: FIGHT_S * 1000, onKill: () => { if (G.state === 'fight') endFight(); } });
}
// SEAMLESS lobby -> fight (user 11-26: "there should be no jump to fight"): same shot, same camera, input never pauses. The fight
// starts at once (HUD swaps in place: PRACTICE -> DAMAGE, warm-up countdown -> fight timer, combo kept); the dummy bursts apart
// and its base sinks while the titan rises out of the cloud sea behind it over RISE_S (water churn from water.js), its rune
// ignites + roar near the top, small name tag + FIGHT! pop (pointer-events none). Taps hit the dummy pieces, then the titan.
const RISE_S = 1.35;
function handover(c) {
  if (G.state !== 'lobby') return;
  const chain = G.chain; $('lobby').classList.add('hidden'); world.dummy?.crumble(); A.sfx('rumble');
  if (DESC_ON && world.hero) return startDescent(chain, c); // ?descent=1: the hero leaps off the ledge and falls deeper first (fight starts at the end)
  if (BLACKOUT) return startBlackout(chain, c); // 11-27 default: fade to black, swap, fade in
  fightIn(c, chain);
  heroJumpIn(); // ?jumpin=1 only (11-27 user: not wanted by default): the hero jumps DOWN onto the platform and lands
}
// 11-27 BLACKOUT transition (user: "a full blackout is okay", replaces the descent cutscene by default): fight start = the dummy
// crumbles while the screen fades to black (BO.OUT); while black the lobby -> fight swap happens (dummy off, hero standing at his
// ledge home, camera snapped to the fight framing, fight begins with the titan sunk), then it fades back in (BO.IN) over the
// existing titan rise. One DOM div with a CSS opacity transition (no render pass). Taps while it goes black do nothing.
// ?blackout=0 = the old instant handover.
const BLACKOUT = Q.get('blackout') !== '0';
// 11-27 dojo lobby (dojo.js, ink style): results -> lobby goes through the same short blackout, the cave -> dojo swap happens while
// black (enterLobby flips G.state, dojo.js follows it). pre() runs at the swap. ?lobbybg=cave / other styles: instant, as before.
const DOJO_ON = Q.get('style') === 'ink' && Q.get('lobbybg') !== 'cave';
function lobbyBack(pre) {
  if (!DOJO_ON || !BLACKOUT) { pre?.(); enterLobby(); return; }
  if (BO.back) return; BO.back = 1; const el = boEl(); el.style.transitionDuration = BO.OUT + 's'; void el.offsetWidth; el.style.opacity = '1';
  setTimeout(() => { BO.back = 0; pre?.(); enterLobby(); requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transitionDuration = BO.IN + 's'; el.style.opacity = '0'; })); }, BO.OUT * 1000 + 40);
}
const BO = { t: 0, OUT: .3, IN: .35, chain: 0, cyc: false, el: null };
function boEl() { if (!BO.el) { const d = BO.el = document.createElement('div'); d.id = 'blackout';
    d.style.cssText = 'position:fixed;inset:0;background:#000;opacity:0;pointer-events:none;z-index:9999;transition:opacity .3s linear'; document.body.appendChild(d); } return BO.el; }
function startBlackout(chain, c) {
  G.state = 'blackout'; BO.t = 0; BO.chain = chain; BO.cyc = !!(CYCLE && c && c.id != null);
  titanState.act = null; world.wps.forEach((w) => { w.on = false; w.m.visible = false; });
  const el = boEl(); el.style.transitionDuration = BO.OUT + 's'; void el.offsetWidth; el.style.opacity = '1';
}
function updateBlackout(dt) {
  if ((BO.t += dt) < BO.OUT + .03) return; // fully black now: swap
  const d = world.dummy; if (d) { d.state = 'off'; d.root.visible = false; for (const ch of d.chips) { ch.life = 0; ch.m.visible = false; } }
  if (world.ret) cancelReturn(); world.heroAway = false; world.heroOld.visible = false; for (const m of world.clones) m.visible = false;
  CAM_FIGHT.k = CAM_FIGHT.on ? 1 : 0; // fight framing from the first visible frame
  fightIn(BO.cyc ? LB.cycle() : null, BO.chain);
  heroJumpIn(); // ?jumpin=1 only
  const el = boEl(); el.style.transitionDuration = BO.IN + 's'; el.style.opacity = '0';
}
function fightIn(c, chain) {
  beginFight(); G.chain = TB.ON ? 0 : chain; titanState.sink = 1; titanState.act = null; G.rise = 0; G.riseFx = {};
  world.wps.forEach((w) => { w.on = false; w.m.visible = false; w.cool = .4; });
  // CYCLE join in progress: the clock is past the cycle start -> same quick rise, then the time left, the phase it is in and
  // the damage already dealt in this window (tt_run, e.g. the app was closed and opened again)
  if (CYCLE && c && c.id != null) { G.fightT = c.t; const r = RUN.get();
    if (r && r.id === G.cycleId && r.titan === G.titanIdx) { G.score = G.scoreShown = r.score || 0; G.taps = r.taps || 0; G.bestCombo = r.combo || 0; G.wpBroken = r.runes || 0; } }
}
function updateRise(dt) {
  const t = (G.rise += dt), F = G.riseFx, ts = titanState, u = clamp(t / RISE_S, 0, 1);
  ts.sink = Math.pow(1 - u, 2.6); // fast out of the sea, eases into place
  if (u < 1 && Math.random() < .35 && ts.sockets.length) { socketWorld(Math.floor(Math.random() * ts.sockets.length), _v); debris(_v, 1, 8); }
  if (!F.card && t > .15) { F.card = 1; const c = $('nameCard'); $('ncName').textContent = TITANS[G.titanIdx]; $('ncSub').textContent = `TITAN ${SAVE.titans + 1}  -  ${TB.ON ? 'KILL IT FAST' : `${CYCLE ? mmss(Math.max(0, FIGHT_S - G.fightT)) : FIGHT_S + 's'}  -  TAP TAP TAP`}`; c.classList.remove('show'); void c.offsetWidth; c.classList.add('show'); A.sfx('card'); }
  if (!F.ignite && u > .72) { F.ignite = 1; A.sfx('ignite'); ts.hit = 2; puppet.glowKick('b', 2.5, 2.5); puppet.glowKick('g', 2.2, 2.2); const a = rigJson.anchors.rune; puppet.point(a.bone, a.x, a.y, _v); titanGroup.localToWorld(_v); flashAt(_v, 2, 30, .6, .3, 1, 1, { ring: .95 }); burst(_v, 60, 30, 'wp', 1.8);
    startAct('roar'); A.sfx('roar'); shake(.4); pop('FIGHT!', '', 3); A.sfx('go'); }
  if (u >= 1) { ts.sink = 0; G.rise = RISE_S; }
}
// ---------------- DESCENT cutscene (11-27, user approved the "cheap version": no new art) ----------------
// Lobby -> fight: the hero leaps off the ledge (0-.4 s) and the camera falls WITH him (.4-1.6 s): one clip-space fog veil (exists
// only while this plays) hides the arena; the ink ruins are redrawn over it by their descent copies (inkdeco.js) streaming UPWARD
// at their own speeds (black frame walls fastest, mid ruins, back ruins slowest; rows past the art fold into an endless band of
// it), the ledge + foreground props slide up out of view, dust motes + speed streaks rush up, fog thickens and it gets darker.
// Arrival (1.6-2.2 s): the layers decelerate back into place, the ledge rises from below, the veil lifts, the camera settles from
// above onto the fight framing and he drops onto the ledge (idle-return landing + dust). Then the fight starts (titan rise as
// before). A tap before the arrival skips to it; taps never attack here. Only with ?descent=1 (default = BLACKOUT above).
const DESC_ON = Q.get('descent') === '1'; // 11-27 user: blackout instead by default; the cutscene stays behind ?descent=1
const DESC = { on: false, t: 0, chain: 0, cyc: false, ret: false, ARR: 1.6, END: 2.2, J: [3.52, 3.08, 1.5], SJ: [.29, .331, .5], sp: 0, st: 0,
  scr: { x: 0, y: 0, z: 0 }, x0: 0, y0: 0, ly: 0, fy: 0, veil: null, hold: null }; // hold: test hook, freezes the clock at that time
const DSCU = SH.dsc || (SH.dsc = { value: new THREE.Vector4(), dark: { value: 0 }, meshes: [] }); // shared with inkdeco.js
// scroll of layer i (0 frame / screens, 1 mid ruins, 2 back ruins / art heights): sine ease over .22-1.95 s; it wraps by J
// once every visible row is folded (frame: 4 mirror periods; mid ruins: 1 + 4 band repeats, seamless; back: hidden by fog), so it ends at 0
function descOff(i, t) { const x = clamp((t - .22) / 1.73, 0, 1), s = .5 - .5 * Math.cos(Math.PI * x), J = DESC.J[i]; return s < DESC.SJ[i] ? -J * s : J * (1 - s); }
function viewH(z) { return 2 * Math.max(1, camera.position.z - z) * Math.tan(camera.fov * Math.PI / 360); }
function startDescent(chain, c) {
  G.state = 'descent'; DESC.on = true; DESC.t = 0; DESC.chain = chain; DESC.cyc = !!(CYCLE && c && c.id != null); DESC.ret = false; DESC.sp = DESC.st = 0;
  titanState.sink = 1; titanState.act = null; world.wps.forEach((w) => { w.on = false; w.m.visible = false; });
  if (world.ret) cancelReturn(); world.heroAway = false; world.heroOld.visible = false;
  const hero = world.hero, hs = hero.userData?.hs || world.heroH; toScreen(_v.copy(hero.position).setY(hero.position.y + hs * .5), DESC.scr); DESC.x0 = DESC.scr.x; DESC.y0 = DESC.scr.y;
  const E = world.env; DESC.ly = E.ledge ? E.ledge.position.y : 0; DESC.fy = E.ledgeFill ? E.ledgeFill.position.y : 0;
  for (const s of E.side) if (s.kind && s.kind !== 'mid') { s.ro0 ??= s.m.renderOrder; s.m.renderOrder = 344; } // foreground props go under the veil (they're depth-cut by the sea)
  descVeil(); DESC.veil.visible = true; for (const m of DSCU.meshes) m.visible = true;
  world.sparks.mesh.material.depthTest = false; // the rushing dust must not be cut by the (veiled) sea plane
  A.sfx('glide'); buzz(6);
}
function descVeil() {
  if (!DESC.veil) {
    DESC.veil = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.ShaderMaterial({ uniforms: { fog: SH.fogColor, a: { value: 0 }, dk: { value: 0 }, dsc: DSCU, ce: { value: 0 } }, transparent: true, depthTest: false, depthWrite: false,
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }',
      fragmentShader: `uniform vec3 fog; uniform float a; uniform float dk; uniform vec4 dsc; uniform float ce; varying vec2 vUv;
        void main(){ float y = vUv.y; vec3 c = mix(fog * mix(.3, .1, dk), fog * mix(.75, .4, dk), smoothstep(0., 1., y)); // light from above, the deep below
          float al = a * mix(1., .86, smoothstep(.35, 1., y)), cy = y - (1. - max(dsc.x, 0.)), ceil = ce * smoothstep(-.01, .01, cy) * smoothstep(.28, .2, cy); // arrival: a slab of dark rock above the
          gl_FragColor = vec4(mix(c, fog * .05, ceil), max(al, ceil)); }` }));                                   // frame's top slab (ink frame scroll)
    DESC.veil.renderOrder = 345; DESC.veil.frustumCulled = false; DESC.veil.visible = false; scene.add(DESC.veil); } // over the arena + mist (<= 320), under the ledge (350), ruin copies (346 / 347), hero, frame
}
// shader warm-up in the lobby (no compile hitch when the leap starts): veil + ruin copies drawn ONE frame at alpha 0, again whenever
// the ink layers are rebuilt (arena / water mode swap)
function descWarm() {
  if (DESC.on) return; if (DESC.warm === 1) { DESC.warm = 2; DESC.veil.visible = false; for (const m of DSCU.meshes) m.visible = false; return; }
  if (DESC.warm === 2 && DESC.wn === DSCU.meshes.length) return;
  descVeil(); DESC.warm = 1; DESC.wn = DSCU.meshes.length; DSCU.value.w = 0; DESC.veil.material.uniforms.a.value = 0; DESC.veil.visible = true; for (const m of DSCU.meshes) m.visible = true;
}
function updateDescent(dt) {
  const t = DESC.t = DESC.hold != null ? Math.min(DESC.t + dt, Math.max(DESC.t, DESC.hold)) : DESC.t + dt;
  const a = .93 * sstep(.12, .48, t) * (1 - sstep(1.55, 2, t)), dk = sstep(.4, 1.35, t) * (1 - sstep(1.5, 2.05, t));
  DSCU.value.set(descOff(0, t), descOff(1, t), descOff(2, t), a); DSCU.dark.value = dk;
  const vu = DESC.veil.material.uniforms; vu.a.value = a; vu.dk.value = dk; vu.ce.value = DSCU.meshes.length ? 1 : 0; // ceiling: ink frame only
  if (!DESC.ret && t >= DESC.ARR) { DESC.ret = true; startReturn(); if (world.ret) world.ret.drop = 1; } // he drops onto the ledge (no hop up first)
  if (t > .45 && t < 1.55) CAM.shake = Math.max(CAM.shake, .3); // wind buffeting
  const fall = sstep(.3, .6, t) * (1 - sstep(1.4, 1.7, t));
  if (fall > 0) { DESC.sp += dt * 150 * fall; // dust motes rushing up (sparks pool)
    while (DESC.sp >= 1) { DESC.sp--; const z = rand(-30, 5); screenToPlane(rand(0, W), Hh * rand(.75, 1.15), z, _v3); const c = rand(.45, .9);
      world.sparks.emit(_v3.x, _v3.y, z, 0, rand(30, 50), 0, rand(.45, .7), rand(.35, 1), .45 * c, .62 * c, .7 * c, -70); }
    DESC.st -= dt; if (DESC.st <= 0) { DESC.st = .045 / Math.max(.3, fall); descStreak(); } } // speed streaks (streak quad pool)
  if (t >= DESC.END && DESC.hold == null) endDescent();
}
function descStreak() {
  let m = null; for (const s of world.streaks) if (!s.visible) { m = s; break; } if (!m) return;
  const z = rand(-25, 3); screenToPlane(rand(.03, .97) * W, Hh * rand(.1, 1.05), z, _v3); const L = pxToWorld(rand(.15, .38) * Hh, _v3);
  m.visible = true; m.userData.t = 0; m.userData.dur = rand(.16, .26); m.position.copy(_v3); m.quaternion.copy(camera.quaternion); m.rotateZ(Math.PI / 2);
  m.scale.set(L, Math.max(.12, L * .03), 1); m.material.uniforms.c1.value.setRGB(.45, .65, .75);
}
// after env.update: the ledge + foreground props ride with the frame scroll (screens -> world at their depth)
function descentScene() {
  const E = world.env, f = DSCU.value.x;
  if (E.ledge) { const d = -f * viewH(E.ledge.position.z), up = Math.max(0, d); E.ledge.position.y = DESC.ly + d;
    if (E.ledgeFill) { E.ledgeFill.position.y = DESC.fy + d; if (up > 0) E.ledgeFill.visible = false; } } // leaving: the ledge's own underside shows, no filler column
  for (const s of E.side) if (s.kind && s.kind !== 'mid') s.m.position.y -= f * viewH(s.z);
}
// the hero before the landing: crouch, leap up off the ledge toward the screen centre (0-.42 s), then hang there falling with the camera
function descentHero(dt, t) {
  const hero = world.hero, x = DESC.t, u = clamp(x / .42, 0, 1), tex = x < .07 ? (T.land || T.hi) : (T.poses[1] || T.hi), face = world.heroFace || 1;
  const x1 = W * .5, y1 = Hh * .4; let sx, sy;
  if (x < .42) { sx = lerp(DESC.x0, x1, sstep(0, 1, u)); sy = lerp(DESC.y0, y1, 1 - Math.pow(1 - u, 2.2)); }
  else { const f = x - .42; sx = x1 + Math.sin(f * 4.2) * W * .03; sy = y1 + Math.sin(f * 2.6) * Hh * .012; }
  const ctr = screenToPlane(sx, sy, world.heroHome.z, _v3), H = pxToWorld(spritePx(tex), ctr), lp = Math.sin(Math.PI * u) * (x < .42 ? 1 : 0);
  const crouch = x < .07 ? .9 : 1, tilt = x < .42 ? -face * .14 * lp : Math.sin((x - .42) * 3.3) * .07;
  setSprite(hero, tex, H, face, _v.copy(ctr).setY(ctr.y - H * .5), tilt, 1 - .05 * lp, crouch * (1 + .1 * lp), 1);
  const ud = hero.userData; ud.h = ud.hs = H; ud.tex = tex; ud.flip = face; ud.asp = tex.image.width / tex.image.height;
  world.heroMat.uniforms.flash.value.setRGB(.2, .1, .34).multiplyScalar(.5 * sstep(.05, .4, x)); world.heroOld.visible = false;
  world.heroGlow.visible = x > .05; world.heroGlow.position.set(ctr.x, ctr.y, ctr.z - .5); world.heroGlow.quaternion.copy(camera.quaternion); world.heroGlow.scale.setScalar(H * 1.2); world.heroGlow.material.uniforms.fade.value = .16;
  if (x > .05 && Math.random() < .6) world.sparks.emit(ctr.x + rand(-.3, .3) * H, ctr.y + rand(-.4, .3) * H, ctr.z, rand(-.5, .5), rand(6, 12), 0, rand(.3, .5), rand(.4, .8), .75, .5, 1, -10); // air rushing past him
}
function skipDescent() { if (DESC.t < DESC.ARR) { DESC.t = DESC.ARR; DESC.hold = null; } } // tap: fast-forward to the arrival (never attacks)
function endDescent() {
  DESC.on = false; DESC.hold = null; DSCU.value.set(0, 0, 0, 0); DSCU.dark.value = 0; DESC.veil.visible = false; for (const m of DSCU.meshes) m.visible = false;
  world.sparks.mesh.material.depthTest = true;
  const E = world.env; if (E.ledge) E.ledge.position.y = DESC.ly; if (E.ledgeFill) E.ledgeFill.position.y = DESC.fy;
  for (const s of E.side) if (s.ro0 != null) s.m.renderOrder = s.ro0;
  fightIn(DESC.cyc ? LB.cycle() : null, DESC.chain);
}
// ?anim=NAME: loop one titan act for review (also rise / sink / flinchHead / flinchFist / flinchChest)
function updatePreview(dt) {
  const ts = titanState; G.pv = (G.pv || 0) + dt; ts.dormant = 0;
  if (ANIM === 'rise' || ANIM === 'sink') { const c = G.pv % 3.6, u = clamp(c / 2, 0, 1); ts.sink = ANIM === 'sink' ? u * u : 1 - (1 - Math.pow(1 - u, 3)); if (ANIM === 'rise' && u < 1 && Math.random() < .3) { const i = Math.floor(Math.random() * ts.sockets.length); socketWorld(i, _v); debris(_v, 1, 8); } }
  else if (ANIM.startsWith('flinch')) { if (G.pv > (G.pvNext || 0)) { G.pvNext = G.pv + 1.3; world.anim.flinch({ flinchHead: 'head', flinchFist: 'fistL', flinchChest: 'chest', flinchShoulder: 'shoulderR' }[ANIM] || 'chest', 1, 1); } }
  else if (!ts.act) { if (G.pv > (G.pvNext || 0)) { startAct(ANIM, 1); G.pvNext = G.pv + (ACTS[ANIM]?.dur || 2) + .6; } }
  if (ANIM === 'guard' && ts.act === 'guard' && ts.actT > 2.2) ts.act = null;
}
// 11-26 (user: "I don't need phases, those are stupid"): no assault / armor / enrage, the fight is one continuous window. The
// phase pill is always hidden (setPhaseLabel kept as a no-op hider for old callers); G.phase / G.shield / G.stun stay 0.
function setPhaseLabel() { const p = $('phase'); if (p) p.classList.add('hidden'); }
function updateFight(dt) {
  if (G.rise < RISE_S) updateRise(dt);
  // CYCLE: fight time = the world clock (the same for everyone; a hidden app keeps time), the fight ends with its window
  let over = false;
  if (CYCLE) { const c = LB.cycle(); over = c.id !== G.cycleId || c.phase !== 'fight'; G.fightT = over ? FIGHT_S : c.t; G.saveT -= dt; if (G.saveT <= 0) { G.saveT = 1; saveRun(); } }
  else if (TB.ON) { if (!(G.rise < RISE_S) || G.riseFx?.ignite) TB.start(); // clock: the FIGHT! cue (or the first hit before it, TB.counts)
    G.fightT = TB.elapsed() / 1000; TB.tick(G.score); }
  else G.fightT += dt;
  G.bestCombo = Math.max(G.bestCombo || 0, Math.floor(G.chain)); G.buffT = Math.max(0, (G.buffT || 0) - dt); NEWS.tick(dt); LB.tick(dt); updateLive(dt);
  // ambient titan moves (flavour only, nothing to react to). 11-26 subtle default (titan.js MOTION, titan.json "motion"): rare, one
  // every 25-40 s; ?motion=1 = the old 5-8 s. No phases (user 11-26), so no rage / guard / enrage slams.
  titanState.nextAct -= dt;
  if (titanState.nextAct <= 0 && !AT.on && (!titanState.act || titanState.act === 'idle') && (TB.ON || G.fightT < FIGHT_S - 3)) {
    const amb = world.ambient || ['slamL', 'slamR', 'swipe', 'throw', 'throw', 'roar'], k = amb[Math.floor(Math.random() * amb.length)];
    if (k === 'roar') { startAct('roar'); A.sfx('roar'); } else startAttack(k); titanState.nextAct = rand(...MOTION.gap); }
  const left = Math.max(0, FIGHT_S - G.fightT), tt = mmss(left); if (HUDT.timer !== tt) { HUDT.timer = tt; $('timer').firstElementChild.textContent = tt; } // 11-26 perf: once a second, not every frame
  if (!TB.ON && (G.fightT >= FIGHT_S || over)) { saveRun(); endFight(); } // time board: no limit, only the kill ends it (timeboard.js onKill)
  if (TB.ON && TB.killed() && G.state === 'fight') endFight(); // safety: with no time limit a dead titan must always end the fight
}
// retreat (~4.6 s): stagger -> roar -> sink back into the clouds -> results
function endFight() {
  // the ONE cinematic: slow motion at the start, slow camera push-in, letterbox, stagger -> roar -> sink, then results
  if (TB.ON && TB.killed()) { // 11-28 the kill = the screen-cut ending (cutend.js), then the results
    G.state = 'retreat'; G.retreat = 2; G.retFx = {}; G.cut = true; A.setMode('lobby'); S.on = false; shake(1.2); burst(_v.set(0, 20, -36), 90, 34, 'wp', 1.8);
    $('shield').classList.add('hidden'); $('hud').classList.remove('armor'); world.shield.visible = false; if (AT.on) { AT.on = false; world.rockP.visible = false; }
    world.wps.forEach((w) => { w.on = false; w.m.visible = false; w.label.style.opacity = 0; }); startAct('stagger'); // the finisher is live: the titan reels, every tap cuts
    CUT.start({ time: TB.resultText() }); return; }
  if (TB.ON) TB.timeout(G.score); const slain = false; // (a time-board fight only ends by a kill; this is the dev-tool path)
  G.state = 'retreat'; G.retreat = .001; A.setMode('lobby'); if (!slain) setTimeout(() => A.voice('exit'), 900); banner(slain ? 'TITAN SLAIN' : 'THE TITAN RETREATS', slain ? TB.resultText() : TB.ON ? `${TB.resultText()} HP REMOVED` : 'TIME'); S.on = false;
  if (slain) { shake(1.2); A.sfx('retreat'); burst(_v.set(0, 20, -36), 90, 34, 'wp', 1.8); } startAct('stagger'); $('shield').classList.add('hidden'); $('hud').classList.remove('armor'); world.shield.visible = false;
  if (AT.on) { AT.on = false; world.rockP.visible = false; }
  G.retFx = {}; document.body.classList.add('cine');
}
function updateRetreat(dt) {
  if (CUT.on()) { const done = CUT.update(Math.min(.05, dt));
    if (CUT.tapping() && !titanState.act) startAct('stagger');
    if (CUT.needsShot()) { world.hurt?.reset(); titanState.hit = 0; } // calm picture for the snapshot (no red hurt tint)
    if (CUT.drawing()) { titanState.sink = 1; titanState.act = null; } if (done) { showResults(); CUT.end(); } return; }
  const t = (G.retreat += dt), F = G.retFx, ts = titanState;
  const slain = TB.ON && TB.killed(), s0 = slain ? .9 : 2.6; // slain (time board): no roar, it goes under mid-stagger
  if (!slain && !F.roar && t > 1.2) { F.roar = 1; startAct('roar'); A.sfx('roar'); shake(1.2); }
  if (!F.sink && t > s0) { F.sink = 1; A.sfx(slain ? 'slam' : 'retreat'); burst(_v.set(0, 2, -34), 80, 26, 'dust', 3); }
  if (t > s0) { const u = clamp((t - s0) / 1.8, 0, 1); ts.sink = u * u; if (Math.random() < .3) { burst(_v.set(rand(-18, 18), 2, -34), 5, 12, 'dust', 2); } shake(.25); }
  if (t > s0 + 2) { document.body.classList.remove('cine'); showResults(); }
}
// painted results: rank, damage count-up, stats, coins flying into the counter, ghost leaderboard, Upgrades / Next titan
function showResults() {
  G.state = 'results'; const score = Math.round(G.score);
  // time board: board = kill times; rewards from the damage basis (a kill pays like the full fight, timeboard.js rewardBasis)
  const TR = TB.ON ? tbResult(score) : null, pay = TR ? TR.pay : { score, runes: G.wpBroken || 0, combo: G.bestCombo || 0, limits: G.slashes || 0 };
  const board = TR ? TR.board : makeBoard(score); const rank = TR ? TR.rank : board.meRank, n = TR ? TR.n : board.n;
  const newBest = TR ? TR.newBest : score > SAVE.best; if (newBest && !TR) SAVE.best = score;
  // 11-27 user "titan kill reward still too high" (score/250 gave thousands): economy plan §5 fight shards = 15 base + 5 per damage tier
  // (250K / 1M / 4M / 16M / 64M) + rank (top 1 +60, top 3 +40, top 10 +25, top half +10) + new best +20; charm bonus capped at +50%. Typical fight 35-50.
  const tiers = [250e3, 1e6, 4e6, 16e6, 64e6].filter((t) => pay.score >= t).length, bonus = rank === 1 ? 60 : rank <= 3 ? 40 : rank <= 10 ? 25 : rank <= n / 2 ? 10 : 0;
  const coins0_ = 15 + 5 * tiers + bonus + (newBest ? 20 : 0);
  const charm = Math.round(coins0_ * Math.min(.5, Math.max(0, EQ.S.coins - 1))), gk = GUILD.bonus(), gx = gk ? (coins0_ + charm) * gk + (+SAVE.gfrac || 0) : 0, gb = Math.floor(gx + 1e-9), coins = (coins0_ + charm + gb) * PASS.N; // charm: shard bonus, max +50%; ?pass=N game pass x N
  const PR = PUI.fightEnd({ ...pay, rank, n, titan: TIX.ids[G.titanIdx] }); window.S3A?.log('fight_end', { titan: TIX.ids[G.titanIdx], damage_tier: tiers }); // 11-27 XP + titan drops (drops.js; replaces EQ.rollDrop)
  if (gk) SAVE.gfrac = Math.max(0, gx - gb); // guild bonus: the part of a shard not paid yet
  const coins0 = SAVE.coins; SAVE.coins += coins; SAVE.titans++; save(); G.coinsEarned = coins;
  $('resTitan').textContent = TITANS[G.titanIdx] + (TR && TB.killed() ? ' SLAIN' : ' RETREATS'); $('resRankN').textContent = '#' + (TR ? TR.board.meRank : rank); $('resRankOf').textContent = `OF ${TR ? TR.board.n : n}`; $('live').classList.add('hidden'); $('resRankN').dataset.l = $('resRankN').textContent.length; // long ranks shrink to stay inside the medal
  const bestTag = TR ? (TR.improved ? 'NEW BEST TODAY' : '') : newBest ? 'NEW BEST' : '';
  $('resBest').textContent = bestTag; $('resBest').classList.toggle('hidden', !bestTag);
  if (TR) document.querySelector('#results .rmain small').textContent = TB.killed() ? 'THIS RUN' : 'TITAN HP REMOVED';
  SAVE.bestCombo = Math.max(SAVE.bestCombo || 0, G.bestCombo || 0);
  // 11-26 minimal results: the stats + coin breakdown move to PROFILE ("LAST FIGHT"), the full boards to RANKS (hud-menu.js)
  SAVE.last = { score, rank, n, combo: G.bestCombo || 0, runes: G.wpBroken || 0, taps: G.taps || 0, coins, dmgCoins: 15 + 5 * tiers, bonus, best: newBest ? 20 : 0, charm, hour: TR ? -1 : MENU.fightWindow(LB), titan: G.titanIdx, trial: EQ.trialId() || undefined, tb: TR ? TB.resultText() : undefined }; save(); // time board: hour -1 = never on the damage board
  // 11-27 ad-blade fights count on the board but are marked ⚡ (economy §8.6); submit_score has no field for it yet -> kept locally (TASKS.md)
  if (EQ.trialId()) { SAVE.trialLog = [...(SAVE.trialLog || []).slice(-29), { blade: EQ.trialId(), score, day: LB.day(), titan: G.titanIdx, t: Date.now() }]; save(); }
  // 3-row mini board: the player above, YOU, the player below (GHOST rows tagged); the online submit refreshes it
  const mini = (b) => { const me = b.findIndex((r) => r.me), i0 = clamp(me - 1, 0, Math.max(0, b.length - 3));
    return b.slice(i0, i0 + 3).map((r) => `<div class="lrow ${r.me ? 'me' : ''}${r.real ? '' : ' gh'}"><span>#${r.rank}</span><span>${r.me ? 'YOU' : r.name}${r.me || r.real ? '' : '<i>GHOST</i>'}</span><span>${fmt(r.score)}</span></div>`).join(''); };
  const hourBoard = () => { const b = makeBoard(score); $('resBoard').innerHTML = mini(b); $('resRankN').textContent = '#' + b.meRank; $('resRankOf').textContent = `OF ${b.n}`; SAVE.last.rank = b.meRank; SAVE.last.n = b.n; save(); };
  $('resBoard').innerHTML = TR ? TB.miniHtml(TR.board, TR.isBest, TR.best, TR.bestRank) : mini(board);
  G.resT = 0; // CYCLE: results -> rest after RES_S (cycleTick)
  if (CYCLE) { const r = RUN.get(); if (r && r.id === G.cycleId) { r.sent = 1; RUN.put(r); } }
  if (!TR) LB.submit({ score, combo: G.bestCombo, taps: G.taps, up: SAVE.up }).then((ok) => { G.lastSubmit = { ok, err: LB.lastError || null, fight: LB.fight }; if (ok && G.state === 'results') hourBoard(); });
  $('resRewards').innerHTML = `<span class="rcoins">+${fmt(coins)} <i class="gem">&#9670;</i></span>${gk ? `<span class="rguild">GUILD +${+(gk * 100).toFixed(1)}%</span>` : ''}${PR.html}${EQ.trialId() ? `<span class="rtrial" style="display:block;margin-top:4px;font:800 12px/1.2 var(--k-fd, Georgia, serif);letter-spacing:.1em;color:#ffd35a">&#9889; TRIAL BLADE &middot; ${EQ.def(EQ.trialId()).name.toUpperCase()}</span>` : ''}`;
  EQ.clearTrial(); // 11-27 the trial blade was for this fight only: own sword back from the results on
  $('resUpg').classList.toggle('hidden', !PR.drops.rolls.length);
  { const ch = $('resRewards').querySelector('.lchip'); if (ch) ch.onclick = () => { if (ch.classList.contains('pu-chest') && !ch.classList.contains('open')) { A.sfx('buy'); ch.classList.add('open'); ch.innerHTML = ch.querySelector('template').innerHTML; return; } A.sfx('click'); INV.open('gear'); }; } // 11-27 tap = open the chest, then tap = GEAR
  $('resCoinN').textContent = fmt(coins0);
  const t0r = { t: 0 }, el = $('resScore'), exact = TR ? TB.resultText() : ''; el.textContent = exact || '0'; // time board: the exact time, no count-up
  const tick = (now) => { const k = clamp((now - t0r.t - 500) / 1300, 0, 1), e = 1 - Math.pow(1 - k, 3); el.textContent = exact || fmt(score * e); if (k < 1 && G.state === 'results') requestAnimationFrame(tick); else if (G.state === 'results') { el.classList.add('done'); setTimeout(flyCoins, 350); } };
  const reveal = () => { const R = $('results'); R.classList.remove('hidden', 'go'); void R.offsetWidth; R.classList.add('go'); if (!G.cut) A.sfx('victory'); $('hud').classList.add('hidden'); // (the kill ending already played it)
    t0r.t = performance.now(); requestAnimationFrame(tick); }; // damage count-up, then coins fly from the reward line into the counter
  // 11-27 user: a chest drop comes BEFORE the score popup - a big closed chest, tap to open it, then the results
  const dr0 = PR.drops.rolls[0];
  if (dr0 && !CYCLE) { $('hud').classList.add('hidden'); const ch = $('resRewards').querySelector('.pu-chest'); if (ch) { ch.classList.add('open'); ch.innerHTML = ch.querySelector('template').innerHTML; }
    INV.chestFx(EQ.def(dr0.id), dr0.dup, EQ.def(dr0.id).rarity, 'TITAN CHEST', reveal); // 11-27 the shared chest animation (inventory-ui.js chestFx)
  } else reveal();
  function flyCoins() {
    if (G.state !== 'results') return; const from = ($('resRewards').querySelector('.rcoins') || $('resRewards')).getBoundingClientRect(), to = $('resCoin').getBoundingClientRect(), N = 14;
    for (let i = 0; i < N; i++) { const c = document.createElement('div'); c.className = 'flycoin'; c.textContent = '◆'; document.body.appendChild(c);
      const x0 = from.left + from.width * (.3 + Math.random() * .4), y0 = from.top + from.height * .5, x1 = to.left + to.width * .2, y1 = to.top + to.height * .5;
      c.animate([{ transform: `translate(${x0}px, ${y0}px) scale(.6)`, opacity: 0 }, { transform: `translate(${x0 + rand(-60, 60)}px, ${y0 - rand(40, 110)}px) scale(1.2)`, opacity: 1, offset: .35 }, { transform: `translate(${x1}px, ${y1}px) scale(.7)`, opacity: 1 }],
        { duration: 700 + i * 45, delay: i * 55, easing: 'cubic-bezier(.4,0,.6,1)', fill: 'forwards' }).onfinish = () => { c.remove(); A.sfx('coin'); const v = Math.round(coins0 + coins * (i + 1) / N); $('resCoinN').textContent = fmt(v); const rc = $('resCoin'); rc.classList.remove('pop'); void rc.offsetWidth; rc.classList.add('pop'); };
    }
  }
}
// time board: record this fight (best of the day kept locally) and what it pays
function tbResult(score) {
  const pay = TB.rewardBasis({ score, runes: G.wpBroken || 0, limits: G.slashes || 0, combo: G.bestCombo || 0 });
  const detail = { combo: Math.floor(G.bestCombo || 0), taps: G.taps || 0, weapon: EQ.weaponDef()?.name };
  return { ...TB.record({ day: LB.day(), titan: G.titanIdx, reward: pay.score, oldBest: SAVE.best, detail }), pay };
}
const GHOSTS = ['Vexa', 'Mordo', 'TapQueen', 'Zephyr9', 'Ironjaw', 'Lumi', 'Kestrel', 'Bramblewick', 'Saltmine', 'Pyxis', 'Grumble', 'Nyx', 'Halcyon', 'Brick', 'Tamsin', 'Rook', 'Juno', 'Cobalt', 'Mirage', 'Dax', 'Wisp', 'Tundra', 'Ember', 'Quill', 'Sable', 'Fenn', 'Orla', 'Pike', 'Riven', 'Soot'];
// Ghost board (offline demo scores, always labelled GHOST). Calibrated from the player's own damage model (user 11-25: ghosts
// were ~10x too low after the combo/finisher buffs): expDmg(rate) walks the fight in 0.25 s steps with the real formulas
// (hop / rune / finisher damage, combo growth, crit chance, phase multipliers, current upgrades) for a player tapping `rate`
// taps per second with some pauses. It is a closed-form estimate, not an auto-play sim. Ghost skill = taps/s, lognormal around
// 4.5/s: a decent run (~4-5 taps/s) lands mid-pack, a great run (~7/s) reaches the top 10, #1 needs ~9-10/s all fight.
function expDmg(rate, curve) { // curve (optional array) receives the running total every 0.25 s
  let tot = 0, chain = 0, fin = 0; const dt = .25, crit = 1 + critCh() * (EQ.S.critMul - 1), eff = .8, cg = comboG();
  for (let t = 0; t < FIGHT_S; t += dt) {
    const m = 1, n = rate * dt * eff; // no phases since 11-26 (no armor x0.3 / cracked x2 / enrage x1.5)
    chain = Math.min(CHAIN_MAX, chain + n);
    const hop = 120 * tapPow() * (1 + chain * cg), rune = 100 * tapPow() * EQ.S.wp * (4 + 30 * .25) * (1 + chain * cg);
    tot += n * (.35 * hop + .65 * rune) * crit * m * 1.15; // checked 11-25 against scripted runs (players hammer the runes): ~2-10K dmg/tap as combo grows
    fin += n; while (fin >= COMBO_STEP) { fin -= COMBO_STEP; tot += 5 * 520 * slashPow() * (1 + chain * .015) * 1.3 * crit * m; }
    if (curve) curve.push(tot);
  }
  return tot;
}
let GH = null, GHkey = '';
function ghosts() { // 49 ghosts for this titan + upgrade level (deterministic), with their bursty pacing
  const key = [G.titanIdx, SAVE.titans, EQ.sig(), FIGHT_S].join(); if (GH && GHkey === key) return GH;
  let s = 1234 + G.titanIdx * 77 + SAVE.titans * 13; const r = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const gauss = () => { let u = 0; for (let i = 0; i < 6; i++) u += r(); return (u - 3) / Math.sqrt(.5); };
  GH = []; for (let i = 0; i < 49; i++) { const rate = clamp(4.5 * Math.exp(gauss() * .33), 1.2, 10.5);
    const curve = [], k = .9 + r() * .2, tot = expDmg(rate, curve); GH.push({ name: GHOSTS[i % GHOSTS.length] + (i >= GHOSTS.length || r() < .35 ? Math.floor(r() * 900 + 10) : ''), score: Math.round(tot * k), k, curve, rate, step: .35 + r() * 1.4, ph: r() * 2, shown: 0 }); }
  GHkey = key; return GH;
}
function ghostAt(g, t) { // bursty, monotone: the ghost's damage jumps every `step` s along its own modelled run
  const tq = clamp(Math.floor((t + g.ph) / g.step) * g.step - g.ph, 0, FIGHT_S), i = Math.floor(tq / .25); return i <= 0 ? 0 : g.curve[Math.min(i, g.curve.length) - 1] * g.k; // same model as their final score
}
function makeBoard(score) {
  return LB.board(ghosts(), score); // [{ name, score, me, real, rank }] + .meRank / .n
}
// GHOST SLASHERS (user 11-25): 3 (phones) / 4 other hero figures, ~65% of our hero, tinted cyan / gold / crimson / green, alpha .6,
// drawn under our hero. Each is tied to one ghost of the live board. GROUNDED (user: "they stay floating, which is weird"): between
// bursts each stands on its own PERCH (the foreground ledge away from our hero, or the titan's pauldrons, following the bone) with
// idle breathing; a burst = blink off the perch -> 2-5 quick strike hops at the titan's edges (airborne only while striking) -> blink
// back with a landing squash + cape settle. A perch out of view = fade out between bursts. When the ticker announces a big ghost hit,
// that ghost's slasher does a big strike + name tag. Light arcs only, no shake, no sound, no distortion, capped particles.
const GHOST_FX = Q.get('ghostfx') === '1', RANK_METER = Q.get('rankmeter') === '1';
if (RANK_METER) document.documentElement.classList.add('rankmeter'); if (GHOST_FX) document.documentElement.classList.add('ghostfx');
const GHOST_SLASHERS = Q.get('ghosts') === '1'; // user 11-25: ghost slasher figures disabled for now (code kept); ?ghosts=1 turns them on
const GS_COL = [[.45, 1, 1.15], [1.2, .92, .4], [1.2, .38, .42], [.45, 1.15, .5]];
const GS_SOCKS = ['fistL', 'fistR', 'foreL', 'foreR', 'pauldronL', 'pauldronR', 'rock1', 'rock2', 'rock3'];
function gsPerches() { // [{ kind, sock?, sx }]: ledge spots on the far side from our hero + both pauldrons
  const hx = toScreen(world.heroHome, {}).x, L = [];
  for (const f of [.55, .7, .86, .3, .14]) { const x = W * f; if (Math.abs(x - hx) > W * .2) L.push({ kind: 'ledge', sx: x }); }
  for (const id of ['pauldronL', 'pauldronR']) { const i = titanState.sockets.findIndex((s) => s.id === id); if (i >= 0) L.push({ kind: 'sock', sock: i }); }
  return L;
}
function perchFoot(g, out) { // world foot point + screen pos of this slasher's perch (null if off-screen)
  const P = g.perch; if (!P) return null;
  if (P.kind === 'sock') { socketWorld(P.sock, out); const s = toScreen(out, {}); out.z += 3; const lift = pxToWorld(spritePx(T.hi) * .65 * .12, out); out.y += lift; return s.x > 20 && s.x < W - 20 && s.y > 120 && s.y < Hh - 80 ? out : null; }
  const fy = toScreen(world.heroHome, {}).y; return screenToPlane(P.sx, fy, world.heroHome.z - .6, out);
}
function gsSetSprite(g, tex, foot, hgt, flip, sx, sy, tilt) { const M = g.m, asp = tex.image.width / tex.image.height; M.material.uniforms.map.value = tex; M.position.copy(foot); M.quaternion.copy(camera.quaternion); if (tilt) M.rotateZ(tilt); M.scale.set(hgt * asp * flip * sx, hgt * sy, 1); }
function gsTint(g, a) { const col = g.col, mu = g.m.material.uniforms; mu.tint.value.setRGB(col[0] * .75, col[1] * .75, col[2] * .75); mu.flash.value.setRGB(col[0] * .22, col[1] * .22, col[2] * .22); mu.alpha.value = a; mu.cut.value = -2; }
function gsAfterimage(g) { const M = g.m; if (!M.visible) return; const A_ = g.ai; A_.position.copy(M.position); A_.quaternion.copy(M.quaternion); A_.scale.copy(M.scale); A_.material.uniforms.map.value = M.material.uniforms.map.value; A_.material.uniforms.tint.value.copy(M.material.uniforms.tint.value); A_.visible = true; g.aiL = .4; }
function slasherHop(g, big, amt) {
  const ids = titanState.sockets.map((s, i) => (GS_SOCKS.includes(s.id) ? i : -1)).filter((i) => i >= 0); if (!ids.length) return;
  const tp = socketWorld(ids[Math.floor(Math.random() * ids.length)], new THREE.Vector3()), ts = toScreen(tp, {});
  const pi = 1 + Math.floor(Math.random() * 4), tex = T.poses[pi] || T.hs, asp = tex.image.width / tex.image.height, hp = spritePx(tex) * .65, hw = hp * asp;
  let dir = ts.x < W / 2 ? -1 : 1; // outward from the screen centre: they fight at the titan's edges
  const hs = world.heroAway ? toScreen(_v.copy(world.hero.position).setY(world.hero.position.y + Math.abs(world.hero.scale.y) * .5), {}) : null;
  let cx = ts.x + dir * (hw * .45 + rand(6, 30)); if (hs && Math.hypot(hs.x - cx, hs.y - ts.y) < hw) { dir = -dir; cx = ts.x + dir * (hw * .45 + rand(6, 30)); } // not on our hero's spot
  cx = clamp(cx, hw * .4, W - hw * .4); const cy = clamp(ts.y + rand(-.25, .25) * hp, 130 + hp * .5, Hh * .72);
  const c = screenToPlane(cx, cy, -31), h = pxToWorld(hp, c), col = g.col;
  const from = g.m.visible ? _v2.copy(g.m.position).setY(g.m.position.y + Math.abs(g.m.scale.y) * .5) : null; gsAfterimage(g);
  gsTint(g, .62); gsSetSprite(g, tex, _v.set(c.x, c.y - h * .5, c.z), h, (tp.x >= c.x ? 1 : -1) * (POSE_FACE[pi] || 1), 1, 1, 0); g.m.visible = true; g.mode = 'strike'; g.hold = .22;
  const ap = screenToPlane(ts.x, ts.y, -34), am = spawnArc(ap, Math.min(W, Hh) * (big ? .4 : .26), Math.atan2(-(ts.y - cy), ts.x - cx) + Math.PI / 2, Math.random() < .5, big ? .3 : .22, 'light');
  am.userData.amp = big ? .9 : .55; am.material.uniforms.c1.value.setRGB(col[0] * .9, col[1] * .9, col[2] * .9); am.material.uniforms.c2.value.setRGB(Math.min(1, col[0] * .6 + .5), Math.min(1, col[1] * .6 + .5), Math.min(1, col[2] * .6 + .5));
  for (let k = 0; k < (big ? 10 : 4); k++) world.sparks.emit(tp.x, tp.y, tp.z + 1, rand(-6, 6), rand(-4, 6), rand(-1, 1), .35, big ? 1.1 : .8, col[0] * .8, col[1] * .8, col[2] * .8, 2);
  const gh = g.ghost; number(tp, fmt(amt || (gh ? gh.score / Math.max(1, FIGHT_S * gh.rate) * rand(.6, 2) : 300)), (big ? 'gsn big gc' : 'gsn gc') + g.i);
  if (big) g.labT = 1.4;
}
function gsLand(g) { // blink back to the perch: afterimage at the strike spot, landing squash, cape settle
  gsAfterimage(g); g.mode = 'perch'; g.landT = 0; const f = perchFoot(g, _v3); if (!f) { g.m.visible = false; return; }
  const top = toScreen(_v2.copy(f).setY(f.y + 1), {}); const col = g.col; for (let k = 0; k < 6; k++) world.sparks.emit(f.x + rand(-.4, .4), f.y + .1, f.z, rand(-3, 3), rand(.5, 2), 0, .3, .7, col[0] * .8, col[1] * .8, col[2] * .8, 3);
}
function updateSlashers(dt) {
  const on = G.state === 'fight';
  for (const g of world.gs) {
    if (!on) { if (g.m.visible || g.ai.visible) { g.m.visible = g.ai.visible = false; g.lab.style.opacity = 0; } continue; }
    // burst scheduler: perch -> 2-5 strike hops -> back to the perch
    g.t -= dt;
    if (g.t <= 0) { if (g.burst > 0) { slasherHop(g, false); g.burst--; g.t = rand(.16, .3); } else if (g.mode === 'strike') { gsLand(g); g.t = rand(1.2, 3.2); g.burst = Math.floor(rand(2, 6)); } else { g.burst = Math.floor(rand(2, 6)); g.t = 0; } }
    if (g.mode === 'perch') { // grounded idle on the perch: breathing, landing squash + cape-settle tilt, fade if the perch is out of view
      const f = perchFoot(g, _v3); g.landT = (g.landT || 0) + dt; const u = g.landT;
      if (!f) { g.m.material.uniforms.alpha.value = Math.max(0, g.m.material.uniforms.alpha.value - dt * 3); g.m.visible = g.m.material.uniforms.alpha.value > 0; }
      else { const hgt = pxToWorld(spritePx(T.hi) * .65, f), squash = .1 * Math.exp(-u * 9) * Math.cos(u * 22), br = .012 * Math.sin(G.t * 1.7 + g.i), tilt = .06 * Math.exp(-u * 5) * Math.sin(u * 13);
        const face = toScreen(f, {}).x < W / 2 ? 1 : -1; gsTint(g, Math.min(.62, u * 4)); gsSetSprite(g, T.hi, f, hgt, face, 1 + squash * .6, (1 - squash) * (1 + br), tilt); g.m.visible = true; } }
    else { g.hold -= dt; g.m.quaternion.copy(camera.quaternion); }
    g.ai.quaternion.copy(camera.quaternion);
    if (g.ai.visible) { g.aiL -= dt; g.ai.material.uniforms.alpha.value = Math.max(0, g.aiL / .4) * .28; if (g.aiL <= 0) g.ai.visible = false; }
    g.labT = Math.max(0, g.labT - dt); const lo = g.labT > 0 ? Math.min(1, g.labT * 3) : 0;
    if (lo > 0 || g.lab.style.opacity !== '0') { const top = toScreen(_v.copy(g.m.position).setY(g.m.position.y + Math.abs(g.m.scale.y)), {}); const nm = g.ghost ? g.ghost.name : ''; if (g.labTxt !== nm) { g.labTxt = nm; g.lab.textContent = nm; } g.lab.style.opacity = lo; /* 11-26 perf: text only on change */ g.lab.style.translate = `${top.x}px ${top.y - 6}px`; }
  }
}
// LIVE mini-board during the fight (same ghosts as the results board). Desktop: top 3 + the rows around YOU; phones: YOUR RANK
// + the player just above with the gap. Updated 4x/s, values tick up between updates. Also faint cyan ghost slashes on the titan
// and a corner ticker for big ghost hits. All pointer-events none, nothing to react to.
const LIVE = { t: 0, rank: 0, slashT: 1, tickT: 4 };
function liveReset() { const gs = ghosts().slice().sort((a, b) => b.score - a.score); const per = gsPerches().sort(() => Math.random() - .5); world.gs.forEach((g, i) => { g.ghost = gs[[3, 12, 24, 36][i] || i]; g.perch = per[i % per.length]; g.mode = 'perch'; g.landT = 0; g.burst = 0; g.t = rand(.8, 2.5); g.m.material.uniforms.alpha.value = 0; }); LIVE.t = 0; LIVE.rank = 0; TK.max = 1; TK.prev.clear(); TK.lastMe = 0; LIVE.slashT = 1; LIVE.tickT = 5; ghosts().forEach((g) => { g.shown = 0; }); $('live').classList.remove('hidden'); }
// 11-26 RANK TRACK (menu.css #track): a full-width strip, x = damage on a soft max that only grows (leader x1.08), one dot per
// rival (ghosts dimmer, top 3 gold / silver / bronze), YOU = the big marker with your rank. Passing a dot pops it, the rank rolls,
// a short tick plays (+ the RANK UP pop from NEWS). Dots are pooled spans; CSS transitions do the smoothing between 0.25 s updates.
const TK = { dots: [], max: 1, prev: new Map(), w: 0 };
addEventListener('resize', () => { TK.w = 0; }); // track width for the px translates (updateTrack)
function updateTrack(rows, me, up) {
  const box = $('tkDots'); if (!box) return;
  const top = rows.length ? rows[0].v : 0; TK.max = Math.max(TK.max, top * 1.08, G.score * 1.08, 1000);
  // 11-26 perf: positions as `translate` in px (compositor-only transitions, menu.css) instead of `left` %, whose 0.25 s CSS
  // transitions re-ran layout on every frame of the fight. Track width measured once (re-measured after a resize).
  if (!TK.w) TK.w = box.getBoundingClientRect().width;
  const X = (v) => `${(clamp(v / TK.max, 0, 1) * (TK.w || 300)).toFixed(1)}px 0`, others = rows.filter((r) => !r.me);
  while (TK.dots.length < others.length) { const d = document.createElement('i'); box.appendChild(d); TK.dots.push(d); }
  TK.dots.forEach((d, i) => { const r = others[i]; if (!r) { if (d.style.display !== 'none') d.style.display = 'none'; return; } if (d.style.display) d.style.display = '';
    const rank = rows.indexOf(r) + 1, was = TK.prev.get(r.name), passed = was != null && was > TK.lastMe && r.v <= G.score;
    const cn = (r.gh ? 'gh' : '') + (rank <= 3 ? ' t' + rank : '') + (passed ? ' pass' : ''); if (d.className !== cn) d.className = cn; d.style.translate = X(r.v); TK.prev.set(r.name, r.v); });
  TK.lastMe = G.score;
  const m = $('tkMe'); m.style.translate = X(G.score); { const rn = '#' + (me + 1); if (TK.rn !== rn) { TK.rn = rn; $('tkN').textContent = rn; } }
  if (up) { m.classList.remove('roll'); void m.offsetWidth; m.classList.add('roll'); A.sfx('tick'); }
  const above = me > 0 ? rows[me - 1] : null, tag = $('tkTag');
  const k3 = (v) => (v >= 1e9 ? (v / 1e9).toFixed(2) + 'B' : v >= 1e6 ? (v / 1e6).toFixed(v >= 1e7 ? 1 : 2) + 'M' : v >= 1e4 ? Math.round(v / 1e3) + 'K' : fmt(v));
  // 11-26 legibility: end labels under the line, "0" at the left, crown + the top score (#1) at the right (menu.css .tkEnd)
  const tr = $('track'); if (tr && !TK.ends) { TK.ends = ['tkL', 'tkR'].map((id) => { const e = document.createElement('b'); e.id = id; e.className = 'tkEnd'; tr.appendChild(e); return e; }); TK.ends[0].textContent = '0'; }
  if (TK.ends) { const tt = `<i>&#9819;</i>${k3(Math.max(top, G.score))}`; if (TK.ends[1].innerHTML !== tt) TK.ends[1].innerHTML = tt; }
  if (above) { tag.style.display = ''; tag.style.translate = X(above.v); { const p = clamp(above.v / TK.max, 0, 1) * 100; tag.style.transform = `translateX(-${p.toFixed(1)}%)`; tag.style.setProperty('--ax', p.toFixed(1) + '%'); } /* stays on screen at both ends; the arrow follows the dot */ tag.innerHTML = `${above.name}${above.gh ? '<i>GHOST</i>' : ''} <em>+${k3(above.v - G.score)}</em>`; } else tag.style.display = 'none';
}
function updateLive(dt) {
  if (TB.ON) return; // the live damage ranking means nothing on the time board
  const gs = ghosts(), t = G.fightT;
  for (const g of gs) { const tg = ghostAt(g, t); g.shown = g.shown + (tg - g.shown) * (1 - Math.exp(-dt * 6)); }
  // faint ghost slashes + small cyan numbers on the titan (11-26 user: "remove the ghost" - off; ?ghostfx=1 brings them + the ticker back)
  LIVE.slashT -= dt; if (GHOST_FX && LIVE.slashT <= 0 && titanState.sockets.length) { LIVE.slashT = rand(.7, 1.6); const g = gs[Math.floor(Math.random() * gs.length)];
    const p = socketWorld(Math.floor(Math.random() * titanState.sockets.length), new THREE.Vector3()); p.x += rand(-3, 3); p.y += rand(-3, 3);
    const sp = toScreen(p, {}), ap = screenToPlane(sp.x, sp.y, -34); const m = spawnArc(ap, Math.min(W, Hh) * .2, rand(0, 6.283), Math.random() < .5, .26, 'light');
    m.userData.amp = .3; m.material.uniforms.c1.value.setRGB(.4, .9, 1); m.material.uniforms.c2.value.setRGB(.8, 1, 1);
    if (Math.random() < .6) number(p, fmt(g.score / Math.max(1, FIGHT_S * g.rate) * rand(.6, 2.4)), 'ghost'); }
  LIVE.tickT -= dt; if (GHOST_FX && LIVE.tickT <= 0) { LIVE.tickT = rand(5, 9); const top = gs.slice().sort((a, b) => b.shown - a.shown).slice(0, 15), sl = world.gs.length && Math.random() < .75 ? world.gs[Math.floor(Math.random() * world.gs.length)] : null;
    const g = sl && sl.ghost ? sl.ghost : top[Math.floor(Math.random() * top.length)], big = g.score * rand(.012, .03); if (sl && sl.ghost) slasherHop(sl, true, big);
    const el = $('ticker'); el.innerHTML = `<b>${g.name}</b> dealt ${fmt(big)}!<i>GHOST</i>`; el.classList.remove('show'); void el.offsetWidth; el.classList.add('show'); }
  LIVE.t -= dt; if (LIVE.t > 0) return; LIVE.t = .25;
  const rows = LB.merge(gs).map((g) => ({ name: g.name, v: g.shown, gh: !g.real })); rows.push({ name: 'YOU', v: G.score, me: true }); rows.sort((a, b) => b.v - a.v);
  const me = rows.findIndex((r) => r.me), up = LIVE.rank && me + 1 < LIVE.rank; LIVE.rank = me + 1;
  const show = [...new Set([0, 1, 2, me - 2, me - 1, me, me + 1, me + 2].filter((i) => i >= 0 && i < rows.length))].sort((a, b) => a - b); let prev = -1; const h = [];
  for (const i of show) { if (prev >= 0 && i > prev + 1) h.push('<div class="gap">...</div>'); const r = rows[i]; h.push(`<div class="lv${r.me ? ' me' + (up ? ' up' : '') : ''}${r.gh ? ' gh' : ''}"><span>#${i + 1}</span><span>${r.name}</span><span>${fmt(r.v)}</span></div>`); prev = i; }
  $('lvRows').innerHTML = h.join('');
  // 11-26 RANK GAUGE (user: "I need to see the rank during battle"; picked the dial): big rank in a painted medallion, the gold
  // ring fills as your damage closes the gap to the player above (0 = just passed the one below), "next: NAME" under it.
  // Overtake: burst + the number rolls to the new rank + the ring resets (plus the RANK UP pop from NEWS).
  if (RANK_METER) updateTrack(rows, me, up); // 11-26 user: "we don't need the rank meter anymore" (hidden; ?rankmeter=1) - the rank still counts for the results
}

// ---------------- upgrades ----------------
function renderUpg() {
  $('upgCoins').textContent = fmt(SAVE.coins);
  $('upgRows').innerHTML = Object.entries(UP).map(([k, u]) => { const l = SAVE.up[k], c = u.cost(l); return `<div class="urow"><div><b>${u.name}  LV ${l}</b><em>${u.desc(l)}  >  ${u.desc(l + 1)}</em></div><button class="btn hot" data-k="${k}" ${SAVE.coins < c ? 'disabled' : ''}><i class="gem">&#9670;</i> ${fmt(c)}</button></div>`; }).join('');
  document.querySelectorAll('#upgRows button').forEach((b) => b.onclick = () => { const k = b.dataset.k, c = UP[k].cost(SAVE.up[k]); if (SAVE.coins < c) { A.sfx('deny'); return; } SAVE.coins -= c; SAVE.up[k]++; save(); A.sfx('buy'); renderUpg(); coinHud(); });
}
function coinHud() { $('coinN').textContent = fmt(SAVE.coins); }
function toggleMute() { A.setMuted(!A.isMuted()); }

// ---------------- main loop ----------------
let last = performance.now(), frames = 0;
G.hitstop = 0;
const post_ = { bloom: .85, chroma: 0, flash: [0, 0, 0], vig: .55, sat: 1.08 };
post.flash = post_.flash; Object.defineProperty(post, 'chroma', { get: () => post_.chroma, set: (v) => { post_.chroma = v; } });
let botT = 0;
const DEB_TMP = { dm: new THREE.Matrix4(), q: new THREE.Quaternion(), e: new THREE.Euler(), sc: new THREE.Vector3() };
const FRC = { n: -1, cand: [], list: [] }; // inkdeco clip-space frame meshes drawn after the post chain (frame(), 11-27 PERF PASS cache)
function frame(now) {
  requestAnimationFrame(frame);
  if (!puppet || document.hidden) return; // hidden: no work at all (rAF normally stops anyway)
  if (TB.ON && TB.paused()) TB.resume(); // frames run again = the app is back (a missed resume event can't leave the clock stopped)
  if (CAP.fps < 60) { const iv = 1000 / CAP.fps; CAP.acc += now - (CAP.prev || now); CAP.prev = now; if (CAP.acc < iv - 4) return; CAP.acc = Math.min(CAP.acc - iv, iv); } // frame cap: skip this vsync
  else CAP.prev = now;
  if (!CAP.upWin) CAP.upWin = now + 30000; // phones may only step UP the tier in the first 30 s of frames (thermal: see gfxMonitor)
  gfxMonitor(now - last); /* auto quality (11-26: adaptive tiers, see the graphics quality block) */
  let dt = Math.min(.05, (now - last) / 1000); last = now; frames++; NFX.begin(); /* WebGL numbers: immediate mode, drawn after the post chain */
  if (G.hitstop > 0) { G.hitstop -= dt; dt *= .05; }
  const sdt = dt * (G.state === 'retreat' ? lerp(.45, 1, clamp((G.retreat - .3) / 1.4, 0, 1)) : 1); // slow motion ONLY in the exit cinematic
  G.t += sdt; SH.time.value = G.t; const t = G.t;

  // state
  cycleTick(dt); // CYCLE mode: world-clock fight start / join in progress / results -> rest
  if (G.state === 'lobby') {
    // 11-26: no warm-up countdown (free play on the dummy until FIGHT); ?lobby=S / ?auto=1 still auto-start for tests + recordings
    if (LOBBY_AUTO && !INV.isOpen() && !DAILY.isOpen() && !MENU.isOpen()) { G.lobbyT -= sdt; if (G.lobbyT <= 0) handover(); }
    MENU.tick(sdt);
  } else if (G.state === 'fight') updateFight(sdt);
  else if (G.state === 'intro') updateIntro(sdt);
  else if (G.state === 'descent') updateDescent(sdt);
  else if (G.state === 'blackout') updateBlackout(dt);
  if (DESC_ON && G.state === 'lobby' && DESC.warm !== 2 | DESC.wn !== DSCU.meshes.length) descWarm();
  else if (G.state === 'retreat') updateRetreat(sdt);
  else if (G.state === 'preview') updatePreview(sdt);
  updateAttack(sdt);
  if (G.chain > 0 && !S.on && G.t - G.lastTap > COMBO_HOLD) G.chain = Math.max(0, G.chain - 16 * sdt); // drains after 1 s without a hit (was 1.4)
  updateNums(dt);
  // bot (visual testing / recording only)
  if (AUTO && (G.state === 'fight' || G.state === 'lobby')) { botT += sdt; while (botT > .11) { botT -= .11; const w = world.wps.find((x) => x.on && x.state === 'live'); const s = world.dummy?.present && (titanState.sink || 0) > .5 ? world.dummy.botPoint(camera, W, Hh) : w && Math.random() < .6 ? toScreen(w.pos) : Math.random() < .9 ? toScreen(socketWorld(Math.floor(Math.random() * 99), _v2)) : { x: W * rand(.05, .95), y: Hh * rand(.1, .6) }; tapAt(s.x, s.y); } }

  // slash
  if (S.on) updateFinisher(dt);
  if (world.heroAway && !S.on && G.t - S.lastHop > RET_DELAY) startReturn();
  else if (world.heroAway && !world.ret && G.state === 'lobby' && LUI.gearView()) startReturn(); // 3D gear view: mid-hop -> straight home, then idle
  if (G.chain < S.nextFin - COMBO_STEP) S.nextFin = (Math.floor(G.chain / COMBO_STEP) + 1) * COMBO_STEP;
  // titan
  const ts = titanState; ts.flinch = damp(ts.flinch, 0, 7, dt); ts.hit = damp(ts.hit, 0, 6, dt); if (G.state !== 'intro') ts.dormant = damp(ts.dormant, G.state === 'lobby' ? 1 : 0, 4, dt);
  if (world.hurt) { puppet.pxRig = pxToWorld(1, titanGroup.position) / (puppet.k * (titanGroup.scale.x || 1)); world.hurt.update(sdt, G.state === 'fight' ? G.chain : 0); } // rig px per screen px (react.js punch knock)
  poseTitan(sdt, t);
  titanGroup.position.y = (world.titanY ?? -1.2) - (ts.sink || 0) * 62 * (world.titanS || 1); // sink / rise through the cloud sea (intro, retreat)
  const pop = ts.slam ? ts.slam : 0; ts.slam = damp(pop, 0, 5, dt); titanGroup.scale.setScalar((world.titanS || 1) * (1 + .035 * ts.slam));
  // titan colour / glow
  const dorm = G.state === 'lobby' ? .55 : 1, flashK = ts.hit * .15, rr = ts.rage;
  const tint = _c.setRGB(dorm * (1 + rr * .35), dorm * (1 - rr * .12), dorm * (1 - rr * .25));
  if (world.hurt) world.hurt.apply(tint, flashK * .8 + rr * .06, flashK * .7, flashK * 1.0); // tint + flash per part (+ hit flash, hurt red; titans/hurt.js)
  for (const m of puppet.mats) { const u = m.uniforms; if (!world.hurt) { u.tint.value.copy(tint); u.flash.value.setRGB(flashK * .8 + rr * .06, flashK * .7, flashK * 1.0); } u.glow.value = m.userData.glow || world.titanId !== 'golem' ? 0 : lerp(.15, 1.15 + rr * .4, dorm === 1 ? 1 : 0) + (G.stun > 0 ? .5 : 0); /* procedural cyan key: golem only */ u.alpha.value = 1; }
  // emissive masks (replace the old eye / rune glow sprites): idle pulse in the shader, act flares in titan.js, here: cracks
  // flash with hits, dim on the exit roar, fade out while sinking
  GLOW.time.value = t; puppet.glow.kick('r', ts.hit * 1.1, 6);
  puppet.glow.fade = clamp(1 - (ts.sink || 0) * 1.8, 0, 1) * (G.state === 'retreat' ? lerp(1, .55, sstep(2.2, 2.8, G.retreat)) : 1);
  puppet.updateGlow(dt);
  if (world.shield.visible || G.shield > 0) { const u = world.shield.material.uniforms; u.k.value = G.shield > 0 ? 1 : 0; u.hit.value = damp(u.hit.value, 0, 6, dt); world.shield.scale.set(40, 54, 1); world.shield.position.set(0, 24, 1.5); world.shield.visible = G.shield > 0 || u.hit.value > .02; world.shield.quaternion.copy(camera.quaternion).premultiply(titanGroup.quaternion.clone().invert()); }
  // titan glow lights
  _c.setRGB(AR.titanLight.r * (1 + rr), AR.titanLight.g, AR.titanLight.b).multiplyScalar(.35 + ts.hit * .5); SH.lightCol.value.lerp(_c, .08); SH.lightPos.value.lerp(_v2.set(0, 18, -34), .05);
  lights.cy.intensity = (dorm === 1 ? 2.4 : 1) + ts.hit * 3; lights.fl.intensity = damp(lights.fl.intensity, 0, 8, dt);
  SH.fogColor.value.setRGB(AR.fog.r + rr * .21, Math.max(0, AR.fog.g - rr * .1), Math.max(0, AR.fog.b - rr * .1)); // arena fog (arena.js), rage warms it
  // weak points
  updateWPs(sdt);
  // layered environment + base mist
  world.env.update(t, dt, camera);
  if (DESC.on) descentScene();
  world.dummy?.update(dt, t, camera);
  // fists / paws touching the sea (11-26 bigger titan, waterline at the belt): small rings + foam where they dip in
  if (titanGroup.visible && !(titanState.sink > .3) && (G.wakeT = (G.wakeT || 0) - dt) < 0) { G.wakeT = .7 + Math.random() * .5;
    for (const id of world.tcfg?.wakeSocks || ['fistL', 'fistR']) { const i = titanState.sockets.findIndex((q) => q.id === id); if (i < 0) continue; socketWorld(i, _v2);
      if (_v2.y < 2.2 * (world.titanS || 1)) world.water.plop(_v2.x, _v2.z + 2 * world.water.ws, .35 + Math.random() * .25); } }
  world.water.update(t, dt, camera, { titanX: titanGroup.position.x, titanZ: titanGroup.position.z /* his real depth (ink TZ): water.js scales every water size by it */, titanW: 9 * (world.titanS || 1), sink: titanState.sink || 0, on: titanGroup.visible && G.state !== 'results', side: world.env.side,
    px: Hh * renderer.getPixelRatio() / (2 * Math.tan(camera.fov * Math.PI / 360)) });
  for (const m of world.mist) { m.m.position.x = m.x + Math.sin(t * .1 * m.sp + m.x) * 4; m.m.quaternion.copy(camera.quaternion); }
  // hero idle
  if (world.ret) updateReturn(dt, t);
  else if (DESC.on) descentHero(dt, t);
  else if (!world.heroAway) {
    const hero = world.hero, h = world.heroH, ft = HA.tick(dt) || T.hi, fa = ft.image.width / ft.image.height, pb = HA.on ? HA_BOB : 1; // painted idle loop breathes itself: only a trace of the old bob
    hero.position.copy(world.heroHome); hero.position.y = (Math.sin(t * 1.6) * .04 + Math.max(0, Math.sin(t * 3)) * .02) * pb;
    world.heroFace = G.state === 'lobby' ? 1 : toScreen(world.heroHome, {}).x > W / 2 ? -1 : 1; // 11-27 user: lobby (and the gear zoom, which moves him to screen centre) = always faces right. 11-26 user: "he should look to the mob always" - live, from where he stands (the titan / dummy sit at screen centre)
    hero.scale.set(h * fa * (world.heroFace || 1) * (1 + .01 * pb * Math.sin(t * 1.6)), h * (1 + .012 * pb * Math.sin(t * 1.6)), 1); hero.userData = { h, hs: h, tex: ft, asp: fa }; hero.quaternion.copy(camera.quaternion); // fa: idle frames are wider (cape room)
    world.heroMat.uniforms.map.value = ft; world.heroMat.uniforms.flash.value.setRGB(0, 0, 0); world.heroMat.uniforms.alpha.value = 1;
    world.heroGlow.visible = false;
  } else if (world.hero.userData.c) { // strike pose: pop in, lunge a little toward the target, hold (11-27 PERF PASS: Starfall v3 hides him with no strike data -> skip; it threw every frame = ~1.3 s of unrendered frames)
    const hero = world.hero, u = hero.userData; u.t += dt; const k = clamp(u.t / .16, 0, 1), pop = 1 + .07 * Math.pow(1 - clamp(u.t / .09, 0, 1), 2); // brief, within +-8%
    const hs = u.h * pop; u.hs = u.h; _v.copy(u.c).lerp(u.to, .07 * (1 - Math.pow(1 - k, 3)));
    hero.position.set(_v.x, _v.y - hs * .5, u.c.z); hero.scale.set(hs * u.asp * u.flip, hs, 1); hero.quaternion.copy(camera.quaternion);
    world.heroGlow.visible = true; world.heroGlow.position.set(_v.x, _v.y, u.c.z - .5); world.heroGlow.quaternion.copy(camera.quaternion); world.heroGlow.scale.setScalar(hs * 1.3); world.heroGlow.material.uniforms.fade.value = .22 * (1 - k * .5);
    world.heroMat.uniforms.flash.value.setRGB(.25, .18, .4).multiplyScalar(1 - k);
  }
  // arcs / streaks / flashes / clones
  world.arcs.forEach((m, i) => { const d = world.darcs[i]; if (!m.visible) { d.visible = false; return; } const u = m.userData; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = d.visible = false; return; }
    const prog = clamp(k * 3.2, 0, 1), fade = 1 - clamp((k - .45) / .55, 0, 1); m.material.uniforms.prog.value = prog; m.material.uniforms.fade.value = fade * (u.amp ?? 1);
    // warp mirror: same transform, lingers a little longer than the glow (~0.25 s) and fades out
    d.visible = !NODIST && (u.warp ?? 1) > 0; if (d.visible) { d.position.copy(m.position); d.quaternion.copy(m.quaternion); d.scale.copy(m.scale).multiplyScalar(1 / SLASH_K); /* user 11-26: smaller slashes, distortion keeps the old size */ const du = d.material.uniforms; du.prog.value = prog; du.fade.value = 1 - clamp((k - .3) / .7, 0, 1); du.dir.value = m.material.uniforms.dir?.value ?? 1; } });
  for (const m of world.larcs) if (m.visible) { const u = m.userData; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = false; continue; }
    m.material.uniforms.prog.value = clamp(k * 1.6, 0, 1.4); m.material.uniforms.fade.value = (1 - clamp((k - .4) / .6, 0, 1)) * (u.amp ?? 1); }
  for (const m of world.shocks) if (m.visible) { const u = m.userData; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = false; continue; } m.material.uniforms.prog.value = 1 - Math.pow(1 - k, 2); m.material.uniforms.fade.value = 1 - k; }
  for (const m of world.streaks) if (m.visible) { const u = m.userData; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = false; continue; } m.material.uniforms.prog.value = clamp(k * 2, 0, 1); m.material.uniforms.fade.value = 1 - clamp((k - .5) / .5, 0, 1); }
  for (const m of world.flashes) if (m.visible) { const u = m.userData; u.t += dt; const k = u.t / u.dur; if (k >= 1) { m.visible = false; continue; } const s = lerp(u.s0, u.s1, 1 - Math.pow(1 - k, 3)); m.scale.set(s, s, 1); m.material.uniforms.fade.value = 1 - k; if (m.material.uniforms.vs.value > 0) m.scale.set(s * .35, s * 1.4, 1); }
  for (const m of world.clones) if (m.visible) {
    const u = m.userData, mu = m.material.uniforms;
    if (u.dis !== undefined) { // graceful dissolve (idle return): drift up, erase top-down along a noisy edge that sheds violet sparkles
      u.dis += dt; const k = clamp(u.dis / u.disDur, 0, 1), hh = Math.abs(m.scale.y);
      if (k >= 1) { m.visible = false; mu.cut.value = -2; u.dis = undefined; continue; }
      mu.alpha.value = u.a0 * (1 - k * k * .6); mu.cut.value = 1.04 - k * 1.1; m.position.y += dt * hh * .3;
      if (Math.random() < .7) { const cw = Math.abs(m.scale.x) * .35; world.sparks.emit(m.position.x + rand(-cw, cw), m.position.y + hh * clamp(mu.cut.value, 0, 1), m.position.z, rand(-.6, .6), rand(1, 2.5), 0, rand(.4, .7), rand(.4, .8), .8, .6, 1, -1); }
      continue; }
    u.life -= dt; if (u.life <= 0) { m.visible = false; continue; } mu.alpha.value = Math.pow(clamp(u.life / u.max, 0, 1), 1.2) * .42; }
  EQ.updateVisuals(dt); // weapon in hand (after every hero / clone sprite is placed)
  WFX.update(dt); // blade element fx follow the blade placed just above
  world.sparks.update(dt);
  // debris
  const { dm, q, e, sc } = DEB_TMP; // reused every frame (no per-frame garbage)
  const debLive = world.dd.some((d) => d.life > 0); // 11-26 thermal: no 140-instance matrix rebuild + upload while no debris flies
  if (debLive || world.debWas) world.dd.forEach((d, i) => { if (d.life > 0) { d.life -= dt; d.v.y -= 26 * dt; d.p.addScaledVector(d.v, dt); d.r.addScaledVector(d.w, dt); if (d.p.y < -.2 && d.v.y < 0) { if (d.p.z < -8 && world.water) { world.water.plop(d.p.x, d.p.z, d.s); d.life = 0; } /* lands in the sea: plop + gone */ d.v.y *= -.3; d.v.x *= .6; d.p.y = -.2; } }
    const s = d.life > 0 ? d.s * clamp(d.life * 2, 0, 1) : 0; e.set(d.r.x, d.r.y, d.r.z); q.setFromEuler(e); sc.setScalar(s); dm.compose(d.p, q, sc); world.debris.setMatrixAt(i, dm); });
  if (debLive || world.debWas) world.debris.instanceMatrix.needsUpdate = true; world.debris.visible = debLive; world.debWas = debLive; // one last pass writes the zero-scale rest state
  world.sparks.u.px.value = Hh * renderer.getPixelRatio() / (2 * Math.tan(camera.fov * Math.PI / 360)) * .045;

  // camera
  // camera: FIXED rest framing (user 11-25: no sway / lean / whip / zoom); impacts = short positional shake that decays fast
  CAM.shake = Math.max(0, CAM.shake - dt * 6); // short, punchy
  // exit only: slow push-in; it holds behind the results and eases back out in the next lobby (11-26: no camera snap)
  const push = G.state === 'retreat' || G.state === 'results' ? .07 * sstep(0, 4.6, G.retreat) : 0, fin = CUT.dim(); CAM.push = CUT.on() ? 0 : G.state === 'retreat' ? push : damp(CAM.push || 0, push, 2.2, dt); // kill finisher: NO zoom (11-28 user), only the vignette below
  // the fight angle holds through the fight and the kill finisher / screen cut, then eases back to the menu framing. (descent: the move
  // to the fight angle happens under the fog veil.) 11-28 fix: the cf.k update had been swallowed by a comment, so the menu kept the fight angle.
  { const cf = CAM_FIGHT, want = cf.on && (G.state === 'fight' || G.state === 'intro' || CUT.on() || (G.state === 'descent' && DESC.t > .45)) ? 1 : 0;
    cf.k = want > cf.k ? Math.min(want, cf.k + dt / cf.dur) : Math.max(want, cf.k - dt / cf.dur);
    const e = cf.k * cf.k * (3 - 2 * cf.k); _camP.copy(BASE_POS).lerp(cf.pos, e); _camL.copy(BASE_LOOK).lerp(cf.look, e); } // fight angle blend (eased)
  camera.position.copy(_camP); if (CAM.push > 1e-4) camera.position.lerp(_camL, CAM.push); camera.lookAt(_camL);
  const sk = CAM.shake * CAM.shake; camera.position.x += rand(-1, 1) * sk * .45; camera.position.y += rand(-1, 1) * sk * .45;
  if (DESC.on) { const x = DESC.t, e = clamp((x - 1.55) / .65, 0, 1); camera.position.y += .35 * sstep(0, .4, x) * (1 - sstep(.45, .9, x)) + 1.4 * sstep(1.1, 1.55, x) * Math.pow(1 - e, 3); } // descent: lifts with the leap; at the arrival it settles down from above
  if (camera.fov !== CAM.fov) { camera.fov = CAM.fov; camera.updateProjectionMatrix(); }
  LUI.frame(dt, camera, W, Hh); // 11-27 lobby UI v2: bar refresh + lobby-only view shift (the ledge sits above the tab bar)
  PUI.frame(dt); // 11-27 auto-train ticks (lobby only), XP bar, AUTO chip, queued lobby popups
  // post params
  const fl = world.heroAway ? 1 : 0; post_.chroma = damp(post_.chroma, S.on ? .05 : 0, 8, dt); for (let i = 0; i < 3; i++) post_.flash[i] = damp(post_.flash[i], 0, 9, dt);
  post_.vig = damp(post_.vig, .55 + fl * .15 + (G.state === 'retreat' ? .3 : 0) + DSCU.dark.value * .35, 4, dt); // descent: darker deeper
  if (fin > 0) { post_.vig = Math.max(post_.vig, .55 + .75 * fin); post_.sat = Math.min(post_.sat, 1.08 - .35 * fin); for (let i = 0; i < 3; i++) post_.flash[i] = Math.min(post_.flash[i], -.07 * fin); } // finisher vignette (as the Eclipse skill)
  post.comp.uniforms.vcol.value.setRGB(.04, .02, .12); post_.sat = damp(post_.sat, 1.08 - DSCU.dark.value * .3, 5, dt); post_.bloom = damp(post_.bloom, S.on ? 1.0 : .85 + fl * .1, 6, dt);
  // bg sits behind everything
  bgMesh.position.set(camera.position.x * .9, 22 + (camera.position.y - 2) * .5, -150); rays.position.set(camera.position.x * .85, 28, -130);
  bgMesh.quaternion.copy(camera.quaternion); rays.quaternion.copy(camera.quaternion); rays.rotateZ(Math.sin(t * .05) * .04); rays.position.x += Math.sin(t * .035) * 5; // god rays sway slowly
  world.refl?.update(t, camera, puppet, titanGroup); // mirrored titan / dummy / ruins (after every source is placed)
  if (CLEAN) cleanView();
  gfxFrameFx(); // adaptive quality tiers: reflections / distortion / bloom switches (graphics quality block)
  // 11-26 user: the black foreground frame must not move - it is drawn AFTER the post chain (no slash distortion / shock ripple / bloom
  // on it). The inkdeco frame meshes (userData.deco 'frame', clip-space) are hidden in the scene pass and drawn here on their own.
  if (FRC.n !== scene.children.length) { FRC.n = scene.children.length; FRC.cand = scene.children.filter((m) => m.isMesh && m.material.vertexShader && m.material.vertexShader.includes('gl_Position = vec4(position.xy')); } // 11-27 PERF PASS: clip-space candidates cached (was a filter + string search per child every frame)
  const FR = FRC.list; FR.length = 0; for (const m of FRC.cand) if (m.userData.deco === 'frame') FR.push(m);
  for (const m of FR) m.visible = false;
  if (CUT.drawing()) CUT.render(); else { // the kill ending draws the screen itself (the world is not rendered)
  post.render(scene, camera, post_, dscene);
  if (FR.length) { for (const m of FR) m.visible = true; const ac = renderer.autoClear; renderer.autoClear = false; renderer.setRenderTarget(null);
    for (const m of FR) renderer.render(m, camera); renderer.autoClear = ac; }
  if (CUT.capture()) CUT.render(); else { if (!CLEAN) NFX.draw(renderer, W, Hh); CUT.overlay(); } // damage numbers + xN counters (numfx.js), over the composite; the finisher's slashes
  }

  hud(dt); updatePops(); updateSlashers(sdt);
  perfEnd(now); // frame work time -> PERF (fps overlay, dev panel, auto quality)
  if (HITDEBUG) drawHitDebug(now);
  if (BONES) drawBones();
  if (WEIGHTS) drawWeights();
}
// ?weights=1 (tools/bake_weights.py): every mesh vertex as a dot coloured by its DOMINANT bone; blended vertices (near joints) are
// bigger and ringed in white, so the blend zones show. Rigid vertices are small.
let wCv = null; const W_COL = { root: '#888', hips: '#ff9040', chest: '#ffd040', neck: '#80ff60', head: '#40ffd0', jaw: '#40a0ff', shL: '#ff4060', shR: '#ff4060',
  elL: '#c060ff', elR: '#c060ff', wrL: '#ff60d0', wrR: '#ff60d0', pdL: '#60e0ff', pdR: '#60e0ff' };
function drawWeights() {
  if (!wCv) { wCv = document.createElement('canvas'); wCv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:52'; document.body.appendChild(wCv); }
  if (wCv.width !== W || wCv.height !== Hh) { wCv.width = W; wCv.height = Hh; }
  const g = wCv.getContext('2d'); g.clearRect(0, 0, W, Hh); titanGroup.updateMatrixWorld();
  for (const p of puppet.parts) { if (p.A.name.startsWith('rock')) continue; const P = p.pos, multi = new Map(p.mv.map((v, m) => [v, m]));
    for (let i = 0, n = P.length / 3; i < n; i++) { _v3.set(P[3 * i], P[3 * i + 1], P[3 * i + 2]); titanGroup.localToWorld(_v3); const q = toScreen(_v3, {});
      let dom = p.A.name; const m = multi.get(i); let big = false;
      if (m !== undefined) { big = true; const ws = p.mw[m], w0 = 1 - ws.reduce((a, b) => a + b, 0), best = Math.max(...ws); if (best > w0) dom = p.mb[m][ws.indexOf(best)].name; }
      g.fillStyle = W_COL[dom] || '#fff'; g.beginPath(); g.arc(q.x, q.y, big ? 3.2 : 1.6, 0, 6.283); g.fill();
      if (big) { g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 1; g.stroke(); } } }
}
function cleanView() {
  for (const m of [world.hero, world.heroOld, world.heroGlow, ...world.clones]) if (m) m.visible = false;
  const E = world.env; if (E.ledge) E.ledge.visible = false;
  for (const s of E.side) if (s.kind) s.m.visible = false; // foreground pillars / block / floating props (mid ruins have no kind)
  for (const it of E.items) if (it.kind === 'mist') it.m.visible = false;
  for (const m of world.mist) m.m.visible = false;
  const l = document.getElementById('animLab'); if (l) l.style.display = 'none'; $('hud').classList.add('hidden');
  const vy = (window.__devShim?.added || []).includes('vy') ? 0 : +(Q.get('vy') || 0); // 11-27: a vy SAVED in the DEV panel no longer applies (it froze the lobby view + gear zoom on the user's phone); only a vy typed in the URL // ?vy=.2 shifts the view up by 20% of the screen height (headroom for raised fists), same perspective
  if (vy && (!camera.view || camera.view.offsetY !== -vy * Hh || camera.view.fullWidth !== W)) { camera.setViewOffset(W, Hh, 0, -vy * Hh, W, Hh); }
}
// ?bones=1 (animation review, see .claude/skills/cutout-animation): every bone's pivot (yellow = limb joint, cyan = pauldron,
// white = others), a line to its parent, and an onion-skin trail of the last ~0.6 s for the fists, elbows and head (shows arcs).
let boneCv = null; const boneTrail = {};
function drawBones() {
  if (!boneCv) { boneCv = document.createElement('canvas'); boneCv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:51'; document.body.appendChild(boneCv); }
  if (boneCv.width !== W || boneCv.height !== Hh) { boneCv.width = W; boneCv.height = Hh; }
  const g = boneCv.getContext('2d'); g.clearRect(0, 0, W, Hh); titanGroup.updateMatrixWorld();
  const sp = (b) => { puppet.point(b, 0, 0, _v3); titanGroup.localToWorld(_v3); return toScreen(_v3, {}); };
  for (const b of puppet.bones) { const s = sp(b.name);
    if (b.p && !b.name.startsWith('rock')) { const q = sp(b.p.name); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 2; g.beginPath(); g.moveTo(q.x, q.y); g.lineTo(s.x, s.y); g.stroke(); }
    if (/^(wr|el|head)/.test(b.name)) { const tr = boneTrail[b.name] || (boneTrail[b.name] = []); tr.push(s); if (tr.length > 36) tr.shift();
      tr.forEach((p, i) => { g.fillStyle = `rgba(255,120,220,${(i / tr.length) * .8})`; g.fillRect(p.x - 2, p.y - 2, 4, 4); }); }
    g.fillStyle = /^pd/.test(b.name) ? '#40f0ff' : /^(sh|el|wr)/.test(b.name) ? '#ffe040' : '#fff'; g.beginPath(); g.arc(s.x, s.y, /^pd/.test(b.name) ? 7 : 5, 0, 6.283); g.fill();
    g.fillStyle = '#000'; g.font = '10px monospace'; g.fillText(b.name, s.x + 7, s.y - 5); }
  // baked IK fist targets (tools/bake_anim.py, anims.json tx/ty): magenta ring + cross where each fist is asked to go
  for (const L in world.anim.ikDbg) { const [rx, ry] = world.anim.ikDbg[L]; _v3.set((rx - puppet.ox) * puppet.k, (puppet.oy - ry) * puppet.k, .5); titanGroup.localToWorld(_v3); const q = toScreen(_v3, {});
    g.strokeStyle = '#ff40ff'; g.lineWidth = 2; g.beginPath(); g.arc(q.x, q.y, 9, 0, 6.283); g.moveTo(q.x - 13, q.y); g.lineTo(q.x + 13, q.y); g.moveTo(q.x, q.y - 13); g.lineTo(q.x, q.y + 13); g.stroke();
    g.fillStyle = '#ff40ff'; g.font = '10px monospace'; g.fillText('ik' + L, q.x + 11, q.y + 12); }
}
// ?hitdebug=1: the hit mask (exact body test on an 8 px grid, refreshed 4x/s) + recent taps (green hit / cyan weak / red miss)
const dbgTaps = []; let dbgCv = null, dbgT = 0;
function drawHitDebug(now) {
  if (!dbgCv) { dbgCv = document.createElement('canvas'); dbgCv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:50'; document.body.appendChild(dbgCv); }
  if (now - dbgT < 250) return; dbgT = now;
  if (dbgCv.width !== W || dbgCv.height !== Hh) { dbgCv.width = W; dbgCv.height = Hh; }
  const g = dbgCv.getContext('2d'); g.clearRect(0, 0, W, Hh); titanGroup.updateMatrixWorld(); g.fillStyle = 'rgba(255,60,200,.35)';
  for (let y = 4; y < Hh; y += 8) for (let x = 4; x < W; x += 8) if (bodyAt(x, y)) g.fillRect(x - 4, y - 4, 8, 8);
  while (dbgTaps.length && now - dbgTaps[0].t > 4000) dbgTaps.shift();
  for (const d of dbgTaps) { g.strokeStyle = d.r === 'miss' ? '#ff4040' : d.r === 'wp' ? '#40f0ff' : '#40ff60'; g.lineWidth = 2; g.beginPath(); g.arc(d.x, d.y, HIT_R(), 0, 6.283); g.stroke(); }
}
function hud(dt) {
  if (document.body.dataset.st !== G.state) document.body.dataset.st = G.state; // menu.css: side circles per state (dimmed + tap-through in the fight)
  if (window.CYCLE?.on && !document.documentElement.classList.contains('cycle')) document.documentElement.classList.add('cycle'); // CYCLE mode hides the FIGHT button (menu.css)
  if (G.state === 'start') return;
  // 11-26 perf: DOM text only when it changed, the rolling score at most 20x/s (each text change = a style + layout pass on iOS);
  // the combo meter is display:none since 11-26, so it is not touched any more
  G.scoreShown = damp(G.scoreShown, G.score, 14, dt); HUDT.t -= dt;
  if (HUDT.t <= 0 || G.scoreShown === G.score) { HUDT.t = .05; const s = Math.round(G.scoreShown); const el = $('scoreN'); const txt = G.state === 'lobby' ? fmt(G.practice || 0) : fmt(s); if (HUDT.score !== txt) { HUDT.score = txt; el.textContent = txt; } }
  { const ct = S.on ? 'FINISHER!' : `COMBO x${Math.floor(G.chain)}`; if (HUDT.chain !== ct) { HUDT.chain = ct; $('chain').textContent = ct; } }
  // 11-26: no combo bar in the fight (it competed with the rank gauge): the finisher progress is the gauge's thin cyan inner arc,
  // and "x85" shows under the score only while the combo is live (>= 10), fading out after it drops (menu.css #comboX)
  CFX.update(dt, G.chain, G.state === 'fight');
  if (G.state === 'fight') { const cx = $('comboX'), on = G.chain >= 10, ct = on ? 'x' + Math.floor(G.chain) : HUDT.combo; if (HUDT.combo !== ct) { HUDT.combo = ct; cx.textContent = ct; } if (HUDT.comboOn !== on) { HUDT.comboOn = on; cx.classList.toggle('on', on); } }
  if (HUDT.coins !== SAVE.coins) { HUDT.coins = SAVE.coins; $('coinN').textContent = fmt(SAVE.coins); }
}
const HUDT = { t: 0, score: null, chain: null, combo: '', comboOn: null, coins: null }; // last DOM text written by hud()
// 11-26 UI pass: the music button moved into SETTINGS (hud-menu.js); M still toggles the master mute
// 11-26: UPGRADES -> the gear screen (inventory-ui.js); the old #upg panel stays in the DOM unused
INV.init({ SAVE, save, sfx: A.sfx, coinHud: () => coinHud() }); // save: IAP shard packs (iap.js) persist the grant at once
DAILY.init({ SAVE, save, sfx: A.sfx, coinHud: () => coinHud(), inFight: () => !['lobby', 'results', 'start'].includes(G.state), inLobby: () => G.state === 'lobby' });
MENU.init({ SAVE, save, sfx: A.sfx, A, LB, INV, board: (score) => makeBoard(score), titanIdx: () => G.titanIdx });
// FIGHT tab: the same entry as the old FIGHT button (handover); true = the fight really started (only then energy is spent)
// 11-27 3D gear view (lobby-ui.js): the hero's box on the REST view (screen px, no view offset): feet .. head at his lobby spot
const _hbv = new THREE.Vector3();
const restPx = (x, y, z) => { _hbv.set(x, y, z).applyMatrix4(camera.matrixWorldInverse); const t = Math.tan(camera.fov * Math.PI / 360), d = Math.max(.01, -_hbv.z);
  return { x: (_hbv.x / d / (t * camera.aspect) * .5 + .5) * W, y: (-_hbv.y / d / t * .5 + .5) * Hh }; };
const heroBox = () => { const h = world.heroHome0 || world.heroHome; if (!h || !world.heroH) return null; const f = restPx(h.x, h.y, h.z), hd = restPx(h.x, h.y + world.heroH, h.z); return { x: f.x, top: hd.y, bot: f.y }; };
LUI.init({ SAVE, save, heroBox, sfx: A.sfx, A, LB, INV, MENU, TIX, CYCLE, titanIdx: () => G.titanIdx, state: () => G.state, fight: () => { A.sfx('click'); handover(); return G.state !== 'lobby'; } });
// 11-27 progression (prog-ui.js): autoHit = one normal dummy hit, aimed like the ?auto=1 bot (auto-train, lobby only)
PUI.init({ SAVE, save, A, EQ, INV, LB, TIX, MENU, state: () => G.state, titanIdx: () => G.titanIdx,
  paused: () => LUI.gearView(), // 11-27 3D gear view: no auto-train while the hero is shown idle
  autoHit: () => { if (LUI.gearView() || !world.dummy?.present || (titanState.sink || 0) <= .5) return; const s = world.dummy.botPoint(camera, W, Hh); tapAt(s.x, s.y); } });
CFX.init();
$('upgClose').addEventListener('click', () => { A.sfx('click'); $('upg').classList.add('hidden'); });
$('fightNow')?.addEventListener('click', () => { A.sfx('click'); handover(); }); // FREE mode only; CYCLE mode hides it (fightBtn) and fights auto-start on the world clock
$('resUpg').addEventListener('click', () => { A.sfx('click'); INV.open(); });
$('resNext').addEventListener('click', () => { A.sfx('click'); lobbyBack(() => { G.titanIdx = titanIdxNow(); $('hud').classList.remove('hidden'); }); });
function startGame() {
  if (G.state !== 'start') return; try { A.init(); A.sfx('click'); } catch (e) { console.error('audio init', e); } $('start').remove(); $('hud').classList.remove('hidden'); enterLobby();
}
$('start').addEventListener('pointerdown', startGame);
// no start screen any more: the first touch anywhere (canvas, buttons, panels) unlocks audio (iOS needs a user gesture)
for (const ev of ['pointerdown', 'touchend', 'click', 'keydown']) addEventListener(ev, () => { try { A.init(); } catch (e) { /* no audio */ } }, { capture: true, passive: true });

(async function boot() {
  try {
    const B = window.__boot = { mod: Math.round(performance.now()) }; // load timings (ms since navigation): modules in, build done, shaders, first frame
    await build(); layout(); B.build = Math.round(performance.now());
    // MOBILE_PERFORMANCE.md "preload": compile every shader once behind the loading screen (pooled splash / puff / arc meshes
    // start hidden and three skips hidden objects, so show them for the compile), so the first slam / slash never stutters
    // 11-27 PERF PASS (warm.js): + the distortion and numfx scenes, each into its own render target, the limit meshes, and every texture
    try { LIM.warm(LCTX()); B.warm = warmGPU(renderer, camera, [[scene, post.scene], [dscene, post.d], [NFX.scene, null]], [T, HA.frames]); } catch (e) { console.warn('warm-up', e); }
    B.compile = Math.round(performance.now());
    requestAnimationFrame(frame); requestAnimationFrame(() => { B.frame = Math.round(performance.now()); });
    await Promise.all([preloadUI(), B.warm?.upload?.()]); // 11-27 user: menu / popup art preloaded behind the loading screen (no blank 'blip' when a screen first opens); PERF PASS: + warm.js texture uploads in slices
    B.ready = Math.round(performance.now());
    LDP.on = false; ldBar(1); await new Promise((r) => setTimeout(r, 280)); // the bar visibly reaches 100% before the screen goes
    $('loading').classList.add('gone');
    if (ANIM) { $('start').remove(); G.state = 'preview'; titanState.dormant = 0; const l = document.createElement('div'); l.id = 'animLab'; l.textContent = 'ANIM: ' + ANIM; document.body.appendChild(l); }
    else startGame(); // user 11-26: no "TAP TO START" - load straight into the lobby (audio unlocks on the first tap: canvas pointerdown -> A.init, #audiofix resumes it)
    window.__g = { EQ, WFX, INV, MENU, G, S, SAVE, T, world, get puppet() { return puppet; }, titanState, CAM, CAM_FIGHT, DESC, BO, camera, scene, renderer, tapAt, spawnArc, flashAt, finisher, startFight, enterLobby, endFight, banner, toScreen,
      titanHit, bodyAt, texK, startAttack, AT, pop, makeBoard, startIntro, skipIntro, showResults, startAct, animAt, get anim() { return world.anim; }, env: () => world.env,
      charScale() { // on-screen px per idle-art texel of the visible (bottom) hero sprite: equal for every pose = no rescale
        const h = world.hero, m = h.material.uniforms.map.value, p = h.position.clone(), a = toScreen(p, {}), q = p.clone().add(new THREE.Vector3(0, Math.abs(h.scale.y), 0).applyQuaternion(h.quaternion)), b = toScreen(q, {});
        return { mode: world.ret ? 'return' : world.heroAway ? 'away' : 'idle', tex: m === T.hi ? 'idle' : HA.has(m) ? 'idle_' + HA.frames.indexOf(m) : m === T.land ? 'land' : 'pose' + T.poses.indexOf(m), px: Math.round(Math.hypot(a.x - b.x, a.y - b.y)), k: +(Math.hypot(a.x - b.x, a.y - b.y) / (m.image.height * texK(m))).toFixed(4), pctScreen: +(Math.hypot(a.x - b.x, a.y - b.y) / Hh * 100).toFixed(1) }; }, socketWorld, shock, post, get ret() { return world.ret; }, get heroMode() { return world.ret ? 'return' : world.heroAway ? 'away' : 'idle'; },
      tapN(n) { for (let i = 0; i < n; i++) tapAt(innerWidth * .5, innerHeight * .3); },
      // 11-26 leak / thermal: live counts (dev panel line has the short form) + per-pass GPU cost
      perfStats() { let n = 0, v = 0; scene.traverse((o) => { n++; if (o.visible) v++; }); const f = fxCounts(), gi = GFX.info();
        return { ...f, sceneN: n, sceneVis: v, dsceneVis: dscene.children.filter((m) => m.visible).length, progs: renderer.info.programs?.length, sparks: world.sparks?.n,
          heapMB: performance.memory ? +(performance.memory.usedJSHeapSize / 1048576).toFixed(1) : null, dom: document.getElementsByTagName('*').length,
          fps: PERF.fps, ms: PERF.ms, js: PERF.work, dc: PERF.calls, tier: gi.tier, dpr: gi.dpr, cap: CAP.fps, capMode: CAP.mode, capLog: CAP.log, autoLog: gi.autoLog }; },
      // passCost(frames, hide): median GPU ms per post pass (EXT_disjoint_timer_query_webgl2) over N frames; hide = group names
      // to switch off while measuring (refl sea mist sky titan deco:ruins deco:beams deco:spores deco:frame) -> diff the 'scene' pass
      passCost(n = 90, hide = []) { const gl = renderer.getContext(), ext = gl.getExtension('EXT_disjoint_timer_query_webgl2'); if (!ext) return Promise.resolve({ err: 'no GPU timer' });
        const grp = (k) => k === 'refl' ? [world.refl?.root] : k === 'sea' ? [world.refl?.floor] : k === 'titan' ? [titanGroup] : k === 'mist' ? [...world.mist, ...(world.env?.mists || [])].map((x) => x.m)
          : k === 'sky' ? [bgMesh, rays, world.env?.rays2, world.env?.sunGlow] : k.startsWith('deco:') ? scene.children.filter((m) => m.userData.deco === k.slice(5)) : [];
        const off = hide.flatMap(grp).filter((m) => m && m.visible); off.forEach((m) => { m.visible = false; });
        const acc = {}, pend = []; let cur = null, cnt = 0;
        post.prof = (name) => { if (cur) { gl.endQuery(ext.TIME_ELAPSED_EXT); pend.push(cur); cur = null; } if (name) { const q = gl.createQuery(); gl.beginQuery(ext.TIME_ELAPSED_EXT, q); cur = { name, q }; } };
        return new Promise((res) => { const poll = () => {
          for (let i = pend.length - 1; i >= 0; i--) { const p = pend[i]; if (gl.getQueryParameter(p.q, gl.QUERY_RESULT_AVAILABLE)) { if (!gl.getParameter(ext.GPU_DISJOINT_EXT)) (acc[p.name] = acc[p.name] || []).push(gl.getQueryParameter(p.q, gl.QUERY_RESULT) / 1e6); gl.deleteQuery(p.q); pend.splice(i, 1); } }
          if (++cnt < n) { requestAnimationFrame(poll); return; }
          post.prof = null; off.forEach((m) => { m.visible = true; }); const out = {};
          for (const [k, a] of Object.entries(acc)) { a.sort((x, y) => x - y); out[k] = { ms: +a[a.length >> 1].toFixed(3), n: a.length }; }
          res(out); }; requestAnimationFrame(poll); }); },
      // animation review: every bone's pivot + fist centres in rig px (root space) AND screen px, so stills can be measured in rig space
      rigPts() { titanGroup.updateMatrixWorld(); const o = {}, an = puppet.rig.anchors || {};
        const put = (nm, bone, lx, ly) => { const [x, y] = [puppet.byName[bone].m[0] * lx + puppet.byName[bone].m[2] * ly + puppet.byName[bone].m[4], puppet.byName[bone].m[1] * lx + puppet.byName[bone].m[3] * ly + puppet.byName[bone].m[5]];
          puppet.point(bone, lx, ly, _v3); titanGroup.localToWorld(_v3); const s = toScreen(_v3, {}); o[nm] = { rx: +x.toFixed(1), ry: +y.toFixed(1), sx: +s.x.toFixed(1), sy: +s.y.toFixed(1), r: +Math.atan2(puppet.byName[bone].m[1], puppet.byName[bone].m[0]).toFixed(3) }; };
        for (const b of puppet.bones) put(b.name, b.name, 0, 0);
        for (const f of ['fistL', 'fistR']) if (an[f]) put(f, an[f].bone, an[f].x, an[f].y);
        return o; }, get frames() { return frames; } };
  } catch (e) { $('loading').textContent = 'Error: ' + e.message; console.error(e); }
})();
