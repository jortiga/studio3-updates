// 2D Spine/Live2D-style puppet in three.js, ported from kaiju/test/rig.js (Codex parts -> skinned meshes).
// Each part is a grid mesh with 2 bones' weights (a bone + the "to" bone, blended along the limb) skinned on the CPU every
// frame. Bones are 2D affine chains; rig space is pixels, y down. Weights (11-25, Spine-style): art/titan2/weights.json from
// tools/bake_weights.py gives a vertex up to 3 bone influences near joints (elbow, wrist, shoulder, neck, jaw, waist); everything
// else stays rigid on its part's bone. Only the blended vertices pay for the weighted sum. Parts render as one lit material each so the titan gets the
// scene's light/fog/flash/bloom. Weak points sit in bone-local coordinates, so they move with the body.
import * as THREE from 'three';
import { GlowDriver, GLOW_LAYER } from './glowmask.js';

const mul = (m, n) => [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
  m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
const trs = (x, y, r, sx = 1, sy = 1) => { const c = Math.cos(r), s = Math.sin(r); return [c * sx, s * sx, -s * sy, c * sy, x, y]; };
const ap = (m, x, y) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];
function alphaMap(img) { // small CPU copy of a part's alpha (rows top-down, matches uv v with flipY = false)
  const s = Math.min(1, 128 / Math.max(img.width, img.height)), w = Math.max(2, Math.round(img.width * s)), h = Math.max(2, Math.round(img.height * s));
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const g = cv.getContext('2d', { willReadFrequently: true }); g.drawImage(img, 0, 0, w, h);
  const d = g.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) a[i] = d[i * 4 + 3]; return { w, h, a };
}
const smooth = (a, b, t) => { const u = Math.min(1, Math.max(0, (t - a) / (b - a))); return u * u * (3 - 2 * u); };

export class Puppet {
  // masks: optional { img: emissive mask texture } (tools/glow_mask.py); makeMaterial(tex, part, mask) must add it (fx.js spriteMat glowMap)
  // weights: optional weights.json { parts: [{ i (index into json.parts), grid: [nx, ny], v: [[vertex, bone, w, bone, w ...]] }] }
  constructor(json, textures, makeMaterial, masks = {}, weights = null) {
    const WT = {}; if (weights) for (const w of weights.parts) WT[w.i] = w;
    this.rig = json;
    this.group = new THREE.Group();
    this.pose = {};
    this.bones = json.bones.map((b) => ({ ...b }));
    const by = this.byName = Object.fromEntries(this.bones.map((b) => [b.name, b]));
    for (const b of this.bones) { b.p = b.parent ? by[b.parent] : null; b.lx = b.x - (b.p ? b.p.x : 0); b.ly = b.y - (b.p ? b.p.y : 0); }
    this.k = 1;            // world units per rig pixel (set by fit())
    this.mats = [];
    const parts = json.parts.slice().sort((p, q) => (p.z || 0) - (q.z || 0));
    this.parts = parts.map((pt, order) => {
      // tex.userData.up: the texture is N x the rig's part size (HD export, tools/hq_export.py): geometry stays in 1x rig pixels
      const tex = textures[pt.img], up = tex.userData.up || 1, img = { width: tex.image.width / up, height: tex.image.height / up };
      const s = pt.scale || 1, fl = pt.flip ? -1 : 1, r = (pt.rot || 0) * Math.PI / 180;
      const sx = s * fl * (pt.sx || 1); // pt.sx: extra width (11-25: chunkier arms from the same painted parts)
      const place = mul(trs(pt.at[0], pt.at[1], r), [sx, 0, 0, s, -pt.pivot[0] * sx, -pt.pivot[1] * s]);
      const W8 = WT[json.parts.indexOf(pt)];
      const nx = W8 ? W8.grid[0] : pt.grid || Math.max(4, Math.min(28, Math.round(img.width / 24))), ny = W8 ? W8.grid[1] : pt.grid || Math.max(4, Math.min(28, Math.round(img.height / 24)));
      const v0 = [], uv = [], wt = [], idx = [];
      const a = pt.from || pt.pivot, e = pt.end;
      for (let j = 0; j <= ny; j++) for (let i = 0; i <= nx; i++) {
        const px = img.width * i / nx, py = img.height * j / ny;
        v0.push(...ap(place, px, py)); uv.push(i / nx, j / ny);
        let w = 0;
        if (e && pt.to) { const dx = e[0] - a[0], dy = e[1] - a[1]; const t = ((px - a[0]) * dx + (py - a[1]) * dy) / (dx * dx + dy * dy); const bl = pt.blend || [0.7, 1.05]; w = smooth(bl[0], bl[1], t); }
        wt.push(w);
      }
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { const q = j * (nx + 1) + i; idx.push(q, q + 1, q + nx + 1, q + 1, q + nx + 2, q + nx + 1); }
      const g = new THREE.BufferGeometry();
      const pos = new Float32Array((v0.length / 2) * 3);
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uv), 2));
      g.setIndex(idx);
      g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5); // skinned on the CPU: never cull
      const mat = makeMaterial(tex, pt, masks[pt.img] || null);
      this.mats.push(mat);
      const mesh = new THREE.Mesh(g, mat);
      const ro = 110 + (pt.z || 0); mesh.renderOrder = ro; mesh.frustumCulled = false; // DRAW ORDER: rig z -> renderOrder (see drawOrder())
      if (mat.userData.glow) mesh.layers.enable(GLOW_LAYER); // selective bloom pass sees only masked parts
      this.group.add(mesh);
      const sm = /^(sh|el|wr)(L|R)$/.exec(pt.bone); // upper arm / forearm / fist: per-pose draw order (drawOrder())
      // blended vertices: mv = vertex ids, mb = [bone, ...] per vertex, mw = [w, ...] (the part's own bone gets 1 - sum)
      const mv = [], mb = [], mw = [];
      if (W8) for (const r of W8.v) { mv.push(r[0]); const bs = [], ws = []; for (let k = 1; k < r.length; k += 2) if (by[r[k]]) { bs.push(by[r[k]]); ws.push(r[k + 1]); } mb.push(bs); mw.push(ws); }
      return { pt, mesh, v0, wt, pos, uv: g.attributes.uv.array, idx, al: alphaMap(tex.image), bb: [0, 0, 0, 0], A: by[pt.bone], B: pt.to ? by[pt.to] : null, z: order * 0.02, ro, roF: pt.zFront != null ? 110 + pt.zFront : ro, side: sm ? sm[2] : null, seg: sm ? sm[1] : null, mv, mb, mw, nx, ny };
    });
    this.solve();
    // bind-pose bounds -> fit()
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
    for (const p of this.parts) for (let i = 0; i < p.v0.length; i += 2) { x0 = Math.min(x0, p.v0[i]); x1 = Math.max(x1, p.v0[i]); y0 = Math.min(y0, p.v0[i + 1]); y1 = Math.max(y1, p.v0[i + 1]); }
    this.bounds = { x0, x1, y0, y1 };
    if (json.view?.bounds) { const v = json.view.bounds; this.bounds = { x0: v[0], x1: v[1], y0: v[2], y1: v[3] }; } // fixed framing box
    // emissive glow: one driver for the whole body (R cracks / G eyes+gem / B runes; base, act multipliers, fade) + per-bone
    // kicks so a rune flares only where it was hammered
    this.glow = new GlowDriver([1, 1, 1]); this.glowBone = {};
    this.glowParts = this.parts.filter((p) => p.mesh.material.userData.glow).map((p) => ({ u: p.mesh.material.userData.glow, bone: p.pt.bone }));
  }
  // flare a glow group: ch 'r' | 'g' | 'b', amt added to its intensity, decays at `decay`/s; bone limits it to that bone's parts
  glowKick(ch, amt, decay = 6, bone) { if (bone) (this.glowBone[bone] || (this.glowBone[bone] = new GlowDriver([0, 0, 0]))).kick(ch, amt, decay); else this.glow.kick(ch, amt, decay); }
  updateGlow(dt) {
    const k = this.glow.update(dt), f = this.glow.fade;
    for (const b in this.glowBone) this.glowBone[b].update(dt);
    for (const { u, bone } of this.glowParts) { const d = this.glowBone[bone]; u.glowK.value.set(k[0] + (d ? d.k[0] * f : 0), k[1] + (d ? d.k[1] * f : 0), k[2] + (d ? d.k[2] * f : 0)); }
  }
  // scale so the rig is `h` world units tall; origin at bottom centre
  fit(h) { const b = this.bounds; this.k = h / (b.y1 - b.y0); this.ox = (b.x0 + b.x1) / 2; this.oy = b.y1; }
  set(n, o) { const p = this.pose[n] || (this.pose[n] = {}); for (const k in o) p[k] = (p[k] || 0) + o[k]; }
  clear() { for (const k in this.pose) delete this.pose[k]; }
  // Scale does NOT inherit (Spine "noScale"): a bone's sx / sy squash its own parts and push its children's joints outward, but
  // never shear or stretch the children (chest breathing / roar expansion used to stretch the raised arms). b.mr = rigid frame
  // handed to children, b.m = scaled frame for the bone's own parts and sockets.
  solve() {
    const I = [1, 0, 0, 1, 0, 0];
    for (const b of this.bones) {
      const o = this.pose[b.name] || {}, p = b.p, ps = p ? p.ps : null;
      const lx = (b.lx + (o.x || 0)) * (ps ? ps[0] : 1), ly = (b.ly + (o.y || 0)) * (ps ? ps[1] : 1);
      b.ps = [1 + (o.sx || 0), 1 + (o.sy || 0)];
      b.mr = mul(p ? p.mr : I, trs(lx, ly, o.r || 0));
      b.m = (o.sx || o.sy) ? mul(b.mr, [b.ps[0], 0, 0, b.ps[1], 0, 0]) : b.mr;
      b.skin = mul(b.m, [1, 0, 0, 1, -b.x, -b.y]);
    }
  }
  // skin all parts into their meshes (call after set()s)
  update() {
    this.solve();
    const { k, ox, oy } = this;
    for (const p of this.parts) {
      const A = p.A.skin, B = p.B ? p.B.skin : null, out = p.pos, bb = p.bb; bb[0] = bb[1] = 1e9; bb[2] = bb[3] = -1e9;
      for (let i = 0, n = p.wt.length; i < n; i++) {
        const x = p.v0[2 * i], y = p.v0[2 * i + 1], w = p.wt[i];
        let ax = A[0] * x + A[2] * y + A[4], ay = A[1] * x + A[3] * y + A[5]; // 11-26 perf: inlined ap() (no 2 arrays per vertex per frame)
        if (B && w > 0) { const bx = B[0] * x + B[2] * y + B[4], by = B[1] * x + B[3] * y + B[5]; ax += (bx - ax) * w; ay += (by - ay) * w; }
        const X = (ax - ox) * k, Y = (oy - ay) * k; out[3 * i] = X; out[3 * i + 1] = Y; out[3 * i + 2] = p.z;
        if (X < bb[0]) bb[0] = X; if (Y < bb[1]) bb[1] = Y; if (X > bb[2]) bb[2] = X; if (Y > bb[3]) bb[3] = Y;
      }
      // weighted vertices near joints: (1 - sum w) * own bone + sum w_i * bone_i (linear blend skinning, 2D affine)
      for (let m = 0, nm = p.mv.length; m < nm; m++) {
        const i = p.mv[m], x = p.v0[2 * i], y = p.v0[2 * i + 1], bs = p.mb[m], ws = p.mw[m];
        let w0 = 1, sx = 0, sy = 0;
        for (let q = 0; q < bs.length; q++) { const M = bs[q].skin, w = ws[q]; w0 -= w; sx += (M[0] * x + M[2] * y + M[4]) * w; sy += (M[1] * x + M[3] * y + M[5]) * w; }
        sx += (A[0] * x + A[2] * y + A[4]) * w0; sy += (A[1] * x + A[3] * y + A[5]) * w0;
        const X = (sx - ox) * k, Y = (oy - sy) * k; out[3 * i] = X; out[3 * i + 1] = Y;
        if (X < bb[0]) bb[0] = X; if (Y < bb[1]) bb[1] = Y; if (X > bb[2]) bb[2] = X; if (Y > bb[3]) bb[3] = Y;
      }
      p.mesh.geometry.attributes.position.needsUpdate = true;
    }
    this.drawOrder();
  }
  // DRAW ORDER (11-25, user: "rendering order, fix it"). Static (rig z): back rocks < neck < upper arms < pelvis < chest < jaw < head
  // < pauldrons < forearms < fists. Per pose:
  //  - an upper arm whose elbow swings ACROSS the body (sweep load, guard) rises above the chest (still under the pauldron and head);
  //    measured from the bones each frame with hysteresis (on > 90 px inward, off < 40 px) so it never flickers at the crossover;
  //  - this.front[side] (baked `front` layers, anims.json) lifts that whole arm (forearm, then its fist) above the other arm, so
  //    crossed arms keep one consistent arm on top and the striking arm is never cut by the idle one.
  // Glow masks render the same meshes (selective bloom), so they follow. Everything stays < 130 (water puffs 132, mist 180, hero 360+).
  drawOrder() {
    const by = this.byName, fr = this.front || {}, X = this._cross || (this._cross = { L: false, R: false });
    for (const S of ['L', 'R']) { const sh = by['sh' + S], el = by['el' + S]; if (!sh || !el) continue;
      const inward = (el.m[4] - sh.m[4]) * (S === 'L' ? 1 : -1); // rig x: L arm sits at -x, so + = toward the body centre
      X[S] = X[S] ? inward > 40 : inward > 90; }
    for (const p of this.parts) { if (!p.side) continue;
      if (p.seg === 'sh') { p.mesh.renderOrder = X[p.side] ? p.roF : p.ro; continue; }
      const f = fr[p.side] || 0; p.mesh.renderOrder = f ? 117 + 2 * f + (p.seg === 'wr' ? 1 : 0) : p.ro; }
    this.hitOrder = null; // hit() re-sorts by the new order
  }
  // bone-local pixel point -> puppet-group-local world units
  point(bone, lx, ly, out = new THREE.Vector3()) {
    const [x, y] = ap(this.byName[bone].m, lx, ly);
    return out.set((x - this.ox) * this.k, (this.oy - y) * this.k, 0.5);
  }
  // is the group-local point (x, y) on an opaque pixel of any skinned part? (CPU: skinned triangles -> UV -> alpha map)
  hit(x, y) {
    const order = this.hitOrder || (this.hitOrder = this.parts.slice().sort((a, b) => b.mesh.renderOrder - a.mesh.renderOrder)); // front-most first
    for (const p of order) {
      const bb = p.bb; if (x < bb[0] || x > bb[2] || y < bb[1] || y > bb[3]) continue;
      const P = p.pos, U = p.uv, I = p.idx, al = p.al;
      for (let t = 0; t < I.length; t += 3) {
        const a = I[t], b = I[t + 1], c = I[t + 2];
        const ax = P[3 * a], ay = P[3 * a + 1], bx = P[3 * b], by = P[3 * b + 1], cx = P[3 * c], cy = P[3 * c + 1];
        const d = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy); if (Math.abs(d) < 1e-9) continue;
        const l1 = ((by - cy) * (x - cx) + (cx - bx) * (y - cy)) / d; if (l1 < 0 || l1 > 1) continue;
        const l2 = ((cy - ay) * (x - cx) + (ax - cx) * (y - cy)) / d; if (l2 < 0 || l1 + l2 > 1) continue;
        const l3 = 1 - l1 - l2, u = U[2 * a] * l1 + U[2 * b] * l2 + U[2 * c] * l3, v = U[2 * a + 1] * l1 + U[2 * b + 1] * l2 + U[2 * c + 1] * l3;
        const ix = Math.min(al.w - 1, Math.max(0, Math.floor(u * al.w))), iy = Math.min(al.h - 1, Math.max(0, Math.floor(v * al.h)));
        if (al.a[iy * al.w + ix] > 110) return p; // the part that was hit (its bone tells the body area)
      }
    }
    return null;
  }
  setUniform(name, v) { for (const m of this.mats) if (m.uniforms[name]) m.uniforms[name].value = v; }
}
export { smooth };
