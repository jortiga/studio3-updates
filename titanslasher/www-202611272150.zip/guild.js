// Titan Slasher GUILDS (11-27), no login. Client side of server/guild.sql. LOGIC ONLY (UI: prog-ui.js guildPanel, the lobby
// GUILD chip that replaced the old INVITE chip).
// Identity = the anonymous leaderboard identity (leaderboard.js: device UUID + secret, LB.auth()); every call is checked on the
// server (lb_auth). The client is never trusted: level / code / cap / join-once / rate limit are all server-side checks.
// Rules (11-28, server/guild_lv.sql): guilds unlock at Lv 10 (founding is checked on the server, the join lock is in the game);
// one guild at a time, not your own, cap 30, 5 join attempts / hour. BONUS: more shards from titan fights, +1% (alone) to +7% (30 members), see tier().
// 24 h (lb_config guild_leave_cooldown_h). A leaving master hands over to the longest-standing member, or the guild is deleted.
// The welcome chest is once per player id ever (an unopened one comes back with the next join).
// Reward (tunable on the server, lb_config guild_*): the joiner's one-time welcome chest of rarity r (default 0 = common),
// claimed via guild_claim, paid here only after ok (DROPS.chestItem + EQ.grant; SAVE.guild.paid guards a double pay per save).
// No shards. Master reward OFF.
// States from load(): { st: 'ok', guild, can_join, welcome, cooldown_s, cooldown_h, ... } | { st: 'offline' } (no net / timeout /
// server error). cooldownLeft() = the leave cooldown seconds left now.
// LIVE since 11-27 (server/guild.sql applied to slash-titans, tested end to end with throwaway players, then deleted).
// Test URL: ?guildmock=1 (fake server in memory, fresh player), ?guildmock=own (you own a guild with members),
// ?guildmock=joined (you joined a 12-member guild, welcome chest waiting), ?guildmock=solo (you own a guild alone),
// ?guildmock=left (you just left: 24 h cooldown). Use with ?lv=N for the Lv 15 lock.
// Store builds (later): the player id gets bound to a verified Play Games / Game Center id (see server/referrals.sql TODO).

export const MIN_LV = 10, BONUS_MIN = 1, BONUS_MAX = 7, CAP = 30, CODE_RE = /^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/; // BONUS_* = percent at 1 member / a full guild
const Q = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
const MOCK = Q.has('guildmock') ? (Q.get('guildmock') || '1') : null;
let C = null, ST = null;
const lb = () => (C && C.LB) || (typeof window !== 'undefined' ? window.__lb : null);
const prog = () => (typeof window !== 'undefined' && window.PROG ? window.PROG.state() : { level: 1, total: 0 });
function sv() { const S = C.SAVE; if (!S.guild || typeof S.guild !== 'object') S.guild = {}; return S.guild; }
export const clean = (c) => String(c || '').toUpperCase().replace(/[^ABCDEFGHJKMNPQRSTUVWXYZ23456789]/g, '').slice(0, 6); // codes never use 0 O 1 I L

async function rpc(fn, args) {
  if (MOCK) return mock(fn, args);
  const L = lb(); if (!L || !L.configured || !L.rpc || !L.auth) { const e = new Error('offline'); throw e; }
  if (L.register && !(await L.register())) throw new Error('reg');
  return L.rpc(fn, { ...L.auth(), ...args });
}
// 11-27 guild.sql is LIVE: no "coming soon" state any more; a missing RPC / timeout / server error all read as offline (TRY AGAIN)
const fail = () => ({ st: 'offline' });

// status (also refreshes the member's shown level on the server)
let loadP = null, loadAt = 0;
export function load() {
  if (loadP) return loadP;
  loadP = (async () => {
    try { const j = await rpc('guild_info', { p_lv: prog().level }); ST = j && j.ok ? { st: 'ok', ...j, cooldownEnd: Date.now() + (+j.cooldown_s || 0) * 1000 } : { st: 'offline' };
      if (ST.st === 'ok' && C) { const S = sv(), n = ST.guild ? +ST.guild.count || 1 : 0; if (S.n !== n) { S.n = n; delete S.in; C.save(); } } } // member count remembered, so the bonus also counts offline
    catch (e) { ST = fail(e); }
    loadAt = Date.now(); return ST;
  })().finally(() => { loadP = null; });
  return loadP;
}
// after a change: a status read that was already running may predate it, so let it finish and read again
const reload = async () => { if (loadP) await loadP; return load(); };
// lobby badge refresh: at most every 3 min (one small RPC), never while a call is running
export const refresh = () => { if (!loadP && Date.now() - loadAt > 180000) load(); };
export const state = () => ST;
export const hasWelcome = () => !!(ST && ST.st === 'ok' && ST.welcome && ST.guild);
// guilds locked: below Lv 10 and not already a member
export const locked = () => prog().level < MIN_LV && !(ST && ST.guild) && !(C && C.SAVE.guild?.n);
// the shard bonus for a guild of n members (0 = no guild), as a fraction in 0.5% steps (0.035 = +3.5%), and the player's own;
// nextAt(n) = the member count where it next goes up (0 = already max)
export const tier = (n) => (n > 0 ? Math.round((BONUS_MIN + (Math.min(n, CAP) - 1) * (BONUS_MAX - BONUS_MIN) / (CAP - 1)) * 2) / 200 : 0);
export const nextAt = (n) => { for (let m = n + 1; m <= CAP; m++) if (tier(m) > tier(n)) return m; return 0; };
export const bonus = () => tier((C && C.SAVE.guild?.n) || 0);
// seconds of the leave cooldown left (0 = may join / found); counts down locally between status reads, the server decides
export const cooldownLeft = () => (ST && ST.st === 'ok' && !ST.guild ? Math.max(0, Math.ceil((ST.cooldownEnd - Date.now()) / 1000)) : 0);
// found your guild -> { ok, guild } | { ok: false, error: lv|in_guild|cooldown (+ wait_s)|offline }
export async function create() {
  const p = prog();
  try { const j = await rpc('guild_create', { p_lv: p.level, p_xp: p.total }); if (j && (j.ok || j.error === 'cooldown')) await reload(); return j || { ok: false, error: 'offline' }; }
  catch (e) { return { ok: false, error: fail(e).st }; }
}
// join with a code -> { ok, guild, welcome } | { ok: false, error: rate|format|code|self|in_guild|cooldown (+ wait_s)|full|offline }
export async function join(code) {
  const c = clean(code); if (!CODE_RE.test(c)) return { ok: false, error: 'format' };
  try { const j = await rpc('guild_join', { p_code: c }); if (j && (j.ok || j.error === 'cooldown')) await reload();
    else if (j && ST && ST.st === 'ok') ST.attempts_left = j.error === 'rate' ? 0 : Math.max(0, (+ST.attempts_left || 0) - 1); // every server attempt counts (5 / hour)
    return j || { ok: false, error: 'offline' }; }
  catch (e) { return { ok: false, error: fail(e).st }; }
}
export async function rename(name) {
  try { const j = await rpc('guild_set_name', { p_name: String(name || '').trim() }); if (j && j.ok) await reload(); return j || { ok: false, error: 'offline' }; }
  catch (e) { return { ok: false, error: fail(e).st }; }
}
// leave your guild -> { ok, was_master, deleted, new_master, cooldown_s } | { ok: false, error: none|offline }
export async function leave() {
  try { const j = await rpc('guild_leave', {}); if (j && (j.ok || j.error === 'none')) await reload(); return j || { ok: false, error: 'offline' }; }
  catch (e) { return { ok: false, error: fail(e).st }; }
}
// claim the welcome chest once (server) and pay it here -> { ok, id (item id), dup } | { ok: false, error }
export async function claim() {
  try {
    const j = await rpc('guild_claim', {});
    if (!j || !j.ok) { if (ST) ST.welcome = null; return j || { ok: false, error: 'offline' }; }
    if (ST) ST.welcome = null;
    const S = sv(); if (S.paid) return { ok: true, id: null, already: true }; // this save got its chest already (e.g. a new id on an old save)
    const id = C.chestItem ? C.chestItem(+j.rarity || 0) : null, g = id && C.EQ && C.EQ.grant(id);
    S.paid = Date.now(); C.save();
    return { ok: true, id, dup: g ? !!g.dup : false, rarity: +j.rarity || 0 };
  } catch (e) { return { ok: false, error: fail(e).st }; }
}

// ---------------------------------------------------------------- ?guildmock= fake server (same answers as guild.sql)
const NAMES = ['InkMonk', 'Ashblade', 'Slasher4821', 'Ronin_K', 'Moonfang', 'Tidecutter', 'Veyra', 'Gloomhook', 'Brakka', 'Saltwind', 'Nyx-7'];
let M = null;
function mockInit() {
  const me = (lb() && lb().nick) || 'You', now = Date.now();
  const others = NAMES.filter((n) => n !== 'Moonfang');
  const mem = (n) => Array.from({ length: n }, (_, i) => [others[i % others.length], 4 + ((i * 7) % 30), false, false, now - i * 9e5]);
  M = { me, guild: null, joined: false, welcome: null, pending: null, att: 0, leftAt: 0 };
  if (MOCK === 'solo') M.guild = { code: 'K7QX3M', name: `${me}'s Guild`, is_master: true, master: me, members: [[me, prog().level, true, true, now]] };
  if (MOCK === 'left') { M.joined = true; M.leftAt = now - 6e4; }
  if (MOCK === 'own') M.guild = { code: 'K7QX3M', name: `${me}'s Guild`, is_master: true, master: me, members: [[me, prog().level, true, true, now], ...mem(4)] };
  if (MOCK === 'joined') { M.guild = { code: 'R4WNP8', name: 'Ink Wardens', is_master: false, master: 'Moonfang', members: [['Moonfang', 31, true, false, now], ...mem(10), [me, prog().level, false, true, now]] }; M.joined = true; M.welcome = { rarity: 0 }; }
}
function pack() { if (!M.guild) return null; const g = M.guild; return { ...g, next_master: g.is_master ? (g.members.find((m) => !m[3]) || [null])[0] : null, count: g.members.length, cap: 30 }; }
const mockWait = () => (M.leftAt ? Math.max(0, Math.ceil((M.leftAt + 864e5 - Date.now()) / 1000)) : 0);
async function mock(fn, a) {
  if (!M) mockInit(); await new Promise((r) => setTimeout(r, 120));
  const p = prog();
  if (fn === 'guild_info') return { ok: true, now: Date.now(), guild: pack(), can_join: !M.guild && !mockWait(), joined_before: M.joined, welcome: M.welcome, min_lv: MIN_LV, attempts_left: Math.max(0, 5 - M.att), cooldown_s: M.guild ? 0 : mockWait(), cooldown_h: 24, mock: true };
  if (fn === 'guild_create') {
    if (M.guild && M.guild.is_master) return { ok: true, guild: pack() }; if (M.guild) return { ok: false, error: 'in_guild' };
    if (mockWait()) return { ok: false, error: 'cooldown', wait_s: mockWait() };
    if (a.p_lv < MIN_LV) return { ok: false, error: 'lv' };
    M.guild = { code: 'K7QX3M', name: `${M.me}'s Guild`, is_master: true, master: M.me, members: [[M.me, p.level, true, true, Date.now()]] }; return { ok: true, guild: pack() };
  }
  if (fn === 'guild_join') {
    if (M.att >= 5) return { ok: false, error: 'rate' }; M.att++;
    if (M.guild) return { ok: false, error: M.guild.code === a.p_code ? 'self' : 'in_guild' };
    if (mockWait()) return { ok: false, error: 'cooldown', wait_s: mockWait() };
    if (a.p_code === 'AAAAAA') return { ok: false, error: 'code' }; if (a.p_code === 'FFFFFF') return { ok: false, error: 'full' };
    const now = Date.now();
    M.guild = { code: a.p_code, name: 'Ink Wardens', is_master: false, master: 'Moonfang', members: [['Moonfang', 31, true, false, now], ['Ashblade', 22, false, false, now - 3e6], ['Veyra', 12, false, false, now - 8e6], [M.me, p.level, false, true, now]] };
    M.welcome = M.joined ? M.pending : { rarity: 0 }; M.pending = null; M.joined = true; return { ok: true, guild: pack(), welcome: M.welcome };
  }
  if (fn === 'guild_leave') {
    if (!M.guild) return { ok: false, error: 'none' };
    const was = M.guild.is_master, heir = was ? pack().next_master : null;
    M.pending = M.welcome || M.pending; M.welcome = null; M.guild = null; M.leftAt = Date.now();
    return { ok: true, was_master: was, deleted: was && !heir, new_master: heir, cooldown_s: mockWait() };
  }
  if (fn === 'guild_claim') { if (!M.welcome) return { ok: false, error: M.joined ? 'claimed' : 'none' }; const r = M.welcome.rarity; M.welcome = null; return { ok: true, rarity: r }; }
  if (fn === 'guild_set_name') { if (!M.guild || !M.guild.is_master) return { ok: false, error: 'master' }; if (!/^[A-Za-z0-9 '_-]{3,24}$/.test(a.p_name)) return { ok: false, error: 'name' }; M.guild.name = a.p_name; return { ok: true, guild: pack() }; }
  return { ok: false, error: 'offline' };
}

// ctx: { SAVE, save, LB, EQ, chestItem(rarity) -> item id }
export function init(ctx) { C = ctx; }
export const isMock = () => !!MOCK;

const GUILD = { init, load, refresh, state, hasWelcome, create, join, rename, leave, claim, locked, bonus, tier, nextAt, cooldownLeft, clean, isMock, MIN_LV, BONUS_MIN, BONUS_MAX, CAP };
if (typeof window !== 'undefined') window.GUILD = GUILD;
export default GUILD;
