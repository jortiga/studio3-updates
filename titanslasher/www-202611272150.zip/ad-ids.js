window.TT_AD_IDS = {"appId": "ca-app-pub-5151387136918372~7115436514", "rewarded": "ca-app-pub-5151387136918372/1286852772", "testing": false, "testDevices": ["58FE6CBF420E7F9D5339A2AE1EC80707"], "ios": {"appId": "ca-app-pub-5151387136918372~8103542565", "rewarded": "ca-app-pub-5151387136918372/2006259267", "testing": false, "testDevices": []}};
window.TT_DEV = false;
window.S3A_ID = null;
