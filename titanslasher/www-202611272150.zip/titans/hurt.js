// 11-27 HURT FEEDBACK (user, iPhone, all 10 ink titans: "we need some sort of indicator the titan is getting hurt ... no reaction").
// The heavy pass (react.js) took the rotation out of hits, so the "it's hurt" read now comes from light and marks, never rotation:
//  - HIT FLASH on the struck part (+ the parts of the same body area, e.g. head + jaw): an additive flash in the blade's colour
//    (white-ish, tinted by the equipped blade), ~100 ms; crits / finisher hits also flash the whole body softly;
//  - HURT TINT: a red pulse on the whole body per hit that grows with the combo and with hits landing in a row (a "worn" level that
//    builds while you keep hitting, decays ~3 s after you stop);
//  - WOUND MARKS: a small pool (6) of painted-on-the-fly ink cracks / drips glued to the struck bone (they ride the animation),
//    fade over ~1.2 s; crits / weak points / finisher always leave one, normal taps sometimes;
//  (the part's squash + 2-4 px knock is react.js punch(); impact sparks + chips + hit-stop are in main.js tapStrike / wpHit).
// Cost: one pass over the titan's ~12-20 materials per frame (already done for the base tint) + <= 6 decal quads.
// `?hurt=0` = off (A/B).
import * as THREE from 'three';

export const HURT_ON = new URLSearchParams(location.search).get('hurt') !== '0';
const KIND = { // flash on the struck area, soft whole-body flash, red pulse, hurt build-up, wound mark chance
  tap: { f: .75, b: 0, p: .45, h: .05, m: .14 },
  crit: { f: 1, b: .15, p: .7, h: .09, m: 1 },
  wp: { f: .75, b: .06, p: .45, h: .06, m: .3 },
  wp10: { f: 1.1, b: .16, p: .8, h: .12, m: 1 },
  fin: { f: 1, b: .2, p: .8, h: .1, m: .6 },
};

// one canvas atlas: 4 crack variants (top row) + 4 drip variants (bottom row), white on transparent; tinted in the shader
function makeAtlas() {
  const S = 128, cv = document.createElement('canvas'); cv.width = S * 4; cv.height = S * 2; const g = cv.getContext('2d');
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = '#fff'; g.fillStyle = '#fff';
  for (let i = 0; i < 4; i++) { // cracks: 3-5 jagged branches from the centre
    const cx = i * S + S / 2, cy = S / 2, n = 3 + (i % 3);
    for (let k = 0; k < n; k++) { let a = (k / n) * 6.283 + rnd() * .8, x = cx, y = cy, w = 10;
      g.beginPath(); g.moveTo(x, y);
      for (let s = 0; s < 5; s++) { a += (rnd() - .5) * 1.1; const l = 8 + rnd() * 9; x += Math.cos(a) * l; y += Math.sin(a) * l; g.lineWidth = w; g.lineTo(x, y); g.stroke(); g.beginPath(); g.moveTo(x, y); w *= .74;
        if (rnd() < .35) { const b = a + (rnd() < .5 ? 1 : -1) * (.6 + rnd() * .6); g.lineWidth = w * .7; g.lineTo(x + Math.cos(b) * 10, y + Math.sin(b) * 10); g.stroke(); g.beginPath(); g.moveTo(x, y); } } }
    g.beginPath(); g.arc(cx, cy, 9, 0, 6.283); g.fill(); }
  for (let i = 0; i < 4; i++) { // ink splat + 2-3 drips running down
    const cx = i * S + S / 2, cy = S + 34; g.beginPath(); g.arc(cx, cy, 13 + rnd() * 5, 0, 6.283); g.fill();
    for (let k = 0; k < 7; k++) { const a = rnd() * 6.283, r = 14 + rnd() * 10; g.beginPath(); g.arc(cx + Math.cos(a) * r, cy + Math.sin(a) * r * .8, 2 + rnd() * 4, 0, 6.283); g.fill(); }
    const nd = 2 + (i % 2); for (let k = 0; k < nd; k++) { const x = cx - 10 + k * (20 / Math.max(1, nd - 1)) + (rnd() - .5) * 4, l = 30 + rnd() * 52, w = 3 + rnd() * 3;
      g.fillRect(x - w / 2, cy, w, l); g.beginPath(); g.arc(x, cy + l, w * .95, 0, 6.283); g.fill(); } }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.NoColorSpace; t.flipY = false; t.needsUpdate = true; return t;
}
let ATLAS = null;
function decalMat() {
  return new THREE.ShaderMaterial({ transparent: true, depthWrite: false, depthTest: false,
    uniforms: { map: { value: ATLAS }, cell: { value: new THREE.Vector2(0, 0) }, a: { value: 0 }, ink: { value: new THREE.Color(.05, .02, .04) }, edge: { value: new THREE.Color(1, .3, .2) }, hot: { value: 0 }, run: { value: 0 } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }',
    fragmentShader: `uniform sampler2D map; uniform vec2 cell; uniform float a; uniform vec3 ink; uniform vec3 edge; uniform float hot; uniform float run; varying vec2 vUv;
      void main(){ vec2 uv = vec2(vUv.x, 1. - vUv.y); /* local cell coords, top = 0 (atlas flipY off) */ if (cell.y > .5 && uv.y > .4 + run * .6) discard; /* drips run down */
        float m = texture2D(map, (uv + cell) * vec2(.25, .5)).a; if (m < .03) discard;
        vec3 c = mix(ink, edge * 1.25, clamp(hot, 0., 1.)); /* fresh = glowing in the titan's colour, then cools to ink */
        gl_FragColor = vec4(c, m * a * .9); }` });
}

export class HurtFX {
  // puppet: titan Puppet (parts[i].mesh.material = sprite material with tint / flash uniforms)
  constructor(puppet) {
    this.P = puppet; const n = puppet.parts.length;
    this.f = new Float32Array(n); this.idx = new Map(puppet.parts.map((p, i) => [p, i]));
    this.area = puppet.parts.map((p) => p.pt.area || p.pt.bone);
    this.body = 0; this.pulse = 0; this.worn = 0; this.col = new THREE.Color(1, 1, 1); this.red = 0;
    if (!ATLAS) ATLAS = makeAtlas();
    this.marks = []; for (let i = 0; i < 6; i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), decalMat()); m.visible = false; m.renderOrder = 131; m.frustumCulled = false;
      puppet.group.add(m); this.marks.push({ m, t: 9, life: 1, bone: null, lx: 0, ly: 0, s: 1, drip: 0 }); }
    this.mi = 0; this.n = 0;
  }
  // part: the Puppet part that was struck (or null = whole body); kind: tap | crit | wp | wp10 | fin; rig: { x, y } puppet-group-local
  // point of the blow (for the wound mark); blade: THREE.Color of the equipped blade (flash colour)
  hit(part, kind = 'tap', rig = null, blade = null) {
    if (!HURT_ON) return; const K = KIND[kind] || KIND.tap; this.n++;
    if (blade) this.col.setRGB(.62 + blade.r * .38, .62 + blade.g * .38, .62 + blade.b * .38); // white-hot, tinted toward the blade
    if (part) { const a = this.area[this.idx.get(part)]; for (let i = 0; i < this.f.length; i++) { const own = this.P.parts[i] === part;
      if (own || this.area[i] === a) this.f[i] = Math.max(this.f[i], K.f * (own ? 1 : .6)); } }
    else this.body = Math.max(this.body, K.f * .45);
    this.body = Math.max(this.body, K.b);
    this.worn = Math.min(1, this.worn + K.h); this.pulse = Math.max(this.pulse, K.p * (.6 + this.worn * .6));
    // wound mark: crit / weak x10 always, others by chance (deterministic cycle so it's spread, not bursty)
    if (part && rig && ((this.n * .618) % 1) < K.m) this.mark(part, rig, kind);
  }
  mark(part, rig, kind) {
    const P = this.P, B = part.A; if (!B) return;
    const qx = rig.x / P.k + P.ox, qy = P.oy - rig.y / P.k, m = B.m, det = m[0] * m[3] - m[2] * m[1] || 1, dx = qx - m[4], dy = qy - m[5];
    const M = this.marks[this.mi = (this.mi + 1) % this.marks.length], drip = kind === 'tap' ? (this.n % 2) : (this.n % 3 === 0 ? 1 : 0);
    M.bone = B.name; M.lx = (m[3] * dx - m[2] * dy) / det; M.ly = (-m[1] * dx + m[0] * dy) / det; M.t = 0; M.life = kind === 'tap' ? .9 : 1.4;
    M.drip = drip; M.s = (kind === 'tap' ? 46 : kind === 'wp' ? 56 : 72) * (P.pxRig || 2) * (.85 + ((this.n * .37) % 1) * .3);
    const u = M.m.material.uniforms; u.cell.value.set(this.n % 4, drip); u.run.value = 0; u.hot.value = 1; M.m.rotation.z = drip ? 0 : (this.n * 2.39996) % 6.283;
    u.edge.value.copy(this.edge || u.edge.value);
  }
  setEdge(c) { this.edge = new THREE.Color(c[0], c[1], c[2]); }
  update(dt, chain = 0) {
    const f = Math.exp(-dt * 24); for (let i = 0; i < this.f.length; i++) this.f[i] *= f; // ~100 ms flash
    this.body *= Math.exp(-dt * 13); this.pulse *= Math.exp(-dt * 4);
    this.worn = Math.max(0, this.worn - dt * .12);
    const combo = Math.min(1, chain / 120);
    this.red = Math.min(1, this.pulse * .85 + this.worn * .32 + combo * .15);
    const P = this.P, k = P.k;
    for (const M of this.marks) { if (M.t >= M.life) { M.m.visible = false; continue; } M.t += dt; const B = P.byName[M.bone]; if (!B) continue;
      const u = M.m.material.uniforms, x = M.t / M.life; P.point(M.bone, M.lx, M.ly, M.m.position); M.m.position.z = .6;
      const s = M.s * k * (x < .08 ? .7 + x / .08 * .3 : 1); M.m.scale.set(s, s * (M.drip ? 1.6 : 1), 1); if (M.drip) M.m.position.y -= s * .45;
      u.a.value = (x < .05 ? x / .05 : 1) * (1 - Math.pow(Math.max(0, (x - .45) / .55), 1.5)); u.hot.value = Math.max(0, 1 - x * 1.5); u.run.value = M.drip ? Math.min(1, x * 1.6) : 0; M.m.visible = true; }
  }
  // per frame after the base tint / flash are known: writes every titan material
  apply(tint, fr, fg, fb) {
    const P = this.P, c = this.col, r = HURT_ON ? this.red : 0, b = HURT_ON ? this.body : 0;
    const tr = tint.r * (1 + r * .45), tg = tint.g * (1 - r * .5), tb = tint.b * (1 - r * .55);
    for (let i = 0; i < P.parts.length; i++) { const u = P.parts[i].mesh.material.uniforms, k = HURT_ON ? this.f[i] + b : 0;
      u.tint.value.setRGB(tr, tg, tb); u.flash.value.setRGB(fr + c.r * k + r * .1, fg + c.g * k + r * .01, fb + c.b * k + r * .015); }
  }
  reset() { this.f.fill(0); this.body = this.pulse = this.worn = this.red = 0; for (const M of this.marks) { M.t = 9; M.m.visible = false; } }
}
