// SPRING REACTIONS (11-26, user: "this practice twig has very good fluid animation" -> dummy.js feel on the titans). Shared by
// every archetype (titan.js humanoid, procanim.js beast / serpent / core), applied POST-spring on top of the baked + procedural pose:
//  - a hit pushes the struck part AWAY from the tap: torque from the tap point relative to the part's bone pivot (lever arm x a
//    sideways push toward the part's centre line), an angular velocity impulse on that bone; its ancestors get a smaller share a
//    few frames later (lag down the chain: head -> neck -> chest), the torso a gentle squash.
//  - every bone channel is a damped spring (stone: heavier and more damped than the straw dummy), clamped, so fast tapping keeps
//    the body "excited" but never jitters; impulses saturate per bone.
//  - idle drift: a slow smooth noise force into the same springs (the sway reads physical instead of keyframed).
// 11-27 HEAVY (user: "it rotates when it's hit - these are titans, they should be hard as f***"): titans are unshakeable.
//  - rotation impulses x HEAVY.r and clamped to HEAVY.max (< 1 deg), struck bone only (no lagged share up a neck / tentacle chain:
//    5 chained bones x 7 deg each turned whole heads 15-28 deg);
//  - NO translation of the struck bone (moving a head / jaw off its neck read as a detached part); instead a short stiff positional
//    SHUDDER of the whole body (root bone, rig px), bigger but still short for heavy blows (finisher, x10 weak point);
//  - idle drift only on the torso (heads never wobble on their own; they follow the body).
// `?heavy=0` = the old springy reactions (comparison).
// cfg (titan.json "react"): { k, c (spring), gain, max (rad), lag (s), share (ancestor share), squash, drift, bones: { name: { k, c, gain, max } } }
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const DEF = { k: 60, c: 9, gain: 1, max: .12, lag: .05, share: .45, squash: .02, drift: .25 };
const HQ = new URLSearchParams(location.search).get('heavy');
export const HEAVY = HQ === '0' ? null : { r: .1, max: .012, shake: 1, drift: ['chest', 'hips'] };
const PUNCH = new URLSearchParams(location.search).get('hurt') !== '0'; // ?hurt=0: no punch / hurt fx (A/B)
const LOOSE = /^(chain|rock|pend|banner|lantern|mane|moss|fringe|tass|plate)/; // loose bits may still swing a little
// 11-27 user "add some very subtle push rotation hit": the punch also tips the struck part away from the blow (~1 deg tap, ~2 deg big
// hit), eased back in ~.25 s. Leaf parts full, bones with children (neck links, upper arms) 35 % so chains don't add up; torso none.
const PR = parseFloat(new URLSearchParams(location.search).get('hitrot')), PUSHROT = .026 * (isFinite(PR) ? Math.max(0, Math.min(4, PR)) : 1);

export class SpringReact {
  constructor(puppet, cfg = {}) {
    this.P = puppet; this.c = { ...DEF, ...cfg }; this.s = {}; this.q = []; this.t = 0;
    this.skip = new Set(cfg.skip || ['root']);
    if (HEAVY) this.c.driftBones = (this.c.driftBones || []).filter((b) => HEAVY.drift.includes(b) || LOOSE.test(b));
    this.root = puppet.byName.root ? 'root' : puppet.bones[0]?.name; this.sh = { x: 0, vx: 0, y: 0, vy: 0, n: 0 }; this.pu = {};
  }
  sp(b) { return this.s[b] || (this.s[b] = { r: 0, v: 0, y: 0, vy: 0 }); }
  // 11-27 HURT PUNCH (user: "no reaction" after the heavy pass): the struck part squashes (scale ~.96 -> 1, about its own joint, so it
  // stays seated) and is knocked 2-4 SCREEN px away from the blow (dir = -1 / +1 sideways, a little up), snapping back in ~.1 s. No
  // rotation. Torso bones only squash (the whole-body shudder already moves them). P.pxRig = rig px per screen px (main.js, per frame).
  punch(b, s = .3, dir = 0, rs = 0) { if (!HEAVY || !PUNCH || this.skip.has(b)) return; const k = Math.min(1.2, .45 + s * .9);
    const S = this.pu[b] || (this.pu[b] = { a: 0, d: 0 }); S.a = Math.min(1.25, Math.max(S.a, k)); S.d = dir || S.d || 1; S.rs = rs || S.d; S.ra = Math.min(1.25, Math.max(S.ra || 0, k)); }
  par(b) { return this.c.bones?.[b] || {}; }
  // whole-body positional shudder (rig px velocity kick into a stiff, heavily damped spring): s = blow strength (.25 tap .. 1.2 finisher)
  shudder(s = .3, dir = 0) { if (!HEAVY) return; const S = this.sh, k = HEAVY.shake * Math.min(1.5, s);
    S.n++; const j = ((S.n * 0.618) % 1) * 2 - 1; // deterministic jitter direction
    S.vx = clamp(S.vx + (dir || j) * 110 * k, -260, 260); S.vy = clamp(S.vy + 70 * k, -200, 200); }
  // bone: the struck part's bone; (x, y): tap in puppet-group-local world units (puppet.hit space); s: strength (0..1.5)
  hit(bone, x, y, s = 1, scale = 1) {
    const P = this.P, B = P.byName[bone]; if (!B || this.skip.has(bone)) return;
    const qx = x / P.k + P.ox, qy = P.oy - y / P.k; // -> rig px
    const m = B.m, px = m[4], py = m[5];
    // part centre ~ halfway down the bone's first child (or 60 px under the pivot): the push points toward the centre line
    const ch = P.bones.find((c) => c.p === B), cx = ch ? (px + ch.m[4]) / 2 : px;
    const sx = Math.sign(qx - cx) || (Math.random() < .5 ? 1 : -1), dy = qy - py;
    const lever = clamp(dy / 120, -1.5, 1.5); // y-down: a tap above the pivot (dy < 0) on the right turns it counter-clockwise
    if (HEAVY) { // struck bone only, tiny, no translation; the body answers with a shudder
      this.q.push({ t: this.t, b: B.name, v: sx * lever * s * scale * HEAVY.r * (LOOSE.test(B.name) ? 3 : 1), vy: 0 });
      this.shudder(s * scale * .6, -sx); this.punch(B.name, s * scale, -sx, sx * (lever > 0 ? 1 : -1)); return; }
    const imp = sx * lever * s * scale * this.c.gain;
    let b = B, k = 1, d = 0;
    while (b && !this.skip.has(b.name) && k > .05) {
      this.q.push({ t: this.t + d, b: b.name, v: imp * k * (this.par(b.name).gain ?? 1), vy: (k === 1 ? 1 : .5) * s * scale });
      b = b.p; k *= this.c.share; d += this.c.lag;
    }
    const torso = P.byName.chest ? 'chest' : null; if (torso) this.sp(torso).vy -= this.c.squash * s * scale * 40; // squash (sy) on the torso
  }
  update(dt, t) {
    this.t += dt;
    for (let i = this.q.length - 1; i >= 0; i--) { const e = this.q[i]; if (e.t > this.t) continue; const S = this.sp(e.b), mx = this.mx(e.b);
      S.v = clamp(S.v + e.v * 6, -mx * 14, mx * 14); if (e.b !== 'chest') S.vy = clamp(S.vy + e.vy * 18, -60, 60); this.q.splice(i, 1); }
    const dr = this.c.drift;
    if (dr > 0 && dt > 0) for (const b of this.c.driftBones || []) { const S = this.sp(b), h = b.length * 1.7; // smooth noise force: two detuned slow sines
      S.v += dt * dr * (Math.sin(t * .37 + h) * .6 + Math.sin(t * .23 + h * 2.1) * .4) * .08 * (HEAVY ? .5 : 1); }
    const n = Math.min(4, Math.max(1, Math.ceil(dt * 60))), h = dt / n;
    for (const b in this.s) { const S = this.s[b], p = this.par(b), K = p.k ?? this.c.k, C = p.c ?? this.c.c, mx = this.mx(b);
      if (dt > 0) for (let i = 0; i < n; i++) { S.v += (-K * S.r - C * S.v) * h; S.r += S.v * h; S.vy += (-K * 1.6 * S.y - C * 1.3 * S.vy) * h; S.y += S.vy * h; }
      S.r = clamp(S.r, -mx, mx); S.y = clamp(S.y, -14, 14); }
    // shudder: stiff (~9 Hz) and near-critically damped -> 2-3 px, gone in ~0.25 s
    const S = this.sh; if (dt > 0) for (let i = 0; i < n; i++) { S.vx += (-3200 * S.x - 95 * S.vx) * h; S.x += S.vx * h; S.vy += (-3200 * S.y - 95 * S.vy) * h; S.y += S.vy * h; }
    S.x = clamp(S.x, -7, 7); S.y = clamp(S.y, -5, 5);
    // punch envelope: instant on the hit, exponential snap back (~90 % gone after .11 s)
    if (dt > 0) { const f = Math.exp(-dt * 21), fr = Math.exp(-dt * 11); for (const b in this.pu) { const U = this.pu[b]; U.a *= f; U.ra *= fr; if (U.a < .01 && U.ra < .03) delete this.pu[b]; } }
  }
  // heavy max: torso never turns from a hit, a bone with children (neck links, upper arms) barely, leaves (head, fist, jaw) < .7 deg
  mx(b) { const m = this.par(b).max ?? this.c.max; if (!HEAVY) return m; if (LOOSE.test(b)) return Math.min(m, HEAVY.max * 3);
    if (/^(root|hips|chest)$/.test(b)) return 0; const B = this.P.byName[b], kids = B && this.P.bones.some((c) => c.p === B);
    return Math.min(m, HEAVY.max * (kids ? .3 : 1)); }
  // post-spring offsets into the puppet pose (call after the animator's own P.set()s, before P.update())
  apply() { for (const b in this.s) { const S = this.s[b]; if (Math.abs(S.r) < 1e-5 && Math.abs(S.y) < 1e-3) continue;
    if (b === 'chest') this.P.set(b, { r: S.r, sy: S.y * .004, sx: -S.y * .0025 }); else this.P.set(b, { r: S.r, y: S.y }); }
    const S = this.sh; if (this.root && (Math.abs(S.x) > .01 || Math.abs(S.y) > .01)) this.P.set(this.root, { x: S.x, y: S.y });
    const pr = this.P.pxRig || 2;
    for (const b in this.pu) { const U = this.pu[b], B = this.P.byName[b], a = U.a; if (!B) continue;
      if (/^(root|hips|chest)$/.test(b)) { this.P.set(b, { sx: -.022 * a, sy: -.022 * a }); continue; } // torso: squash only
      // knock: rig-space direction (sideways away from the blow, slightly up), ~3 screen px at a = 1, into the parent's local frame
      const L = 3 * pr * a, wx = U.d * L * .92, wy = -L * .38, m = B.p ? B.p.mr : null;
      let lx = wx, ly = wy; if (m) { const det = m[0] * m[3] - m[2] * m[1] || 1; lx = (m[3] * wx - m[2] * wy) / det; ly = (-m[1] * wx + m[0] * wy) / det; }
      const rot = U.rs * PUSHROT * (U.ra || 0) * (this.P.bones.some((c) => c.p === B) ? .35 : 1); // the push tip (radians)
      this.P.set(b, { r: rot, x: lx, y: ly, sx: -.04 * a, sy: -.04 * a }); } }
  reset() { this.pu = {}; this.s = {}; this.q = []; this.sh = { x: 0, vx: 0, y: 0, vy: 0, n: 0 }; }
}
