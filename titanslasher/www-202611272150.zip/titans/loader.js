// Data-driven titans (11-26). Each titan = a folder titans/<id>/ with titan.json (name, colours, motion, moves, hooks, framing,
// arena...), rig.json, weights.json, baked anims, part_N.webp + part_N_glow.webp. titans/index.json lists the LIVE daily order
// ("rotation") plus titans that are built but not live ("built", reachable with ?titan=<id>) and seasonal "events".
// Only the current titan's assets are loaded; the next one is preloaded in the background (CLAUDE.md "load only what you need").
import { LB } from '../leaderboard.js';

const Q = new URLSearchParams(location.search);
const bust = () => '?' + (Q.get('nocache') === '0' ? '' : Date.now());
const getJson = (u) => fetch(u + bust()).then((r) => { if (!r.ok) throw new Error(u + ' ' + r.status); return r.json(); });

// ---- index: ids (the rotation in schedule order first: position = the titan id the server knows), display names, the live count n
const idx = await getJson('titans/index.json');
// ink (the default look): every rotation position holds the titan's ink variant (index.json "ink" map). ?style=default: the base
// folder; a titan with none ("ink_only": strider) shows golem on its day.
const INK = Q.get('style') === 'ink';
const inkMap = { ...(idx.ink || {}) }; delete inkMap.doc;
const variant = (id) => (INK ? inkMap[id] || 'golem_ink' : (idx.ink_only || []).includes(id) ? 'golem' : id);
const rot = idx.rotation.map(variant);
const ids = [...rot, ...(idx.built || []).filter((i) => !idx.rotation.includes(i))];
// ?titan=<id> forces a titan (testing). Ink: ?titan=hydra or hydra_ink -> hydra_ink, an unknown id -> golem_ink
const FORCED = (() => { const w = Q.get('titan'); if (!w) return null; if (INK) return Object.values(inkMap).includes(w) ? w : inkMap[w] || 'golem_ink'; return ids.includes(w) ? w : null; })();
if (FORCED && !ids.includes(FORCED)) ids.push(FORCED);
const cfgs = Object.fromEntries(await Promise.all([...new Set(ids)].map((id) => getJson(`titans/${id}/titan.json`).then((c) => [id, c]).catch(() => [id, { id, name: id.toUpperCase() }]))));
export const TIX = { ids, n: rot.length, names: ids.map((id) => cfgs[id].name || id.toUpperCase()), cfg: (i) => cfgs[ids[i]], cfgs };
// schedule + seasonal events -> LB (same rules as SQL lb_titan_of_day / lb_events): enabled events only, titan by rotation position
LB.day0 = +idx.rotation_start || 0;
LB.events = (idx.events || []).filter((e) => e.enabled && idx.rotation.includes(e.titan)).map((e) => ({ idx: idx.rotation.indexOf(e.titan), from: e.from, to: e.to }));
LB.names = TIX.names.slice(0, TIX.n);
// today's titan, or ?titan=<id> (testing; a titan that is not today's titan is unranked: LB.startFight returns no window)
export function titanIdxNow() { return FORCED ? ids.indexOf(FORCED) : LB.titanNow(TIX.n); }

// ---- per-titan data (json + textures), cached promises so preload and load share the work
const cache = new Map();
export function loadTitanData(id, loadTex, opt = {}) {
  if (cache.has(id)) return cache.get(id);
  const base = `titans/${id}/`, cfg = cfgs[id];
  const p = (async () => {
    // 11-26 load speed: rig + anims + weights in parallel, then colour maps + glow masks in parallel (was 4 round trips in a row)
    const animFile = cfg.anim?.files ? (cfg.anim.files[opt.src] || cfg.anim.files.mix || Object.values(cfg.anim.files)[0]) : 'anims.json';
    const [rig, anim, weights] = await Promise.all([getJson(base + 'rig.json'), getJson(base + animFile).catch(() => null), getJson(base + 'weights.json').catch(() => null)]);
    const names = [...new Set(rig.parts.map((q) => q.img))];
    // cfg.glows = the parts that have a glow mask (written into the app copy by titantap-app/build_www.py, so a store build
    // never asks for a missing file); absent (dev server) = probe every part
    const [tex, glow] = await Promise.all([Promise.all(names.map((n) => loadTex(`${base}${n}.webp`, { flipY: false }))),
      opt.noglow ? [] : Promise.all(names.map((n) => (cfg.glows && !cfg.glows.includes(n) ? null : loadTex(`${base}${n}_glow.webp`, { flipY: false, quiet: true }).catch(() => null))))]);
    return { id, cfg, rig, anim, weights, tex: Object.fromEntries(names.map((n, i) => [n, tex[i]])), glow: Object.fromEntries(names.map((n, i) => [n, glow[i]]).filter((e) => e[1])) };
  })();
  cache.set(id, p); p.catch(() => cache.delete(id));
  return p;
}
// the titan after today's (tomorrow's) in the background, so a day change or ?titan swap is instant
export function preloadNext(i, loadTex, opt) { const j = (i + 1) % Math.max(1, TIX.n); if (j !== i && ids[j]) setTimeout(() => loadTitanData(ids[j], loadTex, opt).catch(() => {}), 4000); }
