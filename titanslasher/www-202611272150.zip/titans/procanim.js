// Generic animator for the non-humanoid archetypes (11-26): beast (Cerberus, Chimera), serpent (Hydra, Kraken), core (Watcher).
// Same interface as titan.js TitanAnim (update(dt, st), flinch(area, dir, s, hit), reset(), ch, fl, phone, ikDbg), so main.js
// drives every titan the same way.
// Layers:
//  1. BAKED tracks (titans/<id>/anims.json from tools/titan_anim.py: keyed body channels, leg IK, neck curls, FABRIK neck aims)
//     sampled as spring TARGETS: idle loop (drift scaled by MOTION.amp around its first frame), dormant blend, the act blended in
//     over it (x MOTION.act). L-authored moves mirror for the other side (L <-> R bone names, .r / .x negated).
//  2. PROCEDURAL (titan.json "proc"): breath, sways (per-bone sines, phase-offset so heads move out of sync), neck WAVES down a
//     chain (each joint lags), jaw SNAPS on random per-jaw timers, flicker (mane / flames), spins (gears), pendulums (chains)
//     driven by the body's acceleration, orbits (plates), look-at (eye follows the last tap).
//  3. per-bone damped SPRINGS (stiffness / damping by mass, titan.json "springs"), then the dummy-style spring REACTIONS
//     (react.js) and the per-area sharp flinch envelope (titan.json "areas"), post-spring.
import { MOTION, ACTS } from '../titan.js';
import { SpringReact, HEAVY } from './react.js';
// 11-27 HEAVY hit flinch: the per-area flinch maps (titan.json "areas") keep their shape but rotations (x .05) / translations (x .15) are scaled
// way down (titans are unshakeable: no head tilts, no head / jaw sliding off its neck); the body answers with react.shudder().
const HFL = HEAVY ? { r: .05, t: .15 } : { r: 1, t: 1 };

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function samp(arr, f, loop) { const n = arr.length; if (n === 1) return arr[0];
  if (loop) { f %= n; if (f < 0) f += n; const i = Math.floor(f), j = (i + 1) % n; return arr[i] + (arr[j] - arr[i]) * (f - i); }
  if (f <= 0) return arr[0]; if (f >= n - 1) return arr[n - 1]; const i = Math.floor(f); return arr[i] + (arr[i + 1] - arr[i]) * (f - i); }
const swapLR = (b) => b.replace(/([LR])(\d*)$/, (m, s, d) => (s === 'L' ? 'R' : 'L') + d); // headL2 <-> headR2, nL20 <-> nR20, shL <-> shR
const flinchEnv = (a) => a < .05 ? 1 - Math.pow(1 - a / .05, 3) : a < .34 ? 1 + (-.16 - 1) * ((a - .05) / .29) ** .8 : a < .75 ? -.16 * (1 - (a - .34) / .41) : 0;
// 11-27 HEAVY IDLE (user: titans must read as massive: slow heavy breathing, weight shifts from the body, the head follows the body
// and never wobbles on its own, secondary motion only on loose parts, no parts rotating around their joints, nothing detaching).
// Applied to the titan.json "proc" block at load (shared by every proc titan, ?heavy=0 = old):
//  - head / jaw / neck sways: rotation x .2 and 40% slower; their x / y translations dropped (a head sliding up / down on its
//    neck read as "not attached"); torso / coil / tail / loose sways keep their shape
//  - neck waves x .22 and 40% slower (kraken "heavy.tips": the last N tentacle links keep .6 = loose tips curl a little)
//  - jaw snaps: x .25 opening (y slides x .15), 2x rarer and slower; eyelid blinks unchanged
//  - baked idle drift on head / neck / jaw channels x .3; breath slowed to >= 4.6 s with a little more lift (shoulders ride it)
const HEADISH = /^(head|jaw|neck|mask|n[LRC]?\d|n\d)/;
function heavyProc(pr0, cfg) {
  if (!HEAVY) return pr0; const pr = JSON.parse(JSON.stringify(pr0 || {})), tips = cfg.heavy?.tips || 0;
  if (pr.breath) { const B = pr.breath; B.period = Math.max(4.6, (B.period || 4.8) * 1.1); if (B.y) B.y *= 1.3; }
  pr.sway = (pr.sway || []).filter((s) => !(HEADISH.test(s.bone) && (s.prop === 'x' || s.prop === 'y')))
    .map((s) => HEADISH.test(s.bone) ? { ...s, amp: s.amp * .2, freq: s.freq * .6 }
      : (s.prop === 'x' || s.prop === 'y') && !/^(chest|hips|rock|chain|plate|fringe)/.test(s.bone) ? { ...s, amp: s.amp * .5 } : s); // coils: half the slide
  pr.waves = (pr.waves || []).map((W) => ({ ...W, freq: W.freq * .6, amp: W.amp * .22, tipK: tips ? .6 / .22 : 0, tips }));
  pr.snaps = (pr.snaps || []).map((S) => /^jaw/.test(S.bone) ? { ...S, open: S.open * (S.prop === 'y' ? .15 : .25), dur: (S.dur || .4) * 1.6,
    every: [(S.every?.[0] || 2) * 2, (S.every?.[1] || 5) * 2] } : S);
  return pr;
}
const hash = (i) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

export class ProcAnim {
  constructor(puppet, baked, cfg = {}) {
    this.P = puppet; this.bk = baked; this.cfg = cfg; this.ch = {}; this.fl = {}; this.sec = {}; this.phone = false; this.ikDbg = {}; this.front = {};
    this.proc = heavyProc(cfg.proc, cfg); this.areas = cfg.areas || {}; this.stiff = cfg.springs || {};
    this.react = new SpringReact(puppet, cfg.react || {});
    this.look = { x: 0, y: 0 }; this.snapT = {};
    // act timing from the bake -> ACTS (main.js times FX and act lengths from it)
    for (const a in baked.moves) { const M = baked.moves[a]; ACTS[a] = { ...(ACTS[a] || {}), dur: M.dur, ...(M.hit ? { hit: M.hit } : {}), ...(M.hold ? { hold: true } : {}) }; }
    if (baked.moves.slamL) ACTS.slamR = { ...ACTS.slamL };
  }
  reset() { this.sec = {}; this.fl = {}; this.snapT = {}; this.react.reset(); }
  chan(bone, prop) { const k = bone + '.' + prop; return this.ch[k] || (this.ch[k] = { x: 0, v: 0, bone, prop }); }
  kick(bone, prop, v) { this.chan(bone, prop).v += v; }
  lookAt(x, y) { this.look.x = x; this.look.y = y; } // rig px of the last tap (core archetype: the eye follows it)
  flinch(area, dir, s = 1, hit = null) {
    if (hit) this.react.hit(hit.bone, hit.x, hit.y, Math.min(1.5, s)); else this.react.shudder(Math.min(1.5, s), -(dir || 0));
    s *= MOTION.flinch; if (!area) area = 'chest';
    const f = this.fl[area] || (this.fl[area] = { k: 0, d: 1, age: 9, amp: 0 });
    f.k = Math.min(1, f.k + .45 * Math.min(1.5, s)); f.d = dir || f.d;
    if (f.age > .25) { f.age = 0; f.amp = Math.min(1.2, s); } else f.amp = Math.min(1.2, Math.max(f.amp, s));
  }
  // one move's channels at time u into T (weight w, mirrored?)
  addMove(T, name, u, w, mir) {
    const M = this.bk.moves[name]; if (!M || w <= 0) return;
    const f = u * this.bk.fps;
    for (const k in M.ch) { const i = k.indexOf('.'), b = k.slice(0, i), p = k.slice(i + 1), bb = mir ? swapLR(b) : b;
      let v = samp(M.ch[k], f, M.loop); if (mir && (p === 'r' || p === 'x')) v = -v;
      const key = bb + '.' + p; T[key] = (T[key] || 0) + v * w; }
  }
  update(dt, st) {
    const P = this.P, t = st.t, dorm = st.dormant || 0, am = MOTION.amp, rage = st.rage || 0, pr = this.proc;
    const T = {}; const set = (b, p, v) => { if (!P.byName[b]) return; const k = b + '.' + p; T[k] = (T[k] || 0) + v; };
    // ---- 1. baked: idle (scaled around frame 0) -> dormant -> act
    const I = this.bk.moves.idle;
    if (I) { const f = (t % I.dur) * this.bk.fps; for (const k in I.ch) { const a = I.ch[k], v0 = a[0], v = samp(a, f, true), hk = HEAVY && HEADISH.test(k) ? .3 : 1; T[k] = (T[k] || 0) + v0 + (v - v0) * am * hk; } }
    if (dorm > 0 && this.bk.moves.dormant) { const D = this.bk.moves.dormant; for (const k in D.ch) { const v = D.ch[k][0]; T[k] = (T[k] || 0) * (1 - dorm) + v * dorm; } for (const k in T) if (!(k in D.ch)) T[k] *= (1 - dorm * .5); }
    const a = st.act, u = st.u || 0, side = st.side || 1;
    let mv = a, mir = false; if (a === 'slamR') { mv = 'slamL'; mir = true; } else if (a === 'swipe' && side < 0) mir = true;
    const M = mv && this.bk.moves[mv];
    if (M) { const w = (M.hold ? clamp(u / .12, 0, 1) : clamp(Math.min(u / .12, (M.dur - u) / .15), 0, 1)) * MOTION.act;
      const A = {}; this.addMove(A, mv, u, 1, mir); for (const k in A) T[k] = (T[k] || 0) * (1 - w) + A[k] * w; }
    // ---- 2. procedural (all scaled by the subtle amplitude; rage speeds / deepens a little)
    const live = (1 - dorm * .7) * am, sp = 1 + .5 * rage;
    if (pr.breath) { const B = pr.breath, br = Math.sin(t * 6.283 / (B.period || 4.8) * sp); for (const p of ['y', 'sy', 'sx']) if (B[p]) set(B.bone || 'chest', p, B[p] * br * live * (1 + .5 * rage)); }
    for (const s of pr.sway || []) set(s.bone, s.prop || 'r', s.amp * Math.sin(t * 6.283 * s.freq * sp + (s.phase || 0)) * live * (1 + (s.rage || 0) * rage));
    // 11-27 static BENDS (hydra_ink v2): a constant rotation per chain bone, so a straight painted neck rests as an S-curve
    for (const B of pr.bend || []) B.bones.forEach((b, i) => set(b, 'r', (B.r[i] || 0) * (1 - dorm * .4)));
    for (const W of pr.waves || []) W.bones.forEach((b, i) => set(b, 'r', W.amp * Math.sin(t * 6.283 * W.freq * sp + (W.phase || 0) - i * (W.lag || .6)) * live * (1 + i * (W.grow || 0)) * (W.tips && i >= W.bones.length - W.tips ? W.tipK : 1)));
    for (const s of pr.snaps || []) { // a jaw snaps open-shut on its own random timer (heads out of sync), more often in rage
      const S = this.snapT[s.bone] || (this.snapT[s.bone] = { next: t + 1 + hash(s.bone.length + (s.seed || 0)) * (s.every?.[1] || 4), t0: -9, n: 0 });
      if (t >= S.next) { S.t0 = t; S.n++; S.next = t + (s.every?.[0] || 2) + hash(S.n * 7.3 + (s.seed || 0)) * ((s.every?.[1] || 5) - (s.every?.[0] || 2)) / sp; }
      const e = t - S.t0, d = s.dur || .4, k = e < 0 || e > d ? 0 : e < d * .25 ? e / (d * .25) : 1 - (e - d * .25) / (d * .75);
      set(s.bone, s.prop || 'y', s.open * k * (1 - dorm)); }
    for (const F of pr.flicker || []) { const n = Math.sin(t * F.freq) * .6 + Math.sin(t * F.freq * 1.73 + 1.1) * .4; if (F.sx) set(F.bone, 'sx', F.sx * n); if (F.sy) set(F.bone, 'sy', F.sy * Math.abs(n)); if (F.r) set(F.bone, 'r', F.r * n); }
    for (const S of pr.spin || []) set(S.bone, 'r', ((t * S.speed * sp) % 6.2832) * (S.dir || 1));
    for (const O of pr.orbit || []) { const ph = t * O.speed * (1 + (O.rageSpin || 0) * rage) + (O.phase || 0), rr = O.r * (1 + .06 * Math.sin(t * .7 + (O.phase || 0))) * (1 + (st.open || 0) * (O.open || 0));
      set(O.bone, 'x', Math.cos(ph) * rr * (O.sx || 1) - (O.cx || 0)); set(O.bone, 'y', Math.sin(ph) * rr * (O.sy || 1) - (O.cy || 0)); if (O.tilt) set(O.bone, 'r', Math.sin(ph) * O.tilt); }
    if (pr.look && P.byName[pr.look.bone]) { const L = pr.look; set(L.bone, 'x', clamp(this.look.x / (L.range || 600), -1, 1) * L.x); set(L.bone, 'y', clamp(this.look.y / (L.range || 600), -1, 1) * L.y); }
    // ---- 3a. hit flinch layer (spring part, held tension of repeated blows)
    const PO = {}; const post = (b, p, v) => { if (!P.byName[b]) return; const k = b + '.' + p; PO[k] = (PO[k] || 0) + v; };
    for (const area in this.fl) { const f = this.fl[area]; f.k *= Math.exp(-3.2 * dt); f.age += dt;
      if (f.k < .002 && f.age > .8) { delete this.fl[area]; continue; }
      const map = this.areas[area] || this.areas.chest || [], e = f.age < .8 ? flinchEnv(f.age) * f.amp : 0;
      for (const [b, p, v0, dirSign] of map) { const sg = dirSign ? f.d : 1, v = v0 * (p === 'r' ? HFL.r : HFL.t); post(b, p, v * sg * e); set(b, p, v * sg * f.k * .6); } }
    // ---- springs: targets -> pose
    P.clear();
    for (const k in T) if (!this.ch[k]) { const i = k.indexOf('.'); this.chan(k.slice(0, i), k.slice(i + 1)); }
    const n = Math.min(4, Math.max(1, Math.ceil(dt * 60 - .01))), h = dt / n, ST = this.stiff, D = ST._default || [110, 15];
    for (const k in this.ch) { const c = this.ch[k], tg = T[k] || 0; const [ks, kd] = ST[c.bone] || (c.bone.match(/^(n[LRC]?\d|n\d)/) ? ST._neck : null) || D;
      if (dt > 0) for (let i = 0; i < n; i++) { c.v += (ks * (tg - c.x) - kd * c.v) * h; c.x += c.v * h; }
      P.set(c.bone, { [c.prop]: c.x }); }
    // pendulums (chains, banners): lag the chest's sideways / rotational acceleration
    const cv = (k) => (this.ch[k] ? this.ch[k].v : 0), vel = [cv('hips.x') + cv('chest.r') * 300, cv('hips.y') + cv('chest.y')];
    if (dt > 0) { const pv = this.sec.pv || vel, acc = vel.map((v, i) => clamp((v - pv[i]) / dt, -3000, 3000)); this.sec.pv = vel;
      for (const Q of pr.pendulum || []) { const o = this.sec[Q.bone] || (this.sec[Q.bone] = { x: 0, v: 0 });
        for (let i = 0; i < n; i++) { o.v += (-(Q.k || 14) * o.x - (Q.c || 2.2) * o.v - (Q.g || .0004) * acc[0] + Math.sin(t * (Q.f || .9) + Q.bone.length) * (Q.idle || .02)) * h; o.x += o.v * h; } } }
    for (const Q of pr.pendulum || []) post(Q.bone, 'r', clamp(this.sec[Q.bone]?.x || 0, -.4, .4));
    for (const k in PO) { const i = k.indexOf('.'); P.set(k.slice(0, i), { [k.slice(i + 1)]: PO[k] }); }
    this.react.update(dt, t); this.react.apply();
    // ---- glow: idle pulse lives in the shader; roar / rage flare the eyes, stagger dims, dormant = embers
    if (P.glow) { const gm = P.glow.mul, sleep = 1 - dorm * .75; let rk = 0;
      if (a === 'roar') rk = clamp(Math.min((u - .4) / .3, (ACTS.roar.dur - u) / .5), 0, 1); else if (a === 'stagger') rk = -.5 * clamp(1 - u / 1.6, 0, 1);
      gm[0] = sleep * (1 + .35 * rage + .5 * Math.max(0, rk)); gm[1] = Math.max(.2, sleep * (1 + .6 * rage + 2.6 * rk) + .3 * Math.max(0, rk) * Math.sin(t * 40)); gm[2] = sleep * (1 + .3 * rage + .4 * Math.max(0, rk));
      if (ACTS[a]?.hit && !this._gk && u > ACTS[a].hit) { this._gk = 1; P.glow.kick('r', 1.6, 4); P.glow.kick('g', 1, 5); } if (u < .05) this._gk = 0;
      for (const F of pr.glowFlicker || []) P.glow.kick(F.ch || 'r', Math.max(0, Math.sin(t * F.freq) * Math.sin(t * F.freq * 1.37)) * F.amt * dt * 10, 8); }
    P.front = this.front;
    P.update();
  }
}

// post-spring extras for the humanoid TitanAnim (titan.json "proc"): spin (gears), tick (clock hands: stepped rotation with a little
// overshoot), slide (pistons follow an elbow angle), flicker, sway. Returns fn(P, t, dt, st, anim) for TitanAnim.procFn.
export function humanoidProc(pr = {}) {
  return (P, t, dt, st, A) => {
    const has = (b) => !!P.byName[b], rage = st.rage || 0;
    for (const S of pr.spin || []) if (has(S.bone)) P.set(S.bone, { r: ((t * S.speed * (1 + rage)) % 6.2832) * (S.dir || 1) });
    for (const K of pr.tick || []) if (has(K.bone)) { const n = Math.floor(t / K.every), f = t / K.every - n, o = f < .15 ? Math.sin(f / .15 * Math.PI) * .25 * (1 - f / .15) : 0;
      P.set(K.bone, { r: (n + Math.min(1, f / .06) + o * .4) * K.step + (K.phase || 0) }); }
    for (const L of pr.slide || []) if (has(L.bone)) { const e = A.ch[L.from + '.r']; const v = e ? Math.abs(e.x) : 0; P.set(L.bone, { y: L.amt * Math.min(1, v / (L.range || 1.6)) }); }
    for (const F of pr.flicker || []) if (has(F.bone)) { const n = Math.sin(t * F.freq) * .6 + Math.sin(t * F.freq * 1.73 + 1.1) * .4; P.set(F.bone, { sx: (F.sx || 0) * n, sy: (F.sy || 0) * Math.abs(n) }); }
    for (const W of pr.sway || []) if (has(W.bone)) P.set(W.bone, { [W.prop || 'r']: W.amp * Math.sin(t * 6.283 * W.freq + (W.phase || 0)) });
    if (pr.vents && P.glow && st.act && (A._ventAct !== st.act)) { A._ventAct = st.act; P.glow.kick('r', 1.4, 3); } // steam vents / lamps flare on effort
    if (!st.act) A._ventAct = null;
  };
}
