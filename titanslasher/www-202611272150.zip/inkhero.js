// 11-26 INK HERO BLEND (?style=ink only; user: the v5 bug-knight "looks pasted on", he doesn't sit in the scene).
// Loaded by equipment.js only when INK; the default style never imports this file.
// - grade(mat): patches a hero / weapon spriteMat (fx.js FS) in place: teal ambient tint, less saturation (the scarf keeps most
//   of its crimson), slightly crushed blacks, a little of the arena fog colour, a cool rim on the edges facing the light beams
//   (one extra alpha tap toward the light), a small brightness kick on the bone-white mask so it crosses the bloom threshold
//   like the titan's mask, and an idle-only scarf flutter (one extra tap, red pixels only, anchored at the neck).
//   Outline: the violet glow outline becomes an ink line in the world's line colour.
// - contact shadow: one soft dark ellipse at the hero's feet on the ledge; it shrinks + fades with his height and fades out
//   when he blinks away from his spot. One mesh, no per-frame allocation.
import * as THREE from 'three';
import { SH } from './fx.js';

const Q = new URLSearchParams(location.search);
const OFF = Q.get('inkblend') === '0'; // A/B: ?inkblend=0 = the v5 look (no grade / rim / shadow)
// shared look values (one object: every patched material references these uniforms)
const U = {
  inkTint: { value: new THREE.Color(.8, .95, 1.02) }, // teal-blue ambient (scene: titan [66 93 96], hero raw [95 84 83])
  inkSat: { value: .72 }, inkBlk: { value: .045 }, inkAir: { value: .1 }, inkMask: { value: .2 },
  rimC: { value: new THREE.Color(.42, .78, .95) }, inkRim: { value: .55 }, inkTm: SH.time,
};
const INK_LINE = new THREE.Color(.01, .03, .04); // world ink line (frame / ledge / titan outlines are near-black teal)

const DECL = 'uniform vec3 inkTint; uniform float inkSat; uniform float inkBlk; uniform float inkAir; uniform float inkMask; uniform vec3 rimC; uniform float inkRim; uniform float inkTm; uniform vec2 rimD; uniform float inkSw;\n';
// idle scarf flutter: red pixels of this tap or a neighbour shifted by a slow two-sine wave; amplitude grows away from the neck
const SWAY = `void main(){ vec4 c = texture2D(map, vUv);
  if (inkSw > 0.) { float far = smoothstep(.06, .4, distance(vUv, vec2(.55, .6)));
    vec2 o = vec2(sin(inkTm * 2.1 + vUv.x * 9.) * .004, sin(inkTm * 2.7 + vUv.x * 13.) * .011) * far * inkSw;
    vec4 c1 = texture2D(map, vUv + o);
    float m0 = smoothstep(.1, .22, c.r - max(c.g, c.b)) * c.a, m1 = smoothstep(.1, .22, c1.r - max(c1.g, c1.b)) * c1.a;
    c = mix(c, c1, max(m0, m1) * far); }`;
const GRADE = `{ float lu = dot(col, vec3(.3, .59, .11)), mx = max(col.r, max(col.g, col.b)), sa = mx - min(col.r, min(col.g, col.b));
    float red = smoothstep(.12, .3, col.r - max(col.g, col.b));
    col = mix(vec3(lu), col, mix(inkSat, .82, red)) * mix(inkTint, vec3(.92, .9, .95), red * .6);
    col = max(col - inkBlk, 0.) / (1. - inkBlk);
    col = mix(col, fogColor * (.5 + lu), inkAir * (1. - lu));
    col *= 1. + inkMask * smoothstep(.5, .72, lu) * (1. - smoothstep(.06, .2, sa));
    float ra = texture2D(map, vUv + rimD * olW * 1.6).a; col += rimC * (c.a * (1. - ra) * inkRim); }
  col += flash;`;

export function grade(mat, sway = true) {
  if (OFF || !mat?.fragmentShader || mat.userData.ink) return;
  const fs = mat.fragmentShader;
  if (!fs.includes('void main(){ vec4 c = texture2D(map, vUv);') || !fs.includes('col += flash;')) return; // not the fx.js sprite shader
  Object.assign(mat.uniforms, U, { rimD: { value: new THREE.Vector2(-.7, .7) }, inkSw: { value: 0 } });
  mat.fragmentShader = DECL + fs.replace('void main(){ vec4 c = texture2D(map, vUv);', sway ? SWAY : 'void main(){ vec4 c = texture2D(map, vUv);')
    .replace('col += flash;', GRADE);
  if (mat.uniforms.olC) { mat.uniforms.olC.value.copy(INK_LINE); mat.uniforms.olA.value = mat.uniforms.olA.value > 0 ? 1 : 0; }
  if (mat.uniforms.glow) mat.uniforms.glow.value = Math.min(mat.uniforms.glow.value, .15); // the cyan key lit the teal tunic like a rune
  mat.userData.ink = 1; mat.needsUpdate = true;
}
// per sprite, every frame (no allocation): light from the upper left of the screen, mirrored sprites mirror it; scarf flutter idle only
export function perSprite(mat, sx, idle) {
  const u = mat.uniforms; if (!u.rimD) return;
  u.rimD.value.set(-.7 * sx, .72); u.inkSw.value = idle ? 1 : 0;
  if (u.glowMap) { u.glowMap.value = EYES.map.get(u.map.value) || EYES.black; u.glowK.value.setScalar(EYES.k * (1 + EYES.fl)); }
}

// ---------------- glowing eyes (11-27, user: "can we try make jxed's eyes glow") ----------------
// Masks: art/hero_ink/<pose>_glow.webp (tools/hero_eye_glow.py: the two dark eye holes ringed by the bone mask; half res,
// grayscale; idle_anim_glow.webp = same 3x2 atlas layout, sliced like heroanim.js). One extra texture tap in the existing hero
// shader (glowmask.js addGlow, mono) + the hero meshes join GLOW_LAYER so the selective bloom catches the eyes; no extra draw.
// The mask follows the sprite's current map (Map tex -> mask, swapped in perSprite). ?noeyes=1 = off, ?eyecol=9ff5ff = colour.
const EYES = { on: !OFF && Q.get('noeyes') !== '1', map: new Map(), black: null, fl: 0, k: 1.15,
  col: new THREE.Color('#' + (/^[0-9a-f]{6}$/i.test(Q.get('eyecol') || '') ? Q.get('eyecol') : 'a6fbff')) }; // pale cyan-white, a touch teal
export const eyes = EYES; // dev: __g-style tweaks (eyes.col.set(..), eyes.k)
let glowJs = null;
// poseOf: Map(texture -> pose name) from equipment.js; rig = hero_rig.json (ink files); loadTex = main.js loader
export async function initEyes(poseOf, rig, loadTex) {
  if (!EYES.on || !rig) return;
  glowJs = await import('./glowmask.js').catch(() => null); if (!glowJs) return;
  EYES.black = new THREE.DataTexture(new Uint8Array([0, 0, 0, 255]), 1, 1); EYES.black.needsUpdate = true;
  const gf = (f) => f.replace(/\.webp$/, '_glow.webp'), opt = (f) => loadTex(f, { quiet: true }).catch(() => null);
  const names = [...new Set(poseOf.values())].filter((n) => !n.startsWith('idle_'));
  const A = rig.idle_anim;
  const [masks, atlas] = await Promise.all([Promise.all(names.map((n) => rig.poses?.[n]?.file ? opt(gf(rig.poses[n].file)) : null)), A?.file ? opt(gf(A.file)) : null]);
  const byName = {}; names.forEach((n, i) => { if (masks[i]) byName[n] = masks[i]; });
  if (atlas) { const img = atlas.image, fw = Math.round(img.width / A.cols), fh = Math.round(img.height / A.rows); // slice like heroanim.js
    for (let i = 0; i < A.n; i++) { const c = document.createElement('canvas'); c.width = fw; c.height = fh;
      c.getContext('2d').drawImage(img, (i % A.cols) * fw, Math.floor(i / A.cols) * fh, fw, fh, 0, 0, fw, fh);
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.NoColorSpace; t.needsUpdate = true; byName['idle_' + i] = t; }
    atlas.dispose(); }
  for (const [tex, n] of poseOf) if (byName[n]) EYES.map.set(tex, byName[n]);
}
// one hero sprite material (after grade): mono emissive, gentle pulse; the mesh joins the selective-bloom layer
export function eyeMat(mesh) {
  if (!EYES.on || !glowJs || !EYES.black || mesh.material.userData.glow) return;
  glowJs.addGlow(mesh.material, EYES.black, { mono: true, col: EYES.col, k: EYES.k, rate: 1.4, depth: .2, src: 0, bloom: 1.5, src_var: 'c.rgb' });
  mesh.material.userData.glow.glowC0.value = EYES.col; // shared Color: a live colour tweak hits every hero sprite
  mesh.layers.enable(glowJs.GLOW_LAYER);
}
export const eyeFlare = (amt = 1) => { EYES.fl = Math.max(EYES.fl, amt); }; // strike pose / crit
export function tickEyes(dt) { EYES.fl *= Math.exp(-dt * 3.2); }

// ---------------- contact shadow ----------------
const SHD = { m: null, home: new THREE.Vector3(0, 0, 6.5), a: 0, base: null };
export function initShadow(scene, ro) {
  if (OFF) return;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({
    transparent: true, depthTest: false, depthWrite: false, uniforms: { a: { value: 0 }, col: { value: new THREE.Color(.0, .015, .02) } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
    fragmentShader: `uniform float a; uniform vec3 col; varying vec2 vUv; void main(){ vec2 p = (vUv - .5) * 2.; float d = dot(p, p);
      float s = smoothstep(1., .15, d) * .55 + smoothstep(.3, 0., d) * .45; gl_FragColor = vec4(col, s * a); }` }));
  m.renderOrder = ro - .05; m.frustumCulled = false; m.visible = false; scene.add(m); SHD.m = m;
}
// hero = the main hero sprite (bottom-anchored); grounded = it shows an idle / land frame this frame (feet on the ledge).
// Strike / dive poses fade it out fast; while it fades it also shrinks (reads as the hero leaving the ground).
export function updateShadow(hero, grounded, dt) {
  const m = SHD.m; if (!m) return;
  const h = Math.abs(hero.scale.y) || 1, on = grounded && hero.visible;
  if (on) { const jump = Math.hypot(hero.position.x - SHD.home.x, hero.position.z - SHD.home.z) > h * .5; SHD.home.copy(hero.position); SHD.base = SHD.base == null || jump ? hero.position.y : Math.min(SHD.base + dt * .5, hero.position.y); } // base: lowest recent foot y (the idle bob lifts him a little)
  const lift = on ? Math.max(0, hero.position.y - (SHD.base ?? hero.position.y)) / h : 1;
  const want = on ? Math.max(0, 1 - lift * 2.5) : 0;
  SHD.a += (want - SHD.a) * Math.min(1, dt * (want > SHD.a ? 8 : 20));
  m.visible = SHD.a > .01; if (!m.visible) return;
  const w = h * .95 * (.55 + .45 * SHD.a) * (1 - Math.min(.4, lift * 3));
  m.position.set(SHD.home.x, (SHD.base ?? SHD.home.y) + h * .005, SHD.home.z);
  m.quaternion.copy(hero.quaternion); m.scale.set(w, w * .2, 1);
  m.material.uniforms.a.value = .85 * SHD.a;
}
