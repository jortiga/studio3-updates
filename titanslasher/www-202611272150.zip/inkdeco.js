// 11-26 INK ENVIRONMENT (?style=ink, arenas/inkcave; user: "can u include environment too", target share/concept_inkstyle/concept_c_slash.png).
// Loaded by arena.js ONLY when an arena.json theme has "deco" (dynamic import), so the default look never loads this file or its art.
//   ruinsback / ruinsmid: portrait painted layers of ruined gothic arches + pillars, world planes behind the titan (parallax with the
//     camera ease / shake), sized per frame to cover the view above the waterline; the sea hides their base; back = lighter + foggier,
//     mid = darker + sharper. Each gets a faint mirrored reflection on the black water (no depth test, under the titan's reflection).
//   beams: 2 additive sheets of diagonal light shafts (behind the titan + a faint one over him), slow pulse.
//   frame: clip-space black foreground (framerock = stalactites / side rock / corner boulders, frameplants = hanging roots, vines,
//     thorny stems, drooping bell flowers). Each image half is anchored to its screen edge by screen height, so the side silhouettes
//     rise along the edges on any phone (not hidden behind the ledge). The plants sway in the shader (anchored at the top / bottom
//     edge, two-sine spring-like wobble). One draw call for the whole frame.
// Everything animates from SH.time in the shaders: no per-frame JS work except plane sizing in onBeforeRender.
import * as THREE from 'three';
import { SH } from './fx.js';

const SEA_Y = -.8;
const R_MIRROR = new THREE.Matrix4().makeTranslation(0, SEA_Y, 0).multiply(new THREE.Matrix4().makeScale(1, -1, 1)).multiply(new THREE.Matrix4().makeTranslation(0, -SEA_Y, 0));
const VS = 'varying vec2 vUv; varying vec3 vW; varying float vS; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; vS = gl_Position.y / gl_Position.w * .5 + .5; }'; // vS: screen row (descent copies)
let D = null; // { meshes, hidden, ctx }
// 11-27 DESCENT cutscene (main.js descent block): shared uniform, x = frame scroll, y = mid ruins scroll, z = back ruins scroll (in
// art heights, + = content further down), w = alpha of the descent copies; .dark = extra fog / dimming; .meshes = the descent copies
// (main.js toggles their visibility). Rows scrolled past the art are folded into a mirrored band of it, so the layers stream forever.
const DSC = SH.dsc || (SH.dsc = { value: new THREE.Vector4(), dark: { value: 0 }, meshes: [] });
// ruins: rows below the art continue downward from band.y, rows above it upward from band.x (upright repeats, no mirrored arches);
// sd = distance to the nearest repeat seam (art units) for a soft fog stripe there
const WRAPB = `float wrapB(float y, vec2 b, out float sd){ float P = b.y - b.x; sd = min(y, 1. - y);
  if (y < 0.) { float m = mod(-y, P); sd = min(m, P - m); return b.y - m; }
  if (y > 1.) { float m = mod(y - 1., P); sd = min(m, P - m); return b.x + m; }
  return y; }`;
const FOLD = `float fold(float y, vec2 b){ if (y >= 0. && y <= 1.) return y; float w = b.y - b.x; float m = mod(y - b.x, 2. * w); return b.x + (m < w ? m : 2. * w - m); }`;

// world point where the camera ray through NDC (nx, ny) meets the plane z = Z
const _a = new THREE.Vector3(), _b = new THREE.Vector3();
function at(cam, nx, ny, Z) { _a.set(nx, ny, -1).unproject(cam); _b.set(nx, ny, 1).unproject(cam); const k = (Z - _a.z) / (_b.z - _a.z); return [_a.x + (_b.x - _a.x) * k, _a.y + (_b.y - _a.y) * k]; }

function ruinLayer(t, L) {
  t.wrapS = THREE.MirroredRepeatWrapping; t.needsUpdate = true;
  const u = { map: { value: t }, tint: { value: new THREE.Color(...L.tint) }, fogColor: SH.fogColor, fogK: { value: L.fog }, rep: { value: 1 }, a: { value: L.a ?? 1 },
    top: { value: new THREE.Color(...(L.top || L.tint)) }, t: SH.time, refl: { value: 0 }, rk: { value: 0 }, wob: { value: L.wob ?? 0 },
    dsc: DSC, dark: DSC.dark, dl: { value: L.dl ?? 1 }, band: { value: new THREE.Vector2(...(L.band || [.1, .6])) }, ext: { value: 0 }, dcp: { value: 0 } };
  const FS = `uniform sampler2D map; uniform vec3 tint; uniform vec3 top; uniform vec3 fogColor; uniform float fogK; uniform float rep; uniform float a; uniform float t;
    uniform float refl; uniform float rk; uniform float wob; uniform vec4 dsc; uniform float dark; uniform float dl; uniform vec2 band; uniform float ext; uniform float dcp;
    varying vec2 vUv; varying vec3 vW; varying float vS; ${WRAPB}
    void main(){ vec2 uv = vec2((vUv.x - .5) * rep + .5, vUv.y * (1. + ext) - ext); // ext: descent copy reaching below the waterline
      float off = dl > 1.5 ? dsc.z : dsc.y, seam = 0.;
      if (off != 0. || ext > 0.) { float sd, y = uv.y + off; uv.y = wrapB(y, band, sd); seam = smoothstep(.09, 0., sd) * (y < 0. || y > 1. ? 1. : clamp(abs(off) * 5., 0., 1.)); }
      float dd = ${SEA_Y.toFixed(2)} - vW.y; // depth under the waterline (reflection copy)
      if (refl > .5) { if (dd < 0.) discard; uv.x += (sin(vW.y * 3.1 + t * 1.3) + sin(vW.y * 7.7 - t * 2.1) * .5) * .0035 * (1. + dd * .15); }
      else uv.x += sin(t * .35 + vUv.y * 4.) * wob; // the faint drift of hazy far ruins
      vec4 c = texture2D(map, uv); if (c.a < .03) discard;
      vec3 col = c.rgb * mix(tint, top, smoothstep(.15, .85, uv.y)); col = mix(col, fogColor, fogK); col = mix(col, fogColor * .5, seam * .85); // descent: mist over the repeat seams
      float al = c.a * a;
      if (dcp > .5) { float cy = vS - 1. + dsc.x; if (cy > 0. && cy < .24) discard; al *= dsc.w; // arrival: nothing above the frame's top slab (the ceiling we fell through)
        col = mix(col, fogColor * .45, dark * (dl > 1.5 ? .8 : .5)); } // descent copy: deeper = foggier + darker
      if (refl > .5) { al *= rk * smoothstep(9., 0., dd) * (.75 + .25 * sin(vW.y * 5. + t)); col *= .55; }
      gl_FragColor = vec4(col, al); }`;
  const mk = (refl) => { const uu = { ...u, refl: { value: refl }, rk: { value: L.refl ?? 0 } };
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: uu, vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, depthTest: !refl, side: THREE.DoubleSide }));
    m.frustumCulled = false; return m; };
  const m = mk(0); m.renderOrder = L.ro;
  m.onBeforeRender = (r, s, cam) => { // cover the view above the waterline at this depth (any aspect); mirrored repeat on very wide screens
    const img = t.image; if (!img) return; const asp = img.width / img.height;
    const topY = at(cam, 0, 1, L.z)[1], sw = Math.abs(at(cam, 1, 0, L.z)[0] - at(cam, -1, 0, L.z)[0]), visH = Math.max(4, topY - SEA_Y);
    const h = Math.max(visH * (L.hk ?? 1.06), Math.min(sw * 1.12 / asp, visH * 1.6)), w = h * asp, pw = Math.max(w, sw * 1.12);
    u.rep.value = pw / w; m.scale.set(pw, h, 1); m.position.set(L.x || 0, SEA_Y - h * (L.sink ?? .03) + h * .5, L.z); m.quaternion.copy(cam.quaternion); m.updateMatrixWorld(); };
  const rm = L.refl ? mk(1) : null;
  if (rm) { rm.renderOrder = L.rro; rm.matrixAutoUpdate = false; rm.onBeforeRender = () => { rm.matrixWorld.multiplyMatrices(R_MIRROR, m.matrixWorld); }; rm.material.uniforms.rep = u.rep; }
  // descent copy: the same art + scroll, drawn OVER main.js's fog veil (no depth test, L.dro) and extended down to the bottom of the
  // view (the extra rows fold into the band). At scroll 0 it matches the real layer exactly, so the crossfades are seamless.
  const dc = mk(0), du = dc.material.uniforms; du.dcp = { value: 1 }; du.ext = { value: 0 }; du.rep = { value: 1 };
  dc.material.depthTest = false; dc.renderOrder = L.dro ?? 346; dc.visible = false; dc.name = 'descent';
  dc.onBeforeRender = (r, s, cam) => { const img = t.image; if (!img) return; const asp = img.width / img.height;
    const topY = at(cam, 0, 1, L.z)[1], sw = Math.abs(at(cam, 1, 0, L.z)[0] - at(cam, -1, 0, L.z)[0]), visH = Math.max(4, topY - SEA_Y);
    const h = Math.max(visH * (L.hk ?? 1.06), Math.min(sw * 1.12 / asp, visH * 1.6)), w = h * asp, pw = Math.max(w, sw * 1.12);
    const b0 = SEA_Y - h * (L.sink ?? .03), bot = Math.min(b0, at(cam, 0, -1, L.z)[1] - 1), H2 = h + (b0 - bot);
    du.rep.value = pw / w; du.ext.value = (b0 - bot) / h; dc.scale.set(pw, H2, 1); dc.position.set(L.x || 0, bot + H2 * .5, L.z); dc.quaternion.copy(cam.quaternion); dc.updateMatrixWorld(); };
  DSC.meshes.push(dc);
  return [m, rm, dc].filter(Boolean);
}

function beams(o, ro, z) {
  const u = { t: SH.time, col: { value: new THREE.Color(...(o.col || [.75, .95, 1])) }, k: { value: o.k ?? 1 }, asp: { value: 1 }, ang: { value: o.ang ?? -.42 } };
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: u, transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending,
    vertexShader: VS, fragmentShader: `uniform float t; uniform vec3 col; uniform float k; uniform float asp; uniform float ang; varying vec2 vUv;
      void main(){ vec2 p = vec2((vUv.x - .5) * asp, 1. - vUv.y); // p.y 0 at the top
        float cs = cos(ang), sn = sin(ang); float across = p.x * cs - p.y * sn; float along = p.x * sn + p.y * cs; float r = 0.;
        for (int i = 0; i < 5; i++) { float fi = float(i); float c = -.42 + fi * .19 + sin(t * .06 + fi * 2.1) * .025; float w = .025 + .03 * fract(fi * .61);
          float b = smoothstep(w, 0., abs(across - c)) + smoothstep(w * 3.5, 0., abs(across - c)) * .35; // core + soft halo
          r += b * (.55 + .45 * sin(t * (.28 + fi * .05) + fi * 2.3)) * (.6 + .4 * fract(fi * .37 + .2)); }
        r *= smoothstep(1.35, .05, along) * smoothstep(-.02, .1, p.y) * (.85 + .15 * sin(p.y * 14. - t * .7 + across * 9.)); // fade downward, shimmer of dust in the light
        float a = r * .085 * k; gl_FragColor = vec4(col * a, a); }` }));
  m.renderOrder = ro; m.frustumCulled = false;
  m.onBeforeRender = (r, s, cam) => { const topY = at(cam, 0, 1, z)[1] + 2, sw = Math.abs(at(cam, 1, 0, z)[0] - at(cam, -1, 0, z)[0]) * 1.1, h = topY - SEA_Y;
    m.scale.set(sw, h, 1); m.position.set(0, SEA_Y + h * .5, z); m.quaternion.copy(cam.quaternion); u.asp.value = sw / h; m.updateMatrixWorld(); };
  return m;
}

function frame(rock, plants, o) {
  const u = { rock: { value: rock }, plants: { value: plants || rock }, hasP: { value: plants ? 1 : 0 }, f: { value: 1 }, t: SH.time, tint: { value: new THREE.Color(...(o.tint || [.01, .018, .022])) },
    sway: { value: o.sway ?? .009 }, a: { value: o.a ?? 1 }, dsc: DSC };
  const m = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.ShaderMaterial({ uniforms: u, transparent: true, depthWrite: false, depthTest: false,
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }',
    fragmentShader: `uniform sampler2D rock; uniform sampler2D plants; uniform float hasP; uniform float f; uniform float t; uniform vec3 tint; uniform float sway; uniform float a; uniform vec4 dsc; varying vec2 vUv; ${FOLD}
      // f = image width / screen width at screen height. Left half of the art anchored to the left edge, right half to the right edge;
      // on screens wider than the art the gap is filled with a mirrored run of the art's centre band.
      float pp(float x, float lo, float hi) { float w = hi - lo; float m = mod(x - lo, 2. * w); return lo + (m < w ? m : 2. * w - m); }
      vec4 two(sampler2D tx, vec2 s, vec2 d) { float ul = s.x / f, ur = 1. - (1. - s.x) / f;
        ul = ul > .5 ? pp(ul, .32, .5) : ul; ur = ur < .5 ? pp(ur, .5, .68) : ur;
        vec4 A = texture2D(tx, vec2(ul, s.y) + d), B = texture2D(tx, vec2(ur, s.y) + d); return A.a > B.a ? A : B; }
      void main(){ vec2 s = vUv; if (dsc.x != 0.) s.y = fold(s.y + dsc.x, vec2(.28, .72)); // descent: the side walls stream past
        vec4 c = two(rock, s, vec2(0.));
        if (hasP > .5) { float dt = 1. - s.y, db = s.y; // 11-28 user: ONE wind from the left, subtle: everything leans the same way
          float wT = pow(clamp(dt / .42, 0., 1.), 1.7) * step(.5, s.y), wB = pow(clamp(db / .46, 0., 1.), 1.7) * step(s.y, .5); // grows away from the anchor
          float ph = t * .9 - s.x * 3.2; // the gusts travel across the screen with the wind
          float gust = .55 + .35 * sin(ph) + .10 * sin(ph * 2.3 + 1.1); // 0.1 .. 1: it swells and eases, never blows back
          vec4 p = two(plants, s, vec2(-sway * (wT + wB) * gust / max(f, .5), 0.)); c = c.a > p.a ? c : p; } // sample to the left = lean right
        if (c.a < .02) discard; gl_FragColor = vec4(mix(c.rgb, tint, .9), c.a * a); }` }));
  m.renderOrder = o.ro ?? 395; m.frustumCulled = false; const v = new THREE.Vector2(); // 11-26 user: the black foreground frame is drawn LAST - over the hero (380) and the slashes
  m.onBeforeRender = (r) => { r.getDrawingBufferSize(v); const img = rock.image; if (img) u.f.value = (img.width / img.height) * v.y / Math.max(1, v.x); };
  return m;
}

// drifting white spores inside the portrait view (env.js dust is spread over a 120-unit-wide volume, so few reach a phone screen)
function motes(o) {
  const N = o.n ?? 140, pos = new Float32Array(N * 3), sd = new Float32Array(N * 4), R = Math.random;
  for (let i = 0; i < N; i++) { pos.set([(R() - .5) * 40, R() * 44, -75 + R() * 68], i * 3); sd.set([R(), R(), R(), R()], i * 4); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('seed', new THREE.BufferAttribute(sd, 4));
  const u = { t: SH.time, px: { value: 1 }, col: { value: new THREE.Color(...(o.col || [.9, 1, 1])) }, k: { value: o.k ?? 1 }, sz: { value: o.size ?? 1 } };
  const m = new THREE.Points(g, new THREE.ShaderMaterial({ uniforms: u, transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending,
    vertexShader: `attribute vec4 seed; uniform float t; uniform float px; uniform float sz; varying float vA;
      void main(){ vec3 p = position; p.y = mod(p.y + t * (.25 + seed.x * .5), 44.) - 2.;
        p.x += sin(t * (.2 + seed.y * .3) + seed.z * 30.) * 1.6 + sin(t * .9 + seed.w * 20.) * .25; p.z += cos(t * .15 + seed.y * 9.) * 1.2;
        vec4 mv = modelViewMatrix * vec4(p, 1.); gl_Position = projectionMatrix * mv; float d = -mv.z;
        gl_PointSize = clamp(sz * (1. + seed.z * 1.6) * px * 190. / max(4., d), 1.5, 12.);
        vA = (.45 + .55 * sin(t * (.6 + seed.w) + seed.x * 40.)) * smoothstep(-1., 2., p.y) * smoothstep(42., 34., p.y) * smoothstep(5., 12., d); }`,
    fragmentShader: `uniform vec3 col; uniform float k; varying float vA; void main(){ float d = length(gl_PointCoord - .5) * 2.; if (d > 1.) discard;
      float a = (pow(1. - d, 3.) * .8 + smoothstep(.35, .0, d) * .6) * vA * k; gl_FragColor = vec4(col * a, a); }` }));
  m.renderOrder = o.ro ?? 321; m.frustumCulled = false; const v = new THREE.Vector2();
  m.onBeforeRender = (r) => { r.getDrawingBufferSize(v); u.px.value = v.y / 844; };
  return m;
}

// 11-26 SHORE (user: the water's far edge was "a perfectly straight line, it's weird"). The sea plane meets the ruins in one flat
// horizontal line. A painted strip of rocks / roots / moss / reeds (shore.webp, ragged top AND bottom) is laid over that line as a
// camera-facing world plane just in front of the mid ruins, sized per frame to the view width (mirrored repeat) and to a fraction
// of the view height. No depth test (the opaque sea would cut its ragged bottom back into a straight line); renderOrder after the
// ruin reflections, before the titan / dummy reflections and bodies, so nothing in front is ever covered.
// ?water=abyss passes the chasm rim (rim.webp) instead; its lower shards fade into the fog (o.fadeB).
function shore(t, o) {
  t.wrapS = THREE.MirroredRepeatWrapping; t.needsUpdate = true;
  const u = { map: { value: t }, tint: { value: new THREE.Color(...o.tint) }, top: { value: new THREE.Color(...o.top) }, fogColor: SH.fogColor, fogK: { value: o.fog },
    rep: { value: 1 }, off: { value: 0 }, fadeB: { value: o.fadeB ?? 0 } };
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: u, vertexShader: VS, transparent: true, depthWrite: false, depthTest: false,
    fragmentShader: `uniform sampler2D map; uniform vec3 tint; uniform vec3 top; uniform vec3 fogColor; uniform float fogK; uniform float rep; uniform float off; uniform float fadeB; varying vec2 vUv;
      void main(){ vec4 c = texture2D(map, vec2((vUv.x - .5) * rep + .5 + off, vUv.y)); float al = c.a * (1. - fadeB * smoothstep(.55, .0, vUv.y)); if (al < .03) discard;
        vec3 col = c.rgb * mix(tint, top, smoothstep(.3, .9, vUv.y)); col = mix(col, fogColor, fogK * (1. - .5 * smoothstep(.4, .9, vUv.y)) + fadeB * smoothstep(.6, .1, vUv.y) * .5);
        gl_FragColor = vec4(col, al); }` }));
  m.renderOrder = o.ro; m.frustumCulled = false; u.off.value = o.off ?? .13;
  m.onBeforeRender = (r, s, cam) => {
    const img = t.image; if (!img) return; const asp = img.width / img.height, Z = o.z;
    const sh = at(cam, 0, 1, Z)[1] - at(cam, 0, -1, Z)[1], sw = Math.abs(at(cam, 1, 0, Z)[0] - at(cam, -1, 0, Z)[0]) * 1.08;
    const h = sh * o.hk, w = h * asp; u.rep.value = sw / w; m.scale.set(sw, h, 1);
    m.position.set(0, SEA_Y + h * (.5 - o.wl), Z); m.quaternion.copy(cam.quaternion); m.updateMatrixWorld(); }; // o.wl: waterline, fraction of the strip from the BOTTOM
  return m;
}

// a few small rocks / stumps sticking out of the water further forward: ONE mesh (quads into the rocks.webp atlas), static, no depth
// test (soft alpha fade at the waterline instead of the sea's hard depth cut). They sit behind the titan, which draws over them.
// o.rects: per atlas piece [u0, u1, height frac, w/h] (tools/make_ink_shore.py cut prints them); o.items: [piece, x, z, height]
function rocks(t, o) {
  const pos = [], uv = [], idx = [];
  o.items.forEach(([pi, x, z, h], i) => { const [u0, u1, hf, a] = o.rects[pi], w = h * a, y0 = SEA_Y - h * o.sink;
    pos.push(x - w / 2, y0, z, x + w / 2, y0, z, x + w / 2, y0 + h, z, x - w / 2, y0 + h, z); uv.push(u0, 0, u1, 0, u1, hf, u0, hf); idx.push(i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3); });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
  const u = { map: { value: t }, tint: { value: new THREE.Color(...o.tint) }, fogColor: SH.fogColor, fogK: { value: o.fog }, wd: { value: o.wd } };
  const m = new THREE.Mesh(g, new THREE.ShaderMaterial({ uniforms: u, vertexShader: VS, transparent: true, depthWrite: false, depthTest: false,
    fragmentShader: `uniform sampler2D map; uniform vec3 tint; uniform vec3 fogColor; uniform float fogK; uniform float wd; varying vec2 vUv; varying vec3 vW;
      void main(){ vec4 c = texture2D(map, vUv); float al = c.a * smoothstep(${SEA_Y.toFixed(2)} - wd * .3, ${SEA_Y.toFixed(2)} + wd, vW.y); if (al < .03) discard;
        float k = smoothstep(${SEA_Y.toFixed(2)} + wd * 2.5, ${SEA_Y.toFixed(2)}, vW.y); // wet / fog darkening toward the waterline
        gl_FragColor = vec4(mix(c.rgb * tint, fogColor, fogK + k * .35), al); }` }));
  m.renderOrder = o.ro; m.frustumCulled = false;
  return m;
}

// soft drifting MIST band along the horizon: one camera-facing plane, procedural (no texture), low alpha, slow horizontal drift.
// o.rise > 0 (abyss): wisps also climb upward.
function mist(o) {
  const u = { t: SH.time, col: { value: new THREE.Color(...o.col) }, a: { value: o.a }, asp: { value: 1 }, sp: { value: o.sp ?? 1 }, rise: { value: o.rise ?? 0 }, seed: { value: o.seed ?? 0 } };
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: u, vertexShader: VS, transparent: true, depthWrite: false, depthTest: false,
    fragmentShader: `uniform float t; uniform vec3 col; uniform float a; uniform float asp; uniform float sp; uniform float rise; uniform float seed; varying vec2 vUv;
      void main(){ float x = vUv.x * asp, y = vUv.y, T = t * sp + seed;
        float n = sin(x * 1.7 + T * .11) * .5 + sin(x * 3.9 - T * .17 + 1.3) * .3 + sin(x * 8.3 + T * .23 + y * 3. - rise * T * .6) * .2; // drifting lumps
        float yy = y + n * .09 + rise * (sin(x * 5.1 + T * .3) * .05);
        float band = smoothstep(0., .42, yy) * smoothstep(1., .5, yy); // soft at both edges
        float w = .55 + .45 * (sin(x * 2.3 - T * .14 + n * 2.) * .5 + .5);
        float r = rise > 0. ? .75 + .25 * sin(y * 9. - T * .9 * rise + x * 4.) : 1.; // abyss: faint rising streaks
        float al = band * w * r * a; if (al < .004) discard; gl_FragColor = vec4(col, al); }` }));
  m.renderOrder = o.ro; m.frustumCulled = false;
  m.onBeforeRender = (r, s, cam) => { const Z = o.z, sh = at(cam, 0, 1, Z)[1] - at(cam, 0, -1, Z)[1], sw = Math.abs(at(cam, 1, 0, Z)[0] - at(cam, -1, 0, Z)[0]) * 1.1, h = sh * o.hk;
    m.scale.set(sw, h, 1); m.position.set(0, SEA_Y + h * (.5 - o.wl), Z); m.quaternion.copy(cam.quaternion); u.asp.value = sw / h * .12; m.updateMatrixWorld(); };
  return m;
}

// 11-26 WAIST churn (user: "you can see it flat where the water and the titan collide"). The opaque sea (or fog floor) cuts the titan
// in one straight horizontal line. A painted ring of churned foam / rubble / roots / moss (waist.webp, ragged top AND bottom,
// tapered ends) is laid exactly over that cut, IN FRONT of the titan (no depth test, renderOrder o.ro: over the titan + base puffs,
// under the splash columns 200, the hero 380 and the black frame 395), plus a soft procedural mist band hugging it (2nd quad).
// It follows the titan's real cut: every 3rd frame the titan's (CPU-skinned) part triangles are intersected with the waterline
// y = SEA_Y, giving the body's left / right extent there (inset for the sprite margins), damped; this tracks the POS sliders
// (size / y / depth), the slam pop and the sink / rise (intro, exit: chest, then head, then gone). Nothing crosses = fades out.
function waist(t, o, titan) {
  const img = () => t.image, u = { map: { value: t }, t: SH.time, tint: { value: new THREE.Color(...o.tint) }, foam: { value: new THREE.Color(...o.foam) },
    fogColor: SH.fogColor, fogK: { value: o.fog }, a: { value: 0 }, churn: { value: 0 }, sat: { value: o.sat ?? 1 } };
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: u, vertexShader: VS, transparent: true, depthWrite: false, depthTest: false,
    // v3 (user: "just use an oval, with different normals so it's not flat"): a procedural dark OVAL around the waist at the waterline -
    // lumpy noisy edge, and a fake bumpy surface normal (ellipse dome + noise bumps) lit from above: faint cold rim on top, dark below
    fragmentShader: `uniform sampler2D map; uniform float t; uniform vec3 tint; uniform vec3 foam; uniform vec3 fogColor; uniform float fogK; uniform float a; uniform float churn; uniform float sat; varying vec2 vUv;
      float h1(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f); return mix(mix(h1(i), h1(i + vec2(1, 0)), f.x), mix(h1(i + vec2(0, 1)), h1(i + 1.), f.x), f.y); }
      float fb(vec2 p){ return vn(p) * .55 + vn(p * 2.3 + 7.1) * .3 + vn(p * 5.1 - 3.7) * .15; }
      void main(){ vec2 q = (vUv - .5) * 2.; // -1..1 across the oval
        float ang = atan(q.y, q.x), r = length(q);
        float edge = .78 + .16 * (fb(vec2(ang * 2.2, 3.7)) - .5) * 2. + .05 * sin(ang * 7.); // lumpy outline (static: user - no animation, it only follows the titan)
        if (r > edge) discard;
        float k = r / edge, dome = sqrt(max(0., 1. - k * k));
        float b = fb(q * vec2(3.2, 6.)), bx = fb(q * vec2(3.2, 6.) + vec2(.05, 0.)) - b, by = fb(q * vec2(3.2, 6.) + vec2(0., .05)) - b;
        vec3 n = normalize(vec3(q.x * .9 - bx * 14., q.y * 1.6 - by * 14., dome + .25)); // dome + bumps
        float lit = clamp(dot(n, normalize(vec3(-.35, .85, .45))), 0., 1.);
        vec3 col = mix(tint * .55, foam * 1.6, pow(lit, 3.) * .8) * (.75 + .5 * b); col = mix(col, fogColor, fogK);
        float al = smoothstep(1., .82, k) * a; gl_FragColor = vec4(col, al); }` }));
  m.renderOrder = o.ro; m.frustumCulled = false; m.name = 'waist';
  const mu = { t: { value: 0 }, col: { value: new THREE.Color(...o.mist.col) }, a: { value: 0 }, asp: { value: 1 }, rise: { value: o.mist.rise ?? 0 } };
  const ms = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ uniforms: mu, vertexShader: VS, transparent: true, depthWrite: false, depthTest: false,
    fragmentShader: `uniform float t; uniform vec3 col; uniform float a; uniform float asp; uniform float rise; varying vec2 vUv;
      void main(){ float x = vUv.x * asp, y = vUv.y;
        float n = sin(x * 1.9 + t * .3) * .5 + sin(x * 4.3 - t * .45 + 1.3) * .3 + sin(x * 9.1 + t * .6 + y * 4. - rise * t) * .2;
        float yy = y + n * .1, band = smoothstep(0., .45, yy) * smoothstep(1., .5, yy); // soft lumpy band
        float ends = smoothstep(0., .14, vUv.x) * smoothstep(1., .86, vUv.x);
        float al = band * ends * (.6 + .4 * sin(x * 2.7 - t * .5 + n * 2.)) * a; if (al < .004) discard; gl_FragColor = vec4(col, al); }` }));
  ms.renderOrder = o.ro + .5; ms.frustumCulled = false; ms.name = 'waist';
  // titan cut: [x0, x1] of the titan parts at y = SEA_Y (world), or null
  const v = new THREE.Vector3(), P = [0, 0, 0, 0, 0, 0];
  function cut() {
    let x0 = 1e9, x1 = -1e9; titan.updateMatrixWorld();
    titan.traverseVisible((q) => { if (!q.isMesh || q.renderOrder < 100 || q.renderOrder >= 160) return; const p = q.geometry.attributes.position, ix = q.geometry.index; if (!p || !ix) return;
      const I = ix.array, mw = q.matrixWorld;
      for (let i = 0; i < I.length; i += 3) { for (let k = 0; k < 3; k++) { v.fromBufferAttribute(p, I[i + k]).applyMatrix4(mw); P[k * 2] = v.x; P[k * 2 + 1] = v.y - SEA_Y; }
        for (let k = 0; k < 3; k++) { const j = (k + 1) % 3, ya = P[k * 2 + 1], yb = P[j * 2 + 1]; if ((ya < 0) === (yb < 0)) continue;
          const x = P[k * 2] + (P[j * 2] - P[k * 2]) * ya / (ya - yb); if (x < x0) x0 = x; if (x > x1) x1 = x; } } });
    return x1 > x0 ? [x0, x1] : null; }
  let fr = 0, cx = 0, cw = 0, on = 0, lastY = null, churn = 0, lastT = null, tgt = null, lockS = 1, lockSet = null;
  // the quads stay "visible" (their onBeforeRender is the per-frame hook); when off they collapse to zero size (no fragments)
  m.onBeforeRender = (r, s, cam) => {
    const tt = SH.time.value, dt = lastT == null ? 1 / 60 : Math.min(.1, Math.max(0, tt - lastT)); lastT = tt;
    if (fr++ % (cw ? 20 : 3) === 0) tgt = titan.visible ? cut() : null; // 11-27 PERF PASS: once the width is locked only "is he crossing?" is asked: every 20th frame (the triangle walk was ~2.5% CPU)
    const c = tgt, k = 1 - Math.exp(-dt * 8);
    // 11-26 user: "it still animates when the titan animates (about to hit the water)" - the width is measured ONCE (first time he
    // crosses the water) and after that only follows his position / scale setting, never his poses (fists dipping in, slam pops)
    if (c) { const tx = titan.position.x, sc = (titan.userData.baseS ?? (titan.userData.baseS = titan.scale.x)) || 1;
      if (!cw) { cw = 2 * Math.max(tx - c[0], c[1] - tx) * o.inset; lockS = sc; } cx = tx; }
    on += ((c && cw > .5 ? 1 : 0) - on) * (1 - Math.exp(-dt * 6));
    const y = titan.position.y; if (lastY != null && dt > 0) churn += (Math.min(1, Math.abs(y - lastY) / dt / 8) - churn) * k; lastY = y; u.churn.value = churn;
    const im = img(); if (on < .01 || !im) { m.scale.set(0, 0, 0); ms.scale.set(0, 0, 0); m.updateMatrixWorld(); ms.updateMatrixWorld(); return; }
    const asp = 3.4, W = Math.max(cw, 1) * o.wk * 1.08 * ((window.__titanPos?.().s || 1) / (lockSet ?? (lockSet = window.__titanPos?.().s || 1))), h = W / asp * o.hk, z = titan.position.z + .05; // oval: 3.4 wide : 1 tall, centred on the waterline
    m.scale.set(W, h, 1); m.position.set(cx, SEA_Y + h * (.5 - o.wl), z); m.quaternion.copy(cam.quaternion); m.updateMatrixWorld(); u.a.value = on * o.a;
    const mh = h * o.mist.hk; ms.scale.set(W * o.mist.wk, mh, 1); ms.position.set(cx, SEA_Y + mh * (.5 - o.mist.wl), z + .02); ms.quaternion.copy(cam.quaternion); ms.updateMatrixWorld();
    mu.asp.value = W * o.mist.wk / mh * .25; mu.a.value = on * o.mist.a; }; // static (user: no animation - it just follows the titan)
  return [m, ms];
}

// ?water=abyss / fog: the sea plane's material is swapped for an opaque fog floor (it still writes depth, so the titan's lower body
// stays hidden under the "surface" of the fog). Near colour -> far colour by view distance, slow drifting fog sheets from the shared
// noise. abyss = a black void that fades into fog toward the far rim; fog = no water at all, just a soft low fog bank.
const FLOOR = { abyss: { near: [.004, .009, .012], far: [.13, .22, .25], wisp: [.12, .2, .22], d: [18, 115] },
  fog: { near: [.05, .085, .1], far: [.2, .31, .34], wisp: [.16, .25, .28], d: [10, 95] } };
function fogFloorMat(noise, F) {
  return new THREE.ShaderMaterial({ fog: false, uniforms: { n: { value: noise }, t: SH.time, cN: { value: new THREE.Color(...F.near) }, cF: { value: new THREE.Color(...F.far) },
    cW: { value: new THREE.Color(...F.wisp) }, dd: { value: new THREE.Vector2(...F.d) } },
    vertexShader: 'varying vec3 vW; varying float vD; void main(){ vec4 w = modelMatrix * vec4(position,1.); vW = w.xyz; vec4 mv = viewMatrix * w; vD = -mv.z; gl_Position = projectionMatrix * mv; }',
    fragmentShader: `uniform sampler2D n; uniform float t; uniform vec3 cN; uniform vec3 cF; uniform vec3 cW; uniform vec2 dd; varying vec3 vW; varying float vD;
      void main(){ vec2 p = vW.xz * .014;
        float a = texture2D(n, p + vec2(t * .006, t * .0035)).r, b = texture2D(n, p * 2.7 - vec2(t * .009, -t * .006)).r, f = a * .6 + b * .4;
        float wisp = smoothstep(.45, .8, f) * smoothstep(8., 35., vD);
        vec3 col = mix(cN, cF, smoothstep(dd.x, dd.y, vD));
        col += cW * wisp * (.3 + .7 * smoothstep(12., 80., vD)); // drifting fog sheets
        gl_FragColor = vec4(col, 1.); }` });
}

const Qs = new URLSearchParams(location.search);
// mist bands per water mode: back = over the far edge, near = mid-distance, front = a faint low sheet over the titan's base
const MIST = {
  shore: { back: { z: -74, ro: 30.7, hk: .085, wl: .14, a: .36, col: [.45, .62, .68], sp: 1 },
    near: { z: -60, ro: 30.8, hk: .06, wl: .12, a: .2, col: [.4, .56, .62], sp: 1.4, seed: 40 } },
  abyss: { back: { z: -74, ro: 30.7, hk: .16, wl: .3, a: .38, col: [.42, .6, .66], sp: 1.2, rise: 1 },
    near: { z: -50, ro: 30.8, hk: .12, wl: .6, a: .4, col: [.3, .45, .5], sp: 1.6, rise: 1.4, seed: 40 } },
  fog: { back: { z: -74, ro: 30.7, hk: .14, wl: .3, a: .6, col: [.45, .62, .68], sp: 1, rise: .4 },
    near: { z: -45, ro: 30.8, hk: .11, wl: .35, a: .45, col: [.36, .52, .58], sp: 1.4, rise: .6, seed: 40 },
    front: { z: 2, ro: 118, hk: .09, wl: .22, a: .3, col: [.32, .46, .52], sp: 1.8, rise: .8, seed: 90 } },
};
// waist churn per water mode (theme.deco.waist / .waist.<mode> override): wl = waterline as a fraction of the art from the BOTTOM,
// inset = sprite-margin inset of the measured cut, wk / hk = width / height scale, foam = tint of the pale foam (abyss / fog: it reads
// as mist), fog = mix toward the fog colour
const WAIST = { // 11-26 v2 (user: "not foam - something DARK, irregular shape"): the ring reads as a black ink silhouette of rubble / roots,
  // like the foreground frame, with only a faint cold edge; the mist band is dim
  shore: { ro: 190, wl: .5, inset: .88, wk: 1.12, hk: 1, a: 1, tint: [.1, .12, .14], foam: [.16, .2, .22], fog: .04, sat: .15,
    mist: { col: [.2, .28, .32], a: .18, hk: .9, wk: 1.05, wl: .5, rise: 0 } },
  abyss: { tint: [.08, .1, .11], foam: [.12, .15, .17], fog: .12, sat: .1, mist: { col: [.22, .3, .34], a: .35, hk: 1.2, wl: .45, rise: 1 } },
  fog: { tint: [.1, .12, .13], foam: [.14, .17, .19], fog: .2, sat: .1, mist: { col: [.3, .4, .45], a: .45, hk: 1.3, wl: .45, rise: .6 } },
};
// tex = { back, mid, rock, plants, shore, rocks, waist, water } | null (clears), o = theme.deco
export function applyDeco(ctx, tex, o = {}) {
  clear();
  if (!tex) return;
  const scene = ctx.scene, w = ctx.world, env = w?.env, list = [];
  const L = o.layers || {}, wm = FLOOR[tex.water] || MIST[tex.water] ? tex.water : 'shore', dry = wm !== 'shore', abyss = wm === 'abyss';
  const noRefl = dry ? { refl: 0 } : {}; // no water: no mirrored ruins
  if (tex.back) list.push(...ruinLayer(tex.back, { z: -125, ro: 5, rro: 29, dl: 2, dro: 346, band: [.1, .6], fog: .38, a: 1, tint: [.5, .64, .7], top: [.62, .76, .82], refl: .32, wob: .0012, ...L.back, ...noRefl }));
  if (tex.mid) list.push(...ruinLayer(tex.mid, { z: -82, ro: 8, rro: 29.5, dl: 1, dro: 347, band: [.08, .6], fog: .08, a: 1, tint: [.3, .4, .46], top: [.42, .55, .6], refl: .45, hk: 1.1, ...L.mid, ...noRefl }));
  if (o.beams !== false) { list.push(beams(o.beams || {}, 9, -60)); list.push(beams({ k: .35, ang: -.38, ...(o.beamsFront || {}) }, 119, -36)); }
  // shore / rim strip + rocks + mist (30.4..30.9: after the ruin reflections 29 / 29.5, before the titan's reflection 31+)
  const S = (abyss ? o.rim : o.shore) || {};
  if (tex.shore && S !== false) list.push(Object.assign(shore(tex.shore, abyss
    ? { z: -78, ro: 30.5, hk: .12, wl: .55, tint: [1.1, 1.25, 1.32], top: [1.3, 1.45, 1.5], fog: .08, fadeB: .9, ...S }
    : { z: -78, ro: 30.5, hk: .1, wl: .34, tint: [.95, 1.1, 1.18], top: [1.15, 1.3, 1.36], fog: .1, ...S }), { name: 'shore' }));
  if (tex.rocks && o.rocks !== false) { const R = o.rocks || {};
    list.push(Object.assign(rocks(tex.rocks, { ro: 30.6, tint: [.95, 1.1, 1.18], fog: .1, sink: abyss ? .35 : .12, wd: abyss ? 1.4 : .35,
      rects: [[0, .2948, .8885, 1.341], [.2948, .6922, 1, 1.606], [.6922, 1, .669, 1.859]],
      items: [[0, -11, -56, 5], [1, 11.5, -50, 4.4], [2, -34, -62, 3.6], [2, 40, -64, 3.4]], ...R, ...(abyss ? R.abyss : null) }), { name: 'rocks' })); }
  if (o.mist !== false) { const M = { ...(o.mist || {}) }, D0 = MIST[wm], Mw = M[wm] || {}; // theme.deco.mist.<mode>.<band> overrides
    for (const k of Object.keys(D0)) list.push(Object.assign(mist({ ...D0[k], ...Mw[k] }), { name: 'mist' })); }
  if (tex.waist && ctx.titan && o.waist !== false) { const Wo = o.waist || {}, md = WAIST[wm], dm = { ...WAIST.shore, ...md, ...Wo, ...(Wo[wm] || {}) };
    dm.mist = { ...WAIST.shore.mist, ...md.mist, ...(Wo.mist || {}), ...(Wo[wm]?.mist || {}) }; list.push(...waist(tex.waist, dm, ctx.titan)); }
  if (o.motes !== false) list.push(motes(o.motes || {}));
  if (tex.rock) list.push(frame(tex.rock, tex.plants, o.frame || {}));
  for (const m of list) { m.userData.deco = m.name || (m.isPoints ? 'spores' : m.material.blending === THREE.AdditiveBlending ? 'beams' : m.renderOrder >= 300 ? 'frame' : 'ruins'); scene.add(m); } // tag: main.js __g.passCost groups
  // hide the old floating / far pieces this look replaces (scale 0 + invisible: env.layout() re-shows side pieces on resize)
  const hide = new Set([...(o.hide || []), ...(dry ? ['seaFront', 'seaBack'] : [])]), hidden = [];
  if (env) { for (const k of ['far', 'seaBack', 'seaFront', 'clouds']) if (hide.has(k) && env[k]) hidden.push(env[k]); // seaBack: its painted strip reaches far above the waterline
    for (const s of env.side || []) if (hide.has(s.kind)) hidden.push(s.m); }
  for (const m of hidden) { m.visible = false; m.scale.set(0, 0, 0); }
  // abyss / fog: swap the sea plane's material, switch the water reflections off (restored by clear())
  let floor = null, seaMat = null, refl = null;
  if (dry && w?.water?.o?.seaMat) { seaMat = w.water.o.seaMat; floor = scene.children.find((m) => m.isMesh && m.material === seaMat) || null;
    if (floor) floor.material = fogFloorMat(seaMat.uniforms.n.value, { ...FLOOR[wm], ...(o.floor?.[wm] || {}) });
    if (w.refl && !w.refl.off) { refl = { forced: w.refl.forced, k: w.refl.strength }; w.refl.forced = true; w.refl.setStrength(0); } }
  // the titan-base puffs (main.js world.mist) are depth-cut by the sea plane in one straight line across the screen (just under the
  // shore): no depth test while the ink look is on, their soft edge fades out over the dark water instead
  // (and they're lighter here, o.puffA: at full strength their dark tint muddied the shore behind them)
  const puffs = (w?.mist || []).map((p) => p.m.material).filter((m) => m.depthTest).map((m) => [m, m.uniforms.alpha.value]);
  for (const [m, a] of puffs) { m.depthTest = false; m.uniforms.alpha.value = a * (o.puffA ?? .6); }
  if (w?.water) w.water.dry = dry; // abyss / fog: the blue water splash columns of fist slams look wrong without water
  D = { list, hidden, env, floor, seaMat, refl, w, puffs };
}
function clear() {
  if (!D) return;
  for (const m of D.list) { m.parent?.remove(m); m.geometry.dispose(); m.material.dispose(); }
  DSC.meshes.length = 0;
  if (D.hidden.length && D.env) { for (const m of D.hidden) m.visible = true; D.env.fitScales(); if (D.env.lastL) D.env.layout(...D.env.lastL); }
  if (D.floor) { D.floor.material.dispose(); D.floor.material = D.seaMat; }
  if (D.refl && D.w.refl) { D.w.refl.forced = D.refl.forced; D.w.refl.setStrength(D.refl.k); }
  for (const [m, a] of D.puffs) { m.depthTest = true; m.uniforms.alpha.value = a; }
  if (D.w?.water) D.w.water.dry = false;
  D = null;
}
