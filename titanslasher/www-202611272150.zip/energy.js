// 11-27 ENERGY (lobby UI v2): a titan fight the PLAYER starts (the FIGHT tab) costs energy; it refills over time, also while the
// app is closed. CYCLE-mode fights that start by themselves on the world clock and the training dummy are always free.
// Saved in the game SAVE (main.js tt_save) as SAVE.energy = { v, t } (t = the clock time the next +1 counts from).
// Clock: the daily rewards' trusted clock (daily.js dailyNow via window.DAILY._now: server time when known), else Date.now();
// a clock that goes back never gives energy (t is clamped to now).
// Test URL: ?energycost=N (cost per fight) ?energymax=N ?energymin=M (minutes per +1) ?energy=inf (never spent) ?energy=N (set now)
import PASS from './pass.js';
const Q = new URLSearchParams(location.search);
const num = (k, d) => { const v = parseFloat(Q.get(k)); return isFinite(v) && v > 0 ? v : d; };
export const MAX = Math.round(num('energymax', 30)); // base max; the live max = max() (+5 at player Lv 10 / 20 / 30, progression.js PROG.maxBonus)
export const COST = Math.round(num('energycost', 5));
export const REGEN_MS = num('energymin', 1.8) * 60000 / PASS.N; // ?pass=N game pass: N x faster refill (cost unchanged)
// 11-27 user: +5 energy (= 1 fight) every 9 min -> +1 every 1.8 min
export const INF = Q.get('energy') === 'inf'; // 11-27 user: energy is BACK (was removed for a while; ?energy=inf = never spent, testing)
if (INF) document.documentElement.classList.add('noenergy');
let SAVE = null, save = () => {};
export const max = () => { let b = 0; try { b = +window.PROG?.maxBonus || 0; } catch (e) { /* no progression */ } return MAX + b; };
const now = () => { try { const n = window.DAILY?._now?.(); if (isFinite(n)) return n; } catch (e) { /* no daily */ } return Date.now(); };

export function init(o) {
  SAVE = o.SAVE; save = o.save || save;
  const E = SAVE.energy;
  if (!E || !isFinite(E.v) || !isFinite(E.t)) SAVE.energy = { v: max(), t: now() };
  const set = Q.get('energy'); if (set != null && set !== 'inf' && isFinite(+set)) SAVE.energy = { v: Math.max(0, Math.round(+set)), t: now() }; // test: ?energy=0
  tick(); save();
}
// apply the refill since t; returns the state { v, max, next (ms to the next +1, 0 when full) }
export function tick() {
  const E = SAVE.energy, n = now(), M = max();
  if (n < E.t) E.t = n; // clock went back: no gain, restart the count
  if (E.v >= M) E.t = n;
  else { const k = Math.floor((n - E.t) / REGEN_MS); if (k > 0) { E.v = Math.min(M, E.v + k); E.t = E.v >= M ? n : E.t + k * REGEN_MS; } }
  return { v: E.v, max: M, next: E.v >= M ? 0 : Math.max(0, REGEN_MS - (n - E.t)) };
}
export const get = () => tick().v;
export const canFight = () => INF || get() >= COST;
// ms until there is enough for one fight (0 = now)
export function untilFight() { const s = tick(); if (INF || s.v >= COST) return 0; return s.next + (COST - s.v - 1) * REGEN_MS; }
export function spend(n = COST) { if (INF) return true; tick(); const E = SAVE.energy; if (E.v < n) return false; const full = E.v >= max(); E.v -= n; if (full) E.t = now(); save(); return true; }
export function add(n) { tick(); const E = SAVE.energy; E.v = Math.min(Math.max(max(), E.v), E.v + n); save(); } // ad / rewards: capped at max()
// 11-27 level up (progression.js): a FULL refill (never takes away energy above the max)
export function refill() { if (!SAVE) return; tick(); const E = SAVE.energy; E.v = Math.max(E.v, max()); E.t = now(); save(); }
if (typeof window !== 'undefined') window.ENERGY = { add, refill, max, get, tick, COST };
export const mmss = (ms) => { const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
