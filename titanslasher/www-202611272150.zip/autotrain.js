// Titan Slasher AUTO-TRAIN + OFFLINE XP (11-27). LOGIC ONLY (no DOM): the game calls tick() each lobby frame with a hit()
// callback that runs the normal dummy hit path (visuals / sfx), and tapped() on every real tap of the player's.
// 11-28 user "auto tapping is visual only, it should not change anything; 2 states: normal tap and offline; if you're not
// tapping that is offline": auto-train only SHOWS the hero slashing (unlock UNLOCK_LV, never in fights) and pays nothing.
// Offline XP (OFFLINE.perSec) is paid while the player is not tapping: on the menu (after IDLE_GAP_S without a tap) and with the
// app closed (popup on return), each stretch up to capH() hours; auto on / off / locked makes no difference.
// Upgrade (coins): cap (offline hours). Save: SAVE.auto = { on, up: { cap }, last (trusted ms of the last lobby moment),
// acc (fractional visual hits), xf (fractional idle XP), pend (away result) }. Clock: ctx.now() (server time when known).
// Test URL: ?autotrain=1 (unlock + on, ignores the level), ?offline=S (pretend S seconds away at boot), ?autorate=N (hits/s).

// ---------------------------------------------------------------- balance (tune here)
export const UNLOCK_LV = 5;
export const BASE_RATE = 3; // visual hits/s
export const OFFLINE = { baseH: 4, perSec: .9, minS: 60 }; // XP while not tapping (0.3 x 3 a second); away under 60 s = nothing
export const IDLE_GAP_S = 1.5; // on the menu: this long without a tap = not tapping
export const UPS = {
  cap: { name: 'OFFLINE CAP', max: 4, step: 2, cost: (l) => Math.round(800 * Math.pow(2.1, l)), fmt: (v) => `${v} h` },
};
export const AD_MULT = 2; // "WATCH AD x2" on the offline popup

const Q = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
const PASS_N = () => (typeof window !== 'undefined' && window.PASS ? window.PASS.N : 1); // ?pass=N game pass: coins x N, offline away time x N (cap = N game h)
const FORCE = Q.get('autotrain') === '1', RATE_Q = +Q.get('autorate') || 0;
let C = null; // { SAVE, save, now(), level(), inLobby(), addXp(n, src) }
let quiet = 0, idle = 0; // seconds since the last real tap; length of the current not-tapping stretch on the menu

function st() {
  const S = C.SAVE;
  if (!S.auto || typeof S.auto !== 'object') S.auto = { on: false, up: { speed: 0, cap: 0, coins: 0 }, last: 0, acc: 0, cf: 0, pend: null };
  S.auto.up = Object.assign({ speed: 0, cap: 0, coins: 0 }, S.auto.up);
  return S.auto;
}
const now = () => (C.now ? C.now() : Date.now());
export const OFF = false; // 11-27 user: auto-train in the lobby is fine (back on) - only NO ADS on it
export const unlocked = () => FORCE || (C && C.level ? C.level() >= UNLOCK_LV : false);
export const isOn = () => !!(C && unlocked() && st().on);
// current values of the upgrades
export const rate = () => RATE_Q || BASE_RATE; // visual hits/s
export const capH = () => OFFLINE.baseH + st().up.cap * UPS.cap.step; // offline hours
export const valueOf = (k, l = st().up[k]) => OFFLINE.baseH + l * UPS.cap.step;
// upgrade panel rows: [{ k, name, lv, max, cost (null at max), now, next, can }]
export function upgrades() {
  const A = st();
  return Object.entries(UPS).map(([k, u]) => { const l = A.up[k], mx = l >= u.max;
    return { k, name: u.name, lv: l, max: u.max, cost: mx ? null : u.cost(l), now: u.fmt(valueOf(k, l)), next: mx ? null : u.fmt(valueOf(k, l + 1)), can: !mx && (C.SAVE.coins || 0) >= u.cost(l) }; });
}
export function buy(k) {
  const u = UPS[k], A = st(); if (!u) return { ok: false, why: 'key' }; const l = A.up[k];
  if (l >= u.max) return { ok: false, why: 'max' }; const c = u.cost(l); if ((C.SAVE.coins || 0) < c) return { ok: false, why: 'coins', cost: c };
  C.SAVE.coins -= c; A.up[k]++; C.save(); return { ok: true, cost: c, lv: A.up[k] };
}
export function setOn(on) { const A = st(); if (on && !unlocked()) return false; A.on = !!on; A.last = now(); A.acc = 0; C.save(); return A.on; }
export const toggle = () => setOn(!st().on);

// the player tapped the dummy: not offline
export function tapped() { quiet = 0; idle = 0; }
// lobby frame: dt seconds, hit() runs one visual dummy hit (null while the lobby is paused). Pays the not-tapping XP and keeps the
// away-time clock (A.last) fresh. Returns the visual hits done this frame.
let saveT = 0;
export function tick(dt, hit) { if (OFF || !C || !C.inLobby || !C.inLobby()) return 0;
  const A = st(), d = Math.min(dt, .25); let n = 0;
  if (isOn() && hit) { A.acc += d * rate();
    while (A.acc >= 1 && n < 4) { A.acc -= 1; n++; try { hit(); } catch (e) { /* hit path busy */ } }
    if (A.acc > 1) A.acc = 1; } // a long frame never machine-guns
  quiet += d;
  if (quiet >= IDLE_GAP_S && idle < capH() * 3600) { idle += d; A.xf = (A.xf || 0) + d * OFFLINE.perSec * PASS_N();
    const xp = Math.floor(A.xf); if (xp) { A.xf -= xp; C.addXp && C.addXp(xp, 'auto'); } }
  A.last = now(); saveT -= dt; if (saveT <= 0) { saveT = 5; C.save(); }
  return n;
}
// call when leaving the lobby (fight start) or the page hides: the away time counts from here
export function mark() { if (!C) return; const A = st(); A.last = now(); C.save(); }

// gains for being away since SAVE.auto.last (always: toggle off / locked too). { secs, capped, xp } or null
export function offline(t = now()) {
  const A = st(); if (!A.last) return null;
  const away = (t - A.last) / 1000 * PASS_N(); if (!(away >= OFFLINE.minS)) return null; // also: clock went back -> NaN / negative -> nothing
  const secs = Math.min(away, capH() * 3600), xp = Math.floor(secs * OFFLINE.perSec);
  return { secs: Math.round(secs), away: Math.round(away), capped: away > capH() * 3600, xp };
}
// take the offline gains once (mult = AD_MULT after a rewarded ad). Returns what was paid, or null.
export function claimOffline(mult = 1) {
  const A = st(), g = A.pend || offline(); if (!g) return null; A.pend = null; A.last = now();
  const xp = Math.round(g.xp * mult);
  if (xp && C.addXp) C.addXp(xp, 'auto'); C.save();
  return { ...g, coins: 0, xp, mult };
}
// boot / app resume: freeze the offline result (so the popup and the claim agree) and return it for the popup
export function resume() { if (OFF) return null; const A = st(); if (!A.pend) { A.pend = offline(); A.last = now(); C.save(); } return A.pend; }
export const adReady = () => false; // 11-27 user: no ads on the auto-tap feature (the offline x2 ad is gone)
export async function claimWithAd() { if (!adReady()) return null; let ok = false; try { ok = !!(await window.__rewardedAd('autotrain')); } catch (e) {} return claimOffline(ok ? AD_MULT : 1); }

// ctx: { SAVE, save, now(), level(), inLobby(), addXp(n, src) }
export function init(ctx) {
  C = ctx; const A = st();
  if (FORCE) A.on = true;
  if (Q.has('offline')) { A.last = now() - Math.max(0, +Q.get('offline')) * 1000; A.pend = null; }
  C.save(); return A;
}

const AUTO = { init, tick, tapped, mark, offline, resume, claimOffline, claimWithAd, adReady, unlocked, isOn, setOn, toggle, rate, capH, upgrades, buy, UNLOCK_LV, UPS };
if (typeof window !== 'undefined') window.AUTOTRAIN = AUTO;
export default AUTO;
