// Inventory / equipment screen (11-26): painted 9-slice frame (art/ui/panel.webp, same as the results), paper doll (hero
// portrait with the equipped blade in hand, 3 slots each side, like Runebound's vault), stat summary, bag grid, item details
// with UPGRADE / EQUIP, and a small coin SHOP tab. Phone portrait first; desktop = two columns. DOM + inventory.css only.
import * as EQ from './equipment.js';
import { itemIcon, UI as UIDIR, INK } from './uiart.js';
import * as WFX from './weaponfx.js'; // 11-26: the blade's element fx on the portrait (CSS only: glint, particles, bolts)
import * as EN from './energy.js'; // 11-27 Energy Chest: buy a full refill with shards
import PASS from './pass.js';
import { dailyNow } from './daily.js'; // 11-27 free chest timer (trusted server time when known)
import { chestItem } from './drops.js';
import * as IAP from './iap.js'; // 11-27 shard packs for real money in the store apps (display-only in browsers)

const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.round(n).toLocaleString('en-US');
let saveFn = () => {};
let el = null, sel = null, selG = null, gtab = 'bag', v3d = false, tab = 'gear', sfx = () => {}, coinHud = () => {}, SAVE = null;
const iconURL = (d) => `${itemIcon(d.icon)}`;
const reqLv = (d) => window.PROG?.reqLv?.(d) ?? 1; // 11-27 gear level requirement (progression.js)
const pct = (k, v) => k === 'crit' ? `+${+v.toFixed(1)}%` : `+${Math.round(v)}%`;

export function init(o) {
  SAVE = o.SAVE; sfx = o.sfx || sfx; coinHud = o.coinHud || coinHud; saveFn = o.save || saveFn;
  IAP.init({ SAVE, save: o.save || (() => {}), coinHud: () => { coinHud(); if (el && !el.classList.contains('hidden')) $('invCoins').textContent = fmt(SAVE.coins); }, sfx: (k) => sfx(k),
    onPrice: () => { if (el && !el.classList.contains('hidden') && tab === 'shop') render(); } }); // the store's local prices arrive async
  const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'inventory.css'; document.head.appendChild(css);
  el = document.createElement('div'); el.id = 'inv'; el.className = 'panel hidden';
  el.innerHTML = `<div class="iframe"><div class="ihead"><button class="hback" aria-label="Back"></button><b class="ititle">HERO</b><div class="itabs"><button data-tab="gear">GEAR</button><button data-tab="shop">SHOP</button></div>
    <div class="icoin"><span>&#9670;</span> <b id="invCoins">0</b></div><button class="iclose" aria-label="Close">&#10005;</button></div><div class="ibody"></div></div>`;
  document.body.appendChild(el);
  el.addEventListener('click', onClick);
  EQ.onChange(() => { if (!el.classList.contains('hidden')) render(); });
}
// 11-26 load speed: the item icons (~0.4 MB) are fetched on the first GEAR / SHOP open, not at boot (render() shows the visible
// ones at once; this warms the rest so switching tabs shows every icon)
let keep = null;
const warm = () => { if (keep || !EQ.DATA) return; keep = EQ.DATA.items.map((d) => { const i = new Image(); i.decoding = 'async'; i.src = iconURL(d); return i; }); };
export function open(t = 'gear') {
  if (!EQ.DATA) return; tab = t; warm(); const eq = EQ.equipped(); if (!sel || !EQ.byUid(sel)) sel = eq.weapon?.uid ?? null;
  selG = null; render(); clearTimeout(outT); el.classList.remove('hidden', 'go', 'out'); void el.offsetWidth; el.classList.add('go');
}
// 11-27 ink lobby: the SHOP / GEAR tab screen (#inv.tabscr) is a bottom sheet that slides down on close (kit-ui.css);
// instant = no slide (switching to another tab screen); the popup from the results closes at once as before
let outT = 0;
const INKUI = document.documentElement.classList.contains('ink');
export function close(instant) {
  clearTimeout(outT); v3d = false; selG = null; EQ.setPreview(null); // the camera eases back while the sheet slides down; the preview reverts at once
  if (!instant && INKUI && el.classList.contains('tabscr') && !el.classList.contains('hidden')) { el.classList.add('out'); outT = setTimeout(() => { el.classList.add('hidden'); el.classList.remove('out', 'g3d'); coinHud(); }, el.classList.contains('g3d') ? 450 : 220); return; } // 11-27 gear: .45 s = the camera ease (lobby-ui GV.dur)
  el.classList.add('hidden'); el.classList.remove('out', 'g3d'); coinHud();
}
// 11-27 user: ink lobby GEAR = "3D gear view" (lobby-ui.js turns it on): the live lobby camera frames the real 3D hero (idle) in
// the top half, this sheet is the bottom half without the CSS portrait: 6 equipped slots in a row, the bag (owned items only),
// a GOD TIER row of unowned epic / legendary items (locked; tap = preview), then the item card + stats. Tapping any item previews
// it on the 3D hero (EQ.setPreview: visuals only, never saved); the equipped item / closing reverts.
export function setView3d(on) { v3d = !!on; el.classList.toggle('g3d', v3d); sel = null; selG = null; gtab = 'bag'; marked.clear(); if (!v3d) EQ.setPreview(null); if (isOpen()) render(); }
export const view3d = () => v3d && isOpen() && tab === 'gear';
export const isOpen = () => el && !el.classList.contains('hidden');

function tile(it, extra = '') {
  const d = EQ.def(it), r = EQ.rarity(it), on = EQ.isEquipped(it), lk = !on && EQ.canWear && !EQ.canWear(it); // 11-27 above your level: padlock (prog-ui.css)
  return `<button class="it${d.slot === 'weapon' ? ' wpn' : ''}${sel === it.uid ? ' sel' : ''}${on ? ' on' : ''}${lk ? ' lock' : ''}" data-uid="${it.uid}" data-r="${r.key}" style="--c:${r.color}" ${extra}>
    <img src="${iconURL(d)}" alt="">${it.lv ? `<em>+${it.lv}</em>` : ''}${on ? '<i>E</i>' : ''}${lk ? `<span class="rq">Lv ${reqLv(d)}</span>` : ''}</button>`;
}
function slotTile(s) {
  const it = EQ.equipped()[s.key];
  return it ? tile(it).replace('class="it', 'class="it slot') : `<button class="it slot empty" data-slot="${s.key}"><small>${s.name.toUpperCase()}</small></button>`;
}
// 11-26 user: "gear view: animate the idle" - the idle flipbook atlas (rig.idle_anim, same as heroanim.js in game) as a CSS step
// animation on the portrait; the blade follows each frame's hand / dir anchor (poses.idle_<i>) with matching step keyframes.
function portraitAnim(R, A, wd, W, cape) {
  const P = R.poses.idle, pad = A.pad || 0, iw = P.w + 2 * pad, ih = P.h, n = A.n, dur = (n / (A.fps || 8)).toFixed(3), L = (R.len || 560) * (W.len || 1), ww = L * W.asp;
  const id = 'pa' + Math.random().toString(36).slice(2, 7), bg = [], bl = [];
  for (let i = 0; i < n; i++) { const pc = (i / n * 100).toFixed(3) + '%', cx = i % A.cols, cy = Math.floor(i / A.cols);
    bg.push(`${pc}{background-position:${A.cols > 1 ? (cx / (A.cols - 1) * 100) : 0}% ${A.rows > 1 ? (cy / (A.rows - 1) * 100) : 0}%}`);
    const F = R.poses['idle_' + i] || P, hd = F.hand || P.hand, dr = F.dir || P.dir, ang = Math.atan2(dr[0], -dr[1]) * 180 / Math.PI;
    bl.push(`${pc}{left:${(hd[0] * 100 - W.grip[0] * ww / iw * 100).toFixed(2)}%;top:${(hd[1] * 100 - W.grip[1] * L / ih * 100).toFixed(2)}%;transform:rotate(${ang.toFixed(1)}deg)}`); }
  const F0 = R.poses.idle_0 || P, fc = WFX.TABLE[wd?.id] || WFX.TABLE.w_starter;
  const st = `width:${(ww / iw * 100).toFixed(2)}%;transform-origin:${W.grip[0] * 100}% ${W.grip[1] * 100}%;z-index:${F0.front ? 2 : 0};animation:${id}b ${dur}s step-end infinite`;
  const blade = WFX.ON ? `<div class="bladew m-${fc.mode}" style="${st};--c1:${rgb(fc.core)};--c2:${rgb(fc.edge)}"><img class="blade" src="${W.file}" alt=""><span class="bglint" style="-webkit-mask-image:url('${W.file}');mask-image:url('${W.file}')"></span></div>${bladeFx(wd?.id, { ...F0, w: iw, h: ih }, W, L, iw, ih)}`
    : `<img class="blade" src="${W.file}" alt="" style="${st}">`;
  const hd = headHtml(R, Array.from({ length: n }, (_, i) => R.poses['idle_' + i]?.hs || P.hs), iw, ih, `${id}h ${dur}s step-end infinite`, id + 'h');
  return `<style>@keyframes ${id}a{${bg.join('')}}@keyframes ${id}b{${bl.join('')}}${hd.kf}</style><div class="hero"><div class="aura"></div><div class="fig" style="aspect-ratio:${iw}/${ih}">`
    + `<div class="body" style="position:absolute;inset:0;background:url('${A.file}') 0 0/${A.cols * 100}% ${A.rows * 100}% no-repeat;animation:${id}a ${dur}s step-end infinite"></div>${hd.html || eyesHtml(A.file, A.cols, A.rows, `${id}a ${dur}s step-end infinite`)}${blade}</div></div>`;
}
// 11-27 mask = whole head (?head=1): the body frames are headless, so the portrait gets the head sprite as its own layer, pivot (neck
// point in the sprite) on each frame's neck socket (+ EQ.headSeat() offset / size) hs = [u, v, rot, size idle px] (same rule as equipment.js updateMask; idle rot is 0).
// No eye-glow layer then (the headless body has no glow masks; a missing mask turned the screen-blend layer into a cyan wash).
function headHtml(R, hss, iw, ih, anim, kfId) {
  const D = EQ.headLook?.(); if (!D || !hss[0]) return { html: '', kf: '' };
  const S = EQ.headSeat?.() || { dx: 0, dy: 0, s: 1 }, hp = hss[0][3] * (D.h || 1) * S.s; // head height in frame px; seat offset as margins (% of the figure width)
  const pos = (hs) => `left:${(hs[0] * 100).toFixed(2)}%;top:${(hs[1] * 100).toFixed(2)}%`;
  const kf = hss.length > 1 ? `@keyframes ${kfId}{${hss.map((hs, i) => `${(i / hss.length * 100).toFixed(3)}%{${pos(hs)}}`).join('')}}` : '';
  const st = `position:absolute;${pos(hss[0])};height:${(hp / ih * 100).toFixed(2)}%;margin:${(-((D.dy || 0) + S.dy) * hp / iw * 100).toFixed(2)}% 0 0 ${(((D.dx || 0) + S.dx) * hp / iw * 100).toFixed(2)}%;width:auto;max-width:none;z-index:1;transform:translate(${(-D.pivot[0] * 100).toFixed(2)}%,${(-D.pivot[1] * 100).toFixed(2)}%)${kf ? `;animation:${anim}` : ''}`;
  return { html: `<img class="headl" src="${D.file}" alt="" style="${st}">`, kf };
}
// 11-27 ink hero: glowing eye holes on the portrait (same masks as in game, art/hero_ink/*_glow.webp). Mask x cyan (background
// multiply) screened over the body; a blurred copy is the halo; the atlas layout + step keyframes match the body layer.
const EYE_OFF = /[?&](noeyes=1|inkblend=0)/.test(location.search);
function eyesHtml(file, cols = 1, rows = 1, anim = '') {
  if (!EQ.isInk() || EYE_OFF) return '';
  const st = `background:linear-gradient(#a6fbff,#a6fbff),url('${file.replace(/\.webp$/, '_glow.webp')}') 0 0/${cols * 100}% ${rows * 100}% no-repeat;${anim ? `animation:${anim};` : ''}`;
  return `<div class="eyes"><i style="${st}"></i><i class="h" style="${st}"></i></div>`;
}
function portrait() { // idle hero + the equipped blade at the hand anchor (data/hero_rig.json), like in the game
  const R = EQ.RIG, P = R?.poses?.idle, wd = EQ.weaponDef(), W = R?.weapons?.[wd?.id] || R?.weapons?.w_starter;
  let blade = '';
  if (P?.hand && W) {
    const iw = P.w, ih = P.h, L = (R.len || 560) * (W.len || 1), ww = L * W.asp, ang = Math.atan2(P.dir[0], -P.dir[1]) * 180 / Math.PI;
    const st = `left:${(P.hand[0] * 100 - W.grip[0] * ww / iw * 100).toFixed(2)}%;top:${(P.hand[1] * 100 - W.grip[1] * L / ih * 100).toFixed(2)}%;width:${(ww / iw * 100).toFixed(2)}%;transform-origin:${W.grip[0] * 100}% ${W.grip[1] * 100}%;transform:rotate(${ang.toFixed(1)}deg);z-index:${P.front ? 2 : 0}`;
    const fc = WFX.TABLE[wd?.id] || WFX.TABLE.w_starter;
    blade = WFX.ON ? `<div class="bladew m-${fc.mode}" style="${st};--c1:${rgb(fc.core)};--c2:${rgb(fc.edge)}"><img class="blade" src="${W.file}" alt=""><span class="bglint" style="-webkit-mask-image:url('${W.file}');mask-image:url('${W.file}')"></span></div>${bladeFx(wd?.id, P, W, L, iw, ih)}`
      : `<img class="blade" src="${W.file}" alt="" style="${st}">`;
  }
  const cape = EQ.equipped().armor && EQ.def(EQ.equipped().armor).cape;
  if (R?.idle_anim && P?.hand && W && !cape && !/[?&]noidleanim=1/.test(location.search)) return portraitAnim(R, R.idle_anim, wd, W, cape);
  const hs1 = P?.hs ? headHtml(R, [P.hs], P.w, P.h, '', '') : { html: '' }; // head mode: still idle body + the head layer
  return `<div class="hero${cape ? ' caped' : ''}" style="${cape ? `--cape:rgb(${cape.map((v) => Math.min(255, v * 200)).join(',')})` : ''}"><div class="aura"></div><div class="fig" style="aspect-ratio:${P ? P.w + '/' + P.h : '5/6'}"><img class="body" src="${capeBody(cape)}" alt="">${hs1.html || (P?.file ? eyesHtml(P.file) : '')}${blade}</div></div>`;
}
// weapon fx on the portrait (CSS keyframes, no canvas): particles spawn along the blade line (hand -> tip, in % of the figure)
// and drift screen-up; storm adds 3 flickering SVG bolts; the glint sweep runs inside the rotated blade wrapper (masked by the art)
const rgb = (a, k = 1) => `rgb(${a.map((v) => Math.round(Math.min(1, v * k) * 255)).join(',')})`;
function bladeFx(id, P, W, L, iw, ih) {
  const c = WFX.TABLE[id] || WFX.TABLE.w_starter, mode = c.mode, lt = L * W.grip[1], d = Math.hypot(P.dir[0], P.dir[1]) || 1;
  const hx = P.hand[0] * 100, hy = P.hand[1] * 100, tx = hx + P.dir[0] / d * lt / iw * 100, ty = hy + P.dir[1] / d * lt / ih * 100;
  let s = 7; const r = () => (s = (s * 16807) % 2147483647) / 2147483647; // fixed layout per render (no flicker on re-render)
  const n = { flame: 14, storm: 9, frost: 9, shine: 7, spore: 8, void: 10 }[mode] || 7, parts = [];
  for (let i = 0; i < n; i++) {
    const f = .2 + r() * .85, x = hx + (tx - hx) * f + (r() - .5) * 4, y = hy + (ty - hy) * f + (r() - .5) * 4, dur = (mode === 'storm' ? .35 : mode === 'flame' ? .7 : 1.6) * (.7 + r() * .6);
    const dx = mode === 'storm' ? (r() - .5) * 26 : (r() - .5) * 10, dy = mode === 'storm' ? (r() - .5) * 26 : mode === 'spore' ? 14 + r() * 10 : -(14 + r() * (mode === 'flame' ? 22 : 12));
    const col = mode === 'storm' && r() < .3 ? c.spark || c.core : r() < .5 ? c.core : c.edge;
    parts.push(`<i style="left:${x.toFixed(1)}%;top:${y.toFixed(1)}%;--d:${dur.toFixed(2)}s;--dl:-${(r() * dur).toFixed(2)}s;--dx:${dx.toFixed(0)}px;--dy:${dy.toFixed(0)}px;--pc:${rgb(col)};--sz:${(mode === 'void' ? 14 : mode === 'flame' ? 9 : 6) * (.7 + r() * .6)}px"></i>`);
  }
  let svg = '';
  if (mode === 'storm') { const bolt = (k) => { const pts = []; const f0 = .2 + r() * .45, f1 = Math.min(1.05, f0 + .3 + r() * .25);
      for (let j = 0; j <= 6; j++) { const f = f0 + (f1 - f0) * j / 6, o = j && j < 6 ? (r() - .5) * 7 : 0; pts.push(`${(hx + (tx - hx) * f - P.dir[1] / d * o).toFixed(1)},${(hy + (ty - hy) * f + P.dir[0] / d * o).toFixed(1)}`); }
      return `<polyline points="${pts.join(' ')}" style="animation-delay:-${(k * .17).toFixed(2)}s"/>`; };
    svg = `<svg class="wbolts" viewBox="0 0 100 100" preserveAspectRatio="none">${bolt(0)}${bolt(1)}${bolt(2)}</svg>`; }
  return `<div class="wfx m-${mode}" style="--c1:${rgb(c.core)};--c2:${rgb(c.edge)};--c3:${rgb(c.edge2 || c.edge)}">${svg}${parts.join('')}</div>`;
}
// the armour's cape colour on the portrait: same recolour as the in-game shader (equipment.js capeTint), cached per colour
const capeCache = new Map();
function capeBody(cape) {
  const src = EQ.heroFile('idle'); if (!cape) return src; // head mode: the headless idle body (headHtml adds the head; the baked portrait_<head> is cropped, so the blade anchors would not match)
  const key = src + cape.join(); if (capeCache.has(key)) return capeCache.get(key) || src;
  capeCache.set(key, null);
  const im = new Image(); im.onload = () => {
    const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const g = c.getContext('2d'); g.drawImage(im, 0, 0);
    const d = g.getImageData(0, 0, c.width, c.height), p = d.data, ss = (a, b, x) => { const u = Math.min(1, Math.max(0, (x - a) / (b - a))); return u * u * (3 - 2 * u); };
    for (let i = 0; i < p.length; i += 4) { if (p[i + 3] < 8) continue; const r = p[i] / 255, gg = p[i + 1] / 255, b = p[i + 2] / 255, m = ss(.3, .48, r - Math.max(gg, b)); if (m <= 0) continue;
      const l = r * .85 + gg * .3; for (let k = 0; k < 3; k++) p[i + k] = Math.min(255, 255 * ((k ? (k === 1 ? gg : b) : r) * (1 - m) + cape[k] * l * m)); }
    g.putImageData(d, 0, 0); capeCache.set(key, c.toDataURL('image/webp', .9)); if (isOpen()) render();
  }; im.src = src; return src;
}
function statRow() {
  const p = EQ.S.pct, N = EQ.DATA.statShort, S = EQ.S;
  const v = { tap: pct('tap', p.tap), crit: `${+(S.crit * 100).toFixed(1)}%`, critDmg: `x${S.critMul.toFixed(2)}`, wp: pct('wp', p.wp), combo: pct('combo', p.combo), fin: pct('fin', p.fin), coins: pct('coins', p.coins) };
  return `<div class="istats">${Object.keys(v).map((k) => `<div><small>${N[k]}</small><b>${v[k]}</b></div>`).join('')}</div>`;
}
const HOW = (d) => d.trackOnly ? 'Daily Rewards &middot; day 30' : 'Drops from titans &middot; chests';
function detailG(d) { // GOD TIER preview card: an item you do not own (no EQUIP / UPGRADE)
  const r = EQ.DATA.rarity[d.rarity], now = EQ.statsAt({ id: d.id, lv: 0 }), slotName = EQ.DATA.slots.find((s) => s.key === d.slot).name;
  const lines = Object.keys(now).map((k) => `<div class="sl"><span>${EQ.DATA.statNames[k]}</span><b>${pct(k, now[k] || 0)}</b></div>`).join('');
  return `<div class="idet notown" data-r="${r.key}" style="--c:${r.color}"><div class="dico${d.slot === 'weapon' ? ' wpn' : ''}"><img src="${iconURL(d)}" alt=""></div>
    <div class="dtx"><b>${d.name}</b><small>${r.name.toUpperCase()} ${slotName.toUpperCase()} &middot; NOT OWNED</small>${lines}${d.info ? `<p>${d.info}</p>` : ''}<p class="rep">Previewing on your hero</p></div>
    <div class="dbtns"><button class="btn" disabled>${HOW(d)}</button></div></div>`;
}
function detail() {
  if (selG && EQ.DATA.byId[selG]) return detailG(EQ.DATA.byId[selG]);
  const it = sel != null && EQ.byUid(sel);
  if (!it) return '<div class="idet empty"><p>Tap an item.</p></div>';
  const d = EQ.def(it), r = EQ.rarity(it), now = EQ.statsAt(it), max = it.lv >= EQ.maxLv(it), nx = max ? null : EQ.statsAt(it, it.lv + 1), cost = EQ.upgradeCost(it);
  const keys = [...new Set([...Object.keys(now), ...Object.keys(nx || {})])];
  const lines = keys.map((k) => `<div class="sl"><span>${EQ.DATA.statNames[k]}</span><b>${pct(k, now[k] || 0)}</b>${nx ? `<i>&#9656; ${pct(k, nx[k] || 0)}</i>` : ''}</div>`).join('');
  const on = EQ.isEquipped(it), slotName = EQ.DATA.slots.find((s) => s.key === d.slot).name;
  const cur = !on && EQ.equipped()[d.slot];
  return `<div class="idet" data-r="${r.key}" style="--c:${r.color}"><div class="dico${d.slot === 'weapon' ? ' wpn' : ''}"><img src="${iconURL(d)}" alt=""></div>
    <div class="dtx"><b>${d.name}</b><small>${r.name.toUpperCase()} ${slotName.toUpperCase()} &middot; LV ${it.lv}/${EQ.maxLv(it)}</small>${lines}${d.info ? `<p>${d.info}</p>` : ''}${cur ? `<p class="rep">Replaces ${EQ.def(cur).name} (LV ${cur.lv})</p>` : ''}</div>
    <div class="dbtns">${max ? '<button class="btn" disabled>MAX LEVEL</button>' : `<button class="btn hot" data-act="up" ${SAVE.coins < cost ? 'data-short="1"' : ''}>UPGRADE <span><i class="gem">&#9670;</i> ${fmt(cost)}</span></button>`}
      ${on ? (d.slot === 'weapon' ? '<button class="btn" disabled>EQUIPPED</button>' : '<button class="btn" data-act="off">UNEQUIP</button>') : EQ.canWear && !EQ.canWear(it) ? `<button class="btn reach" disabled>REACH LV ${reqLv(d)}</button>` : '<button class="btn" data-act="on">EQUIP</button>'}</div></div>`;
}
// 11-27 user: the GEAR popup card (ref: a mobile RPG item card, not copied): title plate + rarity, big icon | level + text,
// a STATS list (now > next level), the values at MAX level (dimmed, like locked tiers), the blade effect for weapons, a cost bar
// (shards you have / the upgrade cost) and the buttons. A GOD TIER item (not owned) shows level 0 and where it drops.
const FXNAME = { shine: 'Starlight glint', flame: 'Burning blade', storm: 'Storm sparks', frost: 'Frost mist', spore: 'Spore drift', void: 'Void embers' };
function popCard() {
  const own = !selG && sel != null && EQ.byUid(sel), d = own ? EQ.def(own) : EQ.DATA.byId[selG]; if (!d) return '';
  const r = EQ.DATA.rarity[d.rarity], it = own || { id: d.id, lv: 0 }, mx = r.maxLv, max = own && it.lv >= mx;
  const now = EQ.statsAt(it), nx = own && !max ? EQ.statsAt(it, it.lv + 1) : null, top = EQ.statsAt({ id: d.id, lv: mx });
  const slotName = EQ.DATA.slots.find((x) => x.key === d.slot).name, keys = Object.keys(top);
  // item stats: value now (> next level), and the value at max level (dim)

  const fx = d.slot === 'weapon' ? (WFX.TABLE[d.id] || WFX.TABLE.w_starter) : null;
  const fxRow = fx ? `<div class="pr fx"><i class="pd" style="background:${rgb(fx.edge)};box-shadow:0 0 6px ${rgb(fx.edge)}"></i><span>Blade effect</span><b>${FXNAME[fx.mode] || fx.mode}</b></div>` : '';
  // 11-27 user "add the base stats": the hero's totals, and what they become with this item worn (when it is not worn yet)
  const on = own && EQ.isEquipped(own), cur = !on && EQ.equipped()[d.slot], P = EQ.S.pct, S = EQ.S;
  const minus = cur ? EQ.statsAt(cur) : {}, plus = on ? {} : now, N = EQ.DATA.statShort;
  const fmtS = (k, v) => k === 'crit' ? `${+(v).toFixed(1)}%` : k === 'critDmg' ? `x${v.toFixed(2)}` : pct(k, v);
  const base = { tap: P.tap || 0, crit: S.crit * 100, critDmg: S.critMul, wp: P.wp || 0, combo: P.combo || 0, fin: P.fin || 0, coins: P.coins || 0 };
  const delta = (k) => (plus[k] || 0) - (minus[k] || 0);
  const after = (k) => k === 'crit' ? Math.min(EQ.DATA.caps?.crit ?? 60, base.crit + delta('crit')) : k === 'critDmg' ? 2 * (1 + ((P.critDmg || 0) + delta('critDmg')) / 100) : base[k] + delta(k);
  const hero = Object.keys(base).map((k) => { const ch = !on && Math.abs(delta(k)) > 1e-6, up = delta(k) > 0;
    return `<div><small>${N[k]}</small><b>${fmtS(k, base[k])}</b>${ch ? `<em class="${up ? 'up' : 'dn'}">${up ? '&#9650;' : '&#9660;'} ${fmtS(k, after(k))}</em>` : ''}</div>`; }).join('');
  // 11-27 user "no scrolling": one row per item stat = item value (> next level), max, and the hero total it gives (now > if worn)
  const heroK = (k) => k === 'critDmg' ? 'critDmg' : k;
  const rows = keys.map((k) => { const hk = heroK(k), ch = !on && Math.abs(delta(hk)) > 1e-6, up = delta(hk) > 0;
    return `<div class="pr"><i class="pd"></i><span>${EQ.DATA.statNames[k]}<small>Hero ${fmtS(hk, base[hk])} <em class="${ch ? (up ? 'up' : 'dn') : 'nil'}">${up ? '&#9650;' : '&#9660;'} ${fmtS(hk, after(hk))}</em></small></span><b>${pct(k, now[k] || 0)}</b>${nx ? `<em>&#9656; ${pct(k, nx[k] || 0)}</em>` : ''}<u>max ${pct(k, top[k] || 0)}</u></div>`; }).join('');
  const cost = own && !max ? EQ.upgradeCost(own) : 0, lk = own && !on && EQ.canWear && !EQ.canWear(own);
  const lvTxt = own ? `LEVEL ${it.lv}<small>/${mx}</small>` : 'NOT OWNED';
  const costBar = own ? (max ? '<div class="pcost">MAX LEVEL</div>' : `<div class="pcost"><i class="gem">&#9670;</i><b class="${SAVE.coins >= cost ? 'ok' : 'no'}">${fmt(SAVE.coins)}</b>/${fmt(cost)}</div>`) : `<div class="pcost how">${HOW(d)}</div>`;
  const btnA = !own ? '' : on ? (d.slot === 'weapon' ? '<button class="btn" disabled>EQUIPPED</button>' : '<button class="btn" data-act="off">UNEQUIP</button>')
    : lk ? `<button class="btn reach" disabled>REACH LV ${reqLv(d)}</button>` : '<button class="btn" data-act="on">EQUIP</button>';
  const btnB = !own ? '' : max ? '<button class="btn" disabled>MAX</button>' : `<button class="btn hot" data-act="up" ${SAVE.coins < cost ? 'data-short="1"' : ''}>UPGRADE</button>`;
  return `<div class="pcard" data-r="${r.key}" style="--c:${r.color}"><div class="phead"><div class="ptitle"><b>${d.name}</b></div></div>
    <div class="pbody"><div class="ptop"><div class="dico pico${d.slot === 'weapon' ? ' wpn' : ''}"><img src="${iconURL(d)}" alt=""></div>
      <div class="pinfo"><small class="prar">${r.name.toUpperCase()} ${slotName.toUpperCase()}</small><div class="plv">${lvTxt}</div>${d.info ? `<p>${d.info}</p>` : ''}</div></div>
    <div class="psec"><div class="psh">STATS <small>${nx ? 'now &#9656; next level' : !on ? 'hero if you wear it' : '&nbsp;'}</small></div>${rows}${fxRow}</div>
    </div>
    <div class="pfoot">${costBar}${own ? `<div class="pbtns">${btnA}${btnB}</div>` : ''}</div></div>`;
}
function bag() {
  const all = EQ.items().slice().sort((a, b) => EQ.DATA.slots.findIndex((s) => s.key === EQ.def(a).slot) - EQ.DATA.slots.findIndex((s) => s.key === EQ.def(b).slot) || EQ.def(b).rarity - EQ.def(a).rarity);
  if (v3d) { const n = Math.max(36, Math.ceil((all.length + 1) / 6) * 6); // 11-27 user: proper inventory slots - owned items, then empty boxes
    return `<div class="ibag">${all.map((it) => tile(it)).join('')}${'<div class="it void"></div>'.repeat(n - all.length)}</div>`; }
  const pad = Math.max(0, 12 - all.length) + ((6 - (Math.max(12, all.length) % 6)) % 6);
  return `<div class="ilabel">BAG &middot; ${all.length} &middot; tap an item</div><div class="ibag">${all.map((it) => tile(it)).join('')}${'<div class="it void"></div>'.repeat(pad)}</div>`;
}
// 11-27 SALVAGE tab: tap unequipped items to mark them, then SALVAGE = shards (EQ.salvage). Equipped items can't be salvaged.
let marked = new Set();
function salvBag() {
  const all = EQ.items().filter((it) => !EQ.isEquipped(it)).sort((a, b) => EQ.def(a).rarity - EQ.def(b).rarity || a.lv - b.lv);
  for (const u of [...marked]) if (!all.some((it) => it.uid === u)) marked.delete(u);
  const val = all.filter((it) => marked.has(it.uid)).reduce((t, it) => t + EQ.salvageValue(it), 0), n = Math.max(36, Math.ceil((all.length + 1) / 6) * 6);
  const tiles = all.map((it) => tile(it).replace('data-uid=', `data-sv="${it.uid}" data-x=`).replace('class="it', `class="it${marked.has(it.uid) ? ' mark' : ''}`)).join('');
  return `<div class="svbar"><button class="btn sv-com" data-svall="0">ALL COMMONS</button><button class="btn hot sv-go" data-svgo="1" ${marked.size ? '' : 'disabled'}>SALVAGE ${marked.size || ''} <span>+<i class="gem">&#9670;</i> ${fmt(val)}</span></button></div>`
    + (all.length ? '' : '<p class="svnone">Nothing to salvage. Equipped gear is never salvaged.</p>')
    + `<div class="ibag">${tiles}${'<div class="it void"></div>'.repeat(n - all.length)}</div>`;
}
function godRow() { // unowned epic / legendary gear, locked; tap = preview on the 3D hero
  const g = EQ.DATA.items.filter((d) => d.rarity >= 2 && !EQ.owned(d.id)).sort((a, b) => b.rarity - a.rarity || EQ.DATA.slots.findIndex((s) => s.key === a.slot) - EQ.DATA.slots.findIndex((s) => s.key === b.slot));
  if (!g.length) return '';
  return `<div class="ilabel">GOD TIER &middot; tap to preview</div><div class="ibag igod">${g.map((d) => { const r = EQ.DATA.rarity[d.rarity];
    return `<button class="it god${d.slot === 'weapon' ? ' wpn' : ''}${selG === d.id ? ' sel' : ''}" data-gid="${d.id}" data-r="${r.key}" style="--c:${r.color}"><img src="${iconURL(d)}" alt=""></button>`; }).join('')}</div>`;
}
function allItems() { // every item by slot, best first; owned = its real tile (EQUIP / UPGRADE), not owned = locked preview tile
  const S = EQ.DATA.slots.map((x) => x.key), owned = EQ.items();
  const all = EQ.DATA.items.slice().sort((a, b) => S.indexOf(a.slot) - S.indexOf(b.slot) || b.rarity - a.rarity);
  return `<div class="ilabel">TAP ANY ITEM TO TRY IT ON</div><div class="ibag">${all.map((d) => { const mine = owned.filter((i) => i.id === d.id).sort((a, b) => b.lv - a.lv)[0];
    if (mine) return tile(mine); const r = EQ.DATA.rarity[d.rarity];
    return `<button class="it god${d.slot === 'weapon' ? ' wpn' : ''}${selG === d.id ? ' sel' : ''}" data-gid="${d.id}" data-r="${r.key}" style="--c:${r.color}"><img src="${iconURL(d)}" alt=""></button>`; }).join('')}</div>`;
}
function shop() {
  const offers = EQ.shopOffers();
  const cards = offers.map((d) => { const r = EQ.DATA.rarity[d.rarity], s = EQ.statsAt({ id: d.id, lv: 0 }), c = EQ.price(d);
    return `<div class="offer" data-r="${r.key}" style="--c:${r.color}"><div class="dico${d.slot === 'weapon' ? ' wpn' : ''}"><img src="${iconURL(d)}" alt=""></div>
      <div class="dtx"><b>${d.name}</b><small>${r.name.toUpperCase()} ${EQ.DATA.slots.find((x) => x.key === d.slot).name.toUpperCase()}</small>
      <div class="sum">${Object.entries(s).map(([k, v]) => `${EQ.DATA.statShort[k]} ${pct(k, v)}`).join(' &middot; ')}</div></div>
      <button class="btn hot" data-buy="${d.id}" ${SAVE.coins < c ? 'data-short="1"' : ''}><i class="gem">&#9670;</i> ${fmt(c)}</button></div>`; }).join('');
  return `<div class="ishop">${cards || '<p class="none">You own everything. Well done.</p>'}<p class="snote">New offers after every titan &middot; chests drop after fights</p></div>`;
}
// 11-27 user: the SHOP tab shows only what is sold - chests with a short description, no hero. Display only for now: the buttons
// show a price and answer 'coming soon' (no purchase logic yet).
const CHESTS = [
  { k: 'energy', img: 0, name: 'Energy Chest', desc: '+5 energy: one more titan fight.', price: '<i class="gem">&#9670;</i> 200' },
  { k: 'iron', img: 1, name: 'Iron Chest', desc: 'One common or rare piece of gear.', price: '<i class="gem">&#9670;</i> 300' },
  { k: 'obsidian', img: 2, name: 'Obsidian Chest', desc: 'One common, rare or epic piece of gear.', price: '<i class="gem">&#9670;</i> 900' },
  { k: 'titan', img: 3, name: 'Titan Chest', desc: 'One rare, epic or legendary piece of gear.', price: '<i class="gem">&#9670;</i> 2,500' },
];
// 11-27 user: a FREE common chest in the shop every 8 hours (SAVE.freeChest = last claim, server clock)
const FREE_MS = 8 * 3600e3 / PASS.N; // ?pass=N game pass: cooldown / N
const freeLeft = () => Math.max(0, (SAVE.freeChest || 0) + FREE_MS - dailyNow());
const hms = (ms) => { const t = Math.ceil(ms / 1000), h = Math.floor(t / 3600), m = Math.floor(t / 60) % 60, s2 = t % 60; return `${h}:${String(m).padStart(2, '0')}:${String(s2).padStart(2, '0')}`; };
function freeCard() { const left = freeLeft(); // 11-27 user: the countdown sits ON the chest, the button is FREE / WATCH AD only
  return `<div class="cchest cfree" data-k="free"><div class="cimg"><img src="${UIDIR}/daily/chest_0.webp" alt="">${left ? `<span class="cft" data-fcd="1">${hms(left)}</span>` : ''}</div><div class="ctx"><b>Free Chest</b><p>One common piece of gear. Every 8 hours.</p></div>`
    + (!left ? '<button class="btn hot" data-free="1">FREE</button>' : adRoll() ? '<button class="btn hot cfad" data-freead="1">&#9654; WATCH AD</button>' : '<button class="btn cfwait" disabled aria-hidden="true">FREE</button>') + '</div>'; }
// 11-27 user: "and roll for another one for ads" - once per free chest, a rewarded ad opens one more common chest (native app / ?adfake=1)
const adRoll = () => typeof window.__rewardedAd === 'function' && SAVE.freeChest && SAVE.freeAdAt !== SAVE.freeChest;
function giveFree() { const id = chestItem(0, EQ); if (!id) return false; const g = EQ.grant(id); saveFn(); sfx('buy'); render(); chestReveal(EQ.def(id), g.dup); return true; }
let fcdT = 0; function fcdTick() { clearInterval(fcdT); fcdT = setInterval(() => { const b = el && el.querySelector('[data-fcd]'); if (!b || el.classList.contains('hidden')) { clearInterval(fcdT); return; }
  const l = freeLeft(); if (!l) { clearInterval(fcdT); render(); } else b.textContent = hms(l); }, 1000); }
// 11-27 user: ONE chest animation everywhere (free chest, shop chests, titan drop): closed chest (wobbles, TAP TO OPEN) -> tap -> the item
// (name, rarity, NEW!/COPY) -> tap -> done(). chestTier = which chest art (0-3), d = item def, dup = already owned.
// 11-27 user: centre the halo on the item's VISIBLE centre (old blade art is off-centre in its file): alpha centroid of the icon,
// rotated like the .wpn icon (-35deg) -> offset of .ci-fx inside the square stage
function centreHalo(ov) { const img = ov.querySelector('.ci-item'), fx = ov.querySelector('.ci-fx'); if (!img || !fx) return;
  const go = () => { try { const N = 64, cv = document.createElement('canvas'); cv.width = cv.height = N; const g = cv.getContext('2d');
    const k = Math.min(N / img.naturalWidth, N / img.naturalHeight), w = img.naturalWidth * k, h = img.naturalHeight * k; g.drawImage(img, (N - w) / 2, (N - h) / 2, w, h);
    const a = g.getImageData(0, 0, N, N).data; let sx = 0, sy = 0, sw = 0; for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const v = a[(y * N + x) * 4 + 3]; if (v > 40) { sx += x * v; sy += y * v; sw += v; } }
    if (!sw) return; let dx = sx / sw / N - .5, dy = sy / sw / N - .5;
    if (img.classList.contains('wpn')) { const r = -35 * Math.PI / 180, c = Math.cos(r), s2 = Math.sin(r); [dx, dy] = [dx * c - dy * s2, dx * s2 + dy * c]; dx *= 1.15; dy *= 1.15; }
    fx.style.left = `${(.5 + dx) * 100}%`; fx.style.top = `${(.5 + dy) * 100}%`; } catch (e) { /* tainted / no canvas: stay centred */ } };
  img.complete && img.naturalWidth ? go() : img.addEventListener('load', go, { once: true }); }
export function chestFx(d, dup, chestTier = d.rarity, title = 'CHEST', done = () => {}) {
  const R = EQ.DATA.rarity[d.rarity], ov = document.createElement('div'); ov.id = 'chestIntro'; ov.style.setProperty('--c', EQ.DATA.rarity[Math.min(3, chestTier)].color);
  ov.innerHTML = `<div class="ci-box"><img class="ci-chest" src="${UIDIR}/daily/chest_${Math.min(3, chestTier)}.webp" alt=""><b class="ci-t">${title}</b><small class="ci-s">TAP TO OPEN</small></div>`;
  for (const ev of ['pointerdown', 'touchstart']) ov.addEventListener(ev, (e) => e.stopPropagation(), { passive: true });
  let st = 0; ov.addEventListener('click', (e) => { e.stopPropagation();
    if (st === 0) { st = 1; window.S3A?.log('chest_open', { rarity: d.rarity, chest: title }); sfx(d.rarity >= 2 ? 'win' : 'buy'); ov.classList.add('open', `r${d.rarity}`); ov.style.setProperty('--c', R.color); // 11-27 rotating halo, bigger per rarity
      const sp = d.rarity >= 2 ? `<i class="ci-sparks">${'<b></b>'.repeat(d.rarity >= 3 ? 18 : 10)}</i>` : '';
      ov.querySelector('.ci-box').innerHTML = `<div class="ci-stage"><div class="ci-fx"><i class="ci-halo"></i>${d.rarity >= 1 ? '<i class="ci-halo h2"></i>' : ''}${sp}<i class="ci-flash"></i></div><img class="ci-item${d.slot === 'weapon' ? ' wpn' : ''}" src="${iconURL(d)}" alt=""></div><b class="ci-t" style="color:${R.color}">${d.name}</b><small class="ci-s">${R.name.toUpperCase()} &middot; ${dup ? 'COPY' : 'NEW!'} &middot; TAP TO CONTINUE</small>`; centreHalo(ov); return; }
    ov.remove(); done(); });
  document.body.appendChild(ov); }
const chestReveal = (d, dup) => chestFx(d, dup, 0, 'FREE CHEST');
// 11-27 user "I have enough shards, I can't open any chest": the shop chests are real now. odds = rarity weights (common, rare, epic, legendary)
const CHEST_ODDS = { iron: [80, 20, 0, 0], obsidian: [20, 55, 25, 0], titan: [0, 60, 39.5, 0.5] };
const CHEST_COST = { iron: 300, obsidian: 900, titan: 2500 }, CHEST_TIER = { iron: 1, obsidian: 2, titan: 3 };
function buyChest(k) { const c = CHEST_COST[k]; if (SAVE.coins < c) return null; const w = CHEST_ODDS[k]; let t = Math.random() * w.reduce((a, b) => a + b, 0), r = 0;
  for (; r < 3 && (t -= w[r]) > 0; r++); const id = chestItem(r, EQ); if (!id) return null; SAVE.coins -= c; const g = EQ.grant(id); saveFn(); return { d: EQ.def(id), dup: g.dup }; }
function chestShop() {
  const G = '<i class="gem">&#9670;</i>';
  // 11-27 IAP: in the store app the packs are real (store's local price, data-pack = product id); browsers keep the placeholders
  const live = IAP.enabled() && IAP.status() !== 'offline', esc = (s) => String(s).replace(/[&<>"]/g, (c) => `&#${c.charCodeAt(0)};`);
  const packBtn = (x, p) => live ? `<button class="btn hot" data-pack="${p.sku}">${esc(p.price)}</button>` : '<button class="btn" disabled>NOT AVAILABLE</button>'; // 11-28 user: no in-app purchase = the card is disabled
  const shards = IAP.hidden() ? '' : `<div class="csec">SHARDS</div><div class="cgrid">${SHARDS.map((x) => { const p = IAP.pack(x.sku); return `<div class="cchest cpack${live ? '' : ' off'}" data-k="${p.sku}"><div class="cimg"><img src="${INK ? `${UIDIR}/kit/shards_${x.pile}.webp` : `${UIDIR}/daily/gems_${x.img}.webp`}" alt=""></div>
    <div class="ctx"><b>${G} ${p.n.toLocaleString('en-US')}</b>${x.tag ? `<p>${x.tag}</p>` : ''}</div>${packBtn(x, p)}</div>`; }).join('')}</div>
    <p class="snote">${live ? 'Shards are added to your balance right away' : 'Purchases are not available here'}</p>`;
  if (freeLeft()) setTimeout(fcdTick, 0);
  return `<div class="cshop"><div class="csec">CHESTS</div><div class="cgrid">${freeCard()}${CHESTS.map((c) => `<div class="cchest" data-k="${c.k}"><div class="cimg"><img src="${UIDIR}/daily/chest_${c.img}.webp" alt=""></div>
    <div class="ctx"><b>${c.name}</b><p>${c.desc}</p></div><button class="btn hot" data-chest="${c.k}">${c.price}</button></div>`).join('')}</div>
    ${shards}</div>`;
}
// 11-27 user: shard packs under the chests, standard app-store price tiers. Store apps: real IAP (iap.js, ids shards_pack1..4);
// browsers: placeholders, display only. Amounts + placeholder prices live in iap.js PACKS (one source); here only the art + tag.
// 11-27 user: ink mode shows the rune-veined rock shards, four growing piles (art/ui_ink/kit/shards_1..4, tools/make_ui_ink.py shards)
const SHARDS = [{ sku: 'shards_pack1', img: 1, pile: 1 }, { sku: 'shards_pack2', img: 2, pile: 2 }, { sku: 'shards_pack3', img: 3, pile: 3, tag: 'Popular' }, { sku: 'shards_pack4', img: 3, pile: 4, tag: 'Best value' }];
function render() {
  $('invCoins').textContent = fmt(SAVE.coins);
  el.querySelectorAll('.itabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  const L = EQ.DATA.slots.filter((s) => s.side === 'L'), R = EQ.DATA.slots.filter((s) => s.side === 'R');
  const doll = `<div class="doll"><div class="dcol">${L.map(slotTile).join('')}</div>${portrait()}<div class="dcol">${R.map(slotTile).join('')}</div></div>`;
  // 11-27 user: the worn gear stands LEFT and RIGHT of the 3D hero (top area, .g3doll outside the sheet); the sheet = inventory only
  if (!el.querySelector('.g3win')) { const w = document.createElement('div'); w.className = 'g3win'; el.appendChild(w); } // 11-27 user: full gear panel with a window onto the live hero
  let dl = el.querySelector('.g3doll'); if (!dl) { dl = document.createElement('div'); dl.className = 'g3doll'; el.appendChild(dl); }
  dl.innerHTML = v3d && tab === 'gear' ? `<div class="dcol">${L.map(slotTile).join('')}</div><div class="dcol">${R.map(slotTile).join('')}</div>` : '';
  if (v3d && tab === 'gear') { // 3D gear view: no portrait (the real hero is up in the scene); bag first, card under it
    // 11-27 user: PREVIEW tab - BAG (what you own) | ALL (every item; not owned = dimmed + lock, tap = worn by the hero to see it)
    const B = el.querySelector('.ibody'), y = B.dataset.gt === gtab ? B.scrollTop : 0, own = new Set(EQ.items().map((i) => i.id));
    const tabs = `<div class="gtabs"><button data-gt="bag" class="${gtab === 'bag' ? 'on' : ''}">BAG <small>${EQ.items().length}</small></button><button data-gt="all" class="${gtab === 'all' ? 'on' : ''}">ALL ITEMS <small>${own.size}/${EQ.DATA.items.length}</small></button></div>`;
    const stabs = `<div class="gtabs"><button data-gt="bag" class="${gtab !== 'salv' ? 'on' : ''}">BAG <small>${EQ.items().length}</small></button><button data-gt="salv" class="${gtab === 'salv' ? 'on' : ''}">SALVAGE</button></div>`; void tabs;
    void stabs; const hd = el.querySelector('.ihead'); let ht = hd.querySelector('.htabs'); /* 11-27 user: GEAR | SALVAGE are the tabs, on top in the header */
    if (!ht) { ht = document.createElement('div'); ht.className = 'htabs'; hd.querySelector('.ititle').after(ht); }
    ht.innerHTML = `<button data-gt="bag" class="${gtab !== 'salv' ? 'on' : ''}">GEAR</button><button data-gt="salv" class="${gtab === 'salv' ? 'on' : ''}">SALVAGE</button>`;
    B.innerHTML = gtab === 'salv' ? salvBag() : bag(); B.dataset.gt = gtab; B.scrollTop = y;
    // 11-27 user: the item card is a POPUP, only after tapping an item (worn slot, bag or god tier); tap outside / X closes it
    let pp = el.querySelector('.g3pop'); if (!pp) { pp = document.createElement('div'); pp.className = 'g3pop'; el.appendChild(pp); }
    const any = sel != null || selG; pp.classList.toggle('on', !!any); pp.classList.add('prev'); /* 11-27 user: one card for every item (BAG or ALL): it sits on the sheet, the hero stays in view */ pp.innerHTML = any ? `<div class="g3pcard"><button class="g3px" aria-label="Close"></button>${popCard()}</div>` : '';
    const it = sel != null && EQ.byUid(sel); EQ.setPreview(selG || (it && !EQ.isEquipped(it) ? it.id : null)); return; }
  EQ.setPreview(null); el.querySelector('.g3pop')?.classList.remove('on');
  el.querySelector('.ibody').innerHTML = tab === 'gear'
    ? `<div class="ic1">${doll}${statRow()}</div><div class="ic2">${detail()}${bag()}</div>`
    : chestShop();
}
function showCard() { // (3D gear view: the card is a popup now, nothing to scroll)
  if (v3d || !v3d) return; const b = el.querySelector('.ibody'), d = b && b.querySelector('.idet'); if (!d) return;
  const top = d.offsetTop - b.offsetTop - 6, bot = top + d.offsetHeight + 12; if (top < b.scrollTop || bot > b.scrollTop + b.clientHeight) b.scrollTo({ top: Math.max(0, Math.min(top, bot - b.clientHeight)), behavior: 'smooth' });
}
function flashCoins() { const c = el.querySelector('.icoin'); c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }
function onClick(e) {
  if (e.target.classList.contains('g3pop') || e.target.closest('.g3px')) { sfx('click'); sel = null; selG = null; return render(); } // popup: backdrop / X
  if (el.classList.contains('tabscr') && e.target.closest('.ititle')) { sfx('click'); return close(); } // 11-27 user: '< GEAR' - the word is part of the back button
  const t = e.target.closest('button'); if (!t) return;
  if (t.classList.contains('iclose') || t.classList.contains('hback')) { sfx('click'); return close(); } // 11-27 user: '< GEAR' back arrow closes
  if (t.dataset.tab) { sfx('click'); tab = t.dataset.tab; return render(); }
  if (t.dataset.gt) { sfx('click'); gtab = t.dataset.gt; sel = null; selG = null; marked.clear(); return render(); } // BAG | SALVAGE
  if (t.dataset.sv) { sfx('click'); const u = +t.dataset.sv; marked.has(u) ? marked.delete(u) : marked.add(u); return render(); }
  if (t.dataset.svall) { sfx('click'); for (const it of EQ.items()) if (!EQ.isEquipped(it) && EQ.def(it).rarity === 0) marked.add(it.uid); return render(); }
  if (t.dataset.svgo) { if (!marked.size) return; const got = EQ.salvage([...marked]); marked.clear(); sfx('buy'); flashCoins(); coinHud(); return render(); }
  if (t.dataset.gid) { sfx('click'); selG = t.dataset.gid; sel = null; render(); return showCard(); } // GOD TIER: preview only
  if (t.dataset.uid) { sfx('click'); sel = +t.dataset.uid; selG = null; tab = 'gear'; render(); return showCard(); }
  if (t.dataset.slot) { sfx('deny'); return; }
  if (t.dataset.pack) { // 11-27 IAP (store app only): the store's own purchase sheet; shards granted on "approved" (iap.js)
    sfx('click'); if (t.disabled) return; t.disabled = true;
    IAP.buy(t.dataset.pack).then((p) => { t.disabled = false; if (p) { sfx('buy'); flashCoins(); render(); } });
    return; }
  if (t.dataset.free) { if (freeLeft()) { sfx('deny'); return; } SAVE.freeChest = dailyNow(); if (!giveFree()) sfx('deny'); return; } // 11-27 free common chest
  if (t.dataset.freead) { if (!adRoll() || t.disabled) return; t.disabled = true; sfx('click');
    Promise.resolve(window.__rewardedAd('freechest')).catch(() => false).then((ok) => { t.disabled = false; if (!ok) return render(); SAVE.freeAdAt = SAVE.freeChest; giveFree(); }); return; }
  if (t.dataset.chest === 'energy') { // 11-27 user: buy energy with shards (200 = full refill)
    const cost = 200, s = EN.tick(); const nope = () => { sfx('deny'); t.classList.remove('soon'); void t.offsetWidth; t.classList.add('soon'); };
    if (s.v >= s.max) { t.dataset.msg = 'ENERGY FULL'; return nope(); }
    if (SAVE.coins < cost) { t.dataset.msg = 'NOT ENOUGH SHARDS'; flashCoins(); return nope(); }
    SAVE.coins -= cost; EN.add(EN.COST); /* 11-27 user: 200 shards = +5 energy */ sfx('buy'); flashCoins(); coinHud(); window.dispatchEvent(new Event('energychange')); return render(); }
  if (CHEST_COST[t.dataset.chest]) { const k = t.dataset.chest, r = buyChest(k); if (!r) { sfx('deny'); flashCoins(); t.classList.remove('soon'); void t.offsetWidth; t.classList.add('soon'); return; }
    sfx('buy'); flashCoins(); coinHud(); render(); chestFx(r.d, r.dup, CHEST_TIER[k], `${k.toUpperCase()} CHEST`); return; }
  if (t.dataset.chest) { sfx('deny'); t.classList.remove('soon'); void t.offsetWidth; t.classList.add('soon'); return; } // display only for now
  if (t.dataset.buy) { const r = EQ.buy(t.dataset.buy); if (!r) { sfx('deny'); flashCoins(); return; } sfx('buy'); sel = r.it.uid; tab = 'gear'; flashCoins(); return render(); }
  const it = sel != null && EQ.byUid(sel); if (!it) return;
  if (t.dataset.act === 'up') { const r = EQ.upgrade(it); if (!r.ok) { sfx('deny'); flashCoins(); return; } sfx('buy'); flashCoins();
    const ic = el.querySelector('.idet .dico'); ic && ic.classList.add('lvup'); }
  // 11-27 user: EQUIP / UNEQUIP closes the card so the hero is visible wearing it
  if (t.dataset.act === 'on') { if (EQ.equip(it) === false) { sfx('deny'); return; } sfx('buy'); if (v3d) { sel = null; selG = null; render(); } }
  if (t.dataset.act === 'off') { EQ.unequip(EQ.def(it).slot); sfx('click'); if (v3d) { sel = null; selG = null; render(); } }
}
// minimal results (11-26): the chest drop as a compact icon chip; tapping it opens the gear screen (main.js)
export function lootChip(drop) {
  const d = EQ.def(drop.it), r = EQ.rarity(drop.it);
  return `<button class="lchip" data-r="${r.key}" style="--c:${r.color}" aria-label="${d.name}"><img class="${d.slot === 'weapon' ? 'wpn' : ''}" src="${iconURL(d)}" alt=""><b>${drop.dup ? `+1 LV` : 'NEW!'}</b></button>`;
}
// results screen: the chest row (call after EQ.rollDrop)
export function lootRow(drop) {
  if (!drop) return '';
  const d = EQ.def(drop.it), r = EQ.rarity(drop.it);
  return `<div class="rw loot" data-r="${r.key}" style="--c:${r.color}"><span><img class="lico${d.slot === 'weapon' ? ' wpn' : ''}" src="${iconURL(d)}" alt="">CHEST: <b class="ln">${d.name}</b> <small>${r.name.toUpperCase()}</small></span><b>${drop.dup ? `+1 LV (${drop.it.lv})` : 'NEW!'}</b></div>`;
}
