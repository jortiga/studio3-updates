// 11-27 CLOTH CAPE (ink style; equipment.js imports this file with ?cloth=1|2 or ?head=1). v2 (user: "fix cape, make it like
// slashed, like smoke, smoothing"): a SLASHED cape whose strips dissolve into ink smoke, silky motion; idle sway matters most,
// attacks only need it attached.
// - Physics: 4 strips (verlet point chains, 10 points), roots stacked at the neck (data/hero_rig_ink.json poses.<pose>.neck /
//   tail, tools/hero_neck.py), fanned around the painted tail direction; gravity + gusty back-wind + a travelling ripple,
//   distance + push-only bend constraints, damping, fixed 1/60 step, kept in the hero sprite's plane (2D look).
// - Smooth: each chain is drawn through a Catmull-Rom curve (3 rows per segment), the painted tail direction is eased between
//   poses (no snap when a strike pose points its tail up / down), facing flips mirror the chain instead of swinging it through the
//   body, part of the anchor motion is carried (`follow`) so fast hops don't leave it hanging straight down, a velocity cap,
//   and a hidden -> visible hero (teleport) carries the old shape along instead of resetting it.
// - Look: one procedural strip atlas (4 columns = 4 strips): crimson cloth with folds, torn edges that get more ragged toward
//   the tip, blade slits + burnt holes, the tip thinning into wispy fingers. The hero shader (fx.js spriteMat + capeTint + ink
//   grade) is patched: below `smS` of the strip length the cloth darkens to crimson-black smoke, its alpha dissolves through a
//   flowing two-octave noise and the texture lookup drifts (smoke flow); the ink outline fades out in the smoke.
// - Wisps: a pool of 16 soft hooked smoke tendrils (like the SMOKE head's) shed from the strip tips, drifting back with the wind,
//   curling and fading (one more mesh).
// Cost: 2 draw calls (strips + wisps), both BufferGeometries rewritten in place, no per-frame allocation. Cloak tint: capeTint
// re-hues the crimson, and the smoke / wisps take the cloak colour too. Rule (user 11-27): the cape always shows (no Cloak =
// default crimson).
// v3 (user: "cape different widths and more soft"): broad main panel + medium + 2 narrow ribbons, each with its own widest point,
// tip width and an uneven swell along it; feathered alpha edges, smoother / shallower tatter, lighter ink edge + outline (`ol`),
// softer smoke dissolve; motion: more damping, gentler follow / root pull / pose easing (`ease`), slower gusts + ripple (`sway`),
// softer bend, 2 constraint passes.
// Dev: window.__cloth (equipment.js) = this C object: live-tweak len / grav / wind / gust / damp / bend / follow / ripple /
// smoke / wispRate / w0 / wMax / w1 (tip width scale) / puff / sway / ol / ease / rootK; C.ms / C.msN = cost.
import * as THREE from 'three';

const N = 10, NS = N - 1, SUB = 3, NR = NS * SUB + 1, STEP = 1 / 60, COLS = 4, K = 16, WS = 10; // points, segments, rows / segment, render rows, atlas columns, wisps, wisp stride
// strips: len / width (hero heights), angle offset from the painted tail dir (rad, + = droops more), wind share, gravity share, phase, root
// offset along the sprite's up axis (hero heights; stacked along the neck), atlas column. Drawn in this order (last on top).
// v3 (user: "different widths and more soft"): one broad main panel, one medium, two narrow ribbons; per strip width profile:
// pk = where it is widest (0-1 of the length), tip = tip width / widest, wa / wf = amplitude / frequency of the width swell along it
// (so no two strips run as parallel bands), pf = share of the smoke puff at the tip.
const TAILS = [{ len: .5, w: .42, pk: .14, tip: .32, wa: .24, wf: 3.6, pf: .5, ang: .74, wk: .62, gk: 1.35, ph: 3.9, ro: -.02, col: 3 }, // narrow, low + droopy
  { len: .82, w: 1.5, pk: .32, tip: .7, wa: .13, wf: 2.1, pf: 1, ang: -.06, wk: .9, gk: .95, ph: 1.3, ro: .004, col: 1 }, // broad main panel
  { len: .63, w: .95, pk: .2, tip: .5, wa: .2, wf: 3, pf: .8, ang: .36, wk: .78, gk: 1.15, ph: 2.6, ro: -.01, col: 2 }, // medium
  { len: .7, w: .5, pk: .1, tip: .36, wa: .26, wf: 4.4, pf: .55, ang: -.55, wk: 1.1, gk: .74, ph: 0, ro: .014, col: 0 }]; // narrow ribbon, streams high
const R = TAILS.length;
const C = { mesh: null, wisp: null, geo: null, pos: null, wgeo: null, acc: 0, t: 0, U: 0, has: false, init: false, ax: 0, ay: 0, az: 0, sx: 1, tdx: -.8, tdy: .5,
  ms: 0, msN: 0, idle: 1, spawn: 0, wn: 0, live: 0,
  len: 1.12, w0: .026, wMax: .05, w1: 1, puff: .8, // length scale, root / widest half widths (hero heights), tip width scale, tip puff
  grav: 4.2, wind: 5.6, gust: 2, damp: .962, bend: .16, rootK: .32, follow: .5, ripple: 1.8, smoke: .45, wispRate: 6, sway: .65, ol: .5, // v3: softer, lazier
  ease: 4,
  P: new Float32Array(R * N * 3), PP: new Float32Array(R * N * 3), S: new Float32Array(R * NR * 3), W: new Float32Array(K * WS) };
export const cloth = C;
const _n = new THREE.Vector3(), _r = new THREE.Vector3(), _u = new THREE.Vector3(), _a = new THREE.Vector3(), _d = new THREE.Vector3();
const SMOKE = new THREE.Color(.11, .025, .04); // crimson-black ink smoke (post-grade colour)

const hs = (x, y) => { const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return s - Math.floor(s); };
const vn = (x, y) => { const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, a = hs(xi, yi), b = hs(xi + 1, yi), c = hs(xi, yi + 1), e = hs(xi + 1, yi + 1);
  const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy); return a + (b - a) * sx + (c - a) * sy + (a - b - c + e) * sx * sy; };
const sst = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// slashed crimson strip atlas: column k = strip k, x = across, y = root (top) -> tip (bottom)
function strip() {
  const CW = 64, W = CW * COLS, H = 512, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d'), im = g.createImageData(W, H), d = im.data;
  // per column: blade slits [f centre, slope, from-edge side (-1 / 1), reach across] + burnt holes [u, f, r]
  const SL = [[[.42, .5, -1, .3]], [[.36, -.45, 1, .32]], [[.5, -.6, 1, .28]], [[.6, .4, -1, .3]]];
  const HO = [[], [[.4, .46, .06], [.56, .68, .045]], [[.42, .3, .055]], []]; // narrow ribbons (cols 0 / 3): no holes
  for (let y = 0; y < H; y++) { const f = y / (H - 1);
    for (let k = 0; k < COLS; k++) { const torn = sst(.22, .95, f), cx = .5 + (vn(f * 3 + k * 5, 1 + k) - .5) * .1 * torn;
      // v3 softer tatter: lower-frequency, shallower bites (was f * 14-21, depth .2)
      const hl = .4 + (vn(f * 7 + k * 9, 3 + k) - .5) * .05 - torn * Math.pow(vn(f * 9 + k * 7, 9 + k), 2) * .14; // ragged left edge, bites toward the tip
      const hr = .4 + (vn(f * 8 + k * 4, 5 + k) - .5) * .05 - torn * Math.pow(vn(f * 8.5 + k * 3, 13 + k), 2) * .14;
      for (let x = 0; x < CW; x++) { const u = x / (CW - 1), i = (y * W + k * CW + x) * 4, du = u - cx, hw = Math.max(.02, du < 0 ? hl : hr);
        let a = sst(0, 1, (hw - Math.abs(du)) * 14); // feathered edge (v2: hard * 60)
        if (f < .03) a *= f / .03;
        // tip: wispy fingers (stretched streak noise) that thin out toward the end
        // tip: the cloth gives way to soft smoke streaks (alpha from stretched noise, wider and fading toward the end)
        const smk = sst(.52, .78, f);
        if (smk > 0) { const st = vn(u * 6 + k * 3, f * 3) * .6 + vn(u * 15 + k, f * 8) * .4, as = Math.min(1, Math.max(0, (st - .2 - (f - .55) * .55) * 2.6)) * Math.min(1, Math.max(0, (.47 - Math.abs(u - .5)) * 9));
          a = a + (as - a) * smk; }
        let burn = 0; // dark rim around cuts / holes
        if (0) for (const [sf, sl, side, reach] of SL[k]) { const along = du * side; if (along < hw - reach) continue; // slit enters from one edge
          const gw = .004 + .016 * (along - (hw - reach)) / reach, dd = Math.abs(f - (sf + du * sl * .25)); if (dd < gw) a = 0; else if (dd < gw + .008) burn = Math.max(burn, 1 - (dd - gw) / .008); } // tapered blade cut from the edge
        for (const [hx, hy, hr2] of HO[k]) { const ox = u - hx, oy = (f - hy) * 4.5, q = Math.hypot(ox, oy) / (hr2 * (.75 + .5 * vn(Math.atan2(oy, ox) * 2 + 9 + k, hx * 9))); if (q < 1) a *= sst(.8, 1, q); else if (q < 1.6) burn = Math.max(burn, (1.6 - q) / .6 * .7); }
        const ed = Math.min(1, Math.max(0, 1 - (hw - Math.abs(du)) * 9)) * .6; // soft, lighter ink edge
        const fold = .72 + .28 * Math.sin(u * Math.PI * 2.2 + f * 9 + vn(f * 5, u * 2 + k) * 2.4), grain = .9 + vn(u * 40 + k * 50, f * 220) * .2;
        const sh = .6 + .4 * Math.min(1, f * 4); // root sits in the neck's shadow
        const dk = 1 - .55 * sst(.45, .8, f); // darkens toward the smoke tip
        let r = 178 * fold * grain * sh * dk, gg = 24 * fold * grain * sh * dk, b = 44 * fold * grain * sh * dk;
        const e2 = Math.max(ed * (1 - smk), burn * .9); r *= 1 - e2 * .82; gg *= 1 - e2 * .8; b = b * (1 - e2 * .7) + e2 * 8;
        d[i] = r; d[i + 1] = gg; d[i + 2] = b; d[i + 3] = a * 255; } } }
  g.putImageData(im, 0, 0); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.NoColorSpace; t.needsUpdate = true; return t;
}
// soft hooked smoke tendril (white, alpha = shape): thick at u 0 (rear), thin hooked tip at u 1 (leads the drift)
function wispTex() {
  const W = 128, H = 64, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
  const draw = (y0, amp, w0, hook, al) => { const top = [], bot = [];
    for (let i = 0; i <= 24; i++) { const s = i / 24, x = 10 + 108 * s, y = y0 - amp * Math.sin(s * Math.PI * .6) + hook * Math.pow(sst(.78, 1, s), 2), w = w0 * Math.pow(1 - s, .8) + .8;
      top.push(x, y - w); bot.push(x, y + w); }
    g.beginPath(); g.moveTo(top[0], top[1]); for (let i = 2; i < top.length; i += 2) g.lineTo(top[i], top[i + 1]);
    for (let i = bot.length - 2; i >= 0; i -= 2) g.lineTo(bot[i], bot[i + 1]); g.closePath();
    g.fillStyle = `rgba(255,255,255,${al})`; g.shadowColor = 'rgba(255,255,255,.8)'; g.shadowBlur = 8; g.fill(); };
  draw(38, 20, 11, 12, .85); draw(44, 10, 5, 8, .5);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.NoColorSpace; t.needsUpdate = true; return t;
}

const NOISE = `uniform float smT; uniform float smS; uniform vec3 smC; uniform float smO;
float clH(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float clN(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f); return mix(mix(clH(i), clH(i + vec2(1., 0.)), f.x), mix(clH(i + vec2(0., 1.)), clH(i + vec2(1., 1.)), f.x), f.y); }
`;
// patch the (already ink-graded) hero sprite shader: smoke flow + dissolve + colour on the strip tips
function smokeShader(mat) {
  const u = mat.uniforms; u.smT = { value: 0 }; u.smS = { value: C.smoke }; u.smC = { value: SMOKE }; u.smO = { value: C.ol };
  let fs = mat.fragmentShader; const cape = fs.includes('uniform vec4 capeT;');
  fs = fs.replace('float cm = smoothstep(.3, .48, c.r - max(c.g, c.b)) * capeT.w;', 'float cm = capeT.w;') // the whole strip is cape (dark folds + smoke too)
    .replace('varying float vD;\n', 'varying float vD;\n' + NOISE)
    .replace('void main(){ vec4 c = texture2D(map, vUv);', `void main(){ float sf = 1. - vUv.y, sm = smoothstep(smS, 1., sf);
  vec2 sw = vec2(clN(vec2(vUv.x * 14., sf * 4. - smT * .7)) - .5, clN(vec2(vUv.x * 10. + 7., sf * 3.5 - smT * .5)) - .5) * sm;
  vec4 c = texture2D(map, vUv + sw * vec2(.03, .07));`)
    .replace('float ol = clamp(m - c.a, 0., 1.) * olA;', 'float ol = clamp(m - c.a, 0., 1.) * olA * smO * (1. - sm);') // v3: lighter ink line
    .replace('float a = c.a * alpha;', `float a = c.a * alpha;
  { float sn = clN(vec2(vUv.x * 12., sf * 5. - smT * .9)) * .7 + clN(vec2(vUv.x * 34., sf * 13. - smT * 1.6)) * .3;
    a *= smoothstep(0., 1., clamp((sn + .55 - sm * 1.1) * 1.4, 0., 1.)) * (1. - sm * sm * .5);
    vec3 sc = ${cape ? 'mix(smC, capeT.rgb * .14 + .015, capeT.w)' : 'smC'};
    col = mix(col, sc, smoothstep(0., .75, sm) * .92); }`);
  mat.fragmentShader = fs; mat.needsUpdate = true;
}

// ctx: { scene, spriteMat }; prep(mat) = equipment.js capeTint + ink grade
export function initCloth(ctx, prep) {
  const geo = new THREE.BufferGeometry(), pos = new Float32Array(R * NR * 2 * 3), uv = new Float32Array(R * NR * 2 * 2), idx = [];
  for (let t = 0; t < R; t++) { const u0 = TAILS[t].col / COLS, u1 = (TAILS[t].col + 1) / COLS;
    for (let i = 0; i < NR; i++) { const q = t * NR + i, v = 1 - i / (NR - 1);
      uv.set([u0, v, u1, v], q * 4); if (i < NR - 1) { const a = q * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); } } }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage)); geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); geo.setIndex(idx);
  const mat = ctx.spriteMat(strip(), { glow: 0, fogNear: 999, fogFar: 9999, outline: true });
  mat.depthTest = false; mat.depthWrite = false; mat.uniforms.olW.value.set(.008, .003); prep?.(mat); smokeShader(mat);
  const m = new THREE.Mesh(geo, mat); m.frustumCulled = false; m.visible = false; ctx.scene.add(m);
  // smoke wisps: K quads, world-space positions + per-vertex alpha
  const wg = new THREE.BufferGeometry(), wp = new Float32Array(K * 12), wa = new Float32Array(K * 4), wuv = new Float32Array(K * 8), wi = [];
  for (let k = 0; k < K; k++) { wuv.set([0, 0, 1, 0, 0, 1, 1, 1], k * 8); const a = k * 4; wi.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  wg.setAttribute('position', new THREE.BufferAttribute(wp, 3).setUsage(THREE.DynamicDrawUsage)); wg.setAttribute('aA', new THREE.BufferAttribute(wa, 1).setUsage(THREE.DynamicDrawUsage));
  wg.setAttribute('uv', new THREE.BufferAttribute(wuv, 2)); wg.setIndex(wi);
  const wm = new THREE.ShaderMaterial({ transparent: true, depthTest: false, depthWrite: false, side: THREE.DoubleSide,
    uniforms: { map: { value: wispTex() }, col: { value: new THREE.Color().copy(SMOKE) }, alpha: { value: 1 } },
    vertexShader: 'attribute float aA; varying vec2 vUv; varying float vA; void main(){ vUv = uv; vA = aA; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }',
    fragmentShader: 'uniform sampler2D map; uniform vec3 col; uniform float alpha; varying vec2 vUv; varying float vA; void main(){ float a = texture2D(map, vUv).a * vA * alpha; if (a < .01) discard; gl_FragColor = vec4(col * (1.5 - .7 * vUv.x), a); }' });
  const w = new THREE.Mesh(wg, wm); w.frustumCulled = false; w.visible = false; ctx.scene.add(w);
  Object.assign(C, { mesh: m, geo, pos, wisp: w, wgeo: wg }); return C;
}

// direction of strip t in world (unit, into out): eased painted tail dir rotated by the strip's angle offset, mirrored by facing
function tailDir(t, sx, out) {
  const ang = TAILS[t].ang * sx, ca = Math.cos(ang), sa = Math.sin(ang); // + ang droops the tail (CCW for a tail streaming left)
  const ix = C.tdx * sx, iy = -C.tdy, rx = ix * ca - iy * sa, ry = ix * sa + iy * ca; // image px (y down) -> screen (y up), rotated
  out.copy(_r).multiplyScalar(rx).addScaledVector(_u, ry); return out.normalize();
}
function reset(U, sx) { // hang along the painted tail direction
  const { P, PP } = C;
  for (let t = 0; t < R; t++) { tailDir(t, sx, _d); const seg = C.len * TAILS[t].len * U / NS, ro = TAILS[t].ro * U;
    for (let i = 0; i < N; i++) { const j = (t * N + i) * 3;
      P[j] = PP[j] = C.ax + _u.x * ro + _d.x * seg * i; P[j + 1] = PP[j + 1] = C.ay + _u.y * ro + _d.y * seg * i; P[j + 2] = PP[j + 2] = C.az + _u.z * ro + _d.z * seg * i; } }
}

// s = the main hero sprite (bottom-anchored 1x1 plane), pose = rig pose record (neck / tail / k), mu = its uniforms, idle = idle frame
export function updateCloth(dt, s, pose, mu, idle) {
  const m = C.mesh; if (!m) return;
  const t0 = performance.now(), { P, PP } = C;
  const img = mu.map.value?.image, on = s.visible && pose?.neck && img && mu.alpha.value > .01;
  m.visible = !!on;
  if (!on) { C.has = false; wisps(dt, 0, 0, false); C.ms += performance.now() - t0; C.msN++; return; } // wisps already out keep fading
  s.updateMatrixWorld();
  const sx = Math.sign(s.scale.x) || 1;
  _a.set(pose.neck[0] - .5, 1 - pose.neck[1], 0); s.localToWorld(_a); // neck in world
  _n.set(0, 0, 1).applyQuaternion(s.quaternion); _r.set(1, 0, 0).applyQuaternion(s.quaternion); _u.set(0, 1, 0).applyQuaternion(s.quaternion);
  const U = Math.abs(s.scale.y) * 1221 / (img.height * (pose.k || 1)); // hero height in world (idle-equivalent; 1221 = idle.webp px)
  // painted tail dir; strike poses lean it toward the idle 'back and down' (pose3 dive paints it straight up = an ugly spike)
  const pk = idle ? 0 : .65, tx = (pose.tail?.[0] ?? -.8) * (1 - pk) - .85 * pk, ty = (pose.tail?.[1] ?? .5) * (1 - pk) + .5 * pk;
  if (!C.init) { C.ax = _a.x; C.ay = _a.y; C.az = _a.z; C.U = U; C.sx = sx; C.tdx = tx; C.tdy = ty; reset(U, sx); C.init = C.has = true; }
  const kt = Math.min(1, dt * C.ease); C.tdx += (tx - C.tdx) * kt; C.tdy += (ty - C.tdy) * kt; // eased pose tail dir: no snap on pose switches
  if (sx !== C.sx) { // facing flip: mirror the chain across the old anchor (it does not swing through the body)
    for (let q = 0; q < R * N; q++) { const j = q * 3;
      let e = (P[j] - C.ax) * _r.x + (P[j + 1] - C.ay) * _r.y + (P[j + 2] - C.az) * _r.z; P[j] -= 2 * e * _r.x; P[j + 1] -= 2 * e * _r.y; P[j + 2] -= 2 * e * _r.z;
      e = (PP[j] - C.ax) * _r.x + (PP[j + 1] - C.ay) * _r.y + (PP[j + 2] - C.az) * _r.z; PP[j] -= 2 * e * _r.x; PP[j + 1] -= 2 * e * _r.y; PP[j + 2] -= 2 * e * _r.z; }
    C.sx = sx; }
  const dx = _a.x - C.ax, dy = _a.y - C.ay, dz = _a.z - C.az, dl = Math.hypot(dx, dy, dz), jump = !C.has || dl > 1.2 * U || Math.abs(U / C.U - 1) > .35;
  { // carry: teleport / reappear = the whole shape moves with the anchor (+ a small flick back toward the old spot); normal motion =
    // rescale + carry `follow` of the anchor move (the rest lags = follow-through, never a chain hanging straight down after a hop)
    const k = U / C.U, fo = jump ? 1 : C.follow + (1 - C.follow) * .95 * sst(.06 * U, .35 * U, dl), fl = jump && dl > 1e-6 ? .008 * U / dl : 0; // fast moves (hop / descent) carry more
    const ox = C.ax, oy = C.ay, oz = C.az;
    for (let q = 0; q < R * N; q++) { const j = q * 3, f = (q % N) / NS, vx = P[j] - PP[j], vy = P[j + 1] - PP[j + 1], vz = P[j + 2] - PP[j + 2];
      P[j] = ox + (P[j] - ox) * k + dx * fo; P[j + 1] = oy + (P[j + 1] - oy) * k + dy * fo; P[j + 2] = oz + (P[j + 2] - oz) * k + dz * fo;
      if (jump) { PP[j] = P[j] + dx * fl * f; PP[j + 1] = P[j + 1] + dy * fl * f; PP[j + 2] = P[j + 2] + dz * fl * f; }
      else { PP[j] = P[j] - vx * k; PP[j + 1] = P[j + 1] - vy * k; PP[j + 2] = P[j + 2] - vz * k; } }
  }
  C.has = true; C.ax = _a.x; C.ay = _a.y; C.az = _a.z; C.U = U;
  C.idle += ((idle ? 1 : 0) - C.idle) * Math.min(1, dt * 3); // idle: full wind; strike poses: calmer (the hero barely shows)
  C.acc = Math.min(C.acc + Math.min(dt, .1), STEP * 3); const h2 = STEP * STEP, vmax = .04 * U, sw = C.sway;
  while (C.acc >= STEP) { C.acc -= STEP; C.t += STEP; const T = C.t;
    for (let t = 0; t < R; t++) { const TL = TAILS[t], o = t * N, seg = C.len * TL.len * U / NS, Tp = T + TL.ph, ro = TL.ro * U;
      const rx = _a.x + _u.x * ro, ry = _a.y + _u.y * ro, rz = _a.z + _u.z * ro;
      // gusts: slow swell + medium sway + a little flutter; idle breathes with them, strikes get a steady streaming wind
      // (sway scales the frequencies: v3 lazier idle)
      const gust = (C.wind + C.gust * C.idle * (.6 * Math.sin(Tp * .9 * sw) + .3 * Math.sin(Tp * 2.3 * sw + 1.7) + .1 * Math.sin(Tp * 5.3 * sw))) * TL.wk;
      const j0 = o * 3; P[j0] = PP[j0] = rx; P[j0 + 1] = PP[j0 + 1] = ry; P[j0 + 2] = PP[j0 + 2] = rz;
      for (let i = 1; i < N; i++) { const j = (o + i) * 3, f = i / NS;
        const rip = Math.sin(Tp * 5.2 * sw - i * .55) * (.55 + .45 * Math.sin(Tp * 1.1 * sw)) * f * f; // travelling ripple, grows toward the tip
        const ax = -sx * gust * (.35 + .65 * f) * U, ay = (-C.grav * TL.gk + rip * C.ripple * (.5 + .5 * C.idle) + gust * .2) * U;
        let vx = (P[j] - PP[j]) * C.damp, vy = (P[j + 1] - PP[j + 1]) * C.damp, vz = (P[j + 2] - PP[j + 2]) * C.damp;
        const vl = Math.hypot(vx, vy, vz); if (vl > vmax) { const q = vmax / vl; vx *= q; vy *= q; vz *= q; } // no whip-cracks
        PP[j] = P[j]; PP[j + 1] = P[j + 1]; PP[j + 2] = P[j + 2];
        P[j] += vx + (_r.x * ax + _u.x * ay) * h2; P[j + 1] += vy + (_r.y * ax + _u.y * ay) * h2; P[j + 2] += vz + (_r.z * ax + _u.z * ay) * h2; }
      // root bias: segment 1 leaves the neck along the (eased) painted tail direction; softer in strike poses
      tailDir(t, sx, _d); const j1 = (o + 1) * 3, rk = C.rootK * (.5 + .5 * C.idle);
      P[j1] += (rx + _d.x * seg - P[j1]) * rk; P[j1 + 1] += (ry + _d.y * seg - P[j1 + 1]) * rk; P[j1 + 2] += (rz + _d.z * seg - P[j1 + 2]) * rk;
      for (let it = 0; it < 2; it++) { // 2 passes (v3: softer cloth, cheaper)
        for (let i = 0; i < NS; i++) con(o + i, o + i + 1, seg, 1, i === 0, false);
        for (let i = 0; i < N - 2; i++) con(o + i, o + i + 2, seg * 1.85, C.bend, i === 0, true); }
      for (let i = 0; i < N; i++) { const j = (o + i) * 3, e = (P[j] - _a.x) * _n.x + (P[j + 1] - _a.y) * _n.y + (P[j + 2] - _a.z) * _n.z; // stay in the sprite plane
        P[j] -= _n.x * e; P[j + 1] -= _n.y * e; P[j + 2] -= _n.z * e; PP[j] -= _n.x * e; PP[j + 1] -= _n.y * e; PP[j + 2] -= _n.z * e; } } }
  // Catmull-Rom through the chain points (ends extrapolated) -> S, NR rows per strip
  const S = C.S;
  for (let t = 0; t < R; t++) { const o = t * N;
    for (let i = 0; i < NS; i++) { const j1 = (o + i) * 3, j2 = j1 + 3, j0 = i > 0 ? j1 - 3 : -1, j3 = i < NS - 1 ? j2 + 3 : -1;
      for (let sb = 0; sb < SUB; sb++) { const u = sb / SUB, u2 = u * u, u3 = u2 * u, r0 = (t * NR + i * SUB + sb) * 3;
        for (let c = 0; c < 3; c++) { const p1 = P[j1 + c], p2 = P[j2 + c], p0 = j0 < 0 ? 2 * p1 - p2 : P[j0 + c], p3 = j3 < 0 ? 2 * p2 - p1 : P[j3 + c];
          S[r0 + c] = .5 * (2 * p1 + (p2 - p0) * u + (2 * p0 - 5 * p1 + 4 * p2 - p3) * u2 + (3 * p1 - p0 - 3 * p2 + p3) * u3); } } }
    const rl = (t * NR + NR - 1) * 3, pl = (o + NS) * 3; S[rl] = P[pl]; S[rl + 1] = P[pl + 1]; S[rl + 2] = P[pl + 2]; }
  // ribbon vertices: width across the curve, in the sprite plane; narrow at the knot, widest ~1/4 down, then the slashed strip
  const pos = C.pos;
  for (let t = 0; t < R; t++) { const o = t * NR, Wt = TAILS[t].w;
    for (let i = 0; i < NR; i++) { const j = (o + i) * 3, a = (o + Math.max(0, i - 1)) * 3, b = (o + Math.min(NR - 1, i + 1)) * 3;
      const tx_ = S[b] - S[a], ty_ = S[b + 1] - S[a + 1], tz_ = S[b + 2] - S[a + 2];
      let wx = ty_ * _n.z - tz_ * _n.y, wy = tz_ * _n.x - tx_ * _n.z, wz = tx_ * _n.y - ty_ * _n.x; const l = Math.hypot(wx, wy, wz) || 1;
      const TL = TAILS[t], f = i / (NR - 1), wt = C.wMax * TL.tip * C.w1;
      const prof = (f < TL.pk ? C.w0 + (C.wMax - C.w0) * Math.sin(f / TL.pk * Math.PI / 2) : C.wMax + (wt - C.wMax) * sst(TL.pk, 1, f)) // root -> widest -> own tip width
        * (1 + TL.wa * Math.sin(f * TL.wf * Math.PI + TL.ph * 2) * sst(.05, .35, f)) * (1 + C.puff * TL.pf * sst(.6, 1, f)); // uneven swell along it; smoke puffs out
      const hw = U * Wt * prof * (1 + .07 * Math.sin(C.t * 2.2 - i * .3 + t * 2) * f) / l; // the tip breathes a little
      wx *= hw; wy *= hw; wz *= hw; const q = (o + i) * 6;
      pos[q] = S[j] - wx; pos[q + 1] = S[j + 1] - wy; pos[q + 2] = S[j + 2] - wz; pos[q + 3] = S[j] + wx; pos[q + 4] = S[j + 1] + wy; pos[q + 5] = S[j + 2] + wz; } }
  C.geo.attributes.position.needsUpdate = true;
  const cu = m.material.uniforms, al = mu.alpha.value * (mu.cut.value > -1 ? Math.max(0, mu.cut.value) : 1);
  cu.alpha.value = al; cu.tint.value.copy(mu.tint.value); cu.flash.value.copy(mu.flash.value);
  cu.olC.value.copy(mu.olC.value); cu.olA.value = mu.olA.value; cu.smT.value = C.t; cu.smS.value = C.smoke; cu.smO.value = C.ol;
  m.renderOrder = s.renderOrder - .003; // behind the body (blade behind = -.002)
  const ct = cu.capeT?.value; if (ct) C.wisp.material.uniforms.col.value.setRGB(SMOKE.r + (ct.x * .14 + .015 - SMOKE.r) * ct.w, SMOKE.g + (ct.y * .14 + .015 - SMOKE.g) * ct.w, SMOKE.b + (ct.z * .14 + .015 - SMOKE.b) * ct.w);
  C.wisp.material.uniforms.alpha.value = al; C.wisp.renderOrder = s.renderOrder - .004;
  wisps(dt, U, sx, true);
  C.ms += performance.now() - t0; C.msN++;
}
function con(i, k, rest, st, pin, bend) { // distance constraint (st = stiffness); pin = point i is the pinned root; bend links only push apart
  const P = C.P, a = i * 3, b = k * 3, dx = P[b] - P[a], dy = P[b + 1] - P[a + 1], dz = P[b + 2] - P[a + 2], l = Math.hypot(dx, dy, dz) || 1e-6;
  if (bend && l > rest) return;
  const df = (l - rest) / l * st, wa = pin ? 0 : .5, wb = pin ? 1 : .5;
  P[a] += dx * df * wa; P[a + 1] += dy * df * wa; P[a + 2] += dz * df * wa;
  P[b] -= dx * df * wb; P[b + 1] -= dy * df * wb; P[b + 2] -= dz * df * wb;
}

// smoke wisps: W[k] = x y z, vx vy vz (world / s), age, life, spin, size (0 = free slot when age >= life)
function wisps(dt, U, sx, spawn) {
  const W = C.W, wp = C.wgeo.attributes.position.array, wa = C.wgeo.attributes.aA.array;
  if (spawn) { C.spawn += dt * C.wispRate * (.6 + .4 * C.idle);
    while (C.spawn >= 1) { C.spawn -= 1; let k = -1; for (let i = 0; i < K; i++) if (W[i * WS + 6] >= W[i * WS + 7]) { k = i; break; } if (k < 0) break;
      const t = C.wn++ % R, r = (t * NR + NR - 4 - (C.wn % 5)) * 3, pl = (t * N + NS) * 3, o = k * WS, rnd = hs(C.t * 3.7, k);
      W[o] = C.S[r]; W[o + 1] = C.S[r + 1]; W[o + 2] = C.S[r + 2];
      const vx = (C.P[pl] - C.PP[pl]) * 60 * .2, vy = (C.P[pl + 1] - C.PP[pl + 1]) * 60 * .2, vz = (C.P[pl + 2] - C.PP[pl + 2]) * 60 * .2;
      W[o + 3] = vx + (-sx * _r.x * .16 + _u.x * (.18 + .14 * rnd)) * U; W[o + 4] = vy + (-sx * _r.y * .16 + _u.y * (.18 + .14 * rnd)) * U; W[o + 5] = vz + (-sx * _r.z * .16 + _u.z * (.18 + .14 * rnd)) * U;
      W[o + 6] = 0; W[o + 7] = 1.1 + .6 * rnd; W[o + 8] = (rnd - .5) * 2.4 * sx; W[o + 9] = U * (.7 + .5 * hs(k, C.t)); } }
  let live = 0;
  for (let k = 0; k < K; k++) { const o = k * WS, q = k * 12; W[o + 6] += dt;
    if (W[o + 6] >= W[o + 7]) { wa[k * 4] = wa[k * 4 + 1] = wa[k * 4 + 2] = wa[k * 4 + 3] = 0; continue; } live++;
    // curl: rotate the velocity in the sprite plane, drag, a little buoyancy
    const sp = W[o + 8] * dt, cs = Math.cos(sp), sn = Math.sin(sp), vx = W[o + 3], vy = W[o + 4], vz = W[o + 5];
    const cx = _n.y * vz - _n.z * vy, cy = _n.z * vx - _n.x * vz, cz = _n.x * vy - _n.y * vx, dr = 1 - Math.min(.5, dt * .9), by = W[o + 9] * .25 * dt;
    W[o + 3] = (vx * cs + cx * sn) * dr + _u.x * by; W[o + 4] = (vy * cs + cy * sn) * dr + _u.y * by; W[o + 5] = (vz * cs + cz * sn) * dr + _u.z * by;
    W[o] += W[o + 3] * dt; W[o + 1] += W[o + 4] * dt; W[o + 2] += W[o + 5] * dt;
    const x = W[o + 6] / W[o + 7], L = W[o + 9] * (.06 + .12 * x), Wd = L * .55, al = Math.min(1, x / .15) * Math.pow(1 - x, 1.3) * .85;
    let ex = W[o + 3], ey = W[o + 4], ez = W[o + 5]; const el = Math.hypot(ex, ey, ez); if (el < 1e-5) { ex = -sx * _r.x; ey = -sx * _r.y; ez = -sx * _r.z; } else { ex /= el; ey /= el; ez /= el; }
    const px = _n.y * ez - _n.z * ey, py = _n.z * ex - _n.x * ez, pz = _n.x * ey - _n.y * ex;
    for (let v = 0; v < 4; v++) { const a = v & 1 ? L : -L, b = v & 2 ? Wd : -Wd;
      wp[q + v * 3] = W[o] + ex * a + px * b; wp[q + v * 3 + 1] = W[o + 1] + ey * a + py * b; wp[q + v * 3 + 2] = W[o + 2] + ez * a + pz * b; wa[k * 4 + v] = al; } }
  C.live = live; C.wisp.visible = live > 0;
  if (live) { C.wgeo.attributes.position.needsUpdate = true; C.wgeo.attributes.aA.needsUpdate = true; }
}
