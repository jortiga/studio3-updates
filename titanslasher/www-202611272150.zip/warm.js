// 11-27 PERF PASS: GPU warm-up behind the loading screen (MOBILE_PERFORMANCE.md "Preload behind a loading screen").
// The old boot step compiled only the main scene, into the default framebuffer. Measured after it (headless, ink style): the first
// dummy tap / first fight / first Cross / Eclipse limit still linked 6 shader programs (distortion writers, numfx, limit runes +
// moon) and uploaded ~15 big textures on first use (hero strike poses 0.6-1.3 MP each with mipmaps, slash arcs, dummy chips,
// splashes, the numfx atlas) = the 100-230 ms hitches on the first slash / first fight / first limit.
// warmGPU() now, once at boot:
//   1. every pass's scene is compiled INTO ITS OWN RENDER TARGET (the program key depends on the target), with hidden objects
//      (pooled FX, limit meshes, splashes, clones...) forced visible for the compile;
//   2. upload() (awaited by main.js with preloadUI, still behind the loading screen): every program's first-use queries, then every
//      texture any of their materials references plus the extra lists (main.js T: hero poses / slashes / env, idle frames) via
//      renderer.initTexture (no download: only textures already loaded), in 12 ms slices per frame.
// Nothing is drawn and nothing changes visibly. Note 9: compile ~40 ms, uploads ~0.5 s = loading screen ~0.5 s longer; it was paid
// mid-game before (first dummy tap 250 ms, fight start 130 ms, first Cross / Eclipse limit).
export function warmGPU(renderer, camera, passes, extraTex = []) {
  const t0 = performance.now(), p0 = renderer.info.programs ? renderer.info.programs.length : 0, tex = new Set(), seen = new WeakSet();
  const addTex = (v, d = 0) => { // textures in a uniform value / list / map / plain object (depth-limited)
    if (!v || d > 5 || typeof v !== 'object') return;
    if (v.isTexture) { if (!v.isRenderTargetTexture) tex.add(v); return; }
    if (seen.has(v)) return; seen.add(v);
    if (Array.isArray(v)) { for (const x of v) addTex(x, d + 1); return; }
    if (v instanceof Map) { for (const [k, x] of v) { addTex(k, d + 1); addTex(x, d + 1); } return; }
    if (Object.getPrototypeOf(v) === Object.prototype) for (const k in v) addTex(v[k], d + 1);
  };
  const prevT = renderer.getRenderTarget();
  for (const [sc, target] of passes) {
    if (!sc) continue; const hid = [];
    sc.traverse((o) => { if (!o.visible) { hid.push(o); o.visible = true; }
      for (const m of [].concat(o.material || [])) { if (!m) continue; addTex(m.map); for (const k in m.uniforms || {}) addTex(m.uniforms[k] && m.uniforms[k].value); } });
    try { renderer.setRenderTarget(target || null); renderer.compile(sc, camera); } catch (e) { console.warn('warm compile', e); }
    for (const o of hid) o.visible = false;
  }
  renderer.setRenderTarget(prevT);
  for (const t of extraTex) addTex(t);
  const out = { ms: Math.round(performance.now() - t0), progs: (renderer.info.programs ? renderer.info.programs.length : 0) - p0, tex: 0, texMs: 0 };
  // textures: uploaded in ~12 ms slices, one rAF apart, so they overlap the loading screen's UI-art preload instead of adding to it
  // (Note 9: the whole list in one go was ~1.4 s of blocked main thread). main.js awaits upload() together with preloadUI().
  // + each program's first use (link check + uniform / attribute locations = synchronous GPU round trips; on the Note 9 they showed
  // up mid-fight as getProgramInfoLog the first time a pooled effect drew) is done here too, before the textures
  const list = [...(renderer.info.programs || []).map((p) => () => { p.getUniforms(); p.getAttributes(); }),
    ...[...tex].filter((t) => t.image || t.isDataTexture).map((t) => () => { renderer.initTexture(t); out.tex++; })];
  out.upload = () => new Promise((done) => { const step = () => { const s = performance.now();
    while (list.length && performance.now() - s < 12) { try { list.shift()(); } catch (e) { /* not ready */ } }
    out.texMs += performance.now() - s; if (list.length) requestAnimationFrame(step); else { out.texMs = Math.round(out.texMs); done(out); } }; requestAnimationFrame(step); });
  return out;
}
