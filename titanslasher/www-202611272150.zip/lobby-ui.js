// 11-27 LOBBY UI v2 (user reference: a mobile lobby with a top bar and a bottom tab bar; layout only, our hand-drawn ink look).
//   TOP BAR (lobby + shop / gear screens, never in fights): hero avatar + name + level (tap = PROFILE), ENERGY pill with the
//     refill countdown, coins.
//   BOTTOM TAB BAR (lobby only): SHOP | GEAR | FIGHT (centre, big, raised: starts the titan fight, costs energy) | RANKS | SETTINGS.
//     SHOP / GEAR open inventory-ui.js as full screens between the bars (tap the open tab again, or the back arrow = lobby);
//     RANKS / SETTINGS open the hud-menu.js popups. Badges mirror hud-menu.js updateBadges() (hidden #menu buttons), so a
//     visit clears them exactly as before.
//   LOBBY: the training dummy stays in the middle (every layer here is pointer-events:none except the buttons); a small titan
//     card under the top bar (day + today's titan + best today) and a DAILY chip low on the left.
//   ENERGY (energy.js): FIGHT spends it; not enough -> "out of energy" popup with WATCH AD +5 (window.__rewardedAd, if any).
//   CYCLE mode: fights start by themselves on the world clock (main.js cycleTick) and never cost energy.
//   Lobby framing: the scene's view is shifted up (camera.setViewOffset, lobby only, eased) so the hero ledge sits above the bar;
//     taps project through the same camera, so dummy hits stay exact.
// ?ui=1 = the old round side buttons (no bars). Art: art/ui_ink/{topbar,tab_idle,tab_on,tab_fight,energy_pill,ic_titan}.webp
// (tools/make_ui_ink.py lobby) + the existing ic_*.webp icons.
import * as EN from './energy.js';
import * as EQ from './equipment.js';
import * as TB from './timeboard.js'; // 11-28 ?timeboard=1 kill-time board (default OFF)
import * as PF from './prefight.js'; // 11-27 pre-fight rewarded ad: fight with a random blade (reel + STOP)
import { UI, INK as INKS } from './uiart.js';
// 11-27 ink style: the approved UI kit icons (art/ui_ink/kit, kit-ui.css); the default style keeps the old ones
const KIT = 'art/ui_ink/kit', icon = (k, old) => (INKS ? `${KIT}/ic_${k}.webp` : old);

const Q = new URLSearchParams(location.search);
export const ON = Q.get('ui') !== '1';
const INK = 'art/ui_ink';
const DAY_ONE = Math.floor(Date.UTC(2026, 9, 12) / 864e5); // "DAY n" counter of the daily titan (day 1 = 2026-10-12 UTC)
const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.round(n).toLocaleString('en-US');
// 11-27 user: top-bar coins in a short form - 9,999 / 10.0K / 100.1K / 1.2M / 3.4B (never more than 6 characters)
const fmtShort = (n) => { n = Math.max(0, Math.floor(n)); if (n < 1e4) return n.toLocaleString('en-US'); for (const [d, u] of [[1e9, 'B'], [1e6, 'M'], [1e3, 'K']]) if (n >= d) { const v = Math.floor(n / d * 10) / 10; return (v >= 1000 ? Math.floor(v) : v.toFixed(1)) + u; } return String(n); };
let C = null, tabInv = '', T = 0, shift = 0, last = {}, tbH = -1; // tbH: cached #tabbar height (frame())

export function init(ctx) { // ctx: { SAVE, save, sfx, A, LB, INV, MENU, TIX, CYCLE, titanIdx(), state(), fight() -> true if it started }
  C = ctx; EN.init({ SAVE: C.SAVE, save: C.save }); PF.init({ SAVE: C.SAVE, save: C.save, sfx: C.sfx });
  if (!ON) return;
  document.documentElement.classList.add('ui2');
  const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'lobby-ui.css'; document.head.appendChild(css);
  const tab = (k, ic, label) => `<button class="tab" data-t="${k}" aria-label="${label}"><span class="tt"><img src="${ic}" alt=""></span><small>${label}</small><i class="badge"></i></button>`;
  document.body.insertAdjacentHTML('beforeend', `
<div id="topbar"><div class="tb-in">
  <button class="tb-me" aria-label="Profile"><span class="tb-av"></span><span class="tb-id"><b class="tb-name">-</b><small class="tb-lv">LEVEL 1</small></span></button>
  <div class="tb-en"><div class="tb-pill"><b class="tb-ev">30/30</b><small class="tb-next">FULL</small></div></div>
  <div class="tb-coin"><span>&#9670;</span> <b class="tb-cn">0</b></div>
</div></div>
<div id="lcard"><small class="lc-day">DAY 1</small><b class="lc-name">-</b><em class="lc-best">Best today: -</em></div>
<div id="lchips"><button class="chip" data-k="daily" aria-label="Daily rewards"><img src="${icon('daily', `${UI}/ic_daily.webp`)}" alt=""><small>DAILY</small><i class="badge"></i></button></div>
<nav id="tabbar"><div class="tbar">
  ${tab('shop', icon('shop', `${UI}/ic_shop.webp`), 'SHOP')}${tab('gear', icon('gear', `${UI}/ic_gear.webp`), 'GEAR')}
  <button class="tab tfight" data-t="fight" aria-label="Fight the titan"><span class="tf"><img src="${icon('fight', `${INK}/ic_titan.webp`)}" alt=""><b>FIGHT</b><em><i>&#9889;</i>${EN.COST}</em></span></button>
  ${tab('board', icon('ranks', `${UI}/ic_board.webp`), 'RANKS')}${tab('settings', icon('settings', `${UI}/ic_settings.webp`), 'SETTINGS')}
</div></nav>
<div id="enPop" class="panel hidden"><div class="mframe"><div class="en-ic"><img src="${INK}/energy_pill.webp" alt=""></div><h2>NO ENERGY</h2>
  <p class="en-t">Next refill <b>0:00</b></p>
  <button class="btn hot en-ad">WATCH AD +${EN.COST}</button><button class="btn en-buy">+${EN.COST} ENERGY &#9670; ${REFILL}</button></div></div>`);
  // 11-27 ink fight HUD: titan name plate + a thin teal bar = the fight time left (kit-ui.css shows it in fights only)
  if (INKS) document.body.insertAdjacentHTML('beforeend', '<div id="tplate"><i class="tp-ic"></i><div class="tp-tx"><b class="tp-n">-</b><div class="tp-bar"><i></i></div></div></div>');
  // the back arrow of the tab screens lives in the inventory header (re-render keeps .ihead)
  const ih = document.querySelector('#inv .ihead'); if (ih) ih.insertAdjacentHTML('afterbegin', '<button class="iback" aria-label="Back to the lobby">&#10094;</button>');
  for (const id of ['topbar', 'tabbar', 'lchips', 'enPop']) for (const ev of ['pointerdown', 'touchstart']) $(id).addEventListener(ev, (e) => { if (e.target.closest('button') || id === 'enPop') e.stopPropagation(); }, { passive: true });
  $('tabbar').addEventListener('click', (e) => { const b = e.target.closest('.tab'); if (b) { e.stopPropagation(); C.A.init(); onTab(b.dataset.t); } });
  $('lchips').addEventListener('click', (e) => { const b = e.target.closest('.chip'); if (b) { e.stopPropagation(); C.A.init(); closeAll(); C.MENU.open(b.dataset.k); } });
  document.querySelector('#topbar .tb-me').addEventListener('click', (e) => { e.stopPropagation(); // 11-27 user: tapping the profile again closes it
    if (tabMenu === 'profile' && C.MENU.isOpen() && document.querySelector('#mpanel:not(.hidden):not(.out)')) { C.sfx('click'); C.MENU.close(); tabMenu = null; return refresh(); }
    closeAll(); C.MENU.open('profile'); tabMenu = 'profile'; });
  document.querySelector('#inv .iback')?.addEventListener('click', (e) => { e.stopPropagation(); C.sfx('click'); C.INV.close(); });
  $('enPop').addEventListener('click', (e) => { e.stopPropagation(); if (e.target === $('enPop')) { C.sfx('click'); closePop(); } });
  $('enPop').querySelector('.en-ad').addEventListener('click', watchAd);
  $('enPop').querySelector('.en-buy').addEventListener('click', buyRefill); // 11-27 user: buy energy with shards
  refresh(true);
}
export const tabOpen = () => !!tabInv && C.INV.isOpen();
const enOpen = () => ON && !!$('enPop') && !$('enPop').classList.contains('hidden');
export const popOpen = () => enOpen() || PF.closable(); // closable popups (main.js #popX / Esc); the ad-blade reel can't be backed out of
export const pfOpen = () => PF.isOpen();
export function closePop() { $('enPop')?.classList.add('hidden'); PF.close(); }
function closeAll(instant) { // instant: no slide-down on the ink bottom sheets (switching from one tab screen to another)
  if (popOpen()) closePop();
  if (C.MENU.isOpen()) C.MENU.close(instant);
  if (window.DAILY?.isOpen?.() && window.DAILY.canClose?.() !== false) window.DAILY.close();
  if (C.INV.isOpen()) C.INV.close(instant);
}

let tabMenu = null; // the RANKS / SETTINGS tab whose sheet is up
function onTab(k) {
  if (C.state() !== 'lobby') return;
  if (k === 'fight') return fight();
  if ((k === 'shop' || k === 'gear') && tabOpen() && tabInv === k) { C.sfx('click'); C.INV.close(); return refresh(); } // the open tab again = back to the lobby
  // 11-27 user: RANKS / SETTINGS close too when their tab is tapped again
  if (k !== 'shop' && k !== 'gear' && tabMenu === k && C.MENU.isOpen() && document.querySelector('#mpanel:not(.hidden):not(.out)')) { C.sfx('click'); C.MENU.close(); tabMenu = null; return refresh(); }
  const sw = tabOpen() || !!document.querySelector('#mpanel.sheet:not(.hidden):not(.out)'); // a tab sheet is already up: swap it in place
  closeAll(sw);
  tabMenu = k === 'shop' || k === 'gear' ? null : k;
  C.MENU.open(k); // hud-menu.js: gear / shop -> INV.open (+ marks gear seen), board, settings
  if (k === 'shop' || k === 'gear') { tabInv = k; $('inv').classList.add('tabscr'); }
  if (INKS) C.INV.setView3d?.(k === 'gear'); // 11-27 3D gear view (ink): the live hero up top, the inventory sheet below
  if (sw) for (const id of ['inv', 'mpanel']) if (!(id === 'inv' && k === 'gear' && INKS)) $(id)?.classList.remove('go'); // gear always slides with its camera move
  refresh();
}
function fight() {
  if (C.CYCLE) { C.sfx('deny'); return; } // world clock: the titan rises by itself
  if (!EN.canFight()) { C.sfx('deny'); return openPop(); }
  if (PF.isOpen()) return;
  closeAll();
  const go = () => { if (C.state() !== 'lobby') return false; const ok = C.fight(); if (ok) EN.spend(); refresh(true); return ok; }; // only a fight that really started costs energy
  if (PF.wants()) { C.sfx('click'); PF.open(go); return refresh(true); } // 11-27 pre-fight ad popup (native app / ?adfake=1): WATCH AD · RANDOM BLADE | FIGHT
  go();
}
function openPop() { const p = $('enPop'); p.classList.remove('hidden', 'go'); void p.offsetWidth; p.classList.add('go'); refresh(true); }
const REFILL = 200; // shards for a full energy refill (= the shop's Energy Chest)
function buyRefill(e) {
  e.stopPropagation(); const S = C.SAVE;
  if (S.coins < REFILL) { C.sfx('deny'); const b = e.currentTarget; b.classList.remove('soon'); void b.offsetWidth; b.classList.add('soon'); return; }
  S.coins -= REFILL; EN.add(EN.COST); /* 11-27 user: 200 shards = +5 energy (one fight), not a full refill */ C.sfx('buy'); C.save(); closePop(); refresh(true);
}
async function watchAd(e) {
  e.stopPropagation(); const b = e.currentTarget; if (b.disabled || typeof window.__rewardedAd !== 'function') return;
  C.sfx('click'); b.disabled = true; let ok = false;
  try { ok = !!(await window.__rewardedAd('energy')); } catch (err) { ok = false; }
  b.disabled = false; if (ok) { EN.add(EN.COST); C.sfx('buy'); closePop(); } refresh(true);
}

// best today: the best fight of this UTC day from SAVE.last (main.js writes it after every fight)
function bestToday() {
  const S = C.SAVE, day = C.LB.day(), L = S.last;
  if (!S.dayBest || S.dayBest.day !== day) S.dayBest = { day, score: 0, rank: 0 };
  if (L && L.hour === day && L.score > S.dayBest.score) { S.dayBest.score = L.score; S.dayBest.rank = L.rank; C.save(); }
  return S.dayBest;
}
const lv = (n) => 1 + Math.floor(Math.sqrt((n || 0) * 1.5)); // player level from titans fought (placeholder curve)
// 11-27 user: a long name never ellipsizes - its font shrinks until it fits its column (down to 8px). 11-28 user "it's cut out":
// measured on the letters themselves with room for their outline, and re-checked by the refresh loop (iPhone: the display font can
// arrive after the first fit without any font event)
const nameWide = (e) => { const r = document.createRange(); r.selectNodeContents(e); return r.getBoundingClientRect().width > e.getBoundingClientRect().width - 5; };
function fitName() { const e = document.querySelector('#topbar .tb-name'); if (!e) return; e.style.fontSize = e.style.whiteSpace = e.style.overflowWrap = e.style.lineHeight = '';
  requestAnimationFrame(() => { let f = parseFloat(getComputedStyle(e).fontSize) || 16; while (f > 8 && e.clientWidth && nameWide(e)) { f -= .5; e.style.fontSize = `${f}px`; }
    if (e.clientWidth && nameWide(e)) { e.style.whiteSpace = 'normal'; e.style.overflowWrap = 'anywhere'; e.style.lineHeight = '1.05'; } }); } // still too wide at 8px: two lines, never cut
function fitPlate() { const e = document.querySelector('#lcard .lc-name'); if (!e) return; e.style.fontSize = ''; e.style.whiteSpace = 'nowrap'; e.dataset.fit = '';
  if (!e.offsetWidth) return; /* hidden: the refresh loop retries */ let f = parseFloat(getComputedStyle(e).fontSize) || 24; const w = Math.min(innerWidth - 90, 330);
  while (f > 10 && e.scrollWidth > w) { f -= .5; e.style.fontSize = `${f}px`; } e.dataset.fit = '1'; }
addEventListener('resize', () => { fitName(); fitPlate(); });
document.fonts?.ready?.then(() => fitName()); document.fonts?.addEventListener?.('loadingdone', () => fitName()); // the display font arrives after the first fit
const set = (sel, v, prop = 'textContent') => { const e = typeof sel === 'string' ? document.querySelector(sel) : sel; if (e && last[sel] !== v) { last[sel] = v; e[prop] = v; } };

function refresh(force) {
  if (!ON || !C) return; if (force) last = {};
  const st = C.state(), S = C.SAVE, e = EN.tick();
  // tab screen bookkeeping: the inventory closed (X, a fight starting, a buy jumping tabs) -> follow it
  if (tabInv && !C.INV.isOpen()) { tabInv = ''; $('inv').classList.remove('tabscr'); }
  if (tabInv) { const on = document.querySelector('#inv .itabs button.on')?.dataset.tab; if (on && on !== tabInv) tabInv = on; }
  if (st !== 'lobby' && C.INV.view3d?.()) C.INV.setView3d(false); // never outside the lobby (a fight starting under it)
  set('#inv .ititle', tabInv ? tabInv.toUpperCase() : 'HERO'); // the screen is named after its tab (the popup from the results stays HERO)
  if (st !== 'lobby' && popOpen()) closePop();
  if (INKS) tplate(st);
  document.querySelectorAll('#tabbar .tab').forEach((b) => b.classList.toggle('on', b.dataset.t === tabInv || (b.dataset.t === 'board' && C.MENU.isOpen() && document.querySelector('#mpanel .mhead h2')?.textContent === 'LEADERBOARD') || (b.dataset.t === 'settings' && C.MENU.isOpen() && document.querySelector('#mpanel .mhead h2')?.textContent === 'SETTINGS')));
  // badges = hud-menu.js's (it keeps toggling .on on the hidden #menu buttons)
  const bd = (k) => !!document.querySelector(`#menu .mb[data-k="${k}"]`)?.classList.contains('on');
  document.querySelector('#tabbar .tab[data-t="gear"]').classList.toggle('bad', bd('gear') && tabInv !== 'gear');
  document.querySelector('#lchips .chip[data-k="daily"]').classList.toggle('bad', bd('daily'));
  document.querySelector('#lchips .chip[data-k="daily"]').classList.toggle('off', !window.DAILY);
  // top bar
  if (last['.tb-name'] !== (C.LB.nick || 'Slasher')) { set('.tb-name', C.LB.nick || 'Slasher'); fitName(); }
  { const ne = document.querySelector('#topbar .tb-name'), nw = ne ? ne.clientWidth : 0; if (nw && (nw !== last.nameW || (ne.style.whiteSpace !== 'normal' && nameWide(ne)))) { last.nameW = nw; fitName(); } } // refit once the bar is shown / resized (hidden at boot = width 0)
  set('.tb-lv', `LEVEL ${window.PROG ? window.PROG.level : lv(S.titans)}`); set('.tb-cn', fmtShort(S.coins || 0)); // 11-27 .tb-lv = real level (progression.js; XP bar: prog-ui.js)
  set('.tb-ev', EN.INF ? '∞' : `${e.v}/${e.max}`); set('.tb-next', EN.INF ? 'DEV' : e.next ? `+1 in ${EN.mmss(e.next)}` : 'FULL');
  const av = document.querySelector('#topbar .tb-av'), hf = EQ.portraitFile ? EQ.portraitFile() : EQ.heroFile('idle'); if (av && last.av !== hf) { last.av = hf; av.style.backgroundImage = INKS ? `url('${hf}'), radial-gradient(circle at 52% 45%, #5fa9a6 0, #2c5a5c 45%, #12262b 80%)` : `url('${hf}')`; /* 11-27 ink: teal glow behind the dark heads */
    const avf = INKS && EQ.headLook ? EQ.headLook()?.av : null; av.style.backgroundSize = avf ? `${avf[0]}%, 100%` : ''; av.style.backgroundPosition = avf ? `${avf[1]}% ${avf[2]}%, center` : ''; /* per-head avatar framing (heads.*.av = [size %, x %, y %]; Old Shell: big horned head) */ }
  // lobby card
  const ti = C.titanIdx(), b = TB.ON ? null : bestToday();
  set('.lc-day', `DAY ${Math.max(1, C.LB.day() - DAY_ONE + 1)}`); { const nm = (C.TIX.names[ti] || '').toUpperCase(); if (last['.lc-name'] !== nm) { set('.lc-name', nm); fitPlate(); } else { const e = document.querySelector('#lcard .lc-name'); if (e && (!e.dataset.fit || e.scrollWidth > Math.min(innerWidth - 90, 330) + 1)) fitPlate(); } } /* refit when the display font arrives */ /* 11-27 long ink titan names shrink to fit the plate */
  set('.lc-best', TB.ON ? TB.bestLine(C.LB.day(), ti) : b.score ? `Best today: ${fmt(b.score)} · #${b.rank}` : 'Best today: -');
  // fight tile
  const tf = document.querySelector('#tabbar .tfight'), ok = EN.canFight();
  tf.classList.toggle('broke', !C.CYCLE && !ok); tf.classList.toggle('cyc', !!C.CYCLE);
  set('#tabbar .tfight b', C.CYCLE ? 'TITAN' : 'FIGHT');
  document.documentElement.classList.toggle('ui2tab', !!tabInv);
  if (enOpen()) { set('#enPop .en-t b', EN.mmss(EN.untilFight())); const ad = $('enPop').querySelector('.en-ad'), can = typeof window.__rewardedAd === 'function';
    if (!can) { ad.disabled = true; set(ad, 'AD UNAVAILABLE'); } else set(ad, `WATCH AD +${EN.COST}`);
    if (EN.canFight()) closePop(); }
}

// ink titan plate: the name + the fight time left, read from main.js's (hidden) #timer "m:ss" text; the first value of a fight
// is the full length, so no main.js hook is needed
let tpTot = 0, tpSt = '';
function tplate(st) {
  if (st !== tpSt) { tpSt = st; tpTot = 0; } if (st !== 'fight') return;
  const p = $('tplate'), m = /(\d+):(\d+)/.exec($('timer')?.textContent || ''); if (!p) return;
  set('#tplate .tp-n', (C.TIX.names[C.titanIdx()] || 'TITAN').toUpperCase());
  if (TB.ON) return; // time board: the bar is the titan's HP (timeboard.js hud)
  if (!m) return; const left = +m[1] * 60 + +m[2]; tpTot = Math.max(tpTot, left, 1);
  const f = left / tpTot; p.querySelector('.tp-bar i').style.width = `${(f * 100).toFixed(1)}%`; p.classList.toggle('low', left <= 10);
}

// 11-27 3D gear view (ink lobby, GEAR tab open): the hero stands idle (no auto-train / taps, main.js + prog-ui.js) and the lobby
// view zooms onto him. Done with the SAME view offset as the lobby shift (a sub-window of the rest projection): the camera itself
// does not move, so the dojo's projective layers (dojo.js, painted from the rest camera) stay exact - a pure 2D zoom + pan.
export const gearView = () => INKS && !!C && C.state() === 'lobby' && !!C.INV.view3d?.();
const GV = { k: 0, dur: .45, sheet: .45, fill: .66, maxZ: 2.4 }; // ease s; sheet top (fraction of the screen, kit-ui.css .g3d); hero height / visible gap
// every frame (main.js, after the camera is placed): UI refresh 4x/s + the lobby framing shift (+ the gear view zoom)
export function frame(dt, camera, W, H) {
  if (Q.has('gvdbg') && C) { let d = $('gvdbg0'); if (!d) { d = document.createElement('pre'); d.id = 'gvdbg0'; d.style.cssText = 'position:fixed;left:4px;top:30%;z-index:99999;margin:0;padding:4px 6px;background:#000c;color:#ffd35a;font:11px/1.3 monospace;pointer-events:none;white-space:pre'; document.body.appendChild(d); }
    d.textContent = `ON ${ON} vy ${Q.get('vy')} saved ${JSON.stringify(window.__devShim?.added || [])}
url ${location.search.slice(0, 120)}`; }
  if (!ON || !C) return;
  T -= dt; if (T <= 0) { T = .25; refresh(); tbH = -1; }
  if (+Q.get('vy') && !(window.__devShim?.added || []).includes('vy')) return; // ?vy= (animation review) owns the view offset - only a NON-zero value (a saved DEV panel vy=0 must not switch the lobby view shift + gear zoom off)
  const st = C.state(); if (st === 'lobby' && tbH < 0) tbH = $('tabbar')?.offsetHeight || 0; // 11-27 PERF PASS: read 4x/s in the lobby only (offsetHeight every frame forced a style + layout after each HUD text write: ~4% CPU in fights)
  const bb = st === 'lobby' ? tbH : 0, want = st === 'lobby' && !document.body.classList.contains('cine') ? Math.round(bb * .62) : 0;
  shift += (want - shift) * (1 - Math.exp(-dt * 6)); if (Math.abs(want - shift) < .3) shift = want;
  if (Q.has('gvdbg')) { let d = $('gvdbg'); if (!d) { d = document.createElement('pre'); d.id = 'gvdbg'; d.style.cssText = 'position:fixed;left:4px;top:40%;z-index:99999;margin:0;padding:4px 6px;background:#000c;color:#7fd6c8;font:11px/1.3 monospace;pointer-events:none;white-space:pre'; document.body.appendChild(d); }
    let hbx = null; try { hbx = C.heroBox && C.heroBox(); } catch (e) { hbx = 'ERR ' + e.message; } const vv = camera.view;
    d.textContent = `st ${st} ink ${INKS} v3d ${C.INV.view3d?.()} open ${C.INV.isOpen?.()}
gv ${gearView()} k ${GV.k.toFixed(2)} W ${W} H ${H}
hb ${JSON.stringify(hbx)}
view ${vv && vv.enabled ? [vv.offsetX, vv.offsetY, vv.width, vv.height].map((x) => Math.round(x)).join(',') : 'off'}
cls ${$('inv')?.className}`; }
  const gv = gearView(); GV.k = gv ? Math.min(1, GV.k + dt / GV.dur) : Math.max(0, GV.k - dt / GV.dur);
  const v = camera.view, cur = v && v.enabled ? v.offsetY : 0;
  const hb = GV.k > 0 && C.heroBox ? C.heroBox() : null; // hero { x, top, bot } in rest-view px (no offset)
  if (hb) {
    const e = GV.k * GV.k * (3 - 2 * GV.k), top = $('topbar')?.getBoundingClientRect().bottom || 0, bot = H * GV.sheet - 18; // 18: the sheet's thorn crown
    const gap = Math.max(60, bot - top), hp = Math.max(1, hb.bot - hb.top), z = Math.min(GV.maxZ, Math.max(1.15, GV.fill * gap / hp));
    let feet = H * GV.sheet - 16, cx = W / 2, zz = z; // fallback: feet on the sheet top
    // 11-27 the gear panel's WINDOW (.g3win, kit-ui.css) frames the hero: centred in it, feet near its bottom, ~74% of its height.
    // offsetLeft/Top ignore the slide-in transform, so the target is the window's final spot while everything moves together.
    const wn = document.querySelector('#inv.g3d .g3win'); if (wn && wn.offsetWidth) { const ir = $('inv').getBoundingClientRect(), wt = ir.top + wn.offsetTop, wh = wn.offsetHeight;
      cx = ir.left + wn.offsetLeft + wn.offsetWidth / 2; feet = wt + wh - 18; zz = Math.min(GV.maxZ, Math.max(1, .86 * (wh - 24) / hp)); }
    const xg = hb.x - cx / zz, yg = hb.bot - feet / zz; // hero x -> window centre, hero feet -> window bottom
    const z1 = 1 + (zz - 1) * e, x1 = xg * e, y1 = shift + (yg - shift) * e;
    camera.setViewOffset(W, H, x1, y1, W / z1, H / z1); return;
  }
  if (shift < .3) { if (v && v.enabled) camera.clearViewOffset(); return; }
  if (Math.abs(cur - shift) > .25 || v.offsetX !== 0 || v.width !== W || v.fullWidth !== W || v.fullHeight !== H) camera.setViewOffset(W, H, 0, shift, W, H);
}
