// Titan Slasher INVITES (11-27), no login. Client side of server/referrals.sql. LOGIC ONLY (UI in prog-ui.js).
// Identity = the anonymous leaderboard identity (leaderboard.js: device UUID + secret). Each player has an invite CODE (server).
// Share link = <this page's origin + path>?ref=<CODE> (+ ?style= kept). A NEW player opening it (or typing a code in the
// profile within their first day) is linked to the inviter on the server (once, no self-invite, no cycles, new ids only).
// A friend ACTIVATES only from the STORE APP signed in with Game Center / Play Games (LB.setPlatformId, called by the native layer
// later), after reaching player Lv 3 with plausible XP; max 2 activations per inviter per UTC day. The web build can send invites
// and link, never activate ("Friends join through the app").
// Rewards: the inviter gets +10% TRAINING XP per active friend (cap +50%), computed on the server (status.bonus_pct; the client
// only applies it to training XP via PROG.setTrainMul) + one coin-free XP crate per activation (lb_ref_claim). The invited new
// player gets x2 training XP for 24 h after the link. No coins, gear or leaderboard effect.
// Degrades silently: no server / referrals.sql not applied (404) / offline -> no status, the invite button still shares a code
// only once the server has given one (else it says "Invites need a connection").
// Test URL: ?reftest=N (fake status: N active friends, code TEST1234; no server), ?ref=CODE (link on first open).

export const CRATE_XP = 150, NEW_MUL = 2, NEW_MS = 24 * 3600000, MIN_LV = 3;
const Q = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
const TEST = Q.has('reftest') ? Math.max(0, +Q.get('reftest') | 0) : null;
let C = null, ST = null, busy = false; // ST = last server status
const listeners = new Set();
const lb = () => (C && C.LB) || (typeof window !== 'undefined' ? window.__lb : null);
const emit = () => listeners.forEach((f) => { try { f(ST); } catch (e) { console.error(e); } });
export const onChange = (f) => listeners.add(f);
// store app = a Capacitor native build (the release app also sets TT_DEV false)
export const isApp = () => typeof window !== 'undefined' && !!(window.Capacitor?.isNativePlatform?.() || window.TT_DEV === false);
function sv() { const S = C.SAVE; if (!S.ref || typeof S.ref !== 'object') S.ref = {}; return S.ref; }

async function rpc(fn, args) { const L = lb(); if (!L || !L.configured || !L.rpc || !L.auth) throw new Error('offline'); if (L.register && !(await L.register())) throw new Error('reg'); return L.rpc(fn, { ...L.auth(), ...args }); }

// the server status (or the ?reftest fake); null offline / not deployed
export async function status() {
  if (TEST != null) { ST = { ok: true, code: 'TEST1234', active: TEST, pending: 1, bonus_pct: Math.min(50, TEST * 10), today: 0, crates: 0, linked: false, test: true }; emit(); return ST; }
  try { const j = await rpc('lb_ref_status', {}); if (j && j.ok) { ST = j; if (j.code) sv().code = j.code; if (j.linked && j.linked_at) sv().linkedAt = j.linked_at; C.save(); emit(); } }
  catch (e) { /* offline or not deployed */ }
  return ST;
}
export const bonusPct = () => (ST ? +ST.bonus_pct || 0 : 0);
export const code = () => (ST && ST.code) || sv().code || null;
// training XP multiplier: server bonus + the new-player x2 for 24 h after the link
export function trainMul() { const L = sv().linkedAt, nw = L && Date.now() - L < NEW_MS ? NEW_MUL : 1; return nw * (1 + bonusPct() / 100); }
export const newBoostLeft = () => { const L = sv().linkedAt; return L ? Math.max(0, NEW_MS - (Date.now() - L)) : 0; };

export function link(c) {
  const url = new URL(location.origin + location.pathname); url.searchParams.set('ref', c); const st = Q.get('style'); if (st) url.searchParams.set('style', st); return url.toString();
}
// share: navigator.share, else copy to the clipboard. -> 'shared' | 'copied' | 'nocode' | 'fail'
export async function share() {
  const c = code(); if (!c) return 'nocode'; const url = link(c), text = 'Slash titans with me in Titan Slasher!';
  try { if (navigator.share) { await navigator.share({ title: 'Titan Slasher', text, url }); return 'shared'; } } catch (e) { if (e && e.name === 'AbortError') return 'fail'; }
  try { await navigator.clipboard.writeText(url); return 'copied'; } catch (e) { /* no clipboard */ }
  try { const t = document.createElement('textarea'); t.value = url; document.body.appendChild(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok ? 'copied' : 'fail'; } catch (e) { return 'fail'; }
}
// link this (new) player to a code: -> { ok, inviter } | { ok: false, error: code|self|linked|old|cycle|offline }
export async function enterCode(c) {
  c = String(c || '').trim().toUpperCase(); if (!/^[0-9A-F]{8,12}$/.test(c)) return { ok: false, error: 'code' };
  if (TEST != null) return { ok: true, inviter: 'TestFriend' };
  try { const j = await rpc('lb_ref_link', { p_code: c }); if (j && j.ok) { sv().linkedAt = Date.now(); sv().done = 1; C.save(); await status(); } return j || { ok: false, error: 'offline' }; }
  catch (e) { return { ok: false, error: 'offline' }; }
}
// may this player still type a code? (not linked, within the first day of this save)
export const canEnterCode = () => !(ST && ST.linked) && !sv().done && Date.now() - (sv().first || Date.now()) < NEW_MS;
// invitee: report the level (the server activates when it is plausible + store app + verified platform id)
async function report() {
  if (TEST != null || !ST || !ST.linked || ST.activated || !window.PROG) return; const s = window.PROG.state(); if (s.level < MIN_LV) return;
  try { const j = await rpc('lb_ref_progress', { p_lv: s.level, p_xp: s.total }); if (j && j.activated) { ST.activated = true; emit(); } } catch (e) { /* retried next boot / level */ }
}
// inviter: take the XP crates of new activations (coin-free) -> n
async function crates() {
  if (TEST != null || !ST || !(ST.crates > 0) || busy) return 0; busy = true;
  try { const j = await rpc('lb_ref_claim', {}); const n = j && j.ok ? j.n | 0 : 0; if (n && window.PROG) window.PROG.addXp(n * CRATE_XP, 'invite'); ST.crates = 0; emit(); return n; }
  catch (e) { return 0; } finally { busy = false; }
}
// native layer (store builds, later): the signed-in Game Center / Play Games account. kind 'gc' | 'pg', proof = the verification
// payload (Game Center signature bundle / Play Games server auth code) for the server-side check (TODO in server/referrals.sql).
export async function setPlatformId(kind, id, proof) {
  sv().plat = { kind, id }; C.save();
  try { const j = await rpc('lb_set_platform', { p_kind: kind, p_pid: String(id), p_proof: proof == null ? null : JSON.stringify(proof) }); await report(); return j; } catch (e) { return { ok: false, error: 'offline' }; }
}

// boot: remember the first-open time, link from ?ref=, fetch the status, report / claim. Returns { linked, crates } for a toast.
export async function boot() {
  const R = sv(); if (!R.first) { R.first = Date.now(); C.save(); }
  let linked = null;
  const ref = Q.get('ref'); if (ref && !R.done && !R.tried) { R.tried = ref; C.save(); const r = await enterCode(ref); if (r.ok) linked = r.inviter || 'a friend'; else if (r.error !== 'offline') { R.done = 1; C.save(); } else delete R.tried; }
  await status(); await report(); const n = await crates();
  return { linked, crates: n };
}
// ctx: { SAVE, save, LB }
export function init(ctx) {
  C = ctx;
  if (window.PROG && window.PROG.setTrainMul) window.PROG.setTrainMul(trainMul);
  if (window.PROG) window.PROG.onChange((s) => { if (s.level >= MIN_LV && ST && ST.linked && !ST.activated) report(); });
  const L = lb(); if (L) L.setPlatformId = setPlatformId; // the native layer's hook: window.__lb.setPlatformId('gc', id, proof)
}

const REF = { init, boot, status, share, link, enterCode, canEnterCode, bonusPct, code, trainMul, newBoostLeft, isApp, setPlatformId, onChange, CRATE_XP };
if (typeof window !== 'undefined') window.REF = REF;
export default REF;
