// KILL FINISHER + ENDING (11-28; reached by a time-board kill). User: not a cutscene, "the actual player tapping it until the end,
// like a finishing move": the titan is dead but the game stays live for FIN seconds and EVERY TAP draws one slash where the finger
// is (straight lines; the crescent style is switched off, 11-28 user). When the window closes the
// whole screen is snapshotted once, breaks along exactly those cuts into paper pieces, falls to black, then TITAN SLAIN + time.
// Cheap on phones: while it falls the world is not rendered; all pieces are ONE mesh (+ one line mesh for their edges) moved in the
// vertex shader, textured with the snapshot. Everything is disposed at the end.
import * as THREE from 'three';

const FIN = 3, BREAK_AFTER = .35, TITLE_AFTER = 1.75, TITLE_HOLD = 2.2; // s: the tap window, window end -> the break, ...
const TITLE_ART = 'art/ui_ink/finish_it.webp'; // tools/make_finish_art.py
const INTRO = .5; // the first moment of the finisher (vignette fades in, FINISH IT! slams in); taps already cut during it
const MAX_CUTS = 45, MIN_CUTS = 3; // more taps than MAX still hit (hero + sound), no more cuts; fewer than MIN: the rest cut themselves
// slash1 / slash2: the circle the painted blade's white core follows (px of the image), its middle angle and sweep (rad)
const SPR = [{ file: 'art/slash1.webp', w: 381, h: 513, cx: 266.2, cy: 266.9, R: 210.5, mid: -3.023, lo: -1.632, hi: 1.576 },
  { file: 'art/slash2.webp', w: 466, h: 529, cx: 314.1, cy: 274.3, R: 186, mid: -3.085, lo: -2.0, hi: 1.923 }];
const Q = new URLSearchParams(location.search);
const rnd = (a, b) => a + Math.random() * (b - a), clamp = (v, a, b) => Math.max(a, Math.min(b, v));

let C = null, R = null; // C = { renderer, canvas, sfx }, R = the running ending
export function init(o) {
  C = o;
  window.__cut = state; // tests
  new Image().src = TITLE_ART; // ready before the first kill
}
export const on = () => !!R;
export const tapping = () => !!(R && !R.scene && R.t < FIN); // from the killing hit on: no dead moment (11-28 user "feels disconnected") // the finisher window: taps cut
export const dim = () => (R && !R.scene ? clamp((R.t + INTRO) / .22, 0, 1) : 0); // 0..1 zoom + vignette while the finisher is live
export const needsShot = () => !!(R && !R.scene && R.t >= FIN);
export const drawing = () => !!(R && R.scene); // true = render() replaces the game's picture
export const state = () => (R ? { style: R.style, t: R.t, fin: FIN, taps: R.taps, cuts: R.cuts.length, burst: R.burst, title: R.titleAt, end: R.end, pieces: R.pieces } : null);

export function start({ time = '', style = null } = {}) {
  stop();
  const st = 'lines'; // 11-28 user "disable the crescent ending": straight cuts only (to bring it back, pick 'crescent' here and load SPR in init)
  const W = C.canvas.clientWidth || innerWidth, H = C.canvas.clientHeight || innerHeight, burst = FIN + BREAK_AFTER;
  R = { style: st, time, t: -INTRO, W, H, burst, titleAt: burst + TITLE_AFTER, end: burst + TITLE_AFTER + TITLE_HOLD, cued: {}, cuts: [], taps: 0, scene: null, dispose: [],
    over: new THREE.Scene(), cam: new THREE.OrthographicCamera(0, W, 0, H, -10, 10) }; // CSS px, y down
  prompt(true); document.body.classList.add('finishing'); // the fight HUD steps aside for the prompt
}
const keep = (x) => { R.dispose.push(x); return x; };
// one slash through (x, y) (CSS px): a straight cut at a fresh angle, or a crescent swinging through the point
function addCut(x, y) {
  const i = R.cuts.length, { W, H } = R;
  let c;
  if (R.style === 'lines') {
    const a = ((28 + i * 124 + rnd(-14, 14)) % 180) * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a), s = i % 2 ? -1 : 1;
    c = { px: x, py: y, dx: dx * s, dy: dy * s, f: (qx, qy) => (qx - x) * -dy + (qy - y) * dx };
  } else {
    const spr = SPR[i % 2], th = rnd(0, Math.PI * 2), Rr = rnd(250, 360) * W / 540, cx = x - Rr * Math.cos(th), cy = y - Rr * Math.sin(th);
    c = { spr, th, R: Rr, cx, cy, flip: i % 2, f: (qx, qy) => Math.hypot(qx - cx, qy - cy) - Rr };
  }
  c.at = R.t;
  c.meshes = R.style === 'lines' ? [lineSlash(c, W, H, keep)] : crescentSlash(c, W, H, keep);
  for (const m of c.meshes) { m.frustumCulled = false; m.renderOrder = 2; R.over.add(m); } // above the paper pieces + their edges (made later)
  R.cuts.push(c);
}
// a tap during the window (screen px); false = not taken
export function tap(x, y) {
  if (!tapping()) return false;
  R.taps++;
  if (R.cuts.length < MAX_CUTS) addCut(x, y);
  return true;
}
// true once the ending has played out
export function update(dt) {
  if (!R) return true;
  if (!R.scene) { // the live window (waits at FIN for capture())
    R.t = Math.min(FIN, R.t + dt);
    return false;
  }
  const t = (R.t += dt);
  const cue = (key, at, fn) => { if (!R.cued[key] && t >= at) { R.cued[key] = 1; fn(); } };
  cue('burst', R.burst, () => C.sfx('ultracrit'));
  cue('title', R.titleAt, () => { C.sfx('victory'); title(R.time); });
  return t >= R.end;
}
// call right after the game has drawn its frame: when the window is over, snapshot it and build the paper
export function capture() {
  if (!needsShot()) return false;
  const src = C.canvas, snap = document.createElement('canvas'); snap.width = src.width; snap.height = src.height;
  snap.getContext('2d').drawImage(src, 0, 0);
  while (R.cuts.length < MIN_CUTS) addCut(rnd(.25, .75) * R.W, rnd(.2, .7) * R.H);
  prompt(false); build(snap); document.body.classList.remove('finishing'); document.body.classList.add('cutting');
  return true;
}
export function stop() {
  if (!R) return;
  for (const d of R.dispose) d.dispose();
  R = null;
  document.body.classList.remove('cutting', 'finishing');
  prompt(false);
  const el = document.getElementById('cutTitle'); if (el) el.remove();
}
// end of the ending: a short fade from black into whatever is behind (the results)
export function end() {
  if (!R) return;
  const v = document.createElement('div'); v.id = 'cutVeil'; document.body.appendChild(v);
  v.addEventListener('animationend', () => v.remove()); setTimeout(() => v.remove(), 900);
  stop();
}

function slashFrame(flare, fade) {
  for (const c of R.cuts) {
    const age = R.t - c.at;
    for (const m of c.meshes) { m.visible = age >= 0 && fade > 0 && (!m.userData.until || age <= m.userData.until);
      const mu = m.material.uniforms; if (mu.age) { mu.age.value = age; mu.flare.value = flare; mu.fade.value = fade; } }
  }
}
// the live window: the slashes over the game's own picture
export function overlay() {
  if (!R || R.scene) return;
  slashFrame(0, 1);
  const r = C.renderer, ac = r.autoClear;
  r.setRenderTarget(null); r.autoClear = false; r.render(R.over, R.cam); r.autoClear = ac;
}
export function render() {
  if (!R || !R.scene) return;
  const r = C.renderer, t = R.t, U = R.U, H = R.H;
  // the paper: dim and a flash when the window closes, then it falls
  const pre = t < R.burst, u = Math.max(0, t - R.burst), k = clamp((t - FIN) / .12, 0, 1);
  U.u.value = u;
  U.bright.value = pre ? 1 - .3 * k : 1;
  U.flash.value = pre ? Math.max(0, 1 - Math.abs(t - FIN - .06) / .08) * .35 : 0;
  U.edge.value = pre ? 0 : clamp(u / .22, 0, 1) * .65;
  R.white.material.opacity = !pre && u < .25 ? .86 * (1 - u / .25) : 0; R.white.visible = R.white.material.opacity > 0;
  const shake = pre ? 8 * H / 1168 * k : 0;
  R.paper.position.set(rnd(-shake, shake), rnd(-shake, shake), 0);
  slashFrame(Math.max(0, 1 - Math.abs(t - R.burst) / .16), u > 0 ? clamp(1 - u / .2, 0, 1) : 1);
  R.embers.visible = t >= R.titleAt; R.embers.material.uniforms.u.value = Math.max(0, t - R.titleAt);
  const col = new THREE.Color(); r.getClearColor(col); const al = r.getClearAlpha(), ac = r.autoClear;
  r.setRenderTarget(null); r.setClearColor(0x000000, 1); r.autoClear = true; r.render(R.scene, R.cam);
  r.setClearColor(col, al); r.autoClear = ac;
}

// ---------------------------------------------------------------- build (once, at the snapshot)
function build(snap) {
  const { W, H } = R, ky = H / 1168, scene = new THREE.Scene(), cuts = R.cuts;
  const tex = keep(new THREE.CanvasTexture(snap)); tex.colorSpace = THREE.NoColorSpace; tex.generateMipmaps = false; tex.minFilter = THREE.LinearFilter;
  const U = { map: { value: tex }, u: { value: 0 }, bright: { value: 1 }, flash: { value: 0 }, edge: { value: 0 }, k: { value: ky } };
  const paper = new THREE.Group(); scene.add(paper);
  const pieces = buildPieces(W, H, cuts, U, keep, paper);
  for (const c of cuts) for (const m of c.meshes) scene.add(m); // the slashes move from the overlay onto the paper
  const white = new THREE.Mesh(keep(new THREE.PlaneGeometry(W * 2, H * 2)), keep(new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthTest: false, side: THREE.DoubleSide })));
  white.position.set(W / 2, H / 2, 0); white.renderOrder = 3; scene.add(white);
  const embers = buildEmbers(W, H, keep); scene.add(embers);
  Object.assign(R, { scene, U, paper, white, embers, pieces });
}

const PIECE_VS = `uniform float u, k; attribute vec2 center, fl; attribute vec4 mv; varying vec2 vUv; varying float vA;
void main(){
  float gap = clamp(u / .22, 0., 1.), v = max(0., u - .22 - mv.w), m = min(1., v * 2.);
  vec2 d = position.xy - center;
  d.x *= 1. - .55 * abs(sin(fl.x * m + v * fl.y)) * m;               // paper flutter
  float a = mv.z * v; d = mat2(cos(a), sin(a), -sin(a), cos(a)) * d;
  vec2 p = center + d + mv.xy / 150. * 8. * gap + mv.xy * v + vec2(0., 750. * k * v * v);
  vA = clamp(1. - (v - .35) / .75, 0., 1.); vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 0., 1.); }`;
const PIECE_FS = `uniform sampler2D map; uniform float bright, flash; varying vec2 vUv; varying float vA;
void main(){ vec3 c = texture2D(map, vUv).rgb * bright; gl_FragColor = vec4(mix(c, vec3(1.), flash), vA); }`;
const EDGE_FS = `uniform float edge; varying vec2 vUv; varying float vA;
void main(){ gl_FragColor = vec4(.92, .96, .94, edge * vA); }`;

// a fine triangle grid split along every cut; touching triangles on the same side of every cut = one piece of paper
function buildPieces(W, H, cuts, U, keep, group) {
  const nx = 18, ny = Math.round(nx * H / W); let tris = [];
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    const x0 = i * W / nx, x1 = (i + 1) * W / nx, y0 = j * H / ny, y1 = (j + 1) * H / ny;
    tris.push({ p: [x0, y0, x1, y0, x1, y1], s: 0 }, { p: [x0, y0, x1, y1, x0, y1], s: 0 });
  }
  cuts.forEach((c) => {
    const out = [];
    for (const T of tris) {
      const p = T.p, f = [c.f(p[0], p[1]), c.f(p[2], p[3]), c.f(p[4], p[5])], sg = f.map((v) => v >= 0);
      if (sg[0] === sg[1] && sg[1] === sg[2]) { T.s = T.s * 2 + (sg[0] ? 1 : 0); out.push(T); continue; }
      const l = sg[0] !== sg[1] && sg[0] !== sg[2] ? 0 : sg[1] !== sg[0] && sg[1] !== sg[2] ? 1 : 2, a = (l + 1) % 3, b = (l + 2) % 3;
      const P = (i) => [p[i * 2], p[i * 2 + 1]], cross = (i, j) => { const q = f[i] / (f[i] - f[j]), A = P(i), B = P(j); return [A[0] + (B[0] - A[0]) * q, A[1] + (B[1] - A[1]) * q]; };
      const L = P(l), A = P(a), B = P(b), m = cross(l, a), n = cross(l, b), sl = T.s * 2 + (sg[l] ? 1 : 0), so = T.s * 2 + (sg[l] ? 0 : 1);
      out.push({ p: [...L, ...m, ...n], s: sl }, { p: [...m, ...A, ...B], s: so }, { p: [...m, ...B, ...n], s: so });
    }
    tris = out;
  });
  const key = (x, y) => `${Math.round(x * 4)},${Math.round(y * 4)}`;
  const parent = tris.map((_, i) => i), find = (i) => { while (parent[i] !== i) i = parent[i] = parent[parent[i]]; return i; }, seen = new Map();
  tris.forEach((T, i) => { for (let v = 0; v < 6; v += 2) { const kk = `${key(T.p[v], T.p[v + 1])}|${T.s}`, o = seen.get(kk); if (o == null) seen.set(kk, i); else parent[find(i)] = find(o); } });
  const groups = new Map();
  tris.forEach((T, i) => { const g = find(i); if (!groups.has(g)) groups.set(g, []); groups.get(g).push(T); });
  const pos = [], uv = [], cen = [], mv = [], fl = [], ep = [], euv = [], ecen = [], emv = [], efl = [];
  for (const list of groups.values()) {
    let area = 0, sx = 0, sy = 0; const edges = new Map();
    for (const T of list) {
      const p = T.p, a = Math.abs((p[2] - p[0]) * (p[5] - p[1]) - (p[4] - p[0]) * (p[3] - p[1])) / 2;
      area += a; sx += a * (p[0] + p[2] + p[4]) / 3; sy += a * (p[1] + p[3] + p[5]) / 3;
      for (let e = 0; e < 3; e++) { const i = e * 2, j = ((e + 1) % 3) * 2, k1 = key(p[i], p[i + 1]), k2 = key(p[j], p[j + 1]); if (k1 === k2) continue;
        const ek = k1 < k2 ? `${k1};${k2}` : `${k2};${k1}`; if (edges.has(ek)) edges.set(ek, null); else edges.set(ek, [p[i], p[i + 1], p[j], p[j + 1]]); }
    }
    if (area < .5) continue;
    const cx = sx / area, cy = sy / area, vx = cx - W / 2, vy = cy - H / 2, ln = Math.hypot(vx, vy) || 1, sp = rnd(40, 150), ky = H / 1168;
    const move = [(vx / ln * sp + rnd(-30, 30)) * ky, (vy / ln * sp * .4 - rnd(0, 120)) * ky, rnd(-80, 80) * Math.PI / 180, rnd(0, .42) + (1 - cy / H) * .12], flut = [rnd(0, 6.28), rnd(5, 10)];
    const push = (P, Uv, Ce, Mv, Fl, x, y) => { P.push(x, y, 0); Uv.push(x / W, 1 - y / H); Ce.push(cx, cy); Mv.push(...move); Fl.push(...flut); };
    for (const T of list) for (let v = 0; v < 6; v += 2) push(pos, uv, cen, mv, fl, T.p[v], T.p[v + 1]);
    if (area > 60) for (const e of edges.values()) if (e) { push(ep, euv, ecen, emv, efl, e[0], e[1]); push(ep, euv, ecen, emv, efl, e[2], e[3]); }
  }
  const geo = (P, Uv, Ce, Mv, Fl) => { const g = keep(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(Uv, 2));
    g.setAttribute('center', new THREE.Float32BufferAttribute(Ce, 2)); g.setAttribute('mv', new THREE.Float32BufferAttribute(Mv, 4)); g.setAttribute('fl', new THREE.Float32BufferAttribute(Fl, 2)); return g; };
  const mat = (fs) => keep(new THREE.ShaderMaterial({ uniforms: U, vertexShader: PIECE_VS, fragmentShader: fs, transparent: true, depthTest: false, depthWrite: false, side: THREE.DoubleSide }));
  const body = new THREE.Mesh(geo(pos, uv, cen, mv, fl), mat(PIECE_FS)); body.frustumCulled = false;
  const rim = new THREE.LineSegments(geo(ep, euv, ecen, emv, efl), mat(EDGE_FS)); rim.frustumCulled = false; rim.renderOrder = 1;
  group.add(body, rim);
  return groups.size;
}

const SCREEN_VS = `varying vec2 vP, vUv; varying vec2 vS; attribute vec2 st; void main(){ vP = position.xy; vUv = uv; vS = st; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }`;
const addMat = (keep, uniforms, fs) => keep(new THREE.ShaderMaterial({ uniforms, vertexShader: SCREEN_VS, fragmentShader: fs, transparent: true, depthTest: false, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
// ribbon along a polyline: st = (px across, signed; 0..1 along)
function ribbon(pts, half, keep) {
  const P = [], S = [], I = [];
  pts.forEach(([x, y], i) => { const [ax, ay] = pts[Math.max(0, i - 1)], [bx, by] = pts[Math.min(pts.length - 1, i + 1)], l = Math.hypot(bx - ax, by - ay) || 1, nx = -(by - ay) / l, ny = (bx - ax) / l, s = i / (pts.length - 1);
    P.push(x + nx * half, y + ny * half, 0, x - nx * half, y - ny * half, 0); S.push(half, s, -half, s); if (i) { const b = i * 2; I.push(b - 2, b - 1, b, b - 1, b + 1, b); } });
  const g = keep(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('st', new THREE.Float32BufferAttribute(S, 2)); g.setIndex(I); return g;
}
// a straight slash: sweeps across in .07 s, hot, then stays as a thin cut line
const LINE_FS = `uniform float age, flare, fade; varying vec2 vS;
void main(){ float grow = clamp(age / .07, 0., 1.), hot = max(0., 1. - age / .22), s = vS.y; if (s > grow) discard;
  float taper = 1. - abs(s / max(grow, .001) * 2. - 1.), d = abs(vS.x), w = (2. + 9. * hot + 6. * flare) * .5 * mix(.35, 1., taper);
  float core = 1. - smoothstep(w * .6, w, d), glow = exp(-d / (3. + 9. * max(hot, flare))) * (.43 + .57 * max(hot, flare));
  gl_FragColor = vec4(vec3(.96, 1., 1.) * core + vec3(.31, .92, .86) * glow, fade); }`;
function lineSlash(c, W, H, keep) {
  const L = Math.hypot(W, H) * .62, pts = [];
  for (let i = 0; i <= 1; i++) { const s = i * 2 - 1; pts.push([c.px + c.dx * L * s, c.py + c.dy * L * s]); }
  return new THREE.Mesh(ribbon(pts, 26, keep), addMat(keep, { age: { value: 0 }, flare: { value: 0 }, fade: { value: 1 } }, LINE_FS));
}
// a crescent: our painted blade swings through its own sweep and leaves a glowing curved cut
const MOON_FS = `uniform sampler2D map; uniform float age, th, lo, hi, flip; uniform vec2 c; varying vec2 vP, vUv;
void main(){ float grow = clamp(age / .075, 0., 1.), fade = age < .11 ? 1. : max(0., 1. - (age - .11) / .13);
  float rel = mod(atan(vP.y - c.y, vP.x - c.x) - th + 3.14159265, 6.2831853) - 3.14159265; if (flip > .5) rel = -rel;
  float a = flip > .5 ? -hi : lo, front = a + (hi - lo) * grow, wipe = clamp((front - rel) / .12, 0., 1.);
  gl_FragColor = vec4(texture2D(map, vUv).rgb * wipe * fade, 1.); }`;
// the crescent cuts glow exactly like the straight ones (user 11-28), in the blade's purple; glowK 0 = the rest of the circle, only hinted at the burst (the crescents stand out, not rings)
const ARC_FS = `uniform float age, flare, fade, glowK; varying vec2 vS;
void main(){ if (age < .05) discard; float hot = max(0., 1. - age / .22) * glowK, h = max(hot, flare), d = abs(vS.x), w = (2. + 9. * hot + 6. * flare) * .5;
  float core = (1. - smoothstep(w * .6, w, d)) * mix(.4, 1., max(glowK, flare * .35)), glow = exp(-d / (3. + 9. * h * max(glowK, .35))) * (.43 + .57 * h) * max(glowK, flare * .35);
  gl_FragColor = vec4(vec3(.97, .94, 1.) * core + vec3(.66, .36, 1.) * glow, fade); }`;
function crescentSlash(c, W, H, keep) {
  const sp = c.spr, k = c.R / sp.R, rot = c.th - sp.mid, co = Math.cos(rot), si = Math.sin(rot), out = [];
  if (sp.tex) {
    const P = [], UVs = [];
    for (const [x, y] of [[0, 0], [sp.w, 0], [0, sp.h], [sp.w, sp.h]]) { const dx = (x - sp.cx) * k, dy = (y - sp.cy) * k; P.push(c.cx + dx * co - dy * si, c.cy + dx * si + dy * co, 0); UVs.push(x / sp.w, 1 - y / sp.h); }
    const g = keep(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(UVs, 2));
    g.setAttribute('st', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0, 0, 0, 0], 2)); g.setIndex([0, 1, 2, 1, 3, 2]);
    const m = new THREE.Mesh(g, addMat(keep, { map: { value: sp.tex }, age: { value: 0 }, flare: { value: 0 }, fade: { value: 1 }, th: { value: c.th }, lo: { value: sp.lo - .35 }, hi: { value: sp.hi + .35 }, c: { value: new THREE.Vector2(c.cx, c.cy) }, flip: { value: c.flip } }, MOON_FS));
    m.userData.until = .24; m.renderOrder = 2; out.push(m);
  }
  const arc = (a0, a1, n) => Array.from({ length: n + 1 }, (_, i) => { const a = c.th + a0 + (a1 - a0) * i / n; return [c.cx + c.R * Math.cos(a), c.cy + c.R * Math.sin(a)]; });
  const a0 = Math.max(sp.lo, -1.35), a1 = Math.min(sp.hi, 1.35);
  const cut = (pts, glowK) => new THREE.Mesh(ribbon(pts, 26, keep), addMat(keep, { age: { value: 0 }, flare: { value: 0 }, fade: { value: 1 }, glowK: { value: glowK } }, ARC_FS));
  out.push(cut(arc(a0, a1, 40), 1), cut(arc(a1, a0 + Math.PI * 2, 60), 0)); // the sweep glows; the rest of the cut is a faint line
  return out;
}
function buildEmbers(W, H, keep) {
  const P = [], D = [], n = 70;
  for (let i = 0; i < n; i++) { P.push(rnd(0, W), rnd(H * .3, H * 1.1), 0); D.push(rnd(40, 130) * H / 1168, rnd(1.5, 4), rnd(0, 6)); }
  const g = keep(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('d', new THREE.Float32BufferAttribute(D, 3));
  const m = keep(new THREE.ShaderMaterial({ uniforms: { u: { value: 0 }, dpr: { value: Math.min(3, C.canvas.width / (C.canvas.clientWidth || C.canvas.width)) } }, transparent: true, depthTest: false, depthWrite: false,
    vertexShader: `uniform float u, dpr; attribute vec3 d; void main(){ vec3 p = position + vec3(sin(d.z + u * 2.) * 14., -d.x * u, 0.); gl_PointSize = d.y * 2. * dpr; gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.); }`,
    fragmentShader: `uniform float u; void main(){ if (length(gl_PointCoord - .5) > .5) discard; gl_FragColor = vec4(1., .81, .38, .82 * clamp(u / .22, 0., 1.)); }` }));
  const pts = new THREE.Points(g, m); pts.frustumCulled = false; pts.visible = false; pts.renderOrder = 4; return pts;
}

// ---------------------------------------------------------------- DOM: the HUD is hidden while the paper falls; the title
function prompt(show) {
  const old = document.getElementById('cutPrompt'); if (old) old.remove();
  if (!show) return;
  const el = document.createElement('div'); el.id = 'cutPrompt'; el.innerHTML = `<div class="cp-t"><img src="${TITLE_ART}" alt="Finish it!"></div>`; // 11-28 user: the painted title in the logo's style
  document.body.appendChild(el);
}
function title(time) {
  const el = document.createElement('div'); el.id = 'cutTitle';
  el.innerHTML = '<b>TITAN SLAIN</b><span></span>'; el.querySelector('span').textContent = time;
  document.body.appendChild(el);
}
if (typeof document !== 'undefined') {
  const s = document.createElement('style'); s.textContent = `
body.finishing #score, body.finishing #bottom, body.finishing #live, body.finishing #ticker, body.finishing #hint, body.finishing #tbHud { visibility: hidden !important; }
body.cutting > *:not(#gl):not(#cutTitle) { visibility: hidden !important; }
#cutTitle { position: fixed; left: 0; right: 0; top: 42%; transform: translateY(-50%); z-index: 90; pointer-events: none; display: flex; flex-direction: column; align-items: center; gap: 10px; animation: cutSlam .22s cubic-bezier(.2,.8,.3,1) both; }
#cutTitle b { font: 700 clamp(36px, 11.5vw, 72px)/1 Georgia, 'Times New Roman', serif; color: #ffd66c; text-shadow: 0 0 2px #281606, 0 3px 0 #281606, 0 0 18px rgba(255,190,80,.5); white-space: nowrap; }
#cutTitle span { font: 700 clamp(22px, 6.4vw, 40px)/1 Georgia, 'Times New Roman', serif; color: #f0faf6; font-variant-numeric: tabular-nums; text-shadow: 0 2px 0 #0a1414; animation: cutIn .3s .35s both; }
@keyframes cutSlam { from { opacity: 0; scale: 1.9; } to { opacity: 1; scale: 1; } }
@keyframes cutIn { from { opacity: 0; } to { opacity: 1; } }
#cutPrompt { position: fixed; left: 0; right: 0; top: calc(12% + var(--safeT, 0px)); z-index: 90; pointer-events: none; display: flex; flex-direction: column; align-items: center; gap: 2px; }
#cutPrompt .cp-t { width: min(97vw, 620px); animation: cpSlam .36s .3s cubic-bezier(.15,.9,.25,1.25) both; }
#cutPrompt img { display: block; width: 100%; height: auto; filter: drop-shadow(0 8px 14px rgba(0,0,0,.85)); animation: cpBeat .42s .66s ease-in-out infinite alternate; }
@keyframes cpSlam { from { opacity: 0; scale: 2.8; rotate: -7deg; } 60% { opacity: 1; } to { opacity: 1; scale: 1; rotate: 0deg; } }
@keyframes cpBeat { from { scale: 1; } to { scale: 1.05; } }
#cutVeil { position: fixed; inset: 0; background: #000; z-index: 4; pointer-events: none; animation: cutOut .6s ease-in forwards; }
@keyframes cutOut { from { opacity: 1; } to { opacity: 0; } }`;
  document.head.appendChild(s);
}
