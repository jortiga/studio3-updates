// Titan Slasher PROGRESSION UI (11-27): the DOM side of progression.js (levels / XP), drops.js (titan drops), autotrain.js
// (lobby auto-train + offline gains) and rewards.js (daily winner rewards). main.js only calls these hooks:
//   PUI.init(ctx) once (after LUI.init) · PUI.fightEnd(o) in showResults (XP + drops, returns the drop chips html) ·
//   PUI.tapXp() on every dummy / titan tap · PUI.lobby() on lobby entry · PUI.frame(dt) every frame · PUI.isAuto() (an auto hit).
// Everything else lives here: top-bar level + XP bar (lobby-ui.js #topbar .tb-id), the AUTO chip next to DAILY (#lchips),
// the LEVEL UP overlay on the results screen / lobby popup, offline-gains popup, winner-reward popup, auto-train upgrade panel,
// padlocks on the gear screen (inventory-ui.js reads EQ.canWear + PROG.reqLv), crowns next to yesterday's winners on boards.
// Styles: prog-ui.css. Sounds: A.sfx names that exist (rank, victory, card, coin, buy, click, deny).
import * as PROG from './progression.js';
import * as DROPS from './drops.js';
import * as AUTO from './autotrain.js';
import * as RW from './rewards.js';
import * as EN from './energy.js';
import * as GUILD from './guild.js'; // 11-27 user: guilds replace the friend invites (lobby GUILD chip + window; referral.js no longer wired)
import { UI, INK, itemIcon } from './uiart.js';

const $ = (id) => document.getElementById(id);
const PUPOPS = document.getElementsByClassName('pu-pop'); // live list of the auto-train / guild popups (PUI.closable)
const fmt = (n) => Math.round(n).toLocaleString('en-US');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let C = null, uiT = 0, crownT = 0, popBusy = false, autoNow = false, lobbyQ = false, rewardChecked = false, lastXp = '';
const sfx = (n) => { try { C.A.sfx(n); } catch (e) { /* audio not ready */ } };

// ctx: { SAVE, save, A, EQ, INV, LB, TIX, MENU, state(), titanIdx(), autoHit() (one normal dummy hit, aimed like the ?auto=1 bot) }
export function init(ctx) {
  C = ctx;
  const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'prog-ui.css'; document.head.appendChild(css);
  const now = () => { try { const n = window.DAILY?._now?.(); if (isFinite(n)) return n; } catch (e) { /* */ } return Date.now(); };
  PROG.init({ SAVE: C.SAVE, save: C.save, EQ: C.EQ, energy: EN, now, chestItem: (r) => DROPS.chestItem(r, C.EQ) });
  DROPS.init(C.EQ);
  AUTO.init({ SAVE: C.SAVE, save: C.save, now, level: () => PROG.level(), inLobby: () => C.state() === 'lobby',
    addXp: (n, src) => { const r = PROG.addXp(n, src); if (r.ups.length) lobbyQ = true; return r; } }); // offline XP (not tapping)
  AUTO.resume(); // boot: freeze the time away (shown at the first lobby entry)
  RW.init({ SAVE: C.SAVE, save: C.save, EQ: C.EQ, PROG, energy: EN, chestItem: (r) => DROPS.chestItem(r, C.EQ), LB: C.LB });
  GUILD.init({ SAVE: C.SAVE, save: C.save, LB: C.LB, EQ: C.EQ, chestItem: (r) => DROPS.chestItem(r, C.EQ) });
  setTimeout(() => GUILD.refresh(), 2500); // GUILD chip badge (welcome chest waiting); lobby() refreshes it at most every 3 min
  PROG.onChange(() => { uiT = 0; });
  document.addEventListener('visibilitychange', () => { if (document.hidden) AUTO.mark(); else if (C.state() === 'lobby') { AUTO.resume(); lobbyQ = true; } });
  // top bar XP bar + AUTO chip (lobby-ui.js DOM; guarded: ?ui=1 has no bars)
  const id = document.querySelector('#topbar .tb-id'); if (id && !id.querySelector('.pu-xp')) id.insertAdjacentHTML('beforeend', '<i class="pu-xp"><i></i></i>');
  const chips = $('lchips');
  if (chips && !chips.querySelector('[data-k="auto"]')) {
    chips.insertAdjacentHTML('beforeend', `<button class="chip pu-auto" data-k="auto" aria-label="Auto-train"><img src="" alt=""><small>AUTO</small><i class="pu-lock">&#128274;</i><i class="pu-cog" aria-label="Upgrades">&#9881;</i></button>`);
    const b = chips.querySelector('[data-k="auto"]');
    b.addEventListener('click', (e) => { e.stopPropagation(); e.stopImmediatePropagation(); onAutoChip(e); }, true);
    chips.insertAdjacentHTML('beforeend', `<button class="chip pu-invc" data-k="guild" aria-label="Guild"><img src="${INK ? 'art/ui_ink/kit/ic_invite.webp' : `${UI}/ic_profile.webp`}" alt=""><small>GUILD</small><i class="badge"></i></button>`); // badge = unclaimed welcome chest (paint())
    chips.querySelector('[data-k="guild"]').addEventListener('click', (e) => { e.stopPropagation(); e.stopImmediatePropagation(); C.A.init?.(); sfx('click'); guildPanel(); }, true);
  }
  window.PUI = { closable: () => { for (const p of PUPOPS) if (p.classList.contains('pu-up') || p.classList.contains('pu-inv')) return true; return false; }, /* 11-27 PERF PASS: main.js #popX asks every frame - a live collection instead of a querySelector (~0.8% CPU) */ close: () => { const p = document.querySelector('.pu-pop.pu-up, .pu-pop.pu-inv'); if (p) { p.remove(); popBusy = false; lobbyQ = true; } }, // main.js #popX
    panel: autoPanel, guild: () => guildPanel(), offline: () => offlinePop(AUTO.resume()), reward: () => checkReward(true) };
}
export const isAuto = () => autoNow;

// ---------------------------------------------------------------- fight end (results screen)
// o: { score, rank, n, runes, combo, limits, titan (id) } -> { xp, drops, html (drop chips for #resRewards) }
export function fightEnd(o) {
  const xr = payFight(), dr = DROPS.roll(o);
  const html = `<span class="pu-xpg">+${fmt(xr.gained)} XP</span>${dr.rolls.length ? '<i class="pu-br"></i>' : ''}` + dr.rolls.map((r) => dropChip(r)).join(''); // coins + XP, then the drop chips on their own line
  quietLevels();
  return { xp: xr, drops: dr, html };
}
function dropChip(r) {
  const E = C.EQ, d = E.DATA.byId[r.id], R = E.DATA.rarity[d.rarity], lk = !E.canWear({ id: r.id });
  const inner = `<img class="${d.slot === 'weapon' ? 'wpn' : ''}" src="${itemIcon(d.icon)}" alt=""><span class="pu-dn"><small>${r.dup ? 'ANOTHER COPY' : 'NEW ITEM'}</small><b>${esc(d.name)}</b></span>${lk ? `<em>Lv ${PROG.reqLv(d)}</em>` : ''}${r.sig ? '<s>&#9733;</s>' : ''}`;
  // 11-27 user "have them click it too": the drop arrives as a CLOSED chest; tapping it opens it (main.js results) and shows the item
  return `<button class="lchip pu-drop pu-chest${lk ? ' lock' : ''}${r.sig ? ' sig' : ''}" style="--c:${R.color}" title="${esc(d.name)}"><img class="pu-ch" src="${UI}/daily/chest_${Math.min(3, d.rarity)}.webp" alt=""><b>TAP TO OPEN</b><template>${inner}</template></button>`;
}

// ---------------------------------------------------------------- LEVEL UP (results overlay / lobby popup)
function sparks(host, n, col) {
  for (let i = 0; i < n; i++) { const s = document.createElement('i'); s.className = 'pu-spark'; const a = Math.random() * Math.PI * 2, r = 70 + Math.random() * 110;
    s.style.cssText = `--c:${col};--x:${Math.cos(a) * r}px;--y:${Math.sin(a) * r * .85}px;animation-delay:${Math.random() * .15}s`; host.appendChild(s); setTimeout(() => s.remove(), 1300); }
}
// 11-28 user "we don't need a popup for levelling up": level-ups are silent (the top bar shows the level, a level chest goes
// straight into the bag); only the GEAR tab badge for newly wearable gear stays
function quietLevels() {
  if (!PROG.peekPending().length) return; const ups = PROG.takePending();
  if (ups.some((u) => (u.unlocks || []).length)) { const S = C.SAVE; const mx = Math.max(0, ...C.EQ.items().map((it) => it.uid)); if (S.gearSeen == null || S.gearSeen >= mx) S.gearSeen = mx - 1; C.save(); }
}

// ---------------------------------------------------------------- lobby
export function lobby() { if (fightTaps) payFight(); AUTO.mark(); lobbyQ = true; GUILD.refresh(); }
// 11-28 the player's taps (auto-train hits pay nothing). A dummy tap pays at once (level-ups are silent, see quietLevels); titan taps are counted and paid together
// when the fight ends (no level-up side effects mid-fight)
let fightTaps = 0;
const payFight = () => { const n = fightTaps; fightTaps = 0; return PROG.fight(n); };
export function tapXp() { if (autoNow) return; /* auto-train is for show */ if (C.state() !== 'lobby') { fightTaps++; return; } AUTO.tapped(); if (PROG.tap().ups.length) lobbyQ = true; }
function otherOpen() {
  if (popBusy || document.querySelector('.pu-pop')) return true;
  if (window.DAILY?.isOpen?.() || C.MENU?.isOpen?.() || C.INV?.isOpen?.()) return true;
  const ep = $('enPop'); if (ep && !ep.classList.contains('hidden')) return true;
  return !!document.querySelector('#lbNick:not(.hidden)');
}
async function lobbyQueue() {
  if (C.state() !== 'lobby' || otherOpen()) return; lobbyQ = false;
  quietLevels();
  const g = !AUTO.OFF && C.SAVE.auto && C.SAVE.auto.pend; if (g) { offlinePop(g); return; }
  if (!rewardChecked) { rewardChecked = true; checkReward(); }
}
function popup(html, cls = '') {
  const o = document.createElement('div'); o.className = `panel pu-pop ${cls}`; o.innerHTML = `<div class="pu-frame">${html}</div>`; document.body.appendChild(o);
  for (const ev of ['pointerdown', 'touchstart']) o.addEventListener(ev, (e) => e.stopPropagation(), { passive: true });
  o.addEventListener('click', (e) => e.stopPropagation()); popBusy = true;
  const close = () => { o.remove(); popBusy = false; lobbyQ = true; }; return { o, close };
}
const hm = (s) => { const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`; };
function offlinePop(g) {
  if (!g) return; const ad = AUTO.adReady();
  const { o, close } = popup(`<small class="pu-k">TRAINING</small><h2>WHILE YOU WERE AWAY</h2><p class="pu-s">${hm(g.secs)} of training${g.capped ? ` <em>(cap ${AUTO.capH()} h)</em>` : ''}</p>
    <div class="pu-gain"><b class="xp">+${fmt(g.xp)} XP</b></div>
    <div class="pu-btns">${ad ? `<button class="btn pu-ad">&#9654; WATCH AD x${AUTO.AD_MULT}</button>` : ''}<button class="btn hot pu-ok">CLAIM</button></div>`, 'pu-off');
  sfx('card');
  const pay = (r) => { if (!r) return; sfx('buy'); close(); };
  o.querySelector('.pu-ok').onclick = () => { sfx('click'); pay(AUTO.claimOffline(1)); };
  const a = o.querySelector('.pu-ad'); if (a) a.onclick = async () => { sfx('click'); a.disabled = true; pay(await AUTO.claimWithAd()); };
}
async function checkReward(force) {
  const w = await RW.check(); if (!w) return;
  if (!force && (C.state() !== 'lobby' || otherOpen())) { setTimeout(() => checkReward(), 1500); return; }
  const E = C.EQ, r = RW.chestRarity(w.chest), R = r != null && E.DATA ? E.DATA.rarity[r] : null;
  const rows = [`<li><span><i class="gem">&#9670;</i></span> ${fmt(w.coins)} coins</li>`];
  if (R) rows.push(`<li style="--c:${R.color}"><img src="${UI}/daily/chest_${Math.min(3, r)}.webp" alt=""> ${w.chest === 'fine' ? 'Fine' : R.name} chest</li>`);
  if (w.energy) rows.push(`<li><span>&#9889;</span> +${w.energy} energy</li>`);
  if (w.title) rows.push(`<li class="hi"><span>&#9819;</span> "${esc(w.title.toUpperCase())}" title for today</li>`);
  const { o, close } = popup(`<small class="pu-k">${w.yesterday ? 'YESTERDAY' : 'A PAST DAY'}</small><h2>YOU PLACED <b class="pu-rank">#${w.rank}</b></h2><p class="pu-s">vs ${esc(w.titanName)} &middot; ${fmt(w.damage)} damage</p>
    <ul class="pu-rw">${rows.join('')}</ul><div class="pu-btns"><button class="btn hot pu-ok">CLAIM</button></div><p class="pu-err"></p>`, 'pu-win');
  sfx(w.rank <= 3 ? 'victory' : 'rank'); sparks(o.querySelector('.pu-frame'), w.rank <= 3 ? 26 : 12, '#ffd35a');
  const b = o.querySelector('.pu-ok');
  b.onclick = async () => { sfx('click'); b.disabled = true; const res = await RW.claim(w);
    if (!res.ok) { if (res.error === 'claimed' || res.error === 'none' || res.error === 'expired') return close(); b.disabled = false; o.querySelector('.pu-err').textContent = 'Could not reach the server. Try again.'; return; }
    const p = res.paid, d = p.chest && p.chest.id && E.DATA.byId[p.chest.id];
    o.querySelector('.pu-frame').innerHTML = `<small class="pu-k">CLAIMED</small><h2>REWARDS</h2><ul class="pu-rw"><li><span><i class="gem">&#9670;</i></span> +${fmt(p.coins)}</li>${d ? `<li style="--c:${E.DATA.rarity[d.rarity].color}"><img class="${d.slot === 'weapon' ? 'wpn' : ''}" src="${itemIcon(d.icon)}" alt=""> <b>${esc(d.name)}</b> ${p.chest.dup ? '+1 LV' : 'NEW!'}</li>` : ''}${p.xp ? `<li>+${fmt(p.xp)} XP</li>` : ''}${p.energy ? `<li>&#9889; +${p.energy}</li>` : ''}</ul><div class="pu-btns"><button class="btn hot pu-ok">NICE</button></div>`;
    sfx('buy'); o.querySelector('.pu-ok').onclick = () => { sfx('click'); close(); }; };
}

// ---------------------------------------------------------------- AUTO chip + upgrade panel
function onAutoChip(e) {
  C.A.init?.();
  if (!AUTO.unlocked()) { sfx('deny'); toast(`AUTO-TRAIN unlocks at Lv ${AUTO.UNLOCK_LV} \u00b7 you still earn offline XP`); return; }
  if (e.target.closest('.pu-cog')) { sfx('click'); return autoPanel(); }
  sfx('click'); AUTO.toggle(); uiT = 0; toast(AUTO.isOn() ? 'AUTO-TRAIN ON' : 'AUTO-TRAIN OFF');
}
function autoPanel() {
  if (!AUTO.unlocked()) return;
  const { o, close } = popup('', 'pu-up');
  const draw = () => {
    const rows = AUTO.upgrades().map((u) => `<div class="pu-row"><div><b>${u.name}</b><small>Lv ${u.lv}/${u.max} &middot; ${u.now}${u.next ? ` &#9656; ${u.next}` : ''}</small></div>${u.cost == null ? '<button class="btn" disabled>MAX</button>' : `<button class="btn hot" data-k="${u.k}" ${u.can ? '' : 'data-short="1"'}><i class="gem">&#9670;</i> ${fmt(u.cost)}</button>`}</div>`).join('');
    o.querySelector('.pu-frame').innerHTML = `<small class="pu-k">TRAINING GROUND</small><h2>AUTO-TRAIN</h2>
      <p class="pu-s">Your hero slashes the dummy, just for show. XP comes from your taps; while you are not tapping you earn offline XP (up to ${AUTO.capH()} h).</p>
      <button class="btn pu-tog">${AUTO.isOn() ? 'ON &#10003;' : 'OFF'}</button>${rows}<p class="pu-s"><i class="gem">&#9670;</i> ${fmt(C.SAVE.coins)}</p>`;
    o.querySelector('.pu-tog').onclick = () => { sfx('click'); AUTO.toggle(); draw(); };
    o.querySelectorAll('[data-k]').forEach((b) => { b.onclick = () => { const r = AUTO.buy(b.dataset.k); sfx(r.ok ? 'buy' : 'deny'); draw(); }; });
  };
  o.addEventListener('click', (e) => { if (e.target === o) { sfx('click'); close(); } });
  draw();
}
// ---------------------------------------------------------------- GUILD window (lobby GUILD chip; 11-27 replaced the INVITE window)
// guild.js does the server calls (server/guild.sql); every rule is checked there. Join from Lv 1 with a guild ID (one guild at a
// time), guilds unlock at Lv 10 (GUILD.MIN_LV). No copy button (user): the ID is shown plainly. Live since 11-27 (no "coming soon"
// state). 11-27 LEAVE GUILD: small button at the bottom -> confirm step inside the window -> join / found screen with the cooldown.
const GERR = { format: 'A guild ID is 6 letters / digits', code: 'No guild with that ID. Check the letters', self: "That's your own guild", in_guild: 'You are already in a guild',
  none: 'You are not in a guild any more', full: 'That guild is full', rate: 'Too many tries. Wait an hour and try again', lv: `Guilds unlock at Lv ${GUILD.MIN_LV}`,
  fights: 'Fight a few ranked titans first', xp: 'Keep playing a little longer, then try again', name: '3-24 letters, digits or spaces. Pick another name', master: 'Only the guild master can rename',
  offline: 'No connection. Try again' };
const hhmm = (s) => { const m = Math.ceil(s / 60); return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; };
// shard bonus by member count; n = the player's guild size (0 = no guild)
const pct = (v) => `+${+(v * 100).toFixed(1)}%`;
function gbonus(n) {
  const next = n ? GUILD.nextAt(n) : 0, big = n ? pct(GUILD.tier(n)) : `+${GUILD.BONUS_MIN}% to +${GUILD.BONUS_MAX}%`;
  const sub = !n ? `Grows with members &middot; max with ${GUILD.CAP}` : next ? `${pct(GUILD.tier(next))} at ${next} members &middot; max +${GUILD.BONUS_MAX}%` : 'Full guild: max bonus';
  return `<div class="pu-gbonus"><small>GUILD BONUS &middot; MORE SHARDS FROM TITAN FIGHTS</small><b>${big}</b><em>${sub}</em></div>`;
}
function guildPanel() {
  const { o, close } = popup('<small class="pu-k">GUILD</small><h2>GUILD</h2><p class="pu-s">&middot;&middot;&middot;</p>', 'pu-inv pu-guild');
  let busy = false, editing = false, leaving = false; // leaving = the LEAVE confirm step is shown
  const err = (e, r) => (e === 'fights' && r && r.need ? `Fight ${r.need} ranked titans first (${+r.have || 0} / ${r.need})`
    : e === 'cooldown' && r ? `You can join another guild in ${hhmm(+r.wait_s || 0)}` : GERR[e] || 'Something went wrong. Try again');
  const ago = (ms) => { if (!ms) return ''; const m = Math.max(0, (Date.now() - ms) / 60000); return m < 10 ? 'online' : m < 60 ? `${Math.round(m)}m ago` : m < 1440 ? `${Math.round(m / 60)}h ago` : `${Math.round(m / 1440)}d ago`; };
  const draw = (msg = '', fmsg = '') => { // msg = join / guild message, fmsg = FOUND MY GUILD message (shown under that button)
    if (!o.isConnected) return; const S = GUILD.state(), F = o.querySelector('.pu-frame'), lv = PROG.default.state().level;
    if (!S) { F.innerHTML = '<small class="pu-k">GUILD</small><h2>GUILD</h2><p class="pu-s">&middot;&middot;&middot;</p>'; return; }
    if (S.st !== 'ok') { F.innerHTML = '<small class="pu-k">GUILD</small><h2>GUILDS</h2><p class="pu-s">No connection. Guilds need the internet.</p><div class="pu-btns"><button class="btn pu-retry">TRY AGAIN</button></div>';
      F.querySelector('.pu-retry').onclick = () => { sfx('click'); F.querySelector('.pu-s').innerHTML = '&middot;&middot;&middot;'; GUILD.load().then(() => draw()); }; return; }
    const g = S.guild;
    if (!g) leaving = false;
    if (!g && lv < GUILD.MIN_LV) { // 11-28 user: level based lock
      F.innerHTML = `<small class="pu-k">GUILD</small><h2>GUILDS</h2><div class="pu-glock"><i>&#128274;</i> Unlocks at Lv ${GUILD.MIN_LV}<small>You are Lv ${lv}</small></div>${gbonus(0)}`; return; }
    if (g && leaving) {
      const h = +(S.cooldown_h ?? 24), again = h > 0 ? `You can join another in ${h} h.` : 'You can join another right away.';
      const what = !g.is_master ? '' : g.next_master ? `<b>${esc(g.next_master)}</b> becomes master. ` : 'The guild will be deleted and its ID stops working. ';
      F.innerHTML = `<small class="pu-k">LEAVE GUILD</small><h2>Leave ${esc(g.name)}?</h2><p class="pu-s">${what}${again}</p>
        ${S.welcome ? '<p class="pu-s pu-note">Your unopened welcome chest waits for your next guild.</p>' : ''}<p class="pu-err">${esc(msg)}</p>
        <div class="pu-btns"><button class="btn hot pu-gstay">STAY</button></div><div class="pu-btns"><button class="btn pu-gyes">LEAVE</button></div>`;
      const stay = F.querySelector('.pu-gstay'), yes = F.querySelector('.pu-gyes');
      stay.onclick = () => { if (busy) return; sfx('click'); leaving = false; draw(); };
      yes.onclick = async () => { if (busy) return; busy = true; yes.disabled = stay.disabled = true; sfx('click'); const name = g.name; const r = await GUILD.leave(); busy = false;
        if (r.ok) { leaving = false; toast(r.deleted ? `${name} was deleted` : `You left ${name}`); draw(); }
        else if (r.error === 'none') { leaving = false; draw(err(r.error)); }
        else { sfx('deny'); draw(err(r.error)); } };
      return;
    }
    if (g) {
      const rows = (g.members || []).map((m) => `<li class="${m[2] ? 'gm' : ''}${m[3] ? ' me' : ''}"><i>${m[2] ? '&#9819;' : ''}</i><span>${esc(m[0])}${m[3] ? ' <em>YOU</em>' : ''}</span><small>${m[1] ? 'Lv ' + m[1] : ''}</small><s>${m[3] ? '' : ago(m[4])}</s></li>`).join('');
      F.innerHTML = `<small class="pu-k">${g.is_master ? 'YOUR GUILD &middot; MASTER' : 'YOUR GUILD'}</small>
        ${editing ? `<div class="pu-enter"><input class="pu-in pu-gname" maxlength="24" value="${esc(g.name)}" autocomplete="off" spellcheck="false"><button class="btn pu-gsave">SAVE</button></div>`
          : `<h2>${esc(g.name)}${g.is_master ? ' <button class="pu-gren" aria-label="Rename">&#9998;</button>' : ''}</h2>`}
        <small class="pu-k pu-gidk">GUILD ID</small><div class="pu-code">${esc(g.code)}</div>
        ${g.is_master ? '<p class="pu-s">Share this ID with friends. They enter it under JOIN A GUILD.</p>' : ''}
        <div class="pu-gain sm"><b>${fmt(g.count)}<small>/ ${fmt(g.cap)} MEMBERS</small></b><b class="xp">${esc(g.master)}<small>MASTER</small></b></div>${gbonus(+g.count || 1)}
        ${S.welcome ? '<div class="pu-btns"><button class="btn hot pu-gchest">OPEN WELCOME CHEST</button></div>' : ''}
        <ul class="pu-glist">${rows}</ul><p class="pu-err">${esc(msg)}</p><button class="pu-gleave">LEAVE GUILD</button>`;
      F.querySelector('.pu-gleave').onclick = () => { if (busy) return; sfx('click'); leaving = true; editing = false; draw();
        GUILD.load().then(() => { if (leaving && !busy) draw(); }); }; // fresh member list: who becomes master
      const rn = F.querySelector('.pu-gren'); if (rn) rn.onclick = () => { sfx('click'); editing = true; draw(); F.querySelector('.pu-gname')?.focus(); };
      const sv = F.querySelector('.pu-gsave'); if (sv) { const inp = F.querySelector('.pu-gname'); inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') sv.click(); });
        sv.onclick = async () => { if (busy) return; busy = true; sfx('click'); const r = await GUILD.rename(inp.value); busy = false; if (r.ok) { editing = false; sfx('buy'); toast('Guild renamed'); draw(); } else { sfx('deny'); editing = true; draw(err(r.error)); } }; }
      const ch = F.querySelector('.pu-gchest'); if (ch) ch.onclick = async () => { if (busy) return; busy = true; ch.disabled = true; sfx('click'); const r = await GUILD.claim(); busy = false;
        if (!r.ok) { draw(r.error === 'claimed' || r.error === 'none' ? '' : err(r.error)); return; }
        const d = r.id && C.EQ.DATA && C.EQ.DATA.byId[r.id]; draw(r.already ? 'This device already opened a welcome chest' : '');
        if (d && C.INV?.chestFx) C.INV.chestFx(d, r.dup, r.rarity || 0, 'WELCOME CHEST', () => draw()); // the shared chest animation (inventory-ui.js)
        else if (d) { sfx('buy'); toast(`Welcome chest: ${d.name}${r.dup ? ' (copy)' : ''}`); } };
      return;
    }
    const left = +S.attempts_left, wait = GUILD.cooldownLeft(), off = wait ? ' disabled' : ''; // wait = leave cooldown
    F.innerHTML = `<small class="pu-k">GUILD</small><h2>JOIN A GUILD</h2>
      ${gbonus(0)}${wait ? `<p class="pu-s pu-gcd">You can join another guild in <b>${hhmm(wait)}</b></p>` : '<p class="pu-s">Enter a friend\'s guild ID. One guild at a time.</p>'}
      <div class="pu-enter"><input class="pu-in" maxlength="6" placeholder="GUILD ID" autocomplete="off" autocapitalize="characters" spellcheck="false"${off}><button class="btn hot pu-go"${off}>JOIN</button></div>
      ${wait ? '' : left === 0 && !msg ? '<p class="pu-s pu-note">No tries left. Wait an hour and try again</p>' : left > 0 && left < 5 ? `<p class="pu-s pu-note">${left} tr${left === 1 ? 'y' : 'ies'} left this hour</p>` : ''}
      <p class="pu-err">${esc(msg)}</p>
      <small class="pu-k pu-gsep">YOUR OWN GUILD</small>
      <p class="pu-s">Found your guild and share its ID.</p><div class="pu-btns"><button class="btn pu-gnew"${off}>FOUND MY GUILD</button></div><p class="pu-err">${esc(fmsg)}</p>`;
    const inp = F.querySelector('.pu-in'); if (inp) { inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') F.querySelector('.pu-go').click(); }); inp.addEventListener('input', () => { inp.value = GUILD.clean(inp.value); });
      F.querySelector('.pu-go').onclick = async () => { if (busy) return; busy = true; sfx('click'); const r = await GUILD.join(inp.value); busy = false;
        if (r.ok) { sfx('buy'); toast(`Joined ${r.guild?.name || 'the guild'}!`); draw(); } else { sfx('deny'); const v = inp.value; draw(err(r.error)); const i2 = o.querySelector('.pu-in'); if (i2) i2.value = v; } }; }
    const nw = F.querySelector('.pu-gnew'); if (nw) nw.onclick = async () => { if (busy) return; busy = true; nw.disabled = true; sfx('click'); const r = await GUILD.create(); busy = false;
      if (r.ok) { sfx('buy'); toast('Your guild is ready. Share its ID!'); draw(); } else { sfx('deny'); draw('', err(r.error, r)); } };
  };
  o.addEventListener('click', (e) => { if (e.target === o) { sfx('click'); close(); } });
  const tick = setInterval(() => { // the cooldown clock; at 00:00 the inputs come back
    if (!o.isConnected) return clearInterval(tick); const b = o.querySelector('.pu-gcd b'); if (!b || busy) return; const w = GUILD.cooldownLeft();
    if (w) b.textContent = hhmm(w); else { draw(); GUILD.load().then(() => draw()); } }, 1000);
  draw(); GUILD.load().then(() => draw());
}
function toast(t) { let el = $('puToast'); if (!el) { el = document.createElement('div'); el.id = 'puToast'; document.body.appendChild(el); } el.textContent = t; el.classList.remove('on'); void el.offsetWidth; el.classList.add('on'); }

// ---------------------------------------------------------------- per frame
export function frame(dt) {
  if (!C) return;
  const st = C.state();
  if (st === 'lobby') { autoNow = true; try { AUTO.tick(dt, C.paused?.() ? null : C.autoHit); } finally { autoNow = false; } /* paused (3D gear view): no hits */ if (lobbyQ) lobbyQueue(); } // paused: 3D gear view (hero idle)
  uiT -= dt; if (uiT <= 0) { uiT = .25; paint(); }
  if (st !== 'fight') { crownT -= dt; if (crownT <= 0) { crownT = 1; crowns(); } }
}
function paint() {
  const s = PROG.default.state(), xs = `${s.level}|${s.xp}`;
  if (xs !== lastXp) { lastXp = xs; const b = document.querySelector('#topbar .pu-xp > i'); if (b) b.style.width = `${(s.frac * 100).toFixed(1)}%`;
    const me = document.querySelector('#topbar .tb-me'); if (me) me.style.setProperty('--xp', `${(s.frac * 100).toFixed(1)}%`); /* 11-27 radial XP ring (kit-ui.css) */ if (me) me.title = `Lv ${s.level} · ${fmt(s.xp)} / ${fmt(s.need)} XP`; }
  const gc = document.querySelector('#lchips .pu-invc'); if (gc) { gc.classList.toggle('bad', GUILD.hasWelcome()); // unclaimed guild welcome chest
    const gl = GUILD.locked(), gs = gc.querySelector('small'), gt = gl ? `LV ${GUILD.MIN_LV}` : 'GUILD'; gc.classList.toggle('locked', gl); if (gs.textContent !== gt) gs.textContent = gt; } // 11-28 guilds unlock at Lv 10
  const ch = document.querySelector('#lchips .pu-auto'); if (!ch) return; if (AUTO.OFF) { ch.style.display = 'none'; return; } // 11-27 auto-train removed
  const un = AUTO.unlocked(), on = AUTO.isOn(); ch.classList.toggle('locked', !un); ch.classList.toggle('on', on);
  const sm = ch.querySelector('small'), t = un ? (on ? 'AUTO ON' : 'AUTO') : `Lv ${AUTO.UNLOCK_LV}`; if (sm.textContent !== t) sm.textContent = t;
  const wd = C.EQ.weaponDef?.(), src = wd ? itemIcon(wd.icon) : `${UI}/ic_gear.webp`, im = ch.querySelector('img'); if (im.getAttribute('src') !== src) im.setAttribute('src', src);
}
// crowns next to yesterday's top 3 on any visible board (.lrow: name in the 2nd span) + today's title holder
let WIN = null;
function crowns() {
  if (!WIN) { WIN = {}; RW.winners().then((w) => { WIN = w || { top: [] }; }); return; }
  if (!WIN.top || !WIN.top.length) return;
  document.querySelectorAll('.lrow:not([data-cw])').forEach((row) => {
    row.dataset.cw = '1'; const sp = row.children[1]; if (!sp) return; const nm = (sp.firstChild && sp.firstChild.nodeType === 3 ? sp.firstChild.textContent : sp.textContent).trim();
    const w = WIN.top.find((x) => x.name === nm || (row.classList.contains('me') && nm === 'YOU' && x.name === C.LB.nick)); if (!w) return;
    sp.insertAdjacentHTML('afterbegin', `<i class="pu-crown c${w.rank}" title="#${w.rank} yesterday${w.title ? ' · ' + esc(w.title) : ''}">&#9819;</i>`);
  });
}
