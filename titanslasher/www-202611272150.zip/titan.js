// Titan animation, v2 (11-25 user: "the titan's 2D animation is shit, the entire shoulder is rotating"). Drives art/titan2/rig.json.
// Method (E:/jgmkr/.claude/skills/cutout-animation/SKILL.md):
//  - Keyframed acts per bone channel feed TARGETS. Every channel runs through a damped spring with its own stiffness / damping
//    by mass (heavy torso slow + well damped, fists / jaw lighter), so the chain overlaps for free; keys further down the chain
//    are also offset 3-6 frames (kd()).
//  - Giant timing: long anticipation, a hang, a FAST strike (8-10 frames), a hold on the contact, long recovery.
//  - Pauldrons (pd*) ride the CHEST and only lift / tilt a few degrees after the upper arm (sh*), which swings under them from
//    the shoulder ball joint. Joint targets are clamped to plausible ranges (LIM).
//  - v3 (11-25, user: "maybe we need some sort of IK ... find an IK library, we just bake it anyway"): the ARMS are authored as
//    FIST TARGET paths (tools/anim_spec.json) and baked OFFLINE to joint angles by tools/bake_anim.py (2-bone IK, outward-and-down
//    bend, joint limits, ikpy at the limits) -> art/titan2/anims.json, with a portrait variant whose fists are clamped into the
//    phone frame. Here the baked angles are only sampled (lerp) and fed to the per-joint springs as TARGETS, so the elbow still lags
//    the shoulder and moves follow through; breathing, rage shake and hit flinches are small additive angle offsets on top.
//  - 11-26 (user: "the stupid titan animation"): default source = per-move MIX (anims_mix.json, tools/mocap_to_2d.py mix),
//    bend-locked IK bake, and procedural SECONDARY layers on top of the baked tracks (post-spring, cheap): head / jaw / pauldrons /
//    rocks lag the body's acceleration on their own damped oscillators, breathing follows effort (held on wind-ups, exhale after),
//    fists clench into the contact, stone-grind micro-shake after impacts, sharp hit flinches (3-frame snap, heavy settle).
//  - Hit flinches are a separate ADDITIVE layer: per-area amounts that saturate and decay, mapped to small offsets, so fast
//    tapping reads as a heavy body taking blows, never as whole-body jerks.
import { SpringReact, HEAVY } from './titans/react.js';
const ease = (x) => x * x * (3 - 2 * x);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
// keyframe track: [[t, v, ease?], ...] -> value at u (smoothstep between keys, 'in' = accelerate, 'out' = decelerate, holds the ends)
function kf(u, keys) {
  if (u <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) { const [t1, v1, e] = keys[i]; if (u <= t1) { const [t0, v0] = keys[i - 1]; const x = (u - t0) / Math.max(1e-4, t1 - t0); const k = e === 'in' ? x * x * x : e === 'out' ? 1 - Math.pow(1 - x, 3) : e === 'lin' ? x : ease(x); return v0 + (v1 - v0) * k; } }
  return keys[keys.length - 1][1];
}
const kd = (u, d, keys) => kf(u - d, keys); // same track, offset down the chain (d s later)
// spring [stiffness, damping] per bone, by mass. Damping ratio d / (2 sqrt k): torso ~.85 (heavy, no wobble), arms ~.7, fists /
// jaw ~.6 (a little overshoot = stone settling), pauldrons ~.65 (armour lags the arm, then settles).
const STIFF = { root: [50, 13], hips: [55, 13], chest: [75, 15], neck: [70, 13], head: [80, 13], jaw: [150, 15], pdL: [85, 12], pdR: [85, 12],
  shL: [120, 16], shR: [120, 16], elL: [95, 13], elR: [95, 13], wrL: [170, 16], wrR: [170, 16] };
// joint ranges, side-normalised (value * side sign; + = arm out / up for sh, - = elbow folds). Applied to targets.
// v3: the elbow hinges both ways (the painted capsules have ball caps at both ends); the bake picks the bend (outward and down).
const LIM = { sh: [-1.3, 2.95], el: [-2.6, 2.8], wr: [-.85, .85], pd: [-.06, .14] }; // same as bake_anim.py LIM
// baked track sampler: frame index from time, lerp; loops wrap, one-shots hold their ends
function samp(arr, f, loop) { const n = arr.length; if (n === 1) return arr[0];
  if (loop) { f %= n; if (f < 0) f += n; const i = Math.floor(f), j = (i + 1) % n; return arr[i] + (arr[j] - arr[i]) * (f - i); }
  if (f <= 0) return arr[0]; if (f >= n - 1) return arr[n - 1]; const i = Math.floor(f); return arr[i] + (arr[i + 1] - arr[i]) * (f - i); }
const BAKED = { slamL: ['slamL', 0], slamR: ['slamL', 1], swipe: ['swipe', 0], throw: ['throw', 0], roar: ['roar', 0], guard: ['guard', 0], stagger: ['stagger', 0] }; // act -> [baked move, mirrored]

// MOTION (11-26, user: "maybe it has too much animation; maybe it should just be subtle"): global amplitude scales, set from the
// titan's titan.json "motion" block (titans/loader.js), defaults = subtle. amp = idle breathing / weight shift / idle arm drift /
// secondary + grind; flinch = per-hit reaction; act = how far the big moves go (blend over the idle pose); gap / gapRage = seconds
// between ambient big moves (main.js). ?motion=1 = the old full motion (amp, flinch, act 1, gaps 5-8 s / 3-4.5 s).
export const MOTION = { amp: .42, flinch: .3, act: .6, gap: [25, 40], gapRage: [12, 18] };
{ const q = new URLSearchParams(location.search).get('motion'); if (q != null) { const v = +q || 1; MOTION.force = v;
  Object.assign(MOTION, { amp: v, flinch: v, act: Math.min(1, v), gap: v >= 1 ? [5, 8] : [25, 40], gapRage: v >= 1 ? [3, 4.5] : [12, 18] }); } }
const MOTION0 = { ...MOTION, step: 0 };
export function setMotion(m) { if (MOTION.force != null) return; Object.assign(MOTION, MOTION0, m || {}); } // per titan, from the subtle defaults

// act durations (s) and the moment the hit lands (main.js reads hit / release from here)
export const ACTS = {
  slamL: { dur: 2.9, hit: 1.4 }, slamR: { dur: 2.9, hit: 1.4 }, swipe: { dur: 2.5, hit: 1.22 }, throw: { dur: 2.6, hit: 1.25 },
  roar: { dur: 2.7 }, guard: { dur: 1.2, hold: true }, stagger: { dur: 1.7 }, idle: { dur: 3 }, flinchHead: { dur: .8 }, flinchFist: { dur: .8 },
};

// effort per act (11-26): hold = breath held (0..1), exh = the exhale after the effort (0..1), clench = the striking fist squeezes
// into the contact. H = the act's contact time (main.js FX use the same ACTS.hit).
function effort(a, u) {
  const H = ACTS[a]?.hit || 0, D = ACTS[a]?.dur || 1;
  if (a === 'slamL' || a === 'slamR') return { hold: kf(u, [[.1, 0], [.4, 1], [H, 1], [H + .06, 0]]), exh: kf(u, [[H, 0], [H + .15, 1, 'out'], [H + .5, .8], [H + 1.3, 0]]),
    clench: kf(u, [[.3, 0], [H - .3, .4], [H - .02, 1, 'in'], [H + .3, 1], [H + .8, 0]]) };
  if (a === 'swipe') return { hold: kf(u, [[.1, 0], [.45, 1], [H, 1], [H + .06, 0]]), exh: kf(u, [[H, 0], [H + .15, .8, 'out'], [H + 1.0, 0]]),
    clench: kf(u, [[.3, 0], [H - .2, .4], [H - .02, 1, 'in'], [H + .25, 1], [H + .7, 0]]) };
  if (a === 'throw') return { hold: kf(u, [[.1, 0], [.4, 1], [H, 1], [H + .06, 0]]), exh: kf(u, [[H, 0], [H + .15, .8, 'out'], [H + 1.0, 0]]),
    clench: kf(u, [[.2, 0], [.6, .8], [H - .05, 1], [H + .02, -.6, 'lin'], [H + .5, 0]]) }; // releases the rock: the hand opens
  if (a === 'roar') return { hold: kf(u, [[0, 0], [.15, 1], [D - .45, 1], [D, 0]]), exh: kf(u, [[D - .5, 0], [D - .2, .5], [D + .5, 0]]), clench: kf(u, [[.3, 0], [.8, 1], [D - .6, 1], [D - .1, 0]]) };
  if (a === 'guard') return { hold: kf(u, [[0, 0], [.4, .7]]), exh: 0, clench: kf(u, [[0, 0], [.6, .7]]) };
  if (a === 'stagger') return { hold: 0, exh: kf(u, [[0, 0], [.1, 1, 'out'], [.5, .7], [1.6, 0]]), clench: 0 };
  return { hold: 0, exh: 0, clench: 0 };
}
// sharp flinch envelope (11-26): 0 -> 1 in 3 frames (ease-out), then a heavy settle that sags a little past rest and comes back
const HFL = HEAVY ? { r: .05, t: .15 } : { r: 1, t: 1 }; // 11-27 heavy hit flinch scale (titans/react.js HEAVY)
const flinchEnv = (a) => a < .05 ? 1 - Math.pow(1 - a / .05, 3) : kf(a, [[.05, 1], [.34, -.16], [.75, 0]]);
// deterministic stone-grind noise (two detuned sines per channel: crunchy, never periodic-looking)
const grindN = (t, i) => Math.sin(t * (53 + i * 7) + i * 1.7) * Math.sin(t * (31 + i * 5) + i);

// ?src=mocap (tools/mocap_to_2d.py -> anims_mocap.json): the baked moves carry their own dur / hit (CMU mocap, time-warped);
// apply them to ACTS so main.js times the FX and the act length to the new clips. Codex anims.json has none -> ACTS unchanged.
export function applyTiming(bk) {
  for (const a in BAKED) { const M = bk.moves[BAKED[a][0]]; if (!M) continue; if (M.dur) ACTS[a].dur = M.dur; if (M.hit) ACTS[a].hit = M.hit; }
}

export class TitanAnim {
  // baked = art/titan2/anims.json (tools/bake_anim.py); this.phone = true plays the portrait variant (fists clamped into frame)
  constructor(puppet, baked) {
    this.P = puppet; this.ch = {}; this.front = {}; this.bk = baked; this.phone = false; this.sec = {};
    this.fl = {}; // additive flinch layer: area -> { k (0..1, decays), d (screen side) }
    this.sx = { L: puppet.byName.shL.x, R: puppet.byName.shR.x, y: puppet.byName.shL.y };
    this.ikDbg = {}; // baked fist targets this frame (rig px, root space) for ?bones=1
    // 11-26 dummy-style spring reactions (titans/react.js): the struck part springs away from the tap, lagged down the chain
    this.react = new SpringReact(puppet, { k: 55, c: 9.5, gain: .55, max: .1, drift: .5, driftBones: ['chest', 'head', 'pdL', 'pdR'],
      bones: { head: { k: 70, c: 9, max: .14 }, jaw: { max: .08 }, chest: { k: 40, c: 10, max: .05 }, hips: { k: 35, c: 10, max: .03 }, wrL: { max: .2 }, wrR: { max: .2 }, elL: { max: .15 }, elR: { max: .15 } } });
  }
  // clear the procedural secondary state (review hook __g.animAt calls it with the spring reset)
  reset() { this.sec = {}; this.fl = {}; this.react.reset(); }
  // damped oscillator driven by a parent acceleration (secondary motion): x'' = -k x - c x' - g acc, sub-stepped
  osc(name, k, c, g, acc, n, h) { const o = this.sec[name] || (this.sec[name] = { x: 0, v: 0 });
    for (let i = 0; i < n; i++) { o.v += (-k * o.x - c * o.v - g * acc) * h; o.x += o.v * h; } return o.x; }
  // one arm's baked channels at time u: move name, the side whose track to read -> { sh, el, wr, front, snap, tx, ty }
  arm(name, side, u, out) {
    const M = this.bk.moves[name], c = M[side], f = u * this.bk.fps, ph = this.phone && c.psh;
    out.sh = samp(ph ? c.psh : c.sh, f, M.loop); out.el = samp(ph ? c.pel : c.el, f, M.loop); out.wr = samp(c.wr, f, M.loop);
    const fr = this.phone ? c.pfront || c.front : c.front, i = Math.min(M.n - 1, Math.max(0, Math.round(f))) % M.n;
    out.front = fr ? fr[i] : 0; out.snap = c.snap ? samp(c.snap, f, M.loop) : 1;
    out.tx = samp(this.phone ? c.ptx : c.tx, f, M.loop); out.ty = samp(this.phone ? c.pty : c.ty, f, M.loop); return out;
  }
  // raw velocity kick into a channel (kept for tools; flinches use the additive layer)
  kick(bone, prop, v) { this.chan(bone, prop).v += v; }
  chan(bone, prop) { const k = bone + '.' + prop; return this.ch[k] || (this.ch[k] = { x: 0, v: 0, bone, prop }); }
  // per-area hit reaction; dir = -1 / +1 (side of the hit as seen on screen), s = strength 0..1.5. Saturates at 1 per area.
  flinch(area, dir, s = 1, hit = null) {
    if (!area) area = 'chest';
    if (hit) this.react.hit(hit.bone, hit.x, hit.y, Math.min(1.5, s)); // physical spring push at the tap (titans/react.js)
    else this.react.shudder(Math.min(1.5, s), -(dir || 0)); // 11-27 HEAVY: blows without a tap point (finisher, limits) = body shudder
    s *= MOTION.flinch; // subtle by default: a light shudder, never a jerk
    const f = this.fl[area] || (this.fl[area] = { k: 0, d: 1, v: 0, age: 9, amp: 0 });
    f.k = Math.min(1, f.k + .45 * Math.min(1.5, s)); f.d = dir || f.d;
    // 11-26 SHARP REACTION: a 3-frame snap then a heavy settle (envelope in update), re-armed at most every 0.25 s so fast tapping
    // keeps the body tense (k) instead of jerking per tap; a weaker tap inside the window only tops the amplitude up
    if (f.age > .25) { f.age = 0; f.amp = Math.min(1.2, s); } else f.amp = Math.min(1.2, Math.max(f.amp, s));
    if (s >= 1) this.sec.grind = Math.max(this.sec.grind || 0, .6); // a heavy blow grinds the stone
    if (area.startsWith('rock')) { const hk = HEAVY ? .25 : 1; this.kick(area, 'x', 90 * hk * (dir || 1) * s); this.kick(area, 'r', 1.2 * hk * .5 * (dir || 1) * s); } // loose rocks can drift
  }
  // targets for this frame -> springs -> puppet pose. st: { act, u, rage, dormant, t, side }
  update(dt, st) {
    // humanoid repaints (11-26): MOTION.step = stepped, clockwork-precise timing (targets advance in ticks, the springs snap
    // through with overshoot); this.stiffOv = titan.json "springs" overrides; this.procFn = titan.json "proc" extras (gears spin,
    // clock hands tick, pistons slide, flicker), applied post-spring
    if (MOTION.step) { const q = MOTION.step; st = { ...st, t: Math.floor(st.t * q) / q, u: st.u != null ? Math.floor(st.u * q) / q : st.u }; }
    const T = {}; const set = (b, p, v) => { const k = b + '.' + p; T[k] = (T[k] || 0) + v; };
    const t = st.t, dorm = st.dormant || 0, am = MOTION.amp, live = (1 - dorm * .7) * am, rage = st.rage || 0;
    // additive arm angle offsets per side, side-normalised [sh, el, wr] (breath, rage, flinch, roar tremble, stagger wobble)
    const AD = { L: [0, 0, 0], R: [0, 0, 0] }; const aAdd = (L, sh, el = 0, wr = 0) => { const q = AD[L]; q[0] += sh; q[1] += el; q[2] += wr; };
    // ---- idle: slow weight shift, breathing (chest + shoulders rise, head / jaw lag), hanging arms, fists flex, rocks orbit ----
    // 11-25 Codex idle sheet + LTX idle clip: the breath must READ (chest + shoulders rise ~9 px, fists ride it), the weight shift
    // visibly tilts the shoulder line (~2.5 deg, hips lead, chest follows) while the head counter-tilts to stay level
    // 11-26 BREATH FOLLOWS EFFORT: held breath through a wind-up (chest stays filled, no rise and fall), a big exhale after the
    // strike (chest drops, shoulders sag, jaw parts), a winded gasp on the stagger; the roar replaces the breath entirely
    const ef = effort(st.act, st.u || 0), hold = ef.hold * MOTION.act, exh = ef.exh * MOTION.act;
    const bw = 1.55 + .9 * rage + .5 * exh, br = Math.sin(t * bw), brL = Math.sin(t * bw - .6), brJ = Math.sin(t * bw - 1.1), bA = live * (1 + .6 * rage) * (1 - hold);
    set('chest', 'y', -6 * hold + 5 * exh); set('chest', 'sy', .012 * hold - .02 * exh); set('chest', 'sx', .008 * hold);
    set('head', 'y', 3 * exh); set('jaw', 'y', 12 * exh); set('pdL', 'y', 5 * exh - 3 * hold); set('pdR', 'y', 5 * exh - 3 * hold);
    const ws = Math.sin(t * .32), wsL = Math.sin(t * .32 - .9); // weight shift ~20 s, the arms swing after it like pendulums
    const ib = this.bk.moves.idle.body; // mocap idle (CMU 'Strong Man Wait'): real weight shift / sway, looped; replaces the sine weight shift
    if (ib) { const iu = t % this.bk.moves.idle.dur; for (const k in ib) { const [bn, pr] = k.split('.'); set(bn, pr, kf(iu, ib[k]) * live * (HEAVY && bn === 'head' ? .3 : 1)); } } // 11-27 HEAVY: the head rides the body, its own mocap sway x .3
    else { set('hips', 'x', 10 * ws * live); set('hips', 'r', .03 * ws * live); set('chest', 'r', .014 * wsL * live); } // hips lead, chest follows late
    set('chest', 'y', -9 * br * bA); set('chest', 'sy', .015 * br * bA); set('chest', 'sx', .01 * br * bA);
    set('head', 'r', ((ib ? 0 : -.04 * wsL) + (HEAVY ? 0 : .03 * Math.sin(t * .23)) - .02 * brL) * live + dorm * .08); // 11-27 HEAVY: no head wobble of its own set('head', 'y', -3 * brL * bA + dorm * 12); // chin lifts on the inhale
    set('jaw', 'y', 3 * (1 - dorm * .7) + 2.5 * brJ * live);
    for (const [s, L] of [[1, 'L'], [-1, 'R']]) { const ph = s > 0 ? 0 : 1.9;
      aAdd(L, .035 * brL * bA - (ib ? 0 : .02 * s * wsL * live), -.045 * brL * bA); // the fists ride the breath (LTX idle: fists lift on the inhale), weight shift sways them
      set('pd' + L, 'y', -5 * br * bA); set('sh' + L, 'y', -5 * br * bA); // shoulders rise with the breath
      const flex = Math.max(0, Math.sin(t * .7 + ph * 2)) ** 2; // a slow squeeze every ~9 s per fist, the two out of phase
      aAdd(L, 0, 0, -.08 * flex * live); set('wr' + L, 'sx', -.045 * flex * live); set('wr' + L, 'sy', .025 * flex * live); }
    const ra = .5 + .5 * am; [1, 2, 3].forEach((i) => { const a = t * (.3 + i * .06) + i * 2.1; set('rock' + i, 'x', Math.cos(a) * 26 * ra); set('rock' + i, 'y', (Math.sin(a * 1.3) * 18 + Math.sin(t * .8 + i) * 8) * ra); set('rock' + i, 'r', Math.sin(t * .35 + i) * .2 * ra); });
    if (rage > 0) { const rq = rage * am; aAdd('L', .015 * Math.sin(t * 9) * rq, .015 * Math.sin(t * 11) * rq); aAdd('R', .015 * Math.sin(t * 9 + 1) * rq, .015 * Math.sin(t * 11 + 2) * rq); set('head', 'y', 6 * rage); } // fists shake with fury, head lowered
    // ---- acts ----
    this.front = {}; const snap = this.snap = {}; // snap[side] = arm spring speed-up for the FAST strike frames (stiffness x k^2), baked
    const a = st.act, u = st.u || 0;
    // fists clench into the contact (11-26): the striking fist squeezes (x narrower, y taller) and the wrist cocks; both on roar / guard
    if (ef.clench) { const sides = a === 'slamL' ? ['L'] : a === 'slamR' ? ['R'] : a === 'swipe' ? [(st.side || 1) > 0 ? 'L' : 'R'] : a === 'throw' ? ['R'] : ['L', 'R'];
      for (const L of sides) { set('wr' + L, 'sx', -.07 * ef.clench); set('wr' + L, 'sy', .045 * ef.clench); aAdd(L, 0, 0, -.12 * Math.max(0, ef.clench)); } }
    // contact = grind trigger (micro-shake of the stone body after the impact)
    const hitT = ACTS[a]?.hit, sc = this.sec;
    if (hitT && (sc.pu ?? 99) < hitT && u >= hitT && a !== 'throw') sc.grind = 1;
    sc.pu = a ? u : 99;
    // BODY CHANNELS from anim_spec.json (11-25 "Codex as animation director": poses measured off Codex keyframe sheets + LTX
    // reference clips). "bone.prop": keys; authored for the L-side move; mirrored moves negate .r / .x and swap L <-> R bones.
    // When a move has them, the hand-keyed body lines below are skipped (own = true); the procedural extras stay.
    const bm = a && BAKED[a], body = bm && this.bk.moves[bm[0]].body;
    const own = !!body;
    if (own) { const sg = a === 'slamR' ? -1 : (a === 'swipe' || a === 'stagger') ? (st.side || 1) : 1;
      for (const k in body) { const [bn, pr] = k.split('.'), b = sg < 0 ? bn.replace(/[LR]$/, (c) => (c === 'L' ? 'R' : 'L')) : bn;
        set(b, pr, (pr === 'r' || pr === 'x' ? sg : 1) * kf(u, body[k]) * MOTION.act); } }
    if (a === 'slamL' || a === 'slamR') {
      const L = a === 'slamL', s = L ? 1 : -1, S = L ? 'L' : 'R', O = L ? 'R' : 'L', H = ACTS[a].hit;
      // dip (0-.35) -> heave overhead (.35-1.05) -> hang + creep (1.05-1.26) -> DROP (1.26-1.4, 8 frames) -> contact hold to 1.85 -> slow lift back
      // arms: baked (anim_spec.json slamL: cocks low, heaved over the head, hang, DROP to the cloud sea beside the body, hold, back)
      if (!own) { set('chest', 'r', s * kf(u, [[0, 0], [.35, .07], [1.05, -.15], [1.26, -.17], [H, .2, 'in'], [1.85, .14], [2.8, 0]]));
      set('hips', 'y', kf(u, [[0, 0], [.35, 12], [1.05, -22], [1.26, -24], [H + .02, 30, 'in'], [1.85, 22], [2.8, 0]]));
      set('hips', 'x', s * kf(u, [[0, 0], [1.05, 10], [H + .02, -16, 'in'], [1.85, -12], [2.8, 0]])); // weight goes over the striking fist
      set('head', 'r', s * kd(u, .05, [[0, 0], [.35, .04], [1.05, -.14], [H, .16, 'in'], [1.9, .1], [2.8, 0]]));
      set('head', 'y', kd(u, .05, [[0, 0], [1.05, -8], [H, 10, 'in'], [1.9, 6], [2.8, 0]]));
      set('jaw', 'y', kd(u, .08, [[0, 0], [1.0, 22], [H, 48, 'in'], [1.9, 16], [2.8, 0]])); }
      const imp = kf(u, [[H - .01, 0], [H + .02, 1, 'lin'], [H + .35, 0, 'out']]); // contact squash, decays in ~20 frames
      set('chest', 'sy', -.05 * imp); set('chest', 'sx', .03 * imp); set('pd' + S, 'y', 10 * imp); set('pd' + O, 'y', 6 * imp);
      [1, 2, 3].forEach((i) => set('rock' + i, 'y', 18 * imp));
    } else if (a === 'swipe') {
      const s = st.side || 1, S = s > 0 ? 'L' : 'R', H = ACTS.swipe.hit;
      // load across the body (0-.75) -> hang (.75-.95) -> SWEEP out (.95-1.22, 16 frames) -> follow-through (1.22-1.55) -> recover.
      // The elbow opens mid-sweep and folds again at the end, so the fist travels a wide ARC, not a hinge swing.
      // load keeps the fist low across the belly (11-25 review: a higher load folded the fist over the face)
      // arms: baked (anim_spec.json swipe: fist-target ARC low across the front; the elbow opens mid-sweep)
      if (!own) { set('chest', 'r', s * kf(u, [[0, 0], [.75, .2], [.95, .22], [H, -.2, 'in'], [1.6, -.16], [2.5, 0]]));
      set('hips', 'x', s * kf(u, [[0, 0], [.75, 14], [H, -18, 'in'], [1.6, -14], [2.5, 0]])); set('hips', 'y', kf(u, [[0, 0], [.75, -8], [H, 16, 'in'], [1.6, 10], [2.4, 0]]));
      set('head', 'r', s * kd(u, .07, [[0, 0], [.75, .14], [H, -.18, 'in'], [1.7, -.1], [2.4, 0]])); set('jaw', 'y', kd(u, .08, [[0, 0], [.9, 16], [H, 36], [1.8, 8], [2.4, 0]])); }
    } else if (a === 'throw') {
      // right arm reaches up to rock2, winds back, hurls toward the camera (foreshortened by a scale squash)
      // arms: baked (anim_spec.json throw: reach to rock2, wind back over the shoulder, release low in front)
      set('shR', 'sy', kf(u, [[0, 0], [1.2, 0], [1.3, -.22, 'in'], [1.7, 0]])); // arm swings toward the viewer
      if (!own) { set('chest', 'r', kf(u, [[0, 0], [.5, -.06], [1.05, -.17], [1.25, .15, 'in'], [2.2, 0]])); set('hips', 'y', kf(u, [[0, 0], [1.05, -16], [1.3, 24], [2.2, 0]]));
      set('head', 'r', kd(u, .05, [[0, 0], [1.05, .12], [1.3, -.1], [2.2, 0]])); set('jaw', 'y', kd(u, .08, [[0, 0], [1.1, 10], [1.3, 40], [1.9, 0]])); }
    } else if (a === 'roar') {
      // inhale: chest swells, head goes back and up, jaw shut (0-.55) -> throws the head FORWARD and the jaw snaps open (.55-.72)
      // -> held roar with a fine tremble (.72-1.95) -> jaw closes with a small bite overshoot, settles (1.95-2.7)
      const inh = kf(u, [[0, 0], [.55, 1, 'out'], [.72, .6], [1.95, .6], [2.6, 0]]), rr = kf(u, [[.5, 0], [.72, 1, 'out'], [1.95, 1], [2.45, 0]]);
      const tr = rr * (Math.sin(u * 47) * .6 + Math.sin(u * 31)) * .007;
      set('head', 'r', tr); set('jaw', 'y', 2.5 * rr * Math.sin(u * 53)); set('jaw', 'sy', .14 * rr); set('chest', 'r', tr * .4); // tremble + jaw stretch stay procedural
      if (!own) { set('head', 'r', kd(u, .04, [[0, 0], [.55, -.14, 'out'], [.72, .07, 'in'], [1.95, .05], [2.6, 0]]));
      set('head', 'y', kd(u, .04, [[0, 0], [.55, -20, 'out'], [.72, -4, 'in'], [1.95, -6], [2.6, 0]]));
      set('jaw', 'y', kd(u, .05, [[0, 0], [.55, -2], [.74, 74, 'out'], [1.95, 70], [2.25, -4, 'in'], [2.5, 2], [2.7, 0]]));
      set('chest', 'sx', .05 * inh); set('chest', 'sy', .06 * inh); set('chest', 'y', -8 * inh); set('hips', 'y', -12 * inh + 8 * rr); }
      for (const L of ['L', 'R']) { aAdd(L, 2 * tr, 1.5 * tr); set('wr' + L, 'sx', -.07 * rr); } // baked: fists pulled down and out; clenched + shaking
    } else if (a === 'guard') { // arms cross in front of the chest (shield phase): small outward load, then the brace with a settle
      const up = kf(u, [[0, 0], [.15, -.12], [.55, 1.04, 'out'], [.8, 1]]);
      // arms: baked (fists cross in front of the chest, drawn over it)
      if (!own) { set('chest', 'sy', -.025 * up); set('chest', 'y', 6 * up); set('head', 'y', 16 * up); set('head', 'r', .05 * up); set('hips', 'y', 8 * up); }
    } else if (a === 'stagger') {
      // knocked back: chest goes first, head whips after it (3-4 frames), arms fling out late, wobble dies over ~1 s, slow recovery
      const sd = st.side || 1, up = kf(u, [[0, 0], [.14, 1, 'out'], [.7, .75], [1.6, 0]]), wob = Math.sin(u * 9) * Math.max(0, 1 - u / 1.2);
      set('chest', 'r', .03 * wob); set('head', 'r', .05 * wob); // wobble stays procedural
      if (!own) { set('chest', 'r', .13 * up * sd); set('hips', 'y', 24 * up); set('hips', 'x', -12 * up * sd);
      set('head', 'r', kd(u, .06, [[0, 0], [.16, -.22, 'out'], [.7, -.14], [1.6, 0]])); set('head', 'y', kd(u, .06, [[0, 0], [.16, -18], [1.6, 0]]));
      set('jaw', 'y', kd(u, .09, [[0, 0], [.2, 42], [.9, 20], [1.6, 0]])); }
      for (const L of ['L', 'R']) aAdd(L, 0, .12 * wob); // baked: fists fling out late; the wobble rides on top
    }
    // ---- hit flinch layer: additive, small, per area; amounts decay ~0.5 s and saturate, so rapid taps never stack into jerks ----
    // 11-26: the spring layer (k, .6x) = the held tension of repeated blows; the SHARP layer (flinchEnv, post-spring, below) = the
    // 2-5 frame reaction to each new blow, then a heavy settle
    const PO = {}; const post = (b, p, v) => { const k = b + '.' + p; PO[k] = (PO[k] || 0) + v; }, post0 = post, set0 = set, aAdd0 = aAdd;
    for (const area in this.fl) { const f = this.fl[area]; f.k *= Math.exp(-3.2 * dt); f.age = (f.age ?? 9) + dt;
      if (f.k < .002 && f.age > .8) { delete this.fl[area]; continue; }
      const k = f.k * .6, d = f.d, e = f.age < .8 ? flinchEnv(f.age) * f.amp : 0;
      // 11-27 HEAVY: rotations x .05, translations x .15 (no head tilt / jaw slide / arm swing from a tap; react.shudder carries the hit)
      const post = (b, p, v) => post0(b, p, v * (p === 'r' ? HFL.r : HFL.t)), set = (b, p, v) => set0(b, p, v * (p === 'r' ? HFL.r : HFL.t)), aAdd = (L, a, b2 = 0, c = 0) => aAdd0(L, a * HFL.r, b2 * HFL.r, c * HFL.r);
      if (e) { if (area === 'head') { post('head', 'r', -.08 * d * e); post('head', 'y', -9 * e); post('jaw', 'y', 9 * e); post('neck', 'r', -.02 * d * e); }
        else if (/^(fist|arm)[LR]$/.test(area)) { const L = area.slice(-1), sg = L === 'L' ? 1 : -1, fist = area.startsWith('fist');
          post('wr' + L, 'r', sg * (fist ? .2 : .08) * e); post('el' + L, 'r', sg * (fist ? .06 : .13) * e); post('sh' + L, 'r', sg * .04 * e); }
        else if (/^shoulder[LR]$/.test(area)) { const L = area.slice(-1), sg = L === 'L' ? 1 : -1; post('pd' + L, 'y', 8 * e); post('pd' + L, 'r', -.04 * sg * e); post('chest', 'r', -.02 * sg * e); }
        else if (!area.startsWith('rock')) { post('chest', 'r', .025 * d * e); post('chest', 'y', 5 * e); post('hips', 'y', 4 * e); post('head', 'r', -.025 * d * e); } }
      if (area === 'head') { set('head', 'r', -.09 * d * k); set('head', 'y', -9 * k); set('jaw', 'y', 10 * k); set('neck', 'r', -.03 * d * k); }
      else if (area === 'fistL' || area === 'fistR' || area === 'armL' || area === 'armR') { const L = area.endsWith('L'), sg = L ? 1 : -1, fist = area.startsWith('fist');
        aAdd(L ? 'L' : 'R', .05 * k, (fist ? .1 : .16) * k, (fist ? .22 : .1) * k); }
      else if (area === 'shoulderL' || area === 'shoulderR') { const L = area.endsWith('L'), sg = L ? 1 : -1;
        set(L ? 'pdL' : 'pdR', 'y', 7 * k); set(L ? 'pdL' : 'pdR', 'r', -.04 * sg * k); aAdd(L ? 'L' : 'R', .06 * k); set('chest', 'r', -.025 * sg * k); }
      else if (!area.startsWith('rock')) { set('chest', 'r', .03 * d * k); set('chest', 'y', 5 * k); set('chest', 'sy', -.015 * k); set('hips', 'y', 6 * k); set('head', 'r', -.03 * d * k); } }
    // ---- arms: baked angle tracks (idle loop, blended toward the dormant pose; an act fades in / out over it), + additive layer.
    // The wrist follows the forearm with a small lag (from the springs' angular velocity). Then limits, then the pauldrons. ----
    const bi = this._bi || (this._bi = {}), ba = this._ba || (this._ba = {}), bd = this._bd || (this._bd = {}), map = a && BAKED[a];
    const sd = st.side || 1, mir = map ? (map[1] ? 1 : 0) ^ (a === 'swipe' && sd < 0 ? 1 : 0) : 0, dur = map ? this.bk.moves[map[0]].dur : 1;
    const wA = (map ? (map[0] === 'guard' ? kf(u, [[0, 0], [.12, 1]]) : kf(u, [[0, 0], [.12, 1], [dur - .15, 1], [dur, 0]])) : 0) * MOTION.act;
    const i0 = this._i0 || (this._i0 = {});
    for (const [s, L] of [[1, 'L'], [-1, 'R']]) {
      this.arm('idle', L, t, bi);
      if (am !== 1) { this.arm('idle', L, 0, i0); for (const k of ['sh', 'el', 'wr', 'tx', 'ty']) bi[k] = i0[k] + (bi[k] - i0[k]) * am; } // subtle idle: the loop's drift scaled around its rest frame
      if (dorm > 0) { this.arm('dormant', L, 0, bd); for (const k of ['sh', 'el', 'wr', 'tx', 'ty']) bi[k] += (bd[k] - bi[k]) * dorm; }
      let fr = bi.front, sn = 1;
      if (wA > 0) { this.arm(map[0], mir ? (L === 'L' ? 'R' : 'L') : L, u, ba); for (const k of ['sh', 'el', 'wr', 'tx', 'ty']) bi[k] += (ba[k] - bi[k]) * wA; fr = Math.max(fr, ba.front); sn = ba.snap; }
      if (fr) this.front[L] = fr; if (sn !== 1) snap[L] = sn;
      const q = AD[L], cs = this.ch['sh' + L + '.r'], ce = this.ch['el' + L + '.r'], lag = clamp(-.05 * s * ((cs ? cs.v : 0) + (ce ? ce.v : 0)), -.3, .3);
      set('sh' + L, 'r', s * (bi.sh + q[0])); set('el' + L, 'r', s * (bi.el + q[1])); set('wr' + L, 'r', s * (bi.wr + q[2] + lag));
      this.ikDbg[L] = [this.sx[L] - s * bi.tx, this.sx.y + bi.ty]; }
    // ---- joint limits (side-normalised), then the pauldrons follow the upper arm: lift + small tilt + out, never the full swing ----
    for (const [s, L] of [[1, 'L'], [-1, 'R']]) {
      for (const j of ['sh', 'el', 'wr']) { const k = j + L + '.r'; if (T[k] !== undefined) T[k] = s * clamp(s * T[k], LIM[j][0], LIM[j][1]); }
      const raise = s * (T['sh' + L + '.r'] || 0), up = clamp((raise - .8) / 1.8, 0, 1); // the ready stance (~.7) leaves it seated
      set('pd' + L, 'r', s * clamp(.05 * raise, LIM.pd[0], LIM.pd[1])); set('pd' + L, 'y', -12 * up); set('pd' + L, 'x', -s * 6 * up);
      set('sh' + L, 'y', -10 * up); // the ball joint rides up with the armour, so the arm never pulls out from under it
    }
    // ---- emissive glow (glowmask.js groups: R cracks, G eyes + gem, B runes). Idle pulse lives in the shader; here: act / mood ----
    const P = this.P;
    if (P.glow) { const gm = P.glow.mul, sleep = 1 - dorm * .75; // dormant (lobby / before the intro ignite): embers only
      let roarK = 0; if (a === 'roar') roarK = kf(u, [[.5, 0], [.75, 1, 'out'], [1.95, 1], [2.5, 0]]); else if (a === 'stagger') roarK = -.5 * kf(u, [[0, 0], [.15, 1], [1.6, 0]]);
      gm[0] = sleep * (1 + .35 * rage + .5 * Math.max(0, roarK)); gm[1] = Math.max(.2, sleep * (1 + .6 * rage + 2.8 * roarK) + .35 * Math.max(0, roarK) * Math.sin(t * 40)); // stagger dims the eyes, never below .2
      gm[2] = sleep * (1 + .3 * rage + .4 * Math.max(0, roarK));
      if ((a === 'slamL' || a === 'slamR' || a === 'swipe' || a === 'throw') && !this._gk && u > ACTS[a].hit) { this._gk = 1; P.glow.kick('r', 1.6, 4); P.glow.kick('g', 1, 5); }
      if (u < .05) this._gk = 0; }
    // ---- springs: targets -> pose (semi-implicit, sub-stepped at <= 1/60 s so a frame hitch never makes them ring) ----
    P.clear();
    for (const k in T) if (!this.ch[k]) this.chan(...k.split('.'));
    const n = Math.min(4, Math.max(1, Math.ceil(dt * 60 - .01))), h = dt / n;
    for (const k in this.ch) { const c = this.ch[k], tg = T[k] || 0; let [ks, kdmp] = (this.stiffOv && this.stiffOv[c.bone]) || STIFF[c.bone] || [120, 14];
      const sk = /^(sh|el|wr)/.test(c.bone) ? snap[c.bone[2]] || 1 : 1; if (sk !== 1) { ks *= sk * sk; kdmp *= sk; } // same damping ratio, faster
      if (dt > 0) for (let i = 0; i < n; i++) { c.v += (ks * (tg - c.x) - kdmp * c.v) * h; c.x += c.v * h; }
      P.set(c.bone, { [c.prop]: c.x }); }
    // ---- 11-26 SECONDARY MOTION (post-spring, additive): parts hanging off the body lag its ACCELERATION and settle on their own
    // damped oscillators: head + jaw behind the chest (overlap), pauldrons lag and bounce, the floating rocks drift with inertia.
    // Body signals = the springs' own velocities (roll = hips.r + chest.r, vertical = hips.y + chest.y, sideways = hips.x). ----
    const cv = (k) => (this.ch[k] ? this.ch[k].v : 0), sc2 = this.sec;
    const vel = [cv('hips.r') + cv('chest.r'), cv('hips.y') + cv('chest.y'), cv('hips.x')];
    if (dt > 0) { const pv = sc2.pv || vel, acc = vel.map((v, i) => clamp((v - pv[i]) / dt, [-40, -4000, -3000][i], [40, 4000, 3000][i])); sc2.pv = vel;
      const [aR, aY, aX] = acc;
      this.osc('hR', 60, 9, .18, aR, n, h); this.osc('hY', 70, 10, .28, aY, n, h); this.osc('jY', 90, 11, .45, aY, n, h);
      for (const [s, L] of [[1, 'L'], [-1, 'R']]) { this.osc('pY' + L, 45, 7, .2, aY - s * 170 * aR, n, h); this.osc('pR' + L, 50, 7, .12, aR, n, h); }
      for (const i of [1, 2, 3]) { this.osc('rX' + i, 12, 2.4, .45 + .1 * i, aX - 300 * aR, n, h); this.osc('rY' + i, 14, 2.6, .12 + .03 * i, aY, n, h); }
      sc2.grind = (sc2.grind || 0) * Math.exp(-4.5 * dt); }
    const sx = (nm) => (sc2[nm] ? sc2[nm].x * am : 0);
    post('head', 'r', HEAVY ? clamp(sx('hR') * .5, -.025, .025) : clamp(sx('hR'), -.08, .08)); // 11-27 HEAVY: a slight lag behind the body, no wobble post('head', 'y', clamp(sx('hY'), -14, 14)); post('jaw', 'y', clamp(sx('jY'), -3, 16));
    for (const L of ['L', 'R']) { post('pd' + L, 'y', clamp(sx('pY' + L), -16, 16)); post('pd' + L, 'r', clamp(sx('pR' + L), -.05, .05)); }
    for (const i of [1, 2, 3]) { post('rock' + i, 'x', clamp(sx('rX' + i), -60, 60)); post('rock' + i, 'y', clamp(sx('rY' + i), -40, 40)); }
    // stone-grind micro-shake after impacts / heavy blows (<= .006 rad, ~0.5 s): crunchy noise on the chest, head and pauldrons
    const g = (sc2.grind || 0) * am;
    if (g > .01) { post('chest', 'r', .006 * g * grindN(t, 0)); post('head', 'r', .008 * g * grindN(t, 1)); post('pdL', 'y', 2.5 * g * grindN(t, 2));
      post('pdR', 'y', 2.5 * g * grindN(t, 3)); post('hips', 'x', 1.5 * g * grindN(t, 4)); [1, 2, 3].forEach((i) => post('rock' + i, 'y', 4 * g * grindN(t, 4 + i))); }
    for (const k in PO) { const [b, p] = k.split('.'); P.set(b, { [p]: PO[k] }); }
    // planted legs (11-26 v4 thighs): the thighs counter-rotate against the hip sway, so the waist shifts over still legs
    if (P.byName.thL) { const hx = this.ch['hips.x']?.x || 0, hr = this.ch['hips.r']?.x || 0; P.set('thL', { r: -hr - hx / 420 }); P.set('thR', { r: -hr - hx / 420 }); }
    this.react.update(dt, t); this.react.apply();
    if (this.procFn) this.procFn(P, st.t, dt, st, this);
    P.front = this.front;
    P.update();
  }
}
