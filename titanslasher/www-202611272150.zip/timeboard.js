// TIME BOARD mode (11-28, the DEFAULT since the user's "push it"; ?timeboard=0 = the old damage board). The leaderboard ranks KILL TIME:
//   - HP is fixed at fight start from your OWN gear: P / P0 = typical-player damage over 60 s with this gear / with no gear, target
//     T = the titan's usual time (KILL_S, varies per titan) x (P / P0)^-0.0223 (10x the damage = 5% faster), HP = typical damage by T.
//   - Kill time = real timestamps (performance.now() / the tap's event time), never summed frame dt: hit-stop, slow-mo and frame
//     drops do not change it. Time with the app hidden is taken out (pause / resume; main.js also drops the combo). Integer ms.
//   - NO time limit and no escape (user 11-28 "it's fine, it never ends"): only the kill ends the fight. The clock is HIDDEN until then.
//   - Shards / XP / drops stay damage based: a kill is paid for the damage the same pace would have dealt in an old whole fight.
//   - Board = computed RIVALS (same for everyone: UTC day + titan, never sent anywhere) + the player's best of the day
//     (localStorage 'tt_timeboard'). NOTHING is written to Supabase in this mode (leaderboard.js is offline with ?timeboard=1).
// Pure apart from the HUD at the bottom: main.js / hud-menu.js / lobby-ui.js call in only when ON.
import { LB } from './leaderboard.js';

export const ON = !!LB.timeboard;

// ---------------------------------------------------------------- balance
export const T0_MS = 60000, EDGE_EXP = -0.0223;
// 11-28 user "HP should vary per titan, some fast some long": seconds a typical player needs, by rotation position
// (titans/index.json): Moss Warden, Ashen Hound, Chimera, Black Tide, Rimebound, Hour Warden, The Watcher, Drowned Hydra,
// Sugarbone, Strider. Better gear still shaves only the small edge; the rivals' times scale the same way.
export const KILL_S = [60, 40, 55, 90, 75, 45, 65, 110, 35, 80];
export const usualMs = (titan) => (KILL_S[titan] || T0_MS / 1000) * 1000;
// the TYPICAL PLAYER: tps taps a second without a break; share rune of the taps go to the weak point while one is up; first rune
// runeAt s after the clock starts; runeGap s without one after it breaks (.5 fade + .45 cooldown, a bit more in real time from
// hit-stop); a finisher's blows land finDelay s after it fires. cal = measured game damage / model damage (scripted 5 taps/s
// runs in the real game 11-28; re-check it after any damage change).
export const TYP = { tps: 5, rune: .65, runeAt: .6, runeGap: 1.05, finDelay: .8, cal: 1.17 };
// the old 75 s fight lasted 75 s of GAME time = about 88 s of real time at this tap rate (hit-stop slows game time): rewards pay for that
export const FULL_MS = 88000;
const BASE = { tap: 1, fin: 1, crit: .05, critMul: 2, wp: 1, comboG: .03 }; // no gear (equipment.js recompute with nothing)
const CFG = { gain: .5, step: 30, runeHp: 10, weakS: 10, chainMax: 999 }; // main.js passes its live values

// Deterministic tap-by-tap walk of main.js's formulas (tapAt / tapStrike / wpHit / finisher / limits.js totals), crits at their
// expected value. Returns the damage dealt by `sec` seconds (linear between hits).
export function typicalDamage(st, sec, cfg = CFG, typ = TYP) {
  const E = 1 + st.crit * (st.critMul - 1), runeMax = cfg.runeHp * 100 * st.tap * st.wp * 4.25;
  let tot = 0, chain = 0, nextFin = cfg.step, acc = 0, up = typ.runeAt, hits = 0, rd = 0, fin = null, prevT = 0;
  const runeLive = (t) => { if (t >= up + cfg.weakS) { up += cfg.weakS + typ.runeGap; hits = 0; rd = 0; } return t >= up; };
  const rune = (t, mult) => { hits++; const d = 100 * st.tap * st.wp * (4 + Math.min(hits, 40) * .25) * (1 + chain * st.comboG) * mult * E;
    rd += d; if (rd >= runeMax) { up = t + typ.runeGap; hits = 0; rd = 0; } return d; };
  for (let k = 0; k < 20000; k++) {
    const t = k / typ.tps;
    if (fin && fin.t <= t) { // the finisher's blows (6.5 x 520 units) + up to 5 weak-point hits x2.5
      let d = 6.5 * 520 * st.fin * (1 + chain * .015) * E; for (let i = 0; i < 5 && runeLive(fin.t); i++) d += rune(fin.t, 2.5);
      if (fin.t >= sec) return (tot + d * Math.max(0, (sec - prevT) / Math.max(1e-6, fin.t - prevT))) * typ.cal;
      tot += d; prevT = fin.t; fin = null; }
    chain = Math.min(cfg.chainMax, chain + cfg.gain);
    let d;
    if (runeLive(t) && (acc += typ.rune) >= 1) { acc -= 1; d = rune(t, 1); } else d = 120 * st.tap * (1 + chain * st.comboG) * E;
    if (t >= sec) return (tot + d * Math.max(0, (sec - prevT) / Math.max(1e-6, t - prevT))) * typ.cal;
    tot += d; prevT = t;
    if (chain >= nextFin) { nextFin += cfg.step; if (!fin) fin = { t: t + typ.finDelay }; }
  }
  return tot * typ.cal;
}
export function plan(st, cfg = CFG, base = T0_MS) {
  const P = typicalDamage(st, T0_MS / 1000, cfg), P0 = typicalDamage(BASE, T0_MS / 1000, cfg);
  const target = Math.round(base * Math.pow(P / P0, EDGE_EXP));
  return { P, P0, ratio: P / P0, target, hp: Math.max(1, Math.round(typicalDamage(st, target / 1000, cfg))) };
}

// ---------------------------------------------------------------- the fight: HP + clock
const F = { hp: 0, plan: null, st: null, cfg: CFG, limit: 75000, t0: null, away: null, lost: 0, at: 0, evT: null, over: true, ms: null, pct: 0, onKill: null, startBy: '', endBy: '', pauses: 0 };
export function begin({ stats, cfg, limitMs, onKill, titan }) {
  F.st = { ...stats }; F.cfg = { ...CFG, ...cfg }; F.plan = plan(F.st, F.cfg, usualMs(titan)); F.hp = F.plan.hp; F.limit = limitMs; F.onKill = onKill;
  F.t0 = null; F.away = null; F.lost = 0; F.over = false; F.ms = null; F.pct = 0; F.startBy = F.endBy = ''; F.pauses = 0;
  hud(0, 0);
}
// the touch / pointer / key event's own time while its tap is processed (closer to the finger than "now"); null otherwise
export function stamp(ts) { const n = performance.now(); F.evT = ts != null && ts > 0 && ts <= n + 2 && n - ts < 1500 ? ts : null; }
export function start(at, by = 'cue') { if (F.t0 == null && !F.over) { F.t0 = at ?? performance.now(); F.startBy = by; } }
// fight time in ms (0 before the clock starts; frozen while the app is away)
export function elapsed(at) { if (F.t0 == null) return 0; let n = at ?? performance.now(); if (F.away != null) n = Math.min(n, F.away); return Math.max(0, n - F.t0 - F.lost); }
export function pause() { if (!F.over && F.t0 != null && F.away == null) { F.away = performance.now(); F.pauses++; } }
export function resume() { if (F.away != null) { F.lost += performance.now() - F.away; F.away = null; } }
export const paused = () => F.away != null;
// main.js damage(): may this hit count? (starts the clock on the very first hit; nothing after the kill or past the limit)
export function counts() { if (F.over) return false; F.at = F.evT ?? performance.now(); start(F.at, F.evT != null ? 'tap' : 'hit'); return true; }
// after the hit is added: HP gone = the kill, timed at that hit
export function check(score) {
  if (F.over || score < F.hp) return; F.ms = Math.max(1, Math.round(elapsed(F.at))); F.endBy = F.evT != null ? 'tap' : 'frame'; F.over = true; F.pct = 10000;
  hud(F.ms, score); queueMicrotask(() => F.onKill && F.onKill()); // after the hit's own effects
}
export const expired = () => elapsed() >= F.limit;
export function timeout(score) { if (F.over) return; F.over = true; F.pct = Math.max(0, Math.min(9999, Math.floor(score / F.hp * 10000))); hud(F.limit, score); }
export const killed = () => F.ms != null;
export const state = () => ({ hp: F.hp, plan: F.plan, ms: F.ms, pct: F.pct, elapsed: F.ms ?? elapsed(), started: F.t0 != null, startBy: F.startBy, endBy: F.endBy, lost: F.lost, pauses: F.pauses, over: F.over });

export function fmtTime(ms) { ms = Math.max(0, Math.round(ms)); const p = (v, n) => String(v).padStart(n, '0'); return `${p(Math.floor(ms / 60000), 2)}:${p(Math.floor(ms / 1000) % 60, 2)}.${p(ms % 1000, 3)}`; }
export const fmtPct = (pct) => `${(Math.floor(pct / 10) / 10).toFixed(1)}%`; // pct = hundredths of a percent
export const fmtResult = (r) => (r.ms != null ? fmtTime(r.ms) : fmtPct(r.pct));
export const resultText = () => fmtResult(F);

// damage the rewards are computed from: what the same pace would have dealt in a whole OLD fight (FULL_MS, model curve), so a
// quick kill is not paid less (nor a miss, now cut at 75 s of real time). A kill counts its HP (not the last hit's overkill);
// runes / limit breaks / combo scale by the time saved.
export function rewardBasis(o) {
  const ran = F.ms ?? F.limit, full = FULL_MS * (F.limit / 75000), t = Math.max(25000 * (F.limit / 75000), ran), k = full / t;
  const g = typicalDamage(F.st, full / 1000, F.cfg) / Math.max(1, typicalDamage(F.st, t / 1000, F.cfg));
  return { score: Math.round((F.ms != null ? F.hp : o.score) * g), runes: Math.round(o.runes * k), limits: Math.round(o.limits * k), combo: Math.min(999, Math.round(o.combo * k)) };
}

// ---------------------------------------------------------------- ghosts (computed on the device, same for everyone)
export const BOARD_N = 20, GHOST_START = 10, GHOST_DNF = 0;
const NAMES = ['Pebblewren', 'Duskmarrow', 'Tinroot', 'Quillfen', 'Brinelark', 'Ashpipit', 'Lanternfig', 'Saltbracken', 'Wickerjay', 'Drizzlepine', 'Cinderplum', 'Marshbell', 'Thimbleoak', 'Gorsewhistle', 'Inkpennant', 'Fogbarrel', 'Nettlecove', 'Sootfinch', 'Plumbramble', 'Rustmeadow', 'Larkspindle', 'Vellumcrow', 'Brackenpool', 'Teaselhorn', 'Murkwillow', 'Cobblesnipe', 'Wrenfable', 'Oatshadow', 'Kiteharbor', 'Mirefiddle', 'Sedgelamp', 'Pumicedove', 'Parsnipwick', 'Flintsorrel', 'Hazelcrank', 'Mudlantern', 'Quietbramble', 'Sprocketfern'];
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
// all BOARD_N ghosts of a day + titan: { name, ms | null, pct, at (share of the UTC day when it shows up) }, in order of appearance
export function ghostsOf(day, titan) {
  const r = rng(Math.imul(day | 0, 2654435761) ^ Math.imul((titan | 0) + 1, 40503));
  const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const names = shuffle(NAMES.slice()), n = BOARD_N - GHOST_DNF, kills = [], dnf = [];
  for (let i = 0; i < n; i++) { const q = (i + r()) / n; kills.push({ ms: Math.round((38000 + 36000 * Math.pow(q, .8)) * usualMs(titan) / T0_MS), pct: 10000 }); } // 0.63 - 1.23 x the titan's usual time
  // there from 00:00: every other kill (the whole spread); the rest show up through the first 80% of the day
  const first = kills.filter((_, i) => i % 2 === 0).slice(0, GHOST_START), rest = shuffle(kills.concat(dnf).filter((g) => !first.includes(g)));
  return shuffle(first).map((g) => ({ ...g, at: 0 })).concat(rest.map((g, i) => ({ ...g, at: .8 * (i + .3 + r() * .6) / rest.length }))).map((g, i) => ({ ...g, name: names[i] }));
}

// ---------------------------------------------------------------- the board + the player's best of the day (local only)
const KEY = 'tt_timeboard';
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } };
const store = (s) => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* no storage */ } };
export const better = (a, b) => !b || (a.ms != null ? b.ms == null || a.ms < b.ms : b.ms == null && a.pct > b.pct);
export function bestOf(day, titan) { const s = load(); return (s.days || {})[`${day}:${titan}`] || null; }
const order = (a, b) => (a.ms != null && b.ms != null ? a.ms - b.ms : a.ms != null ? -1 : b.ms != null ? 1 : b.pct - a.pct) || (a.me ? -1 : b.me ? 1 : 0);
// rows ranked: kills by time (fastest first), then the rest by % removed. you = { ms, pct } | null. Every real player takes one
// ghost's place (the latest to show up goes first).
export function board(day, titan, you, frac = (LB.now() % 864e5) / 864e5) {
  const real = you ? [{ name: LB.nick, ms: you.ms, pct: you.pct, me: true }] : [];
  const rows = ghostsOf(day, titan).filter((g) => g.at <= frac).slice(0, BOARD_N - real.length).map((g) => ({ name: g.name, ms: g.ms, pct: g.pct, gh: true })).concat(real).sort(order);
  rows.forEach((r, i) => { r.rank = i + 1; });
  rows.n = rows.length; rows.meRank = rows.findIndex((r) => r.me) + 1; return rows;
}
// fight end: keep the best of the day, rank this fight. o: { day, titan, reward (rewardBasis score), oldBest (SAVE.best) }
export function record({ day, titan, reward, oldBest, detail = {} }) {
  const me = { ms: F.ms, pct: F.pct, ...detail }, s = load(), k = `${day}:${titan}`; s.days = s.days || {};
  const prev = s.days[k] || null, improved = better(me, prev); if (improved) s.days[k] = me;
  for (const old of Object.keys(s.days)) if (+old.split(':')[0] < day - 7) delete s.days[old];
  const newBest = reward > Math.max(oldBest || 0, s.eq || 0); s.eq = Math.max(s.eq || 0, reward); store(s); // the "new personal best" shard bonus (damage)
  const mine = board(day, titan, me); // 11-28 user "the timing is all wrong": the results show THIS fight's time and rank (medal + rows)
  return { me, improved, newBest, rank: mine.meRank, n: mine.n, board: mine, isBest: improved, best: s.days[k], bestRank: board(day, titan, s.days[k]).meRank };
}

// 11-28 user: no ghost icon / "computer-made" note. The others are shown as the game's RIVALS (never claimed to be real players).
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// the gap to your time, in seconds: negative = that rival was faster
const gap = (r, you) => { if (r.me || r.ms == null || you == null) return ''; const d = (r.ms - you) / 1000; return `<em class="tb-gap ${d < 0 ? 'fast' : 'slow'}">${d < 0 ? '\u2212' : '+'}${Math.abs(d).toFixed(1)}s</em>`; };
const row = (r, tag, you) => `<div class="lrow${r.me ? ' me' : ''}"><span>#${r.rank}</span><span>${r.me && tag ? 'YOU' : esc(r.name)}${r.me && tag && tag !== 'YOU' ? `<i class="you">${tag}</i>` : ''}</span><span>${gap(r, you)}${r.ms != null ? fmtTime(r.ms) : `<small>HP</small> ${fmtPct(r.pct)}`}</span></div>`;
// results screen: your earlier best (if this run was not it), then the rivals around THIS run (5 rows on tall screens, else 3)
export function miniHtml(b, isBest, best, bestRank) {
  const n = typeof innerHeight === 'number' && innerHeight >= 740 ? 5 : 3, me = b.findIndex((r) => r.me), i0 = Math.max(0, Math.min(me - Math.floor(n / 2), b.length - n)), mine = b[me]?.ms;
  const prev = !isBest && best && best.ms != null ? `<div class="tb-prevh">YOUR BEST TODAY &middot; EARLIER RUN</div><div class="lrow tb-prev"><span>#${bestRank}</span><span>YOU</span><span>${fmtTime(best.ms)}</span></div>` : '';
  return `${prev}<div class="tb-head">TITAN RIVALS</div>${b.slice(i0, i0 + n).map((r) => row(r, 'THIS RUN', mine)).join('')}`;
}
// RANKS panel: the whole board, gaps to your best, and the details of your best run
export function panelHtml(day, titan) {
  const you = bestOf(day, titan), b = board(day, titan, you);
  const det = you && you.taps != null ? `<div class="tb-det">Best combo &times;${Math.floor(you.combo || 0)} &middot; ${you.taps} hits${you.weapon ? ` &middot; ${esc(you.weapon)}` : ''}</div>` : '';
  // no scrolling (user's rule for every panel): as many rows as fit; if you are further down, the top ones, a gap, then the rows around you
  const fit = Math.max(5, Math.min(b.length, Math.floor(((typeof innerHeight === 'number' ? innerHeight : 800) - 390) / 35))), me = b.findIndex((r) => r.me);
  const near = me >= fit ? [Math.max(fit - 3, me - 1), Math.min(b.length, me + 2)] : null, show = near ? b.slice(0, fit - 4).concat(null, b.slice(near[0], near[1])) : b.slice(0, fit);
  const list = show.map((r) => (r ? row(r, 'YOU', you?.ms ?? null) + (r.me ? det : '') : '<div class="tb-dots">&middot;&middot;&middot;</div>')).join('');
  return `<div class="tb-head">USUAL KILL TIME ${fmtTime(usualMs(titan)).slice(0, 5)}</div>${list}<div class="lnote">Kill time, fastest first${you ? ' &middot; gaps are to your best' : ''}</div>`;
}
export function bestLine(day, titan) { const y = bestOf(day, titan); return y ? `Best today: ${fmtResult(y)}${y.ms == null ? ' HP' : ''} · #${board(day, titan, y).meRank}` : 'Best today: -'; }

// ---------------------------------------------------------------- fight HUD (timer + HP; the ink titan plate's bar becomes the HP bar)
let el = null, chars = [], shown = '', hpShown = '';
function mount() {
  document.documentElement.classList.add('timeboard');
  const st = document.createElement('style'); st.textContent = `
#tbHud{position:fixed;z-index:3;display:none;pointer-events:none;left:calc(12px + env(safe-area-inset-left,0px));top:calc(70px + var(--safeT,0px));flex-direction:column;align-items:flex-start;gap:3px;contain:layout style}
body[data-st="fight"] #tbHud{display:flex}
#tbTime{display:none!important}html.timeboard #timer{visibility:hidden}
#tbTime{font:900 26px/1 var(--k-fd,'Barlow Condensed',sans-serif);color:#fff;text-shadow:0 2px 0 #000,0 0 6px #000,0 0 2px #000;white-space:nowrap;display:flex}
#tbTime span{display:inline-block;width:.6em;text-align:center}#tbTime span.p{width:.3em}
#tbHp{font:800 13px/1 var(--k-fd,'Barlow Condensed',sans-serif);letter-spacing:.08em;color:#bff3ea;text-shadow:0 1px 0 #000,0 0 4px #000}
#tbBar{width:min(52vw,230px);height:9px;background:#0b0f13;border:1px solid #d9ccb0}#tbBar i{display:block;height:100%;width:100%;background:#7fd6c8}
html.ink #tbBar{display:none}html.ink #tbHud{display:none!important}
#tplate .tp-tx{position:relative}#tplate .tp-pct{position:absolute;right:0;top:0;font:900 clamp(10px,3vw,13px)/1.1 var(--k-fd,serif);font-style:normal;color:#a8efe3;text-shadow:0 1px 0 #000,0 0 3px #000}
html.timeboard #tplate .tp-n{padding-right:2.9em}
html.timeboard #tplate .tp-bar i{transition:width .08s linear}
html.timeboard .lrow span:nth-child(3){font-variant-numeric:tabular-nums;white-space:nowrap;margin-left:auto}
html.timeboard .lrow span:nth-child(3) small{font-size:.7em;opacity:.7}
html.timeboard .tb-prevh{margin:0 0 2px;font:800 clamp(10px,3vw,12px)/1.2 var(--k-fd,serif);letter-spacing:.12em;color:#f0d58a;text-align:center}
html.timeboard.ink .rmin #resBoard .lrow.tb-prev,html.timeboard .lrow.tb-prev{border-image:none;border:2px dashed #d9b96a;background:#0e141899;color:#f0d58a}
html.timeboard.ink .rmin #resBoard .lrow.tb-prev span{color:#f0d58a}
html.timeboard.ink .rmin #resBoard .lrow.tb-prev{margin-bottom:8px}
html.timeboard .tb-head{margin:2px 0 1px;font:800 clamp(10px,3vw,12px)/1.2 var(--k-fd,serif);letter-spacing:.14em;color:#9fd9cf;text-align:center}
html.timeboard .tb-gap{font-style:normal;font-size:.76em;margin-right:8px;opacity:.9}
html.timeboard .tb-gap.fast{color:#ff9a86}html.timeboard .tb-gap.slow{color:#8fe3d2}
html.timeboard .tb-dots{text-align:center;line-height:14px;color:#9fd9cf}
html.timeboard .tb-det{margin:-1px 0 3px;font:700 clamp(11px,3.1vw,13px)/1.3 var(--k-fd,serif);color:#f0d58a;text-align:center}
html.timeboard #resScore{font-variant-numeric:tabular-nums}`;
  document.head.appendChild(st);
  el = document.createElement('div'); el.id = 'tbHud';
  el.innerHTML = `<div id="tbTime">${'00:00.000'.split('').map((c) => `<span${/\d/.test(c) ? '' : ' class="p"'}>${c}</span>`).join('')}</div><div id="tbHp">TITAN HP 100%</div><div id="tbBar"><i></i></div>`;
  document.body.appendChild(el); chars = [...el.querySelectorAll('#tbTime span')]; shown = '00:00.000';
}
// a long titan name shrinks until it fits beside the percentage
function fitName(n) { if (!n || !n.clientWidth) return; n.style.fontSize = ''; let f = parseFloat(getComputedStyle(n).fontSize) || 14; while (f > 8 && n.scrollWidth > n.clientWidth + .5) { f -= .5; n.style.fontSize = `${f}px`; } }
// every fight frame (main.js) and once more at the kill / timeout
export function hud(ms, score) {
  if (!el) return; const t = fmtTime(ms);
  if (t !== shown) { for (let i = 0; i < t.length; i++) if (t[i] !== shown[i] && chars[i]) chars[i].textContent = t[i]; shown = t; }
  const left = F.hp ? Math.max(0, 1 - score / F.hp) : 1, key = (left * 100).toFixed(1);
  if (key !== hpShown) { hpShown = key; el.querySelector('#tbHp').textContent = `TITAN HP ${left > 0 ? Math.max(1, Math.ceil(left * 100)) : 0}%`;
    const w = `${(left * 100).toFixed(1)}%`; el.querySelector('#tbBar i').style.width = w; const tx = document.querySelector('#tplate .tp-tx'); if (tx) { let pc = tx.querySelector('.tp-pct'); if (!pc) { pc = document.createElement('em'); pc.className = 'tp-pct'; tx.appendChild(pc); } pc.textContent = `${left > 0 ? Math.max(1, Math.ceil(left * 100)) : 0}%`; fitName(tx.querySelector('.tp-n')); }
    const p = document.querySelector('#tplate .tp-bar i'); if (p) { p.style.width = w; p.parentNode.parentNode.parentNode.classList.toggle('low', left <= .15); } }
}
export const tick = (score) => hud(F.ms ?? elapsed(), score);
export const repaint = () => { hpShown = ''; };

if (ON && typeof document !== 'undefined') { mount(); window.__tb = { plan, typicalDamage, ghostsOf, board, bestOf, state, elapsed, TYP }; }
