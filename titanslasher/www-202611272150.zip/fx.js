// Shared look: lit sprite material, cheap bloom post chain, GPU-point sparks, slash-arc material.
import * as THREE from 'three';
import { addGlow, renderGlowPass } from './glowmask.js'; // shared emissive-mask helper (canonical copy: E:/jgmkr/tools/web/glowmask.js)

export const SH = { // shared uniforms: every sprite references these objects
  fogColor: { value: new THREE.Color(0x5a4a98) },
  lightPos: { value: new THREE.Vector3(0, 12, -30) }, lightCol: { value: new THREE.Color(0, 0, 0) }, lightK: { value: 1 },
  time: { value: 0 },
};

const VS = `varying vec2 vUv; varying vec3 vW; varying float vD;
void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position,1.); vW = w.xyz; vec4 mv = viewMatrix * w; vD = -mv.z; gl_Position = projectionMatrix * mv; }`;
const FS = `uniform sampler2D map; uniform vec3 tint; uniform float alpha; uniform vec3 flash; uniform float glow; uniform float fogNear; uniform float fogFar;
uniform vec3 fogColor; uniform vec3 lightPos; uniform vec3 lightCol; uniform float lightK; uniform vec3 rim; uniform float cut;
uniform vec2 olW; uniform vec3 olC; uniform float olA;
varying vec2 vUv; varying vec3 vW; varying float vD;
void main(){ vec4 c = texture2D(map, vUv);
#ifdef OUTLINE
  float m = 0.; for (int i = 0; i < 8; i++) { float an = float(i) * .785398; m = max(m, texture2D(map, vUv + vec2(cos(an), sin(an)) * olW).a); }
  float ol = clamp(m - c.a, 0., 1.) * olA;
  if (c.a < 0.02 && ol < 0.02) discard;
#else
  if (c.a < 0.02) discard;
#endif
  vec3 col = c.rgb * tint;
  float cy = clamp((min(c.g, c.b) - c.r - 0.06) * 3.2, 0., 1.);
  col += c.rgb * cy * glow;
  float d = distance(vW, lightPos); col += col * lightCol * lightK * (1.4 / (1. + d * d * 0.0035));
  col += rim * pow(1. - c.a, 2.) * 0.0;
  float f = smoothstep(fogNear, fogFar, vD); col = mix(col, fogColor, f * 0.85);
  col += flash;
  float a = c.a * alpha;
  if (cut > -1.) { float n = fract(sin(dot(floor(vUv * vec2(40., 60.)), vec2(12.9898, 78.233))) * 43758.5453); a *= smoothstep(cut + .04, cut - .04, vUv.y + (n - .5) * .12); } // noisy dissolve edge
#ifdef OUTLINE
  float oa = ol * alpha; if (cut > -1.) oa *= step(vUv.y, cut); float ta = a + oa * (1. - a); col = (col * a + olC * oa * (1. - a)) / max(ta, .001); a = ta;
#endif
  gl_FragColor = vec4(col, a); }`;

export function spriteMat(tex, o = {}) {
  const m = new THREE.ShaderMaterial({
    vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    blending: o.additive ? THREE.AdditiveBlending : THREE.NormalBlending, defines: o.outline ? { OUTLINE: '' } : {},
    uniforms: {
      olW: { value: new THREE.Vector2(.012, .009) }, olC: { value: new THREE.Color(.8, .6, 1) }, olA: { value: o.outline ? .9 : 0 },
      map: { value: tex }, tint: { value: new THREE.Color(1, 1, 1) }, alpha: { value: 1 }, flash: { value: new THREE.Color(0, 0, 0) },
      glow: { value: o.glow ?? 0.0 }, fogNear: { value: o.fogNear ?? 60 }, fogFar: { value: o.fogFar ?? 190 }, cut: { value: -2 },
      fogColor: SH.fogColor, lightPos: SH.lightPos, lightCol: SH.lightCol, lightK: SH.lightK, rim: { value: new THREE.Color(0, 0, 0) },
    },
  });
  // emissive mask (tools/glow_mask.py -> <part>_glow.webp): replaces the procedural cyan key above (set glow 0 with it)
  if (o.glowMap) addGlow(m, o.glowMap, { src_var: 'c.rgb', ...(o.glowOpts || {}) });
  return m;
}

// ---------- post: scene -> bright pass (1/4) -> blur x2 -> composite (bloom + vignette + chroma + flash + grade) ----------
const FSQ = new THREE.BufferGeometry();
FSQ.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 3));
const PV = `varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0., 1.); }`;
export class Post {
  constructor(renderer) {
    this.r = renderer;
    const o = { minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: true, type: THREE.UnsignedByteType };
    this.scene = new THREE.WebGLRenderTarget(4, 4, o);
    const ob = { ...o, depthBuffer: false };
    this.a = new THREE.WebGLRenderTarget(4, 4, ob); this.b = new THREE.WebGLRenderTarget(4, 4, ob);
    this.cam = new THREE.Camera(); this.quad = new THREE.Mesh(FSQ, null); this.quad.frustumCulled = false;
    this.sc = new THREE.Scene(); this.sc.add(this.quad);
    const mk = (fs, u) => new THREE.ShaderMaterial({ vertexShader: PV, fragmentShader: fs, uniforms: u, depthTest: false, depthWrite: false });
    this.bright = mk(`uniform sampler2D t; uniform float th; varying vec2 vUv; void main(){ vec3 c = texture2D(t, vUv).rgb; float l = max(c.r, max(c.g, c.b)); gl_FragColor = vec4(c * smoothstep(th, th + 0.35, l), 1.); }`,
      { t: { value: null }, th: { value: 0.8 } });
    this.blur = mk(`uniform sampler2D t; uniform vec2 d; varying vec2 vUv; void main(){ vec3 s = texture2D(t, vUv).rgb * 0.227;
      s += (texture2D(t, vUv + d * 1.385).rgb + texture2D(t, vUv - d * 1.385).rgb) * 0.316; s += (texture2D(t, vUv + d * 3.23).rgb + texture2D(t, vUv - d * 3.23).rgb) * 0.0703; gl_FragColor = vec4(s, 1.); }`,
      { t: { value: null }, d: { value: new THREE.Vector2() } });
    // distortion buffer (1/4 res, RG = 0.5 + screen offset, cleared to 0.5): slash arcs + shockwave rings write into it
    this.d = new THREE.WebGLRenderTarget(4, 4, ob); this.dk = 0.045; this.dClear = new THREE.Color(.5, .5, 0); this._cc = new THREE.Color();
    this.comp = mk(`uniform sampler2D t; uniform sampler2D bl; uniform sampler2D dm; uniform float dk; uniform float asp; uniform float bk; uniform float chroma; uniform vec3 flash; uniform float vig; uniform float sat; uniform vec3 vcol; uniform vec2 ctr;
      varying vec2 vUv; void main(){ vec2 dv = vUv - ctr; float r2 = dot(dv, dv);
        vec2 wp = (texture2D(dm, vUv).rg - .502) * dk; wp.x /= asp; vec2 uv = vUv + wp; // refraction offset (isotropic in pixels)
        vec2 off = dv * chroma * 0.03 * (0.4 + r2 * 2.) + wp * .3; // radial chroma + a chromatic split along the warp edge
        vec3 c = vec3(texture2D(t, uv + off).r, texture2D(t, uv).g, texture2D(t, uv - off).b);
        c += texture2D(bl, uv).rgb * bk;
        float l = dot(c, vec3(.3, .59, .11)); c = mix(vec3(l), c, sat);
        c = mix(c, vcol, smoothstep(0.1, 0.62, r2 * 1.2) * vig);
        c += flash;
#ifdef DITHER
        c += (fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(.06711056, .00583715)))) - .5) / 255.; // +-0.5 LSB dither: breaks 8-bit banding in the sky / vignette, invisible as noise
#endif
        gl_FragColor = vec4(c, 1.); }`,
      { t: { value: null }, bl: { value: null }, dm: { value: null }, dk: { value: 0 }, asp: { value: 1 }, bk: { value: 0.85 }, chroma: { value: 0 }, flash: { value: new THREE.Color(0, 0, 0) }, vig: { value: 0.55 }, sat: { value: 1.08 }, vcol: { value: new THREE.Color(0.04, 0.02, 0.12) }, ctr: { value: new THREE.Vector2(0.5, 0.5) } });
  }
  // w, h = the REAL drawing-buffer size (renderer.getDrawingBufferSize), so the scene target maps 1:1 onto the canvas.
  // o.dpr picks the bloom divisor: bloom stays ~0.75 CSS px per texel (1/4 at 3x, 1/3 at 2x, 1/2 below) so it is never blocky
  // on low-DPR screens; the blur taps are rescaled so the glow radius on screen is the same as the old fixed 1/4 chain.
  // o.samples = MSAA on the scene target (WebGL2), o.bloomDrop = extra /2 on the bloom (automatic quality step).
  size(w, h, o = {}) {
    this.w = w; this.h = h;
    const ms = o.samples || 0; if (this.scene.samples !== ms) { this.scene.samples = ms; this.scene.dispose(); }
    this.scene.setSize(w, h);
    const div = (o.dpr >= 2.5 ? 4 : o.dpr >= 1.75 ? 3 : 2) * (o.bloomDrop ? 2 : 1);
    this.iters = div <= 2 ? 3 : 2; this.tap = 1.2 * (4 / div) * Math.sqrt(2 / this.iters);
    const bw = Math.max(2, Math.round(w / div)), bh = Math.max(2, Math.round(h / div)); this.a.setSize(bw, bh); this.b.setSize(bw, bh);
    this.d.setSize(Math.max(2, w >> 2), Math.max(2, h >> 2)); // distortion offsets are smooth: 1/4 res is plenty
    this.bw = bw; this.bh = bh; this.comp.uniforms.asp.value = w / h;
  }
  // 11-26 perf pass: the composite dither is desktop-only (main.js: post.setDither(!PHONE), ?dither=0/1); phones showed speckle grain
  setDither(on) { this.comp.defines = on ? { DITHER: '' } : {}; this.comp.needsUpdate = true; this.dither = !!on; }
  pass(mat, target) { this.quad.material = mat; this.r.setRenderTarget(target); this.r.render(this.sc, this.cam); }
  render(scene, camera, p, dscene) {
    const r = this.r, pf = this.prof; // prof: optional per-pass GPU timer (main.js __g.passCost), null in normal play
    pf?.('scene'); r.setRenderTarget(this.scene); r.clear(); r.render(scene, camera);
    const du = this.comp.uniforms; du.dk.value = 0; du.dm.value = this.d.texture; this.dOn = false;
    if (dscene && this.dk > 0 && dscene.children.some((m) => m.visible)) { // only when something is warping
      pf?.('distort'); r.getClearColor(this._cc); const ca = r.getClearAlpha(); r.setClearColor(this.dClear, 1);
      r.setRenderTarget(this.d); r.clear(); r.render(dscene, camera); r.setClearColor(this._cc, ca);
      du.dm.value = this.d.texture; du.dk.value = this.dk; this.dOn = true;
    }
    pf?.('bright'); this.bright.uniforms.t.value = this.scene.texture; this.pass(this.bright, this.a);
    // selective bloom: masked sprites (GLOW_LAYER) re-render into the bloom input as emissive only (black body occludes), so the
    // titan blooms exactly at its eyes / runes / cracks instead of wherever it is bright; slashes + sparks keep the threshold
    if (this.glowSel) { pf?.('glowSel'); const au = scene.matrixWorldAutoUpdate; scene.matrixWorldAutoUpdate = false; renderGlowPass(r, scene, camera, this.a); scene.matrixWorldAutoUpdate = au; } // 11-27 PERF PASS: world matrices are fresh from the scene pass (the 2nd full updateMatrixWorld was ~1.5% CPU)
    pf?.('blur'); const it = this.iters || 2, tp = this.tap || 1.2;
    for (let i = 0; i < it; i++) {
      this.blur.uniforms.t.value = this.a.texture; this.blur.uniforms.d.value.set(tp / this.bw, 0); this.pass(this.blur, this.b);
      this.blur.uniforms.t.value = this.b.texture; this.blur.uniforms.d.value.set(0, tp / this.bh); this.pass(this.blur, this.a);
    }
    pf?.('comp'); const u = this.comp.uniforms; u.t.value = this.scene.texture; u.bl.value = this.a.texture;
    u.bk.value = p.bloom; u.chroma.value = p.chroma; u.flash.value.setRGB(p.flash[0], p.flash[1], p.flash[2]); u.vig.value = p.vig; u.sat.value = p.sat;
    this.pass(this.comp, null); pf?.(null);
  }
}

// ---------- GPU-point sparks / embers (additive) ----------
export class Sparks {
  constructor(n, tex) {
    this.n = n; this.i = 0;
    this.pos = new Float32Array(n * 3); this.vel = new Float32Array(n * 3); this.col = new Float32Array(n * 4); this.life = new Float32Array(n); this.max = new Float32Array(n); this.siz = new Float32Array(n); this.grav = new Float32Array(n);
    this.sz = new Float32Array(n);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('size', new THREE.BufferAttribute(this.sz, 1).setUsage(THREE.DynamicDrawUsage));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.u = { px: { value: 1 } };
    this.mesh = new THREE.Points(g, new THREE.ShaderMaterial({
      uniforms: this.u, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `attribute vec4 color; attribute float size; uniform float px; varying vec4 vC; void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.); gl_Position = projectionMatrix * mv; gl_PointSize = size * px / max(0.5, -mv.z); }`,
      fragmentShader: `varying vec4 vC; void main(){ vec2 p = gl_PointCoord - .5; float d = length(p) * 2.; if (d > 1.) discard; float a = pow(1. - d, 1.6); gl_FragColor = vec4(vC.rgb * (0.6 + a), vC.a * a); }`,
    }));
    this.mesh.frustumCulled = false; this.mesh.renderOrder = 400;
  }
  emit(x, y, z, vx, vy, vz, life, size, r, g, b, grav = 0) {
    const i = this.i, j = i * 3, k = i * 4; this.i = (i + 1) % this.n; // 11-27 PERF PASS: no temp arrays per spark (GC on every tap)
    this.pos[j] = x; this.pos[j + 1] = y; this.pos[j + 2] = z; this.vel[j] = vx; this.vel[j + 1] = vy; this.vel[j + 2] = vz;
    this.col[k] = r; this.col[k + 1] = g; this.col[k + 2] = b; this.col[k + 3] = 1;
    this.life[i] = life; this.max[i] = life; this.siz[i] = size; this.grav[i] = grav;
  }
  update(dt) {
    // 11-27 PERF PASS: upload only the span that changed (live sparks + the ones that just died), nothing when the pool is idle
    let lo = this.n, hi = -1;
    for (let i = 0; i < this.n; i++) {
      if (this.life[i] <= 0) { if (this.sz[i] !== 0) { this.sz[i] = 0; if (i < lo) lo = i; hi = i; } continue; }
      if (i < lo) lo = i; hi = i;
      this.life[i] -= dt; const j = i * 3;
      this.vel[j + 1] -= this.grav[i] * dt;
      const d = Math.pow(0.4, dt); this.vel[j] *= d; this.vel[j + 2] *= d; if (this.grav[i] === 0) this.vel[j + 1] *= d;
      this.pos[j] += this.vel[j] * dt; this.pos[j + 1] += this.vel[j + 1] * dt; this.pos[j + 2] += this.vel[j + 2] * dt;
      const t = Math.max(0, this.life[i] / this.max[i]);
      this.sz[i] = this.siz[i] * (0.25 + 0.75 * t); this.col[i * 4 + 3] = Math.min(1, t * 2);
    }
    if (hi < 0) return; const g = this.mesh.geometry.attributes, n = hi - lo + 1;
    g.position.clearUpdateRanges(); g.position.addUpdateRange(lo * 3, n * 3); g.position.needsUpdate = true;
    g.color.clearUpdateRanges(); g.color.addUpdateRange(lo * 4, n * 4); g.color.needsUpdate = true;
    g.size.clearUpdateRanges(); g.size.addUpdateRange(lo, n); g.size.needsUpdate = true;
  }
}

// ---------- slash arc: a crescent that sweeps along its length (additive; white core -> violet edge) ----------
export function arcMat() {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { prog: { value: 0 }, fade: { value: 1 }, c1: { value: new THREE.Color(0.7, 0.45, 1.0) }, c2: { value: new THREE.Color(1, 1, 1) }, bend: { value: 0.42 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }`,
    fragmentShader: `uniform float prog; uniform float fade; uniform vec3 c1; uniform vec3 c2; uniform float bend; varying vec2 vUv;
      void main(){ vec2 p = (vUv - .5) * 2.; // crescent between circle r=1 and circle shifted by bend
        float d1 = length(p); float d2 = length(p - vec2(bend, 0.)); float r = 1.3; float t = (p.y + 1.) * .5;
        float body = smoothstep(1.0, 0.94, d1) * smoothstep(r, r + 0.05, d2);
        float thick = clamp((d2 - r) / max(0.001, (1. - d1) + (d2 - r)), 0., 1.);
        float head = prog * 1.5, tail = head - 0.75;
        float sweep = smoothstep(head, head - 0.12, t) * smoothstep(tail - 0.02, tail + 0.3, t);
        float core = pow(clamp(1. - abs(thick - .55) * 2.2, 0., 1.), 2.);
        vec3 col = mix(c1, c2, core) * (0.9 + core * 1.6);
        float a = body * sweep * fade; gl_FragColor = vec4(col * a, a); }`,
  });
}
// LIGHT slash (normal taps + ghost slashers): one thin tapered crescent stroke THROUGH the quad centre (= the tap point), wiping
// along its length with a fading tail; additive, no texture. bend = curvature.
export function lightArcMat() {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { prog: { value: 0 }, fade: { value: 1 }, c1: { value: new THREE.Color(.62, .42, 1) }, c2: { value: new THREE.Color(1, 1, 1) }, bend: { value: .45 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }`,
    fragmentShader: `uniform float prog; uniform float fade; uniform vec3 c1; uniform vec3 c2; uniform float bend; varying vec2 vUv;
      void main(){ vec2 p = (vUv - .5) * 2.; float yc = bend * (p.x * p.x - .33); float d = abs(p.y - yc);
        float w = .34 * max(0., 1. - p.x * p.x); float body = smoothstep(w, w * .25, d); float core = smoothstep(w * .45, 0., d);
        float head = prog * 2.6 - 1.2; float s = smoothstep(head, head - .2, p.x) * smoothstep(head - 1.9, head - .9, p.x);
        vec3 col = mix(c1, c2, core) * (.9 + core * 1.4); float a = body * s * fade; gl_FragColor = vec4(col * a, a); }`,
  });
}
// painted Codex slash arc (black background, additive): wipes in along its length, white-hot boost, tint toward violet/cyan
export function paintArcMat(tex) {
  return new THREE.ShaderMaterial({
    // premultiplied "screen-like" blend: the white core replaces what is under it, the violet glow adds; stacked arcs saturate
    // toward the arc colours instead of blowing out to a white sheet
    transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide,
    blending: THREE.CustomBlending, blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor, blendEquation: THREE.AddEquation,
    uniforms: { map: { value: tex }, prog: { value: 1 }, fade: { value: 1 }, tint: { value: new THREE.Color(1, 1, 1) }, boost: { value: 1.05 }, dir: { value: 1 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }`,
    fragmentShader: `uniform sampler2D map; uniform float prog; uniform float fade; uniform vec3 tint; uniform float boost; uniform float dir; varying vec2 vUv;
      void main(){ vec3 c = texture2D(map, vUv).rgb; float x = dir > 0. ? vUv.y : 1. - vUv.y; // painted arcs run top to bottom: sweep along them
        float wipe = smoothstep(prog * 1.25, prog * 1.25 - 0.25, x);
        float l = max(c.r, max(c.g, c.b)); vec3 col = c * tint * boost + vec3(pow(l, 4.) * 0.35);
        float a = clamp(l * 1.4 - .15, 0., 1.) * wipe * fade; gl_FragColor = vec4(min(col, vec3(1.)) * wipe * fade, a); }`,
  });
}
// ---------- distortion writers (rendered into Post.d; RG = 0.5 + offset * 0.5, alpha = strength, normal blend) ----------
const DVS = `varying vec2 vUv; varying vec2 vP; varying vec2 vC; uniform float asp;
  void main(){ vUv = uv; vec4 c = projectionMatrix * modelViewMatrix * vec4(0., 0., 0., 1.); vC = c.xy / c.w * vec2(asp, 1.);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); vP = gl_Position.xy / gl_Position.w * vec2(asp, 1.); }`;
const dmat = (fs, u) => new THREE.ShaderMaterial({ transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide, vertexShader: DVS, fragmentShader: fs,
  uniforms: { asp: { value: 1 }, fade: { value: 1 }, amp: { value: 1 }, ...u } });
// slash arc: pushes the picture outward from the arc's centre along the painted band (the crescent's normal), with a fine ripple
export function arcDistMat(tex) {
  return dmat(`uniform sampler2D map; uniform float prog; uniform float fade; uniform float amp; uniform float dir; varying vec2 vUv; varying vec2 vP; varying vec2 vC;
    void main(){ vec3 c = texture2D(map, vUv).rgb; float x = dir > 0. ? vUv.y : 1. - vUv.y; float wipe = smoothstep(prog * 1.25, prog * 1.25 - 0.3, x);
      float l = smoothstep(.04, .5, max(c.r, max(c.g, c.b))); vec2 d = vP - vC; float r = length(d); vec2 n = d / max(r, 1e-4);
      float s = l * wipe * fade * amp * (.75 + .25 * sin(r * 70. - prog * 9.)); gl_FragColor = vec4(.5 + n * .5, 0., clamp(s, 0., 1.)); }`,
  { map: { value: tex }, prog: { value: 0 }, dir: { value: 1 } });
}
// radial shockwave ring: prog 0..1 grows the ring; offset points away from the centre
export function shockDistMat() {
  return dmat(`uniform float prog; uniform float fade; uniform float amp; varying vec2 vUv; varying vec2 vP; varying vec2 vC;
    void main(){ vec2 p = (vUv - .5) * 2.; float d = length(p); float w = .12 + .2 * prog; float ring = smoothstep(w, 0., abs(d - prog)) * step(d, 1.);
      vec2 n = normalize(vP - vC + 1e-5); float s = ring * fade * amp * (1. - prog * .6); gl_FragColor = vec4(.5 + n * .5, 0., clamp(s, 0., 1.)); }`,
  { prog: { value: 0 } });
}
// thin straight streak (additive)
export function streakMat() {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { prog: { value: 0 }, fade: { value: 1 }, c1: { value: new THREE.Color(0.7, 0.5, 1) } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }`,
    fragmentShader: `uniform float prog; uniform float fade; uniform vec3 c1; varying vec2 vUv;
      void main(){ float x = vUv.x, y = abs(vUv.y - .5) * 2.; float w = (1. - y); float taper = sin(3.14159 * x);
        float line = pow(w, 3.) * taper; float sw = smoothstep(prog * 1.3, prog * 1.3 - 0.2, x);
        vec3 col = mix(c1, vec3(1.), pow(w, 6.)) * 2.2; float a = line * sw * fade; gl_FragColor = vec4(col * a, a); }`,
  });
}
// radial glow / blink flash (additive)
export function glowMat(r = 1, g = 1, b = 1) {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { fade: { value: 1 }, col: { value: new THREE.Color(r, g, b) }, ring: { value: 0 }, vs: { value: 0 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }`,
    fragmentShader: `uniform float fade; uniform vec3 col; uniform float ring; uniform float vs; varying vec2 vUv;
      void main(){ vec2 p = (vUv - .5) * 2.; float d = length(p); float a = pow(max(0., 1. - d), 3.2);
        if (ring > 0.) { a = smoothstep(ring, ring - .08, d) * smoothstep(ring - .3, ring - .08, d); }
        if (vs > 0.) { float v = pow(max(0., 1. - abs(p.x) * 6.), 2.) * max(0., 1. - abs(p.y)); a = max(a, v); }
        gl_FragColor = vec4(col * a * fade, a * fade); }`,
  });
}
