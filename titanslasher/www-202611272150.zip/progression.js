// Titan Slasher PROGRESSION (11-27): player level + XP, level-up rewards, gear level requirements. LOGIC ONLY (no DOM, no art):
// the lobby / results UI reads window.PROG and shows PROG.takePending() level-ups (see UI HOOKS at the bottom).
// Save: SAVE.prog = { lv, xp (into the current level), total (all XP ever), dm: { m: minute index, x: dummy XP this minute },
//                     pend: [level-up records not shown yet], seenLv (gear-unlock check), mig }.
// Pure module: nothing is imported, the game passes its pieces to init() so node can unit-test it (tools/test_progression.mjs).
//
// XP curve: need(L) = round(XP_BASE * L^XP_EXP) XP to go from level L to L+1 (Lv1->2 = 500, Lv9->10 = 13,500; Lv 10 = 55,530 in all).
// XP sources (11-28 user, two states): TAPPING (a tap on the training dummy = TAP_XP.you, on a titan = TAP_XP.titan) and NOT
// TAPPING = offline XP (autotrain.js OFFLINE, on the menu or with the app closed). Auto-train is visual only. No fight / login XP.
// Pace: Lv 10 (55,524 XP) is about 2.5-4 hours of semi-fast tapping (4-5 taps/s).
// Level up (11-28 user "fix shard and energy": NO shards and NO energy refill): every CHEST_EVERY levels a chest (rarity chestRarity(L)), max energy +5 at
// Lv 10/20/30 (maxBonus(), read by energy.js). Gear: reqLv(def) by rarity key unless the item / rarity sets reqLv in items.json.
// Test URL: ?lv=N (set the level, xp 0), ?xp=N (add N XP at boot -> level-ups + pending records), ?xpnext=N (N XP short of the
// next level: the next fight levels up on the results screen), ?progreset=1 (wipe SAVE.prog).

// ---------------------------------------------------------------- balance (tune here)
export const XP_BASE = 500, XP_EXP = 1.5, MAX_LV = 100; // 11-27 user: up to Lv 100; 11-28 base 100 -> 500 for tap-only XP
export const TAP_XP = { you: 1, titan: 2 }; // XP per tap of the player's (auto-train hits pay nothing)
export const CHEST_EVERY = 5;
export const chestRarity = (L) => (L >= 30 ? 3 : L >= 15 ? 2 : 1); // rarity index in items.json (0 common, 1 rare, 2 epic, 3 legendary)
export const ENERGY_STEPS = [10, 20, 30], ENERGY_STEP = 5; // max energy +5 at each
// gear level by rarity KEY (items.json rarity[].key). Overrides: items.json item "reqLv", or rarity[i].reqLv.
// NOTE: items.json has 4 tiers (common / rare / epic / legendary), no "fine": so rare = Lv 10. Set rarity[1].reqLv = 5 to soften.
export const REQ_BY_RARITY = { common: 1, fine: 3, rare: 5, epic: 12, legendary: 20 }; // 11-27 user: the old 10 / 20 / 30 was too steep
// existing players (a save from before progression): XP for their past fights, once
export const MIGRATE_XP_PER_FIGHT = 150;

export const need = (L) => (L >= MAX_LV ? Infinity : Math.round(XP_BASE * Math.pow(L, XP_EXP)));
export const totalFor = (L) => { let t = 0; for (let i = 1; i < L; i++) t += need(i); return t; }; // all XP from Lv1 to reach L
export const maxBonus = (L) => ENERGY_STEPS.filter((s) => L >= s).length * ENERGY_STEP;

// ---------------------------------------------------------------- state
const Q = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
const PASS_N = () => (typeof window !== 'undefined' && window.PASS ? window.PASS.N : 1); // game/pass.js (no import: node unit tests load this file alone)
let C = null; // { SAVE, save, EQ (equipment.js), energy (energy.js module or { add, MAX }), now() }
const listeners = new Set();
const nowMs = () => (C && C.now ? C.now() : Date.now());
function st() {
  const S = C.SAVE;
  if (!S.prog || typeof S.prog.lv !== 'number') {
    S.prog = { lv: 1, xp: 0, total: 0, dm: { m: -1, x: 0 }, pend: [], seenLv: 1, mig: 1 };
    const past = (S.titans || 0) * MIGRATE_XP_PER_FIGHT; // veteran: levels for past fights, silently (no pending pop-ups / rewards)
    if (past > 0) { put(S.prog, past); S.prog.seenLv = S.prog.lv; }
  }
  return S.prog;
}
function put(P, x) { P.total += x; P.xp += x; while (P.lv < MAX_LV && P.xp >= need(P.lv)) { P.xp -= need(P.lv); P.lv++; } if (P.lv >= MAX_LV) P.xp = 0; }
const emit = () => listeners.forEach((f) => { try { f(api()); } catch (e) { console.error(e); } });

// ---------------------------------------------------------------- gear level requirements
export function reqLv(d) {
  if (!d) return 1; if (d.reqLv != null) return d.reqLv | 0;
  if (d.trackOnly) return 1; // the 30-day Daily Rewards blade is earned by showing up: always wearable (daily.js equips it on unlock)
  const R = C && C.EQ && C.EQ.DATA ? C.EQ.DATA.rarity[d.rarity] : null;
  if (R && R.reqLv != null) return R.reqLv | 0;
  return REQ_BY_RARITY[R ? R.key : ['common', 'rare', 'epic', 'legendary'][d.rarity]] || 1;
}
export const level = () => (C ? st().lv : 1);
// item instance or id or def -> can the player wear it now?
export function canEquip(it) { const E = C && C.EQ; if (!E || !E.DATA) return true; const d = typeof it === 'object' && it.slot ? it : E.def(it); return level() >= reqLv(d); }
// bag items whose requirement lies in (from, to] (a level-up made them wearable)
export function unlockedBetween(from, to) {
  const E = C && C.EQ; if (!E || !E.DATA) return [];
  return E.items().filter((it) => { const r = reqLv(E.def(it)); return r > from && r <= to; }).map((it) => it.id);
}

// ---------------------------------------------------------------- XP in
// add XP. src: 'tap' | 'auto' | 'test'. Grants each level's rewards at once (coins / energy / chest);
// returns { gained, from, to, ups: [record] }. A record = { lv, coins, chest: { r, id, dup } | null, energyMax: +5 | 0, refill, unlocks: [ids], src }
// and is queued in SAVE.prog.pend until the UI takes it (takePending). Taps save at most every 2 s (a level-up saves at once).
let savedAt = 0;
export function addXp(n, src = 'fight') {
  if (src !== 'test' && src !== 'auto') n *= PASS_N(); // ?pass=N game pass: XP x N ('auto' = offline XP, scaled in autotrain.js)
  const P = st(), x = Math.max(0, Math.round(n)); if (!x) return { gained: 0, from: P.lv, to: P.lv, ups: [] };
  const from = P.lv; put(P, x); const ups = [];
  for (let L = from + 1; L <= P.lv; L++) ups.push(levelReward(L, src));
  if (ups.length) { const un = unlockedBetween(from, P.lv); if (un.length) ups[ups.length - 1].unlocks = un; P.pend.push(...ups); if (P.pend.length > 20) P.pend.splice(0, P.pend.length - 20); if (typeof window !== 'undefined') window.S3A?.log('level_up', { level: P.lv, source: src }); }
  if (ups.length || (src !== 'tap' && src !== 'auto') || Date.now() - savedAt > 2000) { savedAt = Date.now(); C.save(); }
  emit();
  return { gained: x, from, to: P.lv, ups };
}
function levelReward(L, src) {
  const S = C.SAVE, rec = { lv: L, coins: 0, chest: null, energyMax: ENERGY_STEPS.includes(L) ? ENERGY_STEP : 0, refill: false, unlocks: [], src };
  if (L % CHEST_EVERY === 0) {
    const r = chestRarity(L), id = C.chestItem ? C.chestItem(r) : null, g = id && C.EQ && C.EQ.grant(id); // EQ.grant only auto-wears it into an EMPTY slot and only if the level allows
    rec.chest = { r, id, dup: g ? g.dup : false };
  }
  return rec;
}
// one of the player's taps on the dummy. Returns addXp's result
export const tap = () => addXp(TAP_XP.you, 'tap');
// the taps of one titan fight, paid together when it ends
export const fight = (taps) => addXp(taps * TAP_XP.titan, 'tap');

// ---------------------------------------------------------------- UI side
export const takePending = () => { const P = st(), out = P.pend.slice(); P.pend.length = 0; C.save(); return out; };
export const peekPending = () => st().pend.slice();
export const onChange = (f) => { listeners.add(f); return () => listeners.delete(f); };
function api() { const P = st(); return { level: P.lv, xp: P.xp, need: need(P.lv), total: P.total, frac: P.lv >= MAX_LV ? 1 : P.xp / need(P.lv), maxBonus: maxBonus(P.lv) }; }

// ctx: { SAVE, save, EQ, energy?, now?, chestItem?(r) -> item id }
export function init(ctx) {
  C = ctx; if (Q.get('progreset') === '1') delete C.SAVE.prog;
  const P = st();
  if (Q.has('lv')) { const L = Math.max(1, Math.min(MAX_LV, +Q.get('lv') | 0)); P.lv = L; P.xp = 0; P.total = totalFor(L); P.seenLv = L; }
  if (Q.has('xpnext')) P.xp = Math.max(0, need(P.lv) - Math.max(1, +Q.get('xpnext') | 0)); // test: N XP short of the next level
  if (Q.get('allitems') === '1') { let n = 0; const give = () => { const E = C.EQ; if (!E || !E.DATA || !C.SAVE.inv) { if (n++ < 100) setTimeout(give, 100); return; } // 11-27 test: own every item (gear data loads async)
    for (const d of E.DATA.items) if (!E.owned(d.id)) E.grant(d.id); C.save(); }; give(); }
  C.save();
  if (Q.has('xp')) addXp(+Q.get('xp') || 0, 'test');
  if (C.EQ && C.EQ.setReqCheck) C.EQ.setReqCheck(canEquip);
  return api();
}

const PROG = {
  get level() { return C ? st().lv : 1; }, get xp() { return C ? st().xp : 0; }, get need() { return need(C ? st().lv : 1); },
  get maxBonus() { return maxBonus(C ? st().lv : 1); }, get frac() { return C ? api().frac : 0; },
  onChange, addXp, tap, fight, takePending, peekPending, reqLv, canEquip, unlockedBetween, need, totalFor, init, state: () => api(),
};
if (typeof window !== 'undefined') window.PROG = PROG;
export default PROG;
