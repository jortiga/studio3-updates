// Sea reflections (user 11-26: "add reflection on the water. I'm still thinking about whether I like the water.") + a CLOUD SEA
// alternative look (?sea=clouds) to compare.
//
// REFLECTIONS are fake and cheap (no planar render pass, no render target): a mirrored copy of each source mesh that SHARES the
// source's BufferGeometry (the CPU-skinned titan parts follow for free) and its map / tint / alpha / flash / glow uniform objects,
// placed with matrix = R * source.matrixWorld, R = mirror about the sea plane y = SEA_Y. The material (reflMat below, fx.js is
// untouched) clips to below the waterline, fades with depth under it, tints toward the sea, ripples the UVs with the sea noise at
// the WATER-SURFACE point each pixel shows (camera ray -> sea plane), samples a blurrier mip (softness), stretches the eye / rune
// glow masks into bright vertical streaks, thins where the titan's wake churns, and fogs like the sea. Drawn with depthTest off
// right after the opaque sea (renderOrder 31..85: over the back cloud strip, under the titan, mist, front strip, dummy, hero).
// Sources: titan puppet parts, training dummy (base, body, arms, head), the low mid floating ruins (env.js side, high ones fade out).
//
// API: new SeaReflect(scene, { world, q: URLSearchParams, cfg: titan cfg }); update(t, camera, puppet, titanGroup) per frame;
// setStrength(k) (0 = hidden); strengthFor(cfg) = per-arena default (ARENA_REFL, cfg.refl overrides); ?refl=K overrides all,
// ?refl=0 = off entirely (no meshes). ?sea=clouds = cloud sea instead of water (no reflections).
import * as THREE from 'three';
import { SH } from './fx.js';

export const SEA_Y = -.8;
export const REFL_DEFAULT = .55;
export const ARENA_REFL = { skyruins: .55 }; // per arena strength (titan.json "arena"); a titan.json "refl" number overrides
const R_MIRROR = new THREE.Matrix4().set(1, 0, 0, 0, 0, -1, 0, 2 * SEA_Y, 0, 0, 1, 0, 0, 0, 0, 1);

const RVS = `varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`;
const RFS = `uniform sampler2D map; uniform sampler2D n; uniform vec3 tint; uniform float alpha; uniform vec3 flash; uniform float glow;
uniform float str; uniform float seaY; uniform float fadeD; uniform vec2 uvk; uniform float t; uniform vec3 fogColor; uniform vec4 wake; uniform vec3 seaCol; uniform float bodyK; uniform float ws; // ws: water.js waterScale (ripple size / speed follow the depth framing)
#ifdef RGLOW
uniform sampler2D glowMap; uniform vec3 glowK; uniform vec3 glowC0; uniform vec3 glowC1; uniform vec3 glowC2;
#endif
varying vec2 vUv; varying vec3 vW;
void main(){ float dep = seaY - vW.y; if (dep < 0.) discard;
  vec3 cp = cameraPosition; vec3 s = cp + (vW - cp) * ((cp.y - seaY) / max(cp.y - vW.y, 1e-3)); vec2 sp = s.xz; // sea-surface point this pixel shows
  vec2 au = sp / ws; float sd = distance(s, cp); // au = surface point in authored water units
  float n1 = texture2D(n, au * vec2(.045, .15) + vec2(t * .02, -t * .06)).r, n2 = texture2D(n, au * vec2(.12, .42) - vec2(t * .035, t * .1)).r;
  float rip = (n1 * .6 + n2 * .4 - .5) * (.25 + .75 * smoothstep(130., 60., sd / sqrt(ws))), amp = (.35 + min(dep / ws, 24.) * .07) * ws; // world units, grows with depth under the waterline; 11-26 grain: calmer near the horizon (sea point jumps per pixel there)
  vec2 uv = vUv + vec2(rip * amp * uvk.x * 2., (n2 - .5) * .5 * ws * uvk.y);
  vec4 c = texture2D(map, uv, 1.6); float a = c.a * alpha; // +1.6 mip bias: softer than the source
  vec3 col = c.rgb * tint; float cy = clamp((min(c.g, c.b) - c.r - .06) * 3.2, 0., 1.); col += c.rgb * cy * glow;
  col = mix(col, seaCol, .42) * .9;
  vec3 e = vec3(0.);
#ifdef RGLOW
  vec2 sv = vec2(0., uvk.y * ws); // eyes / runes -> bright vertical streaks (4 taps stretched along the reflection)
  vec3 m = texture2D(glowMap, uv).rgb * .5 + (texture2D(glowMap, uv + sv * .9).rgb + texture2D(glowMap, uv - sv * .9).rgb) * .32 + (texture2D(glowMap, uv + sv * 2.2).rgb + texture2D(glowMap, uv - sv * 2.2).rgb) * .2;
#ifdef GLOW_MONO
  m = vec3(m.r, 0., 0.);
#endif
  e = m.x * glowK.x * glowC0 + m.y * glowK.y * glowC1 + m.z * glowK.z * glowC2; col += e * 1.25;
#endif
  float lines = .72 + .28 * smoothstep(-.2, .6, sin(s.z / ws * 2.6 + n1 * 9. - t * 1.3)); // horizontal ripple breaks
  lines = mix(.86, lines, smoothstep(130., 80., sd / ws)); // far: the breaks would be thinner than a pixel, use their average
  float f = exp(-dep / fadeD) * smoothstep(0., .4, dep) * lines;
  vec2 q = (sp - wake.xy) / vec2(wake.z * 1.1, 5. * ws); f *= 1. - smoothstep(1.1, .3, length(q)) * clamp(wake.w, 0., 1.) * .55; // wake foam breaks it
  col = mix(col, fogColor, smoothstep(30., 150., distance(s, cp)) * .75) + flash * .5;
  float A = max(a * bodyK, dot(e, vec3(.3)) * .6) * f * str; if (A < .01) discard; // bodyK < 1: glow-only reflection (lava)
  gl_FragColor = vec4(col, A); }`;

// reflection material for a fx.js spriteMat source: shares its uniform OBJECTS (map, tint, alpha, flash, glow, glow mask + glowK)
function reflMat(src, shared, fadeD) {
  const su = src.uniforms, gl = src.userData.glow;
  const u = { ...shared, map: su.map, tint: su.tint, alpha: su.alpha, flash: su.flash, glow: su.glow || { value: 0 }, fadeD: { value: fadeD }, uvk: { value: new THREE.Vector2(.05, .05) } };
  const defines = {};
  if (gl && gl.glowMap.value) { Object.assign(u, { glowMap: gl.glowMap, glowK: gl.glowK, glowC0: gl.glowC0, glowC1: gl.glowC1, glowC2: gl.glowC2 }); defines.RGLOW = ''; if (src.defines?.GLOW_MONO != null) defines.GLOW_MONO = ''; }
  return new THREE.ShaderMaterial({ vertexShader: RVS, fragmentShader: RFS, uniforms: u, defines, transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide });
}

// ---------- cloud sea floor: same uniforms object as seaFloorMat (rg rings, wake, noise, time), so water.js drives it unchanged ----------
const CFS = (NR) => `uniform sampler2D n; uniform float t; uniform vec3 fogColor; uniform vec4 rg[${NR}]; uniform vec4 wake; varying vec3 vW; varying float vD;
  float H(vec2 p){ vec2 q = p + vec2(t * .5, t * 1.1); // billow height: 3 octaves drifting toward the camera, each warped by the one below
    float b1 = texture2D(n, q * vec2(.022, .009)).r, b2 = texture2D(n, q * vec2(.055, .024) + b1 * .3 + vec2(-t * .004, 0.)).r, b3 = texture2D(n, q * vec2(.14, .06) + b2 * .2 + vec2(t * .006, t * .01)).r;
    return 1. - (abs(b1 * 2. - 1.) * .5 + abs(b2 * 2. - 1.) * .32 + abs(b3 * 2. - 1.) * .18); } // billow noise: rounded puffy lumps
  void main(){ vec2 p = vW.xz; float h = H(p), hl = H(p + vec2(-1.2, -4.)); // second sample toward the sun (back left): slope light
    float lit = clamp(.5 + (h - hl) * 6., 0., 1.), top = smoothstep(.66, .9, h);
    vec3 shadow = vec3(.27, .2, .5), mid = vec3(.5, .42, .76), hi = vec3(.78, .72, .92); // tops stay under the bloom threshold
    vec3 col = mix(shadow, mid, smoothstep(.45, .78, h)); col = mix(col, hi, top * (.35 + .65 * lit)); col *= .85 + .22 * lit;
    float g = exp(-length(p - vec2(0., -42.)) * .03); col += vec3(.1, .45, .6) * g * .35 * (.4 + h); // titan rune light on the cloud tops
    vec2 q = (p - wake.xy) / vec2(wake.z, 6.); float wd = length(q); float fn = texture2D(n, p * .07 + vec2(t * .04, -t * .07)).r;
    float foam = smoothstep(1.2, .2, wd) * smoothstep(.35, .7, fn + (1. - wd) * .3) * wake.w * .8; // churned cloud along the waist
    for (int i = 0; i < ${NR}; i++) { vec4 R = rg[i]; if (R.z < 0.) continue; float d = length((p - R.xy) * vec2(1., 1.15)); float age = R.z;
      float rad = R.w * (1. - exp(-age * 1.3)) * 1.1, k = exp(-age * .8); // puff rings: a soft bright billow pushed outward
      foam += smoothstep(rad * .45 + 1.5, 0., abs(d - rad)) * k * (.6 + .4 * fn) + smoothstep(rad + .5, 0., d) * exp(-age * 1.1) * .5; }
    col = mix(col, vec3(.84, .8, .95), clamp(foam, 0., 1.) * .75);
    col = mix(col, fogColor, smoothstep(45., 150., vD) * .7); gl_FragColor = vec4(col, 1.); }`;

const rnd = (a, b) => a + Math.random() * (b - a);
export class SeaReflect {
  constructor(scene, o = {}) {
    const q = o.q || new URLSearchParams(location.search), w = this.world = o.world;
    this.scene = scene; this.cloud = q.get('sea') === 'clouds';
    const rq = q.get('refl'); this.off = rq === '0' || this.cloud;
    this.forced = rq != null && rq !== '' && !isNaN(+rq); // ?refl=K wins over the arena theme
    this.strength = this.forced ? +rq : SeaReflect.strengthFor(o.cfg);
    this.seaMat = w?.water?.o?.seaMat; this.noise = w?.water?.o?.noise;
    this.floor = scene.children.find((m) => m.isMesh && m.material === this.seaMat) || null;
    if (this.cloud) this.initClouds(o);
    if (this.off || !this.seaMat) { this.off = true; return; }
    this.shared = { n: { value: this.noise }, t: SH.time, fogColor: SH.fogColor, str: { value: this.strength }, seaY: { value: SEA_Y }, wake: this.seaMat.uniforms.wake, ws: this.seaMat.uniforms.ws, seaCol: { value: new THREE.Color(.3, .22, .58) }, bodyK: { value: 1 } };
    this.list = []; // { src, m, kind } plain mirrored sprites (dummy, env)
    this.root = new THREE.Group(); this.root.name = 'reflections'; scene.add(this.root);
    // titan: one mirrored group, children share the skinned geometry
    this.tg = new THREE.Group(); this.tg.matrixAutoUpdate = false; this.root.add(this.tg); this.tparts = []; this.pup = null;
    // dummy parts (base / body / arms / head), behind the dummy, over the titan's reflection
    const d = w?.dummy; if (d) [d.base, d.arms, d.body, d.head].forEach((src, i) => this.add(src, 7, 80 + i * .1, 'dummy'));
    // env mid floating ruins: only the low ones (a high ruin's reflection starts so deep that it fades out completely)
    for (const s of w?.env?.side || []) if (s.bob && s.z < -40 && s.m.material.uniforms) this.add(s.m, 9, 31 + Math.round(-s.z / 20), 'env', s);
    this.setStrength(this.strength);
  }
  static strengthFor(cfg) { if (cfg && typeof cfg.refl === 'number') return cfg.refl; return ARENA_REFL[cfg?.arena] ?? REFL_DEFAULT; }
  add(src, fadeD, ro, kind, side) { const m = new THREE.Mesh(src.geometry, reflMat(src.material, this.shared, fadeD)); m.matrixAutoUpdate = false; m.renderOrder = ro; m.frustumCulled = false;
    this.root.add(m); this.list.push({ src, m, kind, side }); return m; }
  setStrength(k) { this.strength = k; if (this.off) return; this.shared.str.value = k; this.root.visible = k > 0; }
  setArena(cfg) { if (!this.forced) this.setStrength(SeaReflect.strengthFor(cfg)); }
  // 11-26 arenas (arena.js): r = theme.refl { k: strength, body: 0..1 (0 = only the glowing runes / eyes reflect, lava), col: sea tint }
  // a titan.json "refl" number still overrides the arena strength; ?refl=K overrides both
  setTheme(r = {}, cfg) {
    if (this.off) return; if (r.col) this.shared.seaCol.value.setRGB(r.col[0], r.col[1], r.col[2]); this.shared.bodyK.value = r.body ?? 1;
    if (!this.forced) this.setStrength(typeof cfg?.refl === 'number' ? cfg.refl : r.k ?? REFL_DEFAULT);
  }
  buildTitan(puppet) {
    for (const r of this.tparts) { this.tg.remove(r.m); r.m.material.dispose(); } this.tparts = []; this.pup = puppet; if (!puppet) return;
    for (const p of puppet.parts) { const m = new THREE.Mesh(p.mesh.geometry, reflMat(p.mesh.material, this.shared, 13)); m.frustumCulled = false; this.tg.add(m); this.tparts.push({ p, m }); }
  }
  update(t, camera, puppet, titanGroup) {
    if (this.cloud) this.updateClouds(t, camera, titanGroup);
    if (this.off || !this.root.visible) return;
    if (puppet !== this.pup) this.buildTitan(puppet);
    const e = new THREE.Vector3();
    if (puppet && titanGroup) { // titan: mirror of the puppet group's world matrix; draw order follows puppet.drawOrder()
      titanGroup.updateMatrixWorld(true); let vis = titanGroup.visible; for (let o = titanGroup.parent; o && vis; o = o.parent) vis = o.visible;
      this.tg.visible = vis; this.tg.matrix.multiplyMatrices(R_MIRROR, puppet.group.matrixWorld); this.tg.matrixWorldNeedsUpdate = true;
      e.setFromMatrixScale(puppet.group.matrixWorld); const top = puppet.group.matrixWorld.elements[13] + (puppet.bounds.y1 - puppet.bounds.y0) * puppet.k * e.y;
      if (top < SEA_Y) this.tg.visible = false; // fully sunk (intro / exit)
      for (const { p, m } of this.tparts) { m.renderOrder = p.mesh.renderOrder - 60; m.visible = p.mesh.visible;
        const bb = p.bb; m.material.uniforms.uvk.value.set(1 / Math.max(.5, (bb[2] - bb[0]) * e.x), 1 / Math.max(.5, (bb[3] - bb[1]) * e.y)); }
    }
    for (const r of this.list) { const s = r.src; let vis = s.visible; for (let o = s.parent; o && vis; o = o.parent) vis = o.visible;
      if (vis) { s.updateWorldMatrix(true, false); e.setFromMatrixScale(s.matrixWorld); const bottom = s.matrixWorld.elements[13] - Math.abs(e.y) * .5;
        vis = bottom - SEA_Y < r.m.material.uniforms.fadeD.value * 1.6; // its reflection would start below the fade: skip the draw
        if (vis) { r.m.matrix.multiplyMatrices(R_MIRROR, s.matrixWorld); r.m.matrixWorldNeedsUpdate = true; r.m.material.uniforms.uvk.value.set(1 / Math.max(.3, Math.abs(e.x)), 1 / Math.max(.3, Math.abs(e.y))); } }
      r.m.visible = vis; }
  }
  // ---------- ?sea=clouds: a thick rolling cloud sea instead of water ----------
  initClouds(o) {
    const w = this.world, sm = this.seaMat; if (!sm || !this.floor) return;
    const NR = sm.uniforms.rg.value.length;
    this.floor.material = new THREE.ShaderMaterial({ fog: false, uniforms: sm.uniforms, vertexShader: sm.vertexShader, fragmentShader: CFS(NR) }); // same uniform objects: water.js keeps driving wake + rings
    const env = w.env;
    for (const m of [env?.seaFront, ...(env?.items || []).filter((it) => it.m !== env?.seaFront && it.m.material.uniforms?.shimmer && it.m.position.z > -100).map((it) => it.m)]) { if (!m) continue; // painted cloud strips: denser + whiter, no water shimmer
      const u = m.material.uniforms; u.tint.value.setRGB(.92, .86, 1.02); u.shimmer.value = 0; u.glow.value = .15; }
    for (const it of w.mist || []) { const u = it.m.material.uniforms; u.tint.value.setRGB(.72, .64, .95); u.alpha.value = .5; } // base mist around the waist: white, thicker
    // cloud wisps hugging the titan's body at the waterline: in front (over his legs / waist) and a few behind
    this.wisps = []; const puff = w.water?.o?.puff;
    if (puff) for (let i = 0; i < 9; i++) { const front = i < 6, m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: puff, transparent: true, depthWrite: false, depthTest: false, color: front ? 0xa99cd6 : 0x8f80c4, opacity: 0, fog: false }));
      m.renderOrder = front ? 131 + i * .01 : 99; const sc = front ? rnd(12, 22) : rnd(24, 36); m.scale.set(sc, sc * .38, 1);
      const it = { m, x: rnd(-26, 26), y: front ? rnd(-1.6, .6) : rnd(0, 2.5), z: front ? rnd(-38, -34) : rnd(-50, -46), sp: rnd(.4, 1.1) * (i % 2 ? 1 : -1), ph: rnd(0, 6), a: front ? rnd(.35, .55) : .45 };
      this.scene.add(m); this.wisps.push(it); }
    // water splashes -> cloud bursts: painted splash sheets go white (fogged to a cloud colour), every splash throws extra puffs
    const water = w.water; if (!water) return; const white = { value: new THREE.Color(.8, .75, .95) };
    for (const m of water.cols) m.material.uniforms.fogColor = white;
    const col = water.column.bind(water); water.column = (...a) => { col(...a); for (const m of water.cols) if (m.visible && m.material.uniforms.fogK) m.material.uniforms.fogK.value = Math.max(m.material.uniforms.fogK.value, .72); };
    for (const m of water.puffs) m.material.color.setRGB(.85, .8, .98);
    const spl = water.splash.bind(water); water.splash = (p, power = 1, so = {}) => { spl(p, power, so); const P = power;
      for (let i = 0; i < Math.round(3 * P + 1); i++) water.puff(p.x + rnd(-6, 6) * P, water.seaY + rnd(.5, 4) * P, p.z + 2, 9 * P, 24 * P, rnd(1.8, 3), .5, rnd(-2, 2), rnd(.3, 1.2)); };
    this.lastT = 0;
  }
  updateClouds(t, camera, titanGroup) {
    if (!this.wisps) return; const dt = Math.min(.05, Math.max(0, t - this.lastT)); this.lastT = t;
    const tx = titanGroup ? titanGroup.position.x : 0, on = !titanGroup || titanGroup.visible;
    for (const it of this.wisps) { it.x += it.sp * dt; if (it.x > 30) it.x -= 60; else if (it.x < -30) it.x += 60; const e = Math.min(1, (30 - Math.abs(it.x)) / 8);
      const m = it.m; m.visible = on; m.position.set(tx + it.x, it.y + Math.sin(t * .4 + it.ph) * .5, it.z); m.quaternion.copy(camera.quaternion);
      m.material.opacity = it.a * e * (.85 + .15 * Math.sin(t * .5 + it.ph)); }
  }
}
export { SeaReflect as Reflect };
