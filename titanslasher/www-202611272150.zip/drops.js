// Titan Slasher TITAN DROPS (11-27): what a titan fight drops on the results screen. LOGIC ONLY (no DOM).
// Replaces the old single maybe-chest (equipment.js rollDrop) once wired: ONE guaranteed drop + extra rolls for milestones (runes
// broken, best combo, damage thresholds, rank). Rarity odds move from WEIGHTS.low toward WEIGHTS.high with a performance score
// perf 0..1 (rank percentile + damage). Each titan has SIGNATURE items (reused item defs, no new art) that show up more often
// in its drops. Drops go straight into the inventory (EQ.grant: a duplicate = another copy in the bag, 11-27) and may be above your level
// (owned, locked until progression.js says the level is reached; EQ.grant never auto-wears a locked item).
// Pure module: the game passes EQ (equipment.js) to init() or to roll(); node tests: tools/test_progression.mjs.
// Test URL: ?drops=N forces N rolls, ?droprar=R forces rarity R (0-3) on every roll.

// ---------------------------------------------------------------- balance (tune here)
export const WEIGHTS = { low: [100, 0, 0, 0], high: [75, 20, 4.5, 0.5] }; // common, rare, epic, legendary (11-27 user: a common chest by default; a great fight can turn it rare+)
export const MILESTONES = [ // each one met = +1 extra roll (MAX_EXTRA at most)
  { k: 'runes', min: 5, label: '5 RUNES BROKEN' }, { k: 'runes', min: 15, label: '15 RUNES BROKEN' },
  { k: 'combo', min: 100, label: 'COMBO x100' }, { k: 'combo', min: 300, label: 'COMBO x300' },
  { k: 'score', min: 250000, label: '250K DAMAGE' }, { k: 'score', min: 1000000, label: '1M DAMAGE' }, { k: 'score', min: 4000000, label: '4M DAMAGE' },
  { k: 'rank', max: 3, label: 'TOP 3' },
];
export const CHEST_CHANCE = 0.10; // 11-27 user: 10%, mostly common, start from there // 11-27 user: one chest per kill at this chance (no guaranteed drop, no milestone extras)
export const MAX_EXTRA = 2; // 11-27 user: 5 items a kill was too much -> 1 guaranteed + at most 2 extra (economy plan: 1-3 per fight)
export const SIG_CHANCE = 0.3; // a roll picks from the titan's signature list (items of the rolled rarity or lower) when it can
export const PERF_SCORE_FULL = 3000000; // damage that counts as perfect for the damage half of perf
// signature items per titan id (titans/<id>/); reuse existing defs. golem_ink = the ink-style golem.
export const SIGNATURE = {
  golem: ['w_verdant', 'armor_2', 'boots_1', 'amulet_3'], // stone + moss: Thornheart, Runeguard, Iron Visage, Sunheart
  golem_ink: ['w_void', 'ring_2', 'amulet_2', 'charm_2'], // ink: Voidreaver, Sapphire Signet, Moonshard, Clover Seal
  hydra_ink: ['w_verdant', 'boots_2'], // = hydra
  // 11-27 ink roster (= their default-style titan)
  cerberus_ink: ['w_ember', 'ring_3'], frost_ink: ['w_frost', 'amulet_2'], clockwork_ink: ['w_storm', 'charm_1'], chimera_ink: ['w_ember', 'armor_3'],
  kraken_ink: ['w_frost', 'ring_2'], candy_ink: ['charm_3', 'charm_1'], watcher_ink: ['amulet_4', 'ring_4'], strider_ink: ['w_storm', 'ring_3'],
  cerberus: ['w_ember', 'ring_3'], frost: ['w_frost', 'amulet_2'], hydra: ['w_verdant', 'boots_2'], clockwork: ['w_storm', 'charm_1'],
  chimera: ['w_ember', 'armor_3'], kraken: ['w_frost', 'ring_2'], candy: ['charm_3', 'charm_1'], watcher: ['amulet_4', 'ring_4'],
};

import PASS from './pass.js'; // ?pass=N game pass: chest chance x N (max 100%)
const Q = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
let EQ0 = null;
export const init = (eq) => { EQ0 = eq; };
const pickW = (w, r) => { let t = w.reduce((a, b) => a + b, 0) * r; for (let i = 0; i < w.length; i++) if ((t -= w[i]) <= 0) return i; return w.length - 1; };
const lerp = (a, b, t) => a + (b - a) * t;

// performance 0..1: rank percentile (60%) + damage on a log scale (40%)
export function perf(o) {
  const n = Math.max(1, o.n | 0), r = o.rank | 0, pr = r > 0 ? 1 - (r - 1) / Math.max(1, n - 1) : 0;
  const ds = Math.min(1, Math.log(1 + Math.max(0, +o.score || 0) / 1000) / Math.log(1 + PERF_SCORE_FULL / 1000));
  return Math.max(0, Math.min(1, .6 * pr + .4 * ds));
}
export const weights = (p) => WEIGHTS.low.map((v, i) => lerp(v, WEIGHTS.high[i], p));
export function milestones(o) {
  return MILESTONES.filter((m) => (m.k === 'rank' ? (o.rank | 0) > 0 && (o.rank | 0) <= m.max : (+o[m.k] || 0) >= m.min)).slice(0, MAX_EXTRA);
}
// an item of exactly rarity r (falls to lower rarities if empty), never trackOnly / starter; things you don't own first (75%)
export function chestItem(r, eq = EQ0, rnd = Math.random) {
  const X = eq && eq.DATA; if (!X) return null;
  for (let q = r; q >= 0; q--) {
    const pool = X.items.filter((d) => d.rarity === q && !d.trackOnly && !X.starter.includes(d.id)); if (!pool.length) continue;
    const fresh = pool.filter((d) => !eq.owned(d.id)), use = fresh.length && rnd() < .75 ? fresh : pool;
    return use[Math.floor(rnd() * use.length)].id;
  }
  return null;
}
function sigItem(titan, r, eq, rnd) {
  const X = eq.DATA, ids = (SIGNATURE[titan] || SIGNATURE[String(titan).replace(/_ink$/, '')] || []).filter((id) => X.byId[id] && X.byId[id].rarity <= r && !X.byId[id].trackOnly);
  return ids.length ? ids[Math.floor(rnd() * ids.length)] : null;
}

// roll the fight's drops. o: { score, runes, combo, rank, n, titan (id string) }; opts: { eq, grant (default true), rnd }
// returns { perf, rolls: [{ id, r, sig, why, dup, lv, locked? }], milestones: [labels] }. With grant, items are in the inventory.
export function roll(o = {}, opts = {}) {
  const eq = opts.eq || EQ0, rnd = opts.rnd || Math.random, grant = opts.grant !== false;
  if (!eq || !eq.DATA) return { perf: 0, rolls: [], milestones: [] };
  const p = perf(o), w = weights(p), ms = milestones(o);
  let n = rnd() < Math.min(1, CHEST_CHANCE * PASS.N) ? 1 : 0; if (Q.has('drops')) n = Math.max(1, +Q.get('drops') | 0); // 11-27 user: a kill = shards + ONE chest chance, that's it (milestones only raise the rarity odds via perf)
  const forceR = Q.has('droprar') ? Math.max(0, Math.min(3, +Q.get('droprar') | 0)) : null;
  const rolls = [];
  for (let i = 0; i < n; i++) {
    const r = forceR ?? pickW(w, rnd()); let id = null, sig = false;
    if (rnd() < SIG_CHANCE) { id = sigItem(o.titan, r, eq, rnd); sig = !!id; }
    if (!id) id = chestItem(r, eq, rnd); if (!id) continue;
    const d = eq.DATA.byId[id], rec = { id, r: d.rarity, sig, why: i === 0 ? 'DROP' : ms[i - 1] ? ms[i - 1].label : 'BONUS' };
    if (grant) { const g = eq.grant(id); rec.dup = g.dup; rec.lv = g.it.lv; rec.uid = g.it.uid; }
    if (typeof window !== 'undefined' && window.PROG) rec.locked = !window.PROG.canEquip(id);
    rolls.push(rec);
  }
  return { perf: p, rolls, milestones: ms.map((m) => m.label) };
}

const DROPS = { roll, perf, weights, milestones, chestItem, init, SIGNATURE };
if (typeof window !== 'undefined') window.DROPS = DROPS;
export default DROPS;

/* ---------------------------------------------------------------- UI HOOKS (TODO, wire after the main-menu rebuild)
 main.js boot: DROPS.init(EQ) after EQ.load().
 main.js results: replace `const drop = EQ.rollDrop(rank, n)` with
     const dr = DROPS.roll({ score, runes: G.wpBroken, combo: G.bestCombo, rank, n, titan: <titan folder id, e.g. world.titanId> });
   results screen: a row of drop cards (item icon via uiart.js itemIcon(def.icon), rarity colour, "NEW" / "+1 LV", a SIGNATURE tag
   when rec.sig, padlock + "Lv N" when rec.locked) with the milestone label under each extra card; sfx 'card' per card, 'rank' for epic+.
*/
