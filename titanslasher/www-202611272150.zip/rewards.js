// Titan Slasher DAILY WINNER REWARDS, client side (11-27). LOGIC ONLY (no DOM). Server: server/rewards.sql (lb_my_reward /
// lb_claim_reward / lb_winners, top 20 real players of each UTC day, claim once per day per player, enforced on the server).
// Flow: boot -> REWARDS.check() -> { day, rank, titan, titanName, damage, coins, chest, xp, energy, title, yesterday } or null.
// The UI shows "YESTERDAY: YOU PLACED #7 vs <titan>" + CLAIM -> REWARDS.claim(r) -> server marks it claimed -> the reward is paid
// locally (coins, chest item, XP, energy, title) and returned for the reveal. Degrades silently: no server / functions not
// deployed yet (404) / offline / not registered -> check() resolves null and nothing shows.
// Title: SAVE.title = { name, day } is "active" on UTC day `day` only (the day after the win): REWARDS.title() -> name | null.
// Test URL: ?rewardtest=N fakes a placed-#N reward for yesterday (claim pays locally, no server call).

// local mirror of lb_reward_tiers (rewardtest only; the server row is the truth)
export const TIERS = [[1, 1, 5000, 'epic', 400, 0, 'Titan Slayer'], [2, 3, 2500, 'rare', 250, 0, null], [4, 10, 1200, 'fine', 150, 0, null], [11, 20, 600, null, 150, 15, null]];
const DAY = 86400000;
const Q = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
const TEST = Q.has('rewardtest') ? Math.max(1, +Q.get('rewardtest') | 0) : 0;
let C = null; // { SAVE, save, EQ, PROG, energy, chestItem(r), LB }
const lb = () => (C && C.LB) || (typeof window !== 'undefined' ? window.__lb : null);
const today = () => { const L = lb(); return Math.floor((L && L.now ? L.now() : Date.now()) / DAY); };

// chest rarity KEY (server) -> items.json rarity index. items.json has no 'fine' tier: 'fine' = the 2nd tier (index 1).
export function chestRarity(key, eq = C && C.EQ) {
  if (!key) return null; const R = eq && eq.DATA ? eq.DATA.rarity : null;
  const i = R ? R.findIndex((r) => r.key === key) : -1; if (i >= 0) return i;
  return { common: 0, fine: 1, rare: 1, epic: 2, legendary: 3 }[key] ?? 1;
}
function deco(w) {
  if (!w) return null; const L = lb(), t = today();
  return { ...w, titanName: (L && L.names && L.names[w.titan]) || 'THE TITAN', yesterday: w.day === t - 1, test: !!w.test };
}
function fake() {
  const t = TIERS.find(([a, b]) => TEST >= a && TEST <= b); if (!t) return null;
  return { day: today() - 1, rank: TEST, titan: 0, damage: 1234567, coins: t[2], chest: t[3], xp: t[4], energy: t[5], title: t[6], test: true };
}

// newest unclaimed reward (or null). Never throws.
export async function check() {
  if (TEST) return deco(fake());
  const L = lb(); if (!L || !L.configured || !L.rpc || !L.auth) return null;
  try { if (L.register && !(await L.register())) return null; const j = await L.rpc('lb_my_reward', L.auth()); return deco(j && j.reward); }
  catch (e) { return null; } // 404 = rewards.sql not applied yet, offline, ...
}
// claim on the server, then pay locally. Returns { ok, paid: { coins, chest: { r, id, dup } | null, xp, energy, title } } or { ok: false, error }
export async function claim(w) {
  if (!w) return { ok: false, error: 'none' };
  let row = w;
  if (!w.test) {
    const L = lb(); if (!L || !L.rpc) return { ok: false, error: 'offline' };
    try { const j = await L.rpc('lb_claim_reward', { ...L.auth(), p_day: w.day }); if (!j || !j.ok) return { ok: false, error: (j && j.error) || 'fail' }; row = { ...w, ...j.reward }; }
    catch (e) { return { ok: false, error: 'offline' }; }
  }
  return { ok: true, paid: pay(row) };
}
function pay(w) {
  const S = C.SAVE, paid = { coins: w.coins | 0, chest: null, xp: w.xp | 0, energy: w.energy | 0, title: w.title || null };
  S.coins = (S.coins || 0) + paid.coins;
  const r = chestRarity(w.chest);
  if (r != null) { const id = C.chestItem ? C.chestItem(r) : null, g = id && C.EQ && C.EQ.grant(id); paid.chest = { r, id, dup: g ? g.dup : false }; }
  if (paid.energy) { const E = C.energy || (typeof window !== 'undefined' ? window.ENERGY : null); try { E && E.add && E.add(paid.energy); } catch (e) { /* no energy yet */ } }
  if (paid.title) S.title = { name: paid.title, day: w.day + 1 };
  S.rwLast = { day: w.day, rank: w.rank }; C.save();
  return paid;
}
export const title = () => { const t = C && C.SAVE.title; return t && t.day === today() ? t.name : null; };

// yesterday's top 3 for leaderboard crowns: { day, top: [{ rank, name, title }] } or null (cached per day)
let winP = null, winDay = null;
export function winners() {
  const L = lb(); if (!L || !L.configured || !L.rpc) return Promise.resolve(null);
  const d = today() - 1; if (winP && winDay === d) return winP; winDay = d;
  winP = L.rpc('lb_winners', { p_day: d }).then((j) => (j && j.closed ? { day: j.day, top: (j.top || []).map((a) => ({ rank: +a[0], name: a[1], title: a[2] })) } : null)).catch(() => null);
  return winP;
}
// crown for a leaderboard name: '#1' | '#2' | '#3' | null (names aren't unique: a cheap, cosmetic match)
export async function crownOf(name) { const w = await winners(); const r = w && w.top.find((x) => x.name === name); return r ? r.rank : null; }

// ctx: { SAVE, save, EQ, PROG, energy, chestItem(r) (drops.js), LB (leaderboard.js LB) }
export function init(ctx) { C = ctx; }

const REWARDS = { init, check, claim, title, winners, crownOf, chestRarity, TIERS };
if (typeof window !== 'undefined') window.REWARDS = REWARDS;
export default REWARDS;

/* ---------------------------------------------------------------- UI HOOKS (TODO, wire after the main-menu rebuild)
 main.js boot (after PROG / DROPS init): REWARDS.init({ SAVE, save, EQ, PROG, energy: ENERGY, chestItem: DROPS.chestItem, LB });
   on the first lobby entry (after DAILY's popup closes, never in a fight): REWARDS.check().then((w) => w && popup(w)).
 popup: `${w.yesterday ? 'YESTERDAY' : 'DAY ' + w.day}: YOU PLACED #${w.rank} vs ${w.titanName}` + damage + reward list
   (coins, chest rarity, XP, energy, title) + CLAIM -> REWARDS.claim(w) -> reveal paid (chest item icon, coins fly), sfx 'victory';
   error 'claimed' -> just close. Check again on the next app open (another unclaimed day may be waiting).
 leaderboard (RANKS tab / results board rows): REWARDS.winners() once, a small crown next to rows whose name matches top[].name
   (gold #1, silver #2, bronze #3) and the "TITAN SLAYER" badge next to #1 today.
 profile / top bar: REWARDS.title() -> show the title badge under the nickname today.
*/
