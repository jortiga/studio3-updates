// numfx.js (11-26 perf pass, user: "apply reusing of text, or maybe use an image instead"): floating damage numbers, combo /
// crit numbers and the weak-point xN counters drawn in WebGL instead of the DOM. A bitmap font atlas of the game font (Anton) is
// painted ONCE at boot onto a canvas: R = glyph fill, G = hard drop shadow (0.1em down), B = soft glow (blurred). The shader tints
// the three layers per style (fill / shadow / glow colours like the old CSS text-shadows), so one atlas serves every colour.
// Every glyph is one instance of a single InstancedMesh: ONE draw call for all numbers, no DOM nodes, no layout, no CSS animation.
// Immediate mode: NFX.begin() once per frame, NFX.text(str, x, y, sizePx, style, alpha, scale) for every visible number (CSS px,
// centred), NFX.draw(renderer, W, H) after the post chain (straight onto the canvas, over the composite).
import * as THREE from 'three';

const GLYPHS = '0123456789,.KMBx!+#-%';
const FONT = 128, CW = 140, CH = 184, PAD_GLOW = .17; // atlas font px, cell size px, glow sigma in em
// styles: [fill, hard shadow, glow, glow strength]. Same colours as the old CSS (.num / .dmg / .wpc / ghost .gc0-3)
const STYLES = {
  slash: ['#f1e6ff', '#3a1b86', '#8a4dff', 1], wp: ['#e9feff', '#06526b', '#28d8ff', 1.1], crit: ['#ffd35a', '#7a3b00', '#ff9d2b', 1.1],
  fin: ['#ffffff', '#5a0d6e', '#ff7ae0', 1.35], train: ['#c9c0de', '#3a1b86', '#8a4dff', .8], tap: ['#ffffff', '#3a1b86', '#8a4dff', 1],
  wpc: ['#ffffff', '#06526b', '#28d8ff', 1.5], ghost: ['#bff6ff', '#06526b', '#28d8ff', .55],
  gc0: ['#b8fbff', '#06526b', '#28d8ff', .8], gc1: ['#ffe39a', '#7a3b00', '#ff9d2b', .8], gc2: ['#ffb3bd', '#6b0a1c', '#ff4f6d', .8], gc3: ['#b9ffc2', '#0b5a1a', '#3dff6a', .8],
  slashD: ['#e6d3ff', '#3a1b86', '#8a4dff', 1], trainD: ['#b9b0cf', '#3a1b86', '#8a4dff', .8], wpD: ['#53f3ff', '#06526b', '#28d8ff', 1],
};
const SNAMES = Object.keys(STYLES), SIDX = Object.fromEntries(SNAMES.map((n, i) => [n, i]));
const MAX = 640; // glyph instances

const VS = `attribute vec4 iA; attribute vec4 iB; attribute vec4 iUv; uniform vec2 scr; uniform vec2 cell; varying vec2 vUv; varying vec2 vS; varying vec2 vQ;
void main(){ vec2 q = position.xy; vQ = q; vec2 hs = cell * iA.z; // iA = (x, y, size px, alpha), iB = (style, -, -, -)
  vec2 p = iA.xy + vec2(q.x, -q.y) * hs; vUv = mix(iUv.xy, iUv.zw, q + .5); vS = vec2(iA.w, iB.x);
  gl_Position = vec4(p.x / scr.x * 2. - 1., 1. - p.y / scr.y * 2., 0., 1.); }`;
const FS = `uniform sampler2D map; uniform vec3 cF[${SNAMES.length}]; uniform vec3 cS[${SNAMES.length}]; uniform vec4 cG[${SNAMES.length}]; varying vec2 vUv; varying vec2 vS; varying vec2 vQ;
void main(){ vec3 t = texture2D(map, vUv).rgb; int s = int(vS.y + .5); vec3 F = cF[0], S = cS[0]; vec4 G = cG[0];
  for (int i = 0; i < ${SNAMES.length}; i++) if (i == s) { F = cF[i]; S = cS[i]; G = cG[i]; }
  vec2 e = smoothstep(.5, .42, abs(vQ)); float g = clamp(t.b * G.a * e.x * e.y, 0., 1.); /* edge fade: mip bleed never shows as a box */ vec3 c = G.rgb * g; float a = g;   // glow
  c = S * t.g + c * (1. - t.g); a = t.g + a * (1. - t.g);                // hard shadow
  c = F * t.r + c * (1. - t.r); a = t.r + a * (1. - t.r);                // fill
  gl_FragColor = vec4(c, a) * vS.x; }`;

export class NumFX {
  constructor() {
    this.n = 0; this.adv = {}; this.ready = false;
    this.cv = document.createElement('canvas'); this.cols = Math.floor(2048 / CW); this.cv.width = 2048; this.cv.height = Math.pow(2, Math.ceil(Math.log2(Math.ceil(GLYPHS.length / this.cols) * CH)));
    this.tex = new THREE.CanvasTexture(this.cv); this.tex.colorSpace = THREE.NoColorSpace; this.tex.generateMipmaps = true; this.tex.minFilter = THREE.LinearMipmapLinearFilter;
    const g = new THREE.InstancedBufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-.5, -.5, 0, .5, -.5, 0, .5, .5, 0, -.5, .5, 0]), 3)); g.setIndex([0, 1, 2, 0, 2, 3]);
    this.A = new Float32Array(MAX * 4); this.B = new Float32Array(MAX * 4); this.U = new Float32Array(MAX * 4);
    for (const [k, arr] of [['iA', this.A], ['iB', this.B], ['iUv', this.U]]) g.setAttribute(k, new THREE.InstancedBufferAttribute(arr, 4).setUsage(THREE.DynamicDrawUsage));
    g.instanceCount = 0; this.geo = g;
    const col = (c) => new THREE.Color(c);
    this.mat = new THREE.ShaderMaterial({ vertexShader: VS, fragmentShader: FS, transparent: true, depthTest: false, depthWrite: false,
      blending: THREE.CustomBlending, blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor, blendEquation: THREE.AddEquation,
      uniforms: { map: { value: this.tex }, scr: { value: new THREE.Vector2(1, 1) }, cell: { value: new THREE.Vector2(CW / FONT, CH / FONT) },
        cF: { value: SNAMES.map((n) => col(STYLES[n][0])) }, cS: { value: SNAMES.map((n) => col(STYLES[n][1])) },
        cG: { value: SNAMES.map((n) => { const c = col(STYLES[n][2]); return new THREE.Vector4(c.r, c.g, c.b, STYLES[n][3]); }) } } });
    this.mesh = new THREE.Mesh(g, this.mat); this.mesh.frustumCulled = false;
    this.scene = new THREE.Scene(); this.scene.add(this.mesh); this.cam = new THREE.Camera();
    this.paint(); // fallback font now, repaint when Anton is in
    try { document.fonts.load(`${FONT}px Anton`).then(() => this.paint()).catch(() => {}); } catch (e) { /* no FontFaceSet */ }
  }
  paint() {
    const c = this.cv, g = c.getContext('2d'), w = c.width, h = c.height, f = `${FONT}px Anton, 'Arial Narrow', sans-serif`;
    const layer = (fn) => { g.clearRect(0, 0, w, h); g.save(); g.font = f; g.textAlign = 'center'; g.textBaseline = 'alphabetic'; g.fillStyle = '#fff'; fn(); g.restore(); return g.getImageData(0, 0, w, h).data; };
    g.font = f; const m0 = g.measureText('0'), asc = m0.actualBoundingBoxAscent || FONT * .72, base = CH / 2 + asc / 2; // digits centred in the cell
    const at = (i) => [(i % this.cols) * CW + CW / 2, Math.floor(i / this.cols) * CH + base];
    for (let i = 0; i < GLYPHS.length; i++) this.adv[GLYPHS[i]] = g.measureText(GLYPHS[i]).width / FONT;
    const fill = layer(() => { for (let i = 0; i < GLYPHS.length; i++) { const [x, y] = at(i); g.fillText(GLYPHS[i], x, y); } });
    const shad = layer(() => { for (let i = 0; i < GLYPHS.length; i++) { const [x, y] = at(i); g.fillText(GLYPHS[i], x, y + FONT * .1); } });
    // glow: canvas shadow of text drawn far off-cell (only the blurred shadow lands in the cell); Safari has no ctx.filter
    const glow = layer(() => { g.shadowColor = '#fff'; g.shadowBlur = FONT * PAD_GLOW * 2; g.shadowOffsetX = 4096; // clipped per cell: no glow bleeding into the neighbour (showed as box edges)
      for (let i = 0; i < GLYPHS.length; i++) { const [x, y] = at(i); g.save(); g.beginPath(); g.rect(x - CW / 2 + 2, Math.floor(i / this.cols) * CH + 2, CW - 4, CH - 4); g.clip(); g.fillText(GLYPHS[i], x - 4096, y); g.restore(); } });
    const out = g.createImageData(w, h), o = out.data;
    for (let i = 0; i < o.length; i += 4) { o[i] = fill[i + 3]; o[i + 1] = shad[i + 3]; o[i + 2] = Math.min(255, glow[i + 3] * 1.6); o[i + 3] = 255; }
    g.putImageData(out, 0, 0); this.tex.needsUpdate = true; this.ready = true;
  }
  begin() { this.n = 0; }
  // str centred at (x, y) CSS px, size = font px (like CSS font-size), style name (STYLES), alpha 0..1, scale (pop)
  text(str, x, y, size, style = 'slash', alpha = 1, scale = 1) {
    if (alpha <= .003 || !str) return; str = String(str); const s = size * scale, st = SIDX[style] ?? 0, sp = .02; // letter-spacing .02em
    let tw = 0; for (const ch of str) tw += (this.adv[ch] ?? .3) + sp; tw -= sp; let cx = x - tw * s / 2;
    for (const ch of str) { const a = (this.adv[ch] ?? .3); const gi = GLYPHS.indexOf(ch);
      if (gi >= 0 && this.n < MAX) { const i = this.n++, j = i * 4, col = gi % this.cols, row = Math.floor(gi / this.cols);
        this.A[j] = cx + a * s / 2; this.A[j + 1] = y; this.A[j + 2] = s; this.A[j + 3] = alpha; this.B[j] = st;
        const u0 = col * CW / this.cv.width, u1 = (col + 1) * CW / this.cv.width, v0 = 1 - (row + 1) * CH / this.cv.height, v1 = 1 - row * CH / this.cv.height;
        this.U[j] = u0; this.U[j + 1] = v0; this.U[j + 2] = u1; this.U[j + 3] = v1; }
      cx += (a + sp) * s; }
  }
  width(str, size) { let tw = 0; for (const ch of String(str)) tw += (this.adv[ch] ?? .3) + .02; return Math.max(0, tw - .02) * size; }
  draw(renderer, W, H) {
    this.geo.instanceCount = this.n; if (!this.n) return;
    const at = this.geo.attributes; for (const k of ['iA', 'iB', 'iUv']) { at[k].clearUpdateRanges?.(); at[k].addUpdateRange?.(0, this.n * 4); at[k].needsUpdate = true; }
    this.mat.uniforms.scr.value.set(W, H);
    const ac = renderer.autoClear; renderer.autoClear = false; renderer.setRenderTarget(null); renderer.render(this.scene, this.cam); renderer.autoClear = ac;
  }
}
