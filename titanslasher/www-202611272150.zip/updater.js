// Live game updates in the store app (Capgo updater plugin, self-hosted on GitHub; nothing goes to Capgo's servers).
// Same flow as rougulike-app/web-src/updater.js (Runebound) and stormace-app:
// At launch: confirm this bundle works (else the plugin rolls back to the last good one), read <game>/latest.json from the
// public updates repo, and when it is newer than this bundle download it behind a small "UPDATING…" overlay and switch to
// it right away. A slow or failed download never blocks the game: after 45 s the overlay goes and the bundle is applied
// on the next background/restart instead.
// The last step and any error are kept in localStorage 'tt_upd' and shown as "build <stamp> · <status>".
// Titan Slasher has no pause menu, so the line goes at the bottom of the title screen (#start) and of the UPGRADES panel (#upg).
// Publish with: python tools/publish_update.py titantap-app
(() => {
  const C = window.Capacitor, U = C && C.Plugins && C.Plugins.CapacitorUpdater;
  if (!U || !(C.isNativePlatform && C.isNativePlatform())) return;
  U.notifyAppReady().catch(() => {});
  const REPO = 'https://raw.githubusercontent.com/jortiga/studio3-updates/main/'; // one public repo, a folder per game: <app>/latest.json
  const KEY = 'tt_upd';
  const note = (s) => { try { localStorage.setItem(KEY, s + ' @' + new Date().toISOString().slice(5, 16).replace('T', ' ')); } catch (e) { /* no storage */ } };
  const nums = (v) => String(v || '0').split('.').map((n) => parseInt(n, 10) || 0);
  const atLeast = (a, b) => { a = nums(a); b = nums(b); for (let i = 0; i < 3; i++) if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) > (b[i] || 0); return true; };

  // 11-28 user "no dev things when live": nothing on screen; the last update step stays in localStorage 'tt_upd', and SETTINGS
  // shows the build number (hud-menu.js)

  let veil = null;
  const showVeil = (txt) => {
    if (!veil) {
      veil = document.createElement('div');
      veil.style.cssText = 'position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:#0a0420cc;color:#e9dcff;font:600 16px system-ui,sans-serif;letter-spacing:0.08em';
      (document.body || document.documentElement).appendChild(veil);
    }
    veil.textContent = txt;
  };
  const hideVeil = () => { if (veil) veil.remove(); veil = null; };

  (async () => {
    try {
      note('checking');
      const B = await (await fetch('bundle.json', { cache: 'no-store' })).json(), mine = B.stamp; // written by the app's build_www.py
      if (!B.app) return note('no app name');
      const r = await fetch(REPO + B.app + '/latest.json?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) return note('feed ' + r.status);
      const L = await r.json();
      if (!L.url || !L.sha256 || !(+L.stamp > +mine)) return note('up to date (' + L.stamp + ')');
      const nat = (await U.getBuiltinVersion()).version;
      if (L.minNative && !atLeast(nat, L.minNative)) return note('needs app ' + L.minNative + ' (have ' + nat + ')');
      const have = ((await U.list()).bundles || []).find((b) => b.version === String(L.stamp) && b.status !== 'error');
      let b = have, late = false;
      const timer = setTimeout(() => { late = true; hideVeil(); }, 45000); // a slow download keeps going in the background
      if (!b) {
        showVeil('UPDATING…');
        const prog = U.addListener ? await U.addListener('download', (e) => { if (!late && e && e.percent != null) showVeil('UPDATING… ' + Math.round(e.percent) + '%'); }) : null;
        note('downloading ' + L.stamp);
        try { b = await U.download({ url: L.url, version: String(L.stamp), checksum: L.sha256 || '' }); /* the plugin requires the zip's SHA-256 */ } finally { if (prog && prog.remove) prog.remove(); }
      }
      clearTimeout(timer);
      if (!late) { note('installing ' + L.stamp); showVeil('UPDATING…'); await U.set({ id: b.id }); return; } // reloads into the new bundle
      await U.next({ id: b.id }); note('ready ' + L.stamp + ' (next start)');
    } catch (e) { hideVeil(); note('error: ' + String((e && e.message) || e).replace(/https?:\/\/\S+/g, '').slice(0, 160)); }
  })();
})();
