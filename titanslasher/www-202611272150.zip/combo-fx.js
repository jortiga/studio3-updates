// Combo display (11-26, replaces the combo bar; the user dropped the D..SSS style-grade letters):
//  1 SWORD CHARGE (?combo1=0 off): the combo charges the equipped blade: glow grows, then a flame / lightning spark trail
//    (equipment.js setCharge), and the slash arcs shift by tier white -> violet -> gold -> rainbow, blended with the blade's tint.
//  3 EDGE AURA (?combo3=0 off): a soft CSS vignette glow at the screen edges, pulsing faster and brighter with the combo,
//    cyan -> gold -> white-hot. One fixed div, mix-blend screen, no render pass.
// Plus the small "x85" under the score (main.js hud()).
import * as THREE from 'three';
import * as EQ from './equipment.js';

const Q = new URLSearchParams(location.search);
export const ON = { charge: Q.get('combo1') !== '0', aura: Q.get('combo3') !== '0' };
const TIER = [[0, null], [25, new THREE.Color(.75, .5, 1)], [50, new THREE.Color(1, .78, .3)], [100, 'rainbow']]; // combo count -> blade / arc tier
let aEl = null; const aS = { a: '', t: '', sp: '' }; // last aura values written
const _c = new THREE.Color(), WHITE = new THREE.Color(.85, .9, 1);

export function init() {
  if (ON.aura) { aEl = document.createElement('div'); aEl.id = 'aura'; document.getElementById('gl').after(aEl); }
}
const tierOf = (c) => { let t = 0; TIER.forEach(([n], i) => { if (c >= n) t = i; }); return t; };

// per frame. chain = G.chain, live = in the fight
export function update(dt, chain, live) {
  const c = live ? chain : 0;
  if (ON.charge) { const k = Math.min(1, c / 150), col = TIER[tierOf(c)][1];
    if (col === 'rainbow') { _c.setHSL((performance.now() / 1400) % 1, 1, .62); EQ.setCharge(.25 + k * .75, _c, true); }
    else { _c.copy(col || WHITE); EQ.setCharge(k * (col ? 1 : .6), _c, false); } }
  if (aEl) { const k = Math.min(1, c / 160); // 11-26 perf: style writes only when the (quantised) value changes, not every frame
    const a = (c >= 10 ? .18 + k * .62 : 0).toFixed(2), t = String(c >= 120 ? 2 : c >= 50 ? 1 : 0), sp = (0.9 - k * .55).toFixed(1) + 's';
    if (a !== aS.a) { aS.a = a; aEl.style.setProperty('--a', a); aEl.dataset.on = a === '0.00' ? '0' : '1'; } if (t !== aS.t) { aS.t = t; aEl.dataset.t = t; } if (sp !== aS.sp) { aS.sp = sp; aEl.style.setProperty('--sp', sp); } }
}
// slash arcs: shift toward the tier colour, keeping half of the blade's own tint (call after EQ.arcTint)
export function arcTier(col, chain) {
  if (!ON.charge) return; const c = TIER[tierOf(chain)][1]; if (!c) return;
  if (c === 'rainbow') { _c.setHSL(Math.random(), 1, .66); col.lerp(_c, .65); } else col.lerp(c, .5);
}
