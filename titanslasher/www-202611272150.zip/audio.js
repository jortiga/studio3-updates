// Titan Slasher audio: ElevenLabs samples (audio/manifest.json, made by tools/eleven_audio.py --game titantap, the same
// pipeline as Runebound) with the original procedural WebAudio recipes kept as the fallback until a file is in (or if a
// name has none). API (unchanged): init(), hold(on), sfx(name, a, b), setMode('off'|'lobby'|'fight'|'enrage'),
// isMuted(), setMuted(m). Extra: setMode('results'); sfx('win') = victory sting + medal stamp, then the results loop.
// setMode('lobby') straight from a fight = the exit cinematic: the battle track fades out; the lobby loop comes back
// only after the results (enterLobby).
// Mix: per-sound voice cap + min gap, random pitch/volume, rapid-fire attenuation (10+ taps/s must not fatigue), music
// ducks under big moments, glue compressor -> brick-wall limiter. Music: one decoded loop per state, crossfaded. The
// enrage pick can be 'fight_a+' = the fight loop pushed ~6% faster / +1 semitone instead of a separate track.
// Music picks: manifest.pick, overridden by localStorage tt_music_pick (set on /titantap/audio_review.html) or by
// ?mlobby= / ?mfight= / ?menrage= / ?mresults= on the game URL.
// 11-26 v2 (user: tap sounds "too metal, clink clank"; music "too adventurous, make it godly / JRPG boss"): two sets,
// manifest.set (default 'v2') < localStorage tt_audio_set < ?aset=v1|v2. A MIX entry's v2 {} overrides it in set v2 (new
// sample groups: swoosh+swooshl slash, thump impact layered a few ms later and quieter, fwoosh blink, weakv2, critv2,
// victoryv2). Music: manifest.pick (v2) / pick_v1, user picks in localStorage tt_music_pick_<set>. Only the active set's
// groups load. Hero VOICE (tools/make_voice.py, vo_* groups): voice(key) on its own bus + on/off (tt_voice), see VO.
// 11-26 INK set (user: "still sounds cheap"; art ?style=ink): set 'ink' = ink_* groups (tools/raw/audio/PROMPTS_ink.md)
// layered over v2 (LAYERS: a MIX entry's ink {} wins, else its v2 {}, else the base). Picked by ?style=ink unless ?aset=
// says otherwise (dev panel Audio > aset INK). Ink music (manifest.pick_ink): ink_train_* (lobby / results), ink_fight_*
// (intro build plays once, then the body loops: manifest music[n].intro), plus a quiet cave ambience bed (pick_ink.amb).
// PREMIUM MIX (all sets): music no longer goes through the SFX glue compressor (it pumped the music on every tap); SFX
// glue -> sfx toggle, music -> duck -> music toggle, both -> master -> brick-wall limiter. One shared convolution reverb
// (generated cave impulse, 3 fixed send levels = no per-voice send nodes; MIX rev 0-3), a global cap on live SFX voices
// (rapid-fire sounds are dropped first), shuffle-bag round robin, and the hero voice made rare (ink: limit callouts only).
let ac = null, master, sfxBus, musBus, duckG, noiseBuf, muted = false, revSend = [], revOut = null, ambG = null;
try { muted = localStorage.getItem('tt_mute') === '1'; } catch (e) {}
let panelG = null, panelDim = false;
let menuG = null; const OUTRO_VOL = 1.4; /* 11-28 "when the titan leaves it's so quiet": music 30 -> 42 % in the retreat + results */ const MENU_VOL = 1; // 11-28 user "bgm maybe 30 main menu and titan scene": the playlist tracks are vol 0.3 (manifest), same in lobby and fight
let sfxOnG = null, musOnG = null, voOnG = null, voBus = null, musicOn = true, sfxOn = true, voiceOn = true;
try { voiceOn = localStorage.getItem('tt_voice') !== '0'; } catch (e) {}
if (new URLSearchParams(location.search).get('voice') === '0') voiceOn = false; // dev panel
try { musicOn = localStorage.getItem('tt_music') !== '0'; sfxOn = localStorage.getItem('tt_sfx') !== '0'; } catch (e) {}
let mode = 'off', procMode = 'off', step = 0, nextT = 0, timer = 0;
const BPM = 128, SPS = 60 / BPM / 4;
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
const DIR = new URL('./audio/', import.meta.url).href.replace(/\/v\d+\/audio\/$/, '/audio/'); // 11-27 dev server versions module URLs (serve.py): audio keeps its cached URL
const MAN = { man: null, buf: {}, tracks: {}, started: false };
const rnd = (a) => a[Math.floor(Math.random() * a.length)];
const decodeIn = (ab) => new Promise((res, rej) => { const p = ac.decodeAudioData(ab, res, rej); if (p && p.then) p.then(res, rej); });
// MP3 encoders put ~25 ms of silence in front: skip it so hits land on the frame and loops stay tight (Runebound leadOf)
function leadOf(b, th) {
  const d = b.getChannelData(0), n = Math.min(d.length, b.sampleRate * 0.25 | 0);
  let pk = 0; for (let i = 0; i < n; i++) pk = Math.max(pk, Math.abs(d[i]));
  const lim = th != null ? th : pk * 0.02;
  for (let i = 0; i < n; i++) if (Math.abs(d[i]) > lim) return i / b.sampleRate;
  return 0;
}
async function fetchBuf(file) {
  const r = await fetch(DIR + file + (MAN.man && MAN.man.v ? '?v=' + MAN.man.v : ''));
  if (!r.ok && r.status !== 0) throw new Error(file + ' ' + r.status); // status 0: the iOS app (Capacitor serves .mp3 with a non-HTTP response)
  return decodeIn(await r.arrayBuffer());
}

export function init() {
  if (ac) { if (ac.state !== 'running' && ac.state !== 'closed' && !window.__audioHeld) ac.resume().catch(() => {}); return; } // iOS also has 'interrupted' (calls, other apps, Siri): any tap brings it back
  const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
  ac = new AC({ latencyHint: 'interactive' });
  // sfx -> glue compressor (slow-ish attack keeps the transients) -> sfx toggle -> master -> brick-wall limiter: dense taps
  // never clip. Music skips the glue (it used to share it and pumped under every tap); the limiter only catches peaks.
  master = ac.createGain(); master.gain.value = muted ? 0 : 0.9;
  const comp = ac.createDynamicsCompressor(); comp.threshold.value = -20; comp.ratio.value = 3; comp.knee.value = 8; comp.attack.value = 0.006; comp.release.value = 0.16;
  const lim = ac.createDynamicsCompressor(); lim.threshold.value = -2.5; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.001; lim.release.value = 0.09;
  master.connect(lim); lim.connect(ac.destination);
  sfxOnG = ac.createGain(); sfxOnG.gain.value = sfxOn ? 1 : 0; sfxOnG.connect(master); musOnG = ac.createGain(); musOnG.gain.value = musicOn ? 1 : 0; musOnG.connect(master); // settings toggles (11-26)
  sfxBus = ac.createGain(); sfxBus.gain.value = 0.85; sfxBus.connect(comp); comp.connect(sfxOnG);
  // shared cave reverb: 3 fixed send gains -> one convolver -> band-limited return (no mud, no fizz) -> sfx toggle
  const conv = ac.createConvolver(); conv.normalize = true; conv.buffer = caveIR(2.4);
  const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 220; const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 5200;
  revOut = ac.createGain(); revOut.gain.value = 0.5; conv.connect(hp); hp.connect(lp); lp.connect(revOut); revOut.connect(sfxOnG);
  revSend = [null, 0.12, 0.24, 0.42].map((v) => { if (!v) return null; const g = ac.createGain(); g.gain.value = v; g.connect(conv); return g; });
  ambG = ac.createGain(); ambG.gain.value = 0; ambG.connect(sfxOnG); // ink cave ambience bed (follows the SOUND FX toggle)
  voOnG = ac.createGain(); voOnG.gain.value = voiceOn ? 1 : 0; voOnG.connect(master); voBus = ac.createGain(); voBus.gain.value = voVol; voBus.connect(voOnG); // hero voice bus
  panelG = ac.createGain(); panelG.gain.value = 1; menuG = ac.createGain(); menuG.gain.value = 1; menuG.connect(musOnG); panelG.connect(menuG); // 11-27 user: music lower while a panel / popup covers the main screen
  duckG = ac.createGain(); duckG.gain.value = 1; duckG.connect(panelG);
  musBus = ac.createGain(); musBus.gain.value = 0.42; musBus.connect(duckG); // procedural loop bus (sample tracks have their own gains -> duckG)
  const dl = ac.createDelay(1); dl.delayTime.value = SPS * 3; const fb = ac.createGain(); fb.gain.value = 0.32; const dlg = ac.createGain(); dlg.gain.value = 0.35;
  dl.connect(fb); fb.connect(dl); dl.connect(dlg); dlg.connect(musBus); musBus.__delay = dl;
  noiseBuf = ac.createBuffer(1, ac.sampleRate * 1.5, ac.sampleRate);
  const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  nextT = ac.currentTime + 0.1;
  timer = setInterval(sched, 50);
  loadAudio();
  window.__aud = () => ({ ctx: ac.state, mode, menu: +menuG.gain.value.toFixed(2), track: curTrack, duck: +duckG.gain.value.toFixed(2), musicOn, sfxOn, muted }); // debug: why is the music silent
}
// a cave impulse: pre-delay, a few early reflections off rock, then a dense decorrelated stereo tail whose highs die
// faster than its lows (one-pole low-pass that closes over time). Generated once (no file).
function caveIR(sec) {
  const sr = ac.sampleRate, n = sr * sec | 0, b = ac.createBuffer(2, n, sr), pre = 0.018 * sr | 0;
  const ER = [[0.011, 0.5], [0.019, -0.38], [0.027, 0.3], [0.041, -0.24], [0.055, 0.2], [0.072, -0.15]];
  for (let c = 0; c < 2; c++) {
    const d = b.getChannelData(c); let lp = 0;
    for (const [t, a] of ER) { const i = pre + ((t * (c ? 1.13 : 1)) * sr | 0); if (i < n) d[i] += a; }
    for (let i = pre; i < n; i++) { const u = (i - pre) / (n - pre), env = Math.exp(-6.2 * u) * Math.min(1, (i - pre) / (0.012 * sr));
      const k = 0.55 - 0.47 * u; lp += k * ((Math.random() * 2 - 1) - lp); d[i] += lp * env * 0.9; }
  }
  return b;
}
// app hidden (switch / Home / lock): suspend the context so nothing plays in the background; on show resume it now and again
// after 300 ms (iOS can refuse the first one). index.html #audiofix also restarts the output on the first tap after coming back.
export function hold(on) { window.__audioHeld = on; if (!ac) return;
  if (on) ac.suspend().catch(() => {});
  else { const r = () => { if (!window.__audioHeld && ac.state !== 'running' && ac.state !== 'closed') ac.resume().catch(() => {}); }; r(); setTimeout(r, 300); nextT = Math.max(nextT, ac.currentTime + 0.1); } }
export const isMuted = () => muted;
export function setMuted(m) { muted = m; try { localStorage.setItem('tt_mute', m ? '1' : '0'); } catch (e) {} if (master) master.gain.setTargetAtTime(m ? 0 : 0.9, ac.currentTime, 0.02); }
// settings panel (11-26): music and SFX on/off separately (the master mute above stays for the M key)
export const isMusicOn = () => musicOn, isSfxOn = () => sfxOn;
export function setMusicOn(b) { musicOn = !!b; try { localStorage.setItem('tt_music', b ? '1' : '0'); } catch (e) {} if (musOnG) musOnG.gain.setTargetAtTime(b ? 1 : 0, ac.currentTime, 0.05); }
// hero voice (11-26 v2): own bus, on/off in SETTINGS + the dev panel; volume 0-1.5 (tt_voice_vol)
let voVol = 0.9; try { const v = parseFloat(localStorage.getItem('tt_voice_vol')); if (v >= 0) voVol = v; } catch (e) {}
export const isVoiceOn = () => voiceOn, voiceVol = () => voVol;
export function setVoiceOn(b) { voiceOn = !!b; try { localStorage.setItem('tt_voice', b ? '1' : '0'); } catch (e) {} if (voOnG) voOnG.gain.setTargetAtTime(b ? 1 : 0, ac.currentTime, 0.02); }
export function setVoiceVol(v) { voVol = Math.max(0, Math.min(1.5, +v || 0)); try { localStorage.setItem('tt_voice_vol', String(voVol)); } catch (e) {} if (voBus) voBus.gain.setTargetAtTime(voVol, ac.currentTime, 0.02); }
export function setSfxOn(b) { sfxOn = !!b; try { localStorage.setItem('tt_sfx', b ? '1' : '0'); } catch (e) {} if (sfxOnG) sfxOnG.gain.setTargetAtTime(b ? 1 : 0, ac.currentTime, 0.02); }

// ---------------- loading: manifest, then the tap SFX + the current track first, the rest after ----------------
const FIRST = ['ink_fwip', 'ink_slashl', 'ink_hit', 'ink_slash', 'swoosh', 'swooshl', 'thump', 'fwoosh', 'slash', 'hit', 'blink', 'dummy', 'weak', 'weakv2', 'crit', 'critv2', 'click', 'tick', 'coin', 'sting0', 'sting1'];
let SET = 'v2';
const SETS = ['v1', 'v2', 'ink'];
// override layers per set, first match wins (a layer counts once every group it names is in the manifest / decoded)
const LAYERS = { v1: [], v2: ['v2'], ink: ['ink', 'v2'] };
const layersOf = () => LAYERS[SET] || [];
// the sample groups a MIX entry uses in the active set (has = which groups count as present)
function groupsFor(m, has) { for (const l of layersOf()) if (m[l] && [].concat(m[l].s).every(has)) return [].concat(m[l].s); return [].concat(m.s); }
// groups the active set never plays (another set's groups); groups no MIX entry names (and the music-only ones) load as-is
function skipGroups() {
  const sf = (MAN.man && MAN.man.sfx) || {}, has = (g) => !!sf[g], all = new Set(), use = new Set();
  for (const m of Object.values(MIX)) { [].concat(m.s).forEach((g) => all.add(g)); for (const l of SETS) if (m[l]) [].concat(m[l].s).forEach((g) => all.add(g)); groupsFor(m, has).forEach((g) => use.add(g)); }
  const sk = new Set([...all].filter((g) => !use.has(g)));
  if (SET !== 'ink') for (const g of Object.keys(sf)) if (g.startsWith('ink_')) sk.add(g);
  for (const g of ['gdc', 'ultra', 'critx']) sk.add(g); // 11-26 iOS memory: the audition banks are NOT decoded at startup - only picked takes load (fileBuf)
  return sk;
}
// per-set mix settings: reverb return level (ink = the cave), music level trim
function applySetFx() { if (revOut) revOut.gain.setTargetAtTime(SET === 'ink' ? 0.62 : 0.32, ac.currentTime, 0.1); }
const loading = new Set();
function loadGroups(gs) {
  const jobs = [];
  for (const [kind, g] of gs) { const e = MAN.man[kind] && MAN.man[kind][g]; if (!e || loading.has(kind + g)) continue; loading.add(kind + g); for (const f of e.files || []) jobs.push([kind === 'voice' ? 'vo:' + g : g, f]); }
  const worker = async () => { for (let j; (j = jobs.shift());) {
    try { const buf = await fetchBuf(j[1]); (MAN.buf[j[0]] = MAN.buf[j[0]] || []).push({ buf, lead: leadOf(buf), f: j[1] }); } catch (e) { console.warn('sfx', j[1], e.message || e); } } };
  return Promise.all([worker(), worker(), worker()]);
}
async function loadAudio() {
  if (MAN.started) return; MAN.started = true;
  try { MAN.man = await (await fetch(DIR + 'manifest.json', { cache: 'no-cache' })).json(); } catch (e) { console.warn('audio manifest', e); return; }
  SET = MAN.man.set || (MAN.man.pick_v1 ? 'v2' : 'v1');
  try { const s = localStorage.getItem('tt_audio_set'); if (SETS.includes(s)) SET = s; } catch (e) {}
  { const q = new URLSearchParams(location.search), s = q.get('aset');
    if (SETS.includes(s)) SET = s; else if (q.get('style') === 'ink' && MAN.man.pick_ink) SET = 'ink'; } // the ink art brings the ink sound
  applyPicks(); applySetFx();
  // 11-28 user "only these sounds and 4 BGM in the build": the only files ever fetched are HARD_SFX and the playlist tracks (no sound
  // groups, voice or ambience; the release build deletes every other audio file: build_www.py release_audio).
  const hits = Object.values(HARD_SFX).flat().map((f) => fileBuf(f).p);
  const cur = trackFor(mode === 'off' ? 'lobby' : mode);
  await Promise.all([...hits, cur && loadTrack(cur)]);
  // 11-26 load speed: only the picked tracks, one state ahead: lobby + fight now, enrage / results when the fight starts (setMode)
  for (const m of ['lobby', 'fight', ...(mode === 'fight' || mode === 'enrage' ? ['enrage', 'results'] : [])]) { const t = trackFor(m); if (t) await loadTrack(t); }
  mixReady(); // the next mix track, ready for the first fight
  window.__audioLoaded = { sfx: hits.length, music: Object.keys(MAN.tracks).length };
}
let PICK = {};
function applyPicks() {
  PICK = { ...((SET === 'v1' && MAN.man.pick_v1) || (SET === 'ink' && MAN.man.pick_ink) || MAN.man.pick || {}) };
  try { Object.assign(PICK, JSON.parse(localStorage.getItem('tt_music_pick_' + SET) || '{}')); } catch (e) {}
  Object.assign(PICK, MAN.man.pick_force || {}); // temp placeholder BGM for every set (11-26: ref1); remove pick_force from the manifest to undo
  const q = new URLSearchParams(location.search);
  for (const m of ['lobby', 'fight', 'enrage', 'results']) { const v = q.get('m' + m); if (v && /^[\w+]+$/.test(v)) PICK[m] = v; }
}
// 'fight_a+' = the fight loop played hot (enrage variant): returns the base track name
// 11-28 user "love the fighting, all of them": pick 'mix' = manifest.playlist, one full pass of each track in turn (menu + fight share it)
let plI = 0, mixSide = null; const playlist = () => (MAN.man && MAN.man.playlist) || [];
function mixReady() { // decode the NEXT track ahead (instant switch), drop the others (each is ~27 MB of PCM)
  const L = playlist(); if (!ac || !L.length || !MAN.man) return; const cur = L[plI % L.length], next = L[(plI + 1) % L.length]; loadTrack(next);
  setTimeout(() => { const c = L[plI % L.length], n = L[(plI + 1) % L.length]; for (const k of L) { const o = MAN.tracks[k]; if (o && k !== c && k !== n && k !== curTrack && !o.src) { if (o.g) o.g.disconnect(); delete MAN.tracks[k]; } } }, 5000);
}
const trackFor = (m) => { const p = PICK[m]; if (!p) return null; let n = p.replace(/\+$/, ''); if (n === 'mix') n = playlist()[plI % (playlist().length || 1)]; return MAN.man && MAN.man.music && MAN.man.music[n] ? n : null; };
setInterval(() => { // advance the mix; only the current + next track stay decoded (each is ~27 MB of PCM)
  const L = playlist(); if (!ac || !L.length || ac.state !== 'running' || !curTrack || curTrack !== L[plI % L.length]) return;
  const tr = MAN.tracks[curTrack]; if (!tr || !tr.src || tr.t0 == null || !tr.loop) return; const el = ac.currentTime - tr.t0, next = L[(plI + 1) % L.length];
  if (el > tr.loop - 10) loadTrack(next);
  if (el >= tr.loop - 0.4 && MAN.tracks[next] && MAN.tracks[next].buf) { plI = (plI + 1) % L.length; applyMusic(); mixReady(); }
}, 250);
function loadTrack(n) {
  if (MAN.tracks[n]) return MAN.tracks[n].ready;
  const m = MAN.man.music[n], tr = MAN.tracks[n] = { name: n, buf: null, src: null, g: null, quietAt: null, vol: m.vol != null ? m.vol : 0.6, loop: m.loop || 0, intro: m.intro || 0 };
  // intro tracks (ink fight): the file = a build that plays once + one loop body; the loop runs [lead + intro, end)
  tr.ready = fetchBuf(m.file).then((b) => { tr.buf = b; tr.lead = leadOf(b, 0.0005); tr.ls = tr.lead + tr.intro; tr.end = tr.loop ? Math.min(b.duration, tr.ls + tr.loop) : b.duration; applyMusic(); applyAmb(); })
    .catch((e) => console.warn('music', n, e.message || e));
  return tr.ready;
}

// ---------------- music state machine ----------------
let curTrack = null, hot = false;
const HOT_RATE = 1.06; // +1 semitone and ~6% faster: the classic arcade "hurry up"
export function setMode(m) {
  if (m === 'lobby' && (mode === 'fight' || mode === 'enrage')) m = 'outro'; // titan retreating: let the cinematic breathe
  // 11-28 user "bgm should change if I move from main menu to titan fight and vice versa": crossing lobby <-> fight = the next mix track
  const side = m === 'fight' || m === 'enrage' ? 'fight' : m === 'lobby' ? 'lobby' : null, L = playlist();
  if (side && mixSide && side !== mixSide && L.length) plI = (plI + 1) % L.length;
  if (side) mixSide = side;
  mode = m; applyMusic(); applyAmb(); mixReady();
  if (MAN.man && m !== 'off' && m !== 'lobby') for (const s of ['fight', 'enrage', 'results']) { const t = trackFor(s); if (t) loadTrack(t); } // lazy: the fight's next states
}
function applyMusic() {
  if (!ac) return;
  if (menuG) menuG.gain.setTargetAtTime(mode === 'outro' ? OUTRO_VOL : MENU_VOL, ac.currentTime, 0.4);
  if (mode === 'outro') return; // 11-28 user "when the titan was defeated the bgm died down": the fight track keeps playing through the retreat + results
  const now = ac.currentTime, playing = mode !== 'off' && mode !== 'outro';
  const name = playing ? trackFor(mode) : null, isHot = playing && /\+$/.test(PICK[mode] || '');
  const ready = name && MAN.tracks[name] && MAN.tracks[name].buf;
  // the procedural loop covers a state only while its file isn't decoded yet (or it has none)
  procMode = 'off'; // 11-26 user: "old BGM on game start - remove that": the procedural synth loop no longer fills in while a track decodes (silence until the real BGM is ready)
  const target = ready ? name : null;
  if (target === curTrack) { setHot(isHot && !!target); return; }
  const fadeOut = mode === 'outro' ? 2.2 : 0.4, fadeIn = mode === 'fight' || mode === 'enrage' ? 0.1 : 0.6;
  if (curTrack) { const tr = MAN.tracks[curTrack]; tr.quietAt = now; tr.g.gain.cancelScheduledValues(now); tr.g.gain.setValueAtTime(tr.g.gain.value, now); tr.g.gain.setTargetAtTime(0, now, fadeOut / 3); stopLater(tr, fadeOut * 2.5); }
  curTrack = target; hot = false;
  if (target) {
    const tr = MAN.tracks[target];
    if (!tr.g) { tr.g = ac.createGain(); tr.g.gain.value = 0; tr.g.connect(duckG); }
    // a track silent for 8+ s starts from its top (each fight opens with its hook); otherwise it resumes under the fade
    if (!tr.src || tr.quietAt == null || now - tr.quietAt > 8) playTrack(tr);
    tr.quietAt = null; clearTimeout(tr.stopT);
    tr.g.gain.cancelScheduledValues(now); tr.g.gain.setValueAtTime(tr.g.gain.value, now); tr.g.gain.setTargetAtTime(tr.vol, now, fadeIn / 3);
    setHot(isHot);
  }
}
// ink cave ambience: one quiet loop under everything while the game makes sound (any mode but 'off'), slow fades
let ambTrack = null;
function applyAmb() {
  if (!ac || !ambG) return; const n = mode !== 'off' && sfxAllowed('amb') ? trackFor('amb') : null, tr = n && MAN.tracks[n], now = ac.currentTime;
  if (tr && tr.buf) {
    if (ambTrack !== tr) { if (ambTrack && ambTrack.src) { try { ambTrack.src.stop(now + 2); } catch (e) {} } ambTrack = tr; tr.g = ambG; playTrack(tr); }
    ambG.gain.cancelScheduledValues(now); ambG.gain.setValueAtTime(ambG.gain.value, now); ambG.gain.setTargetAtTime(tr.vol != null ? tr.vol : 0.5, now, 1.2);
  } else if (ambTrack) { ambG.gain.cancelScheduledValues(now); ambG.gain.setTargetAtTime(0, now, 0.8); const t = ambTrack; ambTrack = null; setTimeout(() => { if (ambTrack !== t && t.src) { try { t.src.stop(); } catch (e) {} t.src.disconnect(); t.src = null; } }, 4000); }
}
function playTrack(tr) {
  if (tr.src) { try { tr.src.stop(); } catch (e) {} tr.src.disconnect(); }
  const s = ac.createBufferSource(); s.buffer = tr.buf; s.loop = true; s.loopStart = tr.ls != null ? tr.ls : tr.lead; s.loopEnd = tr.end;
  s.connect(tr.g); s.start(ac.currentTime + 0.02, tr.lead); tr.src = s; tr.t0 = ac.currentTime;
}
function stopLater(tr, sec) { clearTimeout(tr.stopT); tr.stopT = setTimeout(() => { if (curTrack !== tr.name && tr.src) { try { tr.src.stop(); } catch (e) {} tr.src.disconnect(); tr.src = null; } }, sec * 1000); }
function setHot(on) {
  if (on === hot || !curTrack) return; hot = on; const tr = MAN.tracks[curTrack]; if (!tr.src) return;
  tr.src.playbackRate.setTargetAtTime(on ? HOT_RATE : 1, ac.currentTime, 0.4);
  tr.g.gain.setTargetAtTime(tr.vol * (on ? 1.12 : 1), ac.currentTime, 0.4);
}
// duck the music under a big moment: depth 0-1, hold seconds
// 11-26 "music volume goes down and never recovers": overlapping ducks cancelled each other's release mid-curve (Safari keeps a
// cancelled setTargetAtTime's value with nothing scheduled after it). Now: anchor the current value before rescheduling, a deeper
// duck never gets shallower / shorter by a later lighter one, and a watchdog pulls the music back to 1 once every duck has ended.
let duckEnd = 0, duckLvl = 1;
function duck(depth, hold) {
  if (!ac || mode === 'outro') return; /* no music dips while the titan leaves */ const now = ac.currentTime, g = duckG.gain, lvl = Math.max(0.2, 1 - depth);
  if (now < duckEnd) { if (lvl >= duckLvl && now + hold <= duckEnd) return; } // a lighter / shorter duck inside a running one: nothing to do
  duckLvl = now < duckEnd ? Math.min(duckLvl, lvl) : lvl; duckEnd = Math.max(duckEnd, now + hold);
  const v = g.value; g.cancelScheduledValues(now); g.setValueAtTime(v, now);
  g.setTargetAtTime(duckLvl, now, 0.015); g.setTargetAtTime(1, duckEnd, 0.3);
}
// 11-27 user "reduce volume when the main menu is not focused, like a panel is visible": any open panel / popup / chest reveal
// -> music (and the cave ambience) down to 45%; back to full when the screen is clear again. DOM poll, 4x a second.
const PANEL_Q = '.panel:not(.hidden):not(#results), #pfPop:not(.hidden), .pu-pop:not(.hidden), #dpPanel:not(.dp-hidden)'; // 11-28: no dim on the fight results / chest reveal
setInterval(() => { if (!ac || !panelG || typeof document === 'undefined') return; const on = !document.querySelector('#results:not(.hidden)') && !!document.querySelector(PANEL_Q); /* 11-28 user "the BGM dies going to the result screen": nothing dims it there (level-up popup included) */
  if (on === panelDim) return; panelDim = on; const t = ac.currentTime; panelG.gain.cancelScheduledValues(t); panelG.gain.setTargetAtTime(on ? 0.45 : 1, t, 0.25);
  }, 250);
setInterval(() => { // watchdog: no duck running for 1.5 s but the music is still turned down -> restore it
  if (!ac || !duckG || ac.state !== 'running') return; const now = ac.currentTime, g = duckG.gain;
  if (now > duckEnd + 1.5 && g.value < 0.97) { g.cancelScheduledValues(now); g.setValueAtTime(g.value, now); g.setTargetAtTime(1, now, 0.2); duckLvl = 1; }
}, 1000);

// ---------------- SFX ----------------
// game name -> sample group + mix. vol = linear gain (manifest sfx[group].vol overrides), max = voices at once (oldest
// stolen), gap = min s between starts, pitch = random +- playback rate, dens = how hard fast repeats are turned down,
// duck = [depth, hold s] on the music, rev = cave reverb send 0-3, low = a rapid-fire sound (dropped first when too many
// SFX voices are alive). ink {} = the INK set's override (tools/raw/audio/PROMPTS_ink.md): soft cloth "fwip" needle slashes
// with a low-mid body, a muffled stone thud under them, no metal anywhere; fewer layers per tap (the blink is nearly gone).
const MIX = {
  // v2: the SWOOSH leads (2 lengths, never the same take twice in a row), the stone thump sits under it 15-40 ms later and
  // quieter (lag), blink = a soft fwoosh
  hop: { s: 'slash', vol: 0.42, max: 3, gap: 0.035, pitch: 0.16, dens: 1, rev: 1, low: 1, v2: { s: ['swoosh', 'swooshl'], vol: 0.55, max: 4, pitch: 0.13 },
    ink: { s: ['ink_fwip', 'ink_slashl'], vol: 0.5, max: 3, gap: 0.045, pitch: 0.08, dens: 1.2 } },
  tap: { s: 'hit', vol: 0.5, max: 3, gap: 0.035, pitch: 0.14, dens: 1, rev: 1, low: 1, v2: { s: 'thump', vol: 0.34, pitch: 0.12, lag: [0.015, 0.04], dens: 1.3 },
    ink: { s: 'ink_hit', vol: 0.15, max: 2, gap: 0.07, pitch: 0.07, lag: [0.012, 0.03], dens: 1.5 } },
  blink: { s: 'blink', vol: 0.22, max: 2, gap: 0.08, pitch: 0.12, dens: 1, low: 1, v2: { s: 'fwoosh', vol: 0.2, pitch: 0.1 },
    ink: { s: 'fwoosh', vol: 0.07, max: 1, gap: 0.2, pitch: 0.08 } },
  whiff: { s: 'slash', vol: 0.2, max: 2, gap: 0.06, pitch: 0.1, rate: 1.2, rev: 1, low: 1, v2: { s: ['swoosh'], vol: 0.25 },
    ink: { s: ['ink_slash'], vol: 0.22, rate: 1.1 } },
  dummy: { s: 'dummy', vol: 0.55, max: 3, gap: 0.035, pitch: 0.14, dens: 1, rev: 1, low: 1 },
  weak: { s: 'weak', vol: 0.5, max: 3, gap: 0.03, pitch: 0.02, dens: 0.6, rev: 1, low: 1, v2: { s: 'weakv2', vol: 0.45 },
    ink: { s: 'ink_weak', vol: 0.45, max: 2, gap: 0.05, rev: 2 } },
  crit: { s: 'crit', vol: 0.6, max: 2, gap: 0.06, pitch: 0.1, dens: 0.6, duck: [0.25, 0.15], rev: 2, v2: { s: 'critv2', vol: 0.6 },
    ink: { s: 'ink_crit', vol: 0.58, pitch: 0.06, duck: null } }, // (unused while crit = slash hit x3, see sfx()) // 11-26 "why is bgm turning off": crits are frequent, no duck
  ready: { s: 'ready', vol: 0.45, max: 1, gap: 0.2, pitch: 0.05, rev: 1 },
  rune: { s: 'rune', vol: 0.8, max: 1, gap: 0.2, pitch: 0.06, duck: [0.45, 0.5], rev: 2 },
  charge: { s: 'charge', vol: 0.6, max: 1, gap: 0.2, pitch: 0, rev: 1 },
  finish: { s: 'finish', vol: 0.9, max: 1, gap: 0.3, pitch: 0.04, duck: [0.6, 0.9], rev: 3,
    ink: { s: 'ink_limit', vol: 0.95, pitch: 0.03, duck: [0.35, 0.7] } }, // was [0.7, 1.8]: music nearly vanished every limit break
  roar: { s: 'roar', vol: 0.85, max: 1, gap: 0.6, pitch: 0.06, duck: [0.5, 1.4], rev: 2 },
  slam: { s: 'slam', vol: 0.8, max: 2, gap: 0.2, pitch: 0.08, duck: [0.4, 0.6], rev: 2 },
  throw: { s: 'throw', vol: 0.6, max: 1, gap: 0.2, pitch: 0.08, rev: 1 },
  shatter: { s: 'shatter', vol: 0.8, max: 1, gap: 0.2, pitch: 0.08, duck: [0.35, 0.4], rev: 2 },
  rumble: { s: 'rumble', vol: 0.65, max: 1, gap: 0.5, pitch: 0.05, rev: 1 },
  rise: { s: 'rumble', vol: 0.6, max: 1, gap: 0.5, pitch: 0.03, rate: 0.85, rev: 1 },
  retreat: { s: 'retreat', vol: 0.8, max: 1, gap: 0.5, pitch: 0.03, duck: [0.4, 2], rev: 2 },
  shieldUp: { s: 'shieldUp', vol: 0.75, max: 1, gap: 0.3, pitch: 0, duck: [0.35, 0.8], rev: 2 },
  shieldBreak: { s: 'shieldBreak', vol: 0.85, max: 1, gap: 0.3, pitch: 0.04, duck: [0.5, 0.8], rev: 2 },
  horn: { s: 'horn', vol: 0.8, max: 1, gap: 0.5, pitch: 0, duck: [0.55, 1.6], rev: 2 },
  ignite: { s: 'ignite', vol: 0.65, max: 1, gap: 0.3, pitch: 0.04, rev: 2 },
  card: { s: 'card', vol: 0.75, max: 1, gap: 0.3, pitch: 0, duck: [0.35, 0.8], rev: 2 },
  go: { s: 'go', vol: 0.7, max: 1, gap: 0.3, pitch: 0, rev: 1 },
  // 11-26 ultracrit = a skill's (limit break's) final big-damage hit (limits.js hit fin): a heavier, lower crit
  ultracrit: { s: 'critv2', vol: 0.8, max: 1, gap: 0.15, pitch: 0.02, rev: 3 }, // (unused while ultra crit = slash hit x5, see sfx())
  land: { s: 'land', vol: 0.4, max: 2, gap: 0.08, pitch: 0.1, rev: 1 },
  glide: { s: 'glide', vol: 0.35, max: 1, gap: 0.2, pitch: 0.06, rev: 1 },
  tick: { s: 'tick', vol: 0.45, max: 1, gap: 0.1, pitch: 0 },
  click: { s: 'click', vol: 0.5, max: 2, gap: 0.04, pitch: 0.06 },
  coin: { s: 'coin', vol: 0.4, max: 4, gap: 0.03, pitch: 0.03, dens: 0.4 },
  buy: { s: 'buy', vol: 0.6, max: 1, gap: 0.1, pitch: 0 },
  deny: { s: 'deny', vol: 0.5, max: 1, gap: 0.1, pitch: 0 },
  victory: { s: 'victory', vol: 0.8, max: 1, gap: 1, pitch: 0, duck: [0.9, 3.5], rev: 1, v2: { s: 'victoryv2', vol: 0.8 } },
  rank: { s: 'rank', vol: 0.75, max: 1, gap: 0.5, pitch: 0, rev: 1 },
};
for (let i = 0; i <= 4; i++) MIX['sting' + i] = { s: 'sting' + i, vol: 0.5 + i * 0.06, max: 1, gap: 0.1, pitch: 0, duck: i >= 2 ? [0.3, 0.8] : null, rev: i >= 2 ? 2 : 1 };
const bufsOf = (gs) => [].concat(gs).flatMap((g) => MAN.buf[g] || []);
// the entry for the active set: the first layer (ink, v2) whose groups all have decoded takes wins (else base / procedural)
const decoded = (g) => !!(MAN.buf[g] && MAN.buf[g].length);
function mixOf(name) { const m = MIX[name]; if (!m) return null; for (const l of layersOf()) if (m[l] && [].concat(m[l].s).every(decoded)) return { ...m, ...m[l] }; return m; }
const live = {}, lastT = {}, recent = {}, lastB = {}, bags = {};
let coinRun = 0, coinT = 0;
// 11-26 "still losing sound" (debug showed [18] stuck): the old liveN counter leaked - iOS never fires onended for a source stopped
// before it started (the crit replacing a lagged slash hit), so the count crept to the cap and every other sound was dropped.
// Now the count is real: every voice knows when it ends (start + length / rate) and is expired by time, onended or not.
function liveCount() { const now = ac ? ac.currentTime : 0; let n = 0;
  for (const k in live) { const v = live[k]; for (const o of v) if (!o.done && now > o.endAt) o.done = true; live[k] = v.filter((o) => !o.done); n += live[k].length; } return n; }
const CASINO = new URLSearchParams(location.search).get('casino') === '1';
const VOICE_CAP = 18, VOICE_SOFT = 12; // all SFX voices alive at once; past SOFT the rapid-fire (low) sounds are skipped
// shuffle-bag round robin: every take plays once per cycle, never the same take twice in a row across cycles
function nextTake(key, bs) {
  if (bs.length < 2) return bs[0];
  let b = bags[key]; if (!b || !b.q.length || b.n !== bs.length) {
    const q = bs.map((_, i) => i); for (let i = q.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [q[i], q[j]] = [q[j], q[i]]; }
    if (b && q[q.length - 1] === b.last) [q[0], q[q.length - 1]] = [q[q.length - 1], q[0]];
    b = bags[key] = { q, n: bs.length, last: b ? b.last : -1 };
  }
  const i = b.q.pop(); b.last = i; return bs[i];
}
function playSample(name, arg, at = 0, gmul = 1, tkey = name, absVol = 0, files = null) {
  const hard = HARD_VOL[tkey]; // 11-28 user "the sfx are wrong": the picked files play CLEAN, as they sound on hit_pick.html (no pitch change, echo or delay)
  let mx = mixOf(name); if (hard && mx) mx = { ...mx, lag: null, pitch: 0, rate: 1, rev: 0, duck: tkey === 'victory' ? null : mx.duck }; /* victory: the music never dips under it */ let bs = mx && bufsOf(mx.s);
  if (files) { const o = files.map((f) => fileBuf(f).b).filter(Boolean); if (o.length) bs = o; } // baked crit takes
  else { const tk = TAKES[tkey] || (tkey !== name && TAKES[name]); if (mx && tk && tk.length) { const o = tk.map((f) => fileBuf(f).b).filter(Boolean); if (o.length) bs = o; } } // picked varieties
  if (!bs || !bs.length) { SDBG('x ' + tkey + ' no file'); return false; }
  if (mx.lag) at += mx.lag[0] + Math.random() * (mx.lag[1] - mx.lag[0]); // layered impact lands just after the swoosh
  const ov = (MAN.man.sfx && MAN.man.sfx[[].concat(mx.s)[0]]) || {}, t = ac.currentTime + at;
  const every = (EVERY_HIT && SWORD_SOUNDS.includes(name)) || name === 'tap'; // the slash hit is never dropped (steals the oldest voice when full) // 11-26 "plays every hit": slash sounds are never swallowed (hard cap only)
  if (!every && !SWORD_SOUNDS.includes(name) && lastT[name] && t - lastT[name] < mx.gap && t - lastT[name] > -0.5) { SDBG('x ' + tkey + ' too soon'); return true; } // swallowed: too soon after the last one
  const boosted = gmul > 1 || absVol > 0; // crit / ultra: own voice pool, never swallowed by the voice caps (11-26: they got cut by the taps)
  const liveN = liveCount();
  if (!boosted && !every && (liveN >= VOICE_CAP || (mx.low && liveN >= VOICE_SOFT))) { SDBG('x ' + tkey + ' mix full'); return true; }
  if (every && liveN >= VOICE_CAP) { // 11-26: a slash hit is never dropped when the mix is full - it steals the oldest other voice instead
    let old = null; for (const k in live) if (k !== 'crit' && k !== 'ultracrit') for (const o of live[k]) if (!o.done && (!old || o.t < old.t)) old = o;
    if (old) { old.g.gain.setTargetAtTime(0, ac.currentTime, 0.01); try { old.s.stop(ac.currentTime + 0.04); } catch (e) {} old.done = true; } } // swallowed: the mix is full (no unbounded nodes)
  lastT[name] = t;
  // rapid-fire attenuation: every start in the last 0.4 s turns the next one down a little (floor 45%)
  const r = (recent[name] = (recent[name] || []).filter((x) => t - x < 0.4)); r.push(t);
  const dens = mx.dens && !every ? Math.max(0.45, 1 / (1 + 0.09 * mx.dens * (r.length - 1))) : 1; // slash sounds keep their set volume (user: hit .15 was playing at .06)
  let rate = (mx.rate || 1) * (1 + (Math.random() - 0.5) * 2 * (mx.pitch || 0)); // (crit pitch is baked into crit/<take>)
  // 11-26 user: "sounds like a casino game" - no climbing pitch ladders (weak / coin) unless ?casino=1
  if (CASINO && name === 'weak') rate *= Math.pow(2, Math.min(arg || 0, 14) / 12);
  if (CASINO && name === 'coin') { coinRun = t - coinT < 0.5 ? coinRun + 1 : 0; coinT = t; rate *= Math.pow(2, Math.min(coinRun, 12) / 12); }
  const b = nextTake(name + '|' + [].concat(mx.s).join(), bs);
  const s = ac.createBufferSource(), g = ac.createGain();
  s.buffer = b.buf; s.playbackRate.value = rate;
  g.gain.value = hard || (absVol || (ov.vol != null ? ov.vol : mx.vol) * (gmul > 1 ? 1 : dens) * gmul) * (1 + (Math.random() - 0.5) * 0.2);
  s.connect(g); g.connect(boosted || hard ? sfxOnG : sfxBus); /* crit skips the glue compressor; the master limiter still catches peaks */ if (mx.rev && revSend[mx.rev]) g.connect(revSend[mx.rev]); s.start(t, b.lead);
  const pool = boosted ? tkey : name, v = (live[pool] = (live[pool] || []).filter((x) => !x.done)), voice = { s, g, done: false, t, endAt: t + (b.buf.duration - b.lead) / rate + 0.05 }; v.push(voice);
  s.onended = () => { voice.done = true; s.disconnect(); g.disconnect(); };
  if (v.length > (boosted ? 5 : every ? Math.max(mx.max, 4) : mx.max)) { const o = v.shift(); o.g.gain.setTargetAtTime(0, t, 0.012); try { o.s.stop(t + 0.06); } catch (e) {} }
  if (mx.duck) duck(mx.duck[0], mx.duck[1]);
  if (window.__sfxLog) window.__sfxLog.push('>' + tkey + ' ' + g.gain.value.toFixed(2)); // debug: what actually played, at what gain
  SDBG('> ' + tkey + '  ' + (b.f || '?') + '  vol ' + g.gain.value.toFixed(2) + (boosted ? '  CRIT' : '') + '  [' + liveCount() + ']');
  return true;
}
// 11-26 SFX picker "varieties": per sound, exactly which takes (files from any set's groups, incl. unused takes) play.
// The files per sound are HARD_SFX below.
// 11-28 user "hard code it, only hit crit and ultra crit": ONLY these three sounds play, with exactly these files. Nothing else can
// change it (no saved device picks, ?sfx or manifest list). To bring a sound back, add its name + files here.
const HARD_SFX = { tap: ['hit.mp3', 'hit_2.mp3', 'hit_3.mp3'], crit: ['crit/gdc_slash_sword.mp3'], ultracrit: ['crit/gdc_hit_angry.mp3', 'crit/gdc_hit_smash.mp3'], victory: ['victory.mp3', 'victory_2.mp3'] };
const TAKES = HARD_SFX;
const HARD_VOL = { tap: 0.6, crit: 0.9, ultracrit: 1, victory: 0.8 }; // their fixed volumes (hit was 0.15)
const fileBufs = {};
function fileBuf(f) { if (!fileBufs[f] && ac) { const e = fileBufs[f] = { b: null }; e.p = fetchBuf(f).then((buf) => { e.b = { buf, lead: leadOf(buf), f }; }).catch(() => {}); } return fileBufs[f] || { b: null, p: Promise.resolve() }; }
// 11-26 "hit bank": every sword / slash / hit sound of every set is offered to each slash-type sound (own groups first)
const SWORD_BANK = ['gdc', 'ink_fwip', 'ink_slashl', 'ink_slash', 'ink_hit', 'ink_crit', 'ink_weak', 'swoosh', 'swooshl', 'slash', 'fwoosh', 'blink', 'hit', 'thump', 'crit', 'critv2', 'dummy', 'weak', 'weakv2'];
let EVERY_HIT = true; try { EVERY_HIT = localStorage.getItem('tt_sfx_every') !== '0'; } catch (e) {}
window.__sfxEvery = (v) => { if (v != null) { EVERY_HIT = !!v; try { localStorage.setItem('tt_sfx_every', v ? '1' : '0'); } catch (e) {} } return EVERY_HIT; };
const CRIT_BANK = ['ink_crit', 'crit', 'critv2', 'ink_limit', 'finish', 'shatter', 'shieldBreak', 'rune', 'ink_weak', 'weak', 'weakv2', 'slam'];
const CRIT_SOUNDS = ['crit', 'ultracrit'];
// 11-26 limit / boom sounds offered in the crit + ultra crit lists (after the slash-hit list); baked like the rest (crit/<file>)
const BOOM_BANK = ['gdc', 'ink_limit', 'finish', 'card', 'rune', 'slam', 'shatter', 'shieldBreak', 'ink_crit', 'crit', 'critv2'];
const SWORD_SOUNDS = ['ultracrit', 'hop', 'tap', 'crit', 'whiff', 'blink', 'dummy', 'weak'];
const setOf = (g) => g === 'gdc' ? 'GDC' : /^(critx|ultra)$/.test(g) ? 'new' : /^ink_/.test(g) ? 'ink' : /^(swoosh|swooshl|thump|fwoosh|critv2|weakv2)$/.test(g) ? 'v2' : 'v1';
window.__sfxVariants = (name) => {
  if (name === 'crit' || name === 'ultracrit') { // same list as slash hit; own picks (none = whatever slash hit uses)
    const tk = TAKES[name], ult = name === 'ultracrit', sf = (MAN.man && MAN.man.sfx) || {};
    const ua = (sf.ultra && sf.ultra.all) || [], def = new Set(ULTRA_DEF());
    const base = [...(ult ? ua.map((f) => ({ f, g: 'ultra', l: 'new · ' + (/pop/.test(f) ? 'slash+pop' : /thunder/.test(f) ? 'slash+thunder' : 'slash+boom'), def: def.has(f), on: def.has(f) })) : []), ...window.__sfxVariants('tap').map((o) => ult ? { ...o, on: false } : o)];
    const seen = new Set(base.map((o) => o.f));
    for (const g of BOOM_BANK) for (const f of (sf[g] && (sf[g].all || sf[g].files)) || []) if (!seen.has(f)) { seen.add(f); base.push({ f, g, l: 'boom · ' + g, def: false, on: false }); }
    return base.map((o) => ({ ...o, on: tk && tk.length ? tk.includes(o.f) : o.on })); }
  const m = MIX[name]; if (!m || !MAN.man) return [];
  const sf = MAN.man.sfx || {}, cur = [].concat(mixOf(name).s), seen = new Set(), out = [];
  const own = [...SETS.filter((x) => m[x]).reverse().map((x) => [x, m[x].s]), ['v1', m.s]];
  const bank = [...(CRIT_SOUNDS.includes(name) ? CRIT_BANK : []), ...(SWORD_SOUNDS.includes(name) ? SWORD_BANK : [])].map((g) => [setOf(g) + ' · ' + g, g]); // crit list first for crits
  for (const [l, gs] of [...own, ...bank]) for (const g of [].concat(gs)) {
    const e = sf[g]; if (!e) continue;
    for (const f of e.all || e.files || []) { if (seen.has(f)) continue; seen.add(f); out.push({ f, g, l, def: cur.includes(g) && (e.files || []).includes(f) }); } }
  const tk = TAKES[name]; for (const o of out) o.on = tk && tk.length ? tk.includes(o.f) : o.def;
  return out;
};
window.__setSfxTakes = () => {}; // dev panel picker: the sounds are hard-coded (HARD_SFX)
window.__sfxPreview = (f) => { if (!ac) return; if (ac.state !== 'running') ac.resume(); const e = fileBuf(f);
  e.p.then(() => { if (!e.b) return; const s = ac.createBufferSource(), g = ac.createGain(); s.buffer = e.b.buf; g.gain.value = 0.6;
    s.connect(g); g.connect(sfxBus); s.start(ac.currentTime, e.b.lead); s.onended = () => { s.disconnect(); g.disconnect(); }; }); };
// sample-only names -> the nearest procedural recipe
const FALLBACK = { dummy: 'tap', shatter: 'crit', rune: 'shieldBreak', rank: 'card', victory: 'win' };
// 11-26 user is re-adding sounds one by one: manifest.sfx_allow = [names] -> only those play (+ 'voice', 'amb');
// [] = BGM only. Remove sfx_allow from the manifest to bring every sound back.
// Dev panel "Sounds on (pick)" = ?sfx=a,b,c ('none' = nothing) overrides the manifest list, live via __setSfxAllow.
// 11-28: all of the above is replaced by HARD_SFX (the dev panel pickers no longer change anything).
// in-game sound debug (SFX popup DEBUG): devpanel.js shows window.__sfxDbg lines; > played, x dropped (why), - switched off
const SDBG = (m) => { const f = window.__sfxDbg; if (f) f(m); };
const sfxList = () => Object.keys(HARD_SFX);
const ULTRA_DEF = () => ((MAN.man && MAN.man.sfx.ultra && MAN.man.sfx.ultra.files) || []); // tools/make_ultra.py: slash + boom
const critFiles = (name) => TAKES[name] || [];
window.__critFiles = critFiles;
const sfxAllowed = (n) => !!MAN.man && Object.prototype.hasOwnProperty.call(HARD_SFX, n);
window.__sfxAllowList = () => sfxList() || [];
window.__sfxTest = (n) => { if (ac && ac.state !== 'running') ac.resume(); sfx(n); }; // SFX popup TEST buttons
window.__setSfxAllow = () => applyAmb(); // hard-coded (HARD_SFX)
export function sfx(name, a, b) {
  if (window.__sfxLog) window.__sfxLog.push(name); // debug: set window.__sfxLog = [] to record every sound request
  if (!ac || muted || !sfxAllowed(name)) return; // (switched-off sounds are not logged in the debug overlay)
  // 11-26 "stuck on tap too soon": iOS left the context suspended / interrupted -> its clock froze, every sound looked "too soon"
  // and nothing played. Any sound request now kicks it back to running (we are inside a tap, so iOS allows it).
  if (ac.state !== 'running' && ac.state !== 'closed') { SDBG('! audio ' + ac.state + ' -> resume'); try { ac.resume(); } catch (e) {} }
  try {
    if (name === 'crit' || name === 'ultracrit') { // 11-26 user: crit = its own louder hit (see below)
      const ult = name === 'ultracrit'; // 11-26: 1.8x / 3x were not loud enough -> 4x / 6x, and the music dips under them so they punch through
      // 11-26 "it's overlapping": the crit REPLACES this strike's normal slash hit (started in the last 80 ms, or still waiting on
      // its lag) instead of stacking on it, and plays once (no doubled take)
      if (ac) { const now = ac.currentTime; for (const o of live.tap || []) if (!o.done && o.t > now - 0.08) { try { o.g.gain.cancelScheduledValues(now); o.g.gain.setValueAtTime(0, now); o.s.stop(now + 0.01); } catch (e) {} } }
      // 11-26 baked crit files (user: "duplicate the actual file"): crit/<take> = the same take made phone-loud offline; the crit's
      // own picks, else whatever slash hit plays. Not decoded yet -> they load now and this one crit uses the plain take.
      const fl = critFiles(name), ready = fl.filter((f) => fileBuf(f).b);
      if (MAN.man && playSample('tap', a, 0, 2, name, ult ? 1.6 : 0.95, ready.length ? ready : null)) { if (ult) duck(0.35, 0.8); else duck(0.12, 0.12); return; } // 11-26: crits are frequent (skill strikes too) - a tiny dip only, or the music sat at 70 % all fight // ultra: louder, music nearly gone for ~1 s // 11-26 user: slash hit .3, crit 1.5 (ultra 2.2) // own picked takes (same list as slash hit), else slash hit's
    } else if (MAN.man) playSample(name, a); // no procedural (synth) stand-in: only the HARD_SFX files can ever sound
  } catch (e) {}
}

// ---- for audio_review.html (it imports this module and drives the real mixer) ----
export const _review = {
  get ac() { return ac; }, get manifest() { return MAN.man; }, get buffers() { return MAN.buf; }, get tracks() { return MAN.tracks; },
  get mode() { return mode; }, get out() { return master; }, mix: MIX, leadOf, fetchBuf, loadTrack,
  pick(m, v) { PICK[m] = v; const n = trackFor(m); if (n) loadTrack(n); applyMusic(); applyAmb(); },
  get set() { return SET; }, get vo() { return VO; }, mixOf, get live() { return liveCount(); }, get sfxIn() { return sfxBus; }, get revSend() { return revSend; },
  // A/B: switch the whole set (sfx groups + music picks), load what it needs, re-apply the current music state
  async setSet(s) { if (!SETS.includes(s)) return; SET = s; try { localStorage.setItem('tt_audio_set', s); } catch (e) {}
    applyPicks(); applySetFx(); const sk = skipGroups(); const ld = loadGroups(Object.keys(MAN.man.sfx || {}).filter((g) => !sk.has(g)).map((g) => ['sfx', g]));
    for (const m of ['lobby', 'fight', 'results', 'amb']) { const t = trackFor(m); if (t) loadTrack(t); } applyMusic(); applyAmb(); await ld; },
};

// ---------------- hero voice (11-26 v2, tools/make_voice.py) ----------------
// key -> group vo_<key> (lim_<id> = the limit-break callouts). chance = how often a call actually speaks, cd = min s between
// lines of that kind, pri = may cut a lower-priority line still playing (grunts never cut anything), duck = light music duck.
// 11-26 premium pass: a grunt every ~2.6 s of tapping was the voice bus talking constantly -> rare grunts (1 in 12 hops,
// 9 s apart). The INK set (small masked knight) speaks only its limit-break callouts, at most every 14 s (VO_INK).
const VO_INK = { lim: { cd: 14 } };
const VO = {
  atk: { chance: 1 / 12, cd: 9, vol: 0.6, pri: 0, pitch: 0.05 },
  lim: { chance: 1, cd: 0.5, vol: 1, pri: 3, duck: [0.22, 1.1] },
  start: { chance: 1, cd: 5, vol: 0.9, pri: 2 },
  rune: { chance: 1, cd: 4, vol: 0.9, pri: 2 },
  rank: { chance: 1, cd: 8, vol: 0.85, pri: 1 },
  best: { chance: 1, cd: 8, vol: 0.9, pri: 2 },
  exit: { chance: 1, cd: 5, vol: 0.9, pri: 2 },
};
let voCur = null; const voLast = {};
// force = skip chance + cooldown (review page)
export function voice(key, force) {
  if (!ac || muted || !voiceOn || !MAN.man || !sfxAllowed('voice')) return false;
  const base = key.startsWith('lim_') ? 'lim' : key;
  if (SET === 'ink' && !VO_INK[base] && !force) return false;
  const cfg = SET === 'ink' && VO_INK[base] ? { ...VO[base], ...VO_INK[base] } : VO[base]; if (!cfg) return false;
  const bs = MAN.buf['vo:vo_' + key]; if (!bs || !bs.length) return false;
  const now = ac.currentTime;
  if (!force && (Math.random() > cfg.chance || now - (voLast[base] || -99) < cfg.cd)) return false;
  if (voCur && !voCur.done && now < voCur.end) { if (cfg.pri <= voCur.pri && !force) return false; voCur.g.gain.setTargetAtTime(0, now, 0.015); try { voCur.s.stop(now + 0.06); } catch (e) {} }
  voLast[base] = now;
  let b = rnd(bs); if (bs.length > 2) for (let k = 0; k < 4 && b === lastB['vo' + key]; k++) b = rnd(bs); lastB['vo' + key] = b;
  const s = ac.createBufferSource(), g = ac.createGain(), ov = (MAN.man.voice && MAN.man.voice['vo_' + key]) || {};
  s.buffer = b.buf; s.playbackRate.value = 1 + (Math.random() - 0.5) * 2 * (cfg.pitch || 0);
  g.gain.value = ov.vol != null ? ov.vol : cfg.vol; s.connect(g); g.connect(voBus); s.start(now, b.lead);
  const v = voCur = { s, g, pri: cfg.pri, done: false, end: now + b.buf.duration - b.lead }; s.onended = () => { v.done = true; s.disconnect(); g.disconnect(); };
  if (cfg.duck) duck(cfg.duck[0], cfg.duck[1]);
  return true;
}

// ---------------- procedural fallback (the original recipes) ----------------
function osc(type, f0, f1, t, dur, vol, dest = sfxBus, detune = 0) {
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t); if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
  o.detune.value = detune;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.02);
}
function noise(t, dur, vol, f0, f1, q = 1, type = 'bandpass', dest = sfxBus) {
  const s = ac.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
  const fl = ac.createBiquadFilter(); fl.type = type; fl.Q.value = q; fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(fl); fl.connect(g); g.connect(dest); s.start(t, Math.random()); s.stop(t + dur + 0.02);
}

const SFX = {
  tap(t, p = 0) { osc('sine', 190 + p * 6, 55, t, 0.13, 0.7); noise(t, 0.05, 0.25, 3000, 800, 0.8); },
  weak(t, p = 0) { const k = Math.pow(2, Math.min(p, 36) / 18); // rising pitch while a weak point is hammered
    osc('square', 660 * k, 990 * k, t, 0.08, 0.22); osc('square', 990 * k, 1320 * k, t + 0.04, 0.1, 0.18); osc('sine', 160, 50, t, 0.18, 0.7); noise(t, 0.12, 0.4, 5000, 1200, 1.2); },
  crit(t) { osc('sawtooth', 1200, 2400, t, 0.15, 0.2); osc('sine', 120, 40, t, 0.22, 0.8); noise(t, 0.2, 0.4, 6000, 900, 0.9); },
  hop(t, i = 0) { const n = 60 + [0, 3, 7, 10, 12, 15, 19][i % 7] + Math.floor(i / 7) * 12;
    noise(t, 0.18, 0.55, 900, 5200, 1.8); osc('triangle', mtof(n + 12), mtof(n + 12) * 0.6, t, 0.12, 0.28);
    osc('sine', 150, 45, t + 0.04, 0.16, 0.6); noise(t + 0.04, 0.07, 0.3, 4000, 1500, 1); },
  whiff(t) { noise(t, 0.14, 0.16, 1800, 5200, 1.4); osc('sine', 420, 260, t, 0.08, 0.05); }, // miss: soft air swish
  glide(t) { noise(t, 0.45, 0.14, 600, 2600, 1.2); osc('sine', 880, 1320, t, 0.3, 0.05); }, // hero floats home
  land(t) { osc('sine', 120, 55, t, 0.16, 0.35); noise(t, 0.12, 0.12, 1600, 400, 0.8); osc('triangle', 1320, 1320, t + 0.03, 0.25, 0.05); },
  blink(t) { osc('sine', 2600, 500, t, 0.1, 0.18); noise(t, 0.08, 0.2, 7000, 2000, 2); },
  finish(t) { osc('sine', 110, 28, t, 0.9, 1); noise(t, 1.0, 0.8, 5000, 80, 0.7, 'lowpass');
    for (const [k, d] of [[57, 0], [64, 0.03], [69, 0.06], [76, 0.09]]) osc('sawtooth', mtof(k), mtof(k), t + d, 0.8, 0.12); osc('square', 1760, 440, t, 0.4, 0.15); },
  charge(t) { osc('sawtooth', 120, 900, t, 0.5, 0.18); noise(t, 0.5, 0.3, 300, 6000, 1.5); },
  ready(t) { osc('square', 660, 660, t, 0.08, 0.2); osc('square', 990, 990, t + 0.08, 0.14, 0.2); },
  shieldBreak(t) { noise(t, 0.6, 0.9, 7000, 200, 0.6, 'bandpass'); osc('sine', 200, 30, t, 0.6, 0.9); osc('square', 1500, 300, t, 0.3, 0.2); },
  shieldUp(t) { osc('sawtooth', 100, 600, t, 0.7, 0.25); osc('sine', 600, 1200, t + 0.5, 0.4, 0.2); },
  horn(t) { for (const d of [0, 7]) osc('sawtooth', mtof(45 + d) , mtof(45 + d) * 0.97, t, 1.3, 0.22, sfxBus, d ? 8 : -8); noise(t, 1.2, 0.3, 200, 60, 0.7, 'lowpass'); },
  roar(t) { osc('sawtooth', 90, 40, t, 1.6, 0.5, sfxBus, 15); osc('sawtooth', 93, 38, t, 1.6, 0.5, sfxBus, -15); noise(t, 1.6, 0.6, 1200, 120, 0.8, 'bandpass'); },
  slam(t) { osc('sine', 80, 25, t, 0.5, 1); noise(t, 0.5, 0.7, 2000, 80, 0.7, 'lowpass'); },
  tick(t) { osc('square', 1000, 1000, t, 0.05, 0.18); },
  go(t) { osc('square', 1000, 1000, t, 0.35, 0.22); osc('square', 1500, 1500, t, 0.35, 0.16); },
  click(t) { osc('triangle', 700, 1000, t, 0.06, 0.25); },
  coin(t) { osc('square', 1318, 1318, t, 0.07, 0.16); osc('square', 1760, 1760, t + 0.07, 0.22, 0.16); },
  buy(t) { osc('square', 660, 660, t, 0.07, 0.2); osc('square', 880, 880, t + 0.07, 0.07, 0.2); osc('square', 1320, 1320, t + 0.14, 0.2, 0.2); },
  deny(t) { osc('square', 160, 120, t, 0.18, 0.25); },
  win(t) { [69, 73, 76, 81].forEach((n, i) => osc('square', mtof(n), mtof(n), t + i * 0.1, 0.35, 0.18)); },
  throw(t) { noise(t, 0.5, 0.5, 300, 2400, 1.2); osc('sawtooth', 70, 140, t, 0.4, 0.25); },
  // pop-up stings (rising arcade arpeggio; tier 0-4 = higher + longer)
  sting(t, tier = 0) { const b = 72 + tier * 3, n = 3 + Math.min(2, tier); for (let i = 0; i < n; i++) osc('square', mtof(b + [0, 4, 7, 12, 16][i]), mtof(b + [0, 4, 7, 12, 16][i]), t + i * 0.045, 0.09 + (i === n - 1 ? 0.1 : 0), 0.11);
    if (tier >= 2) osc('sine', mtof(b + 24), mtof(b + 24), t + n * 0.045, 0.25, 0.06); },
  rumble(t) { noise(t, 1.4, 0.7, 180, 60, 0.7, 'lowpass'); osc('sine', 45, 35, t, 1.4, 0.6); },
  rise(t) { noise(t, 1.9, 0.6, 120, 900, 0.8, 'lowpass'); osc('sawtooth', 40, 80, t, 1.9, 0.25); },
  ignite(t) { osc('sawtooth', 220, 1760, t, 0.35, 0.18); osc('square', 1760, 1760, t + 0.3, 0.3, 0.12); noise(t, 0.4, 0.4, 2000, 9000, 1.5); },
  card(t) { osc('sine', 70, 40, t, 0.5, 0.9); noise(t, 0.4, 0.5, 4000, 300, 0.6); [57, 64, 69].forEach((n) => osc('sawtooth', mtof(n), mtof(n), t, 0.7, 0.08)); },
  retreat(t) { osc('sawtooth', 160, 30, t, 2, 0.3); noise(t, 2, 0.3, 800, 60, 0.6, 'lowpass'); },
};

// ---- procedural music fallback: A minor, Am F C G (plays only while the state's file isn't in) ----
const ROOTS = [33, 29, 36, 31]; // A1 F1 C2 G1
const CH = [[57, 60, 64], [53, 57, 60], [60, 64, 67], [55, 59, 62]];
function sched() {
  if (!ac || ac.state !== 'running') return;
  while (nextT < ac.currentTime + 0.2) { play(step, nextT); step++; nextT += SPS; }
}
function kick(t) { osc('sine', 150, 42, t, 0.18, 0.95, musBus); }
function snare(t) { noise(t, 0.16, 0.5, 2500, 1200, 0.8, 'bandpass', musBus); osc('triangle', 220, 120, t, 0.09, 0.3, musBus); }
function hat(t, v = 0.14) { noise(t, 0.04, v, 9000, 8000, 0.6, 'highpass', musBus); }
function play(s, t) {
  if (procMode === 'off') return;
  const bar = Math.floor(s / 16) % 4, i = s % 16, root = ROOTS[bar], ch = CH[bar];
  const fight = procMode !== 'lobby', hard = procMode === 'enrage';
  if (fight) { if (i % 4 === 0 || (hard && i === 14)) kick(t); if (i === 4 || i === 12) snare(t); if (i % 2 === 1 || hard) hat(t, i % 4 === 2 ? 0.2 : 0.1); }
  else if (i % 8 === 0) kick(t);
  if (i % 2 === 0 && (fight || i % 4 === 0)) {
    const o = ac.createOscillator(), g = ac.createGain(), f = ac.createBiquadFilter();
    o.type = 'sawtooth'; o.frequency.value = mtof(root + ((i === 6 || i === 14) ? 12 : 0)); f.type = 'lowpass'; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(220, t + 0.14);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.4, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + SPS * 1.9);
    o.connect(f); f.connect(g); g.connect(musBus); o.start(t); o.stop(t + SPS * 2);
  }
  const an = ch[[0, 1, 2, 1, 0, 2, 1, 2][i % 8] % 3] + (i % 8 > 4 ? 12 : 0) + 12;
  if (fight || i % 2 === 0) osc('square', mtof(an), mtof(an), t, SPS * 0.9, fight ? 0.07 : 0.05, musBus);
  if (i === 0) for (const n of ch) osc('triangle', mtof(n + 12), mtof(n + 12), t, SPS * 15, 0.06, musBus);
  if (hard && i % 4 === 0) { const L = [76, 79, 81, 79, 83, 81, 79, 76][(Math.floor(s / 4)) % 8]; osc('sawtooth', mtof(L), mtof(L), t, SPS * 3.5, 0.08, musBus, 6); }
  if (procMode === 'fight' && bar % 2 === 1 && i % 4 === 2) { const L = [72, 76, 79, 76][(i >> 2) % 4]; osc('sawtooth', mtof(L), mtof(L), t, SPS * 2, 0.05, musBus, 6); }
}
