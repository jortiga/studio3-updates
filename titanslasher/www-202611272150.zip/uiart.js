// 11-26 INK UI ART (?style=ink only; tools/make_ui_ink.py): the UI art folder + item icon path. art/ui_ink/ mirrors art/ui/
// file for file (same names / canvas sizes); art/ui_ink/items/ holds the ink item icons (rings / amulets / armour / boots /
// charms; weapons keep art/items/ because the icon is also the in-hand sprite). The default style gets exactly the old paths.
// Static <img> tags in index.html and the CSS url()s are switched by the head script there + ink-ui.css.
export const INK = new URLSearchParams(location.search).get('style') === 'ink';
export const UI = INK ? 'art/ui_ink' : 'art/ui';
const INK_ITEMS = /^(ring|amulet|armor|boots|charm)_\d$/;
export const itemIcon = (icon) => (INK && INK_ITEMS.test(icon) ? `art/ui_ink/items/${icon}.webp` : `art/items/${icon}.webp`);
