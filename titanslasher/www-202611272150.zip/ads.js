// Titan Slasher ads bridge (store apps only; @capacitor-community/admob 7.2.0). Same rules as Gran Toretto / Runebound
// (grandtoreto-app/web-src/ads.js, PUBLISHING.md / MOBILE_PERFORMANCE.md):
//  - AdMob is NOT started at app boot. It starts after the first fight's results screen has settled, so SDK start-up and
//    ad loading never compete with the first fight.
//  - Google's UMP consent form where required, then Apple's tracking prompt (ATT) on iOS. Ads run whatever the answer.
//  - Our own phones get test ads: ad-ids.json "testDevices" (the hash is per app; read it from logcat / the Xcode log).
//  - Native loads only start at calm moments (lobby, or a results screen up for 2.5 s), one at a time; never mid-fight.
//
// GAME API (the game folder never imports this file; it only looks for the globals):
//   window.__rewardedAd(placement) -> Promise<boolean>: true only if the player watched to the reward. Any placement name
//     works ('daily30', 'energy', 'autotrain', 'prefight', ...); it is only a label. Never throws, never waits for a load.
//   "Ad ready" = typeof window.__rewardedAd === 'function'. It is a getter: the function exists ONLY while a rewarded ad is
//     loaded and ready to show. No fill / not loaded yet / after one was shown (until the next has loaded) / web and
//     CrazyGames builds: undefined, so a button checked at render time simply stays hidden. window.__rewardedAdReady()
//     returns the same answer as a boolean (native only).
//   window.TTAds = { start, rewarded, canReward }. REWARDED ONLY (user 11-27: no interstitials in this game; the AdMob
//     interstitial units exist but are unused and deliberately not in ad-ids.json).
// Game audio: every AudioContext the game creates is suspended while an ad is on screen (window.__audioHeld blocks the
// game's own resume-on-tap) and resumed after.
// Ad unit ids come from ad-ids.js (build_www.py writes it from ad-ids.json; --dev builds get Google's public test units).
(() => {
  const C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform() || !C.Plugins || !C.Plugins.AdMob) return;
  const AdMob = C.Plugins.AdMob;
  const ALL = window.TT_AD_IDS || {};
  const IDS = C.getPlatform() === 'ios'
    ? (ALL.ios || { rewarded: 'ca-app-pub-3940256099942544/1712485313', testing: true })
    : ALL;
  const testing = !!IDS.testing;
  let started = null, ready = false, rLoaded = false, rLoading = null, showing = false;

  // audio: remember the game's AudioContexts (this script runs before the game modules) so an ad can silence them
  const ctxs = [];
  ['AudioContext', 'webkitAudioContext'].forEach((k) => {
    const B = window[k]; if (!B) return;
    window[k] = class extends B { constructor(...a) { super(...a); ctxs.push(this); } };
  });
  const hold = (on) => {
    window.__audioHeld = on;
    ctxs.forEach((c) => { if (c.state === 'closed') return; (on ? c.suspend() : c.resume()).catch(() => {}); });
    if (!on) setTimeout(() => ctxs.forEach((c) => { if (!window.__audioHeld && c.state !== 'running' && c.state !== 'closed') c.resume().catch(() => {}); }), 300);
  };

  // calm moments only: the lobby, or a results screen that has been up for 2.5 s; never intro / fight / descent
  let resSince = 0;
  const calmNow = () => { const g = window.__g && window.__g.G; if (!g) return false;
    if (g.state !== 'results') resSince = 0; else if (!resSince) resSince = Date.now();
    return !document.hidden && (g.state === 'lobby' || (g.state === 'results' && Date.now() - resSince > 2500)); };
  const calmQ = [];
  let calmBusy = false;
  setInterval(() => { if (calmQ.length && !calmBusy && !showing && calmNow()) { const f = calmQ.shift(); calmBusy = true;
    Promise.resolve().then(f).catch(() => {}).then(() => { calmBusy = false; }); } else calmNow(); }, 400);
  const whenCalm = (f) => { if (!calmQ.includes(f)) calmQ.push(f); };

  const once = (event) => new Promise((resolve) => {
    let h; AdMob.addListener(event, (v) => { h && h.remove(); resolve(v); }).then((x) => (h = x));
  });

  function prepR() {   // no fill / error: stays "not ready" (button hidden), retried at a calm moment 30 s later
    if (!IDS.rewarded || rLoaded || rLoading || !ready) return rLoading;
    rLoading = AdMob.prepareRewardVideoAd({ adId: IDS.rewarded, isTesting: testing })
      .then(() => { rLoaded = true; }, () => { rLoaded = false; setTimeout(() => whenCalm(prepR), 30000); })
      .finally(() => { rLoading = null; });
    return rLoading;
  }

  function start() {
    if (started) return started;
    started = (async () => {
      try {
        await AdMob.initialize({ initializeForTesting: testing || !!(IDS.testDevices && IDS.testDevices.length), testingDevices: IDS.testDevices || [] });
        try {
          const info = await AdMob.requestConsentInfo();
          if (info.isConsentFormAvailable && info.status === 'REQUIRED') await AdMob.showConsentForm();
        } catch (e) { /* consent service unreachable: non-personalised ads */ }
        if (C.getPlatform() === 'ios') { try { await AdMob.requestTrackingAuthorization(); } catch (e) { /* not available */ } }
        ready = true; whenCalm(prepR);
      } catch (e) { /* AdMob unavailable: the game runs without ads */ }
    })();
    return started;
  }

  // Resolves true only if the player watched to the reward. Not loaded: false at once (and a load is queued).
  async function rewarded(placement) {
    if (!ready || !rLoaded || showing) { if (!showing) whenCalm(() => start().then(() => whenCalm(prepR))); return false; }
    rLoaded = false; showing = true;
    let got = false, h = null;
    try {
      h = await AdMob.addListener('onRewardedVideoAdReward', () => { got = true; });
      const closed = Promise.race([once('onRewardedVideoAdDismissed'), once('onRewardedVideoAdFailedToShow')]);
      hold(true);
      await AdMob.showRewardVideoAd(); await closed;
    } catch (e) { /* failed to show: no reward */ }
    try { h && h.remove(); } catch (e) {}
    hold(false); showing = false; whenCalm(prepR);
    return got;
  }

  const canReward = () => ready && rLoaded && !showing;
  window.TTAds = { start, rewarded, canReward };
  window.__rewardedAdReady = canReward;
  Object.defineProperty(window, '__rewardedAd', { configurable: true, get: () => (canReward() ? rewarded : undefined) });

  // start after the first fight's results screen (once it has settled)
  const t = setInterval(() => {
    const g = window.__g && window.__g.G;
    if (g && g.state === 'results') { clearInterval(t); whenCalm(start); }
  }, 500);
})();
