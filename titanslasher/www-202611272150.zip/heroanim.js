// Hero idle flipbook (11-26, user: "can we make the character when idle a spritesheet?").
// Art: art/hero/idle_anim.webp = one Codex sheet of N idle frames (tools/make_hero_idle.py), every frame registered onto idle.webp's
// frame (same aspect, same character scale: TEXK = idle_anim.k), so it drops in wherever T.hi was used for the idle.
// Per-frame hand / blade anchors: hero_rig.json poses.idle_<i> (equipment.js reads them through poseTex()).
// The atlas is sliced into one canvas texture per frame at load (the hero shader samples a whole texture, no UV offsets).
// ?noidleanim=1 = the old still idle.
import * as THREE from 'three';

const OFF = /[?&]noidleanim=1/.test(location.search);
export const HA = {
  frames: [], seq: [], fps: 9, t: 0, cur: null,
  get on() { return this.frames.length > 0; },
  // ctx: { rig (hero_rig.json), loadTex, setK(tex, k), poseTex(tex, name) }
  async init(ctx) {
    const A = ctx.rig?.idle_anim; if (OFF || !A) return;
    const atlas = await ctx.loadTex(A.file).catch(() => null); if (!atlas) return;
    const img = atlas.image, fw = Math.round(img.width / A.cols), fh = Math.round(img.height / A.rows);
    for (let i = 0; i < A.n; i++) {
      const c = document.createElement('canvas'); c.width = fw; c.height = fh;
      c.getContext('2d').drawImage(img, (i % A.cols) * fw, Math.floor(i / A.cols) * fh, fw, fh, 0, 0, fw, fh);
      const t = new THREE.CanvasTexture(c); t.colorSpace = atlas.colorSpace; t.anisotropy = atlas.anisotropy; t.needsUpdate = true;
      ctx.setK(t, A.k || 1); ctx.poseTex(t, `idle_${i}`); this.frames.push(t);
    }
    atlas.dispose();
    this.fps = A.fps || 9;
    // play order: explicit seq, else loop / ping-pong over 0..n-1 (a frame listed twice = held twice as long)
    this.seq = A.seq || (A.mode === 'pingpong' ? [...Array(A.n).keys(), ...[...Array(Math.max(0, A.n - 2)).keys()].map((k) => A.n - 2 - k)] : [...Array(A.n).keys()]);
    this.t = Math.random() * this.seq.length / this.fps; // random start frame
    this.cur = this.frames[this.seq[0]];
  },
  // advance the clock and return the current frame texture (null when off)
  tick(dt) {
    if (!this.on) return null;
    this.t = (this.t + dt) % (this.seq.length / this.fps);
    return (this.cur = this.frames[this.seq[Math.floor(this.t * this.fps) % this.seq.length]]);
  },
  reset() { this.t = 0; if (this.on) this.cur = this.frames[this.seq[0]]; }, // landing -> idle hands off to frame 0
  has(tex) { return this.frames.includes(tex); },
};
