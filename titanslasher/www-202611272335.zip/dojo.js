// 11-27 DOJO LOBBY (user picked concept C "training ground", tools/raw/lobby_bg/c.png): the main menu / lobby stands in a rock-carved
// shrine hall; the titan FIGHT keeps the ink cave (arenas/inkcave + inkdeco.js). Ink style only (?style=ink), ?lobbybg=cave = the old
// lobby. Art: arenas/dojo/ (tools/make_dojo_layers.py mattes the painting into layers + dojo.json anchors).
//
// Layers are real 3D geometry, textured so that from the lobby REST camera they recompose the painting exactly (quad corners =
// rest-camera rays through the painting's placement on screen, hit against each layer's plane; perspective-correct UVs keep the
// mapping exact inside). Any camera move (shake) then gives true parallax:
//   base   : the inpainted painting, upper part on a vertical WALL plane, lower part (from the floor seam) on the FLOOR plane
//            (y = the dummy's feet). Brazier flames + lantern halos flicker from glow.webp (R core, G halo, B light id).
//   hang   : banners (sway from the rod down) + the centre lantern (swings on its chain), just in front of the wall
//   pillars: the two pillars + side lanterns (swing), on a vertical plane at the pillar bases' floor depth
//   fgtop / fgbot: the black stalactites + vines (vines sway) and the foreground rocks, near planes
//   step   : the stone step, re-placed under the hero's feet (stretched to reach him on narrow phones)
//   + soft light shafts (additive, slow sway), two drifting mist bands, ~60 motes. 9 draw calls, ~170 KB of WebP.
// The painting is placed so the carved ring sits under the training dummy (screen position of its root) and >= FIT_W of its width
// shows on phones; above / below / beside it the base fades to black (the UI bars sit there).
// Lobby <-> fight: while G.state is start / lobby / blackout (until the swap under the black), the dojo shows and the cave set (env,
// water, reflections, base mist, ink deco, titan) is hidden for the scene render (scene.onBeforeRender / onAfterRender: no
// per-object bookkeeping in main.js); the inkdeco black frame (drawn by main.js after the post chain) is untagged while hidden.
import * as THREE from 'three';
import { SH } from './fx.js';

const DIR = 'arenas/dojo/';
const FIT_W = .91; // share of the painting's width kept on screen on narrow phones (side lanterns + braziers stay in)
const RO = { base: 1, shafts: 2, mist: 3, hang: 4, pillars: 5, motes: 6, fgtop: 7, step: 335, fgbot: 336 }; // dummy 330+, hero 380
const Q = new URLSearchParams(location.search);
let D = null;

const VS = `attribute vec4 aR; attribute vec4 aA; varying vec3 vW; varying vec4 vR; varying vec4 vA;
  void main(){ vR = aR; vA = aA; vec4 w = modelMatrix * vec4(position, 1.); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`;
// projective texturing: the fragment's world point seen by the REST camera (rVP) -> rest screen -> painting uv (0..1, y down) via
// pm = (x scale, x offset, y scale, y offset). Exact on any plane (the floor too), true parallax when the real camera moves.
// tex(): painting uv -> this quad's atlas texel (clamped to its part)
const TEX = `uniform mat4 rVP; uniform vec4 pm; varying vec3 vW; varying vec4 vR; varying vec4 vA; vec2 vP;
  vec2 paintUV(){ vec4 c = rVP * vec4(vW, 1.); vec2 n = c.xy / c.w; return vec2((n.x * .5 + .5) * pm.x + pm.y, (.5 - n.y * .5) * pm.z + pm.w); }
  vec4 tex(sampler2D m, vec2 p){ vec2 q = clamp(p, vR.xy, vR.zw); vec2 a = vA.xy + (q - vR.xy) / max(vR.zw - vR.xy, vec2(1e-5)) * (vA.zw - vA.xy); return texture2D(m, vec2(a.x, 1. - a.y)); }`;
const FLICK = `float flick(float id, float t){ if (id < .5) return 1.;
    if (id < 3.5) return .93 + .05 * sin(t * 1.7 + id * 2.1) + .03 * sin(t * 4.3 + id * 5.); // lanterns: slow breathing
    return .82 + .1 * sin(t * 11. + id * 3.) + .07 * sin(t * 6.7 + id * 5.) + .06 * sin(t * 23. + id); } // flames: fast flicker
`;
// lantern swing: up to 6 rects (chain + body per lantern), pivot per pair
const SWING = `uniform vec4 swR[6]; uniform vec2 swP[3]; uniform float asp;
  vec2 swing(vec2 p, float t){ for (int i = 0; i < 6; i++) { vec4 r = swR[i]; if (p.x > r.x && p.x < r.z && p.y > r.y && p.y < r.w) {
      float k = float(i / 2), a = .016 * sin(t * 1.05 + k * 2.3) + .005 * sin(t * 2.4 + k * 4.1); vec2 pv = swP[i / 2];
      vec2 d = (p - pv) * vec2(asp, 1.); d = mat2(cos(a), sin(a), -sin(a), cos(a)) * d; return pv + d / vec2(asp, 1.); } } return p; }`;

const _a = new THREE.Vector3(), _b = new THREE.Vector3();
// rest-camera ray through screen point (sx, sy: 0..1, y down) hit on plane {z} or {y}
function hit(rc, sx, sy, pl) {
  _a.set(sx * 2 - 1, 1 - sy * 2, -1).unproject(rc); _b.set(sx * 2 - 1, 1 - sy * 2, 1).unproject(rc);
  const k = pl.z != null ? (pl.z - _a.z) / (_b.z - _a.z) : (pl.y - _a.y) / (_b.y - _a.y);
  return new THREE.Vector3().lerpVectors(_a, _b, k);
}

export async function initDojo(ctx) {
  const J = await fetch(DIR + 'dojo.json?' + Date.now()).then((r) => r.json());
  const ld = (f) => ctx.loadTex(DIR + f);
  const [base, glow, pillars, hang, step, fgtop, fgbot] = await Promise.all([J.base, J.glow, J.pillars, J.hang, J.step, J.fgtop, J.fgbot].map((x) => ld(x.file)));
  for (const t of [pillars, hang, step, fgtop, fgbot, base, glow]) { t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; }
  const [PW, PH] = J.size, n = (x, y) => [x / PW, y / PH], nr = (r) => [r[0] / PW, r[1] / PH, r[2] / PW, r[3] / PH];
  const U = { t: SH.time, fade: { value: 0 }, asp: { value: PW / PH }, rVP: { value: new THREE.Matrix4() }, pm: { value: new THREE.Vector4(1, 0, 1, 0) } };
  const swR = [], swP = []; for (const s of J.swing) { swP.push(new THREE.Vector2(...n(...s.pivot))); for (const r of s.rects) swR.push(new THREE.Vector4(...nr(r))); }
  while (swR.length < 6) swR.push(new THREE.Vector4(2, 2, 2, 2)); while (swP.length < 3) swP.push(new THREE.Vector2());
  const mat = (fs, u, o = {}) => new THREE.ShaderMaterial({ uniforms: { ...U, ...u }, vertexShader: VS, fragmentShader: fs, transparent: true, depthTest: false, depthWrite: false, ...o });

  const M = {};
  M.base = mat(`uniform sampler2D map; uniform sampler2D gmap; uniform float t; uniform float fade; ${TEX} ${FLICK}
    void main(){ vP = paintUV(); vec2 p = clamp(vP, 0., 1.); vec3 g = texture2D(gmap, vec2(p.x, 1. - p.y)).rgb; float id = floor(g.b * 8. + .5), fk = flick(id, t);
      if (id > 3.5) p.x += sin(t * 9. + p.y * 260.) * .0011 * g.g; // flames lick sideways
      vec3 c = texture2D(map, vec2(p.x, 1. - p.y)).rgb;
      c *= 1. + g.g * (fk - 1.) * 1.3; c += vec3(.55, .95, 1.) * g.r * (fk - .78) * .9; // halo breathes with the light, core flares
      // 11-28 user "fade it to the corner so the smoke blends": the floor's straight front edge (painting y ~.82) dissolves into
      // drifting smoke, and the lower corners sink into the dark
      float nx = vP.x * 9., n = sin(nx * 1.3 + t * .21) * .5 + sin(nx * 2.9 - t * .17 + 1.7) * .3 + sin(nx * 6.1 + t * .31 + vP.y * 40.) * .2, yy = vP.y + n * .009;
      float sm = smoothstep(.758, .814, vP.y + n * .006) * (1. - smoothstep(.862, .925, yy));
      c = mix(c, mix(vec3(.235, .33, .35), vec3(.115, .175, .19), smoothstep(.785, .865, yy)) * (1. + n * .08), sm);
      c = mix(c, vec3(.012, .022, .026), .8 * smoothstep(.4, .98, abs(vP.x - .5) * 2.) * smoothstep(.66, .86, vP.y));
      vec2 d = max(-vP, vP - 1.); c = mix(c, vec3(.008, .012, .014), smoothstep(0., .05, d.y) + .35 * smoothstep(0., .25, d.x)); // beyond the painting: top / bottom black; sides keep the edge colour, only a little darker (11-27: the gear zoom showed a black strip)
      gl_FragColor = vec4(c, fade); }`, { map: { value: base }, gmap: { value: glow } });
  M.hang = mat(`uniform sampler2D map; uniform sampler2D gmap; uniform float t; uniform float fade; uniform vec4 ban[2]; uniform float rod[2]; ${TEX} ${FLICK} ${SWING}
    void main(){ vP = paintUV(); vec2 p = swing(vP, t);
      for (int i = 0; i < 2; i++) { vec4 r = ban[i]; if (vP.x > r.x && vP.x < r.z && vP.y > rod[i]) { float w = pow(clamp((vP.y - rod[i]) / (r.w - rod[i]), 0., 1.), 1.4);
        p.x += w * (.0045 * sin(t * 1.25 + vP.y * 9. + float(i) * 1.7) + .0015 * sin(t * 3.1 + vP.y * 23.)); } } // cloth sways from the rod down
      vec4 c = tex(map, p); if (c.a < .02) discard; vec3 g = texture2D(gmap, vec2(p.x, 1. - p.y)).rgb;
      c.rgb += vec3(.55, .95, 1.) * g.r * (flick(floor(g.b * 8. + .5), t) - .78) * .9;
      gl_FragColor = vec4(c.rgb, c.a * fade); }`, { map: { value: hang }, gmap: { value: glow }, swR: { value: swR }, swP: { value: swP },
    ban: { value: J.banners.map((b) => new THREE.Vector4(...nr(b.rect))) }, rod: { value: J.banners.map((b) => b.rod / PH) } });
  M.pillars = mat(`uniform sampler2D map; uniform sampler2D gmap; uniform float t; uniform float fade; ${TEX} ${FLICK} ${SWING}
    void main(){ vP = paintUV(); vec2 p = swing(vP, t); vec4 c = tex(map, p); if (c.a < .02) discard; vec3 g = texture2D(gmap, vec2(p.x, 1. - p.y)).rgb;
      c.rgb += vec3(.55, .95, 1.) * g.r * (flick(floor(g.b * 8. + .5), t) - .78) * .9;
      gl_FragColor = vec4(c.rgb, c.a * fade); }`, { map: { value: pillars }, gmap: { value: glow }, swR: { value: swR }, swP: { value: swP } });
  const fgFS = (top) => `uniform sampler2D map; uniform float t; uniform float fade; ${TEX}
    void main(){ vP = paintUV(); vec2 p = vP; ${top ? `float w = tex(map, p).g; p.x -= w * clamp(p.y * 4., 0., 1.) * .0032 * (.55 + .35 * sin(t * .9 - p.x * 3.2) + .10 * sin((t * .9 - p.x * 3.2) * 2.3 + 1.1));` : ''}
      p.y = ${top ? 'max(p.y, .0015)' : 'min(p.y, .9985)'}; vec4 c = tex(map, p); c.a = max(c.a, ${top ? '1. - smoothstep(.0015, .014, vP.y)' : 'smoothstep(.986, .9985, vP.y)'}); // the black ceiling / rocks run on past the painting (11-28: straight cut)
      c.a *= smoothstep(.04, 0., max(-vP.x, vP.x - 1.)); if (c.a < .02) discard; gl_FragColor = vec4(vec3(c.r) * vec3(.05, .07, .075), c.a * fade); }`;
  M.fgtop = mat(fgFS(true), { map: { value: fgtop } }); M.fgbot = mat(fgFS(false), { map: { value: fgbot } });
  M.step = mat(`uniform sampler2D map; uniform float t; uniform float fade; uniform float lf; ${TEX}
    void main(){ vP = paintUV(); vec4 c = tex(map, vP); float e = (vP.x - vR.x) / (vR.z - vR.x); c.a *= smoothstep(0., lf, e);
      float ey = (vP.y - vR.y) / (vR.w - vR.y) + .035 * sin(e * 17. + t * .4) + .02 * sin(e * 41. - t * .3); // its foot dissolves into the same smoke
      c.rgb = mix(c.rgb, vec3(.17, .25, .27), .7 * smoothstep(.6, .88, ey)); c.a *= 1. - smoothstep(.68, .97, ey); if (c.a < .02) discard; gl_FragColor = vec4(c.rgb, c.a * fade); }`,
  { map: { value: step }, lf: { value: 0 }, pm: { value: new THREE.Vector4() } });
  M.shafts = mat(`uniform float t; uniform float fade; uniform float asp; ${TEX}
    void main(){ vP = paintUV(); vec2 q = vec2(vP.x * asp, vP.y), dir = normalize(vec2(.62, .78)), nrm = vec2(dir.y, -dir.x); float r = 0.;
      for (int i = 0; i < 4; i++) { float fi = float(i), c = .02 + fi * .06 + sin(t * .09 + fi * 2.1) * .012, w = .012 + .014 * fract(fi * .61);
        float ac = dot(q - vec2(.12, -.02), nrm) - c; r += (smoothstep(w, 0., abs(ac)) + smoothstep(w * 4., 0., abs(ac)) * .4) * (.55 + .45 * sin(t * (.31 + fi * .07) + fi * 2.3)); }
      float al = dot(q - vec2(.12, -.02), dir); r *= smoothstep(.0, .06, al) * smoothstep(.42, .1, al) * (.85 + .15 * sin(al * 60. - t * .8));
      float a = r * .07 * fade; gl_FragColor = vec4(vec3(.75, .95, 1.) * a, a); }`, {}, { blending: THREE.AdditiveBlending });
  M.mist = mat(`uniform float t; uniform float fade; uniform float asp; ${TEX}
    void main(){ vP = paintUV(); float y = (vP.y - vR.y) / (vR.w - vR.y), x = vP.x * asp * 3. + vR.y * 40.;
      float nn = sin(x * 1.7 + t * .13) * .5 + sin(x * 3.9 - t * .19 + 1.3) * .3 + sin(x * 8.3 + t * .27 + y * 3.) * .2, yy = y + nn * .12;
      float al = smoothstep(0., .45, yy) * smoothstep(1., .55, yy) * (.55 + .45 * (sin(x * 2.3 - t * .16 + nn * 2.) * .5 + .5)) * .2 * fade * smoothstep(.05, 0., max(-vP.x, vP.x - 1.));
      if (al < .004) discard; gl_FragColor = vec4(.5, .64, .68, al); }`);

  // motes: soft drifting specks inside the hall (rest position + drift in the vertex shader)
  const NM = 60, mp = new Float32Array(NM * 3), ms = new Float32Array(NM * 4), R = Math.random;
  for (let i = 0; i < NM; i++) { mp.set([(R() - .5) * 16, R() * 14 - .5, -9 + R() * 12], i * 3); ms.set([R(), R(), R(), R()], i * 4); }
  const mg = new THREE.BufferGeometry(); mg.setAttribute('position', new THREE.BufferAttribute(mp, 3)); mg.setAttribute('seed', new THREE.BufferAttribute(ms, 4));
  const mu = { t: SH.time, fade: U.fade, px: { value: 1 } };
  const motes = new THREE.Points(mg, new THREE.ShaderMaterial({ uniforms: mu, transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending,
    vertexShader: `attribute vec4 seed; uniform float t; uniform float px; varying float vA;
      void main(){ vec3 p = position; p.y = mod(p.y + .5 + t * (.08 + seed.x * .18), 14.) - .5; p.x += sin(t * (.15 + seed.y * .2) + seed.z * 30.) * .8; p.z += cos(t * .11 + seed.y * 9.) * .6;
        vec4 mv = modelViewMatrix * vec4(p, 1.); gl_Position = projectionMatrix * mv; gl_PointSize = clamp((1. + seed.z * 1.5) * px * 60. / max(3., -mv.z), 1.2, 7.);
        vA = (.4 + .6 * sin(t * (.5 + seed.w) + seed.x * 40.)) * smoothstep(-.5, 1., p.y) * smoothstep(13.5, 10., p.y); }`,
    fragmentShader: `uniform float fade; varying float vA; void main(){ float d = length(gl_PointCoord - .5) * 2.; if (d > 1.) discard; float a = pow(1. - d, 2.) * vA * .55 * fade; gl_FragColor = vec4(vec3(.8, 1., 1.) * a, a); }` }));
  motes.renderOrder = RO.motes; motes.frustumCulled = false;

  const meshes = {}; // geometry is (re)built by place()
  for (const k of ['base', 'hang', 'pillars', 'fgtop', 'fgbot', 'step', 'shafts', 'mist']) {
    const m = new THREE.Mesh(new THREE.BufferGeometry(), M[k]); m.renderOrder = RO[k]; m.frustumCulled = false; m.userData.dojo = k; m.visible = false; meshes[k] = m; ctx.scene.add(m); }
  motes.userData.dojo = 'motes'; motes.visible = false; ctx.scene.add(motes); meshes.motes = motes;
  const rc = new THREE.PerspectiveCamera();
  D = { ctx, J, M, U, meshes, rc, sig: '', k: 0, shown: false, hide: [], hideN: -1, saved: [], frames: [] };
  // atlas parts in painting-normalized coords
  D.parts = {}; for (const k of ['pillars', 'hang', 'step', 'fgtop', 'fgbot']) { const L = J[k];
    D.parts[k] = L.parts.map((p) => ({ src: nr(p.src), at: [p.at[0] / L.size[0], p.at[1] / L.size[1], p.at[2] / L.size[0], p.at[3] / L.size[1]] })); }
  hook(ctx.scene);
  ctx.world.dojo = D;
  return D;
}

// quads: [{ r: painting rect (normalized, may exceed 0..1), pl: plane, src, at, map?: (sx, sy) screen mapper }]
function geo(m, quads) {
  const P = [], PV = [], AR = [], AA = [], I = [];
  quads.forEach((q, i) => { const [x0, y0, x1, y1] = q.r, src = q.src || [0, 0, 1, 1], at = q.at || [0, 0, 1, 1];
    for (const [x, y] of [[x0, y1], [x1, y1], [x1, y0], [x0, y0]]) { const s = q.map(x, y); P.push(...hit(D.rc, s[0], s[1], q.pl).toArray()); PV.push(x, y); AR.push(...src); AA.push(...at); }
    I.push(i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3); });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('pv', new THREE.Float32BufferAttribute(PV, 2));
  g.setAttribute('aR', new THREE.Float32BufferAttribute(AR, 4)); g.setAttribute('aA', new THREE.Float32BufferAttribute(AA, 4)); g.setIndex(I);
  m.geometry.dispose(); m.geometry = g;
}

// fit the painting to the current rest view (on resize / layout changes only)
function place() {
  const { ctx, J, rc, meshes } = D, cam = ctx.camera, w = ctx.world, [PW, PH] = J.size, pa = PW / PH;
  rc.fov = cam.fov; rc.aspect = cam.aspect; rc.near = cam.near; rc.far = cam.far; rc.position.copy(ctx.restPos); rc.up.set(0, 1, 0); rc.lookAt(ctx.restLook);
  rc.updateProjectionMatrix(); rc.updateMatrixWorld(true);
  const sa = cam.aspect, dp = w.dummy.home || w.dummy.root.position, dv = dp.clone().project(rc), sxd = (dv.x + 1) / 2, syd = (1 - dv.y) / 2;
  const ring = J.anchors.ring, ry = ring[1] / PH, rx = ring[0] / PW;
  const S = Math.min(sa / (pa * FIT_W), syd / ry), kx = S * pa / sa, oy = syd - ry * S;
  const scr = (x, y) => [sxd + (x - rx) * kx, oy + y * S]; // painting (normalized) -> rest screen
  D.U.rVP.value.multiplyMatrices(rc.projectionMatrix, rc.matrixWorldInverse); D.U.pm.value.set(1 / kx, rx - sxd / kx, 1 / S, -oy / S);
  const inv = (sx, sy) => [rx + (sx - sxd) / kx, (sy - oy) / S];
  const floor = { y: dp.y }, zAt = (py) => hit(rc, .5, scr(.5, py)[1], floor).z;
  const seam = J.anchors.seam / PH, Zw = zAt(seam), Zp = zAt(J.anchors.pillarBase / PH);
  // painting rect that covers the rest view with a margin (+ the lobby view shift)
  const [ex0, ey0] = inv(-.2, -.16), [ex1, ey1] = inv(1.2, 1.12); // 11-27 sides -.2 / 1.2 (was .06): the 3D gear view (lobby-ui.js) zooms + pans onto the hero, past the rest view's left edge
  const all = (r, pl, o = {}) => ({ r, pl, map: scr, ...o });
  geo(meshes.base, [all([ex0, ey0, ex1, seam], { z: Zw }), all([ex0, seam, ex1, ey1], floor)]);
  const pq = (k, pl) => D.parts[k].map((p) => all(p.src, pl, { src: p.src, at: p.at }));
  geo(meshes.pillars, pq('pillars', { z: Zp }));
  geo(meshes.hang, pq('hang', { z: Zw + .6 }));
  const Zn = Math.min(ctx.restPos.z - 4, (w.heroHome?.z ?? 6.5) + .5);
  { const p = D.parts.fgtop[0]; geo(meshes.fgtop, [all([ex0, Math.min(ey0, 0), ex1, p.src[3]], { z: Zn - 1 }, { src: p.src, at: p.at })]); }
  { const p = D.parts.fgbot[0]; geo(meshes.fgbot, [all([ex0, p.src[1], ex1, Math.max(ey1, 1)], { z: Zn + 1.2 }, { src: p.src, at: p.at })]); }
  geo(meshes.shafts, [all([0, 0, .62, .32], { z: Zw + 1 })]);
  { const a = [ex0, .6, ex1, .7], b = [ex0, .8, ex1, .875]; geo(meshes.mist, [all(a, { z: Zw + 1.5 }, { src: a }), all(b, { z: (Zp + Zn) / 2 }, { src: b })]); }
  // step under the hero's feet: same vertical scale, stretched sideways so its left (cut) end leaves the screen; else faded
  { const hh = w.heroHome, hv = hh.clone().project(rc), hx = (hv.x + 1) / 2, hy = (1 - hv.y) / 2, p = D.parts.step[0], f = J.anchors.stepFeet, fx = f[0] / PW, fy = f[1] / PH;
    const st = Math.min(1.45, Math.max(1, (hx + .02) / (fx * kx))), sk = kx * st, map = (x, y) => [hx + (x - fx) * sk, hy + (y - fy) * S];
    D.M.step.uniforms.lf.value = map(0, 0)[0] > -.01 ? .35 : 0; D.M.step.uniforms.pm.value.set(1 / sk, fx - hx / sk, 1 / S, fy - hy / S);
    geo(meshes.step, [{ r: p.src, pl: { z: hh.z }, map, src: p.src, at: p.at }]); }
  const dpr = ctx.renderer ? ctx.renderer.getPixelRatio() : 1; meshes.motes.material.uniforms.px.value = (innerHeight * dpr) / 844 * 3;
  D.place = { S, kx, oy, Zw, Zp, Zn, sxd, syd };
}

// cave set hidden while the dojo shows: env / water / reflections / base mist / ink deco / titan (rebuilt when the scene changes)
function caveSet() {
  const { ctx } = D, w = ctx.world, s = new Set();
  const add = (o) => { if (o && o.isObject3D && !o.userData.dojo) s.add(o); };
  // 11-27 fix: world.refl keeps a back-reference to world itself, so the scan walked into world.arcs / flashes / sparks ... and hid every
  // slash and hit effect in the lobby. Never descend into world (or the scene).
  const scan = (obj, d) => { if (!obj || typeof obj !== 'object' || d > 3 || obj.isTexture || obj.isMaterial || obj === w || obj === ctx.scene) return; if (obj.isObject3D) return add(obj);
    for (const v of Array.isArray(obj) ? obj : Object.values(obj)) if (v && typeof v === 'object') scan(v, d + 1); };
  for (const k of ['env', 'water', 'refl', 'mist']) if (w[k]) for (const v of Array.isArray(w[k]) ? w[k] : Object.values(w[k])) scan(v, 1);
  add(ctx.titan);
  for (const c of ctx.scene.children) if (c.userData.deco || c.userData.decoOff) add(c);
  for (const c of [w.dummy?.root, w.hero]) s.delete(c);
  return [...s].filter((o) => o.parent === ctx.scene);
}

function hook(scene) {
  const prevB = scene.onBeforeRender, prevA = scene.onAfterRender;
  scene.onBeforeRender = function (...a) { prevB?.apply(this, a); before(); };
  scene.onAfterRender = function (...a) { after(); prevA?.apply(this, a); };
}
let lastT = 0;
function before() {
  const { ctx, meshes } = D, st = ctx.state();
  const want = Q.get('lobbybg') !== 'cave' && (st === 'start' || st === 'lobby' || st === 'blackout');
  // once per frame (the scene can be rendered more than once per frame: selective glow pass)
  const t = SH.time.value; if (t !== lastT) { lastT = t;
    if (want || D.k > 0) { const cam = ctx.camera, sig = [cam.fov, cam.aspect, (ctx.world.dummy.home || ctx.world.dummy.root.position).toArray(), ctx.world.heroHome?.toArray()].join(); // 11-27 PERF PASS: no per-frame string while the dojo is off
      if (sig !== D.sig) { D.sig = sig; place(); } }
    if (!want) D.k = 0; else D.k = D.shown ? 1 : Math.min(1, D.k + 1 / 24); // first appearance: short fade in; later swaps happen under the black
    if (D.k >= 1) D.shown = true;
    D.M.base.uniforms.fade.value = D.k;
    // the inkdeco black frame is drawn by main.js after the post chain for every mesh tagged deco 'frame': untag it in the lobby
    for (const c of ctx.scene.children) { if (D.k >= 1 && c.userData.deco === 'frame') { c.userData.deco = undefined; c.userData.decoOff = 'frame'; D.frames.push(c); }
      else if (D.k < 1 && c.userData.decoOff === 'frame') { c.userData.deco = 'frame'; delete c.userData.decoOff; } }
  }
  for (const k in meshes) meshes[k].visible = D.k > 0;
  if (D.k > 0 && document.querySelector('#inv.g3d:not(.hidden)')) { meshes.fgbot.visible = false; meshes.fgtop.visible = false; } // 11-27 gear zoom: no black foreground silhouettes over the framed hero (PERF PASS: only asked while the dojo shows)
  D.saved.length = 0; if (D.k < 1) return;
  if (D.hideN !== ctx.scene.children.length) { D.hideN = ctx.scene.children.length; D.hide = caveSet(); }
  for (const o of D.hide) { D.saved.push(o.visible); o.visible = false; }
}
function after() {
  const { hide, saved } = D; if (!saved.length) return;
  for (let i = 0; i < hide.length; i++) hide[i].visible = saved[i];
  saved.length = 0;
}
export const DOJO = { get D() { return D; } };
