// Layered painted environment (user 11-25: "make it layered, even the environment"). Codex-painted layers at real depths:
// sky plate -> distant cloud bank -> far ruin silhouettes -> god rays -> mid floating ruins (bob/rotate) -> cloud sea strips
// (behind + in front of the titan's base) -> near mist wisps -> painted foreground ledge, pillars and floating debris.
// Side props are placed by SCREEN fraction at layout time so they frame the shot on phones and desktop alike.
// Dust / ash drift between the layers (one Points draw call, animated in the vertex shader).
// 11-26 ARENAS (user: "the environment should change too"): every layer keeps its mesh; setTheme(theme, tex) swaps the painted
// maps, glow masks, tints, fog distances, particle type, lightning / birds / sun colours in place (no rebuild, nothing leaks).
// arena.js loads game/arenas/<id>/arena.json and calls it; the theme keys are documented there (DEFAULT).
import * as THREE from 'three';
import { spriteMat, glowMat, SH } from './fx.js';
import { layerMat } from './water.js';
import { GLOW_LAYER, addGlow } from './glowmask.js';

const RO = { sky: 0, clouds: 2, far: 4, rays: 6, mid: 10, seaBack: 30, titan: 100, seaFront: 290, mist: 300, dust: 320, fg: 350 };
const rand = (a, b) => a + Math.random() * (b - a);
const SEA_Y = -.8; // the opaque sea plane (main.js floor): cloud layers thin out just above it, nothing is drawn under the water (11-26)
// floating piece: its own bob / sway / rotation amplitude, speed and phase (two harmonics each so nothing moves in lockstep)
const floaty = (s, h, b0, b1, r0, r1) => Object.assign(s, { bob: h * rand(b0, b1), bobS: rand(.28, .6), sway: h * rand(b0 * .5, b1 * .6), swayS: rand(.1, .26),
  rot: rand(r0, r1), rotS: rand(.1, .24), ph2: rand(0, 6) });
const asp = (t) => t.image.width / t.image.height;
// lowest row (fraction from the top) where the painted ledge still has art (>= 12% of the columns opaque: its underside tip); cached per texture
function solidRow(t) {
  if (t.userData.sb != null) return t.userData.sb;
  let sb = .85; try { const c = document.createElement('canvas'); c.width = 64; c.height = 64; const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(t.image, 0, 0, 64, 64);
    const d = g.getImageData(0, 0, 64, 64).data; for (let y = 63; y >= 0; y--) { let n = 0; for (let x = 0; x < 64; x++) if (d[(y * 64 + x) * 4 + 3] > 128) n++; if (n >= 8) { sb = (y + .5) / 64; break; } } } catch (e) { /* tainted / no 2d */ }
  return (t.userData.sb = sb);
}
let BLACK = null; // 1x1 black glow mask for a sprite whose new arena art has no mask
const black = () => BLACK || (BLACK = Object.assign(new THREE.DataTexture(new Uint8Array([0, 0, 0, 255]), 1, 1), { needsUpdate: true }));
// dust particle looks (theme.dust.type): vy = rise speed (negative falls), sw = sideways sway, st = streak (rain), sz = size
const DUST = { dust: { vy: .5, sw: 1, st: 0, sz: 1, a: .7 }, ash: { vy: .9, sw: 1.4, st: 0, sz: 1.1, a: .8 }, rain: { vy: -16, sw: .2, st: 1, sz: 2.2, a: .45 },
  snow: { vy: -1.3, sw: 2.2, st: 0, sz: 1.25, a: .75 }, sprinkles: { vy: -1.1, sw: 1.2, st: 0, sz: 1.15, a: .9 }, spores: { vy: .25, sw: 1.6, st: 0, sz: 1.2, a: .85 } };

export class Env {
  constructor(scene, tex) {
    this.scene = scene; this.T = tex; this.items = []; this.side = []; this.glowCol = new THREE.Color(.5, .95, 1); this.fogK = 1;
    this.skyTint = new THREE.Color(1, 1, 1); this.boltOn = true; this.boltEvery = [14, 30]; this.birdsOn = true; this.boltCol = new THREE.Color(.05, .06, .09);
    // tex.glow: Map(texture -> emissive mask, tools/glow_mask.py): masked sprites glow only on their runes / cracks (procedural key off)
    const plane = (t, o = {}) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), spriteMat(t, { fogNear: o.fogNear ?? 9999, fogFar: o.fogFar ?? 99999, glow: o.glow ?? .4 }));
      m.userData.glow0 = o.glow ?? .4; m.userData.fog0 = [o.fogNear ?? 9999, o.fogFar ?? 99999]; this.setGlow(m, tex.glow?.get(t) || null);
      m.renderOrder = o.ro ?? 0; if (o.tint) m.material.uniforms.tint.value.setRGB(...o.tint); if (o.alpha != null) m.material.uniforms.alpha.value = o.alpha; scene.add(m); return m; };
    // flowing layer (cloud bank, cloud sea): UV scroll on a mirrored-repeat texture + wobble + top-edge swell (water.js layerMat)
    const flow = (t, o = {}) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1, 40, 1), layerMat(t, o)); m.renderOrder = o.ro ?? 0;
      if (o.floorY != null) m.material.depthTest = false; // 11-26 grain: no depth test against the sea (z-fight speckle on iPhone); the shader clips at the waterline
      m.userData.fog0 = [o.fogNear ?? 9999, o.fogFar ?? 99999]; m.userData.p0 = { scroll: o.scroll ?? 0, wob: o.wob ?? 0, shimmer: o.shimmer ?? 0, swell: o.swell ?? 0, glow: o.glow ?? .4 };
      if (o.tint) m.material.uniforms.tint.value.setRGB(...o.tint); if (o.alpha != null) m.material.uniforms.alpha.value = o.alpha; scene.add(m); return m; };
    // far layers: fixed world placement, wide enough for any aspect
    if (tex.clouds) { const m = flow(tex.clouds, { ro: RO.clouds, tint: [.78, .7, .9], scroll: .0028, wob: .0015, swell: .006, swellF: 9, floorY: SEA_Y, floorFade: 16 }); this.clouds = m; m.position.set(0, 0, -170); this.items.push({ m, kind: 'drift', x: 0, sp: .6, amp: 6 }); }
    if (tex.far) { const m = plane(tex.far, { ro: RO.far, tint: [.92, .9, 1.05], alpha: .9 }); this.far = m; m.position.set(0, 26, -140); this.items.push({ m, kind: 'drift', x: 0, sp: -.4, amp: 4, y: 26, bob: 1.5 }); }
    // second god-ray sheet between the far and mid layers
    this.rays2 = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      uniforms: { t: SH.time, col: { value: new THREE.Color(1, .85, 1) }, k: { value: 1 } }, vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
      fragmentShader: `uniform float t; uniform vec3 col; uniform float k; varying vec2 vUv; void main(){ float r = 0.; for (int i = 0; i < 4; i++) { float fi = float(i); float c = .2 + fi * .2 + sin(t * .1 + fi * 1.7) * .03;
        r += smoothstep(.05, 0., abs(vUv.x - c - (1. - vUv.y) * (.5 - c) * .5)) * (.55 + .45 * sin(t * .35 + fi * 2.3)); }
        float a = r * .07 * k * smoothstep(0., .5, vUv.y) * smoothstep(1., .75, vUv.y); gl_FragColor = vec4(col * a, a); }` }));
    this.rays2.renderOrder = RO.rays; this.rays2.position.set(10, 30, -95); this.rays2.scale.set(160, 110, 1); scene.add(this.rays2);
    // mid floating ruins: 6 painted pieces, each placed twice (left / right), bob + slow rotation
    const mid = (tex.mid || []).filter(Boolean);
    const MID = [[-.95, 46, -100, 24], [.9, 38, -95, 22], [-.75, 14, -80, 15], [.78, 20, -78, 17], [-.98, 62, -112, 18], [.98, 58, -110, 20], [-.55, 72, -125, 12], [.5, 70, -122, 13], [-1.1, 4, -70, 12], [1.08, 8, -68, 11]];
    MID.forEach(([sx, y, z, h], i) => { if (!mid.length) return; const ti = i % mid.length, t = mid[ti]; const m = plane(t, { ro: RO.mid + Math.round(-z / 20), fogNear: 40, fogFar: 230, glow: 1, tint: [.82, .8, .95] });
      this.side.push(floaty({ m, sx, y, z, ph: rand(0, 6), sp: rand(.35, .6), kind: 'mid', ti, hh: h, flip: i % 3 === 2 ? -1 : 1 }, h, .045, .09, .025, .07)); });
    // cloud sea: one strip behind the titan's base, one in front (he rises out of it)
    if (tex.sea) {
      // both strips flow the same way on screen (front strip is x-mirrored, so its scroll sign flips); the near one faster (parallax)
      const back = flow(tex.sea, { ro: RO.seaBack, fogNear: 60, fogFar: 260, tint: [.9, .85, 1], glow: .4, scroll: .0045, wob: .0025, shimmer: .45, swell: .008, swellF: 14, floorY: SEA_Y, floorFade: 7 });
      this.items.push({ m: back, kind: 'drift', x: 0, sp: .25, amp: 8 }); this.seaBack = back;
      const front = flow(tex.sea, { ro: RO.seaFront, fogNear: 40, fogFar: 230, tint: [.95, .9, 1], glow: .4, scroll: -.008, wob: .003, shimmer: .7, swell: .012, swellF: 10, floorY: SEA_Y, floorFade: 2.5 });
      this.items.push({ m: front, kind: 'drift', x: 0, sp: -.3, amp: 5 }); this.seaFront = front;
    }
    // near mist wisps (soft, low alpha) in front of the titan, behind the ledge
    const mist = (tex.mist || []).filter(Boolean); this.mists = [];
    for (let i = 0; i < 7 && mist.length; i++) { const t = mist[i % mist.length]; const m = plane(t, { ro: RO.mist + i * .1, alpha: rand(.28, .45), tint: [.85, .78, 1] });
      const w = rand(26, 46); const x = rand(-30, 30); m.position.set(x, rand(-1, 7), rand(-26, -8));
      const it = { m, kind: 'mist', x, y: m.position.y, a0: m.material.uniforms.alpha.value, a00: m.material.uniforms.alpha.value, sp: rand(.5, 1.1) * (i % 3 ? 1 : .6), ph: rand(0, 6), ti: i % mist.length, w, flip: i % 2 ? -1 : 1 };
      this.items.push(it); this.mists.push(it); } // all drift one way (wind), wrap with a fade
    // foreground ledge the hero idles on + framing pillars + floating debris (screen-placed)
    if (tex.ledge) { this.ledge = plane(tex.ledge, { ro: RO.fg, fogNear: 9999, fogFar: 99999, glow: .9, tint: [.9, .88, 1] });
      // 11-26 bottom-aligned floor (user, iPhone: "make sure it's bottom aligned on all screens"): the painted ledge ends above the
      // bottom edge on tall phones. A filler strip under it continues the ledge's lowest solid row (same art, same tint, darkening
      // downward like rock in shadow) to below the frustum bottom; layout() sizes it per aspect. Drawn behind the ledge.
      // its lower part sits below the sea plane (y -0.8) at this depth, so the opaque sea used to cut it with a hard line: no depth
      // test for the ledge + filler (drawn after the scenery at renderOrder 350 anyway; hero / FX draw on top)
      this.ledge.material.depthTest = false;
      const lu = this.ledge.material.uniforms;
      this.ledgeFill = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide,
        uniforms: { map: lu.map, tint: lu.tint, row: { value: .8 } },
        vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
        fragmentShader: `uniform sampler2D map; uniform vec3 tint; uniform float row; varying vec2 vUv;
          void main(){ float y = 1. - vUv.y; // 0 at the top (joins the ledge) .. 1 at the bottom
            vec4 a = texture2D(map, vec2(vUv.x, 1. - row), 4.5), b = texture2D(map, vec2(vUv.x, 1. - row + .06), 4.5); // very blurred mip: a rock mass, no streaks
            float al = smoothstep(.3, .6, a.a); if (al < .02) discard;
            vec3 c = mix(a.rgb, b.rgb, .5) / max(.3, max(a.a, b.a)) * tint * mix(.5, .22, smoothstep(0., .8, y)); // un-premultiplied, darkens downward (shadow)
            gl_FragColor = vec4(c, al); }` }));
      this.ledgeFill.renderOrder = RO.fg - .5; this.ledgeFill.visible = false; scene.add(this.ledgeFill); }
    const fg = (tex.fg || []).filter(Boolean);
    if (fg.length >= 6) {
      // [tex index, screen x (-1..1), height (world), depth z, y (world bottom) or float, kind]
      const FG = [[0, -1.0, 9.5, -3, -3.4, 'pillar'], [1, 1.02, 5, -1, -2.6, 'pillar'], [2, .9, 1.5, 2, null, 'float', .3], [3, -.86, 1.0, 3, null, 'float', .4], [4, .62, .45, 4.5, null, 'float', .2], [5, .86, 1.5, 5.5, -.35, 'block'],
        [3, -.4, 1.4, -8, null, 'floatFar', .42], [2, .45, 2.2, -14, null, 'floatFar', .36]];
      FG.forEach(([ti, sx, h, z, yb, kind, sy], i) => { const t = fg[ti]; const m = plane(t, { ro: RO.fg + 1 + i * .1, fogNear: kind === 'floatFar' ? 30 : 9999, fogFar: 200, glow: .9, tint: kind === 'float' ? [.7, .65, .85] : [.85, .82, .97] });
        const s = { m, sx, y: yb, z, h, ph: rand(0, 6), kind, sp: rand(.6, 1.1), sy: sy || 0, ti, flip: sx > 0 && kind === 'pillar' ? -1 : 1 };
        this.side.push(kind.startsWith('float') ? floaty(s, h, .09, .16, .1, .22) : s); });
    }
    this.fitScales();
    // dust / ash / rain / snow / sprinkles / spores between the layers (theme.dust)
    const N = 360, pos = new Float32Array(N * 3), seed = new Float32Array(N * 4);
    for (let i = 0; i < N; i++) { pos.set([rand(-60, 60), rand(-4, 50), rand(-110, 8)], i * 3); seed.set([Math.random(), Math.random(), Math.random(), Math.random()], i * 4); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('seed', new THREE.BufferAttribute(seed, 4)); g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    const C = (r, gg, b) => ({ value: new THREE.Color(r, gg, b) });
    this.dustU = { t: SH.time, px: { value: 300 }, fogColor: SH.fogColor, wx: { value: 0 }, // wx: integrated wind-gust push (water.js wind)
      c0: C(.85, .78, 1), c1: C(1, .55, .25), c2: C(.85, .78, 1), ember: { value: .18 }, vy: { value: .5 }, sw: { value: 1 }, st: { value: 0 }, sz: { value: 1 }, ak: { value: .7 }, multi: { value: 0 } };
    this.dust = new THREE.Points(g, new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: this.dustU,
      vertexShader: `attribute vec4 seed; uniform float t; uniform float px; uniform float wx; uniform float ember; uniform float vy; uniform float sw; uniform float sz; uniform float multi;
        uniform vec3 c0; uniform vec3 c1; uniform vec3 c2; varying float vA; varying vec3 vC;
        void main(){ vec3 p = position; float em = step(seed.w, ember); float sp = .4 + seed.x * 1.2; p.y = mod(p.y + t * sp * vy * (em > .5 ? 1.6 : 1.) + 4., 54.) - 4.;
          p.x += sin(t * .3 + seed.y * 20.) * 2. * sw + t * .8 * (seed.z - .3) * (vy < 0. ? .3 : 1.) + wx * (.6 + seed.z * .8);
          p.x = mod(p.x + 60., 120.) - 60.; vec4 mv = modelViewMatrix * vec4(p, 1.); gl_Position = projectionMatrix * mv;
          float d = -mv.z; gl_PointSize = (em > .5 ? 1.6 : 1.1) * sz * (.6 + seed.z) * px / max(2., d); vA = (.35 + .65 * fract(seed.y * 7. + t * .2)) * smoothstep(2., 10., d) * (1. - smoothstep(90., 130., d));
          vC = multi > .5 ? (seed.y < .33 ? c0 : seed.y < .66 ? c1 : c2) : mix(c0, c1, em); }`,
      fragmentShader: `uniform float st; uniform float ak; varying float vA; varying vec3 vC; void main(){ vec2 q = gl_PointCoord - .5; float a;
        if (st > .5) { a = smoothstep(.09, .0, abs(q.x + q.y * .12)) * (1. - abs(q.y) * 2.); } else { float d = length(q) * 2.; if (d > 1.) discard; a = pow(1. - d, 2.); }
        a *= vA; if (a < .005) discard; gl_FragColor = vec4(vC * a * ak, a); }` }));
    this.dust.frustumCulled = false; this.dust.renderOrder = RO.dust; scene.add(this.dust);
    // ---- living sky (user 11-25: "animate the environment, not static"): slow drifting sun glow, far lightning, distant bird flocks
    this.sunGlow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), glowMat(1, .82, .95)); this.sunGlow.renderOrder = RO.sky + 1; this.sunGlow.scale.set(150, 110, 1); scene.add(this.sunGlow); this.sunA = .1;
    this.bolt = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), glowMat(.75, .85, 1)); this.bolt.renderOrder = RO.clouds + 1; this.bolt.visible = false; scene.add(this.bolt);
    this.boltT = rand(10, 18); this.boltA = 0; this.boltK = 0;
    this.birdCol = { value: new THREE.Color(.12, .06, .25) };
    const birdMat = () => new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, uniforms: { fl: { value: 0 }, fogColor: SH.fogColor, a: { value: .6 }, bc: this.birdCol },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }',
      fragmentShader: `uniform float fl; uniform vec3 fogColor; uniform float a; uniform vec3 bc; varying vec2 vUv; void main(){ vec2 p = (vUv - .5) * 2.; float ax = abs(p.x);
        float y = ax * fl * .55 - ax * ax * .25 * (1. - fl); float th = .16 * (1. - ax) + .03; float m = smoothstep(th, th * .35, abs(p.y - y)) * step(ax, .96);
        m = max(m, smoothstep(.16, .06, length(p * vec2(1., 1.4)))); if (m < .02) discard; gl_FragColor = vec4(mix(bc, fogColor, .45), m * a); }` });
    this.birds = Array.from({ length: 6 }, () => { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), birdMat()); m.visible = false; m.renderOrder = RO.mid + 1; scene.add(m); return { m, vx: 0, ph: 0, fs: 7, on: false }; });
    this.flockT = rand(4, 9);
  }
  // emissive mask on a painted plane: add it (one-time shader recompile), swap it, or blank it (arena without a mask for this slot)
  setGlow(m, gm) {
    const mat = m.material, g = mat.userData.glow;
    if (gm) { if (!g) addGlow(mat, gm, { src_var: 'c.rgb', mono: true, col: [this.glowCol.r, this.glowCol.g, this.glowCol.b], k: .8, rate: rand(.6, 1.2), depth: .3, src: .85, bloom: 1.6 }); else { g.glowMap.value = gm; g.glowK.value.setScalar(.8); }
      mat.uniforms.glow.value = 0; m.layers.enable(GLOW_LAYER); }
    else { if (g) { g.glowMap.value = black(); g.glowK.value.setScalar(0); } mat.uniforms.glow.value = m.userData.glow0 ?? .4; m.layers.disable(GLOW_LAYER); }
    if (mat.userData.glow) mat.userData.glow.glowC0.value.copy(this.glowCol);
  }
  // world sizes that follow each texture's aspect (constructor + after an arena swap)
  fitScales() {
    if (this.far) { const t = this.far.material.uniforms.map.value, w = 400; this.far.scale.set(w, w / asp(t), 1); }
    for (const s of this.side) { const t = s.m.material.uniforms.map.value; if (s.kind === 'mid') s.m.scale.set(s.hh * asp(t) * s.flip, s.hh, 1); else s.m.scale.set(s.h * asp(t) * s.flip, s.h, 1); }
    if (this.seaBack) { const b = this.seaBack, a = asp(b.material.uniforms.map.value); b.scale.set(320, 320 / a, 1); b.position.set(0, -2 + b.scale.y * .5 - b.scale.y * .55, -70); }
    if (this.seaFront) { const f = this.seaFront, a = asp(f.material.uniforms.map.value); f.scale.set(-170, 170 / a, 1); f.position.set(0, 3.5 - f.scale.y * .5, -31); }
    for (const it of this.mists || []) { const t = it.m.material.uniforms.map.value; it.m.scale.set(it.w * it.flip, it.w / asp(t), 1); }
  }
  // ---- arena swap (arena.js). th = merged theme (arena.js DEFAULT + arena.json theme), tex = { sky, clouds, far, sea, ledge, mid[], fg[], mist[], glow: Map }
  setTheme(th, tex) {
    const tt = th.tints || {}, setT = (m, c) => { if (m && c) m.material.uniforms.tint.value.setRGB(c[0], c[1], c[2]); };
    const glowOf = (t) => tex.glow?.get(t) || null;
    this.glowCol.setRGB(...(th.glowCol || [.5, .95, 1])); this.fogK = th.fogK ?? 1;
    const fogs = (m) => { const f = m.userData.fog0, u = m.material.uniforms; if (!f || f[0] > 5000) return; u.fogNear.value = f[0] * this.fogK; u.fogFar.value = f[1] * this.fogK; };
    const swap = (m, t, glow = true) => { if (!m || !t) return; m.material.uniforms.map.value = t; if (glow) this.setGlow(m, glowOf(t)); fogs(m); };
    const flowT = (m, t) => { if (!m || !t) return; t.wrapS = THREE.MirroredRepeatWrapping; t.needsUpdate = true; m.material.uniforms.map.value = t; fogs(m); };
    if (this.sky && tex.sky) this.sky.material.uniforms.map.value = tex.sky;
    this.skyTint.setRGB(...(th.sky || [1, 1, 1]));
    flowT(this.clouds, tex.clouds); setT(this.clouds, tt.clouds);
    if (this.clouds) { const u = this.clouds.material.uniforms; u.scroll.value = .0028 * (th.cloudScroll ?? 1); }
    swap(this.far, tex.far); setT(this.far, tt.far); if (this.far) this.far.material.uniforms.alpha.value = th.farAlpha ?? .9;
    const mid = (tex.mid || []).filter(Boolean), fg = (tex.fg || []).filter(Boolean), mist = (tex.mist || []).filter(Boolean);
    for (const s of this.side) { if (s.kind === 'mid' && mid.length) { swap(s.m, mid[s.ti % mid.length]); setT(s.m, tt.mid); }
      else if (s.kind !== 'mid' && fg.length >= 6) { swap(s.m, fg[s.ti]); setT(s.m, s.kind === 'float' ? tt.propsFloat : tt.props); } }
    const sea = th.sea || {};
    for (const [m, tint] of [[this.seaBack, tt.seaBack], [this.seaFront, tt.seaFront]]) { if (!m) continue; flowT(m, tex.sea); setT(m, tint); const u = m.material.uniforms, p = m.userData.p0;
      u.scroll.value = p.scroll * (sea.stripScroll ?? 1); u.wob.value = p.wob * (sea.stripWob ?? 1); u.shimmer.value = p.shimmer * (sea.stripShimmer ?? 1); u.swell.value = p.swell * (sea.stripSwell ?? 1); u.glow.value = sea.stripGlow ?? p.glow; }
    for (const it of this.mists || []) { if (mist.length) swap(it.m, mist[it.ti % mist.length], false); setT(it.m, tt.mist); it.a0 = it.a00 * (th.mistA ?? 1); }
    if (this.ledge && tex.ledge) { swap(this.ledge, tex.ledge); setT(this.ledge, tt.ledge); }
    // rays, sun, lightning, birds, dust
    const r = th.rays || {}; this.rays2.material.uniforms.col.value.setRGB(...(r.col2 || [1, .85, 1])); this.rays2.material.uniforms.k.value = r.k ?? 1;
    const ru = this.rays?.material.uniforms; if (ru?.col) { ru.col.value.setRGB(...(r.col || [.72, .6, 1])); if (ru.k) ru.k.value = r.k ?? 1; }
    this.sunGlow.material.uniforms.col.value.setRGB(...(th.sun?.col || [1, .82, .95])); this.sunA = th.sun?.a ?? .1;
    const b = th.bolt || {}; this.boltOn = b.on ?? true; this.boltEvery = b.every || [14, 30]; this.bolt.material.uniforms.col.value.setRGB(...(b.col || [.75, .85, 1]));
    this.boltCol.setRGB(...(b.flash || [.05, .06, .09])); this.boltT = Math.min(this.boltT, rand(this.boltEvery[0] * .4, this.boltEvery[0])); if (!this.boltOn) this.bolt.visible = false;
    const bd = th.birds || {}; this.birdsOn = bd.on ?? true; this.birdCol.value.setRGB(...(bd.col || [.12, .06, .25])); if (!this.birdsOn) for (const x of this.birds) { x.on = false; x.m.visible = false; }
    const d = th.dust || {}, D = DUST[d.type] || DUST.dust, U = this.dustU;
    U.c0.value.setRGB(...(d.col || [.85, .78, 1])); U.c1.value.setRGB(...(d.col2 || [1, .55, .25])); U.c2.value.setRGB(...(d.col3 || d.col || [.85, .78, 1]));
    U.ember.value = d.ember ?? (d.type === 'ash' ? .45 : .18); U.vy.value = d.vy ?? D.vy; U.sw.value = D.sw; U.st.value = D.st; U.sz.value = (d.size ?? 1) * D.sz; U.ak.value = (d.a ?? 1) * D.a; U.multi.value = d.type === 'sprinkles' ? 1 : 0;
    this.fitScales(); if (this.lastL) this.layout(...this.lastL);
  }
  // place screen-framed props for the current camera/aspect; heroHome is where the hero's feet stand
  layout(camera, W, H, heroHome, portrait) {
    this.lastL = [camera, W, H, heroHome, portrait];
    const shifted = camera.view?.enabled; if (shifted) { camera.view.enabled = false; camera.updateProjectionMatrix(); } // place with the plain camera (arena swap on the menu)
    camera.updateMatrixWorld(); this.cam = camera;
    const ray = new THREE.Raycaster(), at = (nx, ny, z) => { ray.setFromCamera({ x: nx, y: ny }, camera); const o = ray.ray.origin, d = ray.ray.direction, k = (z - o.z) / d.z; return [o.x + d.x * k, o.y + d.y * k]; };
    const halfW = (z) => Math.abs(at(1, 0, z)[0] - at(0, 0, z)[0]);
    for (const s of this.side) { // x from a screen fraction at the prop's depth; floating props also get y from a screen fraction (sy: 0 top .. 1 bottom)
      const [x, y] = at(s.sx, s.y == null && s.sy ? 1 - 2 * s.sy : 0, s.z); s.x = x; if (s.y == null) s.yy = y; s.m.position.set(s.x, 0, s.z);
      s.m.visible = !(portrait && s.kind === 'pillar'); } // 11-26 phone declutter: the big edge pillars covered the titan's fists; the ledge stays
    if (this.clouds) { const t = this.clouds.material.uniforms.map.value, w = Math.max(halfW(-170) * 2.4, 200), h = w / (t.image.width / t.image.height); this.clouds.scale.set(w, h, 1); this.clouds.position.y = Math.min(52, h * .8) - h * .5; }
    if (this.ledge) { // ledge under the hero: top surface (TOP of the painted art) at the hero's feet, wide enough to run off the screen edge on the hero's side
      const t = this.ledge.material.uniforms.map.value, a = t.image.width / t.image.height, w = Math.max(halfW(heroHome.z) * (portrait ? 2.3 : 1.25), 9);
      const h = w / a; this.ledge.scale.set(w, h, 1); this.ledgeTop = .3; // fraction of the art height above the walk line
      this.ledge.position.set(heroHome.x + w * (portrait ? .12 : .2), heroHome.y - h * (.5 - this.ledgeTop), heroHome.z + .05);
      if (this.ledgeFill) { // filler from the ledge's lowest solid row down past the frustum bottom (+1.5 for the raised fight camera)
        const L = this.ledge, f = this.ledgeFill, sb = solidRow(t), top = L.position.y + h * .5 - sb * h + h * .03, bot = at(0, -1, L.position.z)[1] - 1.5;
        f.material.uniforms.row.value = Math.max(0, sb - .03); this.ledgeFillOn = bot < top - h * .04;
        if (this.ledgeFillOn) { const fh = top - bot; f.scale.set(w, fh, 1); f.position.set(L.position.x, top - fh * .5, L.position.z - .02); }
      }
    }
    if (shifted) { camera.view.enabled = true; camera.updateProjectionMatrix(); }
  }
  update(t, dt, camera, sink = 0) {
    for (const it of this.items) { const m = it.m;
      if (it.kind === 'drift') { m.position.x = it.x + Math.sin(t * .02 * it.sp) * it.amp; if (it.y != null) m.position.y = it.y + Math.sin(t * .3) * (it.bob || 0); }
      else if (it.kind === 'mist') { // wisps drift with the wind across a 100-unit band, wrap, and fade in/out at the band ends
        it.x += dt * (it.sp * 1.1 + (this.water?.wind || 0) * .7); if (it.x > 50) it.x -= 100; else if (it.x < -50) it.x += 100; /* + wind gusts (water.js) */ const e = Math.min(1, (50 - Math.abs(it.x)) / 14);
        m.position.x = it.x; m.position.y = it.y + Math.sin(t * .2 * it.sp + it.ph) * .6; m.material.uniforms.alpha.value = it.a0 * e * (.85 + .15 * Math.sin(t * .3 + it.ph)); }
      m.quaternion.copy(camera.quaternion); }
    for (const s of this.side) { const m = s.m, y0 = s.y != null ? s.y : s.yy || 0, k = s.kind;
      if (k === 'pillar' || k === 'block') { m.position.set(s.x, y0 + s.h * .5, s.z); m.quaternion.copy(camera.quaternion); continue; }
      const a = t * s.bobS * s.sp + s.ph;
      m.position.y = y0 + Math.sin(a) * s.bob + Math.sin(a * 2.7 + s.ph2) * s.bob * .22;
      m.position.x = s.x + Math.sin(t * s.swayS + s.ph2) * s.sway;
      m.quaternion.copy(camera.quaternion); m.rotateZ(Math.sin(t * s.rotS + s.ph) * s.rot + Math.sin(t * s.rotS * .41 + s.ph2) * s.rot * .5); }
    this.rays2.quaternion.copy(camera.quaternion); this.rays2.rotateZ(Math.sin(t * .045) * .05); this.rays2.position.x = 10 + Math.sin(t * .03) * 6;
    if (this.ledge) this.ledge.quaternion.copy(camera.quaternion);
    if (this.ledgeFill) { this.ledgeFill.visible = !!this.ledgeFillOn && this.ledge.visible; this.ledgeFill.quaternion.copy(camera.quaternion); }
    const wind = this.water?.wind || 0; this.dustU.wx.value += wind * dt * 1.4;
    // sky: gentle colour breathing (around the arena's sky tint) + a slow sun glow that drifts and pulses
    const st = this.skyTint; if (this.sky) this.sky.material.uniforms.tint.value.setRGB(st.r * (1 + .035 * Math.sin(t * .13)), st.g * (1 + .025 * Math.sin(t * .1 + 1.3)), st.b * (1 + .045 * Math.sin(t * .08 + 2.1)));
    const sg = this.sunGlow; sg.position.set(Math.sin(t * .012) * 30 + 8, 44 + Math.sin(t * .05) * 3, -148); sg.quaternion.copy(camera.quaternion); sg.material.uniforms.fade.value = this.sunA * (1 + .4 * Math.sin(t * .23)); sg.visible = this.sunA > 0;
    // far lightning: every 14-30 s (theme.bolt.every) a short double/triple flicker behind the cloud bank (lights the bank a little)
    if (this.boltOn) { this.boltT -= dt; if (this.boltT < 0) { this.boltT = rand(this.boltEvery[0], this.boltEvery[1]); this.boltA = .45; this.bolt.visible = true; this.bolt.position.set(rand(-70, 70), rand(8, 22), -165); const s = rand(50, 80); this.bolt.scale.set(s, s * .7, 1); this.boltK = rand(.5, 1); } }
    if (this.boltA > 0) { this.boltA -= dt; const u = .45 - this.boltA, f = (Math.max(0, 1 - Math.abs(u - .03) * 20) + Math.max(0, 1 - Math.abs(u - .16) * 14) * .7 + Math.max(0, 1 - Math.abs(u - .3) * 18) * .5) * this.boltK;
      this.bolt.material.uniforms.fade.value = f * .55; this.bolt.quaternion.copy(camera.quaternion); const bc = this.boltCol; if (this.clouds) this.clouds.material.uniforms.flash.value.setRGB(f * bc.r, f * bc.g, f * bc.b);
      if (this.boltA <= 0) { this.bolt.visible = false; if (this.clouds) this.clouds.material.uniforms.flash.value.setRGB(0, 0, 0); } }
    // bird flocks: every 12-28 s 3-5 distant shapes cross the sky in a loose V, flapping with glides
    this.flockT -= dt; if (this.birdsOn && this.flockT < 0 && !this.birds.some((b) => b.on)) { this.flockT = rand(12, 28); const side = Math.random() < .5 ? 1 : -1, n = 3 + Math.floor(Math.random() * 3), y = rand(30, 52), z = rand(-125, -105), sp = rand(5, 8);
      for (let i = 0; i < n; i++) { const b = this.birds[i]; b.on = true; b.m.visible = true; b.vx = sp * side; b.ph = rand(0, 6); b.fs = rand(6, 8); const sz = rand(1.4, 2);
        b.m.scale.set(sz * 1.6, sz * .7, 1); b.m.position.set(-side * (72 + i * 3.5), y + (i % 2 ? 1 : -1) * Math.ceil(i / 2) * 1.6, z + i * 2); } }
    for (const b of this.birds) if (b.on) { b.m.position.x += b.vx * dt; b.m.position.y += Math.sin(t * .7 + b.ph) * dt * .5; b.ph += dt * b.fs;
      const glide = Math.sin(t * .5 + b.ph * .05) > .4 ? .15 : 1; b.m.material.uniforms.fl.value = Math.sin(b.ph) * glide; b.m.quaternion.copy(camera.quaternion);
      if (Math.abs(b.m.position.x) > 100 && Math.sign(b.m.position.x) === Math.sign(b.vx)) { b.on = false; b.m.visible = false; } }
  }
}
